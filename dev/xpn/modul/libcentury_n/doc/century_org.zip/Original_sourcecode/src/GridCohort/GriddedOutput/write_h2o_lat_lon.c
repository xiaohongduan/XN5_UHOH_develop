
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Rewrite the h2o.nc netCDF file using COARDS standards */
/* The original file was organized variable(cell, time) */
/*                                 variable(cell, layer, time */
/* The new file is organized variable(time, lat, lon) */
/*                           variable(time, layer, lat, lon) */

#include <stdio.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf_ll.h"

    int write_h2o_ll_(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      /* INDX is dimensioned {CELL, TIME} */
      size_t indx[2]  = {0, 0};
      /* START_LAYER and COUNT_LAYER are dimensioned {TIME, LAYER, LAT, LON} */
      size_t start_layer[4] = {0, 0, 0, 0};
      size_t count_layer[4] = {0, 0, 0, 0};
      /* INDX_LAYER is dimensioned {CELL, LAYER, TIME} */
      size_t indx_layer[3]  = {0, 0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  avh2o1_vals[MAXCELLS], avh2o2_vals[MAXCELLS], avh2o3_vals[MAXCELLS], 
             asmos1_vals[MAXCELLS], asmos2_vals[MAXCELLS], asmos3_vals[MAXCELLS],
             asmos4_vals[MAXCELLS], asmos5_vals[MAXCELLS], asmos6_vals[MAXCELLS],
             asmos7_vals[MAXCELLS], asmos8_vals[MAXCELLS], asmos9_vals[MAXCELLS],
             asmos10_vals[MAXCELLS], evap_vals[MAXCELLS], pet_vals[MAXCELLS],
             rwcf_vals[MAXCELLS], snlq_vals[MAXCELLS], snow_vals[MAXCELLS],
             stemp_vals[MAXCELLS], stream1_vals[MAXCELLS], stream2_vals[MAXCELLS],
             stream5_vals[MAXCELLS], stream6_vals[MAXCELLS], tran_vals[MAXCELLS],
             runoff_vals[MAXCELLS];
      int status;
      int oldh2oid;
      int oldasmosid, oldavh2o1id, oldavh2o2id, oldavh2o3id, oldevapid,
          oldpetid, oldrwcfid, oldsnlqid, oldsnowid, oldstempid, oldstream1id,
          oldstream2id, oldstream5id, oldstream6id, oldtranid, oldrunoffid;
      int ii, jj, kk, ngrids;

      /* Open old version of h2o.nc file */
      status = nc_open("h2o.nc", NC_NOWRITE, &oldh2oid);
      if (status != NC_NOERR) handle_error("nc_open(h2o.nc)", status);

      /* Get the indices for the h2o output variables */
      status = nc_inq_varid(oldh2oid, "asmos", &oldasmosid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for asmos",status);
      status = nc_inq_varid(oldh2oid, "avh2o1", &oldavh2o1id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for avh2o1",status);
      status = nc_inq_varid(oldh2oid, "avh2o2", &oldavh2o2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for avh2o2",status);
      status = nc_inq_varid(oldh2oid, "avh2o3", &oldavh2o3id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for avh2o3",status);
      status = nc_inq_varid(oldh2oid, "evap", &oldevapid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for evap",status);
      status = nc_inq_varid(oldh2oid, "pet", &oldpetid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for pet",status);
      status = nc_inq_varid(oldh2oid, "rwcf", &oldrwcfid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for rwcf",status);
      status = nc_inq_varid(oldh2oid, "snlq", &oldsnlqid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for snlq",status);
      status = nc_inq_varid(oldh2oid, "snow", &oldsnowid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for snow",status);
      status = nc_inq_varid(oldh2oid, "stemp", &oldstempid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for stemp",status);
      status = nc_inq_varid(oldh2oid, "stream1", &oldstream1id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for stream1",status);
      status = nc_inq_varid(oldh2oid, "stream2", &oldstream2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for stream2",status);
      status = nc_inq_varid(oldh2oid, "stream5", &oldstream5id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for stream5",status);
      status = nc_inq_varid(oldh2oid, "stream6", &oldstream6id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for stream6",status);
      status = nc_inq_varid(oldh2oid, "tran", &oldtranid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for tran",status);
      status = nc_inq_varid(oldh2oid, "runoff", &oldrunoffid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for runoff",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        avh2o1_vals[ii] = fill;
        avh2o2_vals[ii] = fill;
        avh2o3_vals[ii] = fill;
        asmos1_vals[ii] = fill;
        asmos2_vals[ii] = fill;
        asmos3_vals[ii] = fill;
        asmos4_vals[ii] = fill;
        asmos5_vals[ii] = fill;
        asmos6_vals[ii] = fill;
        asmos7_vals[ii] = fill;
        asmos8_vals[ii] = fill;
        asmos9_vals[ii] = fill;
        asmos10_vals[ii] = fill;
        evap_vals[ii] = fill;
        pet_vals[ii] = fill;
        rwcf_vals[ii] = fill;
        snlq_vals[ii] = fill;
        snow_vals[ii] = fill;
        stemp_vals[ii] = fill;
        stream1_vals[ii] = fill;
        stream2_vals[ii] = fill;
        stream5_vals[ii] = fill;
        stream6_vals[ii] = fill;
        tran_vals[ii] = fill;
        runoff_vals[ii] = fill;
      }

      ngrids = 0;
      indx[0] = 0;
      indx[1] = 0;
      start[0] = 0;
      start[1] = 0;
      start[2] = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx_layer[0] = 0;
      indx_layer[1] = 0;
      indx_layer[2] = 0;
      start_layer[0] = 0;
      start_layer[1] = 0;
      start_layer[2] = 0;
      start_layer[3] = 0;
      count_layer[0] = 1;
      count_layer[1] = 1;
      count_layer[2] = *nlat;
      count_layer[3] = *nlon;
      /* Re-write the h2o output file */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldh2oid, oldavh2o1id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for avh2o1",status);
            }
            avh2o1_vals[jj] = val;
            status = nc_get_var1_float(oldh2oid, oldavh2o2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for avh2o2",status);
            }
            avh2o2_vals[jj] = val;
            status = nc_get_var1_float(oldh2oid, oldavh2o3id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for avh2o3",status);
            }
            avh2o3_vals[jj] = val;
            indx_layer[1] = 0;
            status = nc_get_var1_float(oldh2oid, oldasmosid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for asmos1",status);
            }
            asmos1_vals[jj] = val;
            indx_layer[1] = 1;
            status = nc_get_var1_float(oldh2oid, oldasmosid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for asmos2",status);
            }
            asmos2_vals[jj] = val;
            indx_layer[1] = 2;
            status = nc_get_var1_float(oldh2oid, oldasmosid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for asmos3",status);
            }
            asmos3_vals[jj] = val;
            indx_layer[1] = 3;
            status = nc_get_var1_float(oldh2oid, oldasmosid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for asmos4",status);
            }
            asmos4_vals[jj] = val;
            indx_layer[1] = 4;
            status = nc_get_var1_float(oldh2oid, oldasmosid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for asmos5",status);
            }
            asmos5_vals[jj] = val;
            indx_layer[1] = 5;
            status = nc_get_var1_float(oldh2oid, oldasmosid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for asmos6",status);
            }
            asmos6_vals[jj] = val;
            indx_layer[1] = 6;
            status = nc_get_var1_float(oldh2oid, oldasmosid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for asmos7",status);
            }
            asmos7_vals[jj] = val;
            indx_layer[1] = 7;
            status = nc_get_var1_float(oldh2oid, oldasmosid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for asmos8",status);
            }
            asmos8_vals[jj] = val;
            indx_layer[1] = 8;
            status = nc_get_var1_float(oldh2oid, oldasmosid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for asmos9",status);
            }
            asmos9_vals[jj] = val;
            indx_layer[1] = 9;
            status = nc_get_var1_float(oldh2oid, oldasmosid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for asmos10",status);
            }
            asmos10_vals[jj] = val;
            status = nc_get_var1_float(oldh2oid, oldevapid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for evap",status);
            }
            evap_vals[jj] = val;
            status = nc_get_var1_float(oldh2oid, oldpetid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for pet",status);
            }
            pet_vals[jj] = val;
            status = nc_get_var1_float(oldh2oid, oldrwcfid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for rwcf",status);
            }
            rwcf_vals[jj] = val;
            status = nc_get_var1_float(oldh2oid, oldsnlqid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for snlq",status);
            }
            snlq_vals[jj] = val;
            status = nc_get_var1_float(oldh2oid, oldsnowid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for snow",status);
            }
            snow_vals[jj] = val;
            status = nc_get_var1_float(oldh2oid, oldstempid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for stemp",status);
            }
            stemp_vals[jj] = val;
            status = nc_get_var1_float(oldh2oid, oldstream1id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for stream1",status);
            }
            stream1_vals[jj] = val;
            status = nc_get_var1_float(oldh2oid, oldstream2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for stream2",status);
            }
            stream2_vals[jj] = val;
            status = nc_get_var1_float(oldh2oid, oldstream5id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for stream5",status);
            }
            stream5_vals[jj] = val;
            status = nc_get_var1_float(oldh2oid, oldstream6id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for stream6",status);
            }
            stream6_vals[jj] = val;
            status = nc_get_var1_float(oldh2oid, oldtranid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for tran",status);
            }
            tran_vals[jj] = val;
            status = nc_get_var1_float(oldh2oid, oldrunoffid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for runoff",status);
            }
            runoff_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
            indx_layer[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        indx_layer[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(h2oll_ncid, avh2o1ll_id, start, count, avh2o1_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for avh2o1",status);
        status = nc_put_vara_float(h2oll_ncid, avh2o2ll_id, start, count, avh2o2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for avh2o2",status);
        status = nc_put_vara_float(h2oll_ncid, avh2o3ll_id, start, count, avh2o3_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for avh2o3",status);
        start_layer[1] = 0;
        status = nc_put_vara_float(h2oll_ncid, asmosll_id, start_layer, count_layer, asmos1_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for asmos1",status);
        start_layer[1] = 1;
        status = nc_put_vara_float(h2oll_ncid, asmosll_id, start_layer, count_layer, asmos2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for asmos2",status);
        start_layer[1] = 2;
        status = nc_put_vara_float(h2oll_ncid, asmosll_id, start_layer, count_layer, asmos3_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for asmos3",status);
        start_layer[1] = 3;
        status = nc_put_vara_float(h2oll_ncid, asmosll_id, start_layer, count_layer, asmos4_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for asmos4",status);
        start_layer[1] = 4;
        status = nc_put_vara_float(h2oll_ncid, asmosll_id, start_layer, count_layer, asmos5_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for asmos5",status);
        start_layer[1] = 5;
        status = nc_put_vara_float(h2oll_ncid, asmosll_id, start_layer, count_layer, asmos6_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for asmos6",status);
        start_layer[1] = 6;
        status = nc_put_vara_float(h2oll_ncid, asmosll_id, start_layer, count_layer, asmos7_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for asmos7",status);
        start_layer[1] = 7;
        status = nc_put_vara_float(h2oll_ncid, asmosll_id, start_layer, count_layer, asmos8_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for asmos8",status);
        start_layer[1] = 8;
        status = nc_put_vara_float(h2oll_ncid, asmosll_id, start_layer, count_layer, asmos9_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for asmos9",status);
        start_layer[1] = 9;
        status = nc_put_vara_float(h2oll_ncid, asmosll_id, start_layer, count_layer, asmos10_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for asmos10",status);
        status = nc_put_vara_float(h2oll_ncid, evapll_id, start, count, evap_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for evap",status);
        status = nc_put_vara_float(h2oll_ncid, petll_id, start, count, pet_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for pet",status);
        status = nc_put_vara_float(h2oll_ncid, rwcfll_id, start, count, rwcf_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for rwcf",status);
        status = nc_put_vara_float(h2oll_ncid, snlqll_id, start, count, snlq_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for snlq",status);
        status = nc_put_vara_float(h2oll_ncid, snowll_id, start, count, snow_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for snow",status);
        status = nc_put_vara_float(h2oll_ncid, stempll_id, start, count, stemp_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for stemp",status);
        status = nc_put_vara_float(h2oll_ncid, stream1ll_id, start, count, stream1_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for stream1",status);
        status = nc_put_vara_float(h2oll_ncid, stream2ll_id, start, count, stream2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for stream2",status);
        status = nc_put_vara_float(h2oll_ncid, stream5ll_id, start, count, stream5_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for stream5",status);
        status = nc_put_vara_float(h2oll_ncid, stream6ll_id, start, count, stream6_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for stream6",status);
        status = nc_put_vara_float(h2oll_ncid, tranll_id, start, count, tran_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for tran",status);
        status = nc_put_vara_float(h2oll_ncid, runoll_id, start, count, runoff_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for runoff",status);
        /* Increment the time index */
        start[0]++;
        start_layer[0]++;
        indx[1]++;
        indx_layer[2]++;
      } 

      /* Close the old output file */
      nc_close(oldh2oid);

      return 0;
    }
