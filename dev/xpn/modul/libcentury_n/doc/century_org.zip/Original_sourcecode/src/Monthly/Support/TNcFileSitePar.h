#ifndef INC_TNcFileSitePar_h
#define INC_TNcFileSitePar_h
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TNcFileSitePar.h
//	Class:	  TNcSiteParameters, TNcSiteParamDef
//
//	Description:
//	Classes for I/O of netCDF files for the TMCSiteParameters class.
//	Derived from the class TNcFile.
//	These are friends of class TMCSiteParameters.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Mar98
// ----------------------------------------------------------------------------
//	Mar99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added member variable for compatible highest netCDF file version.
//	* Modified TNcSiteParameters:Read and Write to use a variable to index
//	  the variables array - necessary to allow for different file versions
//	  to have different variables stored in them. Future versions will
//	  modify these to examine the version of the file to determine what
//	  variables Read/Write can read/write to the file.
//	* Ditto for TNcSiteParamDef::Read.
//	May00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Version = 2
//	* Added RUNOFF parameters.
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* A bit of cleaning up.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Notes:
//	Classes and their corresponding netCDF files:
//	TNcSiteParameters	SiteParam.nc
//	TNcSiteParamDef		SiteParamDef.nc
// ----------------------------------------------------------------------------

#include "TNcFile.h"
//#include "TMCSiteParameters.h"	// assume is included prior in parent file
//#include "TMCSiteParamInfo.h"	// assume is included prior in parent file

//	-----------------------------------------------------------------------
//	TNcSiteParameters
//	Class for I/O of the "SiteParam.nc" netCDF file.
class TNcSiteParameters : public TNcFile
{
  public:
	//--- constructors and destructor
	TNcSiteParameters ( TEH::TFileName const & file )
	  : TNcFile ( file, NCFT_SiteParam, version )
	  {
	  }
	~TNcSiteParameters ()
	  {
	  }

	//--- functions
	bool Read (				// Reads entire contents
	  TMCSiteParameters & sp);
	bool Write (				// Write (replace) contents
	  TMCSiteParameters & sp);
/*
        int GetNumParamsRead () const           // Number of paramters read
          { return numParamsRead; }             //   -mdh 10/31/01

  protected:
        int numParamsRead;                      // -mdh 10/31/01
*/

  private:
	static short const version;		// netCDf file version number
};

//	-----------------------------------------------------------------------
//	TNcSiteParamDef
//	Class for I/O of the "SiteParamDef.nc" netCDF file.
class TNcSiteParamDef : public TNcFile
{
  public:
	//--- constructors and desor
	TNcSiteParamDef ( TEH::TFileName const & file )
	  : TNcFile ( file, NCFT_SiteParamDef, version )
	  {
	  }
	~TNcSiteParamDef ()
	  {
	  }

	//--- functions
	bool Read (TMCSiteParamInfo& pi);	// Reads entire contents

  private:
	static short const version;		// version number (highest)
};

#endif // INC_TNcFileSitePar_h
