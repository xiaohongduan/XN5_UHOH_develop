// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  partit.cpp
//	Class:	  TCentury
//	Function: PartitionResidue
//
//	Description:
//	Partition residue from compartments cdonor and edonor
//	into layer "layer" of structural and metabolic.
// ----------------------------------------------------------------------------
//	History:
//	Jan00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added assertions for all divisions.
//	* Cleaned up variables; declared only where needed.
// ----------------------------------------------------------------------------

#include "TCentury.h"

void TCentury::PartitionResidue (
	float const residueC,	// amount of carbon in the residue.
	float const* recres,	// array [NUMELEM]: residue E:C
	short const layer,	// layer (SRFC or SOIL)
	float* const cdonor,	// array [ISOS]: isotope compartments
	float* const edonor,	// array [NUMELEM]: NPS compartments
	float const frlign,	// fraction of incoming material = lignin.
	float const fractionLabeledC)// fraction of C = labeled.
{
    Assert (residueC >= 0.0f);
    if ( !AmountIsSignificant (residueC) )		// anything to do?
	return;						// ...no

    Assert (layer == SRFC || layer == SOIL);
    Assert (frlign >= 0.0f);
    Assert (frlign <= 1.0f);

    float accum[ISOS] =		// accumulator
	{ 0.0f, 0.0f };
    float directAbsorbE[NUMELEM];	// Direct absorption of E by residue
    float residueE[NUMELEM];		// amount of element in residue

    float actualFractionLabeledC;
    if (fractionLabeledC < 0.0f)
    {
	if (cdonor[1] <= 0.0f)
	    actualFractionLabeledC = 0.0f;
	else
	    actualFractionLabeledC = 1.0f;
    }
    else
    	actualFractionLabeledC = fractionLabeledC;

    for (short e = 0; e < site.nelem; ++e)	// For each mineral element...
    {
	residueE[e] = residueC * recres[e];	// amount of element in residue

	// Direct absorption of mineral element by residue
	// (mineral will be transferred to donor compartment and then
	// partitioned into structural and metabolic using flow routines.)
	// If minerl(SRFC,e) is negative then directAbsorbE = zero.

	if (soil->QuantityE ((TMineralElements)e, 0.0f, wt.simDepth) < 0.0f)
	    directAbsorbE[e] = 0.0f;
	else
	{
	    Assert (fixed.pabres != 0.0f);
	    directAbsorbE[e] =
		damr_ref (layer, e) *
		soil->QuantityE ((TMineralElements)e, 0.0f, wt.simDepth) *
			std::max (residueC / fixed.pabres, 1.0f);
	}

	// If C/E ratio is too low, transfer just enough to make
	// C/E of residue = damrmn
	float ratioCTotalE;
	if (residueE[e] + directAbsorbE[e] <= 0.0f)
	    ratioCTotalE = 0.0f;
	else
	{
	    Assert (residueE[e] != directAbsorbE[e]);
	    ratioCTotalE = residueC / (residueE[e] + directAbsorbE[e]);
	}
	if (ratioCTotalE < fixed.damrmn[e])
	{
	    Assert (fixed.damrmn[e] != 0.0f);
	    directAbsorbE[e] = residueC / fixed.damrmn[e] - residueE[e];
	}
	directAbsorbE[e] = std::max (directAbsorbE[e], 0.0f);
	soilFlows->FlowNPSfromMineralSoil (
		(TMineralElements)e, &edonor[e],
		directAbsorbE[e], wt.simDepth );
    }

    // Partition carbon into structural and metabolic fraction of
    // residue (including direct absorption) which is nitrogen
    Assert (residueC != 0.0f);
    float const fractionN =
    	(residueE[N] + directAbsorbE[N]) / (residueC * 2.5f);
    Assert (fractionN > 0.0f);

    // Carbon added to metabolic
    // Compute the fraction of carbon that goes to metabolic.
    // Make sure the fraction of residue which is lignin isn't
    // greater than the fraction which goes to structural.  -rm 12/91
    // Lignin/nitrogen ratio of residue:
    float const rlnres = frlign / fractionN;
    float frmet = fixed.spl[INTCPT] - fixed.spl[SLOPE] * rlnres;
    frmet = std::min ( frmet, 1.0f - frlign );
    frmet = std::max ( frmet, 0.2f );    // At least 20% goes to metabolic

    // Compute amounts to flow
    float const caddm = 			// C added to metabolic
    	std::max ( residueC * frmet, 0.0f );
    float const cadds = residueC - caddm;	// C added to structural

    // Adjust lignin content of structural.
    // fligst is the fraction of incoming structural residue
    // which is lignin; restricting it to a maximum of .8
    // original: fligst = frlign / (cadds / residueC);
    // Changed allowable maximum from .8 to .6 -rm 5/92
    // Changed maximum fraction from .6 to 1.0  -lh 1/93
    Assert (cadds != 0.0f);
    float const fligst = std::min ( frlign * residueC / cadds, 1.0f );

    // Determine what type of labeling is to be done
    if (param.labtyp != Lbl_13C)			// 14C labeling
    {
	// Carbon added to metabolic
	accum[UNLABL] = accum[LABELD] = 0.0f;
	ScheduleCFlow ( st->time, caddm, actualFractionLabeledC, 1.0f,
			&cdonor[UNLABL], &metcis_ref (layer, UNLABL),
			&cdonor[LABELD], &metcis_ref (layer, LABELD),
			accum);
	cropC.cinput += accum[UNLABL] + accum[LABELD];

	// Carbon added to structural
	accum[UNLABL] = accum[LABELD] = 0.0f;
	ScheduleCFlow ( st->time, cadds, actualFractionLabeledC, 1.0f,
			&cdonor[UNLABL], &strcis_ref (layer, UNLABL),
			&cdonor[LABELD], &strcis_ref (layer, LABELD),
			accum);
	cropC.cinput += accum[UNLABL] + accum[LABELD];
    }
    else						// 13C labeling
    {
    	float c13frac;
	if (actualFractionLabeledC > 0.0f && actualFractionLabeledC < 1.0f)
	{
	    // in incoming:
	    float c13c12r =
	    	1.0f / (1.0f / actualFractionLabeledC - 1.0f);	// 13C:12C
	    float const delin =					// delta 13C
	    	(c13c12r / PEEDEE - 1.0f) * 1000.0f;
	    // in lignin:
	    float const dellig = delin + fixed.dligdf;		// delta 13C
	    c13c12r = dellig * PEEDEE * 0.001f + PEEDEE;	// 13C:12C
	    c13frac = 1.0f / (1.0f / c13c12r + 1.0f);	// frac. 13C
	}
	else if (actualFractionLabeledC == 0.0f)
	    c13frac = 0.0f;	    	// Set fraction of 13C in lignin to 0
	else	// == 1; set the fraction of 13C in lignin to 1
	    c13frac = 1.0f;

	float const c13lig = c13frac * frlign * residueC;  // 13C in lignin
	float const c13nlig =
	    residueC * actualFractionLabeledC - c13lig;	// 13C in non-lignin
	// Flow 13C to structural
	Assert (frlign != 1.0f);
	float const c13struc = cadds * fligst * c13frac + cadds *
		(1.0f - fligst) * c13nlig / ((1.0f - frlign) * residueC);
	SCHEDULE_FLOW(flows, &cdonor[LABELD], &strcis_ref (layer, LABELD),
			st->time, c13struc);
	cropC.cinput += c13struc;
	// Flow 12C to structural
	float const c12struc = cadds - c13struc;
	SCHEDULE_FLOW(flows, &cdonor[UNLABL], &strcis_ref (layer, UNLABL),
			st->time, c12struc);
	cropC.cinput += c12struc;
	// Flow 13C to metabolic
	float const c13met = residueC * actualFractionLabeledC - c13struc;
	SCHEDULE_FLOW(flows, &cdonor[LABELD], &metcis_ref (layer, LABELD),
			st->time, c13met);
	cropC.cinput += c13met;
	// Flow 12C to metabolic
	float const c12met = caddm - c13met;
	SCHEDULE_FLOW(flows, &cdonor[UNLABL], &metcis_ref (layer, UNLABL),
			st->time, c12met);
	cropC.cinput += c12met;
    }

    // Adjust lignin
    AdjustLigninFraction (soilC.strucc[layer], fligst, cadds,
			  soilC.strlig[layer]);

    // Partition mineral elements into structural and metabolic
    for (short e = 0; e < site.nelem; ++e)
    {
	// Flow  E into structural
	Assert (fixed.rcestr[e] != 0.0f);
	float amtAdded = cadds / fixed.rcestr[e];
	SCHEDULE_FLOW(flows, &edonor[e], &struce_ref (layer, e),
			st->time, amtAdded);
	// Flow  E into metabolic
	amtAdded = residueE[e] + directAbsorbE[e] - amtAdded;
	SCHEDULE_FLOW(flows, &edonor[e], &metabe_ref (layer, e),
			st->time, amtAdded);
    }
}

//--- end of file ---
