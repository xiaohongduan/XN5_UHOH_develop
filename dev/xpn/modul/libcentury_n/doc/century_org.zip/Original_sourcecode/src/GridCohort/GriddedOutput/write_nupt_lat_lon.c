
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Rewrite the nupt.nc netCDF file using COARDS standards */
/* The original file was organized variable(cell, time) */
/* The new file is organized variable(time, lat, lon) */

#include <stdio.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf_ll.h"

    int write_nupt_ll_(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  agcnup_vals[MAXCELLS], bgcnup_vals[MAXCELLS], rlvnup_vals[MAXCELLS],
             frtnup_vals[MAXCELLS], fbrnup_vals[MAXCELLS], rlwnup_vals[MAXCELLS],
             crtnup_vals[MAXCELLS];
      int status;
      int oldnuptid;
      int oldagcnupid, oldbgcnupid, oldrlvnupid, oldfrtnupid, oldfbrnupid,
          oldrlwnupid, oldcrtnupid;
      int ii, jj, ngrids;

      /* Open old version of nupt.nc file */
      status = nc_open("nupt.nc", NC_NOWRITE, &oldnuptid);
      if (status != NC_NOERR) handle_error("nc_open(nupt.nc)", status);

      /* Get the indices for the nupt output variables */
      status = nc_inq_varid(oldnuptid, "agcnup", &oldagcnupid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for agcnup",status);
      status = nc_inq_varid(oldnuptid, "bgcnup", &oldbgcnupid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for bgcnup",status);
      status = nc_inq_varid(oldnuptid, "rlvnup", &oldrlvnupid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for rlvnup",status);
      status = nc_inq_varid(oldnuptid, "frtnup", &oldfrtnupid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for frtnup",status);
      status = nc_inq_varid(oldnuptid, "fbrnup", &oldfbrnupid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for fbrnup",status);
      status = nc_inq_varid(oldnuptid, "rlwnup", &oldrlwnupid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for rlwnup",status);
      status = nc_inq_varid(oldnuptid, "crtnup", &oldcrtnupid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for crtnup",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        agcnup_vals[ii] = fill;
        bgcnup_vals[ii] = fill;
        rlvnup_vals[ii] = fill;
        frtnup_vals[ii] = fill;
        fbrnup_vals[ii] = fill;
        rlwnup_vals[ii] = fill;
        crtnup_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the nupt output file */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldnuptid, oldagcnupid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for agcnup",status);
            }
            agcnup_vals[jj] = val;
            status = nc_get_var1_float(oldnuptid, oldbgcnupid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for bgcnup",status);
            }
            bgcnup_vals[jj] = val;
            status = nc_get_var1_float(oldnuptid, oldrlvnupid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for rlvnup",status);
            }
            rlvnup_vals[jj] = val;
            status = nc_get_var1_float(oldnuptid, oldfrtnupid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for frtnup",status);
            }
            frtnup_vals[jj] = val;
            status = nc_get_var1_float(oldnuptid, oldfbrnupid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for fbrnup",status);
            }
            fbrnup_vals[jj] = val;
            status = nc_get_var1_float(oldnuptid, oldrlwnupid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for rlwnup",status);
            }
            rlwnup_vals[jj] = val;
            status = nc_get_var1_float(oldnuptid, oldcrtnupid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for crtnup",status);
            }
            crtnup_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(nuptll_ncid, agcnupll_id, start, count, agcnup_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for agcnup",status);
        status = nc_put_vara_float(nuptll_ncid, bgcnupll_id, start, count, bgcnup_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for bgcnup",status);
        status = nc_put_vara_float(nuptll_ncid, rlvnupll_id, start, count, rlvnup_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for rlvnup",status);
        status = nc_put_vara_float(nuptll_ncid, frtnupll_id, start, count, frtnup_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for frtnup",status);
        status = nc_put_vara_float(nuptll_ncid, fbrnupll_id, start, count, fbrnup_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for fbrnup",status);
        status = nc_put_vara_float(nuptll_ncid, rlwnupll_id, start, count, rlwnup_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for rlwnup",status);
        status = nc_put_vara_float(nuptll_ncid, crtnupll_id, start, count, crtnup_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for crtnup",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldnuptid);

      return 0;
    }
