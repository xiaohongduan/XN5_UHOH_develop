#ifndef INC_ncftypes_h
#define INC_ncftypes_h

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//		  Century Model Interface V GUI
//	File:	  ncftypes.h
//
//	Description:
//	Contains constants corresponding to Century/CMI netCDF file types.
//	Note: There are several values not currently used.
//	      See the comments in the list.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Sep98
// ----------------------------------------------------------------------------
//	History:
//	Feb99	Tom Hilinski
//	* Added value for Century restart file.
//	Apr03	Tom Hilinski
//	* Added value for ecosystem summary output.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Notes:
//	Any changes to the this file must be reflected in the netCDF file,
//	"NCFTypes.cdl".
// ----------------------------------------------------------------------------

enum TNcFileType
{
	NCFT_Unknown = 0,	// 0 =  Unknown (should never be used).
	NCFT_ManageScheme,	// 1 =  name = "ManageScheme"
	NCFT_ManageDef,		// 2 =  name = "ManageDef"
	NCFT_ManageInst,	// 3 =  name = "ManageInst"
	NCFT_BlkHeader,		// 4 =  name = "BlkHeader"
	NCFT_BlkDef,		// 5 =  name = "BlkDef"
	NCFT_SiteParamDef,	// 6 =  name = "SiteParamDef"
	NCFT_SiteParam,		// 7 =  name = "SiteParam"
	NCFT_OutVarsDef,	// 8 =  name = "OutVarsDef"
	NCFT_EcoSumOutVarsDef,	// 9 =  name = "EcoSumOutVarsDef"
	// weather, 14C, parameter file values are not currently used:
	NCFT_Weather,		// 9 =  weather data
	NCFT_14C,		// 10 = 14C data
	NCFT_ParamCrop,		// 11 = Century parameters database: crop
	NCFT_ParamCult,		// 12 = Century parameters database: cult
	NCFT_ParamFert,		// 13 = Century parameters database: fert
	NCFT_ParamFire,		// 14 = Century parameters database: fire
	NCFT_ParamFix ,		// 15 = Century parameters database: fix
	NCFT_ParamGraz,		// 16 = Century parameters database: graz
	NCFT_ParamHarv,		// 17 = Century parameters database: harv
	NCFT_ParamIrri,		// 18 = Century parameters database: irri
	NCFT_ParamOmad,		// 19 = Century parameters database: omad
	NCFT_ParamTree,		// 20 = Century parameters database: tree
	NCFT_ParamTrem,		// 21 = Century parameters database: trem
	// 22-29 = Reserved for future use for parameter files.
	NCFT_CenturyOutput=30,	// 30 = Century simulation results output
	NCFT_ErosionOutput,	// 31 = Century erosion event output
	NCFT_EcosystemSummary,	// 32 = Ecosystem simulation summary results
	// 33-39 = Reserved for future Century output files
	NCFT_RestartFile = 40,	// 40 = Century restart file
	// 41-49 = Reserved for future use for restart files.
	// 50-89 = Reserved for future use.
	//--- 90-99 are administrative info and error messages
	NCFT_CentErrorMsg = 90,	// 90 = Century error text (currently not used)
	NCFT_CentWarnMsg,	// 91 = Century warnings text (currently not used)
	NCFT_CMIErrorMsg,	// 92 = CMI error text (currently not used)
	NCFT_CMIWarnMsg,	// 93 = CMI warnings text (currently not used)
	NCFT_Disclaimer,	// 94 = CMI/Century Dislaimer (currently not used)
	NCFT_CMIRevisions,	// 95 = CMI Version Revision History (currently not used)
	NCFT_CentRevisions,	// 96 = Century Version Revision History (currently not used)
	NCFT_FileTypeDesc,	// netCDF file type descriptions (this list)
	NCFT_EndOfList = 999	// always the last item!
};

#endif 	// INC_ncftypes_h
