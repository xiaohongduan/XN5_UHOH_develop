
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include <time.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf_ll.h"

/* Prototypes */
int cropdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
               float *opltim, float *qtime);
int h2odef_ll(int *ntimes, int *nlat, int *nlon, char *history,
              float *opltim, float *qtime);
int livcdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
               float *opltim, float *qtime);
int livndef_ll(int *ntimes, int *nlat, int *nlon, char *history,
               float *opltim, float *qtime);
int nfluxdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
                float *opltim, float *qtime);
int nmnrdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
               float *opltim, float *qtime);
int nuptdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
               float *opltim, float *qtime);
int proddef_ll(int *ntimes, int *nlat, int *nlon, char *history,
               float *opltim, float *qtime);
int respdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
               float *opltim, float *qtime);
int soilcdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
                float *opltim, float *qtime);
int soilndef_ll(int *ntimes, int *nlat, int *nlon, char *history,
                float *opltim, float *qtime);
int cremvdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
                float *opltim, float *qtime);
int nremvdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
                float *opltim, float *qtime);
/*int sitedef(int*, char*, int*, int*, int row[], int col[],
            int calendar_year[]); */

/* External variables */
extern char history[HISTL+1];

int
deffil_ll_(int *ntimes, int *nrow, int *ncol, int *spinup, int *savall, int row[], int col[],
   int calendar_year[], int *nlat, int *nlon, float *opltim, float *qtime)
{
	/* Define NetCDF OUTPUT files */

	/* ARGUMENTS:
         *      ntimes  Number of output time steps
	 *	nrow	Number of rows
	 *	ncol	Number of columns
         *      spinup  Flag, indicates spinup run
         *      saveall Flag, indicates number of output files to be created
	 */

	 /* Added row[], col[] to be passed to sitedef.  -mdh 8/18/98 */
	 /* row[0], row[1] - starting and ending rows */
	 /* col[0], col[1] - starting and ending columns */

	 /* Added calendar_year[] to be passed to sitedef. -mdh 10/6/98 */
         /* calendar_year[] is written to site file for post processing purposes only */
         /* calendar_year[0] - calendar year corresponding to initial simulation year */
         /* calendar_year[1] - calendar year corresponding to final simulation year */

	 /* Added nlat, nlon, pltime, qtime, cak 03/07/03 */
	 /* nlat    Number of latitude points */
	 /* nlon    Number of longitude points */
         /* opltim  Calendar year to start output */
         /* qtime   Calendar year to end output/simulation */

	/* Local variables */
	int	defok;	/* Error flag for file definition functions	*/
	int	ferr_msg;	/* Error message from file definitions	*/
	int     status;

	/* Define output files */

        if (*savall == 1)
	{
		defok = cropdef_ll(ntimes, nlat, nlon, history, opltim, qtime);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = h2odef_ll(ntimes, nlat, nlon, history, opltim, qtime);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = livcdef_ll(ntimes, nlat, nlon, history, opltim, qtime);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = livndef_ll(ntimes, nlat, nlon, history, opltim, qtime);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = nfluxdef_ll(ntimes, nlat, nlon, history, opltim, qtime);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = nmnrdef_ll(ntimes, nlat, nlon, history, opltim, qtime);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = nuptdef_ll(ntimes, nlat, nlon, history, opltim, qtime);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = proddef_ll(ntimes, nlat, nlon, history, opltim, qtime);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = respdef_ll(ntimes, nlat, nlon, history, opltim, qtime);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = soilcdef_ll(ntimes, nlat, nlon, history, opltim, qtime);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = soilndef_ll(ntimes, nlat, nlon, history, opltim, qtime);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = cremvdef_ll(ntimes, nlat, nlon, history, opltim, qtime);
		if (defok >= 1) 
			ferr_msg = ncerr;


		defok = nremvdef_ll(ntimes, nlat, nlon, history, opltim, qtime);
		if (defok >= 1) 
			ferr_msg = ncerr;
	}

	return 0;
}
