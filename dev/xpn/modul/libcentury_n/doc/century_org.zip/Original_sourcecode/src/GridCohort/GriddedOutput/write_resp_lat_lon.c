
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Rewrite the resp.nc netCDF file using COARDS standards */
/* The original file was organized variable(cell, time) */
/* The new file is organized variable(time, lat, lon) */

#include <stdio.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf_ll.h"

    int write_resp_ll_(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  s11c2_vals[MAXCELLS], s21c2_vals[MAXCELLS], s2c2_vals[MAXCELLS],
             s3c2_vals[MAXCELLS], st1c2_vals[MAXCELLS], st2c2_vals[MAXCELLS],
             mt1c2_vals[MAXCELLS], mt2c2_vals[MAXCELLS], wd1c2_vals[MAXCELLS],
             wd2c2_vals[MAXCELLS], wd3c2_vals[MAXCELLS];
      int status;
      int oldrespid;
      int olds11c2id, olds21c2id, olds2c2id, olds3c2id, oldst1c2id,
          oldst2c2id, oldmt1c2id, oldmt2c2id, oldwd1c2id, oldwd2c2id,
          oldwd3c2id;
      int ii, jj, ngrids;

      /* Open old version of resp.nc file */
      status = nc_open("resp.nc", NC_NOWRITE, &oldrespid);
      if (status != NC_NOERR) handle_error("nc_open(resp.nc)", status);

      /* Get the indices for the resp output variables */
      status = nc_inq_varid(oldrespid, "s11c2", &olds11c2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for s11c2",status);
      status = nc_inq_varid(oldrespid, "s21c2", &olds21c2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for s21c2",status);
      status = nc_inq_varid(oldrespid, "s2c2", &olds2c2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for s2c2",status);
      status = nc_inq_varid(oldrespid, "s3c2", &olds3c2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for s3c2",status);
      status = nc_inq_varid(oldrespid, "st1c2", &oldst1c2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for st1c2",status);
      status = nc_inq_varid(oldrespid, "st2c2", &oldst2c2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for st2c2",status);
      status = nc_inq_varid(oldrespid, "mt1c2", &oldmt1c2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for mt1c2",status);
      status = nc_inq_varid(oldrespid, "mt2c2", &oldmt2c2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for mt2c2",status);
      status = nc_inq_varid(oldrespid, "wd1c2", &oldwd1c2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wd1c2",status);
      status = nc_inq_varid(oldrespid, "wd2c2", &oldwd2c2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wd2c2",status);
      status = nc_inq_varid(oldrespid, "wd3c2", &oldwd3c2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wd3c2",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        s11c2_vals[ii] = fill;
        s21c2_vals[ii] = fill;
        s2c2_vals[ii] = fill;
        s3c2_vals[ii] = fill;
        st1c2_vals[ii] = fill;
        st2c2_vals[ii] = fill;
        mt1c2_vals[ii] = fill;
        mt2c2_vals[ii] = fill;
        wd1c2_vals[ii] = fill;
        wd2c2_vals[ii] = fill;
        wd3c2_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the resp output file */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldrespid, olds11c2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for s11c2",status);
            }
            s11c2_vals[jj] = val;
            status = nc_get_var1_float(oldrespid, olds21c2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for s21c2",status);
            }
            s21c2_vals[jj] = val;
            status = nc_get_var1_float(oldrespid, olds2c2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for s2c2",status);
            }
            s2c2_vals[jj] = val;
            status = nc_get_var1_float(oldrespid, olds3c2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for s3c2",status);
            }
            s3c2_vals[jj] = val;
            status = nc_get_var1_float(oldrespid, oldst1c2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for st1c2",status);
            }
            st1c2_vals[jj] = val;
            status = nc_get_var1_float(oldrespid, oldst2c2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for st2c2",status);
            }
            st2c2_vals[jj] = val;
            status = nc_get_var1_float(oldrespid, oldmt1c2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for mt1c2",status);
            }
            mt1c2_vals[jj] = val;
            status = nc_get_var1_float(oldrespid, oldmt2c2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for mt2c2",status);
            }
            mt2c2_vals[jj] = val;
            status = nc_get_var1_float(oldrespid, oldwd1c2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wd1c2",status);
            }
            wd1c2_vals[jj] = val;
            status = nc_get_var1_float(oldrespid, oldwd2c2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wd2c2",status);
            }
            wd2c2_vals[jj] = val;
            status = nc_get_var1_float(oldrespid, oldwd3c2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wd3c2",status);
            }
            wd3c2_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(respll_ncid, s11c2ll_id, start, count, s11c2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for s11c2",status);
        status = nc_put_vara_float(respll_ncid, s21c2ll_id, start, count, s21c2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for s21c2",status);
        status = nc_put_vara_float(respll_ncid, s2c2ll_id, start, count, s2c2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for s2c2",status);
        status = nc_put_vara_float(respll_ncid, s3c2ll_id, start, count, s3c2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for s3c2",status);
        status = nc_put_vara_float(respll_ncid, st1c2ll_id, start, count, st1c2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for st1c2",status);
        status = nc_put_vara_float(respll_ncid, st2c2ll_id, start, count, st2c2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for st2c2",status);
        status = nc_put_vara_float(respll_ncid, mt1c2ll_id, start, count, mt1c2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for mt1c2",status);
        status = nc_put_vara_float(respll_ncid, mt2c2ll_id, start, count, mt2c2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for mt2c2",status);
        status = nc_put_vara_float(respll_ncid, wd1c2ll_id, start, count, wd1c2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wd1c2",status);
        status = nc_put_vara_float(respll_ncid, wd2c2ll_id, start, count, wd2c2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wd2c2",status);
        status = nc_put_vara_float(respll_ncid, wd3c2ll_id, start, count, wd3c2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wd3c2",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldrespid);

      return 0;
    }
