#ifndef INC_TCentNcFile_h
#define INC_TCentNcFile_h
// ----------------------------------------------------------------------------
//	Copyright 1999-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCentNcFile.h
//	Class:	  TCentNcFile
//
//	Description:
//	Century output file class which builds a netCDF file containing
//	Century output variables.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Jan99
//	History:
//	May99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Version = 2
//	* Added mgmt. file name, site file name, site description.
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added copy constructor, operator=
//	* Added Clone member function.
//	Aug01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Virtual-ized several member functions so this could be used as
//	  a base class.
//	Sep01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified Open/Close to work with new output engine base class.
//	* Added operator==
//	Oct01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Changes for the modified base classes TCentOutFileBase, TOutputBase.
//	Jun02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved static local var list[] into the class definition.
//	Sep03	Tom Hilinski
//	* Implemented new pure virtual base class member DoReset.
// ----------------------------------------------------------------------------

#include "TMCOutputFileBase.h"
#include "TNcFile.h"
#include <string>

class TCentNcFile : public TMCOutputFileBase
{
  public:
	//--- constructors and destructor
	TCentNcFile (
	  std::string const & useFileName, 	// file name instance
	  TOutputBase::TAccessMode const useAccess, // file access mode
	  TManagementScheme & useMgmt,	// simulation mgmt. scheme
	  TMCSiteParameters & useSite,	// site parameter set
	  std::string const & useUserName,	// user name for output file
	  TEH::TFileName const & useOVDefPath);// path to the netCDF file with
						//   the names and definitions
						//   of the output variables.
	virtual ~TCentNcFile ()
	  {
	    Close ();
	  }
	TCentNcFile (				// copy constructor
	  TCentNcFile const & object)
	  : TMCOutputFileBase (object)
	  {
	    Copy (object);
	  }

	//---- operator overloads
	TCentNcFile & operator= (
	  TCentNcFile const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	TMCOutputFileBase::operator= (object);
	    }
	    return *this;
	  }
	bool operator== (
	  TCentOutFileBase const & object) const
	  {
	    if (outputType == object.GetOutputType())
	    {
	    	return fileName == object.GetFileName();
	    }
	    else
		return false;
	  }

	//--- functions
	bool WriteRecord (			// Write 1 record
	  float const simTime);			//   simulation time
	char const* LastErrorMsg () const	// Get the last error message.
	  { return ncErrStr; }
	TCentNcFile* const Clone () const	// Clone this
	  { return new TCentNcFile (*this); }

  protected:
	//--- data
	NcFile* fp;				// pointer to netCDF file
	short numNcVars;			// number of netCDF variables
	NcVar** ncVars;				// netCDF output variables
	char const * ncErrStr;			// netCDF error message
	float list[255];	// output values array: size = largest of lists
	std::string msg;	// user message

  private:
	//--- functions
	void Initialize ();			// Initialize members.
	void Copy (				// Copy to this
	  TCentNcFile const & object);
	virtual bool CreateNCOutputStructure ();// Create output file

	//---- functions: Virtual
	virtual TState DoOpen ();		// Open the output engine
	virtual TState DoClose ();		// Close the output engine
	virtual TState DoReset ();		// Reset the output engine
};

#endif // INC_TCentNcFile_h
