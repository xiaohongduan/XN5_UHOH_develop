#ifndef INC_TSoilCDis_h
#define INC_TSoilCDis_h

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TSoilCDis.h
//	Class:	  TSoilCDistribution
//
//	Description:
//	Models the depth distribution of soil C as an exponential function.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Dec00
// ----------------------------------------------------------------------------
//	History:
//	Nov01	Tom Hilinski, tom.hilinski@colostate.edu
//	* K calc had error in calc of the amount of C at the half-profile depth.
//	  where C at half depth = 0.1 * C0
//	  When C half < Cb, log function failed.
// 	  This was changed to:
//	  C at half depth = Cb + (0.1 * (C0 - Cb))
//	Jul02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added copy constructor.
// ----------------------------------------------------------------------------

#include "TSoilVDCompBase.h"
#include "AssertEx.h"
#include <cmath>

class TSoilCDistribution
{
  public:
	//--- types
	typedef TSoilVDCompBase::TFloatArray		TFloatArray;
	enum TSCDErrors		// error flags
	{
		NoError = 0, 	// no error - FIRST ENUM ITEM ALWAYS
		MemoryAlloc,	// memory allocation error
		NoSolution,	// no solution found
		UnknownError	// unknown error - LAST ENUM ITEM ALWAYS
	};

	//---- constructors and destructor
	// Use this version to access the distribution function
	// without finding the roots
	TSoilCDistribution (			// Default constructor
	  float const useMaxDepth)		//   maximum soil depth (cm)
	  : maxDepth (useMaxDepth),
	    cProfileTotal (0.0f),
	    cSimLayerDensity (0.0f),
	    cLowerLayerDensity (0.0f)
	  {
	    lastError = NoSolution;
	  }
	TSoilCDistribution (			// Construct using Century's
						// simulation and lower layer
						// C densities.
	  float const useMaxDepth,		//   maximum soil depth (cm)
	  float const useCProfileTotal,		// profile C total (g cm-2)
	  float const useSimLayerDensity,	// sim. layer density (g cm-3)
	  float const useLowerLayerDensity);	// lower layer density (g cm-3)
	~TSoilCDistribution () {}
	TSoilCDistribution (			  // copy constructor
	  TSoilCDistribution const & object)
	  : maxDepth (object.maxDepth),
	    cProfileTotal (object.cProfileTotal),
	    cSimLayerDensity (object.cSimLayerDensity),
	    cLowerLayerDensity (object.cLowerLayerDensity)
	  {
	    Copy (object);
	  }

	//---- operator overloads

	//---- functions
	bool GetDistribution (		// Returns the parameters.
	  float& theK,			//   K (cm-1)
	  float& theCTopDen,		//   C at surface (g cm-3)
	  float& theCBottomDen);	//   C at bottom (g cm-3)
	float CDensity (		// C density at the depth (g cm-3)
	  float const z,		//   depth (cm)
	  float const K,		//   expon. scaling constant (cm-1)
	  float const cTop,		//   C density at surface (g cm-3)
	  float const cBottom		//   C density at bottom (g cm-3)
	  ) const
	  {
	    Assert (z >= 0.0f);
	    return cBottom + (cTop - cBottom) * std::exp (-K * z);
	  }
	float LayerAmt (		// C amount in a depth range (g cm-2)
	  float const zTop,		//   depth at top (cm)
	  float const zBottom		//   depth at bottom (cm)
	  ) const;
	float LayerAmt (		// C amount in a depth range (g cm-2)
	  float const zTop,		//   depth at top (cm, >= 0)
	  float const zBottom,		//   depth at bottom (cm, > 0))
	  float const aK,		//   scaling constant (cm-1)
	  float const aTopDensity,	//   C density at surface (g cm-3)
	  float const aBottomDensity	//   C density at profile bottom
	  ) const;
	float CProfileSum () const;	// C amount in the entire profile
	float CProfileSum (		// C amount in the entire profile
	  float const aK,		//   scaling constant (cm-1)
	  float const aTopDensity,	//   C density at surface (g cm-3)
	  float const aBottomDensity	//   C density at profile bottom
	  ) const;
	bool HaveSolution () const	// True if have a solution
	  { return (lastError == NoError); }
 	TSCDErrors LastError () const		// Get last error code
	  { return lastError; }

  private:
	//---- constants
	// Multiplier for C density at 1/2 profile depth
	static float const halfDepthDensityFactor;
	// Factor to multiply lower layer C density by to get the minimum den.
	static float const minDenLLDenFactor;
	// Factor to multiply simulation layer density by to get max. density
	static float const maxDenSLDenFactor;
	// Depth at which to calc the max. depth in the root finder
	static float const maxDenDepthRoot;

	//---- data
	float const maxDepth;		// maximum depth (for speed of access)
	float const cProfileTotal;	// total profile C (g cm-2) from data
	float const cSimLayerDensity;	// C density in the simulation layer
	float const cLowerLayerDensity;	// C density in the lower sim. layer
	float cTopDensity;		// C density at surface (g cm-3)
	float cBottomDensity;		// C density at profile bottom (g cm-3)
	float kSC;			// K, the scaling constant
	TSCDErrors lastError;		// Last error code

	//---- functions
	float K (			// K - calculate the scaling constant
	  float const topDensity,	//   C density at surface (g cm-3)
	  float const bottomDensity	//   C density at profile bottom
	  ) const;
	void FindTheRoots ();		// Find the roots
	void Copy (TSoilCDistribution const & object)	// Copy to this
	  {
	    if ( &object )
	    {
	    	cTopDensity = object.cTopDensity;
	    	cBottomDensity = object.cBottomDensity;
	    	kSC = object.kSC;
	    	lastError = object.lastError;
	    }
	  }
};

#endif // INC_TSoilCDis_h
