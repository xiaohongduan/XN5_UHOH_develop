
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include "netcdf.h"
#include "wrtcdf.h"

int
write_livn(float livn[][12])
{
        int status;
        float *p = (float *) livn;

	/* Write output to NetCDF file */
	status = nc_put_vara_float(livn_ncid, aglivn_id, start, count, p);
	status = nc_put_vara_float(livn_ncid, bglivn_id, start, count, p + 12);
	status = nc_put_vara_float(livn_ncid, stdedn_id, start, count, p + 24);
	status = nc_put_vara_float(livn_ncid, rleavn_id, start, count, p + 36);
	status = nc_put_vara_float(livn_ncid, frootn_id, start, count, p + 48);
	status = nc_put_vara_float(livn_ncid, fbrchn_id, start, count, p + 60);
	status = nc_put_vara_float(livn_ncid, rlwodn_id, start, count, p + 72);
	status = nc_put_vara_float(livn_ncid, crootn_id, start, count, p + 84);
	status = nc_put_vara_float(livn_ncid, wood1n_id, start, count, p + 96);
	status = nc_put_vara_float(livn_ncid, wood2n_id, start, count, p + 108);
	status = nc_put_vara_float(livn_ncid, wood3n_id, start, count, p + 120);
	status = nc_put_vara_float(livn_ncid, crpstgn_id, start, count, p + 132);
	status = nc_put_vara_float(livn_ncid, forstgn_id, start, count, p + 144);

	/* Reset memory for variable livn */
	 memset(p, '\0', (sizeof(float) * 13 * 12));

	return 0;
}
