// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TMgtFromLibDlg.cpp
//	Class:	  TMgtFromLibDlg
//
//	Description:
//	Class for copying a management scheme from the library.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Apr98
//	History: See header file.
// ----------------------------------------------------------------------------

#define _TMgtFromLibDlg_ClassDefined_
#include "TMgtFromLibDlg.h"
#include "TFileList.h"
#include "util.h"
#include "AssertEx.h"
#include "HelpDisplay.h"
#include "netcdf.hh"	// netCDF C++ interface
//#include "externals.h"
using namespace TEH;
#include <v/vnotice.h>
#include <stdio.h>

// ----------------------------------------------------------------------------
//	local variables
// ----------------------------------------------------------------------------

// static char displayStr[21];	// for converting between values and text
static char *NULLStr = "";	// global NULL string
// static char *canceledStr = "Request canceled.\n";

static char *toolTips[] =		// tool tips text
{
	// 0 = app default library folder
	"Select from sites in the default management library.",
	// 1 = user's personal library folder
	"Select from sites in the your personal management library.",
	// 2 = list: descriptions
	"Select a management scheme from these descriptions.",
	// 3 = Accept
	"Use the selected management scheme for the simulation.",
	// 4 = Cancel
	"Cancel this operation.",
	// 5 = Help
	"View Help on selecting a management scheme.",
	// last item always
	NULL
};

// ----------------------------------------------------------------------------
//	static member variables
// ----------------------------------------------------------------------------

CommandObject TMgtFromLibDlg::cmdList[] =
{
	//--- Master Frame provides a border for data
	{C_Frame, 101, 0, NULLStr, NoList, CA_NoBorder, isSens, NoFrame, 0, 0},

	//--- management scheme library
	{C_Label, 201, 0, "1. Select Library",
		NoList, CA_None, isSens, 101, 0, 0},
	{C_Frame, 105, 0, NULLStr, NoList, CA_None, isSens, 101, 0, 201},
	{C_RadioButton, D_DefaultLib, 1, "Default",
		NoList, CA_None, isSens, 105, 0, 201, 0, toolTips[0]},
	{C_RadioButton, D_PersonalLib, 0, "Personal",
		NoList, CA_None, isSens, 105, 0, D_DefaultLib, 0, toolTips[1]},

	//--- management scheme list
	{C_Label, 220, 0, "2. Select Management Scheme",
		NoList, CA_None, isSens, 101, 201, 0},
	{C_List, D_DescripList, 200, NULLStr, (void*)NULL,
		CA_ListWidth, isSens, 101, 201, 220, 0, toolTips[2]},

	//--- site summary
	{C_Label, 260, 0, "Management Scheme File Name Base:",
		NoList, CA_None, isSens, 101, 0, D_DescripList,},
	{C_Label, D_MgmtFile, 0, "",
		NoList, CA_None, isSens, 101, 260, D_DescripList, 100},

	//--- Common Buttons
	{C_Button, M_OK, M_OK,		"  &Open",
		NoList,	CA_DefaultButton, isSens, NoFrame, 0, 101,
		0, toolTips[3]},
	{C_Button, M_Cancel, M_Cancel,	" &Cancel",
		NoList,	CA_None, isSens, NoFrame, M_OK, 101, 0, toolTips[4]},
	{C_Button, M_Help, M_Help, 	"  &Help ",
		NoList,	CA_None, isSens, NoFrame, M_Cancel, 101,
		0, toolTips[5]},

	{C_EndOfList, 0, 0, 0, 0, CA_None, 0, 0}
};

// ----------------------------------------------------------------------------
//	methods
// ----------------------------------------------------------------------------

//--- constructors and destructor

//	newDefPath = default path to search for library subdirectories,
//			which are "crop", "grass", "tree", "savanna".
//	newUserPath = user's library path (no subdirectories).
TMgtFromLibDlg::TMgtFromLibDlg (
	vApp * const useParent,			// pointer to application
	std::string const & newDefPath,		// default path for libraries
	std::string const & newUserPath,	// user's library path
	char*& mgmtFileBase,			// returned value = file name
	std::string const & useHelpPath,	// path to help file
	char const * const title)		// dialog title
	: TModalDlg (useParent, title),
	  parent (useParent),
	  helpFilePath (useHelpPath)
{
	//--- initialize variables
	Initialize ();
	libPath[0] = newDefPath;
	Assert ( !libPath[0].empty() );		// always have a default lib
	libPath[1] = newUserPath;
	ReadDescriptions ();

	// Get the indicies to cmdList items for lists.
	// Done only once for speed.
	idxParamList = GetItemIndexInCmdObj (cmdList, D_DescripList);

	//--- display dialog
	AddDialogCmds ((CommandObject*)cmdList);	// add dialog controls
	ItemVal retVal;
	ShowModalDialog ((char*)title, retVal);		// display it now

	// return data
	if ( !libPath[usingPath].empty() &&
	     fnameList[usingPath] &&
	     usingMgmt >= 0 )
	{
		char *path = new char [libPath[usingPath].size() +
				strlen(fnameList[usingPath][usingMgmt]) + 1];
		Assert (path != NULL);
		strcpy ( path, libPath[usingPath].c_str() );
		strcat ( path, fnameList[usingPath][usingMgmt] );
		mgmtFileBase = path;
	}
}

TMgtFromLibDlg::~TMgtFromLibDlg ()
{
	ClearDlgMgmtList ();
	for (short i = 0; i < 2; i++)
	{
		// delete string lists
		::DeleteNTCStringList (descList[i]);
		::DeleteNTCStringList (fnameList[i]);
	}
}


//--- functions overridden

void TMgtFromLibDlg::DialogDisplayed ()
{
	TModalDlg::DialogDisplayed ();
	if ( !libPath[1].empty() )		// personal lib available?
		SetValue (D_PersonalLib, notSens, Sensitive);	// de-activate
	LoadDlg ();				// load data into dialog
}

void TMgtFromLibDlg::DialogCommand (ItemVal id, ItemVal val, CmdType type)
{
	switch (id)
	{
						// which library path?
	  case D_DefaultLib:
		if ( usingPath != 0 )
		{
			usingPath = 0;
			UpdateDlg_DescList ();
		}
		break;
	  case D_PersonalLib:
		if ( usingPath != 1 )
		{
			usingPath = 1;
			UpdateDlg_DescList ();
		}
		break;
						// list selection
	  case D_DescripList:
	  	UpdateDlg_MgmtData ();
	  	break;
						// buttons
	  case M_OK:
		break;
	  case M_Cancel:
		usingMgmt = -1;
		break;
	  case M_Help:			// "help" button
#ifdef MSWindowsHelp
		::HelpDisplay (parent->winHwnd(), helpFilePath,
			   HELP_CONTEXT, IDH_MGMT_FROMLIB_DLG);
#elif defined(X11Help)
		::HelpDisplay (winHwnd(), helpFilePath,
			   HELP_CONTEXT, IDH_MGMT_FROMLIB_DLG);
#endif
		break;
	  default:
		break;
	};
	// Default event processing
	TModalDlg::DialogCommand (id, val, type);
}


//--- private functions

//	Initialize
// 	initialize members
void TMgtFromLibDlg::Initialize ()
{
	for (short i = 0; i < 2; i++)
	{
		descList[i] = fnameList[i] = NULL;
		libPath[i].clear();
	}
	usingPath = 0;				// default library
	usingMgmt = -1;				// selected mgmt.
}

//	ReadDescriptions
// 	get mgmt. descriptions from files
void TMgtFromLibDlg::ReadDescriptions ()
{
	char mask[257];				// file list mask
	char ncName[257];			// current file to read
	NcVar *descVar;				// pointers to netCDF vars
	char tmpStr[257];			// temporary string
	short count;				// size of list

	for ( short i = 0; i < 2; i++ )		// for each library
	{
		if ( libPath[i].empty() )		// path to folder?
			continue;			// ...no

		// get a list of files
		Assert (libPath[i].size() < 250);
		strcpy ( mask, libPath[i].c_str() );
		strcat ( mask, "*-S.nc" );
		Assert (strlen(mask) < 257);
		TFileNameList fileList (mask, TFileNameList::FLT_Normal);
		if ( fileList.IsError() ||
		     fileList.GetCount() == 0 )			// list ok?
			continue;				// ...no
		const char * const * fileNames =		// get the list
			fileList.GetList ();
		const char * const * p = fileNames;		// pointer

		// alloc memory for lists
		descList[i] = new char* [fileList.GetCount() + 1];
		Assert (descList[i] != NULL);
		descList[i][fileList.GetCount()] = NULL;
		fnameList[i] = new char* [fileList.GetCount() + 1];
		Assert (fnameList[i] != NULL);
		fnameList[i][fileList.GetCount()] = NULL;

		// read the files in the current library path
		count = 0;
		while ( p && *p )			// for each file...
		{
			// create a full path name
			Assert (libPath[i].size() + strlen(*p) < 257);
			strcpy ( ncName, libPath[i].c_str() );
			strcat (ncName, *p);

			// open the file
			NcFile ncFile (ncName, NcFile::ReadOnly);
			if ( !ncFile.is_valid() )
				continue;	// error accessing the file

			// get pointers to netCDF variables (by position)
			descVar = ncFile.get_var ("description");
			Assert (descVar != NULL);

			// read the description
			descVar->get (tmpStr, 1, 80);		// read desc
			tmpStr[80] = '\0';
			::strtrim (tmpStr);

			// save description in the list
			descList[i][count] = new char [strlen(tmpStr) + 1];
			Assert (descList[i][count] != NULL);
			strcpy (descList[i][count], tmpStr);

			// save the file name base in the list
			strcpy (tmpStr, *p);
			*(tmpStr + strlen(tmpStr) - 5) = '\0';
			fnameList[i][count] = new char [strlen(tmpStr) + 1];
			Assert (fnameList[i][count] != NULL);
			strcpy (fnameList[i][count], tmpStr);

			ncFile.close ();		// close the file
			++count;
			++p;				// next file name
		}
	}
}


// Load data into dialogs:

//	LoadDlg
// 	load the dialog
void TMgtFromLibDlg::LoadDlg ()
{
	usingPath = 0;			// default library folder
	UpdateDlg_DescList ();
}

//	UpdateDlg_DescList
// 	site list
void TMgtFromLibDlg::UpdateDlg_DescList ()
{
	// usingPath and usingCat are set in DialogCommand()
 	// set ptr to list and display the list
	cmdList[idxParamList].itemList = (void *)descList[usingPath];
	SetValue (cmdList[idxParamList].cmdId, 0, ChangeListPtr); // display

	// update the parameter data
	UpdateDlg_MgmtData ();
}

//	UpdateDlg_MgmtData
// 	site data
void TMgtFromLibDlg::UpdateDlg_MgmtData ()
{
	// get index to the currently selected item in the event list
	usingMgmt = (short)GetValue (D_DescripList); // get index to item
	// display the file name
	if ( fnameList[usingPath] && fnameList[usingPath][usingMgmt] )
		SetString ( D_MgmtFile, fnameList[usingPath][usingMgmt] );
}

// Clear dialog controls:

//	ClearDlgMgmtList
// 	Clear site list display
void TMgtFromLibDlg::ClearDlgMgmtList ()
{
	cmdList[idxParamList].itemList = (void *)NULL; 	// set ptr to list
	SetValue (cmdList[idxParamList].cmdId, 0, ChangeListPtr); // display
}

//--- end of file ---


