// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  h2olos.cpp
//	Class:	  TCentury
//	Function: SoilWaterModel
//
//	Description:
// 	Water Submodel for monthly Century.
// ----------------------------------------------------------------------------
//	Author: Bill Parton
//	History:
// 	Updated from Fortran 4 - rm 2/92
// 	Rewritten by Bill Pulliam - 9/94
//	Sep98	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to correctly account for runoff,
//	* and use understandable variable names.
//	Jan00	Tom Hilinski
//	* Moved bucket cascade loop into the new class, TCenturySoil.
//	  Now it is done with:  soil->ApplyWaterToSurface (add);
//	* Much more cleanup of the code w/more comments on algorithms.
//	* Added function UpdateWaterVariables.
//	Dec00	Tom Hilinski
//	* Updated to use new soil class member functions.
//	Nov01	Tom Hilinski
//	* Moved calc of co2 effect upon transpiration from cycle.cpp to here.
//	Nov02	Tom Hilinski
//	* Moved UpdateWaterVariables() to class TCenturyBase
//	Sep03	Tom Hilinski
//	* Moved snow evaporation calcs into function TCentury::SnowWaterModel.
//	Nov04	Tom Hilinski
//	* Fixed imbalance in the calc of wt.pttr (potential transpiration)
//	  vs. the actual potential trans. used (remainingPT).
//	Apr05	Tom Hilinski
//	* Changed args to total applied water is passed in,
//	  and wt.* values are passed in and modified.
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include <cmath>
using std::vector;

void TCentury::SoilWaterModel (
	short const month,		  // month (1-12)
	float const agLiveBiomass,	  // aboveground live biomass (g/m2)
	float const surfaceLitterBiomass, // litter biomass (g/m2)
	float const standingDeadBiomass,  // standing dead biomass (g/m2)
	float const totalH2OInput,	  // total water applied to surface
	float const availPET,		// PET
	float & evaporation,		// evaporation
	float & transpiration,		// transpiration
	float & pttr,			// potential transpiration water loss
	float & snow,			// water in snowpack
	float & runoff)			// runoff
{
    float const minPotTrans = 0.01f;	// minimum potential transpiration
    float bareSoilEvapFrac = 0.0f;	// bare soil evaporation
    float netH2OInput = 0.0f;		// total H2O input - runoff
    float remainingPT = minPotTrans;	// potential transpiration water loss
    float evapLoss = 0.0f;		// monthly evaporation loss

#ifdef DO_WATER_BALANCE
    // initial total water in the profile (cm)
    float const initTotalSoilWater =
	soil->WaterContent().Quantity( 0, soil->BottomLayer() ) +
	evaporation + transpiration + snow + runoff +
	soil->GetStormFlow() + soil->GetBaseFlow() + soil->GetDeepSoilStorage();
#endif // DO_WATER_BALANCE

    //--- Determine the snow pack
    // When mean monthly air temperature is below freezing,
    // precipitation is in the form of snow; otherwise water.
    if (wt.tave <= 0.0f)	// if freezing...
    {
	snow += totalH2OInput;			// all water input to snowpack
						// ...so no runoff
    }
    if (snow == 0.0f)				// no snow?
    {
	//--- Compute runoff -rm 12/96
	// Reference:
	// Probert, M.E., B.A. Keating, J.P. Thompson, and W.J. Parton. 1995.
	// Modelling water, nitrogen, and crop yield for a long-term
	// fallow management experiment. Australian Journal of Experimental
	// Agriculture 35:941-950.
	// Using their equation for plots with surface residue.
	// 1. Century 4 version:
	// runoff = std::max (0.0f, (totalH2OInput - 5.0f) * 0.55f);
	// 2. VEMAP version
	// runoff = std::max (0.0f, (totalH2OInput - 8.0f) * 0.15f);
	// Now, have the general quadratic version:
	//    runoff = A*w^2 + B*w + C
	// ...For speed, check for the linear case
	if ( water.runoff[0] == 0.0f )				// linear
		runoff += std::max ( 0.0f,
			water.runoff[1] * totalH2OInput - water.runoff[2] );
	else							// quadratic
		runoff += std::max ( 0.0f,
			water.runoff[0] * totalH2OInput * totalH2OInput +
			water.runoff[1] * totalH2OInput - water.runoff[2] );

	//--- net water input
	netH2OInput = totalH2OInput - runoff;
	//--- Calculate bare soil water loss and interception
	// Allow interception when t < 0 but no snow cover.
	// Calculate total canopy cover and litter, put cap on effects:
	// Equation source ???
	float const canopyCover =
			std::min (agLiveBiomass + standingDeadBiomass, 800.0f);
	float const litter = std::min ( surfaceLitterBiomass, 400.0f );
	// surface ltter and canopy cover interception = fraction of precip.
	// Equation source ???
	float const slccInterceptFrac =
	    fixed.fwloss[0] * (litter * 0.0003f + canopyCover * 0.0006f);
	// Bare soil evaporation =  fraction of precip (abs):
	// Equation source ???
	bareSoilEvapFrac = 0.5f * fixed.fwloss[1] *
			std::exp (-0.002f * litter - 0.004f * canopyCover);
	// Calculate total bare-soil surface evaporation losses;
	// maximum allowable is 0.4 * PET. -rm 6/94
	evapLoss = std::min (
			availPET * 0.4f,
			(bareSoilEvapFrac + slccInterceptFrac) * netH2OInput );
	evaporation += evapLoss;		// accumulate evaporation
	netH2OInput -= evapLoss;		// remove from available water
	remainingPT = availPET - evapLoss;	// pot. trans. as remaining PET
    }
    else
    {
    	netH2OInput = SnowWaterModel (availPET, remainingPT);
    }

    //--- Potential transpiration water loss (cm/month) = f(live biomass)
    // (1) co2 effect on transpiration
    float co2Effect;
    if ( sysType.IsSavanna() )
    {
	if (cropC.aglivc + forestC.rleavc == 0.0f)
	    co2Effect = 1.0f;
	else
	    co2Effect = ( co2.co2ctr[CRPSYS] * cropC.aglivc +
			co2.co2ctr[FORSYS] * forestC.rleavc ) /
			(cropC.aglivc + forestC.rleavc);
    }
    else
	co2Effect = co2.co2ctr[sysType.TypeAsIndex()];
    // (2) Potential transpiration from aboveground biomass
    // Equation source ???
    float pttrNew = 0.0f;
    if (wt.tave >= 2.0f)    // If temp < 2C, no transpiration. -rm 6/94
    {
	pttrNew = availPET * 0.65f * co2Effect *
		(1.0f - std::exp (-0.02f * agLiveBiomass));
    }
    remainingPT = std::min ( remainingPT, pttrNew );		// upper bound
    remainingPT = std::max ( remainingPT, minPotTrans );	// lower bound
//    pttrNew = std::max ( pttrNew, remainingPT );		// must balance
//    pttr += pttrNew;
    pttr += remainingPT;

    //--- Potential evaporation from the top soil layer (cm/month)
    //    after potential transpiration is removed.
    //    This is not actually taken out until after transpiration losses
    //    Saved for use in root-uptake transpiration calc below.
    float const potEvap = std::max (availPET - remainingPT - evapLoss, 0.0f);

    //--- Transpire water from added water before passing water to soil->
    //    This is necessary for a monthly time step to give plants
    //    in wet climates adequate access to water for transpiration.
    //    -rm 6/94, Pulliam 9/94
    transpiration += 					// trans. water
    	std::min (remainingPT - minPotTrans, netH2OInput);
    remainingPT -= transpiration;		// remove from potential trans.
    netH2OInput -= transpiration;		// remove from new soil water
    netH2OInput = std::max (netH2OInput, 0.0f);	// never negative

    //--- Add water to the soil
    if ( netH2OInput > 0.0f )
    {
	// the following is an experiment with doing weekly water applications
	// when the amount is "large enough".
	// This will affect leaching and storm/base flows also.

//	short bottomLayerIndex = soil->GetLayerCount() - 1;
//	if ( netH2OInput >
//	      soil->FieldCapacityQuantity ( (short)0, bottomLayerIndex ) -
//	      soil->WaterContent().Quantity ( (short)0, bottomLayerIndex ) )
//	{
//	    // apply water in intervals
//	    float const intervalAmt = netH2OInput / (float) fixed.ntspm;
//	    for (short kts = 0; kts < fixed.ntspm; ++kts)
//		soil->ApplyWaterToSurface ( intervalAmt );
//	}
//	else	// apply water at once
//	{
//		soil->ApplyWaterToSurface ( netH2OInput );
//	}

	// The original method - apply all at once
	soil->ApplyWaterToSurface ( netH2OInput );
    }

    //--- Calculate transpiration water loss from each layer

    TCenturySoil::size_type const rootDepthLayer =
	( GetSystemType().IsCropGrass() ?
	  GetRootDepthLayerCrop() :
	  GetRootDepthLayerTree() ) - 1;

    // (1) plant available water content by layer, and total
    T1DFloatArray waterPlant ( rootDepthLayer + 1 );
    waterPlant = 0.0f;
    for (TCenturySoil::size_type i = 0; i <= rootDepthLayer; ++i)
	waterPlant(i) = soil->PlantExtractableWater (i, i);

    // (2) transpiration based upon root density and layer water content
    // rdft = root density factor for transpiration from each layer
    // rdftTotal = soil total rdft
    T1DFloatArray rdft ( rootDepthLayer + 1 );
    rdft = 0.0f;
    for (TCenturySoil::size_type i = 0; i <= rootDepthLayer; ++i)
    {
	float const awtl =
		( i < MAXLYR ? fixed.awtl[i] : fixed.awtl[MAXLYR - 1] );
	rdft(i) = waterPlant(i) * awtl;				// for layer
    }
    float const rdftTotal = ARRAY_SUM(rdft);			// sum layers

    // (3) Actual transpiration water loss from each soil layer (cm/mo)
    // (Pulliam 9/94)
    if ( rdftTotal > 0.0f && remainingPT > 0.0f )
    {
	remainingPT = std::min (ARRAY_SUM(waterPlant), remainingPT);
	float const rdftTotalRecip = 1.0f / rdftTotal;
	for ( TCenturySoil::size_type i = 0;
	      i <= rootDepthLayer && remainingPT > 0.0f;
	      ++i )
	{
	    // Transpiration loss from weighted water availability,
	    // constrained to available water
	    float const transLoss =
		std::min ( remainingPT * rdft(i) * rdftTotalRecip,
			   waterPlant(i) );
	    soil->WaterContent(i) -= transLoss;	// remove from storage
//	    waterPlant(i) -= transLoss;		// remove from avail. water
	    transpiration += transLoss;		// accumulate transpiration
	    remainingPT -= transLoss;
	}
    }
    // delete arrays - no longer needed
    rdft.resize (0);
    waterPlant.resize (0);

    //--- Evaporate water from the top evapDepth cm
    //    (Rewritten by Pulliam, should still do the same thing 9/94)
    // assumes that there is at least 10cm of soil!
    // Evaporation amount = fraction of relative water content,
    // constrained to 0.01 min.
    // Changed 4/05 Tom H.:
    // * Evap to evapDepth cm, not just surface layer.
    // * Evap can extract to wilting point.
    float const evapDepth = wt.simDepth;  // to do: make this a site parameter
    float const swcAvailToEvap =
	soil->PlantExtractableWater (0.0f, evapDepth);
    	// soil->WaterContent().Quantity (0.0f, evapDepth);
    if ( swcAvailToEvap > 0.0f )
    {
	// Original Pulliam algorithm:
//	// Min. relative h2o for top layer to evaporate
//	float const fwlos = 0.25f;
//	// max h2o to evap = 1/(1-fwlos)
//	float const maxFwlosRecip = 1.3333333f;
//	float const evapFrac =			// fraction to evaporate
//		std::max ( 0.01f,
//			   (plantExtractableWCF - fwlos) * maxFwlosRecip );
//	// Equation source?
//	evapLoss = std::min ( potEvap * evapFrac * bareSoilEvapFrac * 0.1f,
//			      waterPlant(0) );
//	soil->WaterContent(0) -= evapLoss;	// remove from storage

	// from Shouse, et al (1982)
	// evap (cm) = 0.6 * sqrt (no. days)
	float const pt6xSqrt30Days = 3.286335f;
	float const evapFrac =
		pt6xSqrt30Days / swcAvailToEvap -
		(bareSoilEvapFrac * swcAvailToEvap);
	float const evapLoss = std::min ( potEvap * evapFrac, swcAvailToEvap );
	// following does NOT make sure that a layer is at least at the WP.
	float const removed =
		soil->WaterContent().TransferFrom (
			0.0f, evapDepth,
			soil->Depth(), soil->Thickness(),
			evapLoss );
	// Assert ( !AmountIsSignificant(removed - evapLoss, 1.0e-4f) );
	evaporation += removed;			// accumulate evaporation
    }

#ifdef DO_WATER_BALANCE
    // water balance of the soil profile (cm)
    float const finalTotalSoilWater =
	soil->WaterContent().Quantity( 0, soil->BottomLayer() ) +
	evaporation + transpiration + snow + runoff +
	soil->GetStormFlow() + soil->GetBaseFlow() +
	soil->GetDeepSoilStorage() -
	totalH2OInput;
    char const * const msgImbalance =
	(finalTotalSoilWater > initTotalSoilWater ?
	 "Total soil water: final > initial" :
	 "Total soil water: initial > final");
    BalanceCheckWithMsg (
	initTotalSoilWater, finalTotalSoilWater, 5.0E-5f, msgImbalance );
#endif // DO_WATER_BALANCE
}

//--- end of file h2olos.cpp ---
