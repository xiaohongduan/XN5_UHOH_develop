// ----------------------------------------------------------------------------
//    Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model, daily version
//	File:	  nitrify.cpp
//	Class:	  TDayCentSoil
//	Function: Nitrify
//
//	Description:
//	Calculates the amount of ammonium that is converted to nitrate
//	during the nitrification process.
// ----------------------------------------------------------------------------
//	Author: Melannie Hartman, Bill Parton
//	History:
//	??????  Melannie Hartman, melannie@NREL.colostate.edu
//	* Created original nitrify.c for FORTRAN/C version of DayCent
//	Apr2001	 MelanniHartman, melannie@NREL.colostate.edu
//	* Translated nitrify.c to nitrify.cpp
//	May03	Tom Hilinski
//	* Additional assertions and some minor cleanup.
//	* Made a function returning new NO3.
// ----------------------------------------------------------------------------
//	Notes:
//	* Eventually remove type "double" declarations in favor of
//	  casting when necessary -mdh 4/25/01
// ----------------------------------------------------------------------------

#include "TDayCentSoil.h"
#include "TDayCent.h"
#include "pi_funcs.h"
using namespace std;

double TDayCentSoil::Nitrify (
    TSoilTextureIndex textureIndex,  // soil texture index
    float const surfTempAvg,	// average soil surface temperature (deg C)
    float const maxt,		// Long term avg max monthly air temp of the
    				//   hottest month (deg C)
    float const avgWFPS,	// avg wfps in top nitrifyDepth cm of soil (0-1)
    float const nitrifyDepth,	// depth into soil over which nitrification
    				//   occurs (cm)
    double & ammonium)		// soil ammonium (gN/m^2)
{
    Assert (ammonium >= -0.05);
    Assert (avgWFPS > 0.0f);
    Assert (avgWFPS < 1.0f);

    double NH4_to_NO3 = 0.0;		// amount of NH4 converted to NO3
    					//   due to nitrification (gN/m^2)
    float const MaxNitrifRate = 0.10f;	// max fraction of ammonium that goes
					//   to NO3 during nitrification
    float const Ha_to_SqM = 0.0001f;	// factor to convert ha to sq meters
    float const min_ammonium = 0.15f;	// min. total ammonium in soil (gN/m^2)
#ifndef NDEBUG
    double const initialTotalN = ammonium;
#endif

    if (ammonium >= min_ammonium)
    {
	//  Convert ammonium (gN/m^2) to nh4PPM (ppm)
	//  Assume all ammonium occurs in the top nitrifyDepth cm
	// double nh4PPM;      // soil ammonium (NH4+) concentration (ppm)

	// not used
	// grams of soil per sq. meter in top nitrifyDepth cm of soil
	// double grams_soil =
	//	BulkDensity().WtdMean(0.0f, nitrifyDepth, depth, thickness) *
	//	nitrifyDepth * CM_per_METER * CM_per_METER;

	//  Compute the effect of wfps on Nitrification (0-1)
	float a, b, c, d;
        switch (textureIndex)
        {
            case COARSE:
                a = 0.5;
                b = 0.0;
                c = 1.5;
                d = 4.5;
                break;
            case FINE:
            case VERYFINE:
                a = 0.65;
                b = 0.0;
                c = 1.2;
                d = 2.5;
                break;
            case MEDIUM:
            default:
                a = 0.65;
                b = 0.0;
                c = 1.2;
                d = 2.5;
                break;
        }
        float const base1 =((avgWFPS - b) / (a - b));
        float const base2 =((avgWFPS - c) / (a - c));
        float const e1 = d * ((b - a) / (a - c));
        float const e2 = d;
        Assert ( base1 > 0.0 );
        Assert ( base2 > 0.0 );
        double const fNwfps = pow (base1, e1) * pow (base2, e2);
        Assert (fNwfps >= 0.0);

	float A[4];	// parameters to parton-innis functions

	//  Soil temperature effect on Nitrification (0-1)
        A[0] = maxt;	// Long term avg max monthly air temp. of hottest month
        A[1] = -5.0;
        A[2] = 4.5;
        A[3] = 7.0;
        double const fNsoilt = f_gen_poisson_density (surfTempAvg, A);
        Assert (fNsoilt >= 0.0);

	//  Compute pH effect on nitrification
        A[0] = 5.0;
        A[1] = 0.56;
        A[2] = 1.0;
        A[3] = 0.45;
        double const fNph = f_arctangent (GetSoilPH(), A);
        Assert (fNph >= 0.0);

	// Ammonium that goes to nitrate during nitrification.
        double const base_flux = 0.1 * Ha_to_SqM;	// 0.1 gN/ha/day
        NH4_to_NO3 =
        	ammonium * MaxNitrifRate * fNph * fNwfps * fNsoilt + base_flux;
        Assert (NH4_to_NO3 >= 0.0);
        Assert (NH4_to_NO3 <= ammonium);

	// do not decrease below minimum NH4
        if ((ammonium - NH4_to_NO3) > min_ammonium)
            ammonium -= NH4_to_NO3;
        else
            NH4_to_NO3 = 0.0;
    }

#ifndef NDEBUG
    double const finalTotalN = ammonium + NH4_to_NO3;
    dynamic_cast<TDailyCenturyBase const &>(owner).BalanceCheckWithMsg (
	initialTotalN, finalTotalN, 5.0E-5, "Nitrify total N" );
#endif

    return NH4_to_NO3;
}

//--- end of file ---
