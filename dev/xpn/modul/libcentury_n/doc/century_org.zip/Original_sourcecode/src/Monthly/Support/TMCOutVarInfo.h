#ifndef INC_TOutVarInfo_h
#define INC_TOutVarInfo_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TMCOutVarInfo.h
//	Class:	  TMCOutputVariableInfo
//
//	Description:
//	Reads names and descriptions of the Century output variables
//	from the netCDF file, OutVarInfo,nc / OutVarInfo.cdl.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Sep98
//	History:
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* A bit of cleaning up and const-correctness.
//	Oct01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Substantially modified to use the new base class TOutVarInfoBase.
//	Jun02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Changed file name to TMCOutVarInfo and
//	  class name to TMCOutputVariableInfo
//	  to distinguish from the DayCent version (class TDCOutputVariableInfo).
// ----------------------------------------------------------------------------
//	Notes:
//	This class should only be instantiated once (a singleton).
//	Should never need to be copied, only referenced.
// ----------------------------------------------------------------------------

#include "TOutVarInfoBase.h"
#include "TFileName.h"

//	-----------------------------------------------------------------------
//	Forward references for friend classes to do netCDF I/O
class TNcFileOutVarDef;

//	-----------------------------------------------------------------------
//	TOVICategory
// 	which output variable category
//	See base class
/*
enum TOVICategory
{
	WaterTemp, SoilC, CropGrassC, ForestC, CO2, NPS, numCategories
};
*/

// ----------------------------------------------------------------------------
//	TMCOutputVariableInfo
//	Contains the data describing individual parameters.
class TMCOutputVariableInfo : public TOutVarInfoBase
{
	// Friend classes for all handling all netCDF file I/O.
	friend class TNcFileOutVarDef;		// reads parameter definitions

  public:
	//--- data

	//--- constructors and destructor
	TMCOutputVariableInfo (
	  TEH::TFileName const & outVarDefsPath);
	virtual ~TMCOutputVariableInfo ()
	  {
	    Clear ();
	  }

	//--- functions
	char const** GetNameList (			// Get the name list
	  TOVICategory whichCategory) const;
	char const** GetDescList (			// Get descriptions
	  TOVICategory whichCategory) const;
	short GetListSize (
	  TOVICategory whichCategory) const;

  protected:
	//--- data
	// Note: Lists of names and descriptions are NULL-terminated.
					//--- Water and temperature
	char **wtNames;			// list of parameter names
	char **wtDescs;			// list of parameter descriptions
	short wtCount;			// size of list
					//--- C in soil
	char **soilNames;		// list of parameter names
	char **soilDescs;		// list of parameter descriptions
	short soilCount;		// size of list
					//--- C in Crop and grass
	char **cgNames;			// list of parameter names
	char **cgDescs;			// list of parameter descriptions
	short cgCount;			// size of list
					//--- C in forest systems
	char **forestNames;		// list of parameter names
	char **forestDescs;		// list of parameter descriptions
	short forestCount;		// size of list
					//--- CO2
	char **co2Names;		// list of parameter names
	char **co2Descs;		// list of parameter descriptions
	short co2Count;			// size of list
					//--- N, P, and S
	char **npsNames;		// list of parameter names
	char **npsDescs;		// list of parameter descriptions
	short npsCount;			// size of list

	//--- functions
	void Clear ();					// Clear member data
	bool ReadNamesDescs (				// Read names, desc.
	  TEH::TFileName const & outVarDefsPath);	//   from this file

  private:
	//--- functions
	void Initialize ();				// Initialize members
};

#endif // INC_TOutVarInfo_h
