// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TMCSiteParamInfo.cpp
//	Class:	  TMCSiteParamInfo
//
//	Description:
//	Class for Century site parameter definitions, TMCSiteParamInfo.
//	An associated class is TMCSiteParameters which manages the site params.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Feb98, tom.hilinski@colostate.edu
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TMCSiteParamInfo.h"
#include "TMCSiteParameters.h"
#include "TNcFileSitePar.h"		// always after T_SiteParam.h

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

char const * const TMCSiteParamInfo::defaultFileName = "SiteParamDef.nc";

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	ReadNamesDescs
//	Reads in the names and descriptions of the parameters from the
//	specified netCDF file name.
//	Stores in member variables.
//	Returns false if successful, else true if error.
bool TMCSiteParamInfo::ReadNamesDescs (
	TEH::TFileName const & infoNCFileName)	// netCDF definitions file
{
	TNcSiteParamDef nc (infoNCFileName);	// class to access netCDF data
	if ( nc.Read (*this) ||  nc.IsNcErr() )
	{
		if ( 0 != nc.GetNcErrStr() )
		{
			if ( !errStr.empty() )
				errStr += '\n';
			errStr += nc.GetNcErrStr ();
			errStr += '\n';
			errStr += infoNCFileName.GetFullName();
		}
		return true;
	}
	else
		return false;
}

//	Constructor
//	Common constructor.
void TMCSiteParamInfo::Constructor (
	TEH::TFileName const & useSiteParamInfoFile)
{
	FillSiteSetIndicesList ();
	TEH::TFileName siteParamDefs;
	if ( useSiteParamInfoFile.IsEmpty() )                   // name empty?
	{
        	// add default file name
	        siteParamDefs.Assign (
        	  defaultFileName, TEH::TFileName::FT_Normal);  // use default
	}
	else if ( !useSiteParamInfoFile.HaveName() )            // name empty?
	{
        	// have path; add default file name
	        siteParamDefs = useSiteParamInfoFile;
        	const TEH::TFileName tmpName (defaultFileName);
		siteParamDefs.SetName ( tmpName.GetName() );
		siteParamDefs.SetExtension ( tmpName.GetExtension() );
	}
	else							// use full name
	{
	        siteParamDefs = useSiteParamInfoFile;
	}
	if ( ReadNamesDescs (siteParamDefs) )			// read it now
	{
		// need error handling here
	}
}

void TMCSiteParamInfo::FillSiteSetIndicesList ()	// fill siteSetIdx
{
	unsigned short const mySiteSetIdx[ /* GetSetCount() + 1 */ ] =
	{
		TMCSiteParIndices::SPI_precip,
		TMCSiteParIndices::SPI_ivauto,
		TMCSiteParIndices::SPI_epnfa,
		TMCSiteParIndices::SPI_som1ci,
		TMCSiteParIndices::SPI_rlvcis,
		TMCSiteParIndices::SPI_minerl,
		TMCSiteParIndices::SPI_rwcf,
		TMCSiteParIndices::SPI_lhicu,
		TMCSiteParIndices::SPI_eflcu,
		TMCSiteParIndices::SPI_EndOfList
	};
	siteSetIdx.assign (
		mySiteSetIdx,
		mySiteSetIdx + indices.GetSetCount() + 1);
}

//--- end of definitions for TMCSiteParamInfo ---

