// ----------------------------------------------------------------------------
//	Project:  V GUI Enhancement
//	File:	  TSelectDirDlg.cpp
//	Class:	  TSelectDirDlg
//
//	Description:
//	A class which allows the user to select a directory from a list,
//	or to create a new subdirectory.
//
//	Requires the class TFileList.
//	Requires the V GUI library, version 1.22 or higher.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Aug99
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------
// Copyright (c) 1999 Thomas E. Hilinski. All rights reserved.
// Unauthorized distribution, duplication, sale, and use is prohibited by law.
//
//	This software is made available under the terms of the
//	GNU LIBRARY GENERAL PUBLIC LICENSE.
//	This copyright notice must remain intact and in place.
// ----------------------------------------------------------------------------

#include "TSelectDirDlg.h"
// check for minimum V version
#if (V_VersMajor < 1) || (V_VersMinor < 22)
  #error V version 1.22 or higher is required.
#endif
#include <v/vutil.h>
#include <v/vicon.h>
#include <v/vnotice.h>
#include <v/vos.h>
#include <cstring>
using namespace TEH;


// ----------------------------------------------------------------------------
//	icons
// ----------------------------------------------------------------------------
#include "UpFolderIcon.vbm"
static vIcon UpFolderIcon ( &UpFolderIcon_bits[0], UpFolderIcon_height,
				UpFolderIcon_width, UpFolderIcon_depth );
#include "GoToFolderIcon.vbm"
static vIcon GoToFolderIcon ( &GoToFolderIcon_bits[0], GoToFolderIcon_height,
				GoToFolderIcon_width, GoToFolderIcon_depth );
#include "NewFolderIcon.vbm"
static vIcon NewFolderIcon ( &NewFolderIcon_bits[0], NewFolderIcon_height,
				NewFolderIcon_width, NewFolderIcon_depth );
#include "IntoFolderIcon.vbm"
static vIcon IntoFolderIcon ( &IntoFolderIcon_bits[0], IntoFolderIcon_height,
				IntoFolderIcon_width, IntoFolderIcon_depth );

// ----------------------------------------------------------------------------
//	local variables
// ----------------------------------------------------------------------------

// path separator
#if defined(_Windows) || defined(__WIN32__)
static const char separatorPath = '\\';		// backslash
#else	// assume Unix
static const char separatorPath ='/';		// slash
#endif

static char const* wildCard = "*.*";			// wild card
static char const* title = "Select a Folder";		// default dialog title
static char *NULLStr = "";				// global NULL string

// ----------------------------------------------------------------------------
//	static member variables
// ----------------------------------------------------------------------------

char const* TSelectDirDlg::version = "1.00";	// class version string

char const* TSelectDirDlg::toolTips[] =		// tool tips text
{
	// 0 = "Select" button
	"Select the highlighted folder and close window.",
	// 1 = "Cancel" button
	"Cancel this operation.",
	// 2 = "Look in" path text edit control
	"Path in which to view a list of folders.",
	// 3 = icon button "move up directory tree"
	"View the parent folder.",
	// 4 = icon button "new folder"
	"Create a new folder using the displayed name.",
	// 5 = folder text edit box
	"Select or create this folder.",
	// 6 = "into folder" icon button.
	"View folders in the displayed folder.",
	// 7 = folder list
	"Select a folder from this list.",
	// 8 = "Go to folder" icon
	"View folders in the displayed path.",
	// last item always
	NULL
};

CommandObject TSelectDirDlg::cmdList[] =
{
	//--- Master Frame
	{C_Frame, 101, 0, NULLStr, NoList, CA_NoBorder, isSens, NoFrame, 0, 0},
	//--- "Look in" path
	{C_Frame, 110, 0, NULLStr, NoList, CA_NoBorder, isSens, 101, 0, 0},
	{C_Label, 201, 0, "Path:",
		NoList, CA_None, isSens, 110, 0, 0, 30},
	{C_TextIn, DC_Path, 0, NULLStr,
		NoList, CA_None, isSens, 110, 201, 0, 41, toolTips[2]},
	{C_IconButton, DC_Up, DC_Up, NULLStr, (void*)&UpFolderIcon,
		CA_None, isSens, 110, DC_Path, 0, 0, toolTips[3]},
	{C_IconButton, DC_GoTo, DC_GoTo, NULLStr, (void*)&GoToFolderIcon,
		CA_None, isSens, 110, DC_Up, 0, 0, toolTips[8]},

	//--- Folder selections
	{C_Frame, 120, 0, NULLStr, NoList, CA_NoBorder, isSens, 101, 0, 110},
	{C_Label, 210, 0, "Folder:",
		NoList, CA_None, isSens, 120, 0, 0, 30},
	{C_TextIn, DC_Folder, 0, NULLStr,
		NoList, CA_None, isSens, 120, 210, 0, 41, toolTips[5]},
	{C_IconButton, DC_Down, DC_Down, NULLStr, (void*)&IntoFolderIcon,
		CA_None, isSens, 120, DC_Folder, 0, 0, toolTips[6]},
	{C_IconButton, DC_New, DC_New, NULLStr, (void*)&NewFolderIcon,
		CA_None, isSens, 120, DC_Down, 0, 0, toolTips[4]},
	{C_List, DC_FolderList, 172, NULLStr,
		NoList, CA_ListWidth, isSens, 120, 210, DC_Down,
		0, toolTips[7]},
	{C_Button, M_OK, M_OK, "&Select",
		NoList,	CA_DefaultButton, isSens, 120, DC_FolderList, DC_Down,
		0, toolTips[0]},
	{C_Button, M_Cancel, M_Cancel, "&Cancel",
		NoList,	CA_None, isSens, 120, DC_FolderList, M_OK,
		0, toolTips[1]},

	{C_EndOfList, 0, 0, 0, 0, CA_None, 0, 0}
};

// ----------------------------------------------------------------------------
//	methods
// ----------------------------------------------------------------------------

//--- constructors and destructor

TSelectDirDlg::TSelectDirDlg (
	vApp* const parent,			// ptr to parent V app
	char const * const useDlgTitle) 	// dialog title
	: vModalDialog (parent, useDlgTitle)
{
	Initialize ();
	AddDialogCmds ((CommandObject*)cmdList);	// add dialog controls
}

TSelectDirDlg::TSelectDirDlg (
	vBaseWindow* const parent, 		// ptr to parent window/dialog
	char const * const useDlgTitle) 	// dialog title
	: vModalDialog (parent, useDlgTitle)
{
	Initialize ();
	AddDialogCmds ((CommandObject*)cmdList);	// add dialog controls
}

TSelectDirDlg::~TSelectDirDlg ()
{
	ClearDlgList ();
	DeleteList ();
}


//--- functions overridden

void TSelectDirDlg::DialogDisplayed ()
{
	vModalDialog::DialogDisplayed ();
	LoadDlg ();
}

void TSelectDirDlg::DialogCommand (ItemVal id, ItemVal val, CmdType type)
{
	switch (id)
	{
	  case M_Cancel:		// Cancel button
		if ( path )
		{
			delete [] path;
			path = 0;
		}
	  	break;
	  case M_OK:			// "Select" button or "Enter" keypress
		if ( UserChgLookInText() )
		{
			GetPathFromLookIn ();	// get the entered path
			LoadDlg ();
			id = DC_Path;
		}
		else if ( UserChgFolderText() )
		{
			BldListFromFolder ();	// make new folder list
			id = DC_Folder;
		}
		else
			GetSelectedPath ();	// path from folder list
		break;
	  case DC_FolderList:		// list selection
		Evt_ListSelection ();
		break;
	  case DC_Up:			// up-folder icon button
		Evt_UpFolder ();
		break;
	  case DC_Down:			// into-folder icon button
		Evt_DownFolder ();
		break;
	  case DC_New:			// new-folder icon button
	  	Evt_NewFolder ();
		break;
	  case DC_GoTo:			// go to folder icon button
		Evt_GoToFolder ();
		break;
	  default:
		break;
	};
	// Default event processing
	vModalDialog::DialogCommand (id, val, type);
}

//--- public functions

//	DirSelect
//	Displays the dialog.
//	Returns a string containing the fully-qualified path
//	to the user's selection, or NULL if cancel was pressed.
//	Ownership of the returned string is of the calling function,
//	which must delete the string when done.
//	"initDir" is the starting directory.
char* TSelectDirDlg::DirSelect (
	char const * const initDir)	// initial directory
{
	if ( initDir )				// already have starting path?
		CopyToPath ((char*)initDir);	// ...save it
	else					// need to find starting path
	{
		char cwd [MAX_PATH + 1];
		vOS os;				// instance of
		os.vGetCWD (cwd, MAX_PATH);	// get current path
		CopyToPath (cwd);		// save starting path
	}

	// display dialog
	ItemVal retVal;
	ShowModalDialog ((char*)::title, retVal);	// display it now
	// all done!
	return path;
}


//--- private functions

//	Initialize
//	Initialize the member variables.
void TSelectDirDlg::Initialize ()
{
	lastError = NoError;
	dirList = NULL;
	path = NULL;
	// Get the indicies to cmdList items for lists.
	// Done only once for speed.
	idxParamList = ::vGetcmdIdIndex (DC_FolderList, cmdList);
}

//	LoadDlg
//	load data into dialog
void TSelectDirDlg::LoadDlg ()
{
	// save current string
	char* prevPath = 0;
	try
	{
		prevPath = new char [strlen(path) + 1];
		strcpy (prevPath, path);
	}
	catch (...)
	{
		lastError = MemoryAlloc;
		return;
	}

	// create mask with wildCard "*.*" at end of path
	AppendToPath ((char*)::wildCard);

	// create a list of folders
	TFileNameList fnList (path, TFileNameList::FLT_Directory);
	if ( fnList.GetCount() == 0 )
	{
		ClearDlgList ();
		DeleteList ();
		SetString ( DC_Folder, NULLStr );
	}
	else if ( !fnList.IsError() )
	{
		// copy the list
		DeleteList ();
		CopyList (fnList.GetList(), fnList.GetCount() );
		// display list
		cmdList[idxParamList].itemList = (void *)dirList;
		SetValue (cmdList[idxParamList].cmdId, 0, ChangeListPtr);
	}

	// display current path
	delete [] path;				// delete wildcard mask
	path = prevPath;
	SetString (DC_Path, path);
	Evt_ListSelection ();
}

//	ClearDlgList
// 	Clear site list display
void TSelectDirDlg::ClearDlgList ()
{
	cmdList[idxParamList].itemList = (void *)NULL; 	// set ptr to list
	SetValue (cmdList[idxParamList].cmdId, 0, ChangeListPtr); // display
}

//	CopyList
// 	copy a list to dirList
void TSelectDirDlg::CopyList (
	char const * const * const from,
	short size)
{
	if ( size > 0 && from )
	{
		try
		{
			dirList = (char const**) new char* [size + 1];
		}
		catch (...)
		{
			lastError = MemoryAlloc;
			dirList = 0;
			return;
		}
		dirList[size] = NULL;
		char const * const * p = from;
		char **q = (char**) dirList;
		while ( *p )
		{
			try
			{
				*q = new char [strlen(*p) + 1];
			}
			catch (...)
			{
				lastError = MemoryAlloc;
				*q = 0;
				return;
			}
			strcpy (*q, *p);
			++q;
			++p;
		}
	}
}

//	DeleteList
// 	delete contents of dirList
void TSelectDirDlg::DeleteList ()
{
	if ( dirList )
	{
		char** p = (char**) dirList;
		while ( *p )
			delete [] *(p++);
		delete [] dirList;
		dirList = 0;
	}
}

//	CopyToPath
//	copy to path
void TSelectDirDlg::CopyToPath (char* newPath)
{
	if ( newPath )
	{
		delete [] path;
		try
		{
			path = new char [strlen(newPath) + 1];
		}
		catch (...)
		{
			lastError = MemoryAlloc;
			return;
		}
		strcpy (path, newPath);
	}
}

//	AppendToPath
//	append subdir. to path
void TSelectDirDlg::AppendToPath (char* subDir)
{
	if ( !subDir )
		return;
	if ( !path )
	{
		CopyToPath (subDir);
		return;
	}

	bool needSep = false;			// true if need slash at end
	char *prevPath = path;			// save here
	short len = (short) strlen (prevPath); 	// length of new path
	if ( *(prevPath + len - 1) != ::separatorPath &&
	     *subDir != ::separatorPath )	// need separator?
	{
		needSep = true;
		++len;
	}
	else if ( *(prevPath + len - 1) == ::separatorPath &&
		  *subDir == ::separatorPath )		// two separators?
	{
		*(prevPath + len - 1) = '\0';
		--len;
	}
	// create a new path
	try
	{
		path = new char [len + strlen(subDir) + 1];
	}
	catch (...)
	{
		lastError = MemoryAlloc;
		path = prevPath;
		return;
	}
	strcpy (path, prevPath);
	if ( needSep )
	{
		*(path + len - 1) = ::separatorPath;
		*(path + len) = '\0';
	}
	strcat (path, subDir);
	delete [] prevPath;
}

//	GetParentPath
//	Builds a path string that is the parent of the current path.
//	Stores the new path in the member variable "path".
void TSelectDirDlg::GetParentPath ()
{
	// Search for right-most path separator
	// Conditions to check in path string in DOS/Windows:
	// 1. "", 2. "\", 3. "c:\" and "c:",
	// 4. "<stuff>\<last folder>\", 5. "<stuff>\<last folder>"
	if ( !path || !*path )			// empty? (no. 1)
		return;				// ...do nothing
	short len = (short) strlen(path);		// get path length
	if ( len == 1 && *path == separatorPath)	// no. 2
		return;					// ...do nothing
	char *p = path + len - 1;		// start at end of path
	if ( *p == ':' || *(p - 1) == ':' )	// DOS/Win device separator?
		return;				// ...no. 3 - do nothing
	// assume now we have a normal path
	while ( p != path )
	{
		if ( *(--p) == separatorPath )
		{
			*(p+1) = '\0';
			break;
		}
	}
}

//	GetPathFromLookIn
//	Build path from text input box, "Look In".
//	Stores the new path in the member variable "path".
void TSelectDirDlg::GetPathFromLookIn ()
{
	char str[256];				// input string
	GetTextIn (DC_Path, str, 256);
	strtrim ( static_cast<char*>(str) );
	if ( strcmp (path, str) )		// differ from "path"?
		CopyToPath (str);
}

//	BldListFromFolder
//	Build new list from folder input box text. (e.g., "C*")
void TSelectDirDlg::BldListFromFolder ()
{
	// save current path
	// save current string
	char* prevPath = 0;
	try
	{
		prevPath = new char [strlen(path) + 1];
		strcpy (prevPath, path);
	}
	catch (...)
	{
		lastError = MemoryAlloc;
		return;
	}

	// Get text from the "Folder:" text input box
	char str[256];				// input string
	GetTextIn (DC_Folder, str, 256);
	strtrim ( static_cast<char*>(str) );
	AppendToPath (str);

	// create a list of folders
	TFileNameList fnList (path, TFileNameList::FLT_Directory);
	if ( fnList.IsError() )
	{
		delete [] path;
		path = prevPath;
	}
	else
	{
		// copy the list
		DeleteList ();
		CopyList (fnList.GetList(), fnList.GetCount() );
		// display list
		cmdList[idxParamList].itemList = (void *)dirList;
		SetValue (cmdList[idxParamList].cmdId, 0, ChangeListPtr);
		delete [] prevPath;
	}

	// display current path
	SetString (DC_Path, path);
	Evt_ListSelection ();
}

//	UserChgLookInText
//	Returns true if user has changed the text in the "Look In" text box.
bool TSelectDirDlg::UserChgLookInText ()
{
	bool retVal = false;			// return flag
	char str[256];				// input string
	GetTextIn (DC_Path, str, 256);		// get input
	strtrim ( static_cast<char*>(str) );
	if ( strcmp(path, str) )		// differ from "path"?
		retVal = true;
	return retVal;
}

//	UserChgFolderText
//	Returns true if user has changed the text in the "Folder" text box.
bool TSelectDirDlg::UserChgFolderText ()
{
	bool retVal = false;			// return flag
	if ( dirList )
	{
		char str[256];				// input string
		GetTextIn (DC_Folder, str, 256);	// get input
		strtrim ( static_cast<char*>(str) );
		// get index to the currently selected item in the event list
		short idx = (short)GetValue (DC_FolderList);
		if ( strcmp((char*)dirList[idx], str) )	// differ?
			retVal = true;
	}
	return retVal;
}

//	Evt_ListSelection
//	list selection event
void TSelectDirDlg::Evt_ListSelection ()
{
	if ( dirList )
	{
		// get index to the currently selected item in the event list
		short idx = (short)GetValue (DC_FolderList);
		// display the folder
		SetString ( DC_Folder, (char*)dirList[idx] );
	}
}

//	Evt_UpFolder
//	up-folder icon button event
void TSelectDirDlg::Evt_UpFolder ()
{
	GetParentPath ();
	LoadDlg ();
}

//	Evt_DownFolder
//	into-folder icon button event
void TSelectDirDlg::Evt_DownFolder ()
{
	GetSelectedPath ();
	LoadDlg ();
}

//	Evt_NewFolder
//	new-folder icon button event
void TSelectDirDlg::Evt_NewFolder ()
{
	const char *errMsg[] = {
		"Path length exceeds the maximum allowed.",	// 0
		"Could not create the specified folder.",	// 1
		NULL						// last one
	};

	// get new folder name from the folder input box
	char str[MAX_PATH];				// input string
	GetTextIn (DC_Folder, str, MAX_PATH);		// get input
	strtrim ( static_cast<char*>(str) );
	if ( *str == '\0' )				// anything there?
		return;					// ...no

	// save current path in case of create failure
	char* prevPath = 0;
	try
	{
		prevPath = new char [strlen(path) + 1];
		strcpy (prevPath, path);
	}
	catch (...)
	{
		lastError = MemoryAlloc;
		return;
	}

	// build new path
	AppendToPath (str);
	if ( strlen(path) > MAX_PATH )			// exceed length limit?
	{
		// display notice and return
		vNoticeDialog dlg (this, "Path Error");
		dlg.Notice ((char*)errMsg[0]);
		goto error_done;
	}

	// create a new directory
	if ( mkdir (path) == -1 )			// failed?
	{
		// display notice and return
		vNoticeDialog dlg (this, "Folder Creation Error");
		// add: retrieve the windows error message
		dlg.Notice ((char*)errMsg[1]);
		goto error_done;
	}

error_done:
	// restore the original path
	delete [] path;
	path = prevPath;

	LoadDlg ();
}

//	Evt_GoToFolder
//	go to folder icon button
void TSelectDirDlg::Evt_GoToFolder ()
{
	if ( UserChgLookInText() )
	{
		GetPathFromLookIn ();
		LoadDlg ();
	}
}

//	GetSelectedPath
// 	Builds a fully-qualified path from the highlighted folder in the
//	folder list.
//	Stores the new path in the member variable "path".
void TSelectDirDlg::GetSelectedPath ()
{
	if ( dirList )
	{
		// get index to the currently selected item in the event list
		short idx = (short)GetValue (DC_FolderList);
		AppendToPath ((char*)dirList[idx]);
		// check if needs terminating slash
		short len = (short) strlen(path);
		char *p = path + len - 1;
		if ( *p != '\\' )
		{
			try
			{
				p = new char [len + 2];
			}
			catch (...)
			{
				lastError = MemoryAlloc;
				return;
			}
			strcpy (p, path);
			*(p + len) = '\\';
			*(p + len + 1) = '\0';
			delete [] path;
			path = p;
		}
	}
}

//	strtrim
//	Trims the leading and trailing spaces from a string.
void TSelectDirDlg::strtrim (char* s)
{
	register short i = (short)(strlen(s) - 1);	// length - 1
	register char *p = s + i;			// point to end

	// trim trailing space
	while ( i >= 0 && (*p < '!' || *p > '~') )
	{
		p--;
		i--;
	}
	*(++p) = '\0';			// terminate with NULL

	// trim leading space (if any)
	if ( *s && ( *s < '!' || *s > '~' ) )
	{
		char *pEnd = p;			// point to terminating NULL
		p = s + 1;			// start of string
		while ( *p < '!' || *p > '~' )	// find 1st non-white space
			p++;
		memmove (s, p, pEnd - p + 1);	// move to start of string
	}
}

//	mkdir
//	Create a folder: implements UNIX-style mkdir function
//	in OS-independent manner.
//	Does not set permissions - lets OS do its thing there.
//	Returns 0 if successful, else -1 if not.
int TSelectDirDlg::mkdir (char const* path)
{
#ifndef MAX_PATH
#define MAX_PATH 256
#endif

	// error checks
	if ( !(*path) )					// anything there?
		return -1;				// ...failed
	if ( strlen(path) > MAX_PATH )			// exceed length limit?
		return -1;				// ...failed

	// create the directory

#if defined(_Windows) || defined(__WIN32__)
	SECURITY_ATTRIBUTES security;
	security.lpSecurityDescriptor = NULL;
	security.bInheritHandle = TRUE;
	security.nLength = sizeof security;
	if ( ::CreateDirectory (path, &security) == 0 )
		return -1;					// failed
	else
		return 0;

#elif defined(__MSDOS__)


#else	// assume Unix
	return mkdir (path);

#endif
}

