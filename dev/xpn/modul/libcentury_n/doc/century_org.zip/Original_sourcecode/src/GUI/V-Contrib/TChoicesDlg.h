#ifndef INC_TChoicesDlg_h
#define INC_TChoicesDlg_h

// ----------------------------------------------------------------------------
// Copyright (c) 1999 Thomas E. Hilinski. All rights reserved.
// Unauthorized distribution, duplication, sale, and use is prohibited by law.
//
//	This software is made available under the terms of the
//	GNU LIBRARY GENERAL PUBLIC LICENSE.
//	This copyright notice must remain intact and in place.
// ----------------------------------------------------------------------------
//	Project:  V GUI Enhancement
//	File:	  TChoicesDlg.h
//	Class:	  TChoicesDialog
//
//	Description:
//	Declaration of class for a V dialog displaying a variable number of
//	radio buttons.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, hilinski@lamar.colostate.edu, Jan98
//	History:
//	20Aug99	- version 1.10
//	* Enhanced error handling w/error codes and exception handling.
//	29Nov99	Tom Hilinski, hilinski@lamar.colostate.edu
//	* Added "NextColumn" function.
//	July 2001 - version 1.20
//	* Added to DialogDisplayed, calcs for centering the dialog in an app's
//	  window. This is implemented only for Microsoft Windows display.
//	* Added constructor parameter to turn centering off.
//	Feb03 - version 1.30
//	* Misc. cleanup and added const-ness.
//	* Tested on MS Windows 2000 and X11R6/Motif.
//	Oct03 - version 1.40
//	* Added member InitialSelection.
//	* Overloaded AddChoice to take std::string.
// ----------------------------------------------------------------------------
//	To use:
//	In the constructor, provide (1) a multi-line message telling the user
//	what the buttons are about; (2) the number of radiobuttons to be
//	added, and (3) optionally, a title for the dialog box (the default
//	is "Choose").
//	Add radiobuttons with the member function "AddChoice".
//	If you want to have your radiobuttons in multiple columns, use
//	the function "NextColumn" before the "AddChoice" which will begin
//	the new column.
//	When ready to get a response from the user, use the member function
//	"GetChoice", which returns a 1-based index to the radiobuttons. If
//	the return value is zero, the user pressed "Cancel".
// ----------------------------------------------------------------------------

#include <v/vmodald.h>
#include <string>

class TChoicesDialog : public vModalDialog
{
public:
	//--- types
	enum TCDErrors		// error flags
	{
	  NoError, 		// no error - FIRST ENUM ITEM ALWAYS
	  MemoryAlloc,		// memory allocation error
	  NullText,		// null pointer to choice text
	  NoChoices,		// empty choices list
	  ZeroChoices,		// choice count in constructor is zero
	  TooMany,		// exceeded the number of choices requested
	  UnknownError		// unknown error - LAST ENUM ITEM ALWAYS
	};
	typedef unsigned short		size_type;	// list size and index

	//--- constructors and destructor
	TChoicesDialog (
	  vBaseWindow * const bw,		// pointer to window
	  char const * const msg,		// message at top of choices
	  short const numChoices,		// number of choices
	  char const * const title = "Choose",	// title of dialog
	  bool const centerMe = true);		// flag to center the dialog
	TChoicesDialog (
	  vApp * const app,			// pointer to application
	  char const * const msg,		// message at top of choices
	  short const numChoices,		// number of choices
	  char const * const title = "Choose",	// title of dialog
	  bool const centerMe = true);		// flag to center the dialog
	~TChoicesDialog ();

	//--- functions
	void AddChoice (			// Add a radiobutton
	  char const * const buttonText);
	void AddChoice (			// Add a radiobutton
	  std::string const & buttonText)
	  {
	    AddChoice ( buttonText.c_str() );
	  }
	void NextColumn ();			// Start a new column
	bool InitialSelection (			// Initial item selected
	  size_type const itemNumber);		//   one-based list index
	bool InitialSelection (			// Initial item selected
	  char const * const buttonText);	//   this item's text
	bool InitialSelection (			// Initial item selected
	  std::string const & buttonText)	//   this item's text
	  {
	    return InitialSelection ( buttonText.c_str() );
	  }
	short GetChoice ();			// Get user's response

	//--- Retrieve info
	TCDErrors LastError () const		// Get last error code
	  { return lastError; }
	char const * const GetVersion () const	// Get version of this class.
	  { return version; }
private:
	//--- static data
	static char const * const version;	// class version string

	//--- data
	enum TCmdObjIDs	 		// IDs for CommandObjects
	{
	  CID_Msg     = 1000,		// ID for text above buttons
	  CID_Button1 = 2000,		// ID for first button
	  CID_Frame   = 3000,		// ID for frame
	  CID_EndOfList			// Last one always
	};
	CommandObject* coList;		// CommandObject list
	size_type listSize;		// number of choices wanted
	size_type itemsAdded;		// number of choices added
	size_type currentItem;		// last radio button created
	size_type widestBtnID;		// ID of widest button in column
	size_type widestWidth;		// width of widest button in column
	size_type currentSelection;	// ID of the button initially checked
	int toRightOf;			// ID of button to be right of
	int belowOf;			// ID of button to below of
	char* msgText;			// message text
	short choice;			// choice returned to user
	bool const centered;		// True if dialog is centered in appWin
	TCDErrors lastError;		// last error code

	//--- functions
	void Initialize (
	  char const * const msg);

public:
	//--- functions overridden: NOT FOR PUBLIC CONSUMPTION!
	void DialogDisplayed ();
	void DialogCommand (ItemVal id, ItemVal val, CmdType type);
};

#endif // INC_TChoicesDlg_h
