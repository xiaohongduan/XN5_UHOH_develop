// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  sumcar.cpp
//	Class:	  TCenturyBase
//	Function: SumCarbon
//
//	Description:
//	Sum unlabeled and labeled carbon to get totals.
// ----------------------------------------------------------------------------
//	History:
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::SumCarbon ()
{
    soilC.strucc[ABOVE] = strcis_ref (0, 0) + strcis_ref (0, 1);
    soilC.strucc[BELOW] = strcis_ref (1, 0) + strcis_ref (1, 1);
    soilC.metabc[ABOVE] = metcis_ref (0, 0) + metcis_ref (0, 1);
    soilC.metabc[BELOW] = metcis_ref (1, 0) + metcis_ref (1, 1);

    // Sum som1 surface and soil isotopes separately.  vek 08-91
    soilC.som1c[SRFC] = som1ci_ref (0, 0) + som1ci_ref (0, 1);
    soilC.som1c[SOIL] = som1ci_ref (1, 0) + som1ci_ref (1, 1);
    soilC.som2c = soilC.som2ci[0] + soilC.som2ci[1];
    soilC.som3c = soilC.som3ci[0] + soilC.som3ci[1];
    forestC.wood1c = forestC.wd1cis[0] + forestC.wd1cis[1];
    forestC.wood2c = forestC.wd2cis[0] + forestC.wd2cis[1];
    forestC.wood3c = forestC.wd3cis[0] + forestC.wd3cis[1];
    soilC.somtc = soilC.som1c[1] + soilC.som2c + soilC.som3c +
		  soilC.strucc[1] + soilC.metabc[1];

    cropC.aglivc = cropC.aglcis[0] + cropC.aglcis[1];
    cropC.stdedc = cropC.stdcis[0] + cropC.stdcis[1];
    cropC.bglivc = cropC.bglcis[0] + cropC.bglcis[1];
    cropC.agcacc = cropC.agcisa[0] + cropC.agcisa[1];
    cropC.bgcacc = cropC.bgcisa[0] + cropC.bgcisa[1];

    forestC.rleavc = forestC.rlvcis[0] + forestC.rlvcis[1];
    forestC.frootc = forestC.frtcis[0] + forestC.frtcis[1];
    forestC.fbrchc = forestC.fbrcis[0] + forestC.fbrcis[1];
    forestC.rlwodc = forestC.rlwcis[0] + forestC.rlwcis[1];
    forestC.crootc = forestC.crtcis[0] + forestC.crtcis[1];
    forestC.rlvacc = forestC.alvcis[0] + forestC.alvcis[1];
    forestC.frtacc = forestC.afrcis[0] + forestC.afrcis[1];
    forestC.fbracc = forestC.afbcis[0] + forestC.afbcis[1];
    forestC.rlwacc = forestC.alwcis[0] + forestC.alwcis[1];
    forestC.crtacc = forestC.acrcis[0] + forestC.acrcis[1];
    forestC.fcacc = forestC.rlvacc + forestC.frtacc + forestC.fbracc +
		    forestC.rlwacc + forestC.crtacc;
}

//--- end of file ---
