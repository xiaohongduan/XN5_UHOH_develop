// ----------------------------------------------------------------------------
//	Copyright 1999-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCenturySoil.cpp
//	Class:	  TCenturySoil
//
//	Description:
//	Derived from TSoilBase, implements Century-specific functions.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Dec99
//	History: See header file.
// ----------------------------------------------------------------------------
//	Notes:  See header file.
// ----------------------------------------------------------------------------

// Borland C++ Builder warning "hides virtual function Homogenize"
#pragma warn -hid

#include "TCenturySoil.h"
#include "precision.h"
#include "AssertEx.h"
#include <numeric>
#ifdef DBG_CENTURY_SOIL
  #if defined(DAILY_CENTURY)
    #include "TDayCent.h"
    #define CENTURY_TYPE TDayCent
  #elif defined(MONTHLY_CENTURY)
    #include "TCentury.h"
    #define CENTURY_TYPE TCentury
  #else
    #error "I don't know which version of Century I am working with!"
  #endif
  char const * const soilDebugFileName =
  	"c:/tmp/century/" CenturyNickname "-soil-dump.csv";
#endif

#ifdef DBG_CENTURY_SOIL
	float dbg_SoilLayer1Thickness = 0.0f;
	float dbg_SimTime = 0.0f;
#endif

std::string const NSSoilErrors::errorMsgCentury[NSSoilErrors::BadSWFlag + 1] =
{
  std::string (						// Values::NoSolutionC
  	"C distribution algorothm: no solution"),
  std::string (						// Values::BadSolutionC
  	"C distribution algorothm: invalid solution"),
  std::string (						// Values::BadSWFlag
  	"Invalid flag for wilting point and field capacity algorithm"),
};

// ----------------------------------------------------------------------------
//	Member constants
// ----------------------------------------------------------------------------

//	OMPC geometric decrease factor
//	Each layer has this fraction less OMPC than the layer above it.
float const TCenturySoil::ompcGeomFactor = 0.85f;

// The following indices must match the order in which the components are
// added to the component list.
// See sitein.cpp for the order.
TCenturySoil::size_type const			// component indices
	TCenturySoil::indexBulkDensity 		= 0,
	TCenturySoil::indexSandFraction 	= 1,
	TCenturySoil::indexSiltFraction 	= 2,
	TCenturySoil::indexClayFraction 	= 3,
	TCenturySoil::indexWiltingPoint 	= 4,
	TCenturySoil::indexFieldCapacity 	= 5,
	TCenturySoil::indexWaterContent 	= 6,
	TCenturySoil::indexOMPC 		= 7;

// ----------------------------------------------------------------------------
//	public functions - general
// ----------------------------------------------------------------------------

//--- constructors and destructor

TCenturySoil::TCenturySoil (
	nrel::eco::TEcosystemModelBase const & useOwner)	// owner = model
	: nrel::eco::TSubModelBase (useOwner),
	  CenturySubmodelBase (),
	  TSoilBase ()
{
	Initialize ();
}

TCenturySoil::TCenturySoil (
	nrel::eco::TEcosystemModelBase const & useOwner,	// owner = model
	size_type const useNumLayers)	// initial number of layers
	: ::nrel::eco::TSubModelBase (useOwner),
	  CenturySubmodelBase (),
	  TSoilBase ()
{
	Initialize ();
	SetNumLayers (useNumLayers);
}

// 	copy constructor
TCenturySoil::TCenturySoil (
	TCenturySoil const & object)
	: nrel::eco::TSubModelBase (object),
	  // CenturySubmodelBase (object),
	  TSoilBase (object)
{
	if (this != &object)	// check for assignment to self
	{
		Initialize ();
		Copy (object);
	}
}


//--- operator overloads

TCenturySoil& TCenturySoil::operator= (
	TCenturySoil const & object)
{
	if (this != &object)	// check for assignment to self
	{
		nrel::eco::TSubModelBase::operator= (object);
		TSoilBase::operator= (object);
		Copy (object);
	}
	return *this;
}

//--- Miscellaneous public

//	Clear
//	"clear" data members
void TCenturySoil::Clear ()
{
	nrel::eco::TSubModelBase::Clear ();
	TSoilBase::Clear ();
	amtTrans = 0.0f;
	Initialize ();
}

// ----------------------------------------------------------------------------
//	public functions - water submodel
// ----------------------------------------------------------------------------

//	CalcWPandFC
//	Calculate wilting pt. & field capacity using the methods of
//	Gupta and Larson (1979) and Rawls et al (1982).
void TCenturySoil::CalcWPandFC (
	short const swflag)	// flag: 0 - 6
{
	Assert (thickness.size() > 0);
	if ( thickness.size() == 0 )		// no soil, so nothing to do
	{
		lastError = NSSoilErrors::BadLayerCount;
		return;
	}
	Assert (swflag >= 0);
	Assert (swflag <= 6);
	if ( swflag < 0 || swflag > 6 )		// invalid flag value
	{
		lastError = (NSSoilErrors::Values)NSSoilErrors::BadSWFlag;
		return;
	}
	if ( swflag == 0 )
		return;			// valid flag, but nothing to do!

	/*
	Computations based on
	Gupta and Larson (1979). Estimating soil and water retention
	characteristics from particle size distribution, organic
	matter percent and bulk density. Water Resources Research 15:1633
	or
	Rawls et al (1982). Estimation of soil water properties
	Trans. ASAE ???:1316

	Field capacity options of -0.1 or -0.33 bar.
	Wilting point assumed to be water content at -15 bars.
	Calculate organic matter from initial conditions, ivauto or
	or value at the beginning of an extend
	Note that Gupta and Larson and Rawls use % for texture
	but values here are fractions.
	swflag:
	1 = Gupta and Larson: AWILT = -15 bar, AFIEL = -0.33 bar [vers. 3].
	2 = Gupta and Larson:r AWILT (-15 bar) and AFIEL = -0.10 bar.
	3 = Rawls: AWILT = -15 bar, AFIEL = -0.33 bar.
	4 = Rawls: AWILT = -15 bar, AFIEL = -0.10 bar.
	5 = Rawls: AFIEL = -0.33 bar); actual data for AWILT.
	6 = Rawls: AFIEL = -0.10 bar; actual data for AWILT.
	*/
	// parameters for calculating wilting point
	// no wilting point calcs for swflag = 5, 6
 	float const
	  wpcl[4] = { 0.5766f, 0.5766f, 0.5f, 0.5f },
	  wpom[4] = { 0.002228f, 0.002228f, 0.0158f, 0.0158f },
	  wpbd[4] = { 0.02671f, 0.02671f, 0.0f, 0.0f, },
	  wpin[4] = { 0.0f, 0.0f, 0.026f, 0.026f },
	  wpsa[4] = { -0.0059f, -0.0059f, 0.0f, 0.0f },
	  wpsi[4] = { 0.1142f, 0.1142f, 0.0f, 0.0f };
	// parameters for calculating field capacity
	float const
	  fcsa[6] = { 0.3075f, 0.5018f, -0.2f, -0.3f, -0.19f, 0.31f },
	  fcsi[6] = { 0.5886f, 0.8548f, 0.0f, 0.0f, 0.0f, 0.0f },
	  fccl[6] = { 0.8039f, 0.8833f, 0.36f, 0.23f, 0.0f, 0.0f },
	  fcom[6] = { 0.002208f, 0.004966f, 0.0299f, 0.0317f, 0.021f, 0.026f },
	  fcbd[6] = { -0.1434f, -0.2423f, 0.0f, 0.0f, 0.0f, 0.0f },
	  fcwp[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.72f, 0.41f },
	  fcin[6] = { 0.0f, 0.0f, 0.2576f, 0.4118f, 0.2391f, 0.4103f };

	TFloatArray::const_iterator
		iSand = SandFraction().Values().begin (),
		iSilt = SiltFraction().Values().begin (),
		iClay = ClayFraction().Values().begin (),
		iOmpc = OMPC().Values().begin (),
		iBD = BulkDensity().Values().begin ();
	TFloatArray::iterator
		iWP = WiltingPoint().Values().begin (),
		iFC = FieldCapacity().Values().begin ();
	TFloatArray::const_iterator t = thickness.begin ();
	size_type const idx = swflag - 1;		// index to arrays
	while ( t != thickness.end() )
	{
	    if ( swflag <= 4 )	// no wilting point calcs for swflag = 5, 6
	    {
		*iWP =	wpsa[idx] * *iSand + wpsi[idx] * *iSilt +
			wpcl[idx] * *iClay + wpom[idx] * *iOmpc +
			wpbd[idx] * *iBD   + wpin[idx];
	    }
	    *iFC =	fcsa[idx] * *iSand + fcsi[idx] * *iSilt +
			fccl[idx] * *iClay + fcom[idx] * *iOmpc +
			fcbd[idx] * *iBD   + fcwp[idx] * *iWP + fcin[idx];
	    // increment the iterators
	    ++iSand, ++iSilt, ++iClay, ++iOmpc, ++iBD, ++iWP, ++iFC;
	    ++t;
	}
}


//	SetFractions
//	Save the base and storm flow fractions.
void TCenturySoil::SetFractions (
	float const useBaseFlowFrac,
	float const useStormFlowFrac)
{
	Assert (useBaseFlowFrac >= 0.0f);
	Assert (useBaseFlowFrac <= 1.0f);
	if ( useBaseFlowFrac >= 0.0f && useBaseFlowFrac <= 1.0f )
		baseFlowFraction = useBaseFlowFrac;
	Assert (useStormFlowFrac >= 0.0f);
	Assert (useStormFlowFrac <= 1.0f);
	if ( useStormFlowFrac >= 0.0f && useStormFlowFrac <= 1.0f )
		stormFlowFraction = useStormFlowFrac;
}

//	ApplyWaterToSurface
//	Implements a bucket model approach to water flow.
void TCenturySoil::ApplyWaterToSurface (
	float const amount)
{
	//--- error checks
	Assert (amount > 0.0f);
	Assert (thickness.size() > 0);
	if ( amount <= 0.0f ||
	     thickness.size() == 0 )
		return;

#ifdef DBG_CENTURY_SOIL
	DEBUG_DumpSoil ("ApplyWaterToSurface() start");
	dbg_SoilLayer1Thickness = thickness[0];
	dbg_SimTime = dynamic_cast<CENTURY_TYPE const &>(owner).GetSimTime()->time;
#endif

	//--- bucket model
	// layer index = 0, then add h20 from surface input;
	// layer index > 0, add spillover from layer above
	float availableH2O = amount;
	for ( size_type i = 0;
	      i < GetLayerCount() && availableH2O > 0.0f;
	      ++i )
	{
	    float addThisH2O;
	    float const layerFldCap = thickness[i] * FieldCapacity(i);
	    if ( layerFldCap - WaterContent(i) > availableH2O )
	    {
		addThisH2O = availableH2O;
		availableH2O = 0.0f;
	    }
	    else // have more than layer can take up
	    {
		addThisH2O = layerFldCap - WaterContent(i);  // layer now full
		// spillover execess water to next layer
		availableH2O -= addThisH2O;		// amount drained
		amtTrans(i) += availableH2O;		// cum. amount drained
	    }
	    WaterContent(i) += addThisH2O;		// Add water to layer
	}

	// stormflow out of the bottom layer
	float const newStormFlow = availableH2O * stormFlowFraction;

	// Put water draining out bottom that doesn't go to stormflow
	// into deep soil storage:
	float newDeepStore = availableH2O - newStormFlow;
	Assert (newDeepStore >= 0.0f);

	// Drain baseflow fraction from deep soil storage
	float const newBaseFlow = newDeepStore * baseFlowFraction;
	newDeepStore -= newBaseFlow;

	// save in accumulators
	baseFlow += newBaseFlow;
	stormFlow += newStormFlow;
	deepSoilStore += newDeepStore;

#ifdef DBG_CENTURY_SOIL
	DEBUG_DumpSoil ("ApplyWaterToSurface() end");
	dbg_SoilLayer1Thickness = thickness[0];
#endif
}

//	GetPlantExtractableWCF
//	Plant-extractable water content fraction for layer.
//	Definition:
//	available extractable water / maximum potential extractable water
float TCenturySoil::GetPlantExtractableWCF (
	size_type const layerIndex)
{
	// error checks
	Assert ( layerIndex < GetLayerCount() );

	float wcf = 0.0f;
	wcf = ( WaterContent(layerIndex) / thickness[layerIndex] -
				WiltingPoint(layerIndex) ) /
		( FieldCapacity(layerIndex) - WiltingPoint(layerIndex) );
	wcf = std::max (0.0f, wcf);
	wcf = std::min (wcf, 1.0f);
	return wcf;
}

float TCenturySoil::GetPlantExtractableWCF (	// Get plant-extractable H2O
	float const topDepth,			//   top depth of range
	float const bottomDepth)		//   bottom depth of range
{
	// error checks
	Assert ( topDepth >= 0.0f );
	Assert ( topDepth < bottomDepth );
	Assert ( bottomDepth > 0.0f );
	Assert ( bottomDepth <= depth[BottomLayer()] );

	// calc the quantity
	TSoilPool aPool ( thickness.size() );
	TFloatArray::iterator v = aPool.Values().begin();
	TFloatArray::const_iterator wc = WaterContent().Values().begin();
	TFloatArray::const_iterator fc = FieldCapacity().Values().begin();
	TFloatArray::const_iterator wp = WiltingPoint().Values().begin();
	TFloatArray::const_iterator t = thickness.begin();
	while ( v != aPool.Values().end() )
	{
		*v = ( *wc / *t - * wp ) / ( *fc - *wp );
		++v, ++wc, ++fc, ++wp, ++t;
	}
	return aPool.Quantity (topDepth, bottomDepth, depth, thickness);
}

//	FieldCapacityQuantity
//	Field capacity amount (cm) summed over the depths specified.
// 	Field capacity amount of a layer is defined to be
//		field capacity * thickness
float TCenturySoil::FieldCapacityQuantity (
	float const topDepth, 		// depth to top of layer (cm)
	float const bottomDepth)	// depth to bottom of layer (cm)
{
	// error checks
	Assert ( topDepth >= 0.0f );
	Assert ( topDepth < bottomDepth );
	Assert ( bottomDepth > 0.0f );
	Assert ( bottomDepth <= depth[BottomLayer()] );

	// calc the quantity
	TSoilPool aPool ( thickness.size() );
	TFloatArray::iterator v = aPool.Values().begin();
	TFloatArray::const_iterator f = FieldCapacity().Values().begin();
	TFloatArray::const_iterator t = thickness.begin();
	while ( v != aPool.Values().end() )
	{
		*v = *f * *t;
		++v, ++f, ++t;
	}
	return aPool.Quantity (topDepth, bottomDepth, depth, thickness);
}

//	FieldCapacityQuantity
//	Field capacity amount (cm) summed over the layers specified.
// 	Field capacity amount of a layer is defined to be
//		field capacity * thickness
float TCenturySoil::FieldCapacityQuantity (
	size_type const topLayer, 	// index of top of layer
	size_type const bottomLayer)	// index of bottom of layer
{
	// error checks
	Assert ( topLayer <= bottomLayer );
	Assert ( bottomLayer <= BottomLayer() );

	TFloatArray values ( bottomLayer - topLayer + 1 );
	TFloatArray::iterator v = values.begin();
	TFloatArray::const_iterator f =
		FieldCapacity().Values().begin() + topLayer;
	TFloatArray::const_iterator t = thickness.begin() + topLayer;
	while ( v != values.end() )
	{
		*v = *f * *t;
		++v, ++f, ++t;
	}
	return std::accumulate (values.begin(), values.end(),  0.0f);
}

//	MeanPlantWaterCapacity
// 	Returns mean water capacity summed over the depths specified.
// 	Plant-extractable capacity is defined to be
//		field capacity - wilting point
//	and is a property, not an amount.
float TCenturySoil::MeanPlantWaterCapacity (
	float const topDepth, 	// depth to top of layer (cm)
	float const bottomDepth)	// depth to bottom of layer (cm)
{
	// error checks
	Assert ( topDepth >= 0.0f );
	Assert ( topDepth < bottomDepth );
	Assert ( bottomDepth > 0.0f );
	Assert ( bottomDepth <= depth[BottomLayer()] );

	// calc the quantity
	TSoilProperty aProperty ( thickness.size() );
	TFloatArray::iterator v = aProperty.Values().begin();
	TFloatArray::const_iterator f = FieldCapacity().Values().begin();
	TFloatArray::const_iterator w = WiltingPoint().Values().begin();
	while ( v != aProperty.Values().end() )
	{
		*v = *f - *w;
		++v, ++f, ++w;
	}
	return aProperty.WtdMean (topDepth, bottomDepth, depth, thickness);
}

//	MeanPlantWaterCapacity
// 	Returns mean water capacity summed over the layers specified.
// 	Plant-extractable capacity is defined to be
//		field capacity - wilting point
//	and is a property, not an amount.
float TCenturySoil::MeanPlantWaterCapacity (
	size_type const topLayer, 		// index of top of layer
	size_type const bottomLayer)		// index of bottom of layer
{
	// error checks
	Assert ( topLayer <= bottomLayer );
	Assert ( bottomLayer <= BottomLayer() );

	TFloatArray values ( bottomLayer - topLayer + 1 );
	TFloatArray::iterator v = values.begin();
	TFloatArray::const_iterator f =
		FieldCapacity().Values().begin() + topLayer;
	TFloatArray::const_iterator w =
		WiltingPoint().Values().begin() + topLayer;
	while ( v != values.end() )
	{
		*v = *f - *w;
		++v, ++f, ++w;
	}
	return std::accumulate (values.begin(), values.end(),  0.0f) /
	       std::accumulate (thickness.begin() + topLayer,
				thickness.begin() + bottomLayer + 1, 0.0f);
}

//	PlantWaterCapacityAmt
// 	Returns water capacity (cm) summed over the depths specified.
// 	Plant-extractable capacity of a layer is defined to be
//		(field capacity - wilting point) * thickness
//	and is an estimate of the amount of plant-available water that can
//	be stored over the depth range.
float TCenturySoil::PlantWaterCapacityAmt (
	float const topDepth, 		// depth to top of layer (cm)
	float const bottomDepth)	// depth to bottom of layer (cm)
{
	// error checks
	Assert ( topDepth >= 0.0f );
	Assert ( topDepth < bottomDepth );
	Assert ( bottomDepth > 0.0f );
	Assert ( bottomDepth <= depth[BottomLayer()] );

	// calc the quantity
	TSoilPool aPool ( thickness.size() );
	TFloatArray::iterator v = aPool.Values().begin();
	TFloatArray::const_iterator f = FieldCapacity().Values().begin();
	TFloatArray::const_iterator w = WiltingPoint().Values().begin();
	TFloatArray::const_iterator t = thickness.begin();
	while ( v != aPool.Values().end() )
	{
		*v = (*f - *w) * *t;
		++v, ++f, ++w, ++t;
	}
	return aPool.Quantity (topDepth, bottomDepth, depth, thickness);
}

//	PlantWaterCapacityAmt
// 	Returns water capacity (cm) summed over the layers specified.
// 	Plant-extractable capacity of a layer is defined to be
//		(field capacity - wilting point) * thickness
//	and is an estimate of the amount of plant-available water that can
//	be stored over the depth range.
float TCenturySoil::PlantWaterCapacityAmt (
	size_type const topLayer, 		// index of top of layer
	size_type const bottomLayer)		// index of bottom of layer
{
	// error checks
	Assert ( topLayer <= bottomLayer );
	Assert ( bottomLayer <= BottomLayer() );

	TFloatArray values ( bottomLayer - topLayer + 1 );
	TFloatArray::iterator v = values.begin();
	TFloatArray::const_iterator f =
		FieldCapacity().Values().begin() + topLayer;
	TFloatArray::const_iterator w =
		WiltingPoint().Values().begin() + topLayer;
	TFloatArray::const_iterator t = thickness.begin() + topLayer;
	while ( v != values.end() )
	{
		*v = (*f - *w) * *t;
		++v, ++f, ++w, ++t;
	}
	return std::accumulate (values.begin(), values.end(),  0.0f);
}

//	PlantExtractableWater
//	Plant-extractable water content for the depth range (cm H2O).
//	Definition:
//		water content - wilting point water content (w.p. * thickness)
float TCenturySoil::PlantExtractableWater (
	float const topDepth, 		// depth to range top (cm)
	float const bottomDepth)	// depth to range bottom (cm)
{
	// error checks
	Assert ( topDepth >= 0.0f );
	Assert ( topDepth < bottomDepth );
	Assert ( bottomDepth > 0.0f );
	Assert ( bottomDepth <= depth[BottomLayer()] );

	// calc the quantity
	TSoilPool aPool ( thickness.size() );
	TSoilPool::iterator v = aPool.Values().begin();
	TFloatArray::const_iterator c = WaterContent().Values().begin();
	TFloatArray::const_iterator w = WiltingPoint().Values().begin();
	TFloatArray::const_iterator t = thickness.begin();
	// use 2 loops for optimization
	while ( v != aPool.Values().end() )
	{
		*v = *c - (*w * *t);
		++v, ++c, ++w, ++t;
	}
	v = aPool.Values().begin();
	while ( v != aPool.Values().end() )
	{
		*v = std::max (0.0f, *v);
		++v;
	}
	return aPool.Quantity (topDepth, bottomDepth, depth, thickness);
}

//	PlantExtractableWater
//	Plant-extractable water content for the layers range (cm H2O).
//	Definition:
//		water content - wilting point water content (w.p. * thickness)
float TCenturySoil::PlantExtractableWater (
	size_type const topLayer, 		// index of top of layer
	size_type const bottomLayer)		// index of bottom of layer
{
	// error checks
	Assert ( topLayer <= bottomLayer );
	Assert ( bottomLayer <= BottomLayer() );

	// trival case
	if ( topLayer == bottomLayer )
	    return std::max (
	    	0.0f,
	    	WaterContent().Values()[topLayer] -
		  WiltingPoint().Values()[topLayer] * thickness[topLayer] );

	TFloatArray values ( bottomLayer - topLayer + 1 );
	TFloatArray::iterator v = values.begin();
	TFloatArray::const_iterator c =
		WaterContent().Values().begin() + topLayer;
	TFloatArray::const_iterator w =
		WiltingPoint().Values().begin() + topLayer;
	TFloatArray::const_iterator t = thickness.begin() + topLayer;
	// use 2 loops for optimization
	while ( v != values.end() )
	{
		*v = *c - (*w * *t);
		++v, ++c, ++w, ++t;
	}
	v = values.begin();
	while ( v != values.end() )
	{
		*v = std::max (0.0f, *v);
		++v;
	}
	return std::accumulate (values.begin(), values.end(),  0.0f);
}

// ----------------------------------------------------------------------------
//	public functions - Geometric C depth distribution submodel
// ----------------------------------------------------------------------------

//	GeometricOMPC
//	Calculates the organic matter percent for each layer, using a
//	geometric decrease with depth.
//	Each layer has 0.85 of OM of the layer above.
//	Originally this was in Century's prelim.f function.
void TCenturySoil::GeometricOMPC (
	float const totalC)	// C in top layer (somsc in Century) g m-2
{
#ifdef DBG_CENTURY_SOIL
//	DEBUG_DumpSoil ("GeometricOMPC() start");
//	dbg_SoilLayer1Thickness = thickness[0];
#endif

	if ( GetLayerCount() <= 0 )
	{
		lastError = NSSoilErrors::BadLayerCount;
		return;
	}

    	// organic matter weight percent of simulation layer
    	//   = C (g m-2) / soil mass per unit area (g/m^2) * 100 * 1.724
    	// where
    	//   mass per unit area (g/m^2) =
    	//	bulk density (g/cm^3) * thickness (cm) * 10000 cm^2/m^2
    	// and
    	//   SOM (wt %) = 1.724 * SOC (wt %)
    	// Note: surface OC conversion factor may be better if ~1.9.
    	// Full version:
    	//   ompc = soilC.somsc / (soil.bulkDen * wt.simDepth * 10000.0)
    	//		* 1.724 * 100;
	float newOmpc = Cgm2ToOmwp (totalC, thickness[0], BulkDensity(0));
	TFloatArray::iterator iOmpc = OMPC().Values().begin();
	for ( size_type layer = 0;
	      layer < GetLayerCount();
	      ++layer, ++iOmpc )
	{
		*iOmpc = newOmpc;
		newOmpc *= ompcGeomFactor;	// each layer decreases OM 15%
	}

#ifdef DBG_CENTURY_SOIL
//	DEBUG_DumpSoil ("GeometricOMPC() end");
//	dbg_SoilLayer1Thickness = thickness[0];
#endif
}

// ----------------------------------------------------------------------------
//	public functions - Exponential C depth distribution submodel
// ----------------------------------------------------------------------------

//	ExponentialOMPC
//	Calc OMPC exponential distribution using a modified form of
//	the Rosenbloom (1998) exponential depth distribution of C.
void TCenturySoil::ExponentialOMPC (
	float const cSimLayer,		// simulation layer C (g m-2)
	float const cLowerLayer,	// lower layer C (g m-2)
	float const simThickness,	// simulation layer thickness (cm)
	float const llThickness)	// lower layer thickness (cm)
{
	//--- Error checks
	Assert (cSimLayer > 0.0f);
	Assert (cLowerLayer > 0.0f);
	Assert (simThickness > 0.0f);
	Assert (llThickness > 0.0f);

#ifdef DBG_CENTURY_SOIL
//	DEBUG_DumpSoil ("ExponentialOMPC() start");
//	dbg_SoilLayer1Thickness = thickness[0];
#endif

	//--- convert C units from g m-2 to g cm-2
	float cTopAmount = cSimLayer * NSUnits_m2cm2;
	float cBottomAmount = cLowerLayer * NSUnits_m2cm2;
	cProfileTotal = cTopAmount + cBottomAmount;
	if ( cTopAmount < 1.0e-3f )			// anything there?
		return;

	//--- calc C density of simulation and lower layers (g cm-3)
	cTopDensity = cTopAmount / simThickness;
	cBottomDensity = cBottomAmount / llThickness;
	if ( !AmountIsSignificant((cTopDensity - cBottomDensity), 1.0e-3f) )
		return;

	//--- find the roots
	TSoilCDistribution cDist (
		SoilDepth(), cProfileTotal, cTopDensity, cBottomDensity);
	float newK, newC0, newCb;
	if ( cDist.GetDistribution (newK, newC0, newCb) )	// failed?
	{
		lastError = (NSSoilErrors::Values)NSSoilErrors::NoSolutionC;
		return;
	}
	float const newCSum = cDist.CProfileSum();	// new profile C
	float const changeTolerance = 0.10f;
	if ( std::fabs (newCSum - cProfileTotal) >
	     changeTolerance * cProfileTotal )		// bad?
	{
	    lastError = (NSSoilErrors::Values)NSSoilErrors::BadSolutionC;
	    return;
	}
	else	// acceptable solution
	{
		// save new distribution parameters
		k = newK;
		cTopDensity = newC0;
		cBottomDensity = newCb;
		// add new C values to OMPC array
		OMPC().Values().resize ( depth.size() );
		TFloatArray::iterator c = OMPC().Values().begin();
		TFloatArray::const_iterator t = thickness.begin();
		TFloatArray::const_iterator d = depth.begin();
		TFloatArray::const_iterator bd = BulkDensity().Values().begin();
		float previousDepth = 0.0f;
		while ( d != depth.end() )
		{
		    Assert (*d > 0.0f);
		    Assert (*t > 0.0f);
		    // Calculate the organic matter weight percent
		    // of layer (g OM / g Soil * 100)
		    //    = C content (g cm-2) / thickness (cm) /
		    //      bulk density (g cm-3) *
		    //      1.724 * 100 precent
		    *c = Cgcm2ToOmwp (
		    		cDist.LayerAmt (previousDepth, *d), *t, *bd);
		    Assert (*c >= 0.0f);
		    // next layer
		    previousDepth = *d;
		    ++c, ++t, ++d, ++bd;
		}
	}

#ifdef DBG_CENTURY_SOIL
//	DEBUG_DumpSoil ("ExponentialOMPC() end");
//	dbg_SoilLayer1Thickness = thickness[0];
#endif
}

//	GetExpDistribution
//	Retrieves the parameters of the distribution.
//	Returns false if no error else true if an error occurred.
bool TCenturySoil::GetExpDistribution (
	float& newK,	     	//   K (cm-1)
	float& newCTopDen,   	//   C density at surface (g cm-3)
	float& newCBottomDen)	//   C density at bottom (g cm-3)
{
	bool retVal = false;
	if ( lastError == NSSoilErrors::NoError)
	{
		newK = k;
		newCTopDen = cTopDensity;
		newCBottomDen = cBottomDensity;
	}
	else
		retVal = true;
	return retVal;
}

//	GetCDensity
//	Get the C density (g cm-3)
float TCenturySoil::GetCDensity (
	size_type const layer)		// in this layer index
{
#ifdef DBG_CENTURY_SOIL
//	DEBUG_DumpSoil ("GetCDensity() start");
//	dbg_SoilLayer1Thickness = thickness[0];
#endif

	float result = 0.0f;
	if ( layer < BottomLayer() )
		result = minimalCDist->CDensity (depth[layer], k,
						cTopDensity, cBottomDensity);

#ifdef DBG_CENTURY_SOIL
//	DEBUG_DumpSoil ("GetCDensity() end");
//	dbg_SoilLayer1Thickness = thickness[0];
#endif

	return result;
}

// ----------------------------------------------------------------------------
//	public functions - Misc. C content functions
// ----------------------------------------------------------------------------

//	UpdateBulkDensityFromC
//	Update the bulk density of every layer in the soil
//	from new organic C content.
void TCenturySoil::UpdateBulkDensityFromC ()
{
	// To Do: CenturySoil::UpdateBulkDensityFromC
	// currently done in TCenturyBase::EndOfYearTasks
}

// ----------------------------------------------------------------------------
//	public functions - set values
// ----------------------------------------------------------------------------

//	SetNumLayers
//	Set number of layers for member arrays.
//	Does NOT affect component number of layers.
//	Returns false upon success, else true if error.
void TCenturySoil::SetNumLayers (
	size_type const useNumLayers)
{
	// allocate memory for layer arrays
	Assert (useNumLayers > 0);
	amtTrans.resize ( useNumLayers );
	amtTrans = 0.0f;
}

//	UseThicknesses
//	Set thicknesses of layers.
//	Returns false upon success, else true if error.
bool TCenturySoil::UseThicknesses (
	TFloatArray const & useThicknesses) // container of values
{
	bool const failed = TSoilBase::UseThicknesses (useThicknesses);
	if ( !failed )
	{
		minimalCDist.reset ( new TSoilCDistribution ( SoilDepth() ) );
	}
	Assert (failed == false);
	return failed;
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Initialize
//	initialize members
void TCenturySoil::Initialize ()
{
	lastError = NSSoilErrors::NoError;
	baseFlowFraction = stormFlowFraction = 0.0f;
	baseFlow = stormFlow = deepSoilStore = 0.0f;
	k = cProfileTotal = cTopDensity = cBottomDensity = 0.0f;
	if ( SoilDepth() > 0 )
		minimalCDist.reset ( new TSoilCDistribution ( SoilDepth() ) );
	else
		minimalCDist.reset ();

#ifdef DBG_CENTURY_SOIL
	dbgOFS.open (soilDebugFileName);
	dbgOFS << "\"time\",";
	dbgOFS	<< "\"nlaypg\","
		<< "\"root depth\",";
//		<< "\"depth[] size\","
//		<< "\"thickness[] size\","
//		<< "\"BulkDensity[] size\","
//		<< "\"WaterContent[] size\","
//		<< "\"OMPC[] size\",";
	for (short i = 0; i < 10; ++i)
		dbgOFS << "\"thickness[" << i << "]\",";
	for (short i = 0; i < 10; ++i)
		dbgOFS << "\"water[" << i << "]\",";
	for (short i = 0; i < 10; ++i)
		dbgOFS << "\"PltExH2O[[" << i << "]\",";
	dbgOFS	<< "\"Called From\"" << std::endl;
	dbg_nlaypg = 0;
	dbg_rootDepth = 0.0f;
#endif
}

//	Copy
// 	copy to this
void TCenturySoil::Copy (
	const TCenturySoil& fromObj)
{
	if ( &fromObj && fromObj.GetLayerCount() > 0 )
	{
		amtTrans = fromObj.amtTrans;
		baseFlowFraction = fromObj.baseFlowFraction;
		stormFlowFraction = fromObj.stormFlowFraction;
		deepSoilStore = fromObj.deepSoilStore;
		baseFlow = fromObj.baseFlow;
		stormFlow = fromObj.stormFlow;
		cProfileTotal = fromObj.cProfileTotal;
		k = fromObj.k;
		cTopDensity = fromObj.cTopDensity;
		cBottomDensity = fromObj.cBottomDensity;
	}
}

#ifdef DBG_CENTURY_SOIL

void TCenturySoil::DEBUG_DumpSoil (char const * const calledFrom)
{
	CENTURY_TYPE const & century =
		dynamic_cast<CENTURY_TYPE const &>(owner);
	dbgOFS << century.GetSimTime()->time << ',';
	dbgOFS	<< '\"' << dbg_nlaypg << "\","
		<< '\"' << dbg_rootDepth << "\",";
//		<< '\"' << depth.size() << "\","
//		<< '\"' << thickness.size() << "\","
//		<< '\"' << BulkDensity().Values().size() << "\","
//		<< '\"' << WaterContent().Values().size() << "\","
//		<< '\"' << OMPC().Values().size() << "\",";

	// thickness
	short i;
	short const limit = thickness.size();
	for (i = 0; i < limit; ++i)
		dbgOFS << thickness[i] << ',';
	for (i = 0; i < limit; ++i)
	    if ( limit < 10 )
	    {
		for (i = limit; i < 10; ++i)
			dbgOFS << 0.0f << ',';
	    }
	// water content
	for (i = 0; i < limit; ++i)
		dbgOFS << WaterContent(i) << ',';
	for (i = 0; i < limit; ++i)
	    if ( limit < 10 )
	    {
		for (i = limit; i < 10; ++i)
			dbgOFS << 0.0f << ',';
	    }

	// plant-extractable water
	for (i = 0; i < limit; ++i)
		dbgOFS << ( WaterContent(i) - (WiltingPoint(i) * thickness[i]) )
		       << ',';
	for (i = 0; i < limit; ++i)
	    if ( limit < 10 )
	    {
		for (i = limit; i < 10; ++i)
			dbgOFS << 0.0f << ',';
	    }

	dbgOFS	<< '\"' << calledFrom << '\"' << std::endl;
}

#endif

//--- end of definitions for TCenturySoil ---

