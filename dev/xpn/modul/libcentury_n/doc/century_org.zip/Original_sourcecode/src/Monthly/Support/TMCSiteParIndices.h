#ifndef INC_TMCSiteParIndices_h
#define INC_TMCSiteParIndices_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model, monthly version
//	File:	  TMCSiteParIndices.h
//	Class:	  TMCSiteParIndices
//
//	Description:
//	Indices to site parameter values and descriptions.
//
//	Responsibilities:
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu 	Nov04
//	History:
//	* Extracted this from TMCSiteParameters in order for the indices
//	  to be shared between classes, and instantiated separate from the
//	  parameters and descriptions classes.
// ----------------------------------------------------------------------------

#include "SiteParamIndicesBase.h"

struct TMCSiteParIndices
	: public ::nrel::site::SiteParamIndicesBase
{
    // ------------------------------------------------------------------------
    //	TSiteParamIndex
    //	Indices to values and start of the arrays of parameters in the
    //	parameter arrays.
    //	These are used to index the values, names, and definitions.
    enum TSiteParamIndex
    {
	// 1. climate		-----------------------------------------------
	SPI_precip = 0,		// mean monthly precipitation
	SPI_prcstd = 12,	// standard deviations of precipitation
	SPI_prcskw = 24,	// skewness value of precipitation
	SPI_tmn2m = 36,		// min. temperature at 2 meters (deg C)
	SPI_tmx2m = 48,		// max. temperature at 2 meters (deg C)
	// 2. soil and physical	-----------------------------------------------
	SPI_ivauto = 60,	// tag: Burke's eqs. to init. soil C
	SPI_nelem,		// tag: elements (besides C) to sim.
	SPI_sitlat,		// site latitude (deg)
	SPI_sitlng,		// site longitude (deg)
	SPI_sand,		// fraction of sand (10)
	SPI_silt = 74,		// fraction of silt (10)
	SPI_clay = 84,		// fraction of clay (10)
	SPI_bulkd = 94,		// bulk density (kg/liter) (10)
	SPI_thick = 104,	// layer thickness (cm) (10)
	SPI_nlayer = 114,	// number of soil layers in water model
	SPI_nlaypg,		// no. layers in top level- water model
	SPI_drain,		// fraction of excess water drained
	SPI_basef,		// fraction of soil water lost in base flow
	SPI_stormf,		// fraction of flow lost via base flow
	//SPI_infmin,		// Infiltration minimum (inches) of total water
				//    --- SPI_runfrac is no longer used ---
	//SPI_runfrac,		// Fraction of applied water which to runoff
				//    --- SPI_infmin is no longer used ---
	SPI_runoff,		// Runoff equation coefficients (3)
	SPI_swflag = 122,	// tag: src. of awilt, afield values
	SPI_awilt,		// wilting point of soil layers  (10)
	SPI_afiel = 133,	// field capacity of soil layers  (10)
	SPI_ph = 143,		// soil pH
	SPI_pslsrb,		// slope term for labile mineral P
	SPI_sorpmx,		// maximum P sorption potential
	// 3. external nutrients ----------------------------------------------
	SPI_epnfa = 146,	// intercept/slope: precip/atmos N fixation.
	SPI_epnfs = 148,	// intercept/slope: precip/soil N fixation.
	SPI_satmos = 150,	// intercept/slope: atmos. S input.
	SPI_sirri = 152,	// S in irrigation water (mg/l).
	// 4. initial organic matter ------------------------------------------
	SPI_som1ci = 153,		// C - fast turnover rate
	SPI_som2ci = 157,	// C - intermediate turnover
	SPI_som3ci = 159,	// C - slow turnover rate
	SPI_rces1 = 161,	// C/N, C/P, C/S - fast rate, surface and soil
	SPI_rces2 = 167,	// C/N, C/P, C/S - intermed. rate
	SPI_rces3 = 170,	// C/N, C/P, C/S - slow rate
	SPI_clittr = 173,	// C for plant residue
	SPI_rcelit = 177,	// C/N, C/P, C/S - litter
	SPI_aglcis = 183,	// aboveground live C (g/m2)
	SPI_aglive = 185,	// aboveground live N, P, S (g/m2)
	SPI_bgcis = 188,	// belowground live C (g/m2)
	SPI_bglive = 190,	// belowground live N, P, S (g/m2)
	SPI_stdcis = 193,	// standing dead C (g/m2)
	SPI_stdede = 195,	// standing dead N, P, S (g/m2)
	// 5. initial forest organic matter -----------------------------------
	SPI_rlvcis = 198,	// C in leaf component (g/m2) (2)
	SPI_rleave = 200,	// N, P, S in leaf component (g/m2) (3)
	SPI_fbrcis = 203,	// C in fine branch component (g/m2) (2)
	SPI_fbrche = 205,	// N, P, S in fine branch comp. (g/m2) (3)
	SPI_rlwcis = 208,	// C in large wood component (g/m2) (2)
	SPI_rlwode = 210,	// N, P, S in large wood comp. (g/m2) (3)
	SPI_frtcis = 213,	// C in fine root (2)
	SPI_froote = 215,	// N, P, S in fine root (3)
	SPI_crtcis = 218,	// C in coarse root  (2)
	SPI_croote = 220,	// N, P, S in coarse root (3)
	SPI_wd1cis = 223,	// C in dead fine wood (2)
	SPI_wd2cis = 225,	// C in dead large wood (2)
	SPI_wd3cis = 227,	// C in dead coarse root (2)
	// 6. initial mineral N, P, S -----------------------------------------
	SPI_minerl = 229,	// N, P, S in soil layers (g/m2) (3 x 10)
	SPI_parent = 259,	// N, P, S in parent material (g/m2) (3)
	SPI_secndy = 262,	// secondary N, P, S (g/m2) (3)
	SPI_occlud = 265,	// occluded P (g/m2)
	// 7. initial  water content ------------------------------------------
	SPI_rwcf = 266,		// relative water content - soil layers (10)
	SPI_snlq = 276,		// liquid water in snow pack (cm H2O)
	SPI_snow,		// snow pack water content (cm H2O)
	// 8. initial lower simulation soil horizon pools
	SPI_lhicu = 278,	// unlabeled C - active, slow, and passive (3)
	SPI_lhicl = 281,	// labeled C - active, slow, and passive (3)
	SPI_lhin = 284,		// N - active, slow, and passive (3)
	SPI_lhip = 287,		// P - active, slow, and passive (3)
	SPI_lhis = 290,		// S - active, slow, and passive (3)
	// 9. Erosion and Deposition
	SPI_eflcu = 293,	// fractions of eroded unlabeled C lost (5,2)
	SPI_eflcl = 303,	// fractions of eroded labeled C lost (5,2)
	SPI_efln = 313,		// fractions of eroded N lost (5,2)
	// all done!	-------------------------------------------------------
	SPI_EndOfList = 323	// last one, always!
    };

    // ------------------------------------------------------------------------
    //	TSiteParamSetIndex
    //	Indices to the array of parameter group indices setIndexList (below)
//    enum TSiteParamSetIndex
//    {
//	SPGI_Climate,		// 1. climate
//	SPGI_Soil,		// 2. soil and physical
//	SPGI_ExtNut,		// 3. external nutrients
//	SPGI_InitOrg,		// 4. initial organic matter
//	SPGI_ForOrg,		// 5. initial forest organic matter
//	SPGI_MinNPS,		// 6. initial mineral N, P, S
//	SPGI_Water,		// 7. initial relative water content
//	SPGI_LowerHor,		// 8. lower horizon initial pool amounts
//	SPGI_ErosDep,		// 9. Erosion and deposition
//	SPGI_EndOfList		// all done!
//    };

    // ------------------------------------------------------------------------
    // Array of indices to the start of each group of parameters
    typedef TSiteParamIndex TSiteParSetIndexList[ SPGI_EndOfList + 1 ];
    static TSiteParSetIndexList const setIndexList;

    // ------------------------------------------------------------------------
    //	siteSetCount
    // 	Size of each parameter set.
    //	The indices are zero-based.
    static short const siteSetCount[ /* GetSetCount() */ ];

    // ------------------------------------------------------------------------
    //	siteSetName
    //	Parameter group names (short and descriptive)
    static char const * const siteSetName[ /* GetSetCount() */ ];

    // ------------------------------------------------------------------------
    static inline short GetSetCount ()		// number of parameter sets
      { return SPGI_EndOfList; }

};

#endif // INC_TMCSiteParIndices_h

