#ifndef INC_TPlantSystemType
#define INC_TPlantSystemType

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TPlantSysType.h
//	Class:	  TPlantSystemType
//
//	Description:
//	Specifies type of plant system.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec00
// ----------------------------------------------------------------------------
//	History:
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added member Clear().
//	Jul02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added copy constructor.
// ----------------------------------------------------------------------------
//	Copyright 2000-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include <cstring>

//	-----------------------------------------------------------------------
//	TSystemType
//	Management system at start of simulation.
enum TSystemType
{
	SysType_Unknown = 0,	// Unknown system = error!
	SysType_CropGrass,	// Crop / Grassland
	SysType_Forest,		// Forest
	SysType_Savanna,	// Crop / Grassland and Forest
	SysType_EndOfList	// Should never have this = error!
};

//	-----------------------------------------------------------------------
//	TPlantSystemType
class TPlantSystemType
{
  public:
	//--- functions
	TPlantSystemType ()
	  { Initialize(); }
	virtual ~TPlantSystemType ()
	  { }
	TPlantSystemType (TPlantSystemType const & object)  // copy constructor
	  {
	    Copy (object);
	  }

	//---- operator overloads

	//---- functions - Queries
	bool IsCropGrass () const		// True if crop/grass system
	  { return system == SysType_CropGrass; }
	bool IsForest () const			// True if forest system
	  { return system == SysType_Forest; }
	bool IsSavanna () const			// True if savanna system
	  { return system == SysType_Savanna; }
	bool IsUnknown () const			// True if unknown system (!!!)
	  { return system == SysType_Unknown; }
	bool HaveCropGrass () const		// True if have a crop name
	  { return (*cropName &&
	  	    *cropName != ' '); }
	bool HaveTree () const			// True if have a crop name
	  { return (*treeName &&
	            *treeName != ' '); }
	int TypeAsIndex () const		// Return zero-based index
	  { return (system != SysType_Unknown ?
	  		(int)system - 1 : 0); }
	TSystemType & Type ()			// Set/get system type
	  { return system; }

	//---- functions - Change data
	TSystemType const & Type () const	// Get system type
	  { return system; }
	char* CropName ()			// Set/get crop name
	  { return &cropName[0]; }
	char const * const CropName () const	// Get crop name
	  { return &cropName[0]; }
	char* TreeName ()			// Set/get tree name
	  { return &treeName[0]; }
	char const * const TreeName () const	// Get tree name
	  { return &treeName[0]; }
	void Clear ()				// "Clear" data members
	  { Initialize (); }

  private:
	//--- data
	TSystemType system;		// current type of system
	char cropName[6];		// crop name (5 characters maximum)
	char treeName[6];		// tree name (5 characters maximum)

	//--- functions
	void Initialize ()
	  {
		system = SysType_Unknown;
	  	*cropName = *treeName = '\0';
	  }
	void Copy (TPlantSystemType const & object)	// Copy to this
	  {
	    if ( &object )
	    {
	    	system = object.system;
		std::strncpy (cropName, object.cropName, 6);
		std::strncpy (treeName, object.treeName, 6);
	    }
	  }
};

#endif // INC_TPlantSystemType
