// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TDeposit.cpp
//	Class:	  TDeposition
//
//	Description:
//	Class to perform deposition into Century's pools.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Mar99
// ----------------------------------------------------------------------------
//	History:
//	See header file.
// ----------------------------------------------------------------------------
//	Copyright 1999-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TDeposit.h"
#include "TNcFileErosion.h"
#include <cfloat>		// for FLT_MIN
using namespace std;

//--- constructors and destructor

TDeposition::TDeposition (
	TSite& useSite,			// use this site class instance
	TCenturySoil& useSoil,		// use this soil class instance
	TLowerSoil& useLwrSoil,		// use this lower soil pool instance
	TSoilC& useSoilC, 		// soil C output variable instance
	TNPS& useNPS,			// NPS output variable instance
	TWater& useWater,		// water parameters class
	TWaterTemp& useWT,		// water & temperature output class
	TFlow& useFlows,		// flow manager class instance
	short const useNumIso,		// number of isotopes
	short const useNumElem)		// number of elements
	: TDepEroBase ( useSite, useSoil, useLwrSoil, useSoilC, useNPS,
	  		useWater, useWT, useFlows, useNumIso, useNumElem)
{
}


//--- public functions

//	UseDepositionFile
// 	Specify a netCDF ile containing the amounts be deposited.
//	This file is created by TErosion.
//	Returns false if a valid file, else true if not or if error.
bool TDeposition::UseDepositionFile (
	char const * const filePath)	// full path with file name
{
	//--- error checks
	if( !filePath || !(*filePath) )			// anything there?
	{
		// To Do: invalid file path - need error handling
		return true;
	}

	//--- open the file for reading
	bool retVal = false;			// return value
	TEH::TFileName ncFileName (filePath);	// file name instance
	eoFile.reset ( new TNcErosionFile (ncFileName) );
	TNcErosionFile* const myEOFile =
		dynamic_cast<TNcErosionFile*>( eoFile.get() );
	if ( myEOFile == 0 || !myEOFile->IsValid() )
	{
		// To Do: invalid instance - need error handling
		eoFile.reset ();	// delete memory
		retVal = true;
	}
	return retVal;
}

//	Deposit
//	Do deposition.
//	Remember - no deposit, no return!
//	Returns a new layer containing the deposited material.
auto_ptr<TSoilLayer> TDeposition::Deposit (
	float const simTime)	// simulation time (year + fraction)
{
	//--- Get next deposition record for this simulation time
	register short size = EE_NumElements * EPT_NumPools;
	float	thickness,		// thickess deposited
		sand,			// fraction of sand-sized
		silt,			// fraction of silt-sized
		clay,			// fraction of clay-sized
		bulkDen;		// bulk density of material
	float* data = new float [size]; // data[EE_NumElements][EPT_NumPools]
	auto_ptr<TSoilLayer> newLayer = soil.NewLayerLike (0);
	if ( ReadNextEvent (simTime, thickness, bulkDen,
			    sand, silt, clay, data) )		// failed?
	{
		// TO DO: need error handling here
		delete [] data;
		return newLayer;
	}

	//--- Check input data for correctness

	//--- Add the material to the simulation layer
	// Note: These transfers are independent of those in SimToLowerLayer.
	SimLayerAdditions (simTime, data);

	//--- Transfer the C and element amounts into the lower layer pools.
	float amtC[sizeC]; 	// C transfer amounts (g m-2)
	float amtE[sizeE];	// N, P, S transfer amounts (g m-2)
	float totalC = 0.0f;	// total organic C (g m-2)
	for (short pool = EPT_Active; pool < EPT_NumPools; pool+=1)
	{
		for (short isotope = 0; isotope < ISOS; ++isotope)
		{
			amtC_ref(pool, isotope) = *data_ref(isotope, pool);
			totalC += amtC_ref(pool, isotope);
		}
	}
	delete [] data;					// clean up
	SimToLowerLayer (simTime, amtC, amtE);

	//--- Add material to soil
	//  	index	component	Where created:		Type:
	//	0	bulk density	ReadSiteParameters	property
	//	1	sand fraction	ReadSiteParameters	property
	//	2	silt fraction	ReadSiteParameters	property
	//	3	clay fraction	ReadSiteParameters	property
	//	4	wilting point	ReadSiteParameters	property
	//	5	field capacity	ReadSiteParameters 	property
	//	6	water content   ReadSiteParameters	pool
	//	7	SOM wt %	ReadSiteParameters 	property
	newLayer->Thickness() = thickness;
	newLayer->Component (0) = bulkDen;
	newLayer->Component (1) = sand;
	newLayer->Component (2) = silt;
	newLayer->Component (3) = clay;
	newLayer->Component (6) = soil.CompValue (0, 6);
	newLayer->Component (7) = soil.Cgm2ToOmwp (totalC, thickness, bulkDen);
	return newLayer;
}

//--- protected functions

//	ReadNextEvent
//	Get the next deposition event matching the specified time.
//	Returns false if successful at getting the next event, else
//	true if not successful.
//	If successful, "data" contains the data for the specified simulation
//	time, else "data" is returned unchanged.
bool TDeposition::ReadNextEvent (
	float const simTime,	// simulation time (year + fraction)
	float& thickness,	// thickness eroded
	float& bulkDen,		// bulk density of eroded thickness
	float& sand,		// fraction of sand-sized
	float& silt,		// fraction of silt-sized
	float& clay,		// fraction of clay-sized
	float*& data)		// data[EE_NumElements][EPT_NumPools]
{
	bool retVal = true;				// return value

	//--- error checks

	//--- get next dataset
	if ( eoFile.get() )				// deposition file?
	{
		float newSimTime = -FLT_MIN;
		short const size = EE_NumElements * EPT_NumPools;
		float inputData[size];
		float* pData = inputData;
		for ( short i = 0; i < size; ++i )		// init array
			*(pData++) = 0.0f;
		while ( newSimTime < simTime )
		    if ( dynamic_cast<TNcErosionFile*>(eoFile.get())->
		    	 ReadRecord ( newSimTime, thickness, bulkDen,
		    			sand, silt, clay, inputData) )
		    {
			// TO DO: need error handling
		    }
		if ( newSimTime == simTime )	// have data?
		{
			// transfer the data
			pData = data;
			float* pNewData = inputData;
			for ( short i = 0; i < size; ++i )
				*(pData++) = *(pNewData);
			retVal = false;
		}
	}
	return retVal;
}

//	SimLayerAdditions
//	Add material to simulation layer.
void TDeposition::SimLayerAdditions (
	float const simTime,		// simulation time (year + fraction)
	float const * const data)	// data[EE_NumElements][EPT_NumPools]
{
	short layer;		// Index to the soil layer
       	float* ciDest;		// SOM pool to which 13C/14C is added
       	float* eDest;		// SOM pool to which N,P,S is added

#define eDest_ref(a_1,a_2)	eDest[(a_2)*(layer) + a_1]
#define ciDest_ref(a_1,a_2)	ciDest[(a_2)*(layer) + a_1]

	// Initialize monthly output variables
	soilC.depC = 0.0;

	// for each pool...
	for (short pool = EPT_Active; pool < EPT_NumPools; pool+=1)
	{
		//--- initialize the pool variables
		switch ( pool )
		{
		  case EPT_Active:
		  	layer = SOIL;
		  	ciDest = soilC.som1ci;
			eDest = nps.som1e;
			break;
		  case EPT_Slow:
			layer= 0;
		  	ciDest = soilC.som2ci;
			eDest = nps.som2e;
		  	break;
		  case EPT_Passive:
			layer= 0;
		  	ciDest = soilC.som3ci;
			eDest = nps.som3e;
		  	break;
		  case EPT_Metabolic:
			layer = SOIL;
		  	ciDest = soilC.metcis;
			eDest = nps.metabe;
		  	break;
		  case EPT_Structural:
			layer = SOIL;
		  	ciDest = soilC.strcis;
		  	eDest = nps.struce;
		  	break;
		}

		//--- anything to do?
		register float sumC = *data_ref(UNLABL, pool) +
					*data_ref(LABELD, pool);
		// source large enough?
		if ( sumC < NSDepEro_poolMinThreshold )
			continue;		// ...no, to next pool

		//--- Amount of unlabeled and labeled C lost from current pool
		flows.Schedule (
			&soilC.csrsnk[UNLABL], &ciDest_ref (layer, UNLABL),
			simTime, *data_ref(UNLABL, pool) );
		flows.Schedule (
			&soilC.csrsnk[LABELD], &ciDest_ref (layer, LABELD),
			simTime, *data_ref(LABELD, pool) );

		//--- Amount of N, P, S lost from current pool
		// Loss for each element is based on element/C ratio
		for (short element = 0; element < numElem; ++element)
		    flows.Schedule (
			&nps.esrsnk[element], &eDest_ref (layer, element),
			simTime,
			*data_ref(EE_N + (TErosionElements)element, pool) );

		//--- Save deposited amounts in the output variables
		// Total C losses for this event
		soilC.depC += sumC;		// total C gained this event
		soilC.depCcum += sumC;		// cumulative total C gained
	}

#undef ciDest_ref
#undef eDest_ref
}

//	SimToLowerLayer
//	Do transfers to lower layer pools.
void TDeposition::SimToLowerLayer (
	float const simTime, 		// simulation time
	float const amtC[sizeC], 	// C transfer amounts (g m-2)
	float const amtE[sizeE])	// N, P, S transfer amounts (g m-2)
{
	for (short isotope = 0; isotope < ISOS; ++isotope)
	{
		flows.Schedule (			// active C pool
			&soilC.csrsnk[isotope], &som1ci_ref (SOIL, isotope),
			simTime, amtC_ref (ACTIVE, isotope));
		flows.Schedule (			// slow C pool
			&soilC.csrsnk[isotope], &soilC.som2ci[isotope],
			simTime, amtC_ref (SLOW, isotope));

		flows.Schedule (			// passive C pool
			&soilC.csrsnk[isotope], &soilC.som3ci[isotope],
			simTime, amtC_ref (PASSIVE, isotope));
	}
	for (short element = 0; element < numElem; ++element)
	{
		flows.Schedule (			// active C pool
			&nps.esrsnk[element], &som1e_ref (SOIL, element),
			simTime, amtE_ref (ACTIVE, element));
		flows.Schedule (			// slow C pool
			&nps.esrsnk[element], &nps.som2e[element],
			simTime, amtE_ref (SLOW, element));
		flows.Schedule (			// passive C pool
			&nps.esrsnk[element], &nps.som3e[element],
			simTime, amtE_ref (PASSIVE, element));
	}
}


//--- private functions


//--- End of file T_Deposit.cpp ---//
