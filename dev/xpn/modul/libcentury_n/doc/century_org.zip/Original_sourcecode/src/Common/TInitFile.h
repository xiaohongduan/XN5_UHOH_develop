#ifndef INC_TInitFile_h
#define INC_TInitFile_h

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TInitFile.h
//	Class:	  TInitFile
//
//	Description:
//      Class for read/write of initialization files.
//
//	Author: Sridhar Jillella, Jan98; Concept by Tom Hilinski.
// ----------------------------------------------------------------------------
//	History:
//	Modified: Tom Hilinski, Feb98
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* A bit of cleaning up and const-correctness.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Using this class:
//
//	INI files contain ASCII lines of the form:
//		name=value
//	where "name" and "value" are text strings.
//	Name is case-insensitive
//	Values are literals including everything between '=' and '\n'.
//
//	Create an instance specifying the INI file name, and pointers to two
//	lists (char**, null terminated). Then read or write the file using
//	the functions Read or Write. E.g.,
//		char **nameList = {"Name1", ..., NULL};	// list of names
//		char **valueList = NULL;		// list for values
//		char *iniFileNameStr = "test.ini";
//	 TEH::TFileName iniFileName (iniFileNameStr, TEH::TFileName::FT_Normal);
//		TInitFile iniFile (iniFileName, paramNameList, valueList);
//		short count = iniFile.Read ();		// read INI file
//		valueList = iniFile.GetValueList ();	// retrieve values
//		iniFile.Write ();			// write INI file
//
//	If the values list is null upon read, it is allocated memory when
//	a matching name is found in the INI file. The values list can be
//	obtained with the function GetValueList.
//
//	If the names list is null upon read, the names are read from the
//	INI file for any string containing > 0 chars to the left of '='.
//	Memory is allocated when the name string is assigned to the list.
//	The name list can be retrieved with the function GetNameList.
//
//	If the name list is char const**, the list is "read-only"; the names
//	in the "ini" file cannot be changed.
// ----------------------------------------------------------------------------

#include "TFileName.h"
#include <fstream>

class TInitFile
{
  public:
	//--- constructors and destructor
	TInitFile (
	  TEH::TFileName const & fileName);		// name of "ini" file
	TInitFile (
	  TEH::TFileName const & fileName,		// name of "ini" file
	  char** names,				// list of item names
	  char** &values);			// list of item values
	TInitFile (
	  TEH::TFileName const & fileName,		// name of "ini" file
	  char const** names,			// list of item names
	  char** &values);			// list of item values
	TInitFile (TInitFile const & obj)	// Copy constructor
	  {
	    Initialize();
	    Copy (obj);
	  }
	~TInitFile ();

	//--- operator overloads
	TInitFile& operator = (TInitFile const & obj)
	{ if (this != &obj)	// assignment to self?
	  {
		Clear ();
		Copy (obj);
	  }
	  return *this;
	}

	//--- Functions
	short Read (); 				// Reads from .ini file
	bool Write (); 				// Writes to .ini file.
	short GetCount () const  		// Get number of parameters
	  { return count; }
	bool SetFile (				// Change the "ini" file name
	  TEH::TFileName& newFile );
	TEH::TFileName& GetFile ()		// Get "ini" file name
	  { return initFile; }
	char const** GetNameList () const	// Pointer to list of names
	  {
	    return const_cast<char const**>
	  	(nameList);
	  }
	char** GetValueList () const		// Pointer to list of values
	  { return valueList; }
	char* GetValue (			// Get value at index
	  short const which) const
	  { return valueList[which]; }
	bool SetValue (				// Sets value at index.
	  short const which,
	  char const* value);
	bool SetValue (				// Sets value with param name
	  char const* param,
	  char const* value);
	char* GetValue (			// Get value with param name
	  char const* param) const;
	void SetModified (bool flag)		// Set the modified flag
	  { modified = flag; }
	bool IsModified () const		// True if data modified
	  { return modified; }
	 void Clear ();				// Clear member data

  private:
	//--- data
	TEH::TFileName initFile;			// Name of the INI file.
	char** nameList;			// array of name strings
	char** valueList;			// array of values strings
	short count;         			// Size of nameList, valueList
	bool modified;   			// True if values are changed.
	bool nameFromFile;			// true if names from INI file
	std::fstream fs;			// File stream for INI file.
	bool namesRO;				// read-only flag for name list

	//--- functions
	void Initialize ();   			// Initializes member data
	void Copy (TInitFile const & obj); 	// Copies to this.
	short CountValidLines ();		// counts file lines with "="
	void ClearNameList ();			// Deletes memory in nameList
	void ClearValueList ();			// Deletes memory in valueList
	void FlushSpaces (			// Deletes all spaces in string
	  char* & str);
	bool LineParse (			// Parses input line
	  char const * const line);
	short SaveNames (			// Copies names to list
	  char const** names);
	short SaveValues (			// Copies values to list
	  char** values);
};

#endif
