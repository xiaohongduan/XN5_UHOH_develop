#ifndef INC_CMI_version_h
#define INC_CMI_version_h
// ----------------------------------------------------------------------------
//	Copyright 2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  versionCMI.h
//	Class:	  TCMIApp
//
//	Description:
//	Monthly Century model version information.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Oct03
//	History:
// ----------------------------------------------------------------------------
//	Version macros defined here:
//	Macro:		Description:
//	--------------	-------------------------------
//	CMINickname	Short string name of model.
//	CMIName		String name of model.
//	CMIVersion	String version of version number.
//	CMIVersionLong	String version of model with "version" prefix.
// ----------------------------------------------------------------------------

#define CMICopyright	\
	"Copyright 1998-2005 Colorado State University. " \
	"All rights reserved.";


// For use in this file only - MODIFY WITH EACH VERSION INCREASE
// Format: n.n.n.n where each number is
// "major version number"."minor"."release"."build number"
// This should match the version numbers in the file "cmi.rc".
#define CMIVersion "5.4.7.4"

// use the following in code: CMIName
#define CMINickname	"CMI"
#define CMIName 	"Century Model Interface"
#ifdef NDEBUG
 #define CMIVersionLong 	"Version " CMIVersion " (" __DATE__ ")"
#else
 #define CMIVersionLong 	"Version " CMIVersion" (" __DATE__ ") DEBUG"
#endif

#include "systemdefs.h"

#endif // INC_CMI_version_h
