
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  resp_ncid;			/* netCDF id */

/* variable ids */
int  s11c2_id, s21c2_id, s2c2_id, s3c2_id, st1c2_id, st2c2_id, 
     mt1c2_id, mt2c2_id, wd1c2_id, wd2c2_id, wd3c2_id;

int
respdef(int *ntimes, char *history) {		/* create resp.nc */

   int status;

   /* dimension ids */
   int  time_dim = 0;
   int  cell_dim = 0;

   /* variable shapes */
   int dims[2];

   /* enter define mode */
   status = nc_create("resp.nc", NC_CLOBBER, &resp_ncid);
   if (status != NC_NOERR) handle_error("nc_create(resp.nc)", status);

   /* define dimensions */
   status = nc_def_dim(resp_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(resp_ncid, "cell", NC_UNLIMITED, &cell_dim);

   /* define variables */

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (resp_ncid, "s11c2", NC_FLOAT, 2, dims, &s11c2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (resp_ncid, "s21c2", NC_FLOAT, 2, dims, &s21c2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (resp_ncid, "s2c2", NC_FLOAT, 2, dims, &s2c2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (resp_ncid, "s3c2", NC_FLOAT, 2, dims, &s3c2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (resp_ncid, "st1c2", NC_FLOAT, 2, dims, &st1c2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (resp_ncid, "st2c2", NC_FLOAT, 2, dims, &st2c2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (resp_ncid, "mt1c2", NC_FLOAT, 2, dims, &mt1c2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (resp_ncid, "mt2c2", NC_FLOAT, 2, dims, &mt2c2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (resp_ncid, "wd1c2", NC_FLOAT, 2, dims, &wd1c2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (resp_ncid, "wd2c2", NC_FLOAT, 2, dims, &wd2c2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (resp_ncid, "wd3c2", NC_FLOAT, 2, dims, &wd3c2_id);

   /* assign attributes */
   status = nc_put_att_text (resp_ncid, NC_GLOBAL, "history", strlen(history), history);
   status = nc_put_att_text (resp_ncid, s11c2_id, "long_name", 
	strlen("surface_microbial_respiration"), "surface_microbial_respiration");
   status = nc_put_att_text (resp_ncid, s11c2_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (resp_ncid, s21c2_id, "long_name", 
	strlen("soil_microbial_respiration"), "soil_microbial_respiration");
   status = nc_put_att_text (resp_ncid, s21c2_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (resp_ncid, s2c2_id, "long_name", 
	strlen("som2_respiration"), "som2_respiration");
   status = nc_put_att_text (resp_ncid, s2c2_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (resp_ncid, s3c2_id, "long_name", 
	strlen("som3_respiration"), "som3_respiration");
   status = nc_put_att_text (resp_ncid, s3c2_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (resp_ncid, st1c2_id, "long_name", 
	strlen("surface_structural_respiration"), "surface_structural_respiration");
   status = nc_put_att_text (resp_ncid, st1c2_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (resp_ncid, st2c2_id, "long_name", 
	strlen("soil_structural_respiration"), "soil_structural_respiration");
   status = nc_put_att_text (resp_ncid, st2c2_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (resp_ncid, mt1c2_id, "long_name", 
	strlen("surface_metabolic_respiration"), "surface_metabolic_respiration");
   status = nc_put_att_text (resp_ncid, mt1c2_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (resp_ncid, mt2c2_id, "long_name", 
	strlen("soil_metabolic_respiration"), "soil_metabolic_respiration");
   status = nc_put_att_text (resp_ncid, mt2c2_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (resp_ncid, wd1c2_id, "long_name", 
	strlen("dead_fine_branch_respiration"), "dead_fine_branch_respiration");
   status = nc_put_att_text (resp_ncid, wd1c2_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (resp_ncid, wd2c2_id, "long_name", 
	strlen("dead_large_wood_respiration"), "dead_large_wood_respiration");
   status = nc_put_att_text (resp_ncid, wd2c2_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (resp_ncid, wd3c2_id, "long_name", 
	strlen("dead_coarse_roots_respiration"), "dead_coarse_roots_respiration");
   status = nc_put_att_text (resp_ncid, wd3c2_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   /* leave define mode */
   status = nc_enddef (resp_ncid);
   return 0;
}
