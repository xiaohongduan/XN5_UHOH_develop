
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include "netcdf.h"
#include "wrtcdf.h"

int
write_prod(float prod[][12])
{
        int status;
        float *p = (float *) prod;

	/* Write output to NetCDF file */
	status = nc_put_vara_float(prod_ncid, agcprd_id, start, count, p);
	status = nc_put_vara_float(prod_ncid, bgcprd_id, start, count, p + 12);
	status = nc_put_vara_float(prod_ncid, rlvprd_id, start, count, p + 24);
	status = nc_put_vara_float(prod_ncid, frtprd_id, start, count, p + 36);
	status = nc_put_vara_float(prod_ncid, fbrprd_id, start, count, p + 48);
	status = nc_put_vara_float(prod_ncid, rlwprd_id, start, count, p + 60);
	status = nc_put_vara_float(prod_ncid, crtprd_id, start, count, p + 72);

	/* Reset memory for variable prod */
	 memset(p, '\0', (sizeof(float) * 7 * 12));

	return 0;
}
