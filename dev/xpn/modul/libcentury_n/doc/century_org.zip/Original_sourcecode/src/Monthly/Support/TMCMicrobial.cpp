// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model (Monthly)
//	File:	  TMCMicrobial.cpp
//	Class:	  TMCMicrobial
//
//	Description:
//	Class for microbial decomposition submodel for monthly Century.
//	Members were extracted from class TCentury.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, April 2004
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TMCMicrobial.h"

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	Clone
//	Clone this
TMCMicrobial * const TMCMicrobial::Clone () const
{
	try
	{
		TMCMicrobial* const clone = new TMCMicrobial (*this);
		return clone;					// successful
	}
	catch (...)
	{
		return 0;					// failed
	}
}

//	Respiration
//	Compute flows associated with microbial respiration.
void TMCMicrobial::Respiration (
	float const co2Loss, 	// CO2 loss associated with decomposition
	short const numLayers,	// total number of layers modeled for Box A;
				//   =2 for structural, metabolic, som1;
				//   =1 for som2, som3, wood compartments.
				//   This is left dimension of the arrays
				//   cstatv, estatv, netMin.
	short const layer,  	// soil layer (values: SRFC, SOIL)
	float const * const tcstva,	// [numLayers]: C in each layer of Box A
	float* const cstatv,		// [numLayers,ISOS]: C in Box A
	float* const csrsnk,		// [ISOS]: C source/sink
	float* const respiration,	// respiration; array[2]
	float* const estatv,		// [numLayers,NUMELEM]: N,P,S for Box A
	float* const grossMin,		// [NUMELEM]: gross mineralization
	float* const netMin,		// [numLayers,NUMELEM]: net mineraliz.
	float const simDepth)		// simulation layer depth (cm)
{
#define cstatv_ref(a_1,a_2)	cstatv[(a_2)*(numLayers) + a_1]
#define estatv_ref(a_1,a_2)	estatv[(a_2)*(numLayers) + a_1]
#define netMin_ref(a_1,a_2)	netMin[(a_2)*(numLayers) + a_1]

    Assert (numLayers == 1 || numLayers == 2);
    Assert (layer == SRFC || layer == SOIL);
    Assert (layer < numLayers);

    // C flow from cstatv to CO2
    if (isotopeC == Lbl_13C)
	ScheduleCFlow ( simTime.time, co2Loss,
		cstatv_ref (layer, LABELD) / tcstva[layer], df13C,
		&cstatv_ref (layer, UNLABL), &csrsnk[UNLABL],
		&cstatv_ref (layer, LABELD), &csrsnk[LABELD],
		respiration );
    else
	ScheduleCFlow ( simTime.time, co2Loss,
		cstatv_ref (layer, LABELD) / tcstva[layer], 1.0f,
		&cstatv_ref (layer, UNLABL), &csrsnk[UNLABL],
		&cstatv_ref (layer, LABELD), &csrsnk[LABELD],
		respiration );

    // Mineralization associated with respiration
    for (short element = 0; element < numElem; ++element)
    {
    	// mineral flow
	float mineralFlow =
		co2Loss * estatv_ref (layer, element) / tcstva[layer];
	mineralFlow =
                dynamic_cast<TMCSoilFlows&>(soilFlows).FlowNPSintoMineralSoil (
			static_cast<TMineralElements>(element),
			&estatv_ref (layer, element),
			mineralFlow, simDepth );
	grossMin[element] += mineralFlow;		// Update
	netMin_ref (layer, element) += mineralFlow;	// Update
    }

#undef netMin_ref
#undef estatv_ref
#undef cstatv_ref
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------


//--- end of definitions for TMCMicrobial ---
