// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TDisGenDayCentIRC.cpp
//	Class:	  TDisGenDayCentIRC
//
//	Description:
//	Disturbance generator for DayCentIRC fire and agriculture.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, July 2002
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TDisGenDayCentIRC.h"
#include "TEvent.h"
#include "TCohort.h"
#include "TGridCell.h"
#include "TDisturbListFile.h"
#include "stringutil.h"
#include <fstream>
using namespace nrel::dcirc;

namespace {	// anonymous

char const * const plantSystemCStr[] =
	{ "Unknown", "crop/grass", "forest", "savanna" };

void AppendSystemTypeString (
	TDayCentModel & dayCentModel,
	std::string & msg)
{
	msg = ::plantSystemCStr[dayCentModel.GetModel().GetSystemType().Type()];
	msg += ' ';
	if ( dayCentModel.GetModel().GetSystemType().IsCropGrass() )
		msg += dayCentModel.GetModel().GetSystemType().CropName();
	else if ( dayCentModel.GetModel().GetSystemType().IsForest() )
		msg += dayCentModel.GetModel().GetSystemType().TreeName();
	else	// savanna
	{
		msg += dayCentModel.GetModel().GetSystemType().CropName();
		msg += " + ";
		msg += dayCentModel.GetModel().GetSystemType().TreeName();
	}
	msg += ": ";
}

} // namespace anonymous

//	Disturb
//	Disturb a cohort: fire.
//	Return true if cohort was disturbed, else false.
bool TDisGenDayCentIRC::Disturb (
	::nrel::gcf::TCohort * const cohort,	// this cohort
	TFireInfo & useFireInfo)	// fire information
{
	// first, can this cohort be disturbed?
	if ( cohort->GetAreaFraction() <
	     GetConfiguration().GetMinAreaFractionToDisturb() )
	{
		// too small an area, so skip it
		return false;
	}

	TTimeManager::TTime const timestamp =
		cohort->GetModel().GetTimer().GetTimeStep();

	if ( cohort->GetAge(timestamp) <
	     GetConfiguration().GetMinCohortAgeToDisturb() )
	{
		// cohort is too young, so skip it
		return false;
	}

	// Create a fire disturbance event
	// ... event key
	::nrel::gcf::TEventKey key (
		::nrel::gcf::TEventKey::Event_DivideCohort,
		timestamp);
	// ...event data
	::nrel::gcf::TEventData cohortEventData (cohort);
	::nrel::gcf::TEventData areaFractionEventData (percentToBurn);
	::nrel::gcf::TEventDataArray eventDataArray;
	eventDataArray.push_back (cohortEventData);
	eventDataArray.push_back (areaFractionEventData);
	// ...event
	::nrel::gcf::TEvent event ( make_pair( key, eventDataArray ) );
	// Process the event NOW!
	// Warning! this bypasses the event queue.
	// Send to the grid cell's event manager
	bool const success =
		!( cohort->GetOwner()->GetEventManager().ProcessEvent (event) );
	// write about event to the simulation output
	TDayCentModel & dayCentModel =
		dynamic_cast<TDayCentModel &>( cohort->GetModel() );
	std::string msg;
	::AppendSystemTypeString (dayCentModel, msg);
	if ( !success )  // failed?
	{
		msg += "FAILED fire disturbance";
	}
	else
	{
		msg += "Fire - cell fraction = ";
		msg += ::ToString (percentToBurn * cohort->GetAreaFraction());
	}
	dayCentModel.WriteEventToSim ( msg, cohort->GetID() );
	return success;
}

//	Initialize
void TDisGenDayCentIRC::Initialize ()
{
	if ( ReadConfiguration () ) // failed?
	{
		// To Do: handle ReadConfiguration failure
	}

	// read the disturbance list, if any
	if ( !mySimConfig.GetDisturbFileNameMap().empty() )
	{
	    /* To do: refactor so reads entire set of files

	    TDisturbListFile disturbListFile (
			disturbList,
			mySimConfig.GetDisturbanceFileName(),
			TDisturbListFile::Access_ReadOnly );
	    short const numRecords = disturbListFile.Read ();
	    if (numRecords == 0 )
	    {
		disturbList.clear();
	    }
	    else
	    {
		// Make sure all files have a path
		iDisturbList = disturbList.begin ();	// use member
		while ( iDisturbList != disturbList.end() )
		{
		    if ( !iDisturbList->IsComment() )
			TEH::PrependPathToFileIf (
				iDisturbList->mgmtFile,
				mySimConfig.GetInputPath() );
		    ++iDisturbList;
		}

		// Advance disturbance list pointer to first event
		iDisturbList = disturbList.begin ();
		while ( iDisturbList->IsComment() )
			++iDisturbList;
	    }
	    */
	}
}

//	ReadConfiguration
//	Configure the disturbance manager from a file.
//	Return false if successful, else true if failed or error.
bool TDisGenDayCentIRC::ReadConfiguration ()
{
	// hardwire configuration values for now
	percentToBurn = 0.25f;			// percent of area to burn
	// To Do: ReadConfiguration - read from file rather than hardwire
	return false;
}

//	ProcessDisturbanceList
//	Process any disturbances ready to trigger.
//	Return true if generated the disturbances, else false.
bool TDisGenDayCentIRC::ProcessDisturbanceList (
	::nrel::gcf::TCohort * const cohort)
{
	bool didDisturbance = false;			// return value
	if ( iDisturbList == disturbList.end() ) 	// anything left to do?
		return didDisturbance;

	TDCSimTime const & timer =		// century model sim. time
		*dynamic_cast<TDayCentModel const &>(
			cohort->GetModel() ).GetModel().GetSimTime();
	short const dayOfMonth =
		calendarTools.DayOfMonth (timer.dayOfYear, timer.year);

    while ( iDisturbList->GetYear() == timer.year &&
	    iDisturbList->GetMonth() == timer.month &&
	    iDisturbList->GetDay() == dayOfMonth &&
	    iDisturbList->GetSourceCohortID() == cohort->GetID() )
    {
	// Is it time for a disturbance?
	ScheduledDisturbanceEvent & disturbEvent = *iDisturbList;
	std::string const description =
		( disturbEvent.GetDescription().empty() ?
		  disturbEvent.GetManagementFileName() :
		  disturbEvent.GetDescription() );
	TDayCentModel & dayCentModel =
		  dynamic_cast<TDayCentModel &>( cohort->GetModel() );
	std::string msg;
	::AppendSystemTypeString (dayCentModel, msg);
	if ( !disturbEvent.IsComment() &&
	     disturbEvent.GetSourceCohortID() == cohort->GetID() )
	{
	    // initiate the disturbance
	    TTimeManager::TTime const timestamp =
		cohort->GetModel().GetTimer().GetTimeStep();
	    // for now, let's always to a scheduled disturbance
	    /*
	    if ( cohort->GetAge(timestamp) >=
		 mySimConfig.GetMinCohortAgeToDisturb() )
	    */
	    {
		// ... event key
		::nrel::gcf::TEventKey key (
			::nrel::gcf::TEventKey::Event_DivideCohort,
			timestamp );
		// ...event data
		::nrel::gcf::TEventData cohortEventData (cohort);	// TCohort*
		::nrel::gcf::TEventData areaFractionEventData (
			disturbEvent.GetCellAreaFraction() );	// float
		::nrel::gcf::TEventData mgmtFileEventData (
			disturbEvent.GetManagementFileName() );	// string
		::nrel::gcf::TEventDataArray eventDataArray;		// size = 3
		eventDataArray.push_back ( cohortEventData );		// [0]
		eventDataArray.push_back ( areaFractionEventData );	// [1]
		eventDataArray.push_back ( mgmtFileEventData );		// [2]
		// ...event
		::nrel::gcf::TEvent event ( make_pair( key, eventDataArray ) );
		// Process the event NOW!
		// Warning! this bypasses the event queue.
		// Send to the grid cell's event manager
		didDisturbance =
			!( cohort->GetOwner()->GetEventManager().
				ProcessEvent (event) );

		// write about event to the simulation output
		if ( !didDisturbance )  // failed?
		{
		    msg += "FAILED creating cohort - ";
		    msg += description;
		}
		else
		{
		    disturbEvent.SetDone (true);
		    msg += "New cohort - ";
		    msg += description;
		    msg += ", cell fraction = ";
		    msg += ::ToString ( disturbEvent.GetCellAreaFraction() );
		}
	    }
	    /*
	    else
	    {
		msg += "SKIPPED creating cohort: age < minimum - ";
		msg += description;
	    }
	    */
	    dayCentModel.WriteEventToSim ( msg, cohort->GetID() );
	    // all done!
	    ++iDisturbList;		// to next disturbance event
	    while ( iDisturbList->IsComment() )
		++iDisturbList;
	}
    }
    return didDisturbance;
}


//--- end of file TDisGenDayCentIRC.cpp ---
