// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  snowwater.cpp
//	Class:	  TCentury
//	Function: SnowWaterModel
//
//	Description:
// 	Snow melt and evaporation submodel for monthly Century 5.
//	Returns the amount of liquid water to apply to the soil surface.
// ----------------------------------------------------------------------------
//	History:
//	Jul03	Tom Hilinski, tom.hilinski@colostate.edu
//	* Extracted from h2olos.cpp.
// ----------------------------------------------------------------------------
//	Notes:
//	Difference equations describing the snowpack system:
//		d_snow = -(d_snowmelt + d_evapsnow)
//		d_liquid = d_snowmelt - d _evapliquid
//	    or
//		d_snow + d_liquid = -(d_evapsnow + d _evapliquid)
//
//	No simple simultaneous solution, so let's assume melting occurs first:
//		d_snowmelt = (see code)
//		liquid += d_snowmelt
//
//	Now the problem is reduced to:
//		d_snow = -d_evapsnow
//		d_liquid = -d_evapliquid
// ----------------------------------------------------------------------------

#include "TCentury.h"

float TCentury::SnowWaterModel (
	float const availablePET,	// total available PET
	float & remainingPT)		// net potential transpiration
{
	float netH2OToSoil = 0.0f;			// return value

	// Melt snow if air temperature is above minimum
	float dMelt = 0.0f;			// melted snow
	if ( wt.tave > fixed.tmelt[0] )
	{
		// Amount of snow to melt: proportional to air temp > melt temp
		dMelt = fixed.tmelt[1] * (wt.tave - fixed.tmelt[0]);
		dMelt = std::min (dMelt, wt.snow);
	}
	wt.snow -= dMelt;
	wt.snlq += dMelt;

	// fraction of snow that evaporates.
	// Coefficient 0.87 relates to heat of fusion for ice vs. liquid water
	float const snowEvapFraction = 0.87f;

	// total snowpack water available to evaporate
	float const availableEvap = wt.snow + wt.snlq;
	Assert (availableEvap >= 0.0f);

	// Evaporate water from the snow ice
	// (rewritten Pulliam 9/94: evaporate both snow and snlq in proportion)
	float actualEvap =			// snow evap demand due to PET
	  std::min (
	    availablePET * snowEvapFraction,		// allowed PET demand
	    availableEvap ); 				// cannot exceed this
	float const demandProportion =			// fraction to evap
		actualEvap / availableEvap;
	float dSnowEvap =				// evap. from snow ice
		std::min ( wt.snow, wt.snow * demandProportion );
	float dLiquidEvap =				// evap. from liquid
		std::min ( wt.snlq, wt.snlq * demandProportion );
	actualEvap = dSnowEvap + dLiquidEvap;		// final value

	// Adjust output variables for melting and evaporation
	wt.snow -= dSnowEvap;
	wt.snlq -= dLiquidEvap;
	wt.evap += actualEvap;

	// Drain snowpack to 5% liquid content (weight/weight);
	// excess water to soil.
	// Minimum snow liquid content fraction
	float const snowMinLiqFraction = 0.05f;
	float const snowMinLiquid = wt.snlq * snowMinLiqFraction;
	if ( wt.snlq > snowMinLiquid )
	{
	    // distribute the water
	    netH2OToSoil += wt.snlq - snowMinLiquid;	// to soil
	    wt.snlq = snowMinLiquid;			// to snowpack
	}
	if ( wt.snow == 0.0f && wt.snlq > 0.0f ) // if no snow, then no liquid
	{
		netH2OToSoil += wt.snlq;
		wt.snlq = 0.0f;
	}

	// Adjust PET values
	if ( actualEvap > 0.0f )
	{
		remainingPT = availablePET - actualEvap;
		Assert (remainingPT >= 0.0f);
	}

	// all done!
	return netH2OToSoil;
}

//--- end of snowwater.cpp ---

