
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <stdlib.h>
#include "netcdf.h"
#include "wrtcdf_ll.h"

void
closit_ll_(int *savall)
{
	/* Close all NetCDF files */
	int status;

	if (*savall == 1)
	{
		status = nc_close (cropll_ncid);
		status = nc_close (h2oll_ncid);
		status = nc_close (livcll_ncid);
		status = nc_close (livnll_ncid);
		status = nc_close (nfluxll_ncid);
		status = nc_close (nmnrll_ncid);
		status = nc_close (nuptll_ncid);
		status = nc_close (prodll_ncid);
		status = nc_close (respll_ncid);
		status = nc_close (soilcll_ncid);
		status = nc_close (soilnll_ncid);
		status = nc_close (cremvll_ncid);
		status = nc_close (nremvll_ncid);
	}

	return;
}
