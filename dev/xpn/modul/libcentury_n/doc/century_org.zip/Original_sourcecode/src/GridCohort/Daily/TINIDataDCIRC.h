#ifndef INC_nrel_dcirc_TINIDataDCIRC_h
#define INC_nrel_dcirc_TINIDataDCIRC_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  TINIDataDCIRC.h
//	Class:	  TINIDataDCIRC
//
//	Description:
//	Class for managing INI data for the DayCentIRC model.
//
//	Responsibilities:
//	* Provides public interface to access to the INI data.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Oct03
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TINIDataGCF.h"
#include "IRCUtil.h"
#include "stringutil.h"

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class TDayCentIRCConfig;


class TINIDataDCIRC
	: public ::nrel::gcf::TINIDataGCF
{
  public:
  	//---- types

	//---- constructors and destructor
	TINIDataDCIRC ()
	  : ::nrel::gcf::TINIDataGCF ()
	  {
	    Initialize ();
	  }
	TINIDataDCIRC (
	  TINIDataDCIRC const & object)
	  : ::nrel::gcf::TINIDataGCF (object),
	    ::nrel::ini::INIData (object)
	  {
	  }
	virtual ~TINIDataDCIRC ()
	  {
	  }
	TINIDataDCIRC * const Clone () const			// Clone this
	  { return new TINIDataDCIRC (*this); }

	//---- operator overloads

	//---- functions: Assign data
	void SetLogFile (			// Set the log file name
	  std::string const & fileName);	//   file name + path
	void SetOutputVariablesConfig (
	  TOutputVarConfig const & useConfig);
	void SetCohortAgConfig (		// Set aggregation algorithm
	  ::TimeRange const & catsi,		//   cohort ag. time interval
	  TTime const minCohortAgeToCombine,	//   min. cohort age to combine
	  float const cohortVarFraction);	//   variation range of cohorts
	void SetDisturbanceConfig (		// Set disturbance algorithm
	  TFileNameIDMap const & disturbFiles); // disturbance file names
	void SetDisturbanceConfig (		// Set disturbance algorithm
	  TFileNameIDMap const & disturbFiles,	// disturbance file names
	  float const minAreaFracDisturb,	//   min. area fraction disturb.
	  TTime const minCohortAgeToDisturb);	//   min. cohort age to disturb
							//--- datasets
	void SetWeatherINIFile (			// Weather INI file
	  std::string const & weatherINIFile); 		//   file name
	void SetSoilSource (				// Soil Source
	  ::nrel::gcf::TSoilSource const source,	//   source type
	  std::string const & fileName = EMPTY_STRING);	//   file name

	//---- functions: Access
	std::string const & GetLogFileName () const
	  {
	    Values const & values =
		::nrel::ini::GetValues (
		    data, sectionNames[Simulation],
		    simulationKeys[indexLogFileName] );
	    if ( values.Size() > 0 )
		return values[0];
	    else
		return emptyString;
	  }
	TOutputVarConfig GetOutputVariablesConfig () const
	  {
	    TOutputVarConfig config;
	    Values const & values =
		::nrel::ini::GetValues (
		    data, sectionNames[Simulation],
		    simulationKeys[indexOutputVarsConfig] );
	    if ( ToOutputVariablesConfig (values, config) )
		config.Reset();
	    return config;
	  }
	// cohort aggregation timestep interval
	::TimeRange const GetCATSI () const;
	// cohort aggregation variation range (+/-) of cohorts
	float GetCohortVariationFraction () const
	  {
	    Values const & values =
		::nrel::ini::GetValues (
		    data, sectionNames[CohortAggregation],
		    cohortAggregationKeys[indexCohortVarFraction] );
	    if ( values.Size() > 0 )
		return ::FromString<float>(values[0]);
	    else
		return 0.0f;
	  }
	// disturbance file names indexed by cell ID
	TFileNameIDMap const GetDisturbFileNameMap () const;

	std::string const & GetWeatherINIFileName () const
	  {
	    Values const & values =
	    	::nrel::ini::GetValues (
		  data, sectionNames[Simulation],
		  simulationKeys[indexWeather] );
	    if ( values.IsEmpty() )
		return emptyValue;
	    else
		return values[0];
	  }

	::nrel::gcf::TSoilSource GetSoilSource () const;
	std::string GetSoilSourceFileName () const
	  {
	    Values const & values =
	    	::nrel::ini::GetValues (
		  data, sectionNames[Simulation],
		  simulationKeys[indexSoil] );
	    if ( values.IsEmpty() )
		return emptyValue;
	    else
		return values[1];
	  }

  protected:
	//---- constants

	//---- data
	// indices to key in KeyVector
	TKeyIndex			// simulationKeys:
	    indexLogFileName,		// key: LogFileName
	    indexOutputVarsConfig,	// key: OutputVariables
	    indexWeather,		// key: WeatherINI
	    indexSoil;			// key: SoilSource
	TKeyIndex			// cohortAggregationKeys:
	    indexCATSI,			// key: CATSI
	    indexCohortVarFraction;	// key: CohortVariationFraction
	TKeyIndex			// cohortDisturbanceKeys:
	    indexDisturbFileNameCell;	// key: DisturbFileNameCell

	//---- functions

  private:
	//---- constants

	//---- data

	//---- functions
	void Initialize ()			// Initialize members
	  {
	    StoreSectionAndKeyNames ();
	    BuildINIData ();
	  }
	bool AddKeyNoValue (			// Add empty key to section
	  SectionName & sectionName,		//   section to add to
	  Key & key);				//   key to add to section
	void StoreSectionAndKeyNames ();	// Add section & key names
	void BuildINIData ();			// Fill in INI data
};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_TINIDataDCIRC_h
