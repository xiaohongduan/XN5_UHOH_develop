// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TDayCentSimController.cpp
//	Class:	  TDayCentSimController
//
//	Description:
//	DayCent simulation controller class.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, tom.hilinski@colostate.edu, June 2002
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TDayCentSimController.h"
#include "CenturyOutputMgrFactories.h"	// output managers factories
#include "TCenturyOutputFactory.h"
#include "TDayCentIRCConfig.h"		// simulation configuration
#include "TClimateBase.h"
#include "fnutil.h"
#include "TCenturySimOutputMgr.h"
using namespace nrel::dcirc;

TDayCentSimController::TDayCentSimController (
	TDayCentIRCConfig const & useConfig,		// configuration
	::nrel::gcf::TClimateBase * const useClimate,	// climate source
	TDecisionPtr useDecision,			// decision modules
	TFactoriesPtr useFactories)			// factory modules
	: ::nrel::gcf::TGriddedSimulationBase (
	    dynamic_cast< ::nrel::gcf::TGCFConfiguration const & >(useConfig),
	    dynamic_cast< ::nrel::gcf::TClimateBase * const >(useClimate),
	    useDecision,
	    useFactories )
{
	Assert (factories.get() != 0);
	Assert (factories->HaveOutputFactory());
	Assert (factories->HaveSimOutputMgrFactory());

	// output factory
	TCenturyOutputFactory * const outputFactory =
		dynamic_cast<TCenturyOutputFactory * const>(
			factories->OutputFactory().get() );
	Assert (outputFactory != 0);
	if ( useConfig.GetLogFileName().empty() )
	{
		std::string fileName = useConfig.GetOutputPath();
		fileName += "SimulationLog.txt";
 		outputFactory->SetSimFileName ( fileName );
	}
	else
	{
		std::string fileName = useConfig.GetLogFileName();
		outputFactory->SetSimFileName (
		    TEH::PrependPathToFileIf (
			fileName,
			useConfig.GetOutputPath() ) );
	}

	// output object
	TSharedPtr< ::nrel::io::TFileStream > output (
			outputFactory->CreateInstance (
			::nrel::gcf::TGEOutputFactoryBase::Simulation) );
	Assert (output.get() != 0);

	// output manager
	typedef TCenturySimOutMgrFactory	OMFactory;
	OMFactory * const omFactory =
		dynamic_cast<OMFactory * const>(
			factories->SimOutputMgrFactory().get() );
	Assert (omFactory != 0);
	outputMgr.reset (
	    dynamic_cast<TOutputMgr*>(
		omFactory->CreateInstance (
		    this, 					// owner
		    output					// output
//		    dynamic_cast
//		      < OMFactory::MyBase::OwnerType * const >
//		      (this), 					// owner
//		    static_cast
//		      < TSharedPtr<OMFactory::MyBase::OutputType> >
//		      (output)					// output
		    ).release() ) );
	Assert (outputMgr.get() != 0);
	myOutputMgr = dynamic_cast<TCenturySimOutputMgr*>( outputMgr.get() );
	Assert (myOutputMgr != 0);
	// initialize output
	WriteStartupInfo ();
}

//--- end of file TDayCentSimController.cpp ---

