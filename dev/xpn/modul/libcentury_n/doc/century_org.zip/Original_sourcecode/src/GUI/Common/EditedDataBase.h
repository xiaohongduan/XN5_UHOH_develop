#ifndef INC_EditedDataBase_h
#define INC_EditedDataBase_h
// ----------------------------------------------------------------------------
//	Copyright 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  EditedDataBase.h
//	Class:	  EditedDataBase
//
//	Description:
//	Base class for the data source or object whose data is being
//	edited in a GUI editor. Actions include:
//	* Initialize upon construction.
//	* Cloning the object.
//	* Saving the data.
//	* Accessing the data object.
//	* Checking for errors.
//
//	Responsibilities:
//	* Public interface for accessing the data and performing the
//	  defined actions.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Aug04
//	History:
// ----------------------------------------------------------------------------

#include "TSharedPtr.h"
#include <string>

template
<
	class DataType		// edited data object type
>
class EditedDataBase
{
  public:
	//---- types
  	enum TError
  	{
  		NoError,
  		ReadFailed,
		WriteFailed,
		CopyFailed,
		UnknownError
	};
	enum TUserAction		// return value from user-dialog action
	{
		ActionOK,
		ActionCancel,
		ActionYes,
		ActionNo,
		ActionUnknown
	};
	typedef TSharedPtr<DataType>		DataTypePtr;

	//---- constructors and destructor
	virtual ~EditedDataBase ()
	  {
	  }
	virtual EditedDataBase * const Clone () const = 0; // Clone this

	//---- operator overloads
	EditedDataBase<DataType> & operator= (
	  EditedDataBase<DataType> const & object)
	  {
	    Copy (object);
	    return *this;
	  }
	bool operator== (
	  EditedDataBase<DataType> const & object) const
	  {
	    if ( &object )
	    {
		return
		  (*dataPtr == *object.dataPtr);
	    }
	    else
		return false;
	  }
	bool operator!= (
	  EditedDataBase<DataType> const & object) const
	  {
	    return !(*this == object);
	  }

	//---- functions
	TUserAction Open ()
	  {
	    return DoOpen (dataPtr);
	  }
	TUserAction Save ()
	  {
	    return DoSave (*dataPtr);
	  }
	TUserAction SaveAs ()
	  {
	    return DoSaveAs (dataPtr);
	  }
	DataTypePtr Get ()
	  {
	    return dataPtr;
	  }
	bool IsEmpty () const
	  {
	    return DoIsEmpty ();
	  }
	bool HaveError () const
	  {
	    return error != NoError;
	  };
	TError GetError () const
	  {
	    return error;
	  };
	void ClearError ()
	  {
	    error = NoError;
	  }
	std::string const & GetErrorMessage () const
	  {
	    return errorMsg;
	  }

  protected:
	//---- constants

	//---- data
  	DataTypePtr dataPtr;
  	TError error;
  	std::string errorMsg;

	//---- constructors and destructor
	EditedDataBase ()
	  : error (NoError)
	  {
	  }
	EditedDataBase (EditedDataBase<DataType> const & object)
	  {
	    Copy (object);
	  }

	//---- functions
	TError Copy (
	  DataType const & sourceData)
	  {
	    // dataPtr is of type TMCSiteParameters or TDCSiteParameters
	    if (dataPtr.get() != &sourceData)	// assigning self?
	    {
		try
		{
		    if ( dataPtr.get() == 0 ) // allocate and copy
		    {
			dataPtr.reset (
			    new DataType (sourceData) );
			if ( dataPtr->IsError() )
			    throw true;
		    }
		    else // copy
		    {
			*dataPtr = sourceData;
		    }
		}
		catch (...)
		{
			dataPtr.reset ();
			error = CopyFailed;
		}
	    }
	    return error;
	  }

  private:
	//---- data

	//---- functions
	void Copy (
	  EditedDataBase<DataType> const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
		dataPtr = object.dataPtr;
		error = object.GetError();
	    }
	  }
	// interface must be implemented here
	virtual TUserAction DoOpen (
	  DataTypePtr sourceData) = 0;
	virtual TUserAction DoSave (
	  DataType const & sourceData) = 0;
	virtual TUserAction DoSaveAs (
	  DataTypePtr sourceData) = 0;
	virtual bool DoIsEmpty () const = 0;
};

#endif // INC_EditedDataBase_h
