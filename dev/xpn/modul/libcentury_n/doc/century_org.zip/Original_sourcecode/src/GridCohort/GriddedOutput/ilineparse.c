
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "gridconst.h"

int
ilineparse(char *line, int value[], int maxval, FILE *fp_init)
{
	char *cptr;
	int i;

	cptr = strtok(line, " ");
	sscanf(cptr, "%d", value);

	i = 1;
	while (((cptr = strtok((char*)NULL, " ")) != (char*)NULL) &&
		 i < maxval)
	{
		if (strncmp(cptr, "\\", 1) == 0) 
		{
		   fgets(line, MAXL, fp_init);
		   i += ilineparse(line, &value[i], (int)MAXLU, fp_init);
		}
		else
		{
		   sscanf(cptr, "%d", &value[i]);
		   i++;
		}
	}

	return i;
}
