// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  wrtbin.cpp
//	Class:	  TCentury
//	Function: WriteOutputValues
//
//	Description:
//	Write all daily output values to spreadsheet files or
//      the netCDF output file.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
// ----------------------------------------------------------------------------
//	History:
//	Jan99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to use the new output file classes.
//	Dec99	Tom Hilinski
//	* Clarified the "retrieve water content" loop.
//	Nov02	Tom Hilinski
//	* Replaced ostrstream with ostringstream.
//	* Corrected storage of deep soil water storage, so it isn't overwritten,
//	  and placed at ASMOS(10) per the Century reference manual. This is a
//	  small mod. of the fix Melannie supplied.
//	Jun05	Tom Hilinski
//	* Moved update of water output vars into TCENTURYBASE::OutputVariables.
//	* Moved update of mineral N,P,S output vars into new virtual function
//	  TCentury::UpdateMineralEOutputVariables.
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include "TCentNcFile.h"
#include <sstream>
using namespace std;

void TCentury::WriteOutputValues (float const time)
{
	//--- write output data
	if ( doOutput )
	{
		TMCOutputFileBase* const theOutput =
			dynamic_cast<TMCOutputFileBase*>( output.get() );
		Assert (theOutput != 0);
		if ( theOutput->WriteRecord (time) )
		{
		    ostringstream os;
		    os << "Error occurred with output record "
		       << theOutput->LastRecord();
		    if (theOutput->GetOutputType() == TOutputBase::Type_NetCDF)
		    {
			os << "\nNetCDF message: "
			   << dynamic_cast<TCentNcFile*>(
			   		theOutput)->LastErrorMsg()
			   << ends;
		    }
		    ThrowCentException ( TCentException::CE_WRTOUT,
		    			 os.str().c_str() );
		}
	}
}

//--- end of file ---

