// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model, monthly version
//	File:	  TMCSiteParIndices.cpp
//	Class:	  TMCSiteParIndices
//
//	Description:
//	Indices to site parameter values and descriptions.
//
//	Responsibilities:
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu 	Nov04
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TMCSiteParIndices.h"

//	setIndexList
//	Array of indices to the start of each group of parameters
TMCSiteParIndices::TSiteParSetIndexList const TMCSiteParIndices::setIndexList =
{
	SPI_precip,		// 1. climate
	SPI_ivauto,		// 2. soil and physical
	SPI_epnfa,		// 3. external nutrients
	SPI_som1ci,		// 4. initial organic matter
	SPI_rlvcis,		// 5. initial forest organic matter
	SPI_minerl,		// 6. initial mineral N, P, S
	SPI_rwcf,		// 7. initial relative water content
	SPI_lhicu,		// 8. lower horizon initial pool amounts
	SPI_eflcu,		// 9. Erosion and deposition
	SPI_EndOfList
};

//	siteSetCount
// 	Size of each parameter set.
//	The indices are zero-based.
//      added DayCent parameters to end of list -mdh 3/6/01, 3/30/01
short const TMCSiteParIndices::siteSetCount[ /* GetSetCount() */ ] =
{
	SPI_ivauto, 			// climate
	SPI_epnfa - SPI_ivauto, 	// soil and physical
	SPI_som1ci - SPI_epnfa, 	// external nutrients
	SPI_rlvcis - SPI_som1ci, 	// initial organic matter
	SPI_minerl - SPI_rlvcis, 	// initial forest OM
	SPI_rwcf - SPI_minerl, 		// initial mineral N, P, S
	SPI_lhicu - SPI_rwcf,		// initial rel. water content
	SPI_eflcu - SPI_lhicu, 		// initial lower horizon pools
	SPI_EndOfList - SPI_eflcu, 	// Erosion and Deposition
	0
};

//	siteSetName
//	Parameter group names (short and descriptive)
char const * const TMCSiteParIndices::siteSetName[ /* GetSetCount() */ ] =
{
	"Climate",
	"Soil & Physical Controls",
	"External Nutrients",
	"Initial Crop/Grass Organic Matter",
	"Initial Forest Organic Matter",
	"Initial Soil Mineral N, P, S",
	"Initial Soil Water Content",
	"Initial Soil Lower Layer Pools",
	"Erosion and Deposition",
	0
};


//--- end of definitions for TMCSiteParIndices ---
