// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  DisplayAbout.cpp
//	Functions:
//	  DisplayAbout
//	  DisplayAbout ( <function pointer> )
//
//	Description:
//	Global functions for displaying messages to the user.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Apr98
// ----------------------------------------------------------------------------
//	History:
//	Jun98	Tom Hilinski, tom.hilinski@colostate.edu
//	Modified: Tom Hilinski, Jun98
//	* added overloaded versions which can write to an external function,
//	  msgFunction, which accepts the string for display.
//	Jan01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Removed function DisplayUserString: no longer needed.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#ifdef DAILY_CENTURY
#include "version_dc.h"				// DayCent version info
#else
#include "version.h"				// Century version info
#endif
#include <iostream>
using namespace std;

void DisplayAbout ()
{
	cout << CenturyName << '\n' << CenturyVersion << endl;
}

void DisplayAbout ( void (*msgFunction)(char const*) )
{
	if ( msgFunction )
	{
		// let the compiler concatenate the strings
		char const * const msg = CenturyName "\n" CenturyVersion;
		(*msgFunction)( msg );
	}
}

//--- end of file ---
