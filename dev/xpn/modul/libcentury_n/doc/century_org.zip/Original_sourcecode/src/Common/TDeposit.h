#ifndef INC_TDeposit_h
#define INC_TDeposit_h

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TDeposit.h
//	Class:	  TDeposition
//
//	Description:
//	Class to perform deposition into Century's pools.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Mar99
// ----------------------------------------------------------------------------
//	History:
//	Jan01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Made the reference to the physical soil class a const.
//	* Removed physical soil deposition from this class.
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added copy constructor
// ----------------------------------------------------------------------------
//	Copyright 1999-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TDepEroBase.h"

class TDeposition : public TDepEroBase
{
  public:
	//--- constructors and destructor
	TDeposition (
	  TSite & useSite,		// use this site class instance
	  TCenturySoil & useSoil,	// use this soil class instance
	  TLowerSoil & useLwrSoil,	// use this lower soil pool instance
	  TSoilC & useSoilC, 		// soil C output variable instance
	  TNPS & useNPS,		// NPS output variable instance
	  TWater & useWater,		// water parameters class
	  TWaterTemp & useWT,		// water & temperature output class
	  TFlow & useFlows,		// flow manager class instance
	  short const useNumIso,	// number of isotopes
	  short const useNumElem);	// number of elements
	~TDeposition () { }
	TDeposition (TDeposition const & object)	// copy constructor
	  : TDepEroBase ( static_cast<TDepEroBase const &>(object) )
	  {
	  }

	//--- functions
	bool UseDepositionFile (	// Read amounts be deposited from
					//   a file created by TErosion.
	  char const * const filePath);	//   full path with file name
					//   Returns false if OK, else true.
	bool UseDepositionFile (	// Read amounts be deposited from
					//   a file created by TErosion.
	  std::string const & filePath)	//   full path with file name
	  {				//   Returns false if OK, else true.
	    return UseDepositionFile (
	    		filePath.c_str() );
	  }
	bool HaveDepositFile () const	// True if using deposition input file
	  { return (eoFile.get() != 0); }
	std::auto_ptr<TSoilLayer>
	  Deposit (			// Do deposition
	  float const simTime);		//   simulation time (year + fraction)
	void Clear ()			// "Clear" data members
	  {
	    TDepEroBase::Clear ();
	  }

  protected:
	//--- functions
	bool ReadNextEvent (		// Get the next deposition event
	  float const  simTime,		//   sim. time (year + fraction)
	  float& thickness,		//   thickness eroded
	  float& bulkDen,		//   bulk density of eroded thickness
	  float& sand,			//   fraction of sand-sized
	  float& silt,			//   fraction of silt-sized
	  float& clay,			//   fraction of clay-sized
	  float*& data);		//   data[EE_NumElements][EPT_NumPools]
	void SimLayerAdditions (	// Add material to simulation layer
	  float const simTime, 		//   simulation time
	  float const * const data);	//   data[EE_NumElements][EPT_NumPools]
	void SimToLowerLayer (		// Do transfers to lower layer pools
	  float const simTime, 		//   simulation time
	  float const amtC[sizeC], 	//   C transfer amounts (g m-2)
	  float const amtE[sizeE]);	//   N, P, S transfer amounts (g m-2)

  private:
	//--- functions
};

#endif // INC_TDeposit_h
