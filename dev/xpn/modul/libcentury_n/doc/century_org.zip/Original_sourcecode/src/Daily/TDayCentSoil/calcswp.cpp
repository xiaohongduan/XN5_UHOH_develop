// ----------------------------------------------------------------------------
//    Copyright 1998-2000 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//    Project:  Century Soil Organic Matter Model, daily version
//    File:	calcswp.cpp
//    Class:	TDayCentSoil
//    Function: float UpdateSoilWaterArrays()
//
//    Description:
//    Calculates the soil water potential of all soil layers
//
//    Author: Melannie Hartman
// ----------------------------------------------------------------------------
//    History:
//    Apr2001  Melannie Hartman  melannie@NREL.colostate.edu
//    * Created
//	Nov02   Tom Hilinski, tom.hilinski@colostate.edu
//	* Misc. clean up, const-correctness, optimization.
//	Jan04	Tom Hilinski
//	* Renamed to UpdateSoilWaterArrays.
// ----------------------------------------------------------------------------
//    Class Members:
//      thickness[]       - thicknesses of soil layers (cm)
//      WaterContent()    - soil water content of layers (cm H2O)
//      ClayFraction()
//      SandFraction()
//      BulkDensity()     - (g/cm^3)
// ----------------------------------------------------------------------------
//	To do:
//	Does this duplicate the WaterEquation call in
//	TDayCentSoil::SoilWaterFlux?
// ----------------------------------------------------------------------------

#include "TDayCentSoil.h"

void TDayCentSoil::UpdateSoilWaterArrays ()
{
	// debug
//	Assert (SandFraction().Size() == depth.size());
//	Assert (SiltFraction().Size() == depth.size());
//	Assert (ClayFraction().Size() == depth.size());
//	Assert (BulkDensity().Size() == depth.size());
//	Assert (thetaSat.size() == depth.size());
//	Assert (psiSat.size() == depth.size());
//	Assert (swrc.size() == depth.size());
//	Assert (theta.size() == depth.size());
//	Assert (soilWaterPotential.size() == depth.size());
//	Assert (thickness.size() == depth.size());
//	Assert (WaterContent().Size() == depth.size());

	soilWaterModel->WaterEquation (
		SandFraction(), ClayFraction(), thetaSat, psiSat, swrc );
	for ( short layer = 0; layer < GetLayerCount(); layer++)
	{
		// Use Bulk Density based thetaSat[] instead of
		// one computed by WaterEquation()
		// thetaSat(layer) = PartonThetaSaturation ( BulkDensity(layer) );
		theta(layer) = WaterContent(layer) / thickness[layer];
		soilWaterPotential(layer) =
			soilWaterModel->SoilWaterPotential (
				theta(layer), thetaSat(layer),
				psiSat(layer), swrc(layer) );
	}
}

//--- end of file ---


