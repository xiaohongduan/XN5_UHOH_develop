#ifndef INC_TTextCmdWindow_h
#define INC_TTextCmdWindow_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Model Interface - V GUI
//	File:	  TTextCmdWin.h
//	Class:	  TTextCmdWindow
//
//	Description:
//	Class for text editor windows.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Oct98
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------

#include "TCmdWinBase.h"
#include "TTextWindow.h"

class TTextCmdWindow : public TCmdWinBase
{
  public:
	//--- constructors and destructor
	TTextCmdWindow (
	  TCMIApp * const parentApp,		// pointer to app instance
	  char const * const windowTitle);	// window title string
	~TTextCmdWindow ();

	//--- overridden functions
	void WindowCommand (
	  ItemVal itemId,
	  ItemVal val,
	  CmdType cType);

	//--- functions
	void Text (
	  char const * const text)		// text on canvas
	  { textWindow->AppendText (text); }

  private:
	//--- menu definitions
	static vMenu editTextMenuDef[];		// "Edit" drop-down menu -text
	static vMenu textEditorMenuBarDef[];	// menu bar for text windows

	//--- window display items
	TTextWindow * textWindow;		// For the main text window
};

#endif 	// INC_TTextCmdWindow_h
