//	DayLength
//	Returns the number of fractional hours in the day given the
//	month and the latitude.
//	Author: Melannie Hartman did the original.
//	Tom Hilinski optimized constants, and pow and tan usage.
//      Melannie Hartman modified Tom's version for use with DayCent (4/28/01)

#include "TDayCent.h"
#include <cmath>
#include <algorithm>
using namespace std;

float TDayCent::DayLength (
	int const day,	              // day of year (range: 1-366)
        float const latitude) const   // latitude in degrees (-90,90)
{
	Assert (day >= 1);
	Assert (day <= 366);
        Assert (latitude > -90.0f);
        Assert (latitude < 90.0f);

	double adelt, ahou;
	double tanRadLat;		// tan of latitude in radians
	double temp1, temp2, temp3;
	double julianDay = (double)day;
	static const double recip365 = 1.0 / 365.0;
	static const double recip180 = 1.0 / 180.0;
	static const double recipPI = 1.0 / M_PI;

	float theLatitude = std::fabs (latitude);

	// Convert from degrees to radians
	tanRadLat = std::tan ( (theLatitude * M_PI * recip180) );
	temp1 = 2.0 * M_PI * (julianDay - 77.0) * recip365;
	adelt = 0.4014 * std::sin (temp1);
	// temp1 = 1.0 - std::pow ((-std::tan (rlat) * (adelt)), 2.0);
	// replaced by the following two lines:
	temp3 = -tanRadLat * adelt;
	temp1 = std::sqrt ( std::max ( 1.0 - temp3 * temp3, 0.0 ) );
	temp2 = -tanRadLat * std::tan (adelt);
	ahou = std::atan2 (temp1, temp2);
	return static_cast<float>(ahou * recipPI * 24.0);
}

//--- end of file ---

