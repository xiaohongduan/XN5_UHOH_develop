#ifndef INC_TMCSiteParameters_h
#define INC_TMCSiteParameters_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TMCSiteParameters.h
//	Class:	  TMCSiteParameters
//
//	Description:
//	Classes for Century site file parameters (formerly "<site>.100" files).
//	An associated class is TMCSiteParamInfo which holds the site parameter
//	names and definition text.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Feb98, tom.hilinski@colostate.edu
//	History:
//	May99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Enhanced error messages upon import of Century 4 parameter files.
//	Jan00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Operator= : added check for assignment to self, and changed to return
//	  a reference to this rather than a copy of this.
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* A bit of cleaning up.
//	* Added copy constructors
//	Oct01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added function TMCSiteParameters::GetSiteParamInfo
//	Jul02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Now derived from class TSiteParametersBase and TSiteParamUnknown.
//	* Moved lots of stuff into TSiteParametersBase.h
//	Jan03	Tom Hilinski, tom.hilinski@colostate.edu
//	* Renamed class and file to TMCSiteParameters.
//	Sep03	Tom Hilinski
//	* Exceptions now done in TSiteParametersBase fuctions
//	  SiteParamDefException and SiteParamReadException.
//	* Moved site parameter indices into TMCSiteParIndices.h
//	* Removed all references to the namespace NSMonthlyCent.
//	* Site parameters info object now must be created outside of
//	  the SiteParameters classes.
//	* Site parameters set indices list must be created outside of
//	  the SiteParameters classes.
//	Nov03	Tom Hilinski
//	* Mod to match base class mods of char* members to std::string.
//	Nov04	Tom Hilinski
//	* The parameter indices are now public members of the class.
// ----------------------------------------------------------------------------

#include "TSiteParamUnknown.h"
#include "TMCSiteParIndices.h"
#include "TMCSiteParamInfo.h"
#include "TFileName.h"
#include <fstream>

// ----------------------------------------------------------------------------
//	Forward references
class TNcSiteParameters;	// for friend classes to do netCDF I/O


// ----------------------------------------------------------------------------
//	TMCSiteParameters
//	Class for management of a set of site parameter sets.

class TMCSiteParameters
	: public TSiteParamUnknown
{
	// Friend classes for all handling all netCDF file I/O.
	friend class TNcSiteParameters;		// r/w netCDF parameter values

  public:
	//--- types
	typedef TSiteParamUnknown			TBaseClass;
	// the parameter indices are publicly accessible here
	typedef TMCSiteParIndices			indices_type;
	TMCSiteParIndices indices;

	//--- constructors and destructor
	TMCSiteParameters (			// Create a blank param. set
	  std::string const & useTmpltPath,	//   template files
	  std::string const & useWorkPath,	//   working directory
	  TMCSiteParamInfo::TInfoPtr useInfo);	//   parameter descriptions
	TMCSiteParameters (			// Create a blank param. set
	  char const * const useTmpltPath,	//   template files
	  char const * const useWorkPath,	//   working directory
	  TMCSiteParamInfo::TInfoPtr useInfo);	//   parameter descriptions
	TMCSiteParameters (			// Create reading a file
	  TEH::TFileName const & useFileName,	//   site file name
	  char const * const useTmpltPath,	//   template files
	  char const * const useWorkPath,	//   working directory
	  TMCSiteParamInfo::TInfoPtr useInfo);	//   parameter descriptions
	TMCSiteParameters (			// Create reading a file
	  char const * const useFileName, 	//   site file name
	  char const * const useTmpltPath,	//   template files
	  char const * const useWorkPath,	//   working directory
	  TMCSiteParamInfo::TInfoPtr useInfo);	//   parameter descriptions
	TMCSiteParameters (			// Create reading a file
	  std::string const & useFileName, 	//   site file name
	  std::string const & useTmpltPath,	//   template files
	  std::string const & useWorkPath,	//   working directory
	  TMCSiteParamInfo::TInfoPtr useInfo);	//   parameter descriptions
	TMCSiteParameters (			// copy constructor
	  TMCSiteParameters const & object)
	  : TSiteParamUnknown (object)
	  {
	    Copy (object);
	  }
	~TMCSiteParameters ()
	  {
	  }

	//--- operator overloads
	TMCSiteParameters& operator= (
	  TMCSiteParameters const & object);
	bool operator== (
	  TMCSiteParameters const & object
	  ) const
	  {
	    return TBaseClass::operator== (object);
	  }
	bool operator!= (
	  TMCSiteParameters const & object
	  ) const
	  {
	    return !(*this == object);
	  }

	//--- functions
	void Clear ();				// Clear member data
	TEH::TFileName const & GetFileName (	// Get input file name
	  ) const
	  { return filePath; }
	TSiteParamFileType GetFileType () const	// Get file type
	  { return fileType; }
	TSiteParamFileType GetFileType (
	  TEH::TFileName const & fileName);
						//--- r/w netCDF files
	bool ReadNcFile ();			// Read
	bool WriteNcFile ();			// Write
	bool VerifyValues ();			// Check the parameter values
						//--- status functions:
	//int GetNumParamsRead () const		// Number of parameters read
	//  { return numParamsRead; }
	//int GetNumParamsExpected () const	// Number of parameters expected
	//  { return numParamsExpected; }

	//---- constants

  protected:
	//--- data
	TEH::TFileName filePath;	// path of input file
	TSiteParamFileType fileType;	// type of input file
	// int numParamsRead;		// number of parameters read from file
	// int numParamsExpected;	// number of parameters expected

	//--- functions
	/*
	TMCSiteParameters ()			// Default constructor
	  : TSiteParamUnknown ()
	  {
	    Initialize ();
	  }
        */
	void AssignDefaultValues ();		// Assign default param values
	bool ImportCent4File ();		// Import Cent. 4 file
	TParamImportStatus ImportParameter (	// Import one parameter.
	  std::ifstream & ifs, 			//   file stream imported file
	  TSiteParameter & param);		//   imported parameter
	bool FindObsoleteParameter (		// Check obsolete parameters
	  char const* paramName);		//   parameter name to check
	char const* FindReplacedParameter ( 	// Check for replaced parameter
	  char const* paramName);		//   parameter name to check
	bool Read (				// Read the site parameters
	  TEH::TFileName const & newFileName);	//   site file name
	bool Read (				// Read the site parameters
	  char const * const newFileNameStr)	//   site file name C string
	  {
	    TEH::TFileName newFileName (
		newFileNameStr,
		TEH::TFileName::FT_Normal);
	    return Read (newFileName);
	  }
	bool Read (				// Read the site parameters
	  std::string const & newFileNameStr)	//   site file name string
	  {
	    return Read ( newFileNameStr.c_str() );
	  }
	virtual void CreateZeroedSets ();
	bool IsComment (			// True if a comment char
	  char const * const s
	  ) const
	  {
	    return *s == '#' || *s == '!' || *s == ';' ||
	    	(*s == '/' && *(s + 1) == '/');
	  }

  private:
	//--- functions
	void Initialize ();			// initialize members
	void Copy (				// copy to this
	  TMCSiteParameters const & object);
};

#endif // INC_TMCSiteParameters_h

