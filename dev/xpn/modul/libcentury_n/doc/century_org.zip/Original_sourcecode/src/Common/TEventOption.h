#ifndef INC_TEventOption_h
#define INC_TEventOption_h

// ----------------------------------------------------------------------------
//	Copyright 1997-2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TEventOption.h
//	Classes:
//	  TParamInfo
//	  TParameter
//	  TEventOption
//	  TEventOptionSet
//
//	Description:
//	Classes for Century parameters (formerly "*.100" files).
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Nov-Dec97
//	Concept by Tom Hilinski, Oct97
//	Written by Cindy Keough, Nov97-Jan98
// 	Modified by Tom Hilinski, Feb98, Jun98
//	History:
//	Jan00	Tom Hilinski
//	* Operator= : added check for assignment to self, and changed to return
//	  a reference to this rather than a copy of this.
//	Jun01	Tom Hilinski
//	* Added copy constructor, Copy members to TParamInfo.
//	Jul01	Tom Hilinski
//	* Expanded the notes, shown below.
//	* Misc. cleanup.
//	* TEventOptionSet now is constructed with a TEventType parameter.
//	* Added a constructor with std:;string to TEventOptionSet.
//	Feb04	Tom Hilinski
//	* Made TEventOptionSet::name = std::string.
//	* Made TEventOptionSet::description = std::string.
//	Aug05	Tom Hilinski
//	* Added detailed error messages to class TEventOptionSet.
//	* Added TEventOptionSet::GetErrorMessage.
// ----------------------------------------------------------------------------
//	Notes:
//	"event file" = an event database, eg., "crop" or "fire".
//		Each entry is an "event option".
//		Each event database has a unique event key.
//		Contents are stored in class TEventOptionSet.
//	"event option" = an entry in an event database. Each has
//		a set of parameters. The set is similar for each option
//		in an event database. An event option is the "additional
//		information" field associated with a management event.
//		Contents are stored in class TEventOption.
//	"parameter" = a named value for an event option. There are multiple
//		parameters for each event option.
//		Contents are stored in class TParameter.
//		Associated with each parameter is a description,
//		stored in class TParamInfo.
//	Organization of data:
//	  event file:event options = 1:many (TEventOptionSet:TEventOption)
//	  event options:parameters = 1:many (TEventOption:TParameter)
//	  parameter description:parameters = 1:many (TParamInfo:TParameter)
// ----------------------------------------------------------------------------

#include "TFileName.h"
#include "charutil.h"
#include <set>
#include <vector>
#include <string>
#include <cstring>

// ----------------------------------------------------------------------------
//	TParamFileType
//	Specifies the type of the parameter file: Century 4.0 ASCII or netCDF.
enum TParamFileType
{
	PFT_Unknown,		// Unknown type: first item always
	PFT_Century4,		// ".100" file from Century 4.0
	PFT_netCDF,		// netCDF file
	PFT_EndOfList		// last item always
};

// ----------------------------------------------------------------------------
//	Global constants
static short const _maxParamNameLen = 20;
static short const _maxEventNameLen = 10;
static short const _maxEventDescLen = 80;
static short const _maxParamCount = 200;

// ----------------------------------------------------------------------------
//	TParamInfo
//	Holds data describing the parameter.
//	Since there are many events using the same parameter, but with
//	different parameter values, the data about the parameter needs
//	to be specified only once.
//	For each file there is a list of TParamInfo elements.
//	Data initialization is handled externally.
class TParamInfo
{
  public:
	//--- data
	char  name[_maxParamNameLen + 1];	// parameter variable name
	float min, max;				// min/max values
	char const *description;		// description (for site pars.)

	//--- constructors and destructor
	TParamInfo ()
	  { Initialize (); }
	~TParamInfo()
	  { Clear (); }

	//--- operator overloads
	TParamInfo& operator= (const TParamInfo &object)
	  {
	    if (this != &object)	// check for assignment to self
	    {
		Initialize ();
		Copy (object);
	    }
	    return *this;
	  }
	bool operator== (const TParamInfo &object) const
	  { return  (!strcmp(name, object.name) &&
		   min == object.min && max == object.max );
	  }
	bool operator!= (const TParamInfo &object) const
	  { return !(*this == object); }

	//--- functions
	void Clear ()				// clear member data
	  {
	    delete [] description;
	    Initialize ();
	  }
  private:
	//--- functions
	void Initialize ()			// initialize members
	  {
	    *name = '\0';
	    min = max = 0.0f;
	    description = 0;
	  }
	void Copy (TParamInfo const & object);	// Copy to this
};

// ----------------------------------------------------------------------------
//	TParameter
//	Holds data for one parameter.
//	Century parameters are mostly float but some are int.
//	Since the parameters will be stored in NetCDF files,
//	we can pretend all are floats.
class TParameter
{
  public:
	//--- data
	float value;				// parameter value
	bool  modified;				// true if value changed
	bool  valid;				// true if value within range
	TParamInfo *info;			// ptr to parameter info array

	//--- constructors and destructor
	TParameter ()
	  {
	    Initialize ();
	  }
	TParameter (float newValue, TParamInfo *newInfo)
	  {
	    Initialize ();
	    value = newValue;
	    info = newInfo;
	  }
	~TParameter ()
	  {
	  }
	TParameter (const TParameter &object)	// copy constructor
	  {
	    Initialize ();
	    Copy (object);
	  }				// default constructor

	//--- operator overloads
	TParameter& operator = (const TParameter &obj);
	// 	Equality based upon value and parameter name
	bool operator == (const TParameter &obj) const;
	bool operator != (const TParameter &obj) const
	  { return !(*this == obj); }
	// 	Ordering based upon parameter value
	bool operator < (const TParameter& obj) const;
	bool operator <= (const TParameter &obj) const
	  { return (*this == obj || *this < obj); }
	bool operator > (const TParameter &obj) const
	  { return !(*this <= obj); }
	bool operator >= (const TParameter &obj) const
	  { return !(*this < obj); }

	//--- functions
	void SetValue (				// Set the parameter value
	  float const newValue)
	  { value = newValue; }
	float GetValue () const			// Get parameter's value
	  { return value; }
	bool CheckValue ();			// Returns true if valid value
	void Clear ();				// Clear member data
	char* GetName ()			// Get parameter name
	  { return info->name; }
	char const * GetDescription ()		// Get parameter description
	  { return info->description; }
	float GetMinimum ()			// Get minimum value allowed
	  { return info->min; }
	float GetMaximum ()			// Get maximum value allowed
	  { return info->max; }

  private:
	//--- functions
	void Initialize ();				// initialize members
	void Copy (const TParameter &fromObj);	// copy to this
};

// ----------------------------------------------------------------------------
//	TEventOption
//	Structure for holding a set of parameters for one event option.
//	There can be multiple event options per parameter file.
class TEventOption
{
	friend class TEventOptionSet;
  public:
	//--- constructors and destructor
	TEventOption ()
	  {
	    Initialize ();
	  }
	~TEventOption ()
	  {
	  }
	TEventOption (const TParameter &object)	// copy constructor
	  {
	    Initialize ();
	    Copy (object);
	  }

	//--- operator overloads
	TEventOption& operator = (const TEventOption &obj);
	bool operator == (const TEventOption &obj) const;
	bool operator != (const TEventOption &obj) const
	  { return !(*this == obj); }
	// Ordering based on option name (case-insensitive).
	bool operator < (const TEventOption &obj) const;
	bool operator <= (const TEventOption &obj) const
	  { return (*this == obj || *this < obj); }
	bool operator > (const TEventOption &obj) const
	  { return !(*this <= obj); }
	bool operator >= (const TEventOption &obj) const
	  { return !(*this < obj); }

	//--- functions
	void Clear ();
				// returns true if TParameter is a valid value
	void SetName (char *newName)
	  {
            strncpy (name, newName, _maxEventNameLen);
	    name[_maxEventNameLen] = '\0';
	    ::strtrim((char*)name);
	  }
	void SetDescription (char *newDesc)
	  {
            strncpy (description, newDesc, _maxEventDescLen);
	    description[_maxEventDescLen] = '\0';
	    ::strtrim((char*)description);
	  }
	char const * const GetName () const		// Get option name
	  { return (char const * const) name; }
	char const * const GetDescription () const	// Get option descrip.
	  { return (char const * const) description; }
	TParameter const * const GetParameter (		// Get the parameter
          short const which) const
	  { return &param[which]; }
	short GetParamCount () const			// get no. parameters
	  { return (short)param.size(); }

  protected:
	// types
	typedef std::vector<TParameter> TParamVector;

	//--- data
	char name[_maxEventNameLen+1];		// name of event option
	char description[_maxEventDescLen+1];	// description for event option
	TParamVector param;		// list of parameters for event option

  private:
	//--- functions
	void Initialize ();				// initialize members
	void Copy (const TEventOption &fromObj);	// copy to this
};

// ----------------------------------------------------------------------------
//	TEventOptionSet
//	Class for management of a set of event options.
//	Typically, all the event options are related, and are read from
//	a single file.
//	Files containing parameters are allowed to have any name, however,
//	suffixes are restricted to the file type.
//	Names are checked for suffix. If "nc" then assumed to be netCDF.
//	If "100" then assumed to be a Century 4 parameter file.
class TEventOptionSet
{
  public:
	//--- constructors and destructor
	TEventOptionSet (
	  int const useKey)				// event type for set
	  : key (useKey)
	  {
	    Initialize ();
	  }
	TEventOptionSet (
	  int const useKey,				// event type for set
	  TEH::TFileName const & newFileName);		// source file name
	TEventOptionSet (
	  int const useKey,				// event type for set
	  char const * const newFileName);		// source file name
	TEventOptionSet (
	  int const useKey,				// event type for set
	  std::string const newFileName);		// source file name
	~TEventOptionSet ()
	  {
	    Clear ();
	  }
	TEventOptionSet (const TEventOptionSet& object)	// copy constructor
	  : key (object.key)
	  {
	    Initialize ();
	    Copy (object);
	  }

	//--- operator overloads
	TEventOptionSet& operator = (const TEventOptionSet &obj);
	bool operator == (const TEventOptionSet &obj) const;
	bool operator != (const TEventOptionSet &obj) const
	  { return !(*this == obj); }

	//--- functions
	int GetEventSetKey () const			// Get the event type
	  { return key; }
	void Clear ();					// Clear member data
	void SetName (					// Change name of set
	  char const * const newName)
	  {
	    if ( newName )
	    	name = newName;
	    else
	    	name.clear();
	  }
	void SetDescription (				// Change description
	  char const * const newDescription)
	  {
	    if ( newDescription )
	    	description = newDescription;
	    else
	    	description.clear();
	  }
	std::string const & GetName () const		// Get set name
	  { return name; }
	std::string const & GetDescription () const	// Get set description
	  { return description; }
	std::string const & GetFileName () const	// Get file name
	  { return filePath; }
	TParamFileType GetFileType () const	// Get file type
	  { return fileType; }
	bool ImportCent4File ();		// Import Cent. 4 file
	bool FindObsoleteParameter (		// Check for obsolete parameters
	  char const* paramName);		//   parameter name to check
	short GetOptionCount () const		// Num. of options
	  { return optionCount; }
	bool AddOption (			// Adds option to set
	  TEventOption& newOption);
	TEventOption const * const GetOption (	// Get ptr. to option
	  unsigned short const optNum) const;
	TEventOption const * const GetOption (	// Get ptr. to option
	  char const * const name) const;
	bool DeleteOption (			// Delete an option
	  unsigned short const optNum);
	bool ReplaceOption (			// Replace an option
	  unsigned short const optNum,
	  TEventOption& newOpt);
	short GetParamCount () const		// Get no. parameters
	  { return numParams; }
	bool IsModified () const		// True if modified
	  { return modified; }
	char const ** OptionNameList ();      	// List of names
	char const ** OptionDescriptionList ();	// List of descriptions
	TParamFileType GetFileType (
	  TEH::TFileName const & fileName) const;
	std::string const & GetErrorMessage () const	// Get error message
	  { return errMsg; }

  protected:
	// types
	typedef std::set<TEventOption, std::less<TEventOption> > TSetOptions;
	typedef std::vector<TParamInfo> TParamInfoVector;

	//--- data
	int const key;			// unique key = event type for this set
	std::string name;		// option set name
	std::string description;	// options set description
	std::string filePath;		// path of input file (const)
	TParamFileType fileType;	// type of input file (const)
	short optionCount;		// number of event options in file
	TSetOptions options;		// set of event options
	TParamInfoVector info;		// array of parameter info structs
	short numParams;		// num. of parameters for event option
	bool modified;			// true if set has been modified
	std::string errMsg;			// error message

	//--- functions
	void ClearSets ();			// erase set data

  private:
	//--- functions
	void Initialize ();				// initialize members
	void Copy (const TEventOptionSet &fromObj);	// copy to this
	bool ConstructMe (				// Common construction
	  TEH::TFileName const & newFileName);		// source file name
};

#endif  // INC_TEventOption_h

