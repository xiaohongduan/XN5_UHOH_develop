#ifndef INC_Century_version_h
#define INC_Century_version_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  version.h
//	Class:	  TCentury
//
//	Description:
//	Monthly Century model version information.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
//	History:
//	Mar99	Tom Hilinski
//	* Added a macro for programmers of a non-standard derived TCentury
//	  class to label the version: SPECIAL_VERSION_INFO
//	Apr00	Tom Hilinski
//	* Added CENTURY4 macro handling and explanation.
//	Oct01	Tom Hilinski
//	* Added check for Borland C++ compiler for Windows.
//	* Modified display of version number to include dot separators.
//	* Removed macro for MINGW32 compiler.
//	Jul02	Tom Hilinski
//	* Added macro CenturyNickname mostly for use in messages.
//	Nov02	Tom Hilinski
//	* Added macro MONTHLY_CENTURY
//	Oct03	Tom Hilinski
//	* Removed the unused macros STANDALONE, CENTURY4.
//	* Moved all OS and GUI detection to misc/systemdefs.h, included here.
//	Feb04	Tom Hilinski
//	* Added macro "CenturyCommand".
// ----------------------------------------------------------------------------
//	Macros that can be defined externally:
//
// Macro:		Description:
// --------------	-------------------------------
// SPECIAL_VERSION_INFO	A string that should be defined if a special,
//			non-standard derived class of TCentury is built.
//			The string can contain information such as the
//			researcher's name and special version no./date.
//
//	Version macros defined here:
//	Macro:		Description:
//	--------------	-------------------------------
//	CenturyNickname	Short string name of model.
//	CenturyName	String name of model.
//	CenturyVersion	String version of model.
//	CenturyCommand	Name of the executable file used to run the model.
//
//	Environment macros defined here:
//	Macro:		Environment:
//	--------------	-------------------------------
//	MONTHLY_CENTURY	Monthly time-step Century (rather than daily Century)
// ----------------------------------------------------------------------------

//--- Century model title and version strings

// For use in this file only - MODIFY WITH EACH VERSION INCREASE
// Format: n.n.n.n where each number is
// "major version number"."minor"."release"."build number"
// This should match the values in the file "century.rc".
#define _ver_num_str "5.4.7.6"

// Monthly Century macro flag
#ifndef MONTHLY_CENTURY
#define MONTHLY_CENTURY 1
#endif

// use the following in code: CenturyName
#define CenturyNickname	"Century"
#define CenturyName 	"Century Soil Organic Matter Model"
#ifdef NDEBUG
#define _TMP_VERSION_ 	"Version " _ver_num_str " (" __DATE__ ")"
#else
#define _TMP_VERSION_ 	"Version " _ver_num_str " (" __DATE__ ") DEBUG"
#endif

// check for a derived version macro: SPECIAL_VERSION_INFO
#ifdef SPECIAL_VERSION_INFO
#define CenturyVersion	_TMP_VERSION_ \
			"\nNon-standard version of Century:\n" \
			SPECIAL_VERSION_INFO
#else
#define CenturyVersion	_TMP_VERSION_
#endif

#define CenturyCommand "century"

#include "systemdefs.h"

#endif // INC_Century_version_h
