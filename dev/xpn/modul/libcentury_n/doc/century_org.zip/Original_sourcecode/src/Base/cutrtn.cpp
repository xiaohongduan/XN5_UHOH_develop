// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  cutrtn.cpp
//	Class:	  TCenturyBase
//	Function: CuttingEvent
//
//	Description:
//	N, P, S transfers due to a cutting event.
// ----------------------------------------------------------------------------
//	History:
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::CuttingEvent (
	float *accum)	// C accumulator; // [0]=unlabeled, [1]=labeled
{
    float const minimumPoolAmount = 0.001f;

    float
	egain[NUMELEM],		//
	recres[NUMELEM];	//

    // LEAVES are returned to LITTER
    float const cgainLeaves = forrem.remf[0] * retf_ref (0, 0) * forestC.rleavc;
    if (cgainLeaves > 0.0f)
    {
	for (short element = 0; element < site.nelem; ++element)
	{
	    egain[element] = forrem.remf[0] * retf_ref (0, element + 1) *
			 nps.rleave[element];
	    recres[element] = egain[element] / cgainLeaves;
	}
	float const frc14 = forestC.rlvcis[LABELD] / forestC.rleavc;
	PartitionResidue (cgainLeaves, recres, SRFC, soilC.csrsnk, nps.esrsnk,
			  parfs.wdlig[LEAF], frc14);
    }

    // FINE BRANCHES go to DEAD FINE BRANCHES
    if ( forestC.fbrchc > minimumPoolAmount )
    {
	float const cgainFB = forrem.remf[1] * retf_ref (1,0) * forestC.fbrchc;
	ScheduleCFlow ( st->time, cgainFB,
		forestC.fbrcis[LABELD] / forestC.fbrchc, 1.0f,
		&soilC.csrsnk[UNLABL], &forestC.wd1cis[UNLABL],
		&soilC.csrsnk[LABELD], &forestC.wd1cis[LABELD],
		accum);
	for (short element = 0; element < site.nelem; ++element)
	{
		egain[element] = forrem.remf[1] * retf_ref (1, element + 1) *
				nps.fbrche[element];
		flows->Schedule (&nps.esrsnk[element], &nps.wood1e[element],
				st->time, egain[element]);
	}
    }

    // LARGE WOOD goes to DEAD LARGE WOOD
    if ( forestC.rlwodc > minimumPoolAmount )
    {
	float const cgainLW = forrem.remf[2] * retf_ref (2, 0) * forestC.rlwodc;
	ScheduleCFlow ( st->time, cgainLW,
		forestC.rlwcis[LABELD] / forestC.rlwodc, 1.0f,
		&soilC.csrsnk[UNLABL], &forestC.wd2cis[0],
		&soilC.csrsnk[LABELD], &forestC.wd2cis[LABELD],
		accum);
	for (short element = 0; element < site.nelem; ++element)
	{
		egain[element] = forrem.remf[2] * retf_ref (2, element + 1) *
				nps.rlwode[element];
		flows->Schedule (&nps.esrsnk[element], &nps.wood2e[element],
				st->time, egain[element]);
	}
    }

    // Add STORAGE back
    for (short element = 0; element < site.nelem; ++element)
    {
	egain[element] =
	    forrem.remf[2] * retf_ref (2, element + 1) * nps.forstg[element];
	flows->Schedule (&nps.esrsnk[element], &metabe_ref (SRFC, element),
			 st->time, egain[element]);
    }
}

//--- end of file cutrtn.cpp ---
