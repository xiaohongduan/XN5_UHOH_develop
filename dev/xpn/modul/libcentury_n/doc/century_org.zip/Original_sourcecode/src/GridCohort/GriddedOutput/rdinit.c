
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


/*****************************************************************************
**	rdinit.c
**
**      function to read in century.init file and
**      open corresponding weather, soil, and
**      landuse files
**
*****************************************************************************/

#include <stdio.h>
#include "gridconst.h"

/* Prototypes */
extern int lopen(FILE *fp_init); 
extern int ndopen(FILE *fp_init, int ndpyrs, float noxsc[]); 
extern int sopen(FILE *fp_init); 
extern int wopen(FILE *fp_init); 
extern int ilineparse (char *line, int value[], int maxval, FILE *fp_init);

/* Global Variables */
int curr_row = 0;
int veg_class[MAXLU];
int no_of_lu;
int t_index;
int wrepeat;
char history[HISTL+1];

int
rdinit_(int row[2], int col[2], int *spinup, int *savall,
          int *dobfrq, int *dondep, float *qtime, float *pltime,
          float *pltfrq, float *frcwet, int *ndpyrs,
          int *rseed, float noxsc[200], int *transtrt, int *nolu,
          int *co2strt, int calendar_year[2], float lat[2],
          float lon[2], float *spacing, int *simtype)
{
   char line[MAXL+1];
   int i;
   FILE *fp_init;
   int initok = 1;
   int wthok = 1;
   int soilok = 1;
   int luok = 1;
   int ndok = 1;
   int tranok = 1;

   /* Initialize number of years of deposition */
   *ndpyrs = 0;

   initok = ((fp_init =  fopen("century.init","r")) != NULL);
   if (!initok) return initok;

  /* If history string goes beyond 60 characters, the subsequent reads are offset 
   * Increase HISTL to 200, save room for timestamp to be appended to history string 
   *   -mdh 8/12/98 
   */

   /* fgets(history, 60, fp_init); */
   fgets(history, HISTL-60, fp_init);
   printf("history = %s\n", history);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%f%f", &lat[0], &lon[0]);
   printf("upper left hand corner: lat = %1f, lon = %1f\n", lat[0], lon[0]);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%f%f", &lat[1], &lon[1]);
   printf("lower right hand corner: lat = %1f, lon = %1f\n", lat[1], lon[1]);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%f", spacing);
   printf("spacing = %1f\n", *spacing);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%d", simtype);
   printf("simtype = %1d\n", *simtype);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%f", qtime);
   printf("qtime = %f\n", *qtime);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%f", pltime);
   printf("pltime = %f\n", *pltime);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%f", pltfrq);
   printf("pltfrq = %f\n", *pltfrq);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%d", spinup);
   printf("spinup = %1d\n", *spinup);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%d", savall);
   printf("savall = %1d\n", *savall);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%d", dobfrq);
   printf("dobfrq = %1d\n", *dobfrq);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%d", transtrt);
   printf("transtrt = %1d\n", *transtrt);
   
   fgets(line, MAXL, fp_init);
   sscanf(line, "%d", &t_index);
   printf("t_index = %1d\n", t_index);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%d", &wrepeat);
   printf("wrepeat = %1d\n", wrepeat);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%d", dondep);
   printf("dondep = %1d\n", *dondep);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%d", ndpyrs);
   printf("ndpyrs = %1d\n", *ndpyrs);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%f", frcwet);
   printf("frcwet = %f\n", *frcwet);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%d", rseed);
   printf("rseed = %1d\n", *rseed);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%d", co2strt);
   printf("co2strt = %1d\n", *co2strt);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%d", &calendar_year[0]);
   printf("calendar_year = %1d\n", calendar_year[0]);

   fgets(line, MAXL, fp_init);
   sscanf(line, "%d", &calendar_year[1]);
   printf("calendar_year = %1d\n\n", calendar_year[1]);

   /* Determine which landuse to run */
   fgets(line, MAXL, fp_init);
   fgets(line, MAXL, fp_init);
   no_of_lu = ilineparse(line, veg_class, (int)MAXLU, fp_init);
   /* NOLU is used in the FORTRAN coded stochastic burning */
   *nolu = no_of_lu;

   /* Open mean climate file */
   wthok = wopen(fp_init);

   /* if (wthok == 1) opnerr(); */

   /* Open landuse file and set to first value */
   luok = lopen(fp_init);

   /* Open soils files and set to first value */
   soilok = sopen(fp_init);

   /* If running an NDEP simulation for ROB */
   if (*dondep == 1)
   {
	/* Open Nitrogen Deposition file */
   	ndok = ndopen(fp_init, *ndpyrs, noxsc);
   }
   else
   {
        for (i=0; i<4; i++) fgets(line, MAXL, fp_init);
   }

   /* Open Geographic Information file */
   GeogOpen(fp_init, row, col);

   /* Fill mask with cell values */
   Mask2Cell();

   /* Read latitude and longitude from geog.nc file - cak 09/10/01 */
   ReadLatLon();

   /* Open Transient Climate files */
   if (*transtrt >= 0)
       tranok = TranwOpen(fp_init);

   /* Close century.init file */
   fclose(fp_init);
   return 1;

}
