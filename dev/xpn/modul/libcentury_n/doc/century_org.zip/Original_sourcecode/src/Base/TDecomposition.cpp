// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TDecomposition.cpp
//	Class:	  TDecomposition
//
//	Description:
//	Class for plant decomposition.
//	Members were extracted from class TCenturyBase.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, April 2004
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TLeachOrganicC.h"
#include "TDecomposition.h"
#include "TCenturySoil.h"
#include "arraydefs.h"
#include <algorithm>
#include <cmath>

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

char const * const TDecomposition::version =		// class version number
	"1.0.2";

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

TDecomposition::TDecomposition (
	// Instances of Century submodels
	TLeachOrganicC & useLeachOC,
	TCenturySoil & useSoil,
	TSoilFlowsBase & useSoilFlows,
	TMicrobialBase & useMicrobial,
	// Century internal data
	TSimTime const & useSimTime,
	TFixed const & useFixed,
	Tparfs const & useParfs,
	Tcomput & useComput,
	TSite & useSite,
	// Century output variables
	TCO2 & useCo2,
	TForestC & useForestC,
	TNPS & useNps,
	TSoilC & useSoilC,
	TWaterTemp const & useWT,
	// other
	TSystemType const systemType)
	: TFlowsSchedulable (),
	  leachOC (useLeachOC),
	  soil (useSoil),
	  soilFlows (useSoilFlows),
	  microbial (useMicrobial),
	  simTime (useSimTime),
	  fixed (useFixed),
	  parfs (useParfs),
	  comput (useComput),
	  site (useSite),
	  co2 (useCo2),
	  forestC (useForestC),
	  nps (useNps),
	  soilC (useSoilC),
	  wt (useWT)
{
	decompSystem.Type() = systemType;	// initial decomp system
	// can't use fill_n cuz loop wants to decrement NUMELEM
	// std::fill_n (cemicb, NUMELEM, 0.0f);
	std::fill (cemicb, cemicb + NUMELEM, 0.0f);
}

TDecomposition::TDecomposition (		// copy constructor
	TDecomposition const & object,		//   object to copy
	// Instances of Century submodels - refs to owner's objects
	TLeachOrganicC & useLeachOC,
	TCenturySoil & useSoil,
	TSoilFlowsBase & useSoilFlows,
	TMicrobialBase & useMicrobial,
	// Century internal data
	TSimTime const & useSimTime,
	TFixed const & useFixed,
	Tparfs const & useParfs,
	Tcomput & useComput,
	TSite & useSite,
	// Century output variables
	TCO2 & useCo2,
	TForestC & useForestC,
	TNPS & useNps,
	TSoilC & useSoilC,
	TWaterTemp const & useWT,
	// other
	TSystemType const systemType)
	: TFlowsSchedulable (object),		// gets object to copy
	  leachOC (useLeachOC),		// get refs to owner's objects
	  soil (useSoil),
	  soilFlows (useSoilFlows),
	  microbial (useMicrobial),
	  simTime (useSimTime),
	  fixed (useFixed),
	  parfs (useParfs),
	  comput (useComput),
	  site (useSite),
	  co2 (useCo2),
	  forestC (useForestC),
	  nps (useNps),
	  soilC (useSoilC),
	  wt (useWT)
{
	decompSystem.Type() = systemType;	// initial decomp system
	std::copy (object.cemicb, object.cemicb + NUMELEM, cemicb);
}

TDecomposition::TDecomposition (			// copy constructor
	TDecomposition const & object)
	: TFlowsSchedulable (object),		// gets owner object to copy
	  leachOC (object.leachOC),		// get refs to owner's objects
	  soil (object.soil),
	  soilFlows (object.soilFlows),
	  microbial (object.microbial),
	  simTime (object.simTime),
	  fixed (object.fixed),
	  parfs (object.parfs),
	  comput (object.comput),
	  site (object.site),
	  co2 (object.co2),
	  forestC (object.forestC),
	  nps (object.nps),
	  soilC (object.soilC),
	  wt (object.wt)
{
	decompSystem.Type() = object.decompSystem.Type();
	std::copy (object.cemicb, object.cemicb + NUMELEM, cemicb);
}

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

void TDecomposition::Clear ()				// "Clear" data members
{
	TFlowsSchedulable::Clear ();
	// can't use fill_n cuz loop wants to decrement NUMELEM
	// std::fill_n (cemicb, NUMELEM, 0.0f);
	std::fill (cemicb, cemicb + NUMELEM, 0.0f);
}

//	InitializeSOMDecomp
//	Initialize the decomposition submodel.
//	Sets the C/E ratios for new material created during lignin
//	decomposition.
void TDecomposition::InitializeSOMDecomp ()
{
    float const biocnv[2] = 	// biomass conversion factor...
    {
	2.5f, 			//   for non-wood
	2.0f			//   for wood
    };

    // For each element: N, P, S
    for (short element = 0; element < site.nelem; ++element)
    {
	// cemicb = slope of the regression line for C/E of som1
	//    where pcemic(0,element) = maximum C/E of new som1
	//      pcemic(1,element) = minimum C/E of new som1
	//      pcemic(2,element) = minimum E content of decomposing
	//                      material that gives minimum C/E
	//    pcemic is a fixed parameter
	cemicb[element] =
		(pcemic_ref (1, element) - pcemic_ref (0, element)) /
		pcemic_ref (2, element);

	// Ratios for new som1 from decomposition of AG structural
	rnewas_ref (element, 0) =
		AboveGroundDecompRatio (struce_ref (SRFC, element),
					soilC.strucc[SRFC], biocnv[0], element);

	// Ratio for new SOM2 from decomposition of AG strutural
	float const radds1 = rad1p_ref (0, element) + rad1p_ref (1, element) *
		 (rnewas_ref (element, 0) - pcemic_ref (1, element));
	rnewas_ref (element, 1) = std::max ( rnewas_ref (element, 0) + radds1,
				    rad1p_ref (2, element) );

	// Ratio for new SOM1 from decomposition of BG structural
	rnewbs_ref (element, 0) = varat1_ref (0, element);

	// Ratio for new SOM2 from decomposition of BG structural
	rnewbs_ref (element, 1) = varat2_ref (0, element);

	// Check to see if you are running a forest submodel.  -rm 11/91
	if ( !decompSystem.IsCropGrass() )
	{
	    // Ratio for new SOM1 from decomposition of Fine Branches
	    rneww1_ref (element, 0) =
		AboveGroundDecompRatio (nps.wood1e[element],
					forestC.wood1c, biocnv[1], element);

	    // Ratio for new SOM2 from decomposition of Fine Branches
	    rneww1_ref (element, 1) = rneww1_ref (element, 0) + radds1;
	    rneww1_ref (element, 1) = std::max (rneww1_ref (element, 1),
				       rad1p_ref (2, element));

	    // Ratio for new SOM1 from decomposition of Large Wood
	    rneww2_ref (element, 0) =
		AboveGroundDecompRatio (nps.wood2e[element],
					forestC.wood2c, biocnv[1], element);

	    // Ratio for new SOM2 from decomposition of Large Wood
	    rneww2_ref (element, 1) = rneww2_ref (element, 0) + radds1;
	    rneww2_ref (element, 1) = std::max (rneww2_ref (element, 1),
					rad1p_ref (2, element));

	    // Ratio for new SOM1 from decomposition of Coarse Roots
	    rneww3_ref (element, 0) = varat1_ref (0, element);

	    // Ratio for new SOM2 from decomposition of Coarse Roots
	    rneww3_ref (element, 1) = varat2_ref (1, element);
	}
    }
    // Compute ORGLCH for use in SOMDEC.
    leachOC.CalcTextureEffect ( soil.SandFraction().WtdMean (
				0.0f, wt.simDepth,
				soil.Depth(), soil.Thickness() ) );
} // InitializeSOMDecomp

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	DecomposeLitter
//	Decompose structural and metabolic material for surface and soil.
void TDecomposition::DecomposeLitter (
	float const dtm,	// decomposition time step (fraction of year)
	float const anerb,	// Effect of soil anaerobic conditions
	float const defac)	// Decomposition factor
				//    based on water and temperature
{
    float
      accum[ISOS] = { 0.0f, 0.0f },		// Cumulative C
      rceto1[NUMELEM] = { 0.0f, 0.0f, 0.0f },	// C:E surface metabolic residue
      tcflow = 0.0f;				// total C flow (g m2)

    // Factor to convert C to biomass is 2.5 for everything but wood.
    float const biocnv = 2.5f;

    // Surface STRUCTURAL Material
    if ( AmountIsSignificant (soilC.strucc[SRFC]) )
    {
	// Compute total C flow out of structural in layer SRFC
	// where
	//   strucc(SRFC) = current value for total structural C (grams)
	//	in layer SRFC
	//   strmax(SRFC) is the maximum amount of structural C  (grams)
	//	in layer SRFC that will decompose.
	//   dec1(SRFC) is the intrinsic decomposition rate of
	//	structural C (a fixed parameter)
	//   pligst is a fixed parameter that represents the effect
	// 	of lignin-to-structural-ratio on structural decomposition
	//   strlig(SRFC) is the lignin content of surface structural
	//	residue (grams lignin/grams biomass)
	tcflow = std::min (soilC.strucc[SRFC],
		      fixed.strmax[SRFC]) * defac * fixed.dec1[SRFC] *
			std::exp (-fixed.pligst[SRFC] * soilC.strlig[SRFC]) *
			dtm;

	// Decompose structural into som1 and som2 with CO2 loss.
	// Changed csrsnk to st1c2 (10/92)
	DecomposeLignin (soilC.strlig[SRFC], SRFC, NUMLAYERS,
			 comput.rnewas, tcflow,
			 soilC.strucc, co2.st1c2, soilC.strcis, nps.struce,
			 nps.gromin, nps.strmnr, co2.resp);
    }

    // Soil STRUCTURAL Material
    if ( AmountIsSignificant (soilC.strucc[SOIL]) )
    {
	// Compute total C flow out of structural in layer SOIL
	// where
	//   strucc(SOIL)  is the current value for total structural C
	//           (grams C) in layer SOIL
	//   strmax(SOIL) is the maximum amount of structural C in
	//          layer SOIL that will decompose (grams C).
	//   dec1(SOIL) is the intrinsic decomposition rate of
	//        structural C (a fixed parameter)
	//   pligst is a fixed parameter that represents the effect
	//      of lignin-to-structural-ratio on structural
	//      decomposition
	//   strlig(SOIL) is the lignin content of soil structural
	//         residue (grams lignin/grams biomass)
	//   cltfac(4) is the cultivation factor for soil
	//         structural material (set in cycle)
	// Added impact of soil anerobic conditions -rm 12/91
	tcflow = std::min (soilC.strucc[SOIL],
		      fixed.strmax[SOIL]) * defac * fixed.dec1[SOIL] *
		      std::exp (-fixed.pligst[SOIL] * soilC.strlig[SOIL]) *
	    	      soilC.cltfac[3] * anerb * dtm;

	// Decompose structural into som1 and som2 with CO2 loss.
	// Changed csrsnk to st2c2 (10/92)
	DecomposeLignin (soilC.strlig[SOIL], SOIL, NUMLAYERS,
			 comput.rnewbs, tcflow,
			 soilC.strucc, co2.st2c2, soilC.strcis, nps.struce,
		 	 nps.gromin, nps.strmnr, co2.resp);
    }
    // End of Structural Decomposition

    // METABOLIC Material
    for (short layer = SRFC; layer <= SOIL; ++layer)
    {
	if ( !AmountIsSignificant (soilC.metabc[layer]) )
		continue;

	// Determine C/E ratios for flows to SOM1
	for (short element = 0; element < site.nelem; ++element)
	{
		// surface metabolic residue
		if (layer == SRFC)
		    rceto1[element] = AboveGroundDecompRatio (
		    			metabe_ref (layer, element),
					soilC.metabc[layer], biocnv, element);
		// soil metabolic residue
		else
		    rceto1[element] =
		    	BelowGroundDecompRatio (nps.aminrl[element],
						fixed.varat1, element);
	}

	// Compute total C flow out of metabolic in layer layer
	// where:
	//   tcflow is grams C
	//   metabc(layer) is the current value for total metabolic C
	// (grams C) in layer layer
	//   dec2(layer) is the intrinsic decomposition rate of
	// metabolic C
	tcflow = soilC.metabc[layer] * defac * fixed.dec2[layer] * dtm;

	// Added impact of soil anerobic conditions -rm 12/91
	if (layer == SOIL)
		tcflow *= anerb;

	// Make sure metab does not go negative.
	tcflow = std::min ( tcflow, soilC.metabc[layer] );

	// If decomposition can occur,
	if ( CanDecompose (soilC.metabc[layer], nps.metabe, NUMLAYERS,
			   layer, rceto1) )
	{
		float co2Loss = tcflow * fixed.pmco2[layer];	// CO2 loss
		// Changed csrsnk to mt1c2, mt2c2 (10/92)
		if (layer == SRFC)
		    microbial.Respiration (
		    	co2Loss, NUMLAYERS, layer,
			soilC.metabc, soilC.metcis, co2.mt1c2,
			co2.resp, nps.metabe, nps.gromin, nps.metmnr,
			wt.simDepth );
		else // layer == SOIL
		    microbial.Respiration (
		    	co2Loss, NUMLAYERS, layer,
			soilC.metabc, soilC.metcis, co2.mt2c2,
			co2.resp, nps.metabe, nps.gromin, nps.metmnr,
			wt.simDepth );

		// Decompose metabolic C to som1
		float cfmes1 = tcflow - co2Loss;

		// Partition and schedule C flows by isotope
		ScheduleCFlow (
		    simTime.time, cfmes1,
		    metcis_ref (layer, LABELD) / soilC.metabc[layer], 1.0f,
		    &metcis_ref (layer, UNLABL), &som1ci_ref (layer, UNLABL),
		    &metcis_ref (layer, LABELD), &som1ci_ref (layer, LABELD),
		    accum );

		// Compute and schedule N, P, and S flows and
		//   update mineralization accumulators.
		for (short element = 0; element < site.nelem; ++element)
		{
		    float const minFlow =
		    	ScheduleNPSFlow (
		    		(TMineralElements)element,
		    		cfmes1, 			// E flow
		    		soilC.metabc[layer],		// total C in A
		    		rceto1[element],		// C:E in flow
		    		&metabe_ref (layer, element),	// from
				&som1e_ref (layer, element),	// to
				wt.simDepth);
		    UpdateMineralAccum ( minFlow,
			nps.gromin[element],
			metmnr_ref (layer, element) );
		}
	}
    }
} // DecomposeLitter

//	DecomposeSurfaceSOM1
//	Step 1. Surface SOM1 decomposes to SOM2 with CO2 loss
void TDecomposition::DecomposeSurfaceSOM1 (
	float const dtDecomp,		// decomposition time step
	float const anerb,		// Effect of soil anaerobic conditions
	float const defac)		// Decomposition factor
{
    if ( AmountIsSignificant (soilC.som1c[SRFC]) )
    {
	// Determine C/E ratios for flows to som2
	float rceto2[NUMELEM] =			// C/E ratios for flows to SOM2
		{ 0.0f, 0.0f, 0.0f };
	for (short element = 0; element < site.nelem; ++element)
	{
	    Assert (som1e_ref(SRFC, element) != 0.0f);
	    float const radds1 =
		rad1p_ref (INTCPT, element) + rad1p_ref (SLOPE, element) *
		(soilC.som1c[SRFC] / som1e_ref (SRFC, element) -
		 pcemic_ref (1, element));
	    rceto2[element] =
		soilC.som1c[SRFC] / som1e_ref (SRFC, element) + radds1;
	    rceto2[element] =
	    	std::max ( rceto2[element], rad1p_ref (2, element) );
	}

	// If decomposition can occur, schedule flows associated with /
	// respiration and decomposition
	if (CanDecompose(soilC.som1c[SRFC], nps.som1e, NUMLAYERS, SRFC, rceto2))
	{
	    // Compute total C flow out of surface microbes.
	    // where
	    //   som1c(SRFC) =  unlabeled and labeled C in surface microbes
	    //                (som1ci(SRFC,1)+som1ci(SRFC,2))
	    //   dec3(SRFC)  =  intrinsic decomposition rate of surface microbes
	    // = soilC.som1c[SRFC] * defac * fixed.dec3[SRFC] * dtDecomp;
	    float const microbeC =
		microbial.CFromActiveSOMSurface (
			soilC.som1c[SRFC], defac, dtDecomp );

	    // CO2 loss - Compute and schedule respiration flows.
	    // where
	    // p1co2(SRFC) is set to p1co2a(SRFC) in prelim.
	    // p1co2a(SRFC) is a fixed parameter;

	    float const co2Loss = microbeC * comput.p1co2[SRFC];
	    microbial.Respiration (
	    	co2Loss, NUMLAYERS, SRFC,
		soilC.som1c, soilC.som1ci, co2.s11c2,
		co2.resp, nps.som1e, nps.gromin, nps.s1mnr,
		wt.simDepth );

	    // Decompose Surface SOM1 to SOM2
	    // cfsfs2 is C Flow from SurFace som1 to Som2
	    float cfsfs2 = microbeC - co2Loss;

	    // Partition and schedule C flows by isotope
	    ScheduleCFlow (
	    	simTime.time, cfsfs2,
		som1ci_ref (SRFC, LABELD) / soilC.som1c[SRFC], 1.0f,
		&som1ci_ref (SRFC, UNLABL), &soilC.som2ci[UNLABL],
		&som1ci_ref (SRFC, LABELD), &soilC.som2ci[LABELD],
		comput.accum );

	    // Compute and schedule N, P, and S flows.
	    // Update mineralization accumulators.
	    for (short element = 0; element < site.nelem; ++element)
	    {
		float const mineralEFlow =
			ScheduleNPSFlow (
		    		(TMineralElements)element,
				cfsfs2, 			// E flow
				soilC.som1c[SRFC],		// total C in A
				rceto2[element], 		// C:E in flow
				&som1e_ref (SRFC, element),	// E source
				&nps.som2e[element],		// E sink
				wt.simDepth );
		UpdateMineralAccum (mineralEFlow, nps.gromin[element],
				    s1mnr_ref (SRFC, element));
	    }
	}
    }
} // DecomposeSurfaceSOM1

//	DecomposeSoilSOM1
//	Step 2. Soil SOM1 decomposes to SOM2 and SOM3 with CO2 loss and
//	possible leaching of organics.
void TDecomposition::DecomposeSoilSOM1 (
	float const dtDecomp,		// decomposition time step
	float const anerb,		// Effect of soil anaerobic conditions
	float const defac)		// Decomposition factor
{
    if ( AmountIsSignificant (soilC.som1c[SOIL]) )
    {
	// Determine C/E ratios for flows to som2
	float rceto2[NUMELEM] =			// C/E ratios for flows to SOM2
		{ 0.0f, 0.0f, 0.0f };
	for (short element = 0; element < site.nelem; ++element)
	{
	    rceto2[element] =
	    	BelowGroundDecompRatio (
	    		nps.aminrl[element], fixed.varat2, element);
	}

	// If soil som1 can decompose to som2, it will also go to som3.
	// If it can't go to som2, it can't decompose at all.
	// If decomposition can occur,
	if (CanDecompose(soilC.som1c[SOIL], nps.som1e, NUMLAYERS, SOIL, rceto2))
	{
	    // Compute total C flow out of soil microbes.
	    // Added impact of soil anaerobic conditions -rm 12/91
	    // where
	    //   som1c(SOIL) = unlabeled and labeled C in soil microbes
	    //               (som1ci(SOIL,1)+som1ci(SOIL,2))
	    //   dec3(SOIL)  = intrinsic decomposition rate of
	    //               soil microbes
	    //   cltfac(1)   = cultivation factor for som1
	    //               (set in cycle)
	    //   eftext      = effect of soil texture on the soil microbe
	    //               decomposition rate (computed in prelim)
	    // = soilC.som1c[SOIL] * defac * fixed.dec3[SOIL] *
	    //   soilC.cltfac[0] * comput.eftext * anerb * dtDecomp;
	    float const microbeC =
		microbial.CFromActiveSOMSoil (
			soilC.som1c[SOIL], defac, dtDecomp,
			soilC.cltfac[0], anerb );

	    // CO2 Loss - Compute and schedule respiration flows
	    // where
	    //   p1co2(SOIL) is computed in prelim as a function of
	    //	 fixed parameters
	    //   p1co2a(SOIL) and p1co2b(SOIL) and soil texture.
	    // Changed csrsnk to s21c2 (10/92)
	    float const co2Loss = microbeC * comput.p1co2[SOIL];
	    microbial.Respiration (
	    	co2Loss, NUMLAYERS, SOIL,
	    	soilC.som1c, soilC.som1ci, co2.s21c2,
	    	co2.resp, nps.som1e, nps.gromin, nps.s1mnr,
		wt.simDepth );

	    // Decompose Soil SOM1 to SOM3
	    // The fraction of microbeC that goes to SOM3 is a function of
	    // clay content (fps1s3 is computed in prelim).
	    // cfs1s3 = fraction of C SOM1 going to SOM3
	    float const cfs1s3 = microbeC * comput.fps1s3 *
	    			(fixed.animpt * (1.0f - anerb) + 1.0f);

	    // Partition and schedule C flows by isotope
	    ScheduleCFlow (
	    	simTime.time, cfs1s3,
	    	som1ci_ref (SOIL, LABELD) / soilC.som1c[SOIL], 1.0f,
		&som1ci_ref (SOIL, UNLABL), &soilC.som3ci[UNLABL],
		&som1ci_ref (SOIL, LABELD), &soilC.som3ci[LABELD],
		comput.accum);

	    // Compute and schedule N, P, and S flows and
	    // update mineralization accumulators.
	    float rceto3[NUMELEM] =		// C/E ratios for flows to SOM3
		{ 0.0f, 0.0f, 0.0f };
	    for (short element = 0; element < site.nelem; ++element)
	    {
		rceto3[element] = BelowGroundDecompRatio (nps.aminrl[element],
					   fixed.varat3, element);
		float const mineralEFlow =
			ScheduleNPSFlow (
				(TMineralElements)element,
				cfs1s3, 			// E flow
				soilC.som1c[SOIL],		// total C in A
				rceto3[element], 		// C:E in flow
				&som1e_ref (SOIL, element),	// E source
				&nps.som3e[element],		// E sink
				wt.simDepth);
		UpdateMineralAccum (mineralEFlow, nps.gromin[element],
				    s1mnr_ref (SOIL, element));
	    }

	    // Decompose Soil SOM1 to SOM2.
	    // SOM2 gets what's left of microbeC.
	    // Leach organic C.
	    float const leachedC =
		leachOC.Leach (
		    microbeC,
		    soil.GetWaterTransferred (
					soil.GetLayerIndex (wt.simDepth) ) ) /
		(float) fixed.ntspm;
	    // "C Flow Som1 to Som2"
	    float const cfs1s2 = microbeC - co2Loss - cfs1s3 - leachedC;

	    // Partition and schedule C flows by isotope
	    ScheduleCFlow (
	    	simTime.time, cfs1s2,
		som1ci_ref (SOIL, LABELD) / soilC.som1c[SOIL], 1.0f,
		&som1ci_ref (SOIL, UNLABL), &soilC.som2ci[UNLABL],
		&som1ci_ref (SOIL, LABELD), &soilC.som2ci[LABELD],
		comput.accum);

	    // Compute and schedule N, P, and S flows and
	    // update mineralization accumulators.
	    for (short element = 0; element < site.nelem; ++element)
	    {
		float const mineralEFlow =
			ScheduleNPSFlow (
				(TMineralElements)element,
				cfs1s2, 			// E flow
				soilC.som1c[SOIL],		// total C in A
				rceto2[element], 		// C:E in flow
				&som1e_ref (SOIL, element),	// E source
				&nps.som2e[element],		// E sink
				wt.simDepth );
		UpdateMineralAccum (mineralEFlow, nps.gromin[element],
				    s1mnr_ref (SOIL, element));
	    }
	}
    }
} // DecomposeSoilSOM1

//	DecomposeSOM2
//	Step 3. SOM2 decomposes to soil SOM1 and SOM3 with CO2 loss
void TDecomposition::DecomposeSOM2 (
	float const dtDecomp,		// decomposition time step
	float const anerb,		// Effect of soil anaerobic conditions
	float const defac)		// Decomposition factor
{
    if ( AmountIsSignificant (soilC.som2c) )
    {
	// Determine C/E ratios for flows to SOM1
	float rceto1[NUMELEM] =		// C/E ratios for flows to SOM1
		{ 0.0f, 0.0f, 0.0f };
	for (short element = 0; element < site.nelem; ++element)
	    rceto1[element] = BelowGroundDecompRatio (
				nps.aminrl[element], fixed.varat1, element);

	// Compute total C flow out of SOM2C
	// Added impact of soil anaerobic conditions -rm 12/91
	// where
	// dec5      = intrinsic decomposition rate of som2
	// cltfac(2) = cultivation factor for som2 (set in cycle)
	float const tcflow =
		soilC.som2c * defac * fixed.dec5 * soilC.cltfac[1] *
		anerb * dtDecomp;

	// If som2 can decompose to som1, it will also go to som3.
	// If it can't go to som1, it can't decompose at all.
	// If decomposition can occur,
	if ( CanDecompose (soilC.som2c, nps.som2e, 1, SRFC, rceto1) )
	{
	    // CO2 loss - Compute and schedule respiration flows
	    float const co2Loss = tcflow * fixed.p2co2;

	    // Changed csrsnk to s2c2 (10/92)
	    microbial.Respiration (
	    	co2Loss, 1, SRFC,
		&soilC.som2c, soilC.som2ci, co2.s2c2,
		co2.resp, nps.som2e, nps.gromin, nps.s2mnr,
		wt.simDepth );

	    // Rearranged the order of calculation.  There is a calculated
	    // impact of clay on the decomposition of som2 to som3.
	    // -rm 12/91
	    // Decompose SOM2 to SOM3, SOM3 gets what's left of tcflow.
	    // Added impact of soil anaerobic conditions -rm 12/91
	    float cfs2s3 = tcflow * comput.fps2s3 *
			(fixed.animpt * (1.0f - anerb) + 1.0f);

	    // Partition and schedule C flows by isotope
	    ScheduleCFlow (
	    	simTime.time, cfs2s3,
	    	soilC.som2ci[LABELD] / soilC.som2c, 1.0f,
		&soilC.som2ci[UNLABL], &soilC.som3ci[UNLABL],
		&soilC.som2ci[LABELD], &soilC.som3ci[LABELD],
		comput.accum );

	    // Compute and schedule N, P, and S flows and
	    // update mineralization accumulators.
	    for (short element = 0; element < site.nelem; ++element)
	    {
		float const rcetob =
			BelowGroundDecompRatio (
				nps.aminrl[element], fixed.varat3, element);
		float const mineralEFlow =
			ScheduleNPSFlow (
				(TMineralElements)element,
				cfs2s3, 			// E flow
				soilC.som2c,			// total C in A
				rcetob, 			// C:E in flow
				&nps.som2e[element],		// E source
				&nps.som3e[element],		// E sink
				wt.simDepth );
		UpdateMineralAccum (mineralEFlow, nps.gromin[element],
					nps.s2mnr[element]);
	    }

	    // Decompose SOM2 to SOM1
	    // Added impact of soil anaerobic conditions -rm 12/91
	    float cfs2s1 = tcflow - co2Loss - cfs2s3;

	    // Partition and schedule C flows by isotope
	    ScheduleCFlow (
	    	simTime.time, cfs2s1,
	    	soilC.som2ci[LABELD] / soilC.som2c, 1.0f,
		&soilC.som2ci[UNLABL], &som1ci_ref (SOIL, UNLABL),
		&soilC.som2ci[LABELD], &som1ci_ref (SOIL, LABELD),
		comput.accum );

	    // Compute and schedule N, P, and S flows and
	    // update mineralization accumulators.
	    for (short element = 0; element < site.nelem; ++element)
	    {
		float const mineralEFlow =
			ScheduleNPSFlow (
				(TMineralElements)element,
				cfs2s1, 			// E flow
				soilC.som2c,			// total C in A
				rceto1[element], 		// C:E in flow
				&nps.som2e[element],		// E source
				&som1e_ref (SOIL, element),	// E sink
				wt.simDepth );
		UpdateMineralAccum ( mineralEFlow, nps.gromin[element],
					nps.s2mnr[element] );
	    }
	}
    }
} // DecomposeSOM2

//	DecomposeSOM3
//	Step 4. SOM3 decomposes to soil SOM1 with CO2 loss.
void TDecomposition::DecomposeSOM3 (
	float const dtDecomp,		// decomposition time step
	float const anerb,		// Effect of soil anaerobic conditions
	float const defac)		// Decomposition factor
{
    if ( AmountIsSignificant (soilC.som3c) )
    {
	// Determine C/E ratios for flows to SOM1.
	float rceto1[NUMELEM] =			// C/E ratios for flows to SOM1
		{ 0.0f, 0.0f, 0.0f };
	for (short element = 0; element < site.nelem; ++element)
	    rceto1[element] = BelowGroundDecompRatio (nps.aminrl[element],
	    					  fixed.varat1, element);

	// Compute total C flow out of SOM3C
	// where
	// dec4      = intrinsic decomposition rate of som2
	// cltfac(3) = cultivation factor for som3 (set in cycle)
	// If decomposition can occur,
	float const tcflow =
		soilC.som3c * defac * fixed.dec4 *
		soilC.cltfac[2] * anerb * dtDecomp;
	if ( CanDecompose (soilC.som3c, nps.som3e, 1, SRFC, rceto1) )
	{
	    // CO2 loss - Compute and schedule respiration flows.
	    float const cf3co2 = tcflow * fixed.p3co2 * anerb;

	    // Changed csrsnk to s3c2 (10/92)
	    microbial.Respiration (
	    	cf3co2, 1, SRFC,
		&soilC.som3c, soilC.som3ci, co2.s3c2,
		co2.resp, nps.som3e, nps.gromin, nps.s3mnr,
		wt.simDepth );

	    // Decompose SOM3 to soil SOM1
	    float const cfs3s1 = tcflow - cf3co2;

	    // Partition and schedule C flows by isotope
	    ScheduleCFlow (
		simTime.time, cfs3s1,
		soilC.som3ci[LABELD] / soilC.som3c, 1.0f,
		&soilC.som3ci[UNLABL], &som1ci_ref (SOIL, UNLABL),
		&soilC.som3ci[LABELD], &som1ci_ref (SOIL, LABELD),
		comput.accum );

	    // Compute and schedule N, P, and S flows and
	    // update mineralization accumulators.
	    for (short element = 0; element < site.nelem; ++element)
	    {
		float const mineralEFlow =
			ScheduleNPSFlow (
				(TMineralElements)element,
				cfs3s1, 			// E flow
				soilC.som3c,			// total C in A
				rceto1[element], 		// C:E in flow
				&nps.som3e[element],		// E source
				&som1e_ref (SOIL, element),	// E sink
				wt.simDepth );
		UpdateMineralAccum (mineralEFlow, nps.gromin[element],
					nps.s3mnr[element]);
	    }
	}
    }
} // DecomposeSOM3

//	DecomposeWood
//	Decompose wood frations.
void TDecomposition::DecomposeWood (
	float const dtDecomp,		// decomposition time step
	float const anerb,		// Effect of soil anaerobic conditions
	float const defac)		// Decomposition factor
{
    // FINE BRANCHES
    // wood1c = C in dead fine branch component of forest system (g/m2)
    // decw1 = intrinsic rate of decomposition of dead fine branches
    // wdlig(FBRCH) = lignin fraction for fine branches
    if ( AmountIsSignificant (forestC.wood1c) )
    {
	// Compute total C flow out of fine branches
	float const tcflow = forestC.wood1c * defac * parfs.decw1 *
		 std::exp ( -fixed.pligst[SRFC] * parfs.wdlig[FBRCHwdlig[]) *
		 dtDecomp;
	// Decompose fine branches into som1 and som2 with CO2 loss.
	DecomposeLignin (parfs.wdlig[FBRCH], SRFC, 1, comput.rneww1, tcflow,
		 &forestC.wood1c, soilC.csrsnk, forestC.wd1cis, nps.wood1e,
		 nps.gromin, nps.w1mnr, co2.resp);
    }

    // LARGE WOOD
    // wood2c = C in dead large wood component of forest system (g/m2)
    // decw2 = intrinsic rate of decomposition of dead large wood
    // wdlig(LWOOD) = lignin fraction for large wood
    if ( AmountIsSignificant (forestC.wood2c) )
    {
	// Compute total C flow out of large wood
	float const tcflow = forestC.wood2c * defac * parfs.decw2 *
		 std::exp (-fixed.pligst[SRFC] * parfs.wdlig[LWOOD]) *
		 dtDecomp;

	// Decompose large wood into som1 and som2 with CO2 loss.
	DecomposeLignin (parfs.wdlig[LWOOD], SRFC, 1, comput.rneww2, tcflow,
		&forestC.wood2c, soilC.csrsnk, forestC.wd2cis, nps.wood2e,
		nps.gromin, nps.w2mnr, co2.resp);
    }

    // COARSE ROOTS
    // wood3c = C in dead coarse root component of forest system (g/m2)
    // decw3 = intrinsic rate of decomposition of dead coarse roots
    // wdlig(CROOT) = lignin fraction for coarse roots
    if ( AmountIsSignificant (forestC.wood3c) )
    {
	// Compute total C flow out of coarse roots.
	float const tcflow = forestC.wood3c * defac * parfs.decw3 *
		 std::exp (-fixed.pligst[SOIL] * parfs.wdlig[CROOT]) *
		 anerb * dtDecomp;

	// Decompose coarse roots into som1 and som2 with CO2 loss.
	DecomposeLignin (parfs.wdlig[CROOT], SOIL, 1, comput.rneww3, tcflow,
		&forestC.wood3c, soilC.csrsnk, forestC.wd3cis, nps.wood3e,
		nps.gromin, nps.w3mnr, co2.resp);
    }
} // DecomposeWood

//	DecomposeLignin
//	Decompose lignin (structural and wood).
//	Compartment to be decomposed = 'Box A'.
//	C/E ratios of new material are computed once at the beginning of
//	the simulation in InitializeSOMDecomp().
void TDecomposition::DecomposeLignin (
	float const lignin,	// lignin content of Box A
	short const layer,	// layer (values: SRFC, SOIL)
	short const numLayers,	// total number of layers for Box A;
				//   =2 for structural, metabolic, som1;
				//   =1 for som2, som3, wood compartments.
				//   2nd dim. of rnew, cstatv, elstva, netmin
	float const * const rnew,	// [NUMELEM, 2]: C/E of new material
				//   to add to som2
  	float const tcflow,	// total C flow out of Box A
	float const * const tcstva,	// [numLayers]: C in layers of Box A
  	float* const cSrcSink,	// array [ISOS]: C source/sink
	float* const cstatv,	// [numLayers, ISOS]: C for Box A;
				//   (layer,iso) represents C in layer 'layer',
				//   isotope 'iso' where =0 for unlabeled C
				//   and =1 for labeled C.
	float* const elstva,	// [numLayers,NUMELEM]: N, P, S in Box A layers
	float* const grossMin,	// array [NUMELEM]: gross mineralization
	float* const netMin,	// array [numLayers,NUMELEM]: net mineralization
 				//   for layer layer (N, P, S)
	float* const respiredC)	// Cum. C from microbial respiration (g/y);
 				//   [0] = unlabeled, [1] = labeled
{
    Assert (numLayers == 1 || numLayers == 2);
    Assert (layer == 0 || layer == 1);

#define rnew_ref(a_1,a_2) 	rnew[(a_2)*NUMELEM + a_1]
#define cstatv_ref(a_1,a_2) 	cstatv[(a_2)*(numLayers) + a_1]
#define elstva_ref(a_1,a_2) 	elstva[(a_2)*(numLayers) + a_1]
#define netMin_ref(a_1,a_2) 	netMin[(a_2)*(numLayers) + a_1]

    float accum[ISOS] = { 0.0, 0.0 };	// cumulative C (values not used)

    // In this case layer = 2 and numLayers = 1.  An error results when
    // tcstva(layer) is accessed because tcstva is dimensioned with numLayers.
    // Set activeLayer to layer and layer to 1 for the special case.
    // llyr (temporary variable) is used instead of 'layer' so that it can
    // be modified by the special case of SOIL=2 and numLayers=1.
    short const llyr =
	( ( numLayers == 1 && layer == SOIL ) ? (short) SRFC : layer );
    Assert (llyr < numLayers);

    // actual layer used when coarse roots are decomposed.
    // Used as an array index.
    short const activeLayer = layer;

    // See if Box A can decompose to som1.
    // If it can go to som1, it will also go to som2.
    // If it can't go to som1, it can't decompose at all.
    // Store the C/E ratios for what goes to SOM1 in
    // an array of correct size to be passed to CanDecompose
    float rnew1[NUMELEM];
    for (short element = 0; element < site.nelem; ++element)
	rnew1[element] = rnew_ref (element, 0);
    if ( CanDecompose (tcstva[llyr], elstva, numLayers, llyr, rnew1) )
    {
	// Decompose Box A to SOM2
	// -----------------------

	float cToSOM2 = tcflow * lignin;		// Gross C flow to som2

	// Respiration associated with decomposition to som2
	float co2Loss = cToSOM2 * fixed.rsplig;		// CO2 loss
	microbial.Respiration (
		co2Loss, numLayers, llyr,
		tcstva, cstatv, cSrcSink, respiredC, elstva, grossMin, netMin,
		wt.simDepth );

	cToSOM2 -= co2Loss;			// Net C flow to SOM2

	// Partition and schedule C flows by isotope
	ScheduleCFlow (
		simTime.time, cToSOM2,
		cstatv_ref (llyr, LABELD) / tcstva[llyr], 1.0f,
		&cstatv_ref (llyr, UNLABL), &soilC.som2ci[UNLABL],
		&cstatv_ref (llyr, LABELD), &soilC.som2ci[LABELD],
		accum);

	// Compute and schedule N, P, and S flows.
	// Update mineralization accumulators.
	for (short element = 0; element < site.nelem; ++element)
	{
	    float const minFlow =
	    	ScheduleNPSFlow (
			(TMineralElements)element,	// N, P, S
	    		cToSOM2, 			// amount of flow
	    		tcstva[llyr],			// total C in source
			rnew_ref (element, 1),		// C/E in flow
	    		&elstva_ref (llyr, element),	// source pool
			&nps.som2e[element],		// destination pool
			wt.simDepth );
	    UpdateMineralAccum (minFlow, grossMin[element],
	    			netMin_ref (llyr, element));
	}

	//  Decompose Box A to SOM1
	//  -----------------------

	float cToSOM1 = tcflow - cToSOM2 - co2Loss;	// Gross C flow to som1

	// Respiration associated with decomposition to som1
	co2Loss = cToSOM1 * fixed.ps1co2[llyr];
	microbial.Respiration (
		co2Loss, numLayers, llyr,
		tcstva, cstatv, cSrcSink, respiredC, elstva, grossMin, netMin,
		wt.simDepth );

	cToSOM1 -= co2Loss;			// Net C flow to SOM1

	// Partition and schedule C flows by isotope
	ScheduleCFlow (
		simTime.time, cToSOM1,
		cstatv_ref (llyr, LABELD) / tcstva[llyr], 1.0f,
		&cstatv_ref (llyr, UNLABL), &som1ci_ref (activeLayer, UNLABL),
		&cstatv_ref (llyr, LABELD), &som1ci_ref (activeLayer, LABELD),
		accum);

	// Compute and schedule N, P, and S flows; accumulate mineralization
	for (short element = 0; element < site.nelem; ++element)
	{
	    float const minFlow =
	    	ScheduleNPSFlow (
	    		(TMineralElements)element,
			cToSOM1, 				// E flow
			tcstva[llyr],				// total C in A
			rnew_ref (element, 0),			// C:E in flow
			&elstva_ref (llyr, element),		// from
			&som1e_ref (activeLayer, element),	// to
			wt.simDepth );
	    UpdateMineralAccum (minFlow, grossMin[element],
	    			netMin_ref (llyr, element));
	}
    }

#undef rnew_ref
#undef cstatv_ref
#undef elstva_ref
#undef netMin_ref

} // DecomposeLignin

//	AboveGroundDecompRatio
// 	Calculates the aboveground decomposition ratio.
// 	Determine C/E of new material entering 'Box B'.
// 	'E' represents N, P, or S.
// 	The C/E ratios for structural and wood can be computed once;
// 	they then remain fixed throughout the run.  The ratios for
// 	metabolic and som1 may vary and must be recomputed each time step.
// 	Returns the C/E ratio of new E;  = function of the E content of the
// 	material being decomposed.
//	Author: vek 05/91
float TDecomposition::AboveGroundDecompRatio (
	float const amountEinA,	// Amount of N, P, or S in Box A
	float const totalCinA,	// total C in Box A
	float const biocnv,	// C to biomass conversion factor
				//   (As of 05/16/91, use 2.0 for wood, 2.5
				//   for everything else.)
	short const element)	// index to element for which ratio is calc'd;
				//   0 for N, 1 for P, 2 for S
{
	float const biomass = totalCinA * biocnv;	// biomass
	float const econt =				// E/C ratio in box A
		( biomass <= 1.0e-10f ?
			0.0f :
			amountEinA / biomass );
	float const ratio =				// return value
		( econt > pcemic_ref (2, element) ?
		  pcemic_ref (1, element) :
		  pcemic_ref (0, element) + econt * cemicb[element] );
	return ratio;
}

//	BelowGroundDecompRatio
//	Determine C/E of new material entering 'Box B'.
//	Returns the C/E ratio of E; depends on available E.
float TDecomposition::BelowGroundDecompRatio (
	float const aminrl,	// Amount in layer 1 before uptake by plants.
	float const * const varat, // (0,element) =
				//   max. C/E for E entering 'Box B'
			   	//   (1,element) = min. C/E
			   	//   (2,element) = E present at min. C/E
	short const element)	// index to element; 0 = N, 1 = P, 2 = S
{
#define varat_ref(a_1,a_2)	varat[(a_2)*3 + a_1]

    float retVal;

    if (aminrl <= 0.0f)
	retVal = varat_ref (0, element);	// Set ratio to maximum allowed

    else if (aminrl > varat_ref (2, element))
	retVal = varat_ref (1, element);	// Set ratio to minimum allowed

    else	//  aminrl > 0 and <= varat(2,element)
 	retVal = ( 1.0f - aminrl / varat_ref (2, element) ) *
 		 ( varat_ref (0, element) - varat_ref (1, element) ) +
 		 varat_ref (1, element);

    return retVal;

#undef varat_ref
}

//	CanDecompose
//	Determine if decomposition can occur for all the elements being
//	used (N, P, S).
//	Returns true if Box A can decompose to Box B, otherwise false
//
//	When called from declig, ratioNewCE has 6 elements,
//	but here only needs the first 3:  (1,1), (2,1), and (3,1)).
//	When called from somdec, ratioNewCE has 3 elements.
// 	If there is available mineral E, decomposition can proceed
// 	even if mineral E is driven negative in the next time step.
bool TDecomposition::CanDecompose (
	float const tca,		// total C in Box A
	float const * const elstva,	// array [numLayers, site.nelem];
					//   N, P, and S in Box A
					//   by layer and element
	short const numLayers,		// 1st dimension of elstva
	short const layer,		// layer of Box A (values: SRFC, SOIL)
	float const * const ratioNewCE)	// array [site.nelem];
					//   C/N, C/P, and C/S ratios of new
					//   material being added to Box B
{
#define elstva_ref(a_1,a_2)	elstva[(a_2)*(numLayers) + a_1]

    Assert (numLayers >= 1 && numLayers <= NUMLAYERS);
    Assert (layer == SRFC || layer == SOIL);
    Assert (layer < numLayers);

    register short element;				// loop index
    bool canDo[NUMELEM] = { true, true, true };	// flag for each element

    for (element = 0; element < site.nelem; ++element)	// For each (N, P, S)
    {
	// If there is no available mineral E
	if ( !AmountIsSignificant (nps.aminrl[element]) )
	{
	    // if C/E of Box A > C/E of new material
	    if (tca / elstva_ref (layer, element) > ratioNewCE[element])
	    {
		// Immobilization is necessary therefore
		// Box A cannot decompose to Box B.
		canDo[element] = false;
	    }
	}
    }
    return ( canDo[N] && canDo[P] && canDo[S] );

#undef elstva_ref
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------


//--- end of definitions for TDecomposition ---
