
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Global declarations used in writing out NetCDF files */

	/* From WRTCDF */

extern	int	save_count;
extern	size_t	start[2];
extern	size_t	start_layer[3];
extern	size_t	count[2];
extern	size_t	count_layer[3];


	/* From the File Definitions */

/* Crop File */
extern int      crop_ncid, crpval_id, crmvst_id, cgrain_id, feramt_id,
                irract_id, egrain_id, ermvst_id;

/* H2O File */
extern	int	h2o_ncid, avh2o1_id, avh2o2_id, avh2o3_id, asmos_id, 
		evap_id, pet_id, rwcf_id, snlq_id, snow_id, stemp_id, 
		stream1_id, stream2_id, stream5_id, stream6_id, 
		tran_id, runo_id;

/* LIVC File */
extern	int	livc_ncid, aglivc_id, bglivc_id, stdedc_id, rleavc_id, 
		frootc_id, fbrchc_id, rlwodc_id, crootc_id, wood1c_id, 
		wood2c_id, wood3c_id, pltlig1_id, pltlig2_id;

/* LIVN File */
extern	int	livn_ncid, aglivn_id, bglivn_id, stdedn_id, 
		rleavn_id, frootn_id, fbrchn_id, rlwodn_id, 
		crootn_id, wood1n_id, wood2n_id, wood3n_id,
                crpstgn_id, forstgn_id;

/* NFLUX File */
extern	int     nflux_ncid, minerl_id, nfix_id, volex_id, volgm_id, 
		volpl_id, wdfxma_id, wdfxms_id;

/* NMNR File */
extern 	int     nmnr_ncid, gromin_id, strmnr1_id, strmnr2_id, metmnr1_id, 
		metmnr2_id, s1mnr1_id, s1mnr2_id, s2mnr_id, s3mnr_id, 
		wd1mnr_id, wd2mnr_id, wd3mnr_id;

/* NUPT File */
extern	int	nupt_ncid, agcnup_id, bgcnup_id, rlvnup_id, frtnup_id, 
		fbrnup_id, rlwnup_id, crtnup_id;

/* PROD File */
extern	int	prod_ncid, agcprd_id, bgcprd_id, rlvprd_id, frtprd_id, 
		fbrprd_id, rlwprd_id, crtprd_id;

/* RESP File */
extern	int	resp_ncid, s11c2_id, s21c2_id, s2c2_id, s3c2_id, 
		st1c2_id, st2c2_id, mt1c2_id, mt2c2_id, wd1c2_id,
		wd2c2_id, wd3c2_id;

/* SOILC File */
extern	int	soilc_ncid, defac_id, som1c1_id, som1c2_id, som2c_id, 
		som3c_id, strucc1_id, strucc2_id, metabc1_id, metabc2_id;

/* SOILN File */
extern	int	soiln_ncid, som1n1_id, som1n2_id, som2n_id, som3n_id, 
		strucn1_id, strucn2_id, metabn1_id, metabn2_id;

/* CREMV File */
extern int 	cremv_ncid, shremc_id, sdremc_id, rlvremc_id, fbrremc_id, 
		rlwremc_id, wd1remc_id, wd2remc_id, stremc_id, metrmc_id;

/* NREMV File */
extern int      nremv_ncid, shremn_id, sdremn_id, rlvremn_id, fbrremn_id, 
		rlwremn_id, wd1remn_id, wd2remn_id, stremn_id, metrmn_id, 
		fstgrmn_id;

/* SITE Spinup File */
extern	int	osite_ncid, site_ncid, fltvar_id, intvar_id, mask_id, time_id;
