// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TInitFile.cpp
//	Class:	  TInitFile
//
//	Description:
//      Class for read/write of initialization files.
//
//	Author: Sridhar Jillella, Jan98; Concept by Tom Hilinski.
// ----------------------------------------------------------------------------
//	History: See header file.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TInitFile.h"
#include "charutil.h"
#include <cctype>
#include <cstring>
using namespace std;


//--- constructors and destructor

TInitFile::TInitFile (
	TEH::TFileName const & fileName)	// name of "ini" file
{
 	Initialize();
 	namesRO = false;
	if ( &fileName )
		initFile = fileName;
}

TInitFile::TInitFile (
	TEH::TFileName const & fileName,	// name of "ini" file
	char** names,			// list of item names
	char** &values)			// list of item values
{
 	Initialize();
 	namesRO = false;
	if ( &fileName )
		initFile = fileName;
	SaveNames (const_cast<char const**>(names));
	SaveValues (values);
}

TInitFile::TInitFile (
	TEH::TFileName const & fileName,	// name of "ini" file
	char const** names,		// list of item names
	char** &values)			// list of item values
{
 	Initialize();
 	namesRO = true;
	if ( &fileName )
		initFile = fileName;
	SaveNames (names);
	SaveValues (values);
}

TInitFile::~TInitFile ()
{
	ClearNameList ();
	ClearValueList ();
}


//--- public functions


// 	Read
//	Reads the .ini file.
// 	Attempts to read "count" values.
// 	If count = 0 (no name list), then names are read from file.
// 	Return the number of valid parameters read.
short TInitFile::Read ()
{
	// If the nameList is not specified, then prepare to read from file.
	if ( !nameList )
	{
		count = CountValidLines ();
 		// allocate pointers
		nameList = new char* [count + 1];	// allocate pointers
		for (short i = 0; i <= count; i++)	// init to null
			nameList[i] = NULL;
		nameFromFile = true;		// set flag to read from file
	}

	// prepare the values list
	ClearValueList ();
	valueList = new char* [count + 1];		// allocate pointers
	for (short i = 0; i <= count; i++)		// init to null
		valueList[i] = NULL;

	// open the file stream
	fs.open (initFile.GetFullName().c_str(), ios::in);
	if ( fs.is_open() )
	{
		// To Do: error checks
		fs.clear();
	}

	// read the parameter-value pairs
	short countRead = 0;
	while ( fs.good() )
	{
	    short const maxLen = 289;	// 32 for param. + 256 for value + 1
	    char line[maxLen];
	    fs.getline (line, maxLen);			// get a line
	    if ( fs.good() )
	    {
		if ( *line )
		{
			if ( LineParse (line ) )	// parse the line
				++countRead;
		}
		if ( countRead == count )		// at limit?
			break;
	    }
	}
	if ( countRead != count )			// error?
	{
		// TO DO: need error handling
	}

	// close the stream and clean up
	fs.close();
	return countRead;
}

// 	Write
// 	Writes the parameter-value pairs to the .ini file.
//	If the file doesn't exist, it is created.
//	Returns false if successful else true if error.
bool TInitFile::Write ()
{
	if (modified && nameList )
	{
		// open the stream
		fs.open ( initFile.GetFullName().c_str(),
			  ios::out | ios::trunc );
		// write the values
		char const ** pNL = const_cast<char const **>(nameList);
		for (short i = 0; i < count; ++i, ++pNL)
		{
			if ( pNL && *pNL && **pNL)	// anything there?
			{
				fs << *pNL
				   << '='
				   << (valueList ? valueList[i] : "")
				   << '\n';
			}
			// need to check stream for error
		}
		fs.close();
		modified = false;
	}
	return false;
}

// 	SetFile
// 	Change the INI file name.
// 	Returns false if successful, else true.
bool TInitFile::SetFile ( TEH::TFileName& newFile )
{
	if ( &newFile )
	{
		initFile = newFile;
		modified = true;
		return initFile.IsEmpty();
	}
	return true;
}

//	SetValue
// 	Finds the parameter matching the index and sets the value.
// 	Returns true, if valid index is received.
bool TInitFile::SetValue (short const which, char const* value)
{
 	if ( which >= 0 && which < count )
 	{
  		strcpy (valueList[which], value);
  		modified = true;
  		return true;
 	}
 	else
 		return false;
}

//	SetValue
// 	Finds the parameter matching the name and sets the value.
// 	Returns true, if valid paramter name is received.
bool TInitFile::SetValue (char const* param, char const* value)
{
	for (short i = 0; i < count; i++)
		if (!::strcmplc(nameList[i],param))
		{
   			strcpy(valueList[i],value);
   			modified = true;
   			return true;
  		}
 	return false;
}

//	GetValue
// 	Receives parameter name and returns the value.
// 	If a match is not found, returns NULL.
char* TInitFile::GetValue (char const* param) const
{
	for (short i = 0; i < count; i++)
 		if (!::strcmplc (nameList[i],param))
   			return valueList[i];
	return 0;
}


//--- private functions

// 	Initialize
//	Initialize member variables.
inline void TInitFile::Initialize()
{

	nameList = valueList = NULL;
	count = 0;
	modified = false;
	nameFromFile = false;
}

//	Copy
// 	Copies the contents of TInitFile object.
void TInitFile::Copy (TInitFile const & obj)
{
 	if (&obj)
	{
		initFile.Clear ();
  		initFile = obj.initFile;
		count = obj.count;
		namesRO = obj.namesRO;
		SaveNames ( const_cast<char const**>(obj.nameList) );
		SaveValues ( obj.valueList );
 		modified = obj.modified;
 	}
}

// 	Clear
// 	clears member data
void TInitFile::Clear ()
{
	ClearNameList ();
	ClearValueList ();
  	Initialize();
}

// 	CountValidLines
// 	Counts file lines that contain an equals sign.
short TInitFile::CountValidLines ()
{
	short const maxLen = 288;	// 32 for param. + 256 for value
	char line[maxLen];

	// open the file stream
	fs.open ( initFile.GetFullName().c_str(), ios::in );
	// read the parameter-value pairs
	short countRead = 0;
	while ( fs )
	{
		fs.getline (line, maxLen);		// get a line
		if ( *line )
			if ( strchr (line, '=') )
				++countRead;
	}

	// close the stream and clean up
	fs.close();
	return countRead;
}

// 	LineParse
// 	Splits each line from the .ini file into parameter and value.
// 	Stores the value.
// 	Returns true if valid parameter is read.
bool TInitFile::LineParse (
	char const * const line)
{
	char *value;
	// get the token
	char *token = strtok ( const_cast<char*>(line), "=");
	if ( !token || !(*token) )
		return false;
	FlushSpaces ( token );

	// search for match in the parameter name list
	for ( short i = 0; i < count; i++ )
	{
		if ( nameFromFile )		// get name from file?
		{
			// next available name item
			if ( !nameList[i] )
			{
				nameList[i] = new char [strlen(token) + 1];
				strcpy (nameList[i], token);
			}
			else
				continue;			// next name
		}
		else if ( ::strcmplc (nameList[i], token) )	// match?
			continue;				// ...no
		// have name, so get value
		value = token + strlen(token) + 1;
		if ( !valueList[i] )		// no duplicates
		{
			valueList[i] = new char [strlen(value) + 1];
			strcpy (valueList[i], value);
			return true;
		}
		else
			return false;
	}
	return false;
}

//	FlushSpaces
// 	Delete all the spaces in the string.
void TInitFile::FlushSpaces(char* & str)
{
	char *p1 = str, *p2 = str;
	while (*p1)
		if ( *p1 != ' ' )		// not blank?
			*(p2++) = *(p1++);	// no, so copy
		else
			++p1;
}

// 	ClearNameList
// 	Deletes memory in nameList
void TInitFile::ClearNameList ()
{
	if ( nameList )
	{
		char **p = nameList;
		while (*p)
			delete [] *(p++);
		delete [] nameList;
		nameList = 0;
	}
	count = 0;		// set this here only!
}

//	ClearValueList
// 	Deletes memory in valueList
void TInitFile::ClearValueList ()
{
	if ( valueList )
	{
		char **p = valueList;
		while (*p)
			delete [] *(p++);
		delete [] valueList;
		valueList = NULL;
	}
}

// 	SaveNames
// 	copies names to internal list
// 	Returns the number of names copied.
short TInitFile::SaveNames (char const** names)
{
	ClearNameList ();
	if ( names )
	{
		// count the names
		char **pFrom = const_cast<char**>(names);	// pointer
		while ( *pFrom++ )				// count names
			++count;
 		// allocate pointers
		nameList = new char* [count + 1];		// memory
		nameList[count] = NULL;				// null term.
		// copy the names
		char **pTo = nameList;				// pointer
		pFrom = (char**)names; 				// reset ptr.
		while ( *pFrom )				// copy names
		{
			*pTo = new char [strlen(*pFrom) + 1];
			strcpy (*pTo, *pFrom);
			++pFrom;
			++pTo;
		}
		modified = true;
	}
	return count;
}

// 	SaveValues
// 	copies values to internal list
// 	Values list is forced to be the same size as the names list
// 	if values are supplied, else it is zero length.
//	Empty values are allocated a string of zero length.
// 	Returns the actual number of values copied.
short TInitFile::SaveValues (char** values)
{
	ClearValueList ();
	short countVals = 0;			// count of values copied
	if ( values )				// have a list to copy?
	{
		// allocate pointers
		valueList = new char* [count + 1];		// memory
		valueList[count] = NULL;			// null term.
		// copy the values
		char **pFrom = values, **pTo = valueList;
		for ( short i = 0; i < count; i++)
		{
			if ( *pFrom )	// copy the value string
			{
				*pTo = new char [strlen(*pFrom) + 1];
				strcpy (*pTo, *pFrom);
				++countVals;
			}
			else		// allocate an empty string
			{
				*pTo = new char [1];
				**pTo = '\0';
			}
			++pFrom;
			++pTo;
		}
		modified = true;
	}
	return countVals;
}



