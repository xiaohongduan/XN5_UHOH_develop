// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TUserPreferencesDlg.h
//	Class:	  TUserPreferencesDlg
//
//	Description:
//	Dialog box for specifying application preferences.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Jan98
//	History: See header file.
// ----------------------------------------------------------------------------

#define _TPrefDlg_ClassDefined_
#include "TUserPreferencesDlg.h"
#include "TSelectDirDlg.h"
#include "TFileSelDlg.h"
#include "util.h"
#include "HelpDisplay.h"
#include <v/vnotice.h>
#include <v/vos.h>

// ----------------------------------------------------------------------------
//	local variables
// ----------------------------------------------------------------------------

static char* titleDlg = "Specify Simulation Preferences";
static char *NULLStr = "";		// global NULL string
static vColor labelColor(128, 0, 0);	// define color for main labels

static char *toolTips[] =		// tool tips text
{
	// 0 = r/o text: application path: site libraries
	"Location of the default site parameter library files.",
	// 1 = r/o text: application path: mgmt. schemes
	"Location of the default management scheme files.",
	// 2 = r/o text: application path: mgmt. block libraries
	"Location of the default management block libraries files.",
	// 3 = r/o text: application path: parameter files
	"Location of the default parameter files.",
	// 4 = text edit: user pref: name
	"Your name is used in database files and output.",
	// 5 = text edit: user pref: path to site files
	"Your default location for your site parameter files.",
	// 6 = button: user pref: path to site files
	"Browse for your default site parameter files folder.",
	// 7 = text edit: user pref: path to mgmt. files
	"Your default location for your management files.",
	// 8 = button: user pref: path to mgmt. files
	"Browse for your default management files folder.",
	// 9 = list: user pref: list of work paths
	"Select a work folder to use.",
	// 10 = button: add work path
	"Add a folder to your list of work folders.",
	// 11 = button: delete work path
	"Delete the selected work folder.",
	// 12 = button: select work path
	"Use the selected work folder as the current folder.",
	// 13 = button: done
	"Finished specifying your preferences.",
	// 14 = button: cancel
	"Cancel: Quit and forget your changes.",
	// 15 = button: help
	"View Help on specifying preferences.",
	// 16 = button: get
	"Retrieve your preferences from a file.",
	// 17 = button: save
	"Save the current preferences to a file.",
	// 18 = button: clear
	"Erases all the user information.",
	// last item always
	NULL
};

CommandObject TUserPreferencesDlg::cmdList[] =
{
	//--- application info
	{C_Label, 200, 0, "Location of Application Libraries",
		NoList, CA_None, isSens, NoFrame, 0, 0},
	{C_Frame, 100, 0, "", NoList, CA_None, isSens, NoFrame, 0, 200},
	{C_Label, 205, 0, "Sites:",
		NoList, CA_None, isSens, 100, 0, 0, 20},
	{C_Label, D_AppSiteLibPath, 0, " ",
		NoList, CA_None, isSens, 100, 205, 0, 60, toolTips[0]},
	{C_Label, 210, 0, "Management Schemes:",
		NoList, CA_None, isSens, 100, 0, 205, 20},
	{C_Label, D_AppMgmtLibPath, 0, " ",
		NoList, CA_None, isSens, 100, 210, 205, 60, toolTips[1]},
	{C_Label, 215, 0, "Management Blocks:",
		NoList, CA_None, isSens, 100, 0, 210, 20},
	{C_Label, D_AppBlkLibPath, 0, " ",
		NoList, CA_None, isSens, 100, 215, 210, 60, toolTips[2]},
	{C_Label, 220, 0, "Parameter Files:",
		NoList, CA_None, isSens, 100, 0, 215, 20},
	{C_Label, D_AppParamLibPath, 0, " ",
		NoList, CA_None, isSens, 100, 220, 215, 60, toolTips[3]},
	// --- end of frame ---
	//--- user info
	{C_Label, 300, 0, "User Preferences",
		NoList, CA_None, isSens, NoFrame, 0, 100},
	{C_ColorLabel, D_Modified, 0, "Modified", (void *)&labelColor,
		CA_None, isSens, NoFrame, 300, 100, 40},
	{C_Frame, 110, 0, "", NoList, CA_None, isSens, NoFrame, 0, 300},
	// Name
	{C_Label, 305, 0, "Your Name:", NoList, CA_None, isSens, 110, 0, 0},
	{C_TextIn, D_UserName, 0, "", NoList, CA_None, isSens, 110, 305, 0,
		0, toolTips[4]},
	// Locations:
	{C_Label, 310, 0, "Locations of your files:",
		NoList, CA_None, isSens, 110, 0, D_UserName},
	// site files path
	{C_Label, 315, 0, "Sites:", NoList, CA_None, isSens, 110, 0, 310, 12},
	{C_TextIn, D_SiteLibPath, 0, "",
		NoList, CA_None, isSens, 110, 315, 310,
		50, toolTips[5]},
	{C_Button, D_SiteLibPathBrowse, D_SiteLibPathBrowse, "Browse...",
		NoList,	CA_None, isSens, 110, D_SiteLibPath, 310,
		0, toolTips[6]},
	// Management files path
	{C_Label, 320, 0, "Management:",
		NoList, CA_None, isSens, 110, 0, D_SiteLibPathBrowse, 12},
	{C_TextIn, D_MgmtLibPath, 0, "", NoList,
		CA_None, isSens, 110, 320, D_SiteLibPathBrowse,
		50, toolTips[7]},
	{C_Button, D_MgmtLibPathBrowse, D_MgmtLibPathBrowse, "Browse...",
		NoList,	CA_None, isSens, 110,
		D_MgmtLibPath, D_SiteLibPathBrowse,
		0, toolTips[8]},
	// Project directores list
	{C_Label, 325, 0, "Project Directories:",
		NoList, CA_None, isSens, 110, 0, D_MgmtLibPathBrowse},
	{C_List, D_ProjectPaths, 270, notUsed,
		NoList, CA_Size | CA_ListWidth, isSens, 110, 0, 325,
		5, toolTips[9]},
	{C_Button, D_ProjectPathAdd, D_ProjectPathAdd, "Add...",
		NoList,	CA_None, isSens, 110, D_ProjectPaths, 325,
		0, toolTips[10]},
	{C_Button, D_ProjectPathDel, D_ProjectPathDel, "Delete",
		NoList,	CA_None, isSens, 110,
		D_ProjectPaths, D_ProjectPathAdd,
		0, toolTips[11]},
	{C_Button, D_ProjectPathUse, D_ProjectPathUse, "Select",
		NoList,	CA_None, isSens, 110,
		D_ProjectPaths, D_ProjectPathDel,
		0, toolTips[12]},
	{C_Label, 327, 0, "Current Project Path:",
		NoList, CA_None, isSens, 110, 0, D_ProjectPaths},
	{C_Label, D_ProjectPathCur, 0, "",
		NoList, CA_None, isSens, 110, 0, 327,
		60},
	// --- end of frame ---
	// Dialog Action buttons
	{C_Button, M_OK, M_OK, " &Done ",
		NoList,	CA_DefaultButton, isSens, NoFrame, 0, 110,
		0, toolTips[13]},
	{C_Button, M_Cancel, M_Cancel, "&Cancel",
		NoList,	CA_None, isSens, NoFrame, M_OK, 110,
		0, toolTips[14]},
	{C_Button, M_Clear, M_Clear, " &Clear",
		NoList, CA_None, isSens, NoFrame, M_Cancel, 110,
		0, toolTips[18]},
	{C_Button, D_OpenIniFile, D_OpenIniFile, "Open...",
		NoList,	CA_None, isSens, NoFrame, M_Clear, 110,
		0, toolTips[16]},
	{C_Button, D_SaveIniFile, D_SaveIniFile, "Save...",
		NoList,	CA_None, isSens, NoFrame, D_OpenIniFile, 110,
		0, toolTips[17]},
 	{C_Button, M_Help, M_Help, " &Help ",
		NoList, CA_None, isSens, NoFrame, D_SaveIniFile, 110,
		0, toolTips[15]},
	// all done!
	{C_EndOfList, 0, 0, 0, 0, CA_None, 0, 0}
};

//--- constructors and destructor

TUserPreferencesDlg::TUserPreferencesDlg (
	vApp* const parentApp,  	// pointer to application
	TUserPref& currentPref)		// current preferences
	: origPref (currentPref),
	  TModalDlg (parentApp, titleDlg)
{
	ConstructMe ();
}

TUserPreferencesDlg::TUserPreferencesDlg (
	vBaseWindow * const parentWin,   // pointer to parent window
	TUserPref& currentPref)		// current preferences
	: origPref (currentPref),
	  TModalDlg (parentWin, titleDlg)
{
	ConstructMe ();
}

// common to constructors
void TUserPreferencesDlg::ConstructMe ()
{
	//--- initialize variables
	Initialize ();
	dispPref = origPref;
	dispPref.SetModified ( false );
	idxProjPathList = GetItemIndexInCmdObj (cmdList, D_ProjectPaths);
	//--- display dialog
	AddDialogCmds ((CommandObject*)cmdList);	// add dialog controls
	ItemVal retVal;
	ShowModalDialog (titleDlg, retVal);		// display it now
}

TUserPreferencesDlg::~TUserPreferencesDlg ()
{
	ClearDlgProjPathList ();
	DeleteProjPaths ();
}

//--- functions overridden

//	DialogDisplayed
//	Overrides the vModelDialog method.
void TUserPreferencesDlg::DialogDisplayed ()
{
	LoadDlg ();				// load data into dialog
	// things to check always
	ShowHideModified ();
}

void TUserPreferencesDlg::DialogCommand (ItemVal id, ItemVal val, CmdType type)
{
	// process events
	switch (id)
	{
	  case M_OK:				// "done" button
		GetDlg ();			// get data from dialog
		origPref = dispPref;		// save changes
		break;
	  case M_Help:				// "help" button
#ifdef MSWindowsHelp
		::HelpDisplay (::myApp.winHwnd(), ::helpPath,
			HELP_CONTEXT, IDH_USER_PREFERENCES_DLG);
#elif defined(X11Help)
		::HelpDisplay (winHwnd(), ::helpPath,
			HELP_CONTEXT, IDH_USER_PREFERENCES_DLG);
#endif
		break;
	  case M_Clear:				// "clear" button
		ClearDlg ();
	  	break;
	  case D_SiteLibPathBrowse:
		Evt_SiteLibPathBrowse ();	// browse for site lib path
		break;
	  case D_MgmtLibPathBrowse:
		Evt_MgmtLibPathBrowse ();	// browse for block lib path
		break;
	  case D_ProjectPathAdd:
		Evt_ProjectPathAdd ();		// add project path
		break;
	  case D_ProjectPathDel:
		Evt_ProjectPathDel ();		// delete project path
		break;
	  case D_ProjectPathUse:
		Evt_ProjectPathUse ();		// select project path
		break;
	  case D_OpenIniFile:
		Evt_OpenIniFile ();		// open a .ini file
		break;
	  case D_SaveIniFile:
		Evt_SaveIniFile ();		// save to a .ini file
		origPref = dispPref;		// save changes
		break;
	  case D_UserName:
	  case D_SiteLibPath:
	  case D_MgmtLibPath:
	  case D_ProjectPaths:
	  default:
		break;
	}

	// things to check always
	ShowHideModified ();
	// Default event processing
	TModalDlg::DialogCommand (id, val, type);
}

//--- public functions

//--- private functions

//	Initialize
// 	Initialize member variables
inline void TUserPreferencesDlg::Initialize ()
{
	projPathList = NULL;
}

//	LoadDlg
//	load data into dialog
void TUserPreferencesDlg::LoadDlg ()
{
	char const * const notAvailMsg = "Folder is not available.";

	// text boxes - application info
	SetString ( D_AppSiteLibPath,
		( ::defPaths->Exists (CenturyPaths::SiteLib) ?
		  ::defPaths->GetPath(CenturyPaths::SiteLib).c_str() :
		  notAvailMsg ) );
	SetString ( D_AppMgmtLibPath,
		( ::defPaths->Exists (CenturyPaths::MgmtLib) ?
		  ::defPaths->GetPath(CenturyPaths::MgmtLib).c_str() :
		  notAvailMsg ) );
	SetString ( D_AppBlkLibPath,
		( ::defPaths->Exists (CenturyPaths::BlockLib) ?
		  ::defPaths->GetPath(CenturyPaths::BlockLib).c_str() :
		  notAvailMsg ) );
	SetString ( D_AppParamLibPath,
		( ::defPaths->Exists (CenturyPaths::Parameters) ?
		  ::defPaths->GetPath(CenturyPaths::Parameters).c_str() :
		  notAvailMsg ) );

	// text boxes - user info
	SetString ( D_UserName, dispPref.GetName().c_str() );
	std::string pathStr = dispPref.GetSitesPath().GetFullPath();
	SetString ( D_SiteLibPath, pathStr.c_str() );
	pathStr = dispPref.GetMgmtPath().GetFullPath();
	SetString ( D_MgmtLibPath, pathStr.c_str() );
	pathStr = dispPref.GetWorkPath().GetFullPath();
	SetString ( D_ProjectPathCur, pathStr.c_str() );

	// lists - user info
	BuildProjPathList ();
	if ( projPathList )
	{
		short const c = idxProjPathList;	// index to cmdList[]
		cmdList[c].itemList = (void *)projPathList;	// set pointer
		SetValue (cmdList[c].cmdId, 0, ChangeListPtr);	// display list
	}
	CheckButtons ();
}

//	GetDlg
//	get data from dialog
void TUserPreferencesDlg::GetDlg ()
{
	TUserPref prevPref = dispPref;		// save current
	short const maxLen = 257;			// retrieved string
	char str[maxLen];
	TEH::TFileName newPath;				// retrieved path
	GetTextIn ( D_UserName, str, maxLen );		// user name
	dispPref.SetName (str);
	GetTextIn ( D_SiteLibPath, str, maxLen );	// site files path
	newPath.Clear();
	newPath.Assign (str, TEH::TFileName::FT_Directory);
	dispPref.SetSitesPath (newPath);
	GetTextIn ( D_MgmtLibPath, str, maxLen );	// mgmt. files path
	newPath.Clear();
	newPath.Assign (str, TEH::TFileName::FT_Directory);
	dispPref.SetMgmtPath (newPath);
	// List is saved each time a list button is pressed.
	// Working directory is saved each time "select" button is pressed.

	// check if modified
	if ( prevPref == dispPref )
		dispPref.SetModified (false);		// not modified
}

//--- event handlers

//	Evt_SiteLibPathBrowse
//	browse for  files path
void TUserPreferencesDlg::Evt_SiteLibPathBrowse ()
{
	std::string initPath;		// initial search path

	// 1. check the text edit box for a path
	short const maxLen = 257;			// retrieved string
	char str[maxLen];
	GetTextIn ( D_SiteLibPath, str, maxLen );	// site files path
	::strtrim (str);
	if ( *str )					// any text?
		initPath = str;				// ...yes, point to it

	// 2. check the user's preferences for a path
	else						// ...no
	{
		// try the site library directory
		TEH::TFileName tmpFN = dispPref.GetSitesPath ();
		if ( tmpFN.IsEmpty() )				// empty?
		{						// ...yes
			// try the working directory
			tmpFN = dispPref.GetWorkPath();
			if ( tmpFN.IsEmpty() )	// empty?
				tmpFN.Clear();			// ...yes
		}
		else						// empty?
			initPath = tmpFN.GetFullPath ();	// ...no, get
	}

	// let user browse directory
	TSelectDirDlg dirSelDlg (this);
	char const * path = dirSelDlg.DirSelect ( initPath.c_str() );

	// display path
	if ( path )
	{
	 	TEH::TFileName fn (path, TEH::TFileName::FT_Directory);
		// check the path
		if ( !CanAddPath ( fn ) )			// path ok?
			return;					// ...no
		// display the new path
		SetString ( D_SiteLibPath, path );
		dispPref.SetModified ( true );
		delete [] path;
	}
	else
		SetString ( D_SiteLibPath, str );  // original path displayed
}

//	Evt_MgmtLibPathBrowse
//	browse for management files path
void TUserPreferencesDlg::Evt_MgmtLibPathBrowse ()
{
	std::string initPath;		// initial search path

	// 1. check the text edit box for a path
	short const maxLen = 257;			// retrieved string
	char str[maxLen];
	GetTextIn ( D_MgmtLibPath, str, maxLen );	// site files path
	::strtrim (str);
	if ( *str )					// any text?
		initPath = str;				// ...yes, point to it

	// 2. check the user's preferences for a path
	else						// ...no
	{
		// try the site library directory
		TEH::TFileName tmpFN = dispPref.GetMgmtPath ();
		if ( tmpFN.IsEmpty() )				// empty?
		{						// ...yes
			// try the working directory
			tmpFN = dispPref.GetWorkPath();
			if ( tmpFN.IsEmpty() )			// empty?
				tmpFN.Clear();			// ...yes
		}
		else						// empty?
			initPath = tmpFN.GetFullPath ();	// ...no, get
	}

	// let user browse directory
	TSelectDirDlg dirSelDlg (this);
	char const * path = dirSelDlg.DirSelect ( initPath.c_str() );

	// display path
	if ( path )
	{
	 	TEH::TFileName fn (path, TEH::TFileName::FT_Directory);
		// check the path
		if ( !CanAddPath ( fn ) )			// path ok?
			return;					// ...no
		// display the new path
		SetString ( D_MgmtLibPath, path );
		dispPref.SetModified ( true );
		delete [] path;
	}
	else
		SetString ( D_MgmtLibPath, str );  // original path displayed
}

//	Evt_ProjectPathAdd
//	button: add project path
void TUserPreferencesDlg::Evt_ProjectPathAdd ()
{
	// check the user's preferences for a path
	// try the working directory
	TEH::TFileName tmpFN = dispPref.GetWorkPath ();
	std::string initPath;				// initial search path
	if ( tmpFN.IsEmpty() )				// empty?
		initPath = tmpFN.GetFullPath ();	// ...no, get

	// let user browse directory
	TSelectDirDlg dirSelDlg (this);
	char const * path = dirSelDlg.DirSelect ( initPath.c_str() );

	// display path
	if ( !path )					// path selected?
		return;					// ...no

	// Add the selected path to the list
	TEH::TFileName pathFN (				// create a TFileName
		path, TEH::TFileName::FT_Directory);
	delete [] path;
	if ( !CanAddPath ( pathFN ) )			// path ok?
		return;					// ...no
	if ( dispPref.AddProjectPath (pathFN) )	// add to global var
	{
		vNoticeDialog dlg (this, "Error Adding Folder");
		dlg.Notice ("The project folder which you selected\n"
			    "was NOT added to the to the list.\n\n"
			    "The folder may already be in the list.");
		return;
	}

	// Display the list
	BuildProjPathList ();				// build path list
	short c = idxProjPathList;			// index to cmdList[]
	cmdList[c].itemList = (void *)projPathList;	// set pointer to list
	SetValue (cmdList[c].cmdId, 0, ChangeListPtr);	// display list
	CheckButtons ();
}

//	Evt_ProjectPathDel
//	button: delete project path
void TUserPreferencesDlg::Evt_ProjectPathDel ()
{
	if ( !projPathList )			// anything to delete?
		return;
	// Get index to item, delete it, then rebuild and redisplay the list:
	short indexList = (short) GetValue (D_ProjectPaths);	// get index
	dispPref.DelProjectPath (indexList);		// delete path
	BuildProjPathList ();				// rebuild path list
	short c = idxProjPathList;			// index to cmdList[]
	cmdList[c].itemList = (void *)projPathList;	// set pointer
	SetValue (cmdList[c].cmdId, 0, ChangeListPtr);	// display list
	CheckButtons ();
}

//	Evt_ProjectPathUse
//	button: select project path
void TUserPreferencesDlg::Evt_ProjectPathUse ()
{
 	if ( !projPathList )			// anything to delete?
		return;
	short indexList = (short) GetValue (D_ProjectPaths);	// get index
								// get string
	std::string const pathStr =
		dispPref.GetProjectPath(indexList).GetFullPath();
	SetString ( D_ProjectPathCur, pathStr.c_str() );
	// save in global variable
	dispPref.SetWorkPath ( dispPref.GetProjectPath(indexList) );
}

//	BrowseIniFile
//	Allows the user to browse for a .ini file.
//	If parameter "save" is true, uses "save as" dialog,
//	otherwise uses "open" dialog.
//	Returns the selected file name in the parameter.
//	Returns true if have a file, else false if browse cancelled.
bool TUserPreferencesDlg::BrowseIniFile (
	TEH::TFileName & iniFile,
	bool save)
{
	bool retVal = false;				// return value
	char const* filter[] =
	{
		"Initialization files (*.ini)|*.ini|"
		"All files (*.*)|*.*|",
		NULL
	};
	int filterIdx = 0;				// filter index
	TFileSelectDlg fileOpenDlg (this);		// instance of

	// is there a previously specified INI file name?
	iniFile = dispPref.GetIniFile ();

	// initial values
	char fileName[257];
	short const pathLength = 257;
	std::string path;
	if ( !iniFile.IsEmpty() )
	{
		if ( iniFile.HaveName() )
			strcpy ( fileName, iniFile.GetName().c_str() );
		else
			strcpy (fileName, "*");
		strcat (fileName, ".");
		if ( iniFile.HaveExtension() )
			strcat ( fileName, iniFile.GetExtension().c_str() );
		else
			strcat (fileName, "ini");
		std::string const tempPath =
			iniFile.GetFullPath ();		// starting path
		if ( !tempPath.empty() )
			path = tempPath;
	}
	else
		strcpy (fileName, "*.ini");
	if ( path.empty() )
		path = ::defPaths->GetPath(CenturyPaths::Work);

	// browse
	int result;
	if ( save )
		result = fileOpenDlg.FileSelectSave (
				"Save Initialization File",
				(char *)fileName, pathLength - 1,
				filter, filterIdx, path.c_str() );
	else
		result = fileOpenDlg.FileSelect (
				"Open Initialization File",
				(char *)fileName, pathLength - 1,
				filter, filterIdx, path.c_str() );
	if ( result && *fileName )			// path selected?
	{
		iniFile.Assign (fileName,		// save the file nane
				TEH::TFileName::FT_Normal);
		retVal = true;				// success!
	}

	// clean up
	return retVal;
}

//	Evt_OpenIniFile
//	button: open a .ini file
void TUserPreferencesDlg::Evt_OpenIniFile ()
{
	TEH::TFileName iniFile;			// let user specify ini file
	if ( BrowseIniFile (iniFile, false) )	// have a new file?
	{
		dispPref.SetIniFile (iniFile);		// save name
		dispPref.ReadIniFile ();		// read the file
		dispPref.SetModified ( false );
		LoadDlg ();				// display new
	}
}

//	Evt_SaveIniFile
//	button: save to a .ini file
void TUserPreferencesDlg::Evt_SaveIniFile ()
{
	GetDlg ();				// get data from dialog
	TEH::TFileName iniFile;			// let user specify the file
	if ( BrowseIniFile (iniFile, true) )	// have a new file?
	{
		dispPref.SetIniFile (iniFile);	// save in global variable
		dispPref.WriteIniFile ();	// write the file
	}
}


//--- utility functions

//	ClearDlg
//	clears user's info in dialog
void TUserPreferencesDlg::ClearDlg ()
{
	SetString ( D_UserName, NULLStr );
	SetString ( D_SiteLibPath, NULLStr );
	SetString ( D_MgmtLibPath, NULLStr );
	SetString ( D_ProjectPathCur, NULLStr );
	ClearDlgProjPathList ();
	DeleteProjPaths ();
	dispPref.Clear ();
	dispPref.SetModified ( false );
}

//	ClearDlgProjPathList
// 	Clear project path list display
void TUserPreferencesDlg::ClearDlgProjPathList ()
{
 	if ( !projPathList )			// anything to delete?
		return;

	// Get the index to cmdList item for the list.
	short i = idxProjPathList;
	// change list to empty one
	cmdList[i].itemList = (void*)NULL;	// set pointer to list
	SetValue (cmdList[i].cmdId, 0, ChangeListPtr);	// display list
}

//	DeleteProjPaths
// 	Deletes the projPathList member variable
void TUserPreferencesDlg::DeleteProjPaths ()
{
	if ( projPathList )
	{
		// delete block description string list
		char **p = projPathList;
		while ( p && *p )
		{
			delete [] *p;
			++p;
		}
		delete [] projPathList;
		projPathList = NULL;
	}
}

//	BuildProjPathList
//	Build the project path list.
void TUserPreferencesDlg::BuildProjPathList ()
{
	// Check for previously allocated memory
	DeleteProjPaths ();
	// Is there a list to build?
	short listSize = dispPref.GetProjPathCount();
	if ( listSize == 0 )
		return;
	// Build a new list:
	// allocate memory for list
	projPathList = new char* [listSize + 1];
	projPathList[listSize] = NULL;			// NULL at end of list
	// add paths to list
	char **p = projPathList;			// pointer to list
	for (short i = 0; i < listSize; i++)
	{
		// get path
		std::string const pathStr =
			dispPref.GetProjectPath(i).GetFullPath();
		*p = new char [pathStr.size() + 1];
		strcpy ( *p, pathStr.c_str() );
		++p;					// go to next string
	}
}

//	CheckButtons
// 	(de)activate project path list buttons, and
//	clears the work path field if list is empty.
void TUserPreferencesDlg::CheckButtons ()
{
	if ( projPathList )
	{
		// activate list buttons
		SetValue ( D_ProjectPathDel, isSens, Sensitive );
		SetValue ( D_ProjectPathUse, isSens, Sensitive );
		// work directory
		std::string str = dispPref.GetWorkPath().GetFullPath();
		if ( !str.empty() )
			SetString ( D_ProjectPathCur, str.c_str() );
		else	// use the 1st path in the list
		{
			str = dispPref.GetProjectPath(0).GetFullPath();
			SetString ( D_ProjectPathCur, str.c_str() );
			// save in global variable
			dispPref.SetWorkPath ( dispPref.GetProjectPath(0) );
		}
	}
	else
	{
		// deactivate list buttons
		SetValue ( D_ProjectPathDel, notSens, Sensitive );
		SetValue ( D_ProjectPathUse, notSens, Sensitive );
		// work directory
		SetString ( D_ProjectPathCur, "" );
	}
}

//	CanAddPath
//	Returns true if can add path to the user's path.
bool TUserPreferencesDlg::CanAddPath (TEH::TFileName& path)
{
	bool retVal = false;
	std::string pathStr = path.GetFullPath ();
	if ( pathStr.empty() )		// anything there?
		goto all_done;

	// is path the same as the a system read-only paths?
	if ( pathStr == ::defPaths->GetPath(CenturyPaths::Executable) ||
	     pathStr == ::defPaths->GetPath(CenturyPaths::Parameters) ||
	     pathStr == ::defPaths->GetPath(CenturyPaths::Templates) ||
	     pathStr == ::defPaths->GetPath(CenturyPaths::SiteLib) ||
	     pathStr == ::defPaths->GetPath(CenturyPaths::BlockLib) ||
	     pathStr == ::defPaths->GetPath(CenturyPaths::MgmtLib) )
	{
		char msg[1024];
		vNoticeDialog dlg (this, "Not a Valid Folder");
		strcpy (msg, "The folder you selected:\n\n");
		strcat (msg, pathStr.c_str() );
		strcat (msg, "\n\nis not a valid folder.\n"
			     "Select a different folder.");
		dlg.Notice (msg);
	}
	else
		retVal = true;		// can add path!

	all_done:
		return retVal;
}

//	ShowHideModified
//	Toggles the display of the "modified" message at the top-right
//	of the dialog.
inline void TUserPreferencesDlg::ShowHideModified ()
{
	if ( dispPref.IsModified() || IsUserTextChanged() )
		SetValue (D_Modified, 0, Hidden);	// show
	else
		SetValue (D_Modified, 1, Hidden);	// hide
}

//	IsUserTextChanged
//	Returns true if text input boxes contents have changed.
bool TUserPreferencesDlg::IsUserTextChanged ()
{
	bool retVal = false;				// return value
	short const maxLen = 257;			// retrieved string len
	char name[maxLen], site[maxLen], mgmt[maxLen];	// string contents
							// previous contents
	static char namePrev[maxLen], sitePrev[maxLen], mgmtPrev[maxLen];
	static bool firstTime = true;

	// get displayed strings
	GetTextIn ( D_UserName, name, maxLen );		// user name
	GetTextIn ( D_SiteLibPath, site, maxLen );	// site files path
	GetTextIn ( D_MgmtLibPath, mgmt, maxLen );	// mgmt. files path

	// initialize the static variables
	if ( firstTime )
	{
		if ( *name || *site || *mgmt )	// anything there?
		{
			firstTime = false;	// turn off initialization
			strcpy (namePrev, name);	// save initial values
			strcpy (sitePrev, site);
			strcpy (mgmtPrev, mgmt);
		}
	}

	// compare
	else if ( strcmp (name, namePrev) ||
		  strcmp (site, sitePrev) ||
		  strcmp (mgmt, mgmtPrev) )
	{
		// changed, so save for next comparison
		if ( *name )
			strcpy (namePrev, name);
		else
			*namePrev = '\0';
		if ( *site )
			strcpy (sitePrev, site);
		else
			*sitePrev = '\0';
		if ( *mgmt )
			strcpy (mgmtPrev, mgmt);
		else
			*mgmtPrev = '\0';
		retVal = true;
	}
	return retVal;
}





