#ifndef INC_TMCDecomposition_h
#define INC_TMCDecomposition_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model (Monthly)
//	File:	  TMCDecomposition.h
//	Class:	  TMCDecomposition
//
//	Description:
//	Class for plant decomposition for monthly Century.
//	Members were extracted from class TCentury.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, April 2004
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TDecomposition.h"
#include "TCenturySoil.h"
#include "TMCSoilFlows.h"
#include "TMCMicrobial.h"

class TMCDecomposition
	: public TDecomposition
{
  public:
	//---- constructors and destructor
	TMCDecomposition (
	  // Instances of Century-owned objects
	  TLeachOrganicC & useLeachOC,
	  TCenturySoil & useSoil,
	  TMCSoilFlows & useSoilFlows,
	  TMCMicrobial & useMicrobial,
	  // Century internal data
	  TSimTime & useSimTime,
	  TFixed const & useFixed,
	  Tparfs const & useParfs,
	  Tcomput & useComput,
	  TSite & useSite,
	  // Century output variables
	  TCO2 & useCo2,
	  TForestC & useForestC,
	  TNPS & useNps,
	  TSoilC & useSoilC,
	  TWaterTemp const & useWT,
	  // other
	  TSystemType systemType = SysType_Unknown )
	  : TDecomposition (
		useLeachOC, useSoil, useSoilFlows, useMicrobial,
		useSimTime, useFixed, useParfs, useComput, useSite,
	  	useCo2, useForestC, useNps, useSoilC, useWT,
	  	systemType )
	  {
	  }
	TMCDecomposition (			// copy constructor
	  TMCDecomposition const & object,	//   object to copy
	  // Instances of Century submodels - refs to owner's objects
	  TLeachOrganicC & useLeachOC,
	  TCenturySoil & useSoil,
	  TMCSoilFlows & useSoilFlows,
	  TMCMicrobial & useMicrobial,
	  // Century internal data
	  TSimTime const & useSimTime,
	  TFixed const & useFixed,
	  Tparfs const & useParfs,
	  Tcomput & useComput,
	  TSite & useSite,
	  // Century output variables
	  TCO2 & useCo2,
	  TForestC & useForestC,
	  TNPS & useNps,
	  TSoilC & useSoilC,
	  TWaterTemp const & useWT,
	  // other
	  TSystemType systemType)
	  : TDecomposition ( object,
		useLeachOC, useSoil, useSoilFlows, useMicrobial,
	  	useSimTime, useFixed, useParfs, useComput, useSite,
	  	useCo2, useForestC, useNps, useSoilC, useWT,
	  	systemType )
	  {
	  }
	~TMCDecomposition ()
	  {
	  }
	// virtual TMCDecomposition * const Clone () const;	// Clone this

	//---- operator overloads

	//---- functions
	virtual float ScheduleNPSFlow (
          TMineralElements element,	// N, P, or S
	  float const cFlowAtoB,	// C flow from Box A to Box B
	  float const cATotal,		// total C (both isotopes) in Box A
	  float const rcetob,		// C/E of new E added to Box B
	  float* const eA,		// E pool in box A
	  float* const eB,		// E pool in box B
	  float const simDepth);		// simulation depth

  protected:
	//---- data

	//---- functions

  private:
	//---- data

	//---- functions

	//---- functions not allowed
	TMCDecomposition (			// copy constructor
	  TMCDecomposition const & object)
	  : TDecomposition (object)
	  {
	  }
	TMCDecomposition& operator= (
	  TMCDecomposition const & object)
	  {
	    return *this;
	  }
};

#endif // INC_TMCDecomposition_h
