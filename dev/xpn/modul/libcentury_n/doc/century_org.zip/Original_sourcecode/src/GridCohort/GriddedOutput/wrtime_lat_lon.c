
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include "netcdf.h"
#include "wrtcdf_ll.h"

void
wrtime_ll_(int *simdays)
{
        int status;
	static size_t	tstartll={0};
	size_t 		tcount={1};

	status = nc_put_vara_int(cropll_ncid, timell_id, &tstartll, &tcount, simdays);
	status = nc_put_vara_int(h2oll_ncid, timell_id, &tstartll, &tcount, simdays);
	status = nc_put_vara_int(livcll_ncid, timell_id, &tstartll, &tcount, simdays);
	status = nc_put_vara_int(livnll_ncid, timell_id, &tstartll, &tcount, simdays);
	status = nc_put_vara_int(nfluxll_ncid, timell_id, &tstartll, &tcount, simdays);
	status = nc_put_vara_int(nmnrll_ncid, timell_id, &tstartll, &tcount, simdays);
	status = nc_put_vara_int(nuptll_ncid, timell_id, &tstartll, &tcount, simdays);
	status = nc_put_vara_int(prodll_ncid, timell_id, &tstartll, &tcount, simdays);
	status = nc_put_vara_int(respll_ncid, timell_id, &tstartll, &tcount, simdays);
	status = nc_put_vara_int(soilcll_ncid, timell_id, &tstartll, &tcount, simdays);
	status = nc_put_vara_int(soilnll_ncid, timell_id, &tstartll, &tcount, simdays);
	status = nc_put_vara_int(cremvll_ncid, timell_id, &tstartll, &tcount, simdays);
	status = nc_put_vara_int(nremvll_ncid, timell_id, &tstartll, &tcount, simdays);
	tstartll += 1;

	return;
}
