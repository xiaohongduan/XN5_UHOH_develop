// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TCenturyCellOutputMgr.cpp
//	Class:	  TCenturyCellOutputMgr
//
//	Description: See header file.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, June 2002
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TCenturyCellOutputMgr.h"
#include "TDayCentSimController.h"
#include "TDayCentIRCConfig.h"
#include "OutputVariablesByBiome.h"
#include "OutputVariablesByCell.h"
#include "TDayCentGCF.h"
#include "versionDayCentIRC.h"
using namespace std;
using namespace nrel::dcirc;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// file header information
char const * const ::nrel::gcf::TCellOutputMgr::headerInitialInfo[] =
{
	DayCentIRCNickname,
	DayCentIRCVersionLong,
	0
};

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

TCenturyCellOutputMgr::TCenturyCellOutputMgr (
	TOwner * const useParent,			// grid cell ptr
	TSharedPtr<TOutput> outputSink)			// output sink
	: ::nrel::gcf::TCellOutputMgr (useParent, outputSink),
	  csvFile (outputSink)
{
	using ::nrel::gcf::TGridCell;
	using ::nrel::gcf::TGrid;
	using ::nrel::gcf::TGriddedSimulationBase;

	if ( !csvFile->IsOpen() )
	{
		// To Do: constructor - file not open
	}
	TDayCentSimController * const mySimController =
	/*
		Following works until cast from
		::nrel::gcf::TGriddedSimulationBase to TDayCentSimController,
		which fails.
		Don't know why yet, so I'll use brute-force with a C-style cast.
	    dynamic_cast<TDayCentSimController* const> (
	      dynamic_cast<TGridCell * const>(owner)->GetOwner()->GetOwner() );
	*/
	    (TDayCentSimController* const)
	      dynamic_cast<TGridCell * const>(owner)->GetOwner()->GetOwner();
	Assert (mySimController != 0);
	TDayCentIRCConfig const & myConfig =
		dynamic_cast<TDayCentIRCConfig const &> (
			mySimController->GetConfiguration() );
	SetOutputTiming ( myConfig.GetCellOTSI() );

	// output variables
	TOutputVarConfig const & outVarConfig =
		myConfig.GetOutputVariablesConfig();

	// to do: fix this kluge; implement scope X groupBy matrix
	TOutputVarMgrPtr newOutVarMgr;
	if ( outVarConfig.scope == OVS_Cell &&
		outVarConfig.groupBy == OVSG_None )
	{
		newOutVarMgr.reset ( new OutputVariablesByCell (this) );
	}
	else if ( outVarConfig.scope == OVS_Cell &&
		outVarConfig.groupBy == OVSG_Biome )
	{
		newOutVarMgr.reset ( new OutputVariablesByBiome (this) );
	}

	if ( SetOutputVariablesManager (newOutVarMgr) )
	{
		// to do: SetOutputVariablesManager<OutputVariables> failed
		Assert (HaveOutputVariablesManager());
	}
}

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------


//--- end of definitions for TCenturyCellOutputMgr ---
