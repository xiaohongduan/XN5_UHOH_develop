#ifndef INC_TSelectDirDlg_h_
#define INC_TSelectDirDlg_h_

// ----------------------------------------------------------------------------
//	Project:  V GUI Enhancement
//	File:	  TSelectDirDlg.h
//	Class:	  TSelectDirDlg
//
//	Description:
//	A class which allows the user to select a directory from a list,
//	or to create a new subdirectory.
//
//	Requires the class TFileList.
//	Requires the V GUI library, version 1.16 or higher.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Aug99
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------
// Copyright (c) 1999 Thomas E. Hilinski. All rights reserved.
// Unauthorized distribution, duplication, sale, and use is prohibited by law.
//
//	This software is made available under the terms of the
//	GNU LIBRARY GENERAL PUBLIC LICENSE.
//	This copyright notice must remain intact and in place.
// ----------------------------------------------------------------------------

#include "TFileList.h"
#include <v/vmodald.h>

#ifndef MAX_PATH
#define MAX_PATH 256
#endif

//	Command objects values
enum {
	Enum_DC_Start = 1000,		// first item!
					//--- controls
	DC_Path,			// text input: path to "look in"
	DC_Folder,			// text input: selected folder
	DC_FolderList,			// list: list of folders
	DC_Up,				// button: move up the tree
	DC_GoTo,			// button: go to the path
	DC_Down,			// button: move down the tree
	DC_New,				// button: new folder
					//--- all done!
	Enum_DC_End			// last item!
};


class TSelectDirDlg : public vModalDialog
{
  public:
	//--- types
	enum TSDDErrors		// error flags
	{
		NoError, 	// no error - FIRST ENUM ITEM ALWAYS
		MemoryAlloc,	// memory allocation error
		UnknownError	// unknown error - LAST ENUM ITEM ALWAYS
	};

	//--- constructors and destructor
	TSelectDirDlg (
		vApp* const parent,			// ptr to parent V app
		char const * const useDlgTitle = 	// dialog title
			"Select a Folder");
	TSelectDirDlg (
		vBaseWindow* const parent, 		// ptr to parent window
		char const* const useDlgTitle = 	// dialog title
			"Select a Folder");
	~TSelectDirDlg ();

	//--- functions
	char* DirSelect (		// Do the directory selection.
	  char const * const initDir);
		// Returns a string containing the fully-qualified path
		// to the user's selection, or NULL if cancel was pressed.
		// Ownership of the returned string is of the calling function,
		// which must delete the string when done.
		// "initDir" is the starting directory.

	//--- Retrieve info
	TSDDErrors LastError () const		// get last error code
		{ return lastError; }
	char const* GetVersion () const		// Get version of this class.
		{ return version; }

  private:
	//--- static data
	static char const* version;		// class version string
	static CommandObject cmdList[];		// dialog elements
	static char const* toolTips[];		// tool tips text

	//--- data
	char const** dirList;			// list of subdirectories
	char* path;				// selected path
	int idxParamList;			// index to cmdList list object
	TSDDErrors lastError;			// last error code

	//--- functions
	void Initialize ();			// initialize member variables
	void LoadDlg ();			// load data into dialog
	void ClearDlgList ();			// clear list
	void CopyList (				// copy to dirList
	  char const * const * const from,
	  short size);
	void DeleteList ();			// delete dirList
	void CopyToPath (char* newPath);	// copy to path
	void AppendToPath (char* subDir);	// append subdir. to path
	void GetParentPath ();			// builds parent path
	void GetPathFromLookIn ();		// build path from text input
	void BldListFromFolder ();		// build new list from folder
	bool UserChgLookInText ();		// true if "look in" text chgd.
	bool UserChgFolderText ();		// true if "folder" text chgd.
	void GetSelectedPath ();		// gets full selected path
						//--- Event handlers
	void Evt_ListSelection ();		// list selection
	void Evt_UpFolder ();			// up-folder icon button
	void Evt_DownFolder ();			// into-folder icon button
	void Evt_NewFolder ();			// new-folder icon button
	void Evt_GoToFolder ();			// go to folder icon button
						//--- Utility functions
	void strtrim (char* s);			// Trims leading+trailing space
	int mkdir (char const* path);		// create a folder

  public:
	//--- functions overridden: NOT FOR PUBLIC CONSUMPTION!
	void DialogDisplayed ();
	void DialogCommand (ItemVal id, ItemVal val, CmdType type);
};

#endif // INC_TSelectDirDlg_h_

