#ifndef INC_TSelectOutVarsDlg_h
#define INC_TSelectOutVarsDlg_h
// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TSelectOutVarsDlg.h
//	Class:	  TSelectOutVarsDlg
//
//	Description:
//	Class for dialog to select output variables for view/plot/export.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Sep98
//	History:
//	Oct03	Tom Hilinski
//	* Renamed class to TSelectOutVarsDlg.
// ----------------------------------------------------------------------------
// Usage Notes:
// Returns a list of Century output file names (fully-qualified paths),
// and a list containing three indices:
// (1) which output file name,
// (2) which output variable category (type TOVICategory from T_OutVarInfo.h),
// (3) the variable in that category.
// ----------------------------------------------------------------------------

#include "TModalDlg.h"
#include "TMCOutVarInfo.h"
#include "TNcFileList.h"
// STL
#pragma warn -csu
using namespace std;

//	-----------------------------------------------------------------------
//	Command objects values
enum {
	Enum_SelOutVars_Start = 8000,	// first item!
					//--- output variable categories
	D_Categories,			// combo list: categories
					//--- lists
	D_ResultsSource,		// source of output variables (files)
	D_AvailableVars,		// available variables for category
	D_SelectedVars,			// selected variables for category
					//--- buttons
	D_ToSelected,			// right arrow to "selected" list
	D_FromSelected,			// left arrow from "selected" list
	D_AddOutFile,			// browse for files to add to list
	D_ClearSelected,		// clear the "selected" list
	D_MoveItemUp,			// move highlighted item up in list
	D_MoveItemDown,			// move highlighted item down in list
					//--- text
	D_SimDescrip,			// description of highlighted source
	D_VarDescrip,			// description of highlighted avail.
					//--- all done!
	Enum_SelOutVars_End		// last item!
};

//	-----------------------------------------------------------------------
//	TSelectOutVarsDlg
class TSelectOutVarsDlg : public TModalDlg
{
  public:
	// type for STL vector of indices to lists
	struct TIndexGroup
		{ short file,		// file = index in file list "srcList"
			category,	// category = type TOVICategory
			variable;	// variable = index in category
		  bool operator == (const TIndexGroup &obj) const
		    {	return  file == obj.file &&
				category == obj.category &&
				variable == obj.variable;
		    }
		  bool operator != (const TIndexGroup &obj) const
		    { return !(*this == obj); }
		};
	typedef std::vector<TIndexGroup> TSelIndexList;		// the list

	// type for STL vector of strings for selected items
	typedef std::vector<std::string> TSelectedVector;

	//--- constructors and destructor
	TSelectOutVarsDlg (vApp* const parent,
		TEH::TFileName const &
			useVarDefFilePath,	// variable definitions file
		TEH::TFileName const ** const
			useWorkPaths,		// working directory paths
						//   (null-term. list of ptrs.)
		char const * const title =
			"Select Output Variables");	// dialog title
	~TSelectOutVarsDlg ();

	//--- functions overridden
	void DialogDisplayed ();
	void DialogCommand (ItemVal id, ItemVal val, CmdType type);

	//--- functions
	const TNcFileList* GetOutputFileNames ();	// get output file list
	const TSelIndexList& GetIndicesList ();		// get selection indices
	const TMCOutputVariableInfo* GetOutputVarInfo (); // get names/descrips.

  private:
	//--- data
	static CommandObject cmdList[];	// dialog elements
	short idxCategoryList;		//index to the category list
	short idxSourceList;		// index to source list in cmdList
	short idxAvailList;		// index to available list in cmdList
	short idxSelectList;		// index to selected list in cmdList
	const TEH::TFileName** const	workPaths;	// working directory paths
							//   (null-term. list of ptrs.)
	const TMCOutputVariableInfo* info; // variables' names and defs.
	const TNcFileList* srcList;	// list of netCDF output files
	TSelIndexList indexSelected;	// vector of indices arrays
	TSelectedVector selectedList;	// vector of strings of selection
	char const** selectedStrList;	// list of strings of selection
	char** simDescList;		// list of sim. descriptions

	//--- functions
	void Initialize ();		// initialize members
	void Clear ();			// clear member variables
	void LoadDlg ();	   	// load the dialog
	void LoadSources ();		// load the sources list
	void AddToSourcesList (char* item);	// add to output sources list
	char const* GetSourceName ();	// get name of selected source file
	void DisplaySelected ();	// displays the selected items list
	void DisplayDescription (ItemVal list);	// displays a vars. description
	void CheckRightArrowSens ();	// changes sensitivity of right arrow
	void CheckSelListSens ();	// changes sens. of "selected" controls
	void BuildSimDescList ();	// builds a list of simulation descrip.
					//--- event handlers
	void Evt_Source ();		// selected an output source
	void Evt_Category ();		// selected a category
	void Evt_AvailableVars ();	// list of available variables
	void Evt_ToSelected ();		// right-arrow button
	void Evt_FromSelected ();	// left arrow button
	void Evt_AddOutFile ();		// browse for source button
	void Evt_SelectedVars ();	// list of selected variables
	void Evt_ClearSelected ();	// "clear selected" button
	void Evt_MoveItemUp ();		// move highlighted item up
	void Evt_MoveItemDown ();	// move highlighted item down
};

#endif // INC_TSelectOutVarsDlg_h
