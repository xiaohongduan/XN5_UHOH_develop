
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "gridconst.h"

/* Global Variables */
FILE *fp_l;
int curr_row;

/* Open SVF Landuse File */

int
lopen(FILE *fp_init)
{

     char junk[MAXR+1];
     int i;
     char line[MAXL];

     char lfname[FNAMEMAX];

        /* Read comment line from init file */
        fgets(line, MAXL, fp_init);

        /* Read landuse filename from init file */
        fgets(line,MAXL, fp_init);
	/* Open Landuse SVF File */
        sscanf(line, "%s", &lfname[0]);
	if ((fp_l = fopen(lfname, "r")) == NULL) {
           printf("lopen: Unable to open file %s\n", lfname);
        }

        /* Skip over the header lines */
	for (i=0; i<5; i++)
	{
		fgets(junk, MAXR, fp_l);
	}

	return 0;
}
