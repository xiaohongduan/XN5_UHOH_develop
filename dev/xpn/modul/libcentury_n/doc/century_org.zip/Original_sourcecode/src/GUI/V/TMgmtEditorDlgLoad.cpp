// ----------------------------------------------------------------------------
//	Copyright 1999-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TMgmtEditorDlgLoad.cpp
//	Class:	  TMgmtEditorDlg
//
//	Description:
//	Dialog box for editing the site managment.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec97
//	History: See the class header file, TMgmtEditorDlg.h.
// ----------------------------------------------------------------------------
//	Notes:
//	This class is divided among the following files:
//	TMgmtEditorDlg.h		declarations header file
//	TMgmtEditorDlg.cpp		main class definitions
//	TMgmtEditorDlgLoad.cpp		methods to load data into dialog
//	TMgmtEditorDlgEvents.cpp	methods to handle dialog events
//	TMgmtEditorDlgGet.cpp		methods to retrieve data from dialog
// ----------------------------------------------------------------------------

#define _TMgtDlg_ClassDefined_
#include "TMgmtEditorDlg.h"
#include "externals.h"
#include "util.h"
#include <cstring>
#include <cstdio>
#include "AssertEx.h"

using namespace std;
// ----------------------------------------------------------------------------
//	local variables
// ----------------------------------------------------------------------------

static char displayStrLen = 21;	// length of display string
static char displayStr[21];	// for converting between values and text

//	LoadDlg_Simulation
//	Loads management scheme data into the "simulation' tabbed dialog.
void TMgmtEditorDlg::LoadDlg_Simulation ()
{
	TSimInfo si;				// local TSimInfo info
	TManagementScheme *mgmt = mgmtDisp;	// management scheme

	//--- Error checks
	if (mgmt == NULL || mgmt->IsEmpty() )
	{
		if ( mgmt )
		{
			mgmt->modified = true;
			mgmt->verified = false;
		}
		return;
	}

	//--- Data
	SetString ( D_MgtBaseName, mgmt->GetBaseName() );	// base name
	SetString ( D_MgtDescrip, mgmt->GetSimDescription () );	// description
	si = mgmt->GetSimInfo ();
	sprintf ( displayStr, "%hd", si.yearStart);		// year start
	SetString ( D_YearStart, displayStr );
	sprintf ( displayStr, "%hd", si.yearEnd);		// year end
	SetString ( D_YearEnd, displayStr );
	if ( si.labelType == Lbl_14C )				// CO2 labeling
	{
		SetValue ( D_LabelType14C, isChk, Checked );
		Enable14CFileName (true);
		if ( si.c14FileName )
		{
			std::string const name = si.c14FileName->GetFullName();
			if ( !name.empty() )
				SetString ( D_14CFileName, name.c_str() );
		}
	}
	else if ( si.labelType == Lbl_13C )
	{
		SetValue ( D_LabelType13C, isChk, Checked );
		Enable14CFileName (false);
	}
	else // Lbl_None
	{
		SetValue ( D_LabelTypeNone, isChk, Checked );
		Enable14CFileName (false);
	}
	if ( si.labelType != Lbl_None )				// label year
	{
		sprintf ( displayStr, "%hd", si.labelYear);
		SetString ( D_LabelYear, displayStr );
	}

	UpdateInitSystem ();

	if ( si.microcosm )					// microcosm
	{
		SetValue ( D_Microcosm, isChk, Checked );
		SetValue ( D_MicrocosmTemp, isSens, Sensitive );
		sprintf (displayStr, "%6.2f", si.microcosmTemp);
		SetString ( D_MicrocosmTemp, displayStr );
	}
	else
	{
		SetValue ( D_Microcosm, notChk, Checked );
		SetValue ( D_MicrocosmTemp, notSens, Sensitive );
	}

	if ( si.co2Effect )					// CO2 effect
	{
		SetValue ( D_CO2Effect, isChk, Checked );	 // ...check
		SetValue ( D_CO2EffectYrSt, isSens, Sensitive ); // ...yr start
		sprintf ( displayStr, "%hd", si.co2YearStart);
		SetString ( D_CO2EffectYrSt, displayStr );
		SetValue ( D_CO2EffectYrEnd, isSens, Sensitive ); // ...yr end
		sprintf ( displayStr, "%hd", si.co2YearEnd);
		SetString ( D_CO2EffectYrEnd, displayStr );
	}
	else
		SetValue ( D_CO2Effect, notChk, Checked );
	if ( si.erosionFileName )			// erosion file name
	{
		std::string const name = si.erosionFileName->GetFullName ();
		if ( !name.empty() )
			SetString ( D_EroFileName, name.c_str() );
	}
	if ( si.depoFileName )				// deposition file name
	{
		std::string const name = si.depoFileName->GetFullName ();
		if ( !name.empty() )
			SetString ( D_DepFileName, name.c_str() );
	}
	sprintf ( displayStr, "%hd", mgmt->GetBlockCount() );	// num. blocks
	SetString ( D_SimBlkCnt, displayStr );
}

//	LoadDlg_BlockDef
//	Loads management scheme data into the "block definition' tabbed dialog.
void TMgmtEditorDlg::LoadDlg_BlockDef ()
{
	//--- Error checks
	if ( !mgmtDisp )
		return;				// no management!

	//--- load the data into the display
	LoadBlockLists ();
	UpdateDlg_EventList ();
}

//	LoadDlg_BlockInst
//	Loads management scheme data into the "block instances' tabbed dialog.
void TMgmtEditorDlg::LoadDlg_BlockInst ()
{
	//--- Error checks
	if ( !mgmtDisp )
		return;				// no management!

	//--- load the data into the display
	// Assumes that the block list has already been loaded by a
	// previous call to LoadDlg_BlockDef.
	UpdateDlg_InstList ();
}

//	LoadBlockLists
//	Loads the block string list into the specified list box.
void TMgmtEditorDlg::LoadBlockLists ()
{
	// Build the block list.
	short numBlks = BuildBlockLIst ();
	if ( numBlks )
	{
	    // Display the lists
	    // in the definitions tabbed dialog
	    short c = idxBlkListDef;		// index to cmd obj list item
	    cmdList[c].itemList = (void *)blkList;	// set pointer to list
	    SetValue (cmdList[c].cmdId, 0, ChangeListPtr);	// display list
	    if ( curFrameId == D_ToggleFrame2 )
		SetValue (cmdList[c].cmdId, 0, Hidden);	// make sure is visible
	    // in the instance tabbed dialog
	    c = idxBlkListInst;
	    cmdList[c].itemList = (void *)blkList;	// set pointer to list
	    SetValue (cmdList[c].cmdId, 0, ChangeListPtr);	// display list
	    if ( curFrameId == D_ToggleFrame3 )
		SetValue (cmdList[c].cmdId, 0, Hidden);	// make sure is visible
	    // update the dialog
	    blockDisp = mgmtDisp->GetBlock (0);	// get the 1st block
	}
	else
	{
		ClearDlgBlkDefList ();			// clear list display
		ClearDlgBlkInstList ();			// clear list display
	}
}

//	BuildBlockLIst
//	Build a list of abbreviated blocks from the block descriptions.
//	Returns the number of blocks.
short TMgmtEditorDlg::BuildBlockLIst ()
{
	short numBlks = mgmtDisp->GetBlockCount ();	// get number of blocks
	if ( numBlks )					// no blocks?
	{
		ClearBlockList ();			// empty the list
		// Reallocating the list every time is not efficient -
		// better to have a fixed number of pointers allocated at once,
		// then check each time if need more pointers.
		// This should be done for all lists.
		blkList = new char* [numBlks + 1];	// allocate
		char** p = blkList;			// temp. pointer
		for ( short i = 0; i <= numBlks; ++i )	// NULL the pointers
			*(p++) = 0;
		p = blkList;				// temp. pointer
		TManagementBlock* blk;			// pointer to a block
		for (short i = 0; i < numBlks; i++)	// for each block...
		{
			// build the list
			blk = mgmtDisp->GetBlock (i);	// get the block
			MakeBlkDescItemStr (*p, blk->GetDescription());
			++p;				// go to next string
		}
	}
	return numBlks;
}

//	UpdateInitSystem
//	Loads the initial system info.
void TMgmtEditorDlg::UpdateInitSystem ()
{
	TSimInfo& si = mgmtDisp->GetSimInfo ();		// simulation info
	if ( si.initManagement == SysType_CropGrass )
	{
		SetValue ( D_InitSysCrop, isChk, Checked );
		Evt_InitSysCrop ();
	}
	else if ( si.initManagement == SysType_Forest )
	{
		SetValue ( D_InitSysTree, isChk, Checked );
		Evt_InitSysTree ();
	}
	else if ( si.initManagement == SysType_Savanna )
	{
		SetValue ( D_InitSysBoth, isChk, Checked );
		Evt_InitSysBoth ();
	}
}

//	UpdateDlg_EventList
//	Loads the event list based on the currently selected block in blkList.
void TMgmtEditorDlg::UpdateDlg_EventList ()
{
	short numEvts;				// number of events in block
	char **p;				// ptr. to event descrip. list
	TManagementBlock *blk;			// pointer to a block
	TManagementEvent *evt;			// pointer to event
	short indexList;			// index of block descrip. list
	short i;				// loop index
	short j;				// index to event constants
	short c;				// command object index

	//--- Error checks
	if ( !mgmtDisp )
		return;

	// get the index of the currently selected item in the block list
	c = idxEvtList;					// index to list item
	indexList = (short)GetValue (D_BlkList);	// get index to item
	blockDisp = mgmtDisp->GetBlock (indexList);   	// get the block
	if ( !blockDisp )				// no blocks?
	{
		ClearDlgEvtList ();			// clear display
		goto skip_list;
	}
	blk = blockDisp;				// local pointer
	sprintf ( displayStr, "%hd", blk->GetBlockNum() );
	SetString ( D_BlkNumber, displayStr );		// block number
	SetString ( D_BlkDesc, blk->GetDescription() );	// block description
	sprintf ( displayStr, "%hd", blk->GetYearLength() );
	SetString ( D_BlkLenYrs, displayStr );		// block length years
	// build the event list
	ClearEventList ();				// delete prev. list
	numEvts = blk->GetEventCount ();		// get no. of events
	sprintf ( displayStr, "%hd", numEvts );
	SetString ( D_BlkEvtCnt, displayStr );	      	// and display
	if ( !numEvts )					// no events?
	{
		ClearDlgEvtList ();			// clear display
		goto skip_list;
	}
	evtList = new char* [numEvts + 1];		// allocate event list
	evtList[numEvts] = NULL;			// NULL at end of list
	p = evtList;					// temp. pointer
	for (i = 0; i < numEvts; i++)			// for each event...
	{
		evt = blk->GetEvent (i);		// get event
		j = (short) evt->type;			// index to constants
							// memory for string
		*p = new char [strlen(::eventDescrip[j]) + 1];
		strcpy (*p, ::eventDescrip[j]);		// copy string
		++p;					// go to next string
	}

	// Display the list
	cmdList[c].itemList = (void *)evtList;		// set pointer to list
	SetValue (cmdList[c].cmdId, 0, ChangeListPtr);	// display list
	// update the dialog
	evtDisp = blk->GetEvent (0);			// get 1st event
skip_list:
	if ( curFrameId == D_ToggleFrame2 )
		SetValue (cmdList[c].cmdId, 0, Hidden);	// make sure is visible
	UpdateDlg_EventData ();
}

//	UpdateDlg_EventData
//	Displays data associated with the event selected in evtList.
void TMgmtEditorDlg::UpdateDlg_EventData ()
{
	short indexList;			// index of event descrip. list
	short j;				// index to event constants

	if ( !blockDisp || !evtDisp )		// anything there?
	{
		ClearDlgEvtData ();
		ShowEventDataDialog (EvtDlg_NoEvt);
		return;
	}

	// get the currently selected item in the event list
	indexList = (short)GetValue (D_EvtList);	// get index to item
	evtDisp = blockDisp->GetEvent (indexList);	// get the event
	Assert ( evtDisp != NULL );

	// display the event data
	j = (short) evtDisp->type;    			// index to constants
	SetString (D_EvtType, (char*)eventName[j]);	// Type of event
							// range event?
	if ( evtDisp->haveRangeEvent )
	{
		// display "range event" toggle dialog
		DisplayRangeEvent ();			// display data
		ShowEventDataDialog (EvtDlg_Range);
	}
	else
	{
		// display "Century 4.0 event" toggle dialog
		DisplayCent4Event ();			// display data
		ShowEventDataDialog (EvtDlg_Cent4);
	}
}

//	DisplayRangeEvent
//	Displays the data associated with the range event specified.
//	Note: This does not force display of the toggle dialog for this data.
void TMgmtEditorDlg::DisplayRangeEvent ()
{
	sprintf ( displayStr, "%hd", evtDisp->yearStart); // year at start
	SetString (D_RngYrStart, displayStr);
	sprintf ( displayStr, "%hd", evtDisp->yearEnd);	// year at end
	SetString (D_RngYrEnd, displayStr);
	sprintf ( displayStr, "%d", evtDisp->valueStart); // value at start
	SetString (D_RngValStart, displayStr);
	sprintf ( displayStr, "%d", evtDisp->valueEnd);	// value at end
	SetString (D_RngValEnd, displayStr);
	for (short i = 0; i < 12; i++)			// monthly fractions
	{
		sprintf ( displayStr, "%d",
				evtDisp->fraction[i]);
		SetString (D_FracMo1 + i, displayStr);
	}
}

//	DisplayCent4Event
//	Displays the data associated with the Century 4.0-style event.
//	Note: This does not force display of the toggle dialog for this data.
void TMgmtEditorDlg::DisplayCent4Event ()
{
	sprintf ( displayStr, "%hd", evtDisp->year);	// edit:  Year of event
	SetString (D_EvtYear, displayStr);
	sprintf ( displayStr, "%hd", evtDisp->month);	// edit: Month of event
	SetString (D_EvtMonth, displayStr);
	SetString (D_EvtAdd, evtDisp->additional);	// edit: Add'l. info
}

//	UpdateDlg_InstList
//	Loads instance list based on the currently selected block in blkList.
void TMgmtEditorDlg::UpdateDlg_InstList ()
{
	short numInsts;				// number of instances in block
	char **p;				// ptr. to inst. descrip. list
	TManagementBlock *blk;			// pointer to a block
	TManagementInst *inst;			// pointer to instance
	short indexList;			// index of block descrip. list
	short i;				// loop index
	short c;				// command object index

	//--- Error checks
	Assert ( mgmtDisp != NULL );		// no management!

	// get the currently selected item in the block list
	c = idxInstList;				// index to list item
	indexList = (short)GetValue (D_BlkListInst);	// get index to item
	blockDisp = mgmtDisp->GetBlock (indexList);   	// get the block
	if ( !blockDisp )				// no blocks?
	{
		ClearDlgInstList ();			// clear display
		goto skip_list;
	}
	blk = blockDisp;				// local pointer
	SetString ( D_BlkDescInst, blk->GetDescription() );// block description
	// build the instance list
	ClearInstList ();
	numInsts = blk->GetInstanceCount ();		// get no. instances
	sprintf ( displayStr, "%hd", numInsts );
	SetString ( D_BlkInstCnt, displayStr );	      	// and display
	if ( !numInsts )				// no instances?
	{
		ClearDlgInstList ();
		goto skip_list;
	}
	instList = new char* [numInsts + 1];		// allocate inst. list
	instList[numInsts] = NULL;			// NULL at end of list
	p = instList;					// temp. pointer
	for (i = 0; i < numInsts; i++)			// for each instance...
	{
		inst = blk->GetInstance (i);		// get instance
		Assert ( inst != NULL );
		// build description string: e.g., "1900-2099"
		*p = new char [16];			// memory for string
		sprintf (*p, "%hd-%hd",
			 inst->yearFirst, inst->yearLast);
		++p;					// go to next string
	}

	// Display the list
	cmdList[c].itemList = (void *)instList;		// set pointer to list
	SetValue (cmdList[c].cmdId, 0, ChangeListPtr);	// display list
	// update the dialog
	instDisp = blk->GetInstance (0);		// get 1st instance
skip_list:
	if ( curFrameId == D_ToggleFrame3 )
		SetValue (cmdList[c].cmdId, 0, Hidden);	// make sure is visible
	UpdateDlg_InstData ();
}

//	UpdateDlg_InstData
//	Displays data associated with the instance selected in instList.
void TMgmtEditorDlg::UpdateDlg_InstData ()
{
	short indexList;			// index of inst. descrip. list

	if ( !blockDisp || !instDisp )	// anything there?
	{
		ClearDlgInstData ();
		return;
	}

	// get the currently selected item in the instance list
	indexList = (short)GetValue (D_InstList);
	instDisp = blockDisp->GetInstance (indexList);  	// get instance
	Assert ( instDisp != NULL );

	// load data
	sprintf ( displayStr, "%hd", instDisp->yearFirst);  // first sim. year
	SetString (D_FirstYear, displayStr);
	sprintf ( displayStr, "%hd", instDisp->yearLast);   // last sim. year
	SetString (D_LastYear, displayStr);
	if ( instDisp->weatherSource == WS_Means )	   // weather source
	{
		SetValue ( D_WthrMeans, isChk, Checked );
		DisableWeatherFileControls ();
	}
	else if ( instDisp->weatherSource == WS_Stochastic ||
		  instDisp->weatherSource == WS_Unknown )
 	{
		SetValue ( D_WthrStoch, isChk, Checked );
		DisableWeatherFileControls ();
	}
	else if ( instDisp->weatherSource == WS_FileRewind )
	{
		SetValue ( D_WthrFileRew, isChk, Checked );
		EnableWeatherFileControls ();
	}
	else if ( instDisp->weatherSource == WS_FileContinue )
	{
		SetValue ( D_WthrFileCont, isChk, Checked );
		DisableWeatherFileControls ();
	}
	sprintf ( displayStr, "%hd",
			instDisp->outputStartYr); // out. yr in blk
	SetString (D_OutputYr, displayStr);
	sprintf ( displayStr, "%hd",
			instDisp->outputStartMo); // out. mo. start
	SetString (D_OutputMo, displayStr);
	::sprintf (displayStr, "%f", instDisp->outputInterval); // output freq.
	SetString (D_OutputFreq, displayStr);

	TEH::TFileName weatherFileName (
		instDisp->weatherFile, TEH::TFileName::FT_Normal);
	// make sure weather file name includes a path
	/*
	if ( weatherFileName.GetFullPath().empty() )	// no path?
	{
	    if ( !workPath.empty() )
	    {
		weatherFileName.SetPath (workPath);	// add work dir
		instDisp->weatherFile = weatherFileName.GetFullName();
		mgmtDisp->modified = true;
	    }
	    else
	    {
	    	// to do - need another path
	    }
	}
	*/

	// display weather file name
	if ( !instDisp->weatherFile.empty() )
		SetString (D_WthrFileName, instDisp->weatherFile.c_str() );
	else
		SetString (D_WthrFileName, "");

	// check the weather file status and display status message
	if ( instDisp->weatherFile.empty() )
		SetString ( D_WthrFileMsg, "File name not entered!" );
	else if ( !weatherFileName.IsValid() )
		SetString ( D_WthrFileMsg, "Invalid file name!" );
	else if ( !weatherFileName.Exists() )
		SetString ( D_WthrFileMsg, "File not found!" );
	else
		SetString ( D_WthrFileMsg, "" );
}

// --- end of TMgmtEditorDlgLoad.cpp ---

