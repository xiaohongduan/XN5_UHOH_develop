#ifndef INC_OutputSoilWaterTempLayers_h
#define INC_OutputSoilWaterTempLayers_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  OutputSoilWaterTempLayers.h
//	Class:	  OutputSoilWaterTempLayers
//
//	Description:
//	Writes soil water content and temperature by layer interval
//	to an output file in CSV format.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, July 2005
//	History:
//	2005Oct	Tom Hilinski
//	* Added output for soil water content at saturation.
// ----------------------------------------------------------------------------
//	Notes:
//	(1) File structure:
//	Each output appends to the table.
//	The columns are like this:
//	time, thickness, swc0, swc1, ..., swcN, st0, st1, ..., stN
// ----------------------------------------------------------------------------

#include "TCSVFileBase.h"
#include "TSoilPool.h"
#include "TSoilProperty.h"
#include "arraytypes.h"
#include <iosfwd>

class OutputSoilWaterTempLayers
	: public ::nrel::io::TCSVFileBase
{
  public:
  	typedef TSoilVDCompBase::TFloatArray	TFloatArray;
  	typedef TFloatArray::size_type		size_type;

	OutputSoilWaterTempLayers (
	  float const useIntervalThickness,	// thickness of depth intervals
	  short const useIntervalMaxCount,	// max. number of intervals
  	  TSoilPool const & useSoilH2O,		// soil water content object
  	  TSoilProperty const & useFldCapacity,	// soil field capacity
	  T1DDoubleArray const & useThetaSat,	// soil water saturation content
  	  TSoilProperty const & useSoilTemp,	// soil temperature object
	  TFloatArray const & useDepth,		// array of depth values
	  TFloatArray const & useThickness,	// array of thickness values
	  std::string const & useFileName, 	// file name with path
	  bool const appendToFile = false)	// true if appending to file
	  : ::nrel::io::TCSVFileBase (
	  	useFileName, Access_WriteOnly, Location_Local,
	  	false /* do not open at construction */ ),
	    intervalThickness (useIntervalThickness),
	    intervalMaxCount (useIntervalMaxCount),
	    soilH2O (useSoilH2O),
	    fldCapacity (useFldCapacity),
	    thetaSat (useThetaSat),
	    soilTemp (useSoilTemp),
	    depth (useDepth),
	    thickness (useThickness)
	  {
	    // init output
	    if ( !appendToFile )
	    {
		TStringArray titles;
		CreateTitles (titles);
		WriteColumnTitles (titles);
	    }
	  }
	~OutputSoilWaterTempLayers ()
	  {
	  }
	OutputSoilWaterTempLayers (
	  OutputSoilWaterTempLayers const & object)
	  : ::nrel::io::TCSVFileBase (object),
	    intervalThickness (object.intervalThickness),
	    intervalMaxCount (object.intervalMaxCount),
	    soilH2O (object.soilH2O),
	    fldCapacity (object.fldCapacity),
	    thetaSat (object.thetaSat),
	    soilTemp (object.soilTemp),
	    depth (object.depth),
	    thickness (object.thickness)
	  {
	  }

	OutputSoilWaterTempLayers & operator= (
	  OutputSoilWaterTempLayers const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	// to do: operator=
	    }
	    return *this;
	  }
	bool operator== (
	  OutputSoilWaterTempLayers const & object) const
	  {
	    if ( &object )
		return
		  intervalThickness == object.intervalThickness &&
		  soilH2O == object.soilH2O &&
		  fldCapacity == object.fldCapacity &&
		  ARRAY_EQUAL<T1DBoolArray> (thetaSat, object.thetaSat) &&
		  soilTemp == object.soilTemp &&
		  depth == object.depth;
	    else
	    	return false;
	  }
	bool operator!= (
	  OutputSoilWaterTempLayers const & object) const
	  { return !(*this == object); }

	bool Write (				// write the data
	  float const outputTime);		// time of output

  private:
  	float const intervalThickness;		// thickness of depth intervals
  	short const intervalMaxCount;		// maximum number of intervals
  	TSoilPool const & soilH2O;		// soil water content object
	TSoilProperty const & fldCapacity;	// soil field capacity
	T1DDoubleArray const & thetaSat;	// saturation water content
  	TSoilProperty const & soilTemp;		// soil temperature object
	TFloatArray const & depth;		// array of depth values
	TFloatArray const & thickness;		// array of thickness values
						//   for each variable

	void CreateTitles (			// make column titles
	  TStringArray & titles);		//   list of column titles

	virtual bool DoWriteHeader (		// Write file header to stream
	  TStringArray const & header)		//   file header strings
	  {
	    return false; // no-op
	  }
	virtual bool DoWriteColumnTitles (	// Write column titles to stream
	  TStringArray const & titles);		//   list of column titles
	virtual bool DoReadColumnTitles (	// Read col. titles from stream
	  TStringArray & titles)		//   list of column titles
	  {
	    return false; // no-op
	  }
	float WtdMean (
	  T1DDoubleArray const & values,	// values to get mean of
	  float const topDepth, 		// depth to top of layer (cm)
	  float const bottomDepth,		// depth to bottom of layer (cm)
	  TFloatArray const & depth,		// depth values
	  TFloatArray const & thickness		// thickness values
	  ) const;
	size_type GetLayerIndex (		// Find zero-based layer index
	  float const findDepth			//   depth to search for
	  ) const;				//   <- depth.size() if failed

};


#endif // INC_OutputSoilWaterTempLayers_h
