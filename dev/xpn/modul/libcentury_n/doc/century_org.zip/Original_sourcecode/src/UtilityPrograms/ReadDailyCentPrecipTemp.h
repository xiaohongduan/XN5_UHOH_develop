#ifndef INC_nrel_util_ReadDailyCentPrecipTemp_h
#define INC_nrel_util_ReadDailyCentPrecipTemp_h

// ----------------------------------------------------------------------------
//	Copyright 2002, 2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  ReadDailyCentPrecipTemp.h
//	Class:	  ReadDailyCentPrecipTemp
//
//	Description:
//	Reads precip and temperature data from Century daily weather file
//	into arrays.
//---------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May2005 (C++ driver)
//		Cindy Keough, 2002, file read, and statistical functions.
//	History:
//	
//---------------------------------------------------------------------------

#include <string>
#include <utility>
#include "arraytypes.h"
#include "TInterval.h"

namespace nrel
{

  namespace util
  {

class ReadDailyCentPrecipTemp
{
  public:
	//---- types
	typedef std::pair<long, short>		TSizeDimensions; // year, month	

	//---- constructors and destructor
	ReadDailyCentPrecipTemp (
	  std::string const & fileName,
	  long const yearStart,
	  long const yearEnd);
	ReadDailyCentPrecipTemp (
	  ReadDailyCentPrecipTemp const & object)
	  {
	    Copy (object);
	  }
	~ReadDailyCentPrecipTemp ()
	  {
	  }

	//---- operator overloads
	ReadDailyCentPrecipTemp& operator= (
	  ReadDailyCentPrecipTemp const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
		Clear ();
		Copy (object);
	    }
	    return *this;
	  }
	bool operator== (
	  ReadDailyCentPrecipTemp const & object) const;
	bool operator!= (
	  ReadDailyCentPrecipTemp const & object) const
	  { return !(*this == object); }

	//---- functions
	T2DFloatArray const & Precip ()
	  { return precip; }
	float Precip (
	  long const year,
	  short const month)
	  { return precip(year, month); }

	T2DFloatArray const & TempMin ()
	  { return tempMin; }
	float TempMin (
	  long const year,
	  short const month)
	  { return tempMin(year, month); }

	T2DFloatArray const & TempMax ()
	  { return tempMax; }
	float TempMax (
	  long const year,
	  short const month)
	  { return tempMax(year, month); }

	TInterval<long> YearRange () const
	  { return yearRange; }

	bool IsEmpty () const
	  {
	    return
		precip.empty() &&
		tempMin.empty() &&
		tempMax.empty();
	  }
	TSizeDimensions Size () const
	  {
	    TSizeDimensions dim;
	    dim.first = precip.size().first;
	    dim.second = precip.size().second;
	    return dim;
	  }

	int GetRecordsRead () const
	  { return recordCount; }

	float GetMissingValue () const
	  { return missingValue; }

	std::string const & GetErrorMsg () const
	  { return errorMsg; }

	void Clear ();					// "clear" data members
	static char const * const GetVersion ()		// Return version
	  { return version; }

  protected:
	//---- data

	//---- functions

  private:
	//---- constants
	static char const * const version;	// class version number
	static const float missingValue;

	//---- data
	std::string errorMsg;
	int recordCount;		// number of records read
	T2DFloatArray precip;		// precipitation [year][month]
	T2DFloatArray tempMin;		// minimum temperature [year][month]
	T2DFloatArray tempMax;		// maximum temperature [year][month]
	TInterval<long> yearRange;	// year range of the data

	//---- functions
	bool IsComment (			// True if a comment char
	  char const * const s
	  ) const
	  {
	    // function source: weather data framework
	    return *s == '#' || *s == '!' || *s == ';' ||
	    	(*s == '/' && *(s + 1) == '/');
	  }
	TSizeDimensions GetRecordsInFile (
	  std::FILE * const fp);
	int process_daily_weather (	// Read data and return record count
	  std::FILE * const wthrfp,	//   file to read
	  T2DFloatArray & prec,		//   precipitation [year][month]
	  T2DFloatArray & tmin,		//   minimum temperature [year][month]
	  T2DFloatArray & tmax,		//   maximum temperature [year][month]
	  TInterval<long> & yearRange);	//   year range of the data
	bool ReadData (			// Reads the data
	  std::string const & fileName,
	  long const yearStart,
	  long const yearEnd);
	void Copy (					// copy to this
	  const ReadDailyCentPrecipTemp &object);
};


  }	// namespace util

}	// namespace nrel

#endif // INC_nrel_util_ReadDailyCentPrecipTemp_h

