// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  firrtn.cpp
//	Class:	  TCentury
//	Function: FireEvent
//
//	Description:
//	Elemental return from a fire event.
//	Only burn litter if a forest system.  Litter is burned in
//	grem for the savanna system.
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------

#include "TCentury.h"

void TCentury::FireEvent ()
{
    float egain[NUMELEM];	// element amounts
    for (short element = 0; element < site.nelem; ++element)
	egain[element] = 0.0f;

    // Litter is burned in RemoveCropGrass for crop/grass/savanna fire.
    if ( sched->DoingForestFire() )
	BurnLitter (egain);

    // Return from TREE compartments
    // Carbon return is usually 0.  It is ignored since it
    // would be returned as charcoal.  N, P, and S returns
    // go to the top layer of minerl.  EGAIN will contain
    // the total returns for N, P, and S across pools.
    for (short element = 0; element < site.nelem; ++element)
    {
	egain[element] += egain[element] +
	    forrem.remf[0] * retf_ref (0, element+ 1) * nps.rleave[element] +
	    forrem.remf[1] * retf_ref (1, element + 1) * nps.fbrche[element] +
	    forrem.remf[2] * retf_ref (2, element + 1) * nps.rlwode[element] +
	    forrem.remf[3] * retf_ref (1, element + 1) * nps.wood1e[element] +
	    forrem.remf[4] * retf_ref (2, element + 1) * nps.wood2e[element] +
	    forrem.remf[2] * retf_ref (2, element + 1) * nps.forstg[element];
	soilFlows->FlowNPSintoMineralSoil (
		(TMineralElements)element,
		&nps.esrsnk[element], egain[element], wt.simDepth );
    }
}

//--- end of file ---
