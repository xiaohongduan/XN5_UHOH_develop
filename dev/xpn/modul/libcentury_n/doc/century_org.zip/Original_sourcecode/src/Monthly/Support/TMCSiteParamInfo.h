#ifndef INC_TSiteParamInfo_h
#define INC_TSiteParamInfo_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TMCSiteParamInfo.h
//	Class:	  TMCSiteParamInfo
//
//	Description:
//	Class for Century site parameter definitions, TMCSiteParamInfo.
//	An associated class is TMCSiteParameters which manages the site params.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Feb98, tom.hilinski@colostate.edu
//	History:
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* A bit of cleaning up.
//	* Added copy constructor and operator=
//	Oct01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added additional constructors.
//	Mar02	Tom Hilinski, tom.hilinski@colostate.edu
//	* ReadNamesDescs - Now checks result of nc.Read()
//	Jul02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Now has pointer to owner.
//	* Only instantiate from inside the TMCSiteParameters class.
//	Jan03	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to use the new base class TSiteParamInfoBase
//	* Changed name of class and file to TMCSiteParamInfo.
//	Sep03	Tom Hilinski
//	* Site parameters set indices list must be created outside of
//	  the SiteParameters classes.
//	Feb05	Tom Hilinski
//	* Added error string information, with access functions.
// ----------------------------------------------------------------------------

#include "TSiteParamInfoBase.h"
#include "TMCSiteParIndices.h"

//	-----------------------------------------------------------------------
//	Forward references
class TNcSiteParamDef;		// for friend classes to do netCDF I/O

// ----------------------------------------------------------------------------
//	TMCSiteParamInfo
//	Contains the data describing individual parameters.
class TMCSiteParamInfo
	: public TSiteParamInfoBase
{
	// Friend classes for all handling all netCDF file I/O.
	friend class TNcSiteParamDef;		// reads parameter definitions

  public:
	//--- types
	// the parameter indices are publicly accessible here
	static TMCSiteParIndices indices;

	//--- constructors and destructor
	TMCSiteParamInfo (
	  TEH::TFileName const & useSiteParamInfoFile)	// path +/- name
	  : TSiteParamInfoBase ()
	  {
	    Constructor (useSiteParamInfoFile);
	  }
	TMCSiteParamInfo (
	  std::string const & useSiteParamInfoFile)	// path +/- name
	  : TSiteParamInfoBase ()
	  {
	    TEH::TFileName theInfoFileName ( useSiteParamInfoFile.c_str() );
	    Constructor (theInfoFileName);
	  }
	TMCSiteParamInfo (
	  char const * const useSiteParamInfoFile)	// path +/- name
	  : TSiteParamInfoBase ()
	  {
	    TEH::TFileName theInfoFileName (useSiteParamInfoFile);
	    Constructor (theInfoFileName);
	  }
	TMCSiteParamInfo (				// copy constructor
	  TMCSiteParamInfo const & object)
	  : TSiteParamInfoBase (object)
	  {
	  }
	virtual ~TMCSiteParamInfo ()
	  {
	  }

	//---- operator overloads

	//--- functions

  private:
	//--- data
	static char const * const defaultFileName;	// default file name

	//--- functions
	virtual bool ReadNamesDescs (			// read param info file
	  TEH::TFileName const & infoNCFileName);
	void Constructor (				// Common constructor
	  TEH::TFileName const & useSiteParamInfoFile);
	virtual void FillSiteSetIndicesList ();		// fill siteSetIdx
};

#endif // INC_TSiteParamInfo_h
