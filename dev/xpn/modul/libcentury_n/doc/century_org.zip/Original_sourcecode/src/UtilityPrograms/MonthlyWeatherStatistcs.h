#ifndef INC_nrel_util_MonthlyWeatherStatistcs_h
#define INC_nrel_util_MonthlyWeatherStatistcs_h

// ----------------------------------------------------------------------------
//	Copyright 2002, 2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  MonthlyWeatherStatistcs.h
//	Class:	  MonthlyWeatherStatistcs
//
//	Description:
//	Class to calculate monthly statistics and
//	generate a site parameter set.
//---------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May2005 (C++ driver)
//		Cindy Keough, 2002, file read, and statistical functions.
//	History:
//	
//---------------------------------------------------------------------------

#include "arraytypes.h"
#include <iosfwd>

namespace nrel
{

  namespace util
  {

class MonthlyWeatherStatistcs
{
  public:
	MonthlyWeatherStatistcs (
	  T2DFloatArray const & precip,	   // precipitation [year][month]
	  T2DFloatArray const & tempMin,   // minimum temperature [year][month]
	  T2DFloatArray const & tempMax,   // maximum temperature [year][month]
	  float const missingValue)
	  {
	    Initialize (missingValue);
	    DoStatistics (precip, tempMin, tempMax, missingValue);
	  }
	~MonthlyWeatherStatistcs ()
	  {
	  }

	void WriteSiteParameters (
	  std::ostream & os);

	T1DFloatArray const & GetPrecipMean()
	  { return precipMean; }
	T1DFloatArray const & GetPrecipStdDev()
	  { return precipStdDev; }
	T1DFloatArray const & GetPrecipSkewness()
	  { return precipSkew; }
	T1DFloatArray const & GetTempMinMean()
	  { return tempMinMean; }
	T1DFloatArray const & GetTempMaxMean()
	  { return tempMaxMean; }

  private:
	//---- constants
	static std::string const precipMeanName;
	static std::string const precipStdDevName;
	static std::string const precipSkewName;
	static std::string const tempMinMeanName;
	static std::string const tempMaxMeanName;

	//---- data
	T1DFloatArray precipMean;
	T1DFloatArray precipStdDev;
	T1DFloatArray precipSkew;
	T1DFloatArray tempMinMean;
	T1DFloatArray tempMaxMean;

	void Initialize (
	  float const missingValue);
	void DoStatistics (
	  T2DFloatArray const & precip,	   // precipitation [year][month]
	  T2DFloatArray const & tempMin,   // minimum temperature [year][month]
	  T2DFloatArray const & tempMax,   // maximum temperature [year][month]
	  float const missingValue);

};

  }	// namespace util

}	// namespace nrel

#endif // INC_nrel_util_MonthlyWeatherStatistcs_h


