
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include "netcdf.h"
#include "wrtcdf.h"

int
write_crop(float crop[][12])
{
        int status;
        float *p = (float *) crop;

	/* Write output to NetCDF file */
	status = nc_put_vara_float(crop_ncid, crpval_id, start, count, p);
	status = nc_put_vara_float(crop_ncid, crmvst_id, start, count, p + 12);
	status = nc_put_vara_float(crop_ncid, cgrain_id, start, count, p + 24);
	status = nc_put_vara_float(crop_ncid, feramt_id, start, count, p + 36);
	status = nc_put_vara_float(crop_ncid, irract_id, start, count, p + 48);
	status = nc_put_vara_float(crop_ncid, egrain_id, start, count, p + 60);
	status = nc_put_vara_float(crop_ncid, ermvst_id, start, count, p + 72);

	/* Reset memory for variable soilc */
	 memset(p, '\0', (sizeof(float) * 7 * 12));

	return 0;
}
