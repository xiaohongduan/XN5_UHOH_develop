// ----------------------------------------------------------------------------
//	Project:  V GUI Enhancement
//	File:	  TFileSelDlg.cpp
//	Class:	  TFileSelectDlg
//
//	Description:
//	Class for file selection dialog box.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, 19Aug99
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// Copyright (c) 1999 Thomas E. Hilinski. All rights reserved.
// Unauthorized distribution, duplication, sale, and use is prohibited by law.
// ----------------------------------------------------------------------------

#include "TFileSelDlg.h"

//	FileSelect
//	Open a new or existing file ("Open").
//	Returns true if the user pressed the OK button,
//	or false if the user pressed the Cancel button,
//	or false if error.
bool TFileSelectDlg::FileSelect (
	char const* const prompt,	// user prompt
	char* fileName, 		// selected file name
	int const maxLen, 		// maximum length of fileName
	char const** const filters, 	// list of filters
	int& filterIndex,		//   starting & ending filter
	char const* const initialPath)	// starting path
{
	if ( ToInitialPath (initialPath) )	// change path to starting path
		return false;			// error
	//--- get file
	bool retVal = true;			// return value
	if ( DoFileSelection (prompt, fileName, maxLen,
				filters, filterIndex, initialPath, false) )
		retVal = false;			// error or cancel button
	//--- else successful and OK button
	if ( ToPreviousPath () )		// change path to original
		retVal = false;			// error
	return retVal;
}

//	FileSelectSave
//	Save to a file ("Save" or "Save As").
//	Returns true if the user pressed the OK button,
//	or false if the user pressed the Cancel button,
//	or false if error.
bool TFileSelectDlg::FileSelectSave (
	char const * const prompt,	// user prompt
	char* fileName, 		// selected file name
	int const maxLen, 		// maximum length of fileName
	char const** const filters, 	// list of filters
	int& filterIndex,		//   starting & ending filter
	char const * const initialPath)	// starting path
{
	if ( ToInitialPath (initialPath) )	// change path to starting path
		return false;			// error
	//--- get file
 	bool retVal = true;			// return value
	if ( DoFileSelection (prompt, fileName, maxLen,
				filters, filterIndex, initialPath, true) )
		return false;			// error or cancel button
	//--- else successful and OK button
	if ( ToPreviousPath () )		// change path to original
		retVal = false;			// error
	return retVal;
}

//	ToInitialPath
//	Change current directory to the path in which the dialog box
//	will open to.
//	Returns false if successful, else true if not or error.
bool TFileSelectDlg::ToInitialPath (
	char const* initialPath)
{
	//--- error checks
	if ( !initialPath || !(*initialPath) )		// anything to do?
		return false;				// ...pretend success
	//--- save current directory
	int result = os.vGetCWD (prevPath, 1023);
	if ( result == 0 )
		return true;
	//--- change to working directory
	if ( initialPath && *initialPath )
	{
		result = os.vChDir (initialPath);
		if ( result == 0 )
			return true;
	}
	//--- all done!
	return false;
}

//	ToPreviousPath
//	Sets the current directory to the original directory.
//	Returns false if successful, else true if not or error.
bool TFileSelectDlg::ToPreviousPath ()
{
	//--- error checks
	if ( !prevPath || !(*prevPath) )		// anything to do?
		return false;				// ...pretend success
	//--- change to previous path
	int result = os.vChDir (prevPath);	// change path
	if ( result == 0 )			// check result
		return true;			// failed
	else
		return false;			// successful
}

//	DoFileSelection
//	Do the file selection.
//	Returns false if successful, else true if not or error.
bool TFileSelectDlg::DoFileSelection (
	char const * const prompt,	// user prompt
	char* fileName, 		// selected file name
	int const maxLen, 		// maximum length of fileName
	char const** const filters, 	// list of filters
	int& filterIndex,		// starting & ending filter
	char const * const initialPath,	// starting path
	bool const save)		// true if save file else open
{
	//--- browse
	int result;
	if ( save )
	{
		result = vFileSelect::FileSelectSave (
				prompt, fileName, maxLen,
				const_cast<char**>(filters),
				filterIndex, initialPath );
	}
	else
	{
		result = vFileSelect::FileSelect (
				prompt, fileName, maxLen,
				const_cast<char**>(filters),
				filterIndex,
				(char const *)initialPath);
	}
	//--- all done!
	if ( result == 0 )			// failed or canceled?
		return true;			// ...yes
	else
		return false;			// ...successful!
}

//--- end of file ---
