// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model, daily version
//	File:	leachNPS.cpp
//	Class:	TDayCentSoil
//	Function: LeachMineralNPS
//
//	Description:
//	Leaching of mineralized N, P, and S.
// ----------------------------------------------------------------------------
//	Author: 2/92 -rm
//	History:
//	See Century/leach.cpp
//	Feb1997  Melannie Hartman, melannie@NREL.colostate.edu
//	* Created original leachdly.c for FORTRAN/C version of DayCent
//	Dec1999  Tom Hilinski, tom.hilinski@colostate.edu
//	* Created TCentury::LeachMineralNPS() from FORTRAN leach.f.
//	* Local variable amtLeached was an array [MAXLYR], but array wasn't
//	  needed, so made it a scalar value.
//	* Changed names of some variables for readability.
//	* Reduced the number of function parameters.
//	* Additional optimization of loops.
//	Apr2001  Melannie Hartman, melannie@NREL.colostate.edu
//	* added deepSoilMnrlStore[NUMELEM] to TDayCentSoil Class,
//	  eliminated reference to layer Nitrate(numlyrs)
//	Jun2001  Melannie Hartman, melannie@NREL.colostate.edu
//	* Merged Tom's version of TCentury::LeachMineralNPS() with
//	  leachdly to create TDayCentSoil::LeachMineralNPS().
//	* Added function parameters
//	* Updated LeachMineralNPS() to work with Nitrate(), Phosphorus(),
//	  and Sulfur() soil components
//	Nov02   Tom Hilinski
//	* Misc. clean up, const-correctness, optimization.
//	Apr03   Tom Hilinski
//	* Apply bug fixes to issues found by Melannie (see Tutos bug tracking).
//	May03	Tom Hilinski
//	* Additional assertions and some minor cleanup.
// ----------------------------------------------------------------------------

#include "TDayCentSoil.h"
#include "TDayCent.h"
using namespace std;

void TDayCentSoil::LeachMineralNPS (
    short const numElements,	// number of elements to be leached (1-3)
    float const critflow,	// critical interlayer water flow for leaching
				//   of inorganic soil minerls (cm H2O/day)
    T1DFloatArray const & fractionLeached, // leaching fraction for each mineral
    float const baseFlowFraction,	// base flow fraction (0-1)
    float const stormFlowFraction,	// storm flow fraction (0-1)
    float * const stream)		// daily stream flows (set stream[E])
{
    //---  check function arguments
    Assert (numElements > 0);
    Assert (numElements <= NUMELEM);
    Assert (stormFlowFraction >= 0.0f);
    Assert (stormFlowFraction <= 1.0f);
    Assert (baseFlowFraction >= 0.0f);
    Assert (baseFlowFraction <= 1.0f);
    Assert (stream != 0);

    //--- constants
    double const initialTotalN =
	Nitrate().Quantity (0, BottomLayer()) + deepSoilMnrlStore[N];
    double const critflow_recip = 1.0 / critflow;      // optimize
    float const minimumLeachAmount = 1.0e-8f;

    //--- Leach each element
    for (short element = 0; element < numElements; ++element)
    {
	double stormFlow = 0.0f;	// E leached in storm flow (gN/m^2)
	double baseFlow = 0.0f;		// E leached in base flow (gN/m^2)

	for (short layer = 0; layer < GetLayerCount(); ++layer)
	{
	    // GetWaterTransferred(layer) > 0 indicates
	    // saturated water flow out of layer
	    if (amtTrans(layer) <= 0.0f)		// anything to do?
		continue;				// ...no - to next layer

	    double leachIntensity =			// leaching intensity
		1.0 - ( critflow - amtTrans(layer) ) * critflow_recip;
	    leachIntensity = std::min (1.0, leachIntensity);
	    leachIntensity = std::max (0.0, leachIntensity);

	    switch (element)
	    {
	      case N:
		if (Nitrate(layer) > minimumLeachAmount)
		{
		    // amount leached from layer (g/m^2)
		    Assert (fractionLeached(N) >= 0.0f);
		    Assert (fractionLeached(N) <= 1.0f);
		    double const amtLeached =
			fractionLeached(N) * Nitrate(layer) * leachIntensity;
		    Assert(amtLeached >= 0.0);
		    if (amtLeached < Nitrate(layer))
		    {
			Nitrate(layer) -= amtLeached;
			// If at the bottom layer, compute storm flow
			if (layer == BottomLayer())
			{
				stormFlow = amtLeached * stormFlowFraction;
				deepSoilMnrlStore[N] += amtLeached - stormFlow;
			}
			else
			{
				Nitrate(layer+1) += amtLeached;
			}
		    }
		}
		break;

	      case P:
		if (Phosphorus(layer) > minimumLeachAmount)
		{
		    // amount leached from layer (g/m^2)
		    Assert (fractionLeached(P) >= 0.0f);
		    Assert (fractionLeached(P) <= 1.0f);
		    double const amtLeached =
			fractionLeached(P) * Phosphorus(layer) * leachIntensity;
		    Assert(amtLeached >= 0.0);
		    if (amtLeached < Phosphorus(layer))
		    {
			Phosphorus(layer) -= amtLeached;
			// If at the bottom layer, compute storm flow
			if (layer == BottomLayer())
			{
				stormFlow = amtLeached * stormFlowFraction;
				deepSoilMnrlStore[P] += amtLeached - stormFlow;
			}
			else
			{
				Phosphorus(layer+1) += amtLeached;
			}
		    }
		}
		break;

	      case S:
		if (Sulfur(layer) > minimumLeachAmount)
		{
		    // amount leached from layer (g/m^2)
		    Assert (fractionLeached(S) >= 0.0f);
		    Assert (fractionLeached(S) <= 1.0f);
		    double const amtLeached =
			fractionLeached(S) * Sulfur(layer) * leachIntensity;
		    Assert(amtLeached >= 0.0);
		    if (amtLeached < Sulfur(layer))
		    {
			Sulfur(layer) -= amtLeached;
			// If at the bottom layer, compute storm flow
			if (layer == BottomLayer())
			{
				stormFlow = amtLeached * stormFlowFraction;
				deepSoilMnrlStore[S] += amtLeached - stormFlow;
			}
			else
			{
				Sulfur(layer+1) += amtLeached;
			}
		    }
		}
		break;
	    } // switch (element)
	} // for layer

	// Compute base flow and mineral stream flows.
	if (deepSoilMnrlStore[element] > minimumLeachAmount)
	{
	    baseFlow = deepSoilMnrlStore[element] * baseFlowFraction;
	    deepSoilMnrlStore[element] -= static_cast<double>(baseFlow);
	}
	stream[element] = static_cast<float>( stormFlow + baseFlow );
    } // for element

    // Check N balance
    double const finalTotalN =
	Nitrate().Quantity (0, BottomLayer()) + deepSoilMnrlStore[N] +
	 stream[N];
    dynamic_cast<TDailyCenturyBase const &>(owner).BalanceCheckWithMsg (
	initialTotalN, finalTotalN, 5.0E-5, "LeachNPS total N" );
}

//--- end of file ---
