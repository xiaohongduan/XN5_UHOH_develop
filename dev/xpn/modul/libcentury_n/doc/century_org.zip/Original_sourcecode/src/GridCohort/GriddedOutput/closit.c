
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <stdlib.h>
#include "netcdf.h"
#include "wrtcdf.h"

void
closit_(int *savall)
{
	/* Close all NetCDF files */
	int status;

	status = nc_close (site_ncid);

	if (*savall == 1)
	{
		status = nc_close (crop_ncid);
		status = nc_close (h2o_ncid);
		status = nc_close (livc_ncid);
		status = nc_close (livn_ncid);
		status = nc_close (nflux_ncid);
		status = nc_close (nmnr_ncid);
		status = nc_close (nupt_ncid);
		status = nc_close (prod_ncid);
		status = nc_close (resp_ncid);
		status = nc_close (soilc_ncid);
		status = nc_close (soiln_ncid);
		status = nc_close (cremv_ncid);
		status = nc_close (nremv_ncid);
	}

	return;
}
