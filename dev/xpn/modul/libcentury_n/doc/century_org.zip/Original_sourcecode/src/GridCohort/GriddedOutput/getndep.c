
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include "gridconst.h"

/* Prototypes */
void lineparse(char*, float[], int);

/* Externally defined variables */
extern int curr_row;
extern FILE *fp_ndep;

/* Read N deposition from grid */

int
getndv_(float *ndep, int *nrow, int *ncol)
{
	static char lineN[MAXR];
	static float andep[MAXE];
	int retval;
        int save_row;

	retval = 0;

        /* save the value of curr_row so it can be reset before
           getsoil is called.
        */ 
        save_row = curr_row;

	while (*nrow >= curr_row)
	{
		/* Read in line from landuse file */
		fgets(&lineN[0], MAXR, fp_ndep);

		/* Parse records into storage arrays */
		if (curr_row == *nrow)
		{
			/* Parse records to pull out data by cell */
			lineparse(lineN, andep, (int)MAXE);
		}

		/* Increment current row counter */
		curr_row += 1;
	}

	/* Do you have the correct row if you are returning to this function? */
	if (curr_row == *nrow + 1)
	{
		*ndep = (float) andep[*ncol];

		/* Scale from kg/km2/yr to g/m2/yr */
		*ndep = *ndep / 1000 ;
	}

        curr_row = save_row;

	return retval;
}
