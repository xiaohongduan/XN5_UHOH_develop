// ----------------------------------------------------------------------------
//    Project:  Century Soil Organic Matter Model, daily version
//    File:	potbst.cpp
//    Class:	TDayCent
//    Function: float PotentialTranspRate()
//
//    Description:
//    Return the potential transpiration rate (cm/day)
//    See 2.11 in ELM doc.
//
//    Author: Susan Chaffee, Melannie Hartman, Bill Parton
// ----------------------------------------------------------------------------
//    History:
//    Apr1992  Susan L. Chaffee
//    * Created potbst.f
//    Sep1993  Melannie Hartman  melannie@NREL.colostate.edu
//    * Translated potbst.f to potbst.c
//    MMMYYYY  Melannie Hartman  melannie@NREL.colostate.edu
//    * Updated for FORTRAN/C version of DayCent model
//    Apr2001  Melannie Hartman  melannie@NREL.colostate.edu
//    * Translated potbst.c to potbst.cpp
//	Nov02   Tom Hilinski, tom.hilinski@colostate.edu
//	* Misc. clean up, const-correctness, optimization.
// ----------------------------------------------------------------------------
//    Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//    Calls:
//      float WaterRate() - compute transpiration rate
// ----------------------------------------------------------------------------
#include "TDayCent.h"
#include "TCenturyMath.h"
#include <algorithm>
using namespace std;

//  Weighted average soil water potential over the soil profile
//  for transpiration
//  (see similar code in TDayCentSoil::SoilTranspiration)
float TranspirationWtdMeanSWPotential (
    T1DFloatArray const & soilWaterPotential, // soil h2o potential (bars > 0)
    float const awtl[])  		      // root density factors for
					      //   tran. water loss
					      //   values range 0-1
{
    float swpAvg = 0.0f;	// wtd mean soil water potential (bars > 0)
    float sumAWTL = 0.0f;	// sum of transpiration coefficients
    for (short layer = 0; layer <  soilWaterPotential.size(); layer++)
    {
	float const actualAWTL =
	    ( layer < MAXLYR ? awtl[layer] : awtl[MAXLYR - 1] );
	Assert ( actualAWTL >= 0.0f );
	Assert ( soilWaterPotential(layer) > 0.0f );
	swpAvg += actualAWTL * std::min ( 30.0f, soilWaterPotential(layer) );
	sumAWTL += actualAWTL;
    }
    swpAvg /= sumAWTL;
    return swpAvg;
}

float TDayCent::PotentialTranspRate (
    float const biomassLive,	// live above-ground biomass (g biomass/m^2)
    float const biomassDead,	// dead above-ground biomass (g biomass/m^2)
    float const fbst,         // fraction of water loss from transpiration (0-1)
			      //   1 - fbst = fraction of evaporation water loss
    float const PET,          // potential evapotranspiration (cm H2O/day)
    float const co2Effect,    // CO2 effect on transpiration (0-1)
    T1DFloatArray const & soilWaterPotential) // soil water potential (bars > 0)
{
    // check function parameters
    Assert ( biomassLive >= 0.0f );
    Assert ( biomassDead >= 0.0f );
    Assert ( fbst >= 0.0f && fbst <= 1.0f );
    Assert ( PET >= 0.0f );
    Assert ( co2Effect >= 0.0f );
    //Assert ( co2Effect <= 1.0f );

    // constants
    // float trpar1 = 28.0f;
    float trpar1 = 12.0f;		// input parameter to watrate
    float const scale1 = 0.3f;		// scale for shade affect
    float maxBiomassDead = 150.0f;	// maximum biomass of dead (g/m^2)

    // local variables
    float potentialTransp = 0.0f;	// return value
    float const swpAvg =	// weighted mean soil water potential (bars > 0)
	::TranspirationWtdMeanSWPotential (soilWaterPotential, fixed.awtl);

    // potential transpiration
    if (biomassLive == 0.0f)
    {
	potentialTransp = 0.0f;
    }
    else
    {
	// Effect of shading by dead biomass:
	// If there is a lot of dead biomass, it may serve to
	// reduce the potential Transpiration rate (shadeEffect < 1.0)
	float shadeEffect = 1.0f;	// shade effect of dead biomass on the
	if (biomassDead >= maxBiomassDead)
	{
		float const par1 =
	    		atanf (biomassLive, 300.0f, 12.0f, 34.0f, 0.002f);
		float const par2 =
	    		atanf (biomassDead, 300.0f, 12.0f, 34.0f, 0.002f);
	    	shadeEffect = (par1 / par2) * (1.0f - scale1) + scale1;
	    	if (shadeEffect > 1.0f)
	    		shadeEffect = 1.0f;
	}
	Assert ( shadeEffect >= 0.0f && shadeEffect <= 1.0f );
	potentialTransp = WaterRate (swpAvg, PET, trpar1, 0.10f) *
				shadeEffect * PET * fbst * co2Effect;
    }
    Assert ( potentialTransp >= 0.0f );
    Assert ( potentialTransp <= PET );
    return potentialTransp;
}

//--- end of file ---
