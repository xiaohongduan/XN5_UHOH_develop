// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  rcpgraz.cpp
//	Class:	  TCenturyBase
//	Function: RestrictCropProdGrazing
//
//	Description:
// 	Restrict crop production from grazing affects.
// ----------------------------------------------------------------------------
//	History:
//	Sep03	Tom Hilinski, tom.hilinski@colostate.edu
//	* Extracted from TDayCent and TCentury into TCenturyBase.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::RestrictCropProdGrazing (
	float const ratioRootShoot,	// root:shoot C
	float & agPotProd,		// aboveground potential production
	float & bgPotProd)		// belowground potential production
{
	float bop;
	if (agPotProd <= 0.02f)
		agPotProd = 0.02f;
	switch ( parcp.grzeff )
	{
	  case 0:		// grazing has no direct effect on production
	  	break;
	  case 1:		// linear impact on agp
		agPotProd *= (1.0f - parcp.flgrem * 2.21f);
		if (agPotProd < 0.02f)
		    agPotProd = 0.02f;
		bgPotProd = ratioRootShoot * agPotProd;
	  	break;

	  case 2:		// quadratic impact on agp and root/shoot ratio
	  {
		// Computing 2nd power
		float const r2 = parcp.flgrem * parcp.flgrem;
		agPotProd = (parcp.flgrem * 2.6f + 1.0f - r2 * 5.83f) *
				agPotProd;
		if (agPotProd < 0.02f)
		    agPotProd = 0.02f;
		// Computing 2nd power
		bop = ratioRootShoot + parcp.flgrem * 3.05f - r2 * 11.78f;
		if (bop <= 0.01f)
		    bop = 0.01f;
		bgPotProd = agPotProd * bop;
		break;
	  }
	  case 3:		// quadratic impact on root/shoot ratio
		// Computing 2nd power
		bop = ratioRootShoot + parcp.flgrem * 3.05f -
			parcp.flgrem * parcp.flgrem * 11.78f;
		if (bop <= 0.01f)
		    bop = 0.01f;
		bgPotProd = agPotProd * bop;
	  	break;

	  case 4:		// linear impact on root/shoot ratio
		bop = 1.0f - parcp.flgrem * fixed.gremb;
		bgPotProd = agPotProd * bop;
	  	break;

	  case 5:		// quadratic impact on agp and
	      			// linear impact on root/shoot ratio
		// Computing 2nd power
		agPotProd = (parcp.flgrem * 2.6f + 1.0f -
				parcp.flgrem * parcp.flgrem * 5.83f) *
				agPotProd;
		if (agPotProd < 0.02f)
		    agPotProd = 0.02f;
		bop = 1.0f - parcp.flgrem * fixed.gremb;
		bgPotProd = agPotProd * bop;
	  	break;

	  case 6:		// linear impact on agb and root/shoot ratio
		agPotProd = (1.0f - parcp.flgrem * 2.21f) * agPotProd;
		if (agPotProd < 0.02f)
		    agPotProd = 0.02f;
		bop = 1.0f - parcp.flgrem * fixed.gremb;
		bgPotProd = agPotProd * bop;
	  	break;
	  default:
	  	break;
	}
}

//--- end of file ---
