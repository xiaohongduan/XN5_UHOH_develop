// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  ClimateServer.cpp
//
//	Description:
//	Climate interface for DayCentIRC.
//	Contains a DayCent5 weather server.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, tom.hilinski@colostate.edu, March 2005
//	History: See header file.
//---------------------------------------------------------------------------

#include "ClimateServer.h"
#include "WeatherINIData.h"
#include "WeatherException.h"
#include "INIFileText.h"
using namespace nrel::dcirc;

bool ClimateServer::CreateServer (
	  std::string const & weatherINIFile)
{
	bool failure = false;

	// read INI file
	::nrel::weather::WeatherINIData iniData;
	::nrel::ini::INIFileText iniFile (
		iniData,
		weatherINIFile,
		::nrel::ini::INIFileText::Access_ReadOnly );
	if ( iniFile.GetDeviceState() ==
		::nrel::ini::INIFileText::DevState_Error )
	{
		// Read failed
		failure = true;
	}
	else
	{
		// Read successful
		failure = InitWeatherObjects ();
	}

	return failure;
}

bool ClimateServer::InitWeatherObjects ()
{
    bool failure = false;

    try
    {
	// create a data source and check if OK

	// create a transform object

	// create interface objects

	// create weather descriptors and list

	// create server
    }
    catch (nrel::weather::WeatherException const & e)
    {
    }
    catch (std::exception const & e)
    {
    }
    catch (...)
    {
    }

    return failure;
}

//--- end of file ClimateServer.cpp ---
