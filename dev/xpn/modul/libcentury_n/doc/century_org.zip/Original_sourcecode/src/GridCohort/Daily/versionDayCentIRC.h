#ifndef INC_DayCentIRC_version_h
#define INC_DayCentIRC_version_h
// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  versionDayCentIRC.h
//
//	Description:
//	DayCentIRC model version information.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Oct 2003
//	History:
// ----------------------------------------------------------------------------
//	Macros that can be used externally:
//
//	Macro:			Description:
//	--------------		-------------------------------
//	DayCentIRCName		String name of model.
//	DayCentIRCNickname	Short string name of model.
//	DayCentIRCVersion	String version number of model.
//	DayCentIRCVersionLong	String version of model with more info.
//	DayCentIRCDescription	Description string.
//	DEBUG_STATE_DCIRC	Defined if in debug build.
// ----------------------------------------------------------------------------

#if !defined(DEBUG_STATE_DCIRC)
  #if defined(_DEBUG) || !defined(NDEBUG)
    #define DEBUG_STATE_DCIRC
  #endif
#endif

// For use in this file only - MODIFY WITH EACH VERSION INCREASE
// Format: n.n.n.n where each number is
// "major version number"."minor"."build"
#define DayCentIRCVersion "1.2.6"

#define DayCentIRCName 		"DayCentIRC Model"
#define DayCentIRCNickname	"DayCentIRC"
#if !defined(DEBUG_STATE_DCIRC)
  #define DayCentIRCVersionLong DayCentIRCVersion " (" __DATE__ ")"
#else
  #define DayCentIRCVersionLong DayCentIRCVersion " (" __DATE__ ") DEBUG"
#endif

#define DayCentIRCDescription \
	"DayCentIRC gridded cohort-based terrestrial ecosystem model"

#endif // INC_DayCentIRC_version_h
