// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TDayCentGCF.cpp
//	Class:	  TDayCentGCF
//
//	Description: See header file.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, Sept 2002
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TDayCentGCF.h"
#include "TDisGenDayCentIRC.h"
#include "TDayCentModel.h"
#include <sstream>
#include "AssertEx.h"
using namespace nrel::dcirc;

void TDayCentGCF::InitMonthlyCycle ()
{
	Assert (owner.GetOwner() != 0);		// null cohort ptr?

	TDayCent::InitMonthlyCycle ();

	// have a disturbance generator?
	if ( !owner.GetOwner()->GetDecision().HaveDisturbanceGenerator() )
		return;			// no; nothing more to do

	// Fire disturbance from mgmt. schedule
	if ( sched->DoingFire() )
	{
		// debug start
		owner.WriteEventToSim (
			"TDayCentGCF::InitMonthlyCycle: fire: ",
			owner.GetOwner()->GetID() );
		// debug end

		// create a fire info structure
		TFireInfo fireInfo;
		if ( sched->DoingCropGrassFire() )
			fireInfo.fireType = TFireInfo::FT_CropGrass;
		else if ( sched->DoingForestFire() )
			fireInfo.fireType = TFireInfo::FT_Savanna;
		else if ( sched->DoingSavannaFire() )
			fireInfo.fireType = TFireInfo::FT_Forest;
		// do the fire disturbance
		TDisGenDayCentIRC * const myDisGen =
		    dynamic_cast<TDisGenDayCentIRC * const>(
			owner.GetOwner()->
				GetDecision().GetDisturbanceGenerator() );
		Assert (myDisGen != 0);
		if ( myDisGen->Disturb ( owner.GetOwner(), fireInfo ) )
		{
			// debug start
			owner.WriteToSim (
				"TDayCentGCF::InitMonthlyCycle: fire: "
				"successful!" );
			// debug end

			// Fire disturbance was successful
			// so cancel the event for this model.
			sched->CancelScheduledEvent (ET_Fire);
	    	}
	}

	// Agricultural disturbance
	// ...not done here: see class TDisturbListFile
}

//--- end of TDayCentGCF.cpp ---

