#ifndef INC_TMCSoilFlows_h
#define INC_TMCSoilFlows_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model (Monthly)
//	File:	  TMCSoilFlows.h
//	Class:	  TMCSoilFlows
//
//	Description:
//	Class for managing flows to/from physical soil pools.
//	Members were extracted from class TCentury.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, April 2004
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TSoilFlowsBase.h"
#include "TCenturySoil.h"
#include "TSimTime.h"

class TMCSoilFlows
	: public TSoilFlowsBase
{
  public:
	//---- constructors and destructor
	TMCSoilFlows (
	  TCenturySoil & useSoil,	// the soil
	  TFlow & useFlows,		// flow stack
	  TSimTime const & useST)	// simulation time manager
	  : TSoilFlowsBase (useSoil, useFlows, useST)
	  {
	  }
	TMCSoilFlows (
	  TMCSoilFlows const & object,
	  // Instances of Century submodels - refs to owner's objects
	  TCenturySoil & useSoil,		// the soil
	  TFlow & useFlows,		// flow stack
	  TSimTime const & useST)	// simulation time manager
	  : TSoilFlowsBase (object, useSoil, useFlows, useST)
	  {
	  }
	~TMCSoilFlows ()
	  {
	  }

	//---- operator overloads

	//---- functions
	float FlowNPSintoMineralSoil (
	  TMineralElements element,	// N, P, S
	  float * const source,		// source of mineral E
	  float const eToAdd,		// amount of mineral E to add (gE/m^2)
	  float const depth);		// soil depth to receive mineral E (cm)
	float FlowNPSfromMineralSoil (
	  TMineralElements element,	// N=nitrogen, P=Phosphorus, S=Sulfur
	  float * const destination,	// destination for mineral E
	  float const eDemand,		// amount of mineral E wanted (gE/m^2)
	  float const depth);		// soil depth to receive mineral E (cm)

	//---- functions: Queries

  protected:
	//---- constants

	//---- data

	//---- functions

  private:
	//---- constants

	//---- data

	//---- functions
};

#endif // INC_TMCSoilFlows_h
