#ifndef INC_TLeachOrganicC_h
#define INC_TLeachOrganicC_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TLeachOrganicC.h
//	Class:	  TLeachOrganicC
//
//	Description:
//	Class for submodel of leaching of organic C from the simulation layer.
//	Members were extracted from class TCenturyBase.
//	Responsibilities:
//	*
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, April 2004
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TFlowsSchedulable.h"
#include "centconsts.h"

class TSimTime;
class TNPS;
class TSoilC;
class TWaterTemp;


class TLeachOrganicC
	: public TFlowsSchedulable
{
  public:
	//---- constructors and destructor
	TLeachOrganicC (
	  float const useOmlech[3],
	  TSimTime const & useSimTime,
	  TNPS & useNps,
	  TSoilC & useSoilC,
	  TWaterTemp & useWT,
	  short const useNumE = 1)
	  : TFlowsSchedulable (),
	    simTime (useSimTime),
	    nps (useNps),
	    soilC (useSoilC),
	    wt (useWT),
	    numE (useNumE),
	    textureEffectIntercept ( useOmlech[0] ),
	    textureEffectSlope ( useOmlech[1] ),
	    maxLeachWater ( useOmlech[2] ),
	    dataCleared (false)
	  {
	    ClearAmtLeached ();
	  }
	TLeachOrganicC (			// copy constructor
	  TLeachOrganicC const & object,	//   object to copy
	  // Instances of Century submodels - refs to owner's objects
	  TSimTime const & useSimTime,
	  TNPS & useNps,
	  TSoilC & useSoilC,
	  TWaterTemp & useWT)
	  : TFlowsSchedulable (object),		// gets object to copy
	    simTime (useSimTime),		// get refs to owner's objects
	    nps (useNps),
	    soilC (useSoilC),
	    wt (useWT),
	    numE (object.numE),			// gets data to copy
	    textureEffectIntercept ( object.textureEffectIntercept ),
	    textureEffectSlope ( object.textureEffectSlope ),
	    maxLeachWater ( object.maxLeachWater ),
	    dataCleared (false)
	  {
	    Copy (object);			// gets data to copy
	  }
	~TLeachOrganicC ()
	  {
	  }

	//---- operator overloads
	TLeachOrganicC& operator= (
	  TLeachOrganicC const & object)
	  {
	    Copy (object);
	    return *this;
	  }

	//---- functions
	void SetNumberOfElements (		// Set number of N,P,S to
	  TMineralElements const numElements)	//   this number (1-3)
	  {
	    numE = numElements;
	    if ( numE < 1 )
	    	numE = 1;
	  }
	float Leach (				// Leaching of organic C
	  float const microbeC,			//   C from microbial pool
	  float const h2oFromLayer);		//   water flow from sim. layer
	void CalcTextureEffect (		// Update the sand effect value
	  float const sandFraction)
	  {
	    textureFactor =
		textureEffectIntercept +
		textureEffectSlope * sandFraction;
	  }
	void Clear ()
	  {
	    ClearAmtLeached ();
	  }

	//---- functions: Queries
	float GetLeachedC () const
	  { return amtLeachedC; }
	float GetLeachedC (
	  TIsotopesIndex isotope) const
	  { return amtLeachedCI[isotope]; }
	float GetLeachedE (
	  TMineralElements element) const
	  { return amtLeachedE[element]; }

  protected:
	//---- constants

	//---- data

	//---- functions

  private:
	//---- constants

	//---- data: external
	// Century internal data
	TSimTime const & simTime;
	// Century output variables
	TNPS & nps;
	TSoilC & soilC;
	TWaterTemp & wt;
	mutable short numE;			// number of {N,P,S} used

	//---- data: const parameters
	// factors affecting leaching; from fix.100
	float const textureEffectIntercept;	// omlech(1)
	float const textureEffectSlope;		// omlech(2)
	float const maxLeachWater;		// omlech(3)

	//---- data
	float textureFactor;			// Sand effect upon leaching
	float amtLeachedC;			// Amount C leached last time
	float amtLeachedCI[2];			// Amount C isotope leached
						//   0 = unlabeled, 1 = labeled
	float amtLeachedE[NUMELEM];		// organic N, P, S leached
	bool dataCleared;			// true if ClearAmtLeached

	//---- functions
	void Copy (				// Copy to this
	  TLeachOrganicC const & object);
	void ClearAmtLeached ();
};

#endif // INC_TLeachOrganicC_h
