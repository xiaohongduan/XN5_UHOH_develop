// ----------------------------------------------------------------------------
//	Copyright 1998-2000 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  leach.cpp
//	Class:	  TCentury
//	Function: LeachMineralNPS
//
//	Description:
//	Computes the leaching of mineralized nitrogen, phosphorus, and sulfur.
// ----------------------------------------------------------------------------
//	Author: 2/92 -rm
//	History:
//	Dec99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Local variable amtLeached was an array [MAXLYR], but array wasn't
//	  needed, so made it a scalar value.
//	* Changed names of some variables for readability.
//	* Reduced the number of function parameters.
//	* Additional optimization of loops.
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added function LeachOrganicC, containing the leaching code from
//	  somdec.
//	Aug03	Tom Hilinski
///	* Moved LeachOrganicC into TCenturyBase.
// ----------------------------------------------------------------------------
//	To Do:
//	* Move LeachMineralNPS into class TMCSoil.
// ----------------------------------------------------------------------------

#include "TCentury.h"

void TCentury::LeachMineralNPS (
	float const* fractionLeached)	// array: leaching fractions
{
    register float const recip = 1.0f / fixed.minlch;		// optimize
    for (short element = 0; element < site.nelem; ++element)
    {
    	if ( !AmountIsSignificant (fractionLeached[element]) )
    		continue;	// nothing to do

	float stormFlow= 0.0f;

	// iterators to layers
	TSoilPool::TFloatArray::iterator currentLayer;
	TSoilPool::TFloatArray::iterator bottomOfSoil;
	switch (element)
	{
	  case N:
		currentLayer = soil->MineralN().Values().begin();
		bottomOfSoil = soil->MineralN().Values().end();
	  	break;
	  case P:
		currentLayer = soil->MineralP().Values().begin();
		bottomOfSoil = soil->MineralP().Values().end();
	  	break;
	  case S:
		currentLayer = soil->MineralS().Values().begin();
		bottomOfSoil = soil->MineralS().Values().end();
	  	break;
	};
	TSoilPool::TFloatArray::iterator lowerLayer = currentLayer + 1;

	short index = 0;				// index to layers
	while ( currentLayer != bottomOfSoil )
	{
	    // AMOV > 0. indicates a saturated water flow out of layer
	    if ( soil->GetWaterTransferred(index) > 0.0f &&
	         *currentLayer > 0.0f )
	    {
	    	// leaching intensity - constrain to 0 to 1 inclusive
		float leachingIntensity = 1.0f -
		    (fixed.minlch - soil->GetWaterTransferred(index)) *
		    recip;
		leachingIntensity = std::min (1.0f, leachingIntensity);
		leachingIntensity = std::max (0.0f, leachingIntensity);
		float const amountLeached = fractionLeached[element] *
					*currentLayer *	leachingIntensity;
		// If you are at the bottom layer, compute storm flow.
		if (currentLayer == bottomOfSoil - 1)
		{
		    stormFlow = amountLeached * soil->GetStormFlowFraction();
		    water.deepStoreE[element] += amountLeached - stormFlow;
		}
		else	// not at bottom
		{
		    *lowerLayer += (amountLeached - stormFlow);
		    ++lowerLayer;
		}
		*currentLayer -= amountLeached;
	    }
	    ++currentLayer;
	    ++index;
	}
	// Compute base flow and mineral stream flows.
	float const baseFlow =
		water.deepStoreE[element] * soil->GetBaseFlowFraction();
	water.deepStoreE[element] -= baseFlow;
	// Note: stream flow indices differ from mineral element
	// indices by 1 (eg  stream(2) is stream flow for nitrogen).
	wt.stream[element + 1] = stormFlow + baseFlow;
    }
}
