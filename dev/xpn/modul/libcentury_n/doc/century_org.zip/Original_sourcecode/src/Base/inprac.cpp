// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  inprac.cpp
//	Class:	  TCenturyBase
//	Function: InitAnnualProdAccum
//
//	Description:
//	Initialize annual production accumulators.
// ----------------------------------------------------------------------------
//	History:
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::InitAnnualProdAccum ()
{
    // In the CROP system or SAVANNA, if it is the first month
    // of the growing season reset the accumulators.
    if ( sched->DoingPlanting() || sched->DoingStartCropGrassGrowth() )
    {
	// Aboveground carbon production
	cropC.agcisa[UNLABL] = cropC.agcisa[LABELD] =
		cropC.agcacc = cropC.ptagc = 0.0f;
	// Belowground carbon production
	cropC.bgcisa[UNLABL] = cropC.bgcisa[LABELD] =
		cropC.bgcacc = cropC.ptbgc = 0.0f;
    }

    // In the FOREST system or SAVANNA, if it is the first month
    // of the growing season reset the accumulators.
    if ( sched->DoingStartTreeGrowth() )
    {
	forestC.fcacc = 0.0f;			// Total forest C
	forestC.alvcis[UNLABL] = 		// Leaf C production
	  forestC.alvcis[LABELD] =
	  forestC.rlvacc = 0.0f;
	forestC.afrcis[UNLABL] = 		// Fine root C production
	  forestC.afrcis[LABELD] =
	  forestC.frtacc = 0.0f;
	forestC.afbcis[UNLABL] = 		// Fine branch C production
	  forestC.afbcis[LABELD] =
	  forestC.fbracc = 0.0f;
	forestC.alwcis[UNLABL] = 		// Large wood C production
	  forestC.alwcis[LABELD] =
	  forestC.rlwacc = 0.0f;
	forestC.acrcis[UNLABL] = 		// Coarse root C production
	  forestC.acrcis[LABELD] =
	  forestC.crtacc = 0.0f;
    }
    if ( st->IsStartOfYear() )			// January?
    {
	// N, P, and S uptake by plants
	for (short element = 0; element < NUMELEM; ++element)
	{
	    nps.eupacc[element] = nps.eupaga[element] = nps.eupbga[element] = 0.0f;
	    for (short part = 0; part < FPARTS; ++part)
		eupprt_ref (part, element) = 0.0f;
	}
    }
}

//--- end of file inprac.cpp ---
