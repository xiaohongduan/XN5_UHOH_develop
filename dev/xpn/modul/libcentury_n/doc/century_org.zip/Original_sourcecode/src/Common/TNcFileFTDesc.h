#ifndef INC_TNcFileFTDesc_h
#define INC_TNcFileFTDesc_h

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TNcFileFTDesc.h
//	Class:	  TNcFileFTDesc
//
//	Description:
//	Class to read the NCFTypes.nc file, containing descriptions of the
//	netCDF file types used by Century and CMI.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Feb99
// ----------------------------------------------------------------------------
//	History:
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* A bit of cleaning up and const-correctness.
//	* Added copy constructor, operator=
//	* Changed lists to std::vector, and char* to std::string.
// ----------------------------------------------------------------------------
//	Copyright 1999-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TNcFile.h"
#include <vector>
#include <string>

class TNcFileFTDesc : public TNcFile
{
  public:
	//--- types
	typedef std::vector<short>		TValueList;
	typedef std::vector<std::string>	TDescripList;

	//--- constructors and destructor
	TNcFileFTDesc (
	  TEH::TFileName const & useFilePath)	// path to description file
	  : TNcFile ( useFilePath, NCFT_FileTypeDesc )
	  {
	    Initialize ();
	    Read ();
	  }
	~TNcFileFTDesc ()
	  {
	    Clear ();
	  }
	TNcFileFTDesc (TNcFileFTDesc const & object)	// copy constructor
	  : TNcFile (object)
	  {
	    Initialize ();
	    Copy (object);
	  }

	//---- operator overloads
	TNcFileFTDesc& operator= (TNcFileFTDesc const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	TNcFile::operator= (object);
		Copy (object);
	    }
	    return *this;
	  }

	//--- functions
	char const* GetDesc (			// gets matching description
		TNcFileType const enumValue) const;
	void Clear ();				// "clear" data members

  private:
	//--- data
	TValueList valueList;			// list of enum values
	TDescripList descList;			// list of descriptions

	//--- functions
	void Initialize ()			// initialize members
	  {
	  }
	void Copy (TNcFileFTDesc const & object)	// Copy to this
	  {
	    if ( &object )
	    {
	    	valueList = object.valueList;
	    	descList = object.descList;
	    }
	  }
	void Read ();				// read the descriptions
};

#endif // INC_TNcFileFTDesc_h
