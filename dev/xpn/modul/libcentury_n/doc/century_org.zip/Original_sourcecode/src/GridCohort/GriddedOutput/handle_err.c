#include <stdio.h>
#include <stdlib.h>
#include "netcdf.h"

/*********************************************************************************
 **
 **  FUNCTION:  void handle_error()
 **
 **  Print error message when a NetCDF error occurs.
 **
 **********************************************************************************/
 
void handle_error(char *funcname, int status)
{
 fprintf(stderr, "NetCDF Error in %s: %s\n", funcname, nc_strerror(status));
 exit(1);
}
