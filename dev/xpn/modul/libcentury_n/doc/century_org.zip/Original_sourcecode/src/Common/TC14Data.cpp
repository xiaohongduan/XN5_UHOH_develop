// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TC14Data.cpp
//	Class:	  T14CData
//
//	Description:
//	Class T14CData to manage the 14C data.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jun98
// ----------------------------------------------------------------------------
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TC14Data.h"
#include "TCentException.h"
#include <sstream>
using namespace std;

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

T14CData::T14CData (
	char const * const newFileName,		// 14C data file name
	const long useStartYear)		// year for start of C labeling
{
	Initialize ();
	fileName = newFileName;
	yearLabelStart = useStartYear;
	OpenStream ();
}

T14CData::T14CData (
	std::string const & newFileName,	// 14C data file name
	const long useStartYear)		// year for start of C labeling
{
	Initialize ();
	fileName = newFileName;
	yearLabelStart = useStartYear;
	OpenStream ();
}

T14CData::~T14CData ()
{
	if ( df.is_open() )
		df.close ();			// close the stream
}

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------
bool T14CData::operator== (T14CData const & object) const
{
	if ( &object )
	{
		return	fileName == object.fileName &&
			yearLabelStart == object.yearLabelStart;
	}
	else
		return false;
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	GetFraction14C
//	Returns the fraction of 14C in new plant tissue for the year.
//
float T14CData::GetFraction14C (
	short const simYear)		// simulation year
{
	fraction = 0.0;

	if ( simYear < yearLabelStart )		// ready to get 14C?
		return fraction;		// ...no

	short newLabelYear = yearLabelStart - 1;// input label year
	float newPct;				// input percent tissue 14C
	while ( simYear > newLabelYear )	// year to get 14C?
	{
		// get the next year & pct from the data file
		if ( GetRecord ( &newLabelYear, &newPct ) )	// read failed?
		{
			if ( df.eof() )			// end of file?
			{
				// warn of no more data
				ostringstream os;
				os << "File: " << fileName << '\n'
				   << "Simulation year: " << simYear << '\n'
				   << "Labeling year: " << yearLabelStart
				   << endl;
				ThrowCentException (
					TCentException::CE_14CRDF,
						os.str().c_str() );
			}
		}
	}
	if ( simYear < newLabelYear )			// no match?
	{
		// warn of no matching data
		ostringstream os;
		os << "File: " << fileName << '\n'
		   << "Simulation year: " << simYear << '\n'
		   << "Labeling year: " << yearLabelStart << endl;
		ThrowCentException (TCentException::CE_14CNMY,
					os.str().c_str() );
	}
	else
	{
		curYear = newLabelYear;		// save
		curPct = newPct;		// save
		fraction = newPct * 0.01;	// convert percent to fraction
	}
	return fraction;
}

//	Clear
// 	clear member data
void T14CData::Clear ()
{
	fileName.clear();
	Initialize ();
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	OpenStream
//	Open the input file stream
void T14CData::OpenStream ()
{
	if ( !fileName.empty() )		// name specified?
	{
		//df.open (fileName, ios::in | ios::nocreate);	// open file
		df.open ( fileName.c_str(), ios::in );		// open file
		if ( !df.is_open() )
			errorState = Error_OpenFailed;
		else if ( !df.good() )
			errorState = Error_FileStream;
	}
	else	// no name specified
		errorState = Error_NoFileName;
}

//	GetRecord
// 	Retrieves the next record in file.
//	Returns the values in newYear and pct via parameters.
//	Returns false if successful, else true if not.
bool T14CData::GetRecord (
	short* const newYear,
	float* const pct)
{
	*newYear = 0;
	*pct = 0.0f;
	bool retVal = false;
	if ( !df.eof() )
	{
		std::string record;
		df >> record;
		if ( df.good() && !record.empty() )
		{
			istringstream is (record);
			is >> *newYear >> *pct;
		}
		else
			retVal = true;
		df >> ws;
	}
	return retVal;
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Initialize
// 	initialize member data
void T14CData::Initialize ()
{
	fraction = 0.0f;
	curYear = 0;
	curPct = 0.0f;
	yearLabelStart = 0;
	errorState = Error_None;
}

//	Copy
// 	copy to this
void T14CData::Copy (T14CData const & object)
{
	if ( &object )
	{
		fileName = object.fileName;
		fraction = object.fraction;
		curYear = object.curYear;
		curPct = object.curPct;
		yearLabelStart = object.yearLabelStart;
	}
}

//--- end of definitions for T14CData ---
