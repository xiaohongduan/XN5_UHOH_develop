// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//    Project:  Century Soil Organic Matter Model, daily version
//    File:	h2oflux.cpp
//    Class:	TDayCentSoil
//    Function: SoilWaterFlux
//
//    Description:
//    Water Submodel for DayCent. This algorithm was derived from the
//    on described in Hillel, Daniel (1977), "Computer Simulation
//    of Soil-Water Dynamics".
// ----------------------------------------------------------------------------
//    Author: Melannie Hartman, Bill Parton
//    History:
//    Mar1996  Melannie Hartman, melannie@NREL.colostate.edu
//    * Created original h2oflux.c for FORTRAN/C version of DayCent
//    Mar2001	 Melannie Hartman, melannie@NREL.colostate.edu
//    * Translated h2oflux.c to h2oflux.cpp
//    Oct2001	 Melannie Hartman, melannie@NREL.colostate.edu
//    * Fixed water balance problem - cumOverSat no longer part
//      of the water balance.
//	Nov02   Tom Hilinski, tom.hilinski@colostate.edu
//	* Misc. clean up, const-correctness, optimization.
//	* Hydraulic conductivity functions put inline (comments left here.)
//	* Arrays of double[MAXLYR] changed to TDblValArray and declared as
//	  class members so they aren't reallocated at each call.
//	Dec02   Tom Hilinski
//	* Convert to use arraytypes.h for arrays
//	Aug03   Tom Hilinski
//	* deepSoilWaterStoreDbl could be negative (~ -1e-10), so checked this.
//	Sep03	Tom Hilinski
//	* Removed variables overSat, cumOverSat since they aren't used.
//	* Changed "TFloatArray netFlux" to loop-local "double netFlux",
//	  since values are not used outside of loop.
//	* Ditto for swcSat.
// ----------------------------------------------------------------------------
//
//    Notes:
//    * Double precision is required in this routine for many of the
//      soil water related variables in order to maintain daily
//      water balance.  Fluxes at any given time step can be very
//      small, and without double precision, the accumulation of these
//      fluxes is lost. - mdh 3/30/01
//
//    * It seems that soil may not be able to completely dry to
//      swcMin[] even when there is no water inputs for a number of
//      years.  This routine enacts a restore on the first time step.
//      -mdh 3/30/01
//
// ----------------------------------------------------------------------------
//	To do:
//	* Parameterize the following in the site parameters:
//		dtHours - granularity of the time step for darcy's flux
//		dmpflux - fudge factor scaling the fluxes
// ----------------------------------------------------------------------------
//  Local Variables:
//    flux[] - flow rate of water flux at the top of layer
//             (cm/sec, -upward, +downward)
//    netFlux - net water flux into/out of a layer (flux top - flux bottom)
//             (cm/sec). A gain is positive, a loss is negative.
//    restore - 1 if subprogram is to restore swc to previous
//       timestep before returning, else 0.
// ----------------------------------------------------------------------------

#include "TDayCentSoil.h"
#include "TDayCent.h"
using namespace std;

void TDayCentSoil::InitializeSoilWaterArrays ()
{
    //  Array sizes
    MidPointsOfLayers ();
    unsigned short const layerCount = GetLayerCount();
    if ( avgHydrCond.size() != layerCount )
    {
	avgHydrCond.resize (layerCount);
	flux.resize (layerCount + 1);
	headPotentl.resize (layerCount);
	hydrCond.resize (layerCount);
	matricPotentl.resize (layerCount);
	swc.resize (layerCount);
	swcFieldCapacity.resize (layerCount);
	swcMin.resize (layerCount);
	theta.resize (layerCount);
	thetaSat.resize (layerCount);
	soilWaterPotential.resize (layerCount);
	psiSat.resize (layerCount);
	swrc.resize (layerCount);
    }

    // debug
//    Assert ( avgHydrCond.size() == layerCount );
//    Assert ( flux.size() == layerCount );
//    Assert ( headPotentl.size() == layerCount );
//    Assert ( hydrCond.size() == layerCount );
//    Assert ( matricPotentl.size() == layerCount );
//    Assert ( swc.size() == layerCount );
//    Assert ( swcFieldCapacity.size() == layerCount );
//    Assert ( swcMin.size() == layerCount );
//    Assert ( theta.size() == layerCount );
//    Assert ( thetaSat.size() == layerCount );
//    Assert ( soilWaterPotential.size() == layerCount );
//    Assert ( psiSat.size() == layerCount );
//    Assert ( swrc.size() == layerCount );
//    Assert ( SandFraction().Values().size() == layerCount );
//    Assert ( SiltFraction().Values().size() == layerCount );
//    Assert ( ClayFraction().Values().size() == layerCount );

    // initialize the soil water content arrays
    avgHydrCond = 0.0;
    flux = 0.0;
    headPotentl = 0.0;
    hydrCond = 0.0;
    matricPotentl = 0.0;
    theta = 0.0;
    soilWaterPotential = 0.0f;
    psiSat = 0.0;
    swrc = 0.0;
}

void TDayCentSoil::SoilWaterFlux (
    float const rainDuration,	  // duration of a rain event (hours)
    T1DFloatArray const & soilTavg, // average soil temperature by layer (deg C)
    float const waterInput,	  // rain + snowmelt to be added to the top of
				  //   soil profile (cm/day)
    float const bareSoilEvapMax,  // potential bare-soil evaporation rate (cm/day)
    float const snowPack,	// snow water equivalent in snow pack (cm H2O)
    float & soilEvap,		// evaporation from soil(cm H2O)
    float & outflow,		// water that runs off or drains out of profile
				//   (cm H2O)
    float & runoff)		// inflitration excess and return flow (cm H2O)
{
    unsigned short const numberLayers = GetLayerCount(); // soil layer count
    bool restore = false;	// See above comment block

    double const petMaxRate = 	// potential evaporativity (cm/sec)
	bareSoilEvapMax / SEC_PER_DAY;

    //  Variables to check water balance
    double cumEvap = 0.0; 	// cumulative evaporation (cm)

    // Initialization of soil water arrays is now in
    // TDayCentSoil::InitializeSoilWaterArrays
    // and first called in
    // TDayCent::ComputeSoilWaterFluxes

    // Following is called via TDayCent::CalculateSoilWaterPotential
    // just before this in TDayCent::ComputeSoilWaterFluxes
    // WaterEquation ( SandFraction(), ClayFraction(), thetaSat, psiSat, swrc );

    amtTrans = 0.0f;
    TSoilProperty::TFloatArray::const_iterator
	iSand = SandFraction().Values().begin (),
	iClay = ClayFraction().Values().begin ();
    for (short layer = 0; layer < numberLayers; ++layer, ++iSand, ++iClay)
    {
	// this routine requires double precision for soil water variables
	swc(layer) = WaterContent (layer);
	swcMin(layer) = VSwcMin(layer) * thickness[layer];
	// don't let field capacity exceed porosity
	float const porosity = 1.0f - BulkDensity(layer) / PARTDENS;
	swcFieldCapacity(layer) =
		std::min (porosity, FieldCapacity(layer)) *
		thickness[layer];
	// thetaSat(layer) = PartonThetaSaturation ( BulkDensity(layer) );
	thetaSat(layer) = soilWaterModel->ThetaAtSaturation (*iSand, *iClay);
    }

    // initial total water in the profile (cm)
    double const initTotalSoilWater = ARRAY_SUM(swc) + deepSoilWaterStore;

    //  Extend infiltration time for snowmelt events -mdh, cindyk 9/18/00
    //  If there is snowpack lengthen the number of hours that the water
    //  is infiltrated into the soil

    // duration of infiltration of rain and/or snowmelt event (hours)
    int infiltTime;
    if (snowPack <= 1.0e-8)
	infiltTime = static_cast<int>(rainDuration + 0.5f);
    else
	infiltTime = 16;			// 16 hours for snowmelt - why?
    // int const dtHours = 2;	// water flux calculation time step (hours)
    int const dtHours = 1;	// water flux calculation time step (hours)
    Assert ((infiltTime % dtHours) == 0);
    Assert (infiltTime <= HOURS_PER_DAY);

    // need double prec. for deep soil store and flows since
    // drainageOut and slowDrain are typically very small.
    double deepSoilWaterStoreDbl = deepSoilWaterStore;  // float --> double
    T1DFloatArray amtTransDbl (amtTrans);		// interlayer flow

    // Infiltrate water into the soil
    double cumRunoff = 0.0;	// cumulative runoff (cm)
    double cumTime = 0.0;	// seconds that have elapsed in the current day
    if (waterInput > 0.0)
    {
	// infiltration capacity at top of soil profile (cm/sec)
	double infiltCapacity = Ksat(0);

	// water inputs will infiltrate first at the saturated hydraulic
	// conductivity of the top layer, then at the minimum of saturated
	// hydraulic conductivities of layers that the water passes through

	double drainageOut = 0.0;	// drainage from bottom of profile (cm)
	double cumInfilt = 0.0; 	// cumulative infiltration (cm)
	AddWaterToSoil (infiltTime, waterInput,
		infiltCapacity, soilTavg, thetaSat, swcFieldCapacity,
		// output
		swc, cumTime, cumRunoff, cumInfilt, drainageOut);
	deepSoilWaterStoreDbl += drainageOut;
    }

    // time steps per day and time step length in seconds
    // number of time steps per day for infiltration
    // NOTE: this truncates vs. rounds the division result
    // therefore will tend to err too low.
    int const nsteps = (waterInput > 0.0) ?
		((HOURS_PER_DAY - infiltTime) / dtHours) :
		(HOURS_PER_DAY / dtHours);
    // number of seconds per time step (sec)
    double const dt = ( static_cast<double>(SEC_PER_DAY) - cumTime) / nsteps;

    //  Loop thru nsteps or until error condition occurs

    int tstepCnt = 0;         // current number of time steps executed
    // save previous time-step values - used only if restore == true
    T1DDoubleArray swcSave (swc.size());	 // previous soil water content
    swcSave = 0.0;
    T1DFloatArray amtTranSave (amtTrans.size()); // previous interlayer flow
    amtTranSave = 0.0f;
    double deepSoilWaterPoolSave = 0.0;		// previous deep H2O store
    while ( std::fabs(cumTime - SEC_PER_DAY) > 0.01 &&
    	    !restore )
    {
	// save previous time-step values - used only if restore == true
	//if (restore)
	//{
		swcSave = swc;
		amtTranSave = amtTransDbl;
		deepSoilWaterPoolSave = deepSoilWaterStoreDbl;
	//}

	// hydraulic parameters
	++tstepCnt;
	for (short layer = 0; layer < numberLayers; layer++)
	{
	    theta(layer) = swc(layer) / thickness[layer];

	    // just in case theta(layer) < vSwcMin(layer),
	    // take wetter of resulting soilwater potentials

	    matricPotentl(layer) =
		max( -soilWaterModel->SoilWaterPotential (
			VSwcMin(layer), thetaSat(layer),
			psiSat(layer), swrc(layer) ),
		     -soilWaterModel->SoilWaterPotential (
		     	theta(layer), thetaSat(layer),
			psiSat(layer), swrc(layer) )
		   ) * BAR2CM;
	    hydrCond(layer) =
		soilWaterModel->HydraulicConductivity (
		  Ksat(layer), theta(layer), thetaSat(layer), soilTavg(layer) );
	    headPotentl(layer) = matricPotentl(layer) - depthToMidPt(layer);
	}

	for (short layer = 1; layer < numberLayers; layer++)
	{
	    avgHydrCond(layer) =
		( hydrCond(layer - 1) * thickness[layer - 1] +
			hydrCond(layer) * thickness[layer] ) /
		(thickness[layer - 1] + thickness[layer]);
	}

	// Darcy's Law
	for (short layer = 1; layer < numberLayers; layer++)
	{
	    flux(layer) =
	      (headPotentl(layer-1) - headPotentl(layer)) * avgHydrCond(layer) /
	      ( 0.5 * (thickness[layer-1] + thickness[layer]) );
	}
	// available flux below the soil
	Assert (hydrCond(numberLayers - 1) >= 0.0);
	flux(numberLayers) = hydrCond(numberLayers - 1);

	double const dmpflux = 1.0e-6;	// flux damping multiplier
	flux *= dmpflux;

	// The following comments are from Hillel's book
	// (they are not implemented):
	//   As long as the matric potential of the topmost layer remains
	//   greater (wetter) than the specified air dryness, AET=PET.  If the
	//   topmost compartment dries out and drops to this minimum potential,
	//   AET equals the upward transmission of moisture (or PET, whichever
	//   is less)

	double evapFlux = 0.0; 			// evaporation rate (cm/sec)
	float const potentialBars =
		-soilWaterModel->SoilWaterPotential (
	     		VSwcMin(0), thetaSat(0), psiSat(0), swrc(0) ) * BAR2CM;
	if ( matricPotentl(0) > potentialBars )
	{
		evapFlux = max(0.0, petMaxRate);
		flux(0) = -evapFlux;
	}
	else
		evapFlux = 0.0;

	// calculate fluxes and water contents for each layer
	for (short layer = 0; layer < numberLayers; layer++)
	{
	    double netFlux = flux(layer) - flux(layer + 1);  // flux in - out

	    // If potential net flux into layer will bring it above saturation
	    // adjust the net flux into layer

	    // saturation water capacity of soil (cm H2O)
	    double const swcSat = thetaSat(layer) * thickness[layer];
	    double available = netFlux * dt;
	    if ( swc(layer) + available > swcSat )
	    {
		netFlux = (swcSat - swc(layer)) / dt;
		available = netFlux * dt;
		flux(layer + 1) = flux(layer) - netFlux;
	    }

	    // If potential net flux out of layer (negative flux) will bring it
	    // below its minimum water content, adjust the net flux out of layer

	    else if ( swc(layer) + available < swcMin(layer) )
	    {
		// net flux must be reduced so soil does not get below
		// the minimum swc
		// flux[layer+1] = (swc(layer) - swcmin(layer) +
		//			flux(layer) * dt) / dt;
		// netFlux = flux(layer) - flux[layer+1];
		netFlux = -1.0 * (swc(layer) - swcMin(layer)) / dt;
		available = netFlux * dt;
		if (layer == 0)				// at surface?
		{
			// all flux goes to evaporation
			flux(0) = netFlux + flux(1);
			evapFlux = -flux(0);
		}
		else
		{
			// layer == 0, fluxes downward are not changed
			flux(layer + 1) = flux(layer) - netFlux;
		}
	    }
	    amtTransDbl(layer) += flux(layer + 1) * dt;
	    // swc(layer) += std::max ( 0.0, available );
	    swc(layer) += available;

	    // Check for error conditions
	    // at least minimum H2O
	    Assert (swc(layer) - swcMin(layer) >= -1.0e-6);
	    // Following can "leak" water from the budget:
	    // swc(layer) = std::max ( swc(layer), swcMin(layer) );
	} // for layer

	// When soil conditions get dry, and fluxes are readjusted, sometimes
	// water is sucked out of "nowhere" into the bottom of the soil column.
	// If this happens, reduce evaporation by this amount to maintain the
	// water balance, or restore the previous timestep's swc.

	double const evapDemand = evapFlux * dt;	// surface evaporation
	double const available = flux(numberLayers) * dt;
	if ( available < -1.0E-9 )			// very dry at bottom?
	{
	    if ( evapDemand > -available )
	    {
		cumEvap += evapDemand + available;
	    	flux(numberLayers) = 0.0;		// used it all
	    }
	    else
	    {
		// very dry, but surface evaporation demand > profile bottom H2O
		// Is this an error condition to recover from?
		// Does this cause a leak of evapFlux from the water budget?

		// restore to swc of the previous timestep before exiting
		restore = true;
	    }
	}
	else
	{
	    cumEvap += evapDemand;
	}

	// Note: slowDrain is very small, even under saturated conditions
	// and deepSoilWaterStore increases very slowly.
	// When the call to DrainToFieldCapcity is bypassed in AddWaterToSoil,
	// water in excess of saturation is all going to runoff. -mdh 3/30/01

	//if ( !restore )
	{
		double const slowDrain = dt * flux(numberLayers);
		deepSoilWaterStoreDbl += slowDrain;
	}
	cumTime += dt;

    }  // while

    if (!restore)
    {
	// Check for error conditions
	double const tdiff = cumTime - SEC_PER_DAY;
	if (fabs(tdiff) > 0.01)
	{
	    ostringstream os;
	    os << "Error in time step in h2oflux: "
	       << "tdiff = " << tdiff;
	    ThrowDayCentException (TDayCentException::DCE_SWMERR,
				    os.str().c_str() );
	}
    }
    else
    {
	// Restore swc to previous timestep's value
	swc = swcSave;
	amtTransDbl = amtTranSave;
	deepSoilWaterStoreDbl = deepSoilWaterPoolSave;
    }

    // remove rounding errors (~ 1e-10)
    if ( !(deepSoilWaterStoreDbl >= -1.0e-7) )
    {
	std::stringstream os;
	os << "!(deepSoilWaterStoreDbl >= -1.0e-7)"
	   << "\n  deepSoilWaterStoreDbl = " << deepSoilWaterStoreDbl
	   << "\n  restore = " << restore
	   << std::endl;
	TDayCentException (TDayCentException::DCE_SWMERR, os.str());
    }
    deepSoilWaterStoreDbl = std::max (deepSoilWaterStoreDbl, 0.0);
    double const deepPoolBaseFlow = baseFlowFraction * deepSoilWaterStoreDbl;
    deepSoilWaterStoreDbl -= deepPoolBaseFlow;

    // save results
    for (short layer = 0; layer < numberLayers; layer++)
    {
	WaterContent(layer) = static_cast<float>( swc(layer) );
	Assert (WaterContent(layer) > 0.0f);
    }
    soilEvap = static_cast<float>(cumEvap);
    outflow = static_cast<float>(cumRunoff + deepPoolBaseFlow);
    runoff = static_cast<float>(cumRunoff);
    deepSoilWaterStore = static_cast<float>(deepSoilWaterStoreDbl);
    amtTrans = amtTransDbl;

    // Does actual evaporation exceed potential evaporation?
    if ( soilEvap > bareSoilEvapMax )
    {
    	if ( AmountIsSignificant (soilEvap - bareSoilEvapMax, 1.0e-2f) )
	{
		ostringstream os;
		os << "Soil Evaporation (" << soilEvap
		   << ")\nexceeds potential evaporation (" << bareSoilEvapMax
		   << ") in SoilWaterFlux()";
		ThrowDayCentException ( TDayCentException::DCE_SWMERR,
				os.str().c_str() );
	}
	// soilEvap = bareSoilEvapMax; // remove rounding errors
    }

    // water balance of the soil profile (cm)
    double const netWaterIntoSoil = waterInput -
    	(cumRunoff + cumEvap + deepPoolBaseFlow);
    double const finalWaterBalance =
    	ARRAY_SUM(swc) + deepSoilWaterStoreDbl - netWaterIntoSoil;
    char const * const msgImbalance =
	(finalWaterBalance > initTotalSoilWater ?
	 "Total soil water: final > initial" :
	 "Total soil water: initial > final");
    dynamic_cast<TDailyCenturyBase const &>(owner).BalanceCheckWithMsg (
			initTotalSoilWater, finalWaterBalance, 5.0E-5,
			msgImbalance );
/*
    // for debugging only!
    if ( !AreClose (initTotalSoilWater, finalWaterBalance, 5.0E-6) )
    {
	ThrowDayCentException ( TDayCentException::DCE_SWMERR,
				"Simulation stopped." );
    }
*/
}


//--- end of file ---

