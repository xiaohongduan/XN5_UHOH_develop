// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC
//	File:	  TCohortAgModelPercent.cpp
//	Class:	  TCohortAgModelPercent
//
//	Description: See header file.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, July 2002
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TCohortAgModelPercent.h"
#include "TDayCentModel.h"
#include "DayCentIRCTypes.h"
#include <iterator>
using namespace std;
using namespace nrel::dcirc;

using ::nrel::gcf::TCohort;
using ::nrel::gcf::TCohortList;
using ::nrel::gcf::TCohortListIterator;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	CompareCohorts
//	Compares a pair of cohorts.
//	Returns true if cohorts are similar.
bool TCohortAgModelPercent::CompareCohorts (
	TCohort const * const cohort1,	// this cohort
	TCohort const * const cohort2	// and this cohort
	) const
{
	// Same landscape?
	bool areSimilar =
		( cohort1->GetLandElement() == cohort2->GetLandElement() );
	if ( areSimilar )
	{
	    // Kluge! The following hardwires Century stuff into this.
	    // 1. cast to TDayCentModel for each cohort in the pair
	    TDayCentModel const & dayCentModel1 =
		dynamic_cast<TDayCentModel const &>( cohort1->GetModel() );
	    TDayCentModel const & dayCentModel2 =
		dynamic_cast<TDayCentModel const &>( cohort2->GetModel() );
	    // 2. cast to TDayCent for each TDayCentModel instance
	    TDayCent const & myModel1 =
		dynamic_cast<TDayCent const &>( dayCentModel1.GetModel() );
	    TDayCent const & myModel2 =
		dynamic_cast<TDayCent const &>( dayCentModel2.GetModel() );

	    // use large area system as the comparison base
	    TDayCent const * standard;	// larger cohort = comparison base
	    TDayCent const * sample;	// smaller cohort = sample to check
	    if ( cohort1->GetAreaFraction() >= cohort2->GetAreaFraction() )
	    {
	    	standard = &myModel1;
	    	sample = &myModel2;
	    }
	    else	// model 2 is larger in area
	    {
	    	standard = &myModel2;
	    	sample = &myModel1;
	    }

	    // 1. Are they the same system?
	    areSimilar = ( standard->GetSystemType().Type() ==
				sample->GetSystemType().Type() );
	    // ...same crop/grass?
	    if ( areSimilar &&
	         ( standard->GetSystemType().IsCropGrass() ||
	           standard->GetSystemType().IsSavanna() ) )
	    {
	    	areSimilar =
		  ( strncmp (standard->GetSystemType().CropName(),
			     sample->GetSystemType().CropName(),
			     6) == 0 );
	    }
	    // ...same tree?
	    if ( areSimilar &&
	         ( standard->GetSystemType().IsForest() ||
	           standard->GetSystemType().IsSavanna() ) )
	    {
	    	areSimilar =
		  ( strncmp (standard->GetSystemType().TreeName(),
			     sample->GetSystemType().TreeName(),
			     6) == 0 );
	    }

	    // 2. compare soil C
	    if ( areSimilar )
		areSimilar =
		    ValuesWithinPercentRange (
			standard->GetSoilC().som1c[SOIL],
			sample->GetSoilC().som1c[SOIL] ) &&
		    ValuesWithinPercentRange (
			standard->GetSoilC().som2c,
			sample->GetSoilC().som2c ) &&
		    ValuesWithinPercentRange (
			standard->GetSoilC().som3c,
			sample->GetSoilC().som3c );

	    // 3. compare biomass
	    if ( areSimilar &&
	         standard->GetSystemType().IsCropGrass() )
	    {
	    	areSimilar =
		    ValuesWithinPercentRange (
			standard->GetCropGrassC().aglivc,
			sample->GetCropGrassC().aglivc ) &&
		    ValuesWithinPercentRange (
			standard->GetCropGrassC().bglivc,
			sample->GetCropGrassC().bglivc );
	    }
	    else if ( standard->GetSystemType().IsForest() )
	    {
	    	areSimilar =
		    ValuesWithinPercentRange (
			standard->GetForestC().frstc ,
			sample->GetForestC().frstc  );
	    }
	    else if ( standard->GetSystemType().IsSavanna() )
	    {
	    	areSimilar =
		    ValuesWithinPercentRange (
			standard->GetCropGrassC().aglivc,
			sample->GetCropGrassC().aglivc ) &&
		    ValuesWithinPercentRange (
			standard->GetCropGrassC().bglivc,
			sample->GetCropGrassC().bglivc ) &&
		    ValuesWithinPercentRange (
			standard->GetForestC().frstc,
			sample->GetForestC().frstc );
	    }

	    // For now we'll ignore N, P, S, water, soil texture.
	    // Also, we'll ignore trends in pool changes (in/decreasing or same)
	}
	return areSimilar;
}

//	CompareCohorts
//	Compares cohorts in a TCohortList range.
//	Returns a vector of indices to the cohort list of cohorts that
//	can be combined.
//	Returns the size of the indices vector.
//	The indices are zero-based relative to the starting iterator.
unsigned int TCohortAgModelPercent::CompareCohorts (
	TCohortListIterator beginRange,		// start of cohort list
	TCohortListIterator endRange,		// end of cohort list
	TTimeManager::TTime const minimumAge,	// minimum age of cohorts
	TTimeManager::TTime const currentTime,	// current simulation time
	TCohortIteratorList & listOfIndices	// list of indices
	) const
{
	listOfIndices.clear();

	// find first valid candidate
	TCohortListIterator key = endRange;
	for ( TCohortListIterator i = beginRange;
	      i != endRange;
	      ++i )
	{
		if ( OldEnough (*i, currentTime, minimumAge) )
		{
			key = i;
			break;
		}
	}

	// Build a list of cohorts that match criteria
	if ( key != endRange )				// anything to do?
	{
	    // check the remaining cohorts for a match
	    bool keyInList = false;		// true if added key to list
	    TCohortListIterator start = key;	// loop start
	    ++start;
	    for ( TCohortListIterator i = start;
	          i != endRange;
	          ++i )
	    {
		if ( OldEnough (*i, currentTime, minimumAge) &&
		     CompareCohorts (*i, *key) )
		{
		    if ( !keyInList )
		    {
			// save key index to list
			listOfIndices.push_back (
			  reinterpret_cast<
			  	TCohortList::TCohortSet::iterator>(key) );
			keyInList = true;
		    }
		    // save new index to list
		    listOfIndices.push_back (i);
		}
	    }
	}
	return listOfIndices.size();		// return ownership of pointer
}


//--- end of definitions for TCohortAgModelPercent ---
