// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  treegrow.cpp
//	Class:	  TCentury
//	Function: TreeGrowth
//
//	Description:
//	Simulate forest production associated with tree growth.
// ----------------------------------------------------------------------------
//	History:
//	Apr00   Tom Hilinski, tom.hilinski@colostate.edu
//	* Cleaned up code and optimized.
//	Dec01   Tom Hilinski
//	* Modified to use new mineral E pools.
//	Sep03   Tom Hilinski
//	* Merged many of the mods in TDayCent::TreeGrowth.
// ----------------------------------------------------------------------------
//	Notes:
//	(1) This function was part of trees()/trees.f in Century 4.
// ----------------------------------------------------------------------------

#include "TCentury.h"

void TCentury::TreeGrowth ()
{
    float uptake[12]; 		// was [EPOOLS][NUMELEM];
    float cprodf = 0.0f;        // NPP this time period -mdh 7/12/02

#define uptake_ref(a_1,a_2)	uptake[(a_2)*EPOOLS + a_1]

    //--- Initialize monthly production
    float monthlyProduction[FPARTS];
    for ( short part = 0; part < FPARTS; ++part )
	monthlyProduction[part] = 0.0f;

    //--- Determine old or new forest
    // indexFCAF points to new forest carbon allocation fractions (ptr = 0) or
    // mature forest carbon allocation fractions (ptr = 1) for each of the
    // tree parts; leaves, fine roots, fine branches, large wood, and
    // coarse roots.  switch from new forest allocation fractions to old
    // forest allocation fractions at time = swold
    register short indexFCAF;
    if (st->time <= parfs.swold)
    	indexFCAF = 0;			// new forest C allocation fractions
    else
    	indexFCAF = 1;			// mature forest C allocation fractions

    // Calculate carbon fraction in each part
   float cfrac[FPARTS];
    for ( short part = 0; part < FPARTS; ++part)
    	cfrac[part] = fcfrac_ref (part, indexFCAF);

    //--- For seasonal deciduous/conifer forest system, reapportion growth
    // if its the first month of the growing season to simulate leaf
    // bloom (80% of growth goes to leaves)
    // This applies only to non-drought systems.
    // From Bill Parton (April 2000):
    // "For the drought decidious plants the main impact is to have leaves
    // drop in response to drought stress. You don't want leaf growth
    // initiated the same way as traditional decidious plants. Drought
    // decidious plants have their leaf growth start when it get wet enough
    // and is not controlled by temperature directly like the traditional
    // decidious plants."
    if ( IsNormalDecidForest() )
    {
        // First month of the growing season?
        if ( StartDeciduousGrowth () )
        {
    		// Carbon reapportionment . . .
    		// Changed to balance the portions  -rm 5/91
    		cfrac[LEAF] = 0.8f;
    		register float
    		    remc = 1.0f - cfrac[LEAF],	// C to be partitioned
    		    totcup = 0.0f;		// total C uptake except leaves
    		for ( short part = FROOT; part <= CROOT; ++part)
    			totcup += cfrac[part];
    		Assert (totcup != 0.0f);
    		for ( short part = FROOT; part <= CROOT; ++part)
    		    cfrac[part] = remc * fcfrac_ref (part, indexFCAF) / totcup;
        }
    }
    // Previous flowup should have updated mineral pools
    float eProfileTotal[NUMELEM];	// sum of element in profile
    for ( short element = 0; element < site.nelem; ++element )
    {
	eProfileTotal[element] = soil->QuantityE (
		(TMineralElements)element, 0, water.depthOfRoots);
	eProfileTotal[element] = std::max (0.0f, eProfileTotal[element]);
    }

    float plantNfix = 0.0f;
    if ( parfs.IsGrowing() &&
    	 potentProd.forestC > 0.0f )
    {
	// Determine actual production values, restricting the C/E ratios
	RestrictProduction ( eProfileTotal, parfs.ccefor, FPARTS,
		 cfrac, potentProd.forestC,
		 RootImpactOnNutrients (forestC.frootc),
		 nps.forstg, param.snfxmx[FORSYS],
		 // the following parameters return values:
		 cprodf, nps.eprodf, uptake, plantNfix );
    }
    else
    {
	cprodf = 0.0f;
    }
    Assert ( cprodf <= potentProd.forestC );

    // If growth occurs...
    if (cprodf > 0.0f)
    {
	// The following N-fixation accumulations were moved from
	//   NutrientLimitation() because RestrictProduction() is sometimes
	//   called twice (for trees). -mdh 10/9/02
	nps.snfxac[FORSYS] += plantNfix;  // annual accumulation by plant type
	nps.nfixac += plantNfix;          // annual accumulation
	nps.nfix += plantNfix;            // monthly accumulation

	// Update accumulators for N, P, and S uptake
	for (short element = 0; element < site.nelem; ++element)
	{
	    nps.eupacc[element] += nps.eprodf[element];
	    for (short part = 0; part < FPARTS; ++part)
		eupprt_ref (part, element) += elementUptake_ref (part, element);
	}

	// C/N ratio for production
	Assert (nps.eprodf[N] != 0.0f);
	nps.tcnpro = cprodf / nps.eprodf[N];

	//--- Production for each tree part
	// New variable MFPRD added for gridded output - 6/96 rm
	for ( short part = 0; part < FPARTS; ++part)
	    monthlyProduction[part] = cfrac[part] * cprodf;

	// Growth of leaves; split into labeled & unlabeled parts
	ScheduleCFlow ( st->time, monthlyProduction[LEAF],
		param.cisotf, 1.0f,
		&soilC.csrsnk[UNLABL], &forestC.rlvcis[UNLABL],
		&soilC.csrsnk[LABELD], &forestC.rlvcis[LABELD],
		forestC.alvcis);

	// Growth of fine roots; split into labeled & unlabeled parts
	ScheduleCFlow ( st->time, monthlyProduction[FROOT],
		param.cisotf, 1.0f,
		&soilC.csrsnk[UNLABL], &forestC.frtcis[UNLABL],
		&soilC.csrsnk[LABELD], &forestC.frtcis[LABELD],
		forestC.afrcis);

	// Growth of fine branches; split into labeled & unlabeled parts
	ScheduleCFlow ( st->time, monthlyProduction[FBRCH],
		param.cisotf, 1.0f,
		&soilC.csrsnk[UNLABL], &forestC.fbrcis[UNLABL],
		&soilC.csrsnk[LABELD], &forestC.fbrcis[LABELD],
		forestC.afbcis);

	// Growth of large wood; split into labeled & unlabeled parts
	ScheduleCFlow ( st->time, monthlyProduction[LWOOD],
		param.cisotf, 1.0f,
		&soilC.csrsnk[UNLABL], &forestC.rlwcis[UNLABL],
		&soilC.csrsnk[LABELD], &forestC.rlwcis[LABELD],
		forestC.alwcis);

	// Growth of coarse roots; split into labeled  unlabeled parts
	ScheduleCFlow ( st->time, monthlyProduction[CROOT],
		param.cisotf, 1.0f,
		&soilC.csrsnk[UNLABL], &forestC.crtcis[UNLABL],
		&soilC.csrsnk[LABELD], &forestC.crtcis[LABELD],
		forestC.acrcis);

	//--- Actual Uptake
	for (short e = 0; e < site.nelem; ++e)	// each element...
	{
	    float euf[FPARTS];		// fraction of update for each tree part
	    Assert (nps.eprodf[e] > 0.0f);
	    float const recipEProdF = 1.0f / nps.eprodf[e];	// optimize
	    for ( short part = 0; part < FPARTS; ++part )
	    	euf[part]  = elementUptake_ref (part,  e) * recipEProdF;

	    // Take up nutrients from the E translocation pool
	    {
	      float const totalUptake = uptake_ref (ESTOR, e);
	    float* const ptrForstg = &nps.forstg[e];		// optimize
	      flows->Schedule (ptrForstg, &nps.rleave[e], st->time,
	      			totalUptake * euf[LEAF]);
	      flows->Schedule (ptrForstg, &nps.froote[e], st->time,
	      			totalUptake * euf[FROOT]);
	      flows->Schedule (ptrForstg, &nps.fbrche[e], st->time,
	      			totalUptake * euf[FBRCH]);
	      flows->Schedule (ptrForstg, &nps.rlwode[e], st->time,
	      			totalUptake * euf[LWOOD]);
	      flows->Schedule (ptrForstg, &nps.croote[e], st->time,
	      			totalUptake * euf[CROOT]);
	    }

	    // Take up nutrients from soil
	    {
	      float const fractionInSolution =
			(e == P ?
			  FractionMinPInSolution (
			  	water.depthOfRoots, soil->MineralP() ) :
			  1.0f);
	      float const totalUptake =
	      		uptake_ref (ESOIL, e) * fractionInSolution;
	      Assert (totalUptake <= eProfileTotal[e]);
	      if ( totalUptake > 0.0f )
	      {
		soilFlows->FlowNPSfromMineralSoil (		// leaves
			(TMineralElements)e,
			&nps.rleave[e], totalUptake * euf[LEAF],
			water.depthOfRoots );
		soilFlows->FlowNPSfromMineralSoil (		// fine roots
			(TMineralElements)e,
			&nps.froote[e], totalUptake * euf[FROOT],
			water.depthOfRoots );
		soilFlows->FlowNPSfromMineralSoil (		// fine branches
			(TMineralElements)e,
			&nps.fbrche[e], totalUptake * euf[FBRCH],
			water.depthOfRoots );
		soilFlows->FlowNPSfromMineralSoil (		// large wood
			(TMineralElements)e,
			&nps.rlwode[e], totalUptake * euf[LWOOD],
			water.depthOfRoots );
		soilFlows->FlowNPSfromMineralSoil (		// coarse roots
			(TMineralElements)e,
			&nps.croote[e], totalUptake * euf[CROOT],
			water.depthOfRoots );
	      }
	    }

	    // Take up nutrients from nitrogen fixation
	    if (e == N && plantNfix > 0.0f)
	    {
		float const totalUptake = uptake_ref (ENFIX, e); // optimize
		flows->Schedule (&nps.esrsnk[e], &nps.rleave[e], st->time,
				totalUptake * euf[LEAF]);
		flows->Schedule (&nps.esrsnk[e], &nps.froote[e], st->time,
				totalUptake * euf[FROOT]);
		flows->Schedule (&nps.esrsnk[e], &nps.fbrche[e], st->time,
				totalUptake * euf[FBRCH]);
		flows->Schedule (&nps.esrsnk[e], &nps.rlwode[e], st->time,
				totalUptake * euf[LWOOD]);
		flows->Schedule (&nps.esrsnk[e], &nps.croote[e], st->time,
				totalUptake * euf[CROOT]);
	    }

	    // Take up nutrients from fertilizer
	    if (param.aufert != 0.0f && uptake_ref (EFERT, e) > 0.0f)
	    {
		// Automatic fertilizer added to plant pools
		float const totalUptake = uptake_ref (EFERT, e); // optimize
		flows->Schedule (&nps.esrsnk[e], &nps.rleave[e], st->time,
				totalUptake * euf[LEAF]);
		flows->Schedule (&nps.esrsnk[e], &nps.froote[e], st->time,
				totalUptake * euf[FROOT]);
		flows->Schedule (&nps.esrsnk[e], &nps.fbrche[e], st->time,
				totalUptake * euf[FBRCH]);
		flows->Schedule (&nps.esrsnk[e], &nps.rlwode[e], st->time,
				totalUptake * euf[LWOOD]);
		flows->Schedule (&nps.esrsnk[e], &nps.croote[e], st->time,
				totalUptake * euf[CROOT]);

		// Automatic fertilizer added to mineral pool
		Assert (fixed.favail[e] != 0.0f);
		float amt = totalUptake * (1.0f / fixed.favail[e] - 1.0f);
		amt = soilFlows->FlowNPSintoMineralSoil (
			(TMineralElements)e, &nps.esrsnk[e], amt, wt.simDepth );
		nps.fertot[e] += totalUptake + amt;
	    }
	} // end - for each element loop

	// Accumulate this period's NPP in monthly and annual variables
	forestC.cprodf += cprodf;
	forestC.cproda += cprodf;

    } // end - If growth occurs
    // Else there is no production this month

#undef uptake_ref
}

//--- end of file treegrow.cpp ---
