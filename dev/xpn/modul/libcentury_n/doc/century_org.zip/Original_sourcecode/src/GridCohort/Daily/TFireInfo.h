#ifndef INC_nrel_dcirc_TFireInfo_h
#define INC_nrel_dcirc_TFireInfo_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TFireInfo.h
//	Class:	  TFireInfo
//
//	Description:
//	Describes the type of system (crop/grass, forest,savanna) that is
//	having a fire event.
//
//	Responsibilities:
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, July 2002
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

struct TFireInfo			// Fire information
{
	enum TFireType
	{
		FT_None,
		FT_CropGrass, FT_Savanna, FT_Forest,
		FT_EndOfList
	};
	TFireType fireType;

	TFireInfo ()
	{
	  fireType = FT_None;
	}
};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_TFireInfo_h
