#ifndef INC_TLowerSoil_h
#define INC_TLowerSoil_h

// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TLowerSoil.h
//	Class:	  TLowerSoil
//
//	Description:
//	Class to manage Century's soil C and element pools in the soil
//	below the simulation layer.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Oct98
// ----------------------------------------------------------------------------
//	History:
//	Mar99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Updated the notes and algorithm description.
//	May99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added minimum thresholds for pools and thicknesses.
//	Jan00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Fixed some inappropriate code.
//	* Modified constructor and removed "SetTopDepth".
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Rewritten to work with the new physical soil and C depth distribution
//	  submodels.
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added copy constructor, operator=
//	Jun02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Fixed bug in Add, when thicknessAdded > topDepth.
//	* Fixed bug in Initialize, so topDepth is now set to minTopDepth.
// ----------------------------------------------------------------------------
//	Notes and Algorithm: See file TLowerSoil.cpp.
// ----------------------------------------------------------------------------

#include "TCenturySoil.h"
#include "centconsts.h"

//	Array sizes for C, E pools
static short const
	sizeC = 6,	// (6) NUMPOOLS * NUMISO
	sizeE = 9,	// (9) NUMPOOLS * NUMELEM
	sizeCE = 9;	// (9) NUMPOOLS * NUMELEM

class TLowerSoil
{
  public:
	//--- constructors and destructor
	TLowerSoil (
	  float const useMinTopDepth,	// min. depth to top (cm)
	  float const useMaxTopDepth);	// max. depth to top (cm)
	~TLowerSoil ()
	  {
	  }

	TLowerSoil (TLowerSoil const & object)	// copy constructor
	  : minTopDepth (object.minTopDepth),
	    maxTopDepth (object.maxTopDepth)
	  {
	    Initialize ();
	    Copy (object);
	  }

	//---- operator overloads
	TLowerSoil& operator= (TLowerSoil const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	Clear ();
		Copy (object);
	    }
	    return *this;
	  }

	//--- constants
	// These should match those in src/century/centconsts.h
	enum { ACTIVE, SLOW, PASSIVE, NUMPOOLS }; // Indices to C pools
	enum { N, P, S, NUMELEM };		  // Indices to elements
	enum { UNLABELED, LABELED, NUMISO };	  // Indices to C isotopes

	//--- functions - Assign values
	void SetSoil (TCenturySoil* useSoil);	// Set physical soil instance
        void SetPoolsFromDensity (		// Initialize C and E pools
        					//   using C and E densities
        					//   (g/cm^3)
	  float const (&densityC)[sizeC],	//   C [NUMPOOLS][NUMISO]
	  float const (&densityE)[sizeE]);	//   E [NUMPOOLS][NUMELEM]
        void SetPoolsFromAmounts (		// Initialize C and E pools
        					//   with total C and E amounts
        					//   (g/m^2/cm * 180cm)
	  float (&amountC)[sizeC],		//   C [NUMPOOLS][NUMISO]
	  float (&amountE)[sizeE]);		//   E [NUMPOOLS][NUMELEM]
	void SetPoolsFromC (			// Initialize from C pools
	  float (&amountC)[sizeC]);		//   C [NUMPOOLS][NUMISO]

	//--- functions - Transfers
	float Add (				// Add C and E (g/m^2)
	  float& thickness,		//   thickness added (cm)
	  float (&amountC)[sizeC],	//   C [NUMPOOLS][NUMISO]
	  float (&amountE)[sizeE]);	//   E [NUMPOOLS][NUMELEM]
	float Remove (				// Remove C and E (g/m^2)
	  float& thickness,		//   thickness removed (cm)
	  float (&removedC)[sizeC],	//   C [NUMPOOLS][NUMISO]
	  float (&removedE)[sizeE]);	//   E [NUMPOOLS][NUMELEM]

	//--- functions - Queries
	float Thickness () const		// Lower layer thickness (cm)
	  { return soil->SoilDepth() - topDepth; }
	float DepthToTop () const		// Depth to top of layer (cm)
	  { return topDepth; }
	float DepthToBottom () const		// Bottom depth (cm)
	  { return soil->SoilDepth(); }
	float MinSimLayerThickness () const	// Get minimum depth to top
	  { return minTopDepth; }
	float MaxSimLayerThickness () const	// Get maximum depth to top
	  { return maxTopDepth; }
	float GetTotalC () const;		// Return total C in C pools

	//--- functions - Data access (element)
	float&  C (				// C isotope pools  (g)
	  short const pool,
	  short const isotope)
	  { return poolC[pool * NUMISO + isotope]; }
	float const &  C (			// C isotope pools  (g)
	  short const pool,
	  short const isotope) const
	  { return poolC[pool * NUMISO + isotope]; }
	float&  E (				// Element pools: N,P,S (g)
	  short const pool,
	  short const element)
	  { return poolE[pool * NUMELEM + element]; }
	float const &  E (			// Element pools: N,P,S (g)
	  short const pool,
	  short const element) const
	  { return poolE[pool * NUMELEM + element]; }
	float& CCA (				// C cumulative additions (g)
	  short const pool,
	  short const isotope)
	  { return cumAddC[pool * NUMISO + isotope]; }
	float& ECA (				// N,P,S cum. additions (g)
	  short const pool,
	  short const element)
	  { return cumAddE[pool * NUMELEM + element]; }
	float& CCR (				// C cumulative removals (g)
	  short const pool,
	  short const isotope)
	  { return cumRemC[pool * NUMISO + isotope]; }
	float& ECR (				// N,P,S cum. removals (g)
	  short const pool,
	  short const element)
	  { return cumRemE[pool * NUMELEM + element]; }

	//--- functions - Miscellaneous
	void Clear ()				// "Clear" data members
	  {
	    Initialize ();
	  }
	void ZeroThesePools (			// Set pools to zero
	  float (&poolsC)[sizeC],		//   C[NUMPOOLS][NUMISO]
	  float (&poolsE)[sizeE]);	//   E[NUMPOOLS][NUMELEM]

  protected:
	//--- constants
	static float const
		poolMinThreshold,	// min. pool size in calcs
		minLayerThickness;	// min. layer thickness
	float const
		minTopDepth,		// minimum depth to top (cm)
		maxTopDepth;		// maximum depth to top (cm)

	//--- data
	float	topDepth;	// depth to top of lower layer (cm)
				// Pool sizes are (g m-2)
	float poolC[sizeC];	// pools for C isotopes: [NUMPOOLS][NUMISO]
	float cumAddC[sizeC];	// cumulative transfers into C pools
	float cumRemC[sizeC];	// cumulative transfers out of C pools
	float poolE[sizeE];	// pools for N, P, S: [NUMPOOLS][NUMELEM]
	float cumAddE[sizeE];	// cumulative transfers into N, P, S pools
	float cumRemE[sizeE];	// cumulative transfers from N, P, S pools
	float ratioCE[sizeCE];	// C:E ratios, each pool and each element
	TCenturySoil* soil;	// pointer to soil physical class instance

  private:
	//--- data

	//--- functions
	void Initialize ();			// Initialize members
	void Copy (TLowerSoil const & object);	// Copy to this
	void CalcCERatios ();			// Calc the C:E ratios
};

#endif // INC_TLowerSoil_h
