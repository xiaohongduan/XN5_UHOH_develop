// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model, daily version
//	File:	diffusiv.cpp
//	Class:	TDayCentSoil
//	Function: Diffusivity
//
//	Description:
//	Estimates normalized diffusivity in soils.
//	Returns the normalized diffusivity in aggregate soil media, units 0-1:
//	ratio of gas diffusivity through soil to gas diffusivity through air
//	at optimum water content.
//	Reference:
//	Millington and Shearer (1971) Soil Science Literature Source:
//	Davidson, E.A. and S.E. Trumbore (1995).
// ----------------------------------------------------------------------------
//	Author: Melannie Hartman, Contributed by Chris Potter, NASA Ames
//	History:
//	??????  Melannie Hartman, melannie@NREL.colostate.edu
//	* Created original diffusiv.c for FORTRAN/C version of DayCent
//	Apr2001	 Melannie Hartman, melannie@NREL.colostate.edu
//	* Translated diffusiv.c to diffusiv.cpp
//	May03	Tom Hilinski
//	* Additional assertions and some minor cleanup.
//	Sep03	Tom Hilinski
//	* Assertions failing when wfps == 1.0 and A ~= porosity;
//	  - added vol. air content to replace (porosity - A) calc.
//	  - allowed wfps == 1.0
//	* Porosity changed to be a function argument.
//	* If pore space is saturated, then diffusivity = 0
// ----------------------------------------------------------------------------
//	Notes:
//	* swflag == 6 in site.100 produced a field capacity > porosity.
//	  Field Capacity is computed in prelim.cpp if swflag > 0. -mdh 6/21/01
// ----------------------------------------------------------------------------

#include "TDayCentSoil.h"
using namespace std;

float TDayCentSoil::Diffusivity (
	float const A,		// fraction of soil bed volume occupied by
				//   field capacity
				//   (intra-aggregate pore space, 0-1)
	float const bulkDen,	// bulk density of soil (g/cm^3)
	float const porosity,	// porosity fraction (0-1)
	float const wfps)	// Water Filled Pore Space fraction
				// (volumetric swc/porosity, 0-1)
{
    Assert (A > 0.0f && A < 1.0f);
    Assert (bulkDen > 0.0f && bulkDen <= PARTDENS);
    Assert (wfps >= 0.0f && wfps <= 1.0f);

    // fraction of soil bed volume occupied by pore space,
    //   (A + inter-aggregate pore space)
    //   (1.0 - bulkden/particle density, 0-1)
    // float const porosity = 1.0f - bulkDen / PARTDENS;
    Assert (porosity > 0.0f && porosity < 1.0f);

    // normalized diffusivity in aggregate soil media (0-1)
    float dDO = 0.0f;

    // volumetric air content fraction
    float const vac = std::min (1.0f,
			std::max (0.0f, porosity - A) );
    if ( vac > 0.0f )	// undersaturated?
    {
	// soil water content as % of field capacity (%)
	// (this value can be > 100%)
	float const pfc = wfps * 100.0f  / (A / porosity);

	// volumetric fraction
	float const vfrac = ( pfc >= 100.0f ?
		(wfps * porosity - A) / vac :
		0.0f );

	// volumetric water content of the soil bed volume
	// float my_theta_V = wfps * (1.0 - bulkden/PARTDENS);
	// float my_theta_V = wfps * porosity;
	float const theta_V = ( pfc < 100.0f ?
		(pfc / 100.0f) * A :
		A + std::min (vfrac, 1.0f) * vac );

	// volume H2O per unit bed volume in inter-aggregate pore space
	float const theta_P = (theta_V < A) ? 0.0f : theta_V - A;

	// volume H2O per unit bed volume in intra-aggregate pore space
	float const theta_A = (theta_V > A) ? A : theta_V;

	// fractional liquid saturation of the A component of total pore volume
	float const s_wat = std::min ( 1.0f, theta_V / A );

	// fractional liquid saturation of the P component of total pore volume
	float const sw_p = std::min ( 1.0f, theta_P / vac );

	float tp1, tp2, tp3, tp4, tp5, tp6, tp7, tp8;  // intermediate variables
	if (1.0f - s_wat > 0.0f)
		tp1 = std::pow( (1.0f - s_wat), 2.0f );
	else
		tp1 = 0.0f;

	tp2 = (A - theta_A) / (A + (1.0f - porosity));
	Assert ( A + (1.0f - porosity) > 0.0f );
	if ( tp2 > 0.0f )
		tp3 = std::pow( tp2, (0.5f * tp2 + 1.16f) );
	else
		tp3 = 0.0f;


	tp4 = 1.0f - pow( vac, (0.5f * vac + 1.16f) );
	tp5 = vac - theta_P;
	if (tp5 > 0.0f)
		tp6 = std::pow(tp5, (0.5f * tp5 + 1.16f));
	else
		tp6 = 0.0f;
	Assert ( (1.0f - sw_p) > 0.0f );
	tp7 = std::pow((1.0f - sw_p), 2.0f);
	tp8 = std::max( 0.0f,
		( (tp1 * tp3 * tp4 * (tp5 - tp6)) /
		(1.0E-6f + (tp1 * tp3 * tp4) + tp5 - tp6) * 1.0E7f) );

	// normalized diffusivity in aggregate soil media (0-1)
	float const dDO = std::max(0.0f, (tp8 / 1.0E7f + tp7 * tp6) );
    }
    Assert (dDO <= 1.0f);
    return dDO;
}

//--- end of file ---

