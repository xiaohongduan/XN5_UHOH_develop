#ifndef INC_nrel_dcirc_TCenturySimOutputMgr_h
#define INC_nrel_dcirc_TCenturySimOutputMgr_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TCenturySimOutputMgr.h
//	Class:	  TCenturySimOutputMgr
//
//	Description:
//	Class for managing simulation output at the simulation level for
//	the DayCent model.
//	Output object is TFileStream.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, June 2002
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TSimOutputMgr.h"
#include "TFileStream.h"
#include "TSharedPtr.h"
#include <string>
#include "GCFfwd.h"

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class TDayCentSimController;

class TCenturySimOutputMgr
	: public ::nrel::gcf::TSimOutputMgr
{
  public:
	//---- types
	typedef TDayCentSimController			TOwner;
	typedef ::nrel::io::TFileStream			TOutput;
	typedef ::nrel::gcf::TSimOutputMgr		MyBase;

	//---- constructors and destructor
	TCenturySimOutputMgr (
	  TOwner * const useParent,		// ptr to parent
	  TSharedPtr<TOutput> useOutputSink);	// output sink
	virtual ~TCenturySimOutputMgr ()
	  {
	  }

	//---- functions
	bool Write (					// Write to output
	  std::string const & outputText)
	  {
	    return !(ofs->GetStream() << outputText << std::endl);
	  }
	bool Write (					// Write to output
	  char const * const outputText)
	  {
	    return !(ofs->GetStream() << outputText << std::endl);
	  }

  protected:
	//---- data
	TSharedPtr<TOutput> ofs;			// output object
};

  } // namespace dcirc
} // namespace nrel


#endif // INC_nrel_dcirc_TCenturySimOutputMgr_h
