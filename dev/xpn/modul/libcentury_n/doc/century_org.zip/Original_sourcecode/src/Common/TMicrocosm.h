#ifndef INC_TMicrocosm_h_
#define INC_TMicrocosm_h_

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TMicrocosm.h
//	Class:	  TMicrocosm
//
//	Description:
//	Variables for the microbial community, if simulated.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec00
// ----------------------------------------------------------------------------
//	History:
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Extracted this class from the rest of Century;
//	  Just an outline for now - hopefully to be fleshed out later.
//	Jul02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added copy constructor.
// ----------------------------------------------------------------------------
//	Copyright 2000 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

class TMicrocosm
{
  public:

	//--- functions
	TMicrocosm ()				// Constructor
	  { Initialize(); }
	~TMicrocosm ()				// Destructor
	  { ; }
	TMicrocosm (TMicrocosm const & object)  // copy constructor
	  {
	    Copy (object);
	  }

	//---- operator overloads

	//---- functions
	void SetTemperature (			// Set the microcosm temp.
	  float const useTemperature)
	  { mcTemperature = useTemperature; }
	float GetTemperature () const		// Returns microcosm temp.
	  { return mcTemperature; }
	void Clear ()				// Clear member variables
	  { Initialize(); }

  protected:

	//--- data
	float mcTemperature;	// microcosm temperature

  private:

	//--- functions
	void Initialize ()
	  {
	    mcTemperature = 0.0f;
	  }
	void Copy (TMicrocosm const & object)	// Copy to this
	  {
	    if ( &object )
	    {
	    	mcTemperature = object.mcTemperature;
	    }
	  }
};

#endif // INC_TMicrocosm_h_
