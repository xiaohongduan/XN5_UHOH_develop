
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  nfluxll_ncid;			/* netCDF id */

/* variable ids */
int  minerlll_id, nfixll_id, volexll_id, volgmll_id, volplll_id, wdfxmall_id, wdfxmsll_id;
int  timell_id, lat_id, lon_id;

/* added volpl -mdh 8/1/00 */

/* create nflux.nc */
int
nfluxdef_ll(int *ntimes, int *nlat, int *nlon, char * history,
            float *opltim, float *qtime) {

   int   status, istart_year, iend_year, ii;
   float fill, fstart_year, fend_year;
   char  timeunits[25], temp[5];

   /* dimension ids */
   int  time_dim = 0;
   int  layer_dim = 0;
   int  lat_dim = 0;
   int  lon_dim = 0;

   /* variable shapes */
   int dims[4];

   /* Set fill, start_year, and end_year values */
   fill = NC_FILL_FLOAT;
   fstart_year = *opltim;
   fend_year = *qtime - 1;
   istart_year = fstart_year;
   iend_year = fend_year;

   for (ii = 0; ii < 25; ii++) {
     timeunits[ii] = '\0';
   }
   /* Get the start time for the time definition */
   sprintf(temp, "%d", istart_year); 
   strcat(timeunits, "days since ");
   strcat(timeunits, temp);
   strcat(timeunits, "-01-01");

   /* enter define mode */
   status = nc_create("nfluxll.nc", NC_CLOBBER, &nfluxll_ncid);
   if (status != NC_NOERR) handle_error("nc_create(nflux.nc)", status);

   /* define dimensions */
   status = nc_def_dim(nfluxll_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(nfluxll_ncid, "layer", 10L, &layer_dim);
   status = nc_def_dim(nfluxll_ncid, "lat", (size_t) *nlat, &lat_dim);
   status = nc_def_dim(nfluxll_ncid, "lon", (size_t) *nlon, &lon_dim);

   /* define variables */

   dims[0] = time_dim;
   status = nc_def_var (nfluxll_ncid, "time", NC_INT, 1, dims, &timell_id);

   dims[0] = lat_dim;
   status = nc_def_var (nfluxll_ncid, "lat", NC_FLOAT, 1, dims, &lat_id);

   dims[0] = lon_dim;
   status = nc_def_var (nfluxll_ncid, "lon", NC_FLOAT, 1, dims, &lon_id);

   dims[0] = time_dim;
   dims[1] = layer_dim;
   dims[2] = lat_dim;
   dims[3] = lon_dim;
   status = nc_def_var (nfluxll_ncid, "minerl", NC_FLOAT, 4, dims, &minerlll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nfluxll_ncid, "nfix", NC_FLOAT, 3, dims, &nfixll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nfluxll_ncid, "volex", NC_FLOAT, 3, dims, &volexll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nfluxll_ncid, "volgm", NC_FLOAT, 3, dims, &volgmll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nfluxll_ncid, "volpl", NC_FLOAT, 3, dims, &volplll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nfluxll_ncid, "wdfxma", NC_FLOAT, 3, dims, &wdfxmall_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nfluxll_ncid, "wdfxms", NC_FLOAT, 3, dims, &wdfxmsll_id);

   /* assign attributes */
   status = nc_put_att_text (nfluxll_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (nfluxll_ncid, timell_id, "long_name", strlen("Time"), "Time");
   status = nc_put_att_text (nfluxll_ncid, timell_id, "units", strlen(timeunits), timeunits);
   status = nc_put_att_text (nfluxll_ncid, timell_id, "time_step", strlen("monthly"), "monthly");
   status = nc_put_att_text (nfluxll_ncid, timell_id, "calendar", strlen("gregorian"), "gregorian");
   status = nc_put_att_int (nfluxll_ncid, timell_id, "start_year", NC_INT, 1, &istart_year);
   status = nc_put_att_int (nfluxll_ncid, timell_id, "end_year", NC_INT, 1, &iend_year);

   status = nc_put_att_text (nfluxll_ncid, lat_id, "long_name", strlen("Latitude"), "Latitude");
   status = nc_put_att_text (nfluxll_ncid, lat_id, "units", strlen("degrees_north"), "degrees_north");
   status = nc_put_att_text (nfluxll_ncid, lat_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (nfluxll_ncid, lat_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (nfluxll_ncid, lon_id, "long_name", strlen("Longitude"), "Longitude");
   status = nc_put_att_text (nfluxll_ncid, lon_id, "units", strlen("degrees_east"), "degrees_east");
   status = nc_put_att_text (nfluxll_ncid, lon_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (nfluxll_ncid, lon_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (nfluxll_ncid, minerlll_id, "long_name", 
	strlen("mineral_N"), "mineral_N");
   status = nc_put_att_text (nfluxll_ncid, minerlll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(nfluxll_ncid, minerlll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nfluxll_ncid, nfixll_id, "long_name", 
	strlen("symbiotic_N_fixation"), "symbiotic_N_fixation");
   status = nc_put_att_text (nfluxll_ncid, nfixll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(nfluxll_ncid, nfixll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nfluxll_ncid, volexll_id, "long_name", 
	strlen("Volatilization_after_uptake"), "Volatilization_after_uptake");
   status = nc_put_att_text (nfluxll_ncid, volexll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(nfluxll_ncid, volexll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nfluxll_ncid, volgmll_id, "long_name", 
	strlen("Volatilization_gross_min"), "Volatilization_gross_min");
   status = nc_put_att_text (nfluxll_ncid, volgmll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(nfluxll_ncid, volgmll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nfluxll_ncid, volplll_id, "long_name", 
	strlen("Volatilization_of_N_from_plants"), "Volatilization_of_N_from_plants");
   status = nc_put_att_text (nfluxll_ncid, volplll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(nfluxll_ncid, volplll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nfluxll_ncid, wdfxmall_id, "long_name", 
	strlen("Atmospheric_N_fixation"), "Atmospheric_N_fixation");
   status = nc_put_att_text (nfluxll_ncid, wdfxmall_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(nfluxll_ncid, wdfxmall_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nfluxll_ncid, wdfxmsll_id, "long_name", 
	strlen("Non-symbiotic_soil_N_fixation"), "Non-symbiotic_soil_N_fixation");
   status = nc_put_att_text (nfluxll_ncid, wdfxmsll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(nfluxll_ncid, wdfxmsll_id, "_FillValue", NC_FLOAT, 1, &fill);

   /* leave define mode */
   status = nc_enddef (nfluxll_ncid);
   return 0;
}
