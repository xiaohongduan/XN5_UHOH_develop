// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  tremin.cpp
//	Class:	  TCentury
//	Function: GetTreeRemoval
//
//	Description:
//	Read the new tree removal parameter set.
//	Returns true if successful match in database, else false if not.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
// ----------------------------------------------------------------------------
//	History:
//	Jul01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to use new TEventDBList class.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "TEventDBList.h"
#include "util.h"
#include "constants.h"

MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::GetTreeRemoval (char const* tremToMatch)
{
	// error checks
	if ( !tremToMatch || !(*tremToMatch) )		// anything there?
		return false;

	// get the option set
	TEventOptionSet const & optionSet =
		*paramDbList->Get (TEventDBList::DBI_Trem);
	if ( !&optionSet )				// database not there?
		ThrowCentException (TCentException::CE_NSPPDB,
			::eventName[ET_TreeRemoval]);
	if ( !optionSet.GetOptionCount () )		// empty database?
		ThrowCentException (TCentException::CE_EMPPDB,
			::eventName[ET_TreeRemoval]);

	// get the option matching the parameter string
    	TEventOption const * const option = optionSet.GetOption (tremToMatch);
	if ( !option )					// match found?
		return false;

	// retrieve values from option and save in Century's variables
	short const numParams = 20;			// total for an option
	short count = option->GetParamCount ();
	if ( count != numParams )			// counts match?
		ThrowCentException (TCentException::CE_OPCBAD,
			::eventName[ET_TreeRemoval]);

	register short k = 0;			// index to param values

	// forest removal event type
	forrem.evntyp = static_cast<Tforrem::TForestEventType>(
		(int)( option->GetParameter(k++)->GetValue() ) );
	if ( forrem.evntyp != Tforrem::FORESTCUT &&
	     forrem.evntyp != Tforrem::FORESTFIRE )	// invalid event types?
	{
		// To Do: handle invalid forest event type
	}

	// Fractions of material removed from pools:
	// 0 = live leaves
	// 1 = live fine branches
	// 2 = live large wood
	// 3 = dead find branches
	// 4 = dead large wood
	for ( short i = 0; i < 5; i++ )
		forrem.remf[i] = option->GetParameter(k++)->GetValue();
	// Fractions of live root pools that die:
	// 0 = find root
	// 1 = coarse root
	for ( short i = 0; i < 2; i++ )
		forrem.fd[i] = option->GetParameter(k++)->GetValue();
	// Fraction of component E in a pool P that is returned to the
	// system as ash or litter, where arrays is (P, E).
	// Components are 0 = C, 1 = N, 2 = P, 3 = S.
	// Pools:
	// 0 = dead live leaves
	// 1 = dead fine branches
	// 2 = dead large wood
    	for (short i = 0; i < 4; ++i)			// for each element
    		for (short j = 0; j < 3; ++j)		// for each pool
			retf_ref (j, i) = option->GetParameter(k++)->GetValue();

	// save option name in Century class variable
	strcpy (sched->curTRem, tremToMatch);
	return true;
}	// GetTreeRemoval
