// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  cultiv.cpp
//	Class:	  TDayCent
//	Function: SimulateCultivation
//
//	Description:
//	Implement cultivation event.
// ----------------------------------------------------------------------------
//	History:
//      See Century/cultiv.cpp
//      Sep01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Changed this function from TCentury to TDayCent member.
//      * A fraction of the maintenance respiration storage pool is
//        removed in proportion to the amount of live roots removed.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//      Notes:
//      * A fraction of the maintenance respiration storage pool flows into
//        the soil metabolic C pool, is this correct? -mdh 9/5/01
//        (See also droot.cpp and harvst.cpp)
// ----------------------------------------------------------------------------

#include "TDayCent.h"
#include "TCenturyMath.h"

void TDayCent::SimulateCultivation ()
{
    float  accum[2] = { 0.0f, 0.0f },
	recres[3];	//

    //--- Some standing dead goes into surface litter
    if (cropC.stdedc > 0.0f)
    {
	float const tsdsfc = cropC.stdedc * parcp.cultra[3];
	for (short iel = 0; iel < site.nelem; ++iel)
	    recres[iel] = nps.stdede[iel] / cropC.stdedc;
	float const fr14 = cropC.stdcis[1] / cropC.stdedc;
	PartitionResidue (tsdsfc, recres, SRFC, cropC.stdcis, nps.stdede,
			  comput.pltlig[ABOVE], fr14);
    }

    //--- Some surface litter goes into the top soil layer.
    // Structural
    float trans = soilC.strucc[SRFC] * parcp.cultra[5];
    if (trans > 0.0f)
    {
	ScheduleCFlow ( st->time, trans,
			strcis_ref (SRFC,LABELD) / soilC.strucc[SRFC], 1.0f,
			&strcis_ref (SRFC,UNLABL), &strcis_ref (SOIL,UNLABL),
			&strcis_ref (SRFC,LABELD), &strcis_ref (SOIL,LABELD),
			accum );

	// Recompute lignin fraction in structural soil C
	AdjustLigninFraction ( soilC.strucc[SOIL], soilC.strlig[SRFC], trans,
				soilC.strlig[SOIL] );
	for (short iel = 0; iel < site.nelem; ++iel)
	{
	    trans = struce_ref (SRFC, iel) * parcp.cultra[5];
	    flows->Schedule (&struce_ref (SRFC, iel), &struce_ref (SOIL, iel),
		   		st->time, trans);
	}
    }
    // Metabolic
    trans = soilC.metabc[SRFC] * parcp.cultra[5];
    if (trans > 0.0f)
    {
	ScheduleCFlow ( st->time, trans,
			metcis_ref (SRFC,LABELD) / soilC.metabc[SRFC], 1.0f,
			&metcis_ref (SRFC,UNLABL), &metcis_ref (SOIL,UNLABL),
			&metcis_ref (SRFC,LABELD), &metcis_ref (SOIL,LABELD),
			accum );
	for (short iel = 0; iel < site.nelem; ++iel)
	{
	    trans = metabe_ref (SRFC, iel) * parcp.cultra[5];
	    flows->Schedule (&metabe_ref (SRFC, iel), &metabe_ref (SOIL, iel),
		   		st->time, trans);
	}
    }

    //--- Surface SOM1
    trans = soilC.som1c[SRFC] * parcp.cultra[5];
    if (trans > 0.0f)
    {
	ScheduleCFlow ( st->time, trans,
		som1ci_ref (SRFC,LABELD) / soilC.som1c[SRFC], 1.0f,
		&som1ci_ref (SRFC,UNLABL), &som1ci_ref (SOIL,UNLABL),
		&som1ci_ref (SRFC,LABELD), &som1ci_ref (SOIL,LABELD),
		accum );
	for (short iel = 0; iel < site.nelem; ++iel)
	{
	    trans = som1e_ref (SRFC, iel) * parcp.cultra[5];
	    flows->Schedule (&som1e_ref (SRFC, iel), &som1e_ref (SOIL, iel),
	    	  st->time, trans);
	}
    }

    //--- Some standing dead goes to the top soil layer.
    if (cropC.stdedc > 0.0f)
    {
	register float tsdsoi = cropC.stdedc * parcp.cultra[4];
	float const fr14 = cropC.stdcis[1] / cropC.stdedc;
	PartitionResidue (tsdsoi, recres, SOIL, cropC.stdcis, nps.stdede,
			  comput.pltlig[ABOVE], fr14);
    }

    //--- Some above ground live goes into surface litter
    if (cropC.aglivc > 0.0f)
    {
	register float tagsfc = cropC.aglivc * parcp.cultra[1];
	for (short iel = 0; iel < site.nelem; ++iel)
	    recres[iel] = nps.aglive[iel] / cropC.aglivc;
	float const fr14 = cropC.aglcis[LABELD] / cropC.aglivc;
	PartitionResidue (tagsfc, recres, SRFC, cropC.aglcis, nps.aglive,
			  comput.pltlig[ABOVE], fr14);
    }

    //--- Some storage pool goes to metabolic surface pool
    if (cropC.aglivc > 0.0f)
    {
	for (short iel = 0; iel < site.nelem; ++iel)
	{
	    trans = nps.crpstg[iel] * parcp.cultra[1];
	    flows->Schedule (&nps.crpstg[iel], &metabe_ref (SRFC, iel),
	    		    st->time, trans);
	}
    }

    //--- Some above ground live goes to the top soil layer.
    if (cropC.aglivc > 0.0f)
    {
	register float tagsoi = cropC.aglivc * parcp.cultra[2];
	float const fr14 = cropC.aglcis[LABELD] / cropC.aglivc;
	PartitionResidue (tagsoi, recres, SOIL, cropC.aglcis, nps.aglive,
			  comput.pltlig[ABOVE], fr14);
    }

    //--- Some storage pool goes to metabolic soil pool
    if (cropC.aglivc > 0.0f)
    {
	for (short iel = 0; iel < site.nelem; ++iel)
	{
	    trans = nps.crpstg[iel] * parcp.cultra[2];
	    flows->Schedule (&nps.crpstg[iel], &metabe_ref (SOIL, iel),
	    		    st->time, trans);
	}
    }

    //--- Live roots go to the top soil layer.
    if (cropC.bglivc > 0.0f)
    {
	register float tbgsoi = cropC.bglivc * parcp.cultra[6];
	for (short iel = 0; iel < site.nelem; ++iel)
	    recres[iel] = nps.bglive[iel] / cropC.bglivc;
        float mRespStorageFractionRemoved = tbgsoi / cropC.bglivc;
	float const fr14 = cropC.bglcis[LABELD] / cropC.bglivc;
	PartitionResidue (tbgsoi, recres, SOIL, cropC.bglcis, nps.bglive,
			  comput.pltlig[BELOW], fr14);

        // When live roots die, a proportional amount of the maintenance
        // respiration storage carbon pool flows to the same destination
        // as the roots.

        float const mRespStorage =
        	gpp.mRespStorageCrop[UNLABL] + gpp.mRespStorageCrop[LABELD];
        float const mRespStorageLoss =
        	mRespStorageFractionRemoved * mRespStorage;
        float accum[ISOS] =	{ 0.0f, 0.0f }; 	// accumulator
        Assert (gpp.mRespStorageCrop[UNLABL] >= 0.0);
        Assert (gpp.mRespStorageCrop[LABELD] >= 0.0);
        ScheduleCFlow ( st->time, mRespStorageLoss,
        	gpp.mRespStorageCrop[LABELD] / mRespStorage, 1.0f,
		&gpp.mRespStorageCrop[UNLABL], &metcis_ref (SOIL, UNLABL),
		&gpp.mRespStorageCrop[LABELD], &metcis_ref (SOIL, LABELD),
		accum );
        //cropC.cinput += accum[UNLABL] + accum[LABELD];  // need this?
    }

    //--- Some above ground live goes to standing dead
    trans = cropC.aglivc * parcp.cultra[0];
    if (trans > 0.0f)
    {
	ScheduleCFlow ( st->time, trans,
			cropC.aglcis[LABELD] / cropC.aglivc, 1.0f,
			&cropC.aglcis[UNLABL], &cropC.stdcis[UNLABL],
		 	&cropC.aglcis[LABELD], &cropC.stdcis[LABELD],
		 	accum );
	for (short element = 0; element < site.nelem; ++element)
	{
	    trans = nps.aglive[element] * parcp.cultra[0];
	    flows->Schedule (&nps.aglive[element], &nps.stdede[element],
	    			st->time, trans);
	}
    }

    //--- Modify the physical soil due to disturbance.
    // The depth of homogenization is proportional to the degree of
    // disturbance, based upon the intensity of the cultivation factor
    // for decomposition.
    // Also, allow clteff to be > 1.6 (CLTEFF_MAX), but limit the mean to
    // CLTEFF_MAX for the purposes of calc'ing homogenize depth.

    /*   original version assummed CLTEFF_MAX ~ 1.6, but now == 10, so...
    float const meanCFD = 				  // mean of factor
	std::min (::Sum (parcp.clteff, 4) / 4.0f, CLTEFF_MAX);
    Assert (meanCFD >= CLTEFF_MIN);
    //Assert (meanCFD <= CLTEFF_MAX);
    if ( meanCFD > CLTEFF_MIN )				// anything to do?
    {
	float const homogenDepth = wt.simDepth *
			(meanCFD - CLTEFF_MIN) / (CLTEFF_MAX - CLTEFF_MIN);
	soil->Homogenize (0.0f, homogenDepth);
	UpdateFromTexture ();	// update dependencies on soil texture
	UpdateFromSoilWater ();	// update dependencies on SOM and soil water
    }
    */

    float meanCFD = ::Sum (parcp.clteff, 4) / 4.0f;	  // mean of factor
    const float ACTUAL_CLTEFF_MAX = (meanCFD > 1.6f ? CLTEFF_MAX : 1.6);
    meanCFD = std::min (meanCFD, ACTUAL_CLTEFF_MAX);
    Assert (meanCFD >= CLTEFF_MIN);
    if ( meanCFD > CLTEFF_MIN )				// anything to do?
    {
	float const homogenDepth = wt.simDepth *
		(meanCFD - CLTEFF_MIN) / (ACTUAL_CLTEFF_MAX - CLTEFF_MIN);
	soil->Homogenize (0.0f, homogenDepth);
	water.UpdateRootingDepth (*soil);
	UpdateFromTexture ();	// update dependencies on soil texture
	UpdateFromSoilWater ();	// update dependencies on SOM and soil water
    }
}

// --- end of file ---

