
/*              Copyright 1998 Colorado State University     */
/*                      All Rights Reserved                  */

#include <stdlib.h>
#include <stdio.h>
#include "netcdf.h"

/* Externally defined variables */
extern int GeogNcid;
extern size_t maskRows, maskCols;

void handle_error(char *funcname, int status);

/* Global variables */
short *mask;

/* Compute a new mask by replacing the 1's in the Geog mask with cellNo */
void
Mask2Cell()
{
    int i, j;
    size_t start[2] = {0, 0};
    size_t count[2] = {1, 1}; 
    int cellNo = 1;
    int maskid;
    int status;
    short *p;
/*    int icell; */

    /* Allocate space to hold mask with cell numbers */
    mask = calloc(maskRows * maskCols, sizeof(short));
    p = mask;

    /* Set count length to number of columns */
    count[1] = maskCols;

/*    printf("Mask2Cell: GeogNcid = %d\n", GeogNcid); */

    /* Get NetCDF variable ID for mask variable */
    status = nc_inq_varid(GeogNcid, "mask", &maskid);
    if (status != NC_NOERR) handle_error("nc_inq_varid(mask)", status);

    for (i = 0; i < maskRows; i++)
    {
	start[0] = i;

	/* Count number of active cells */
	status = nc_get_vara_short(GeogNcid, maskid, start, count, p);
        if (status != NC_NOERR) handle_error("nc_get_vara_short(geog mask)", status);

	for ( j = 0; j < maskCols; j++)
	{
/*            icell = i*maskCols + j; 
            printf("Mask2Cell: mask[%1d] = %1d\n", icell, mask[icell]); */
	    if (*p == 1) {
               *p = cellNo++;
            }
	    p++;
	}
    }

    return;
}
