#ifndef INC_TMgmtSchedule_h
#define INC_TMgmtSchedule_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TMgmtSchedule.h
//	Class:	  TMgmtSchedule
//
//	Description:
//	Classes for management scheduling.
//	Responsibilities:
//	* Manage and access management scheduling.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, July 2002
//	History:
//	Jul02	Tom Hilinski
//	* Rebuilt both TActions and TSchedule to
//	  (1) centralize scheduling
//	  (2) add more members to check upon events
//	  (3) add "Cancel" an event function.
//	* Renamed TSchedule to TMgmtSchedule.
//	* "TActions actions" is now private to TMgmtSchedule.
//	* Affected mostly TCentury/TDayCent::rdblock.cpp and schedl.cpp
//	* TCentury/TDayCent members "activeBlock" and "activeInstance"
//	  move to here.
// ----------------------------------------------------------------------------

#include "centconsts.h"
#include "TManagement.h"
#include "TSharedPtr.h"
#include <cstring>

//	------------------------------------------------------------
//	TActions
//	Flags for event scheduling action events.
class TActions
{
  public:
	//--- constructor
	TActions ()
    	  { Initialize (); }

	//--- data
	bool flags[ET_EndOfList];		// true if action triggered
	TManagementEvent const *
		currentEvent[ET_EndOfList];	// pointer to event
	bool fireType[NUMSYS];			// type of fire system

	//---- operator overloads
	TActions& operator= (TActions const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	      bool const * pSrc = object.flags;
	      bool * pDest = flags;
	      for ( short i = 0;
	            i < (short)ET_EndOfList;
	            ++i, ++pSrc, ++pDest )
	      {
		*pDest = *pSrc;
	      }
	      for ( short i = 0; i < (short)NUMSYS; ++i )
	      	fireType[i] = object.fireType[i];
	    }
	    return *this;
	  }

	//--- functions
	void Clear ()
	  {
	    Initialize ();
	  }
	void ClearFire ()
	  {
	    for ( short i = 0; i < (short)NUMSYS; ++i )
		fireType[i] = false;
	  }
	void Initialize ()
	  {
	    bool * pFlags = flags;
	    TManagementEvent const ** pCurrentEvent = currentEvent;
	    for ( short i = 0;
	    	  i < (short)ET_EndOfList;
	    	  ++i, ++pFlags, ++pCurrentEvent )
	    {
		*pFlags = false;
		*pCurrentEvent = 0;
	    }
	    ClearFire ();
	  }
};

//	------------------------------------------------------------
//	TMgmtSchedule
//	Holds information regarding events in the active block.
class TMgmtSchedule
{
  public:
	//--- types
	typedef TSharedPtr<TManagementScheme const>		TMgmtPtr;

	//--- data
	short currentEventIndex;	// current index to event array
	char
    	  curCrop[6],	// current crop name
    	  curTree[6],	// current tree name
    	  curCult[6],	// current option string for cultivation
	  curFert[6],	// current option string for fertilization
	  curFire[6],	// current option string for fire
	  curGraz[6],	// current option string for grazing
	  curHarv[6],	// current option string for harvest
	  curIrri[6],	// current option string for irrigation
	  curOMAd[6],	// current option string for org. matter addition
	  curTRem[6];	// current option string for tree removal

	//--- constructor
	TMgmtSchedule (
	  TMgmtPtr & useMgmt)		// management scheme
	  : mgmt (useMgmt)
	  {
      		Initialize ();
	  }
	virtual ~TMgmtSchedule ()
	  {
	  }
	TMgmtSchedule (TMgmtSchedule const & object)  // copy constructor
	  : mgmt (object.mgmt)
	  {
	    Copy (object);
	  }

	//---- operator overloads
	TMgmtSchedule& operator= (TMgmtSchedule const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
		Copy (object);
	    }
	    return *this;
	  }

	//--- functions
	void SetActiveBlock (				// Set the active block
	  TManagementBlock const * const useActiveBlock) // from this block
	  { activeBlock = useActiveBlock; }
	TManagementBlock const * const GetActiveBlock (	// Get the active block
	  ) const
	  { return activeBlock; }
	void SetActiveInstance (			// Set active instance
	  TManagementInst const * const useActiveInstance) // from this instance
	  { activeInstance = useActiveInstance; }
	TManagementInst const * const GetActiveInstance ( // Get active instance
	  ) const
	  { return activeInstance; }
	TActions & Actions () 			// Access the actions
	  { return actions; }
	bool HaveEventScheduled (		// true if have event scheduled
	  TEventType thisEventType)		//   of this type
	  {
	    return actions.flags[thisEventType] == true;
	  }
	void CancelScheduledEvent (		// Cancel an event scheduled
	  TEventType thisEventType)		//   of this type
	  {
	    actions.flags[thisEventType] = false;
	    if ( thisEventType == ET_Fire )
	    {
		actions.ClearFire ();
		*curFire = '\0';
	    }
	  }
	bool DoingCultivation () const
	  { return actions.flags[ET_Cultivate]; }
	bool DoingFertilization () const
	  { return actions.flags[ET_Fertilize]; }
	bool DoingFire () const
	  { return actions.flags[ET_Fire]; }
	bool DoingCropGrassFire () const
	  { return actions.fireType[CRPSYS]; }
	bool DoingForestFire () const
	  { return actions.fireType[FORSYS]; }
	bool DoingSavannaFire () const
	  { return actions.fireType[SAVSYS]; }
	bool DoingGrazing () const
	  { return actions.flags[ET_Graze]; }
	bool DoingHarvest () const
	  { return actions.flags[ET_Harvest]; }
	bool DoingIrrigation () const
	  { return actions.flags[ET_Irrigate]; }
	bool DoingOMAddition () const
	  { return actions.flags[ET_AddOM]; }
	bool DoingTreeRemoval () const
	  { return actions.flags[ET_TreeRemoval]; }
	bool DoingPlanting () const
	  { return actions.flags[ET_Plant]; }
	bool DoingStartCropGrassGrowth () const
	  { return actions.flags[ET_StartCrop]; }
	bool EndCropGrassGrowth () const
	  { return actions.flags[ET_EndCrop]; }
	bool DoingSenescence () const
	  { return actions.flags[ET_Senesce]; }
	bool DoingStartTreeGrowth () const
	  { return actions.flags[ET_StartTree]; }
	bool DoingEndTreeGrowth () const
	  { return actions.flags[ET_EndTree]; }
	bool DoingErosion () const
	  { return actions.flags[ET_Erosion]; }
	bool DoingDeposition () const
	  { return actions.flags[ET_Deposition]; }
	bool HaveExternalEvent () const
	  { return actions.flags[ET_External]; }
	void Clear ()
	  {
	    Initialize ();
	  }
	void Initialize ()
	  {
		activeBlock = 0;
		activeInstance = 0;
		actions.Clear ();
		currentEventIndex = (short)0;
		*curCrop = *curTree =*curCult = *curFert = *curFire =
		  *curGraz = *curHarv = *curIrri = *curOMAd = *curTRem = '\0';
	  }
	bool IsEmpty ()
	  {
	    return ( activeBlock == 0 ? true :
	    		activeBlock->GetEventCount() == 0 );
	  }

  private:
	//--- data
	TMgmtPtr mgmt;				// management scheme
	TManagementBlock const * activeBlock;	// current block
	TManagementInst const * activeInstance;	// the active mgmt instance
	TActions actions;			// actions currently scheduled

	//--- functions
	void Copy (TMgmtSchedule const & object)	// Copy to this
	  {
	    if ( &object )
	    {
		currentEventIndex = object.currentEventIndex;
		activeBlock = object.activeBlock;
		activeInstance = object.activeInstance;
		actions = object.actions;
		if ( *object.curCrop )
			std::strncpy ( curCrop, object.curCrop, 6);
		if ( *object.curTree )
			std::strncpy ( curTree, object.curTree, 6);
		if ( *object.curCult )
			std::strncpy ( curCult, object.curCult, 6);
		if ( *object.curFert )
			std::strncpy ( curFert, object.curFert, 6);
		if ( *object.curFire )
			std::strncpy ( curFire, object.curFire, 6);
		if ( *object.curGraz )
			std::strncpy ( curGraz, object.curGraz, 6);
		if ( *object.curHarv )
			std::strncpy ( curHarv, object.curHarv, 6);
		if ( *object.curIrri )
			std::strncpy ( curIrri, object.curIrri, 6);
		if ( *object.curOMAd )
			std::strncpy ( curOMAd, object.curOMAd, 6);
		if ( *object.curTRem )
			std::strncpy ( curTRem, object.curTRem, 6);
	    }
	  }
};

#endif // INC_TMgmtSchedule_h
