#ifndef INC_constants_h
#define INC_constants_h

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  constants.h
//
//	Description:
//	Contains constants common to the various parts of the Century project.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Nov97
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

extern char const * const eventName[];		// Array of event name strings
//	Array of event description strings associated with eventName[]
extern char const * const eventDescrip[];
//	Descriptive strings of the output file format choices.
//	Order must match TOutputBase::TOutputType.
extern char const * const oFFDescrip[];

#endif // INC_constants_h
