// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  pschem.cpp
//	Class:	  TCentury
//	Function: PSDecompChemistry
//
//	Description:
//	Calculates the P and S chemistry for  decomposition flows.
// ----------------------------------------------------------------------------
//	History:
//	6/91	McKeown
//	These calculations were removed from
//	the DECOMP subroutine, and slightly modified to include the
//	calculation for the fraction of mineral P in solution.  Also
//	removed the flow from secondary to parent material.
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include "TCenturyMath.h"

void TCentury::PSDecompChemistry (
	float const dtm)	// time step (years)
{
    Assert (site.nelem > 1);
    for (short element = P; element < site.nelem; ++element)
    {
	// Determine the fraction of mineral P in solution
	float fractionInSolution;
	if (element == P)
	    fractionInSolution = FractionMinPInSolution ();
	else
	    fractionInSolution = 1.0f;

	// Flow from parent material to mineral compartment.
	// Soil Texture may affect weathering of Phosophorus.
	// This calculation is actually done in prelim, it is
	// shown here for clarity.
	//   if ((element .eq. P) .and. (texepp(1) .eq. 1.0)) then
	//     Include effect of texture
	//     textur = clay + silt
	//     Weathering factor should be per year
	//     wfact = 12.0 * atanf(textur, texepp(2), texepp(3),
	//    +                             texepp(4), texepp(5))
	//   else
	//     wfact = pparmn(element)
	//   endif
	float amount =
		fixed.pparmn[element] * nps.parent[element] * wt.defac * dtm;
	flows->Schedule (&nps.parent[element], &minerl_ref (SRFC, element),
			st->time, amount);

	// Flow from secondary to mineral compartment.
	// Soil texture may affect mineralization of secondary P.
	// This calculation is actually done in prelim, it is
	// shown here for clarity.
	//   if ((element .eq. P) .and. (texesp(1) .eq. 1.0)) then
	//     Include effect of texture
	//     wfact = 12.0 * (texesp(2) + texesp(3) * sand)
	//   else
	//     wfact = psecmn(element)
	//   endif
	amount = fixed.psecmn[element] * nps.secndy[element] * wt.defac * dtm;
	flows->Schedule (&nps.secndy[element], &minerl_ref (SRFC, element),
			st->time, amount);

	// Flow from mineral to secondary
	short const numLayers = MELoopLimit ();	// loop limit
	for (short layer = 0; layer < numLayers; ++layer)
	{
	    amount = fixed.pmnsec[element] * minerl_ref (layer, element) *
			(1.0 - fractionInSolution) * wt.defac * dtm;
	    flows->Schedule (&minerl_ref (layer, element), &nps.secndy[element],
	    		    st->time, amount);
	}
    }
    // Flow from secondary Phosophorus to occluded Phosophorus.
    float const amount = fixed.psecoc * nps.secndy[P] * wt.defac * dtm;
    flows->Schedule (&nps.secndy[P], &nps.occlud, st->time, amount);
}

//--- end of file ---
