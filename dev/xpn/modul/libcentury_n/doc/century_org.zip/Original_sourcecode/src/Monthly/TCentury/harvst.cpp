// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  harvst.cpp
//	Class:	  TCentury
//	Function: HarvestCrop
//
//	Description:
//	Harvest the current crop.
// ----------------------------------------------------------------------------
//	History:
//	Oct98	Tom Hilinski, tom.hilinski@colostate.edu
//	* Removed statement which reset the water content at the drainage layer.
//      Jul02   Melannie Hartman, melannie@nrel.colostate.edu
//      * Adjusted nps.volpl and nps.volpla calculations.
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include <cmath>

void TCentury::HarvestCrop (
	short const month,	// current month
	float const *pltlig)	// array [2]:
{
    // Check that there is material to harvest
    if (cropC.aglivc < 0.001f)
    {
	// empty pools and return
	cropC.cgrain = cropC.crmvst = 0.0f;
	for (short e = 0; e < site.nelem; ++e)
	    nps.egrain[e] = nps.ermvst[e] = 0.0f;
	return;
    }

    // Carbon
    // Grain
    // (Alister's new way of calculating:)
    cropC.hi = 0.0f;
    if (parcp.flghrv == 1)
    {
    	short hmonth[2];
	float sumtran = 0.0f;
	float sumpttr = 0.0f;
	for ( short i = 0; i < 2; i++ )
	{
 		hmonth[i] = month - parcp.himon[i];
		if (hmonth[i] < 1)
			hmonth[i] += MPY;
	}
	if (hmonth[1] >= hmonth[0])
	{
	    for (short m = hmonth[0]; m <= hmonth[1]; ++m)
	    {
		sumtran += param.htran[m];
		sumpttr += param.hpttr[m];
	    }
	}
	else
	{
	    for (short m = hmonth[0]; m < MPY; ++m)
	    {
		sumtran += param.htran[m];
		sumpttr += param.hpttr[m];
	    }
	    for (short m = 0; m < hmonth[1]; ++m)
	    {
		sumtran += param.htran[m];
		sumpttr += param.hpttr[m];
	    }
	}
	Assert (AmountIsSignificant(sumpttr));
	cropC.hi = parcp.himax *
			(1.0f - parcp.hiwsf * (1.0f - sumtran / sumpttr));
	cropC.cgrain = cropC.hi * cropC.aglivc * (1.0f - parcp.aglrem);
	ScheduleCFlow ( st->time, cropC.cgrain,
    		cropC.aglcis[LABELD] / cropC.aglivc, 1.0f,
		&cropC.aglcis[UNLABL], &soilC.csrsnk[UNLABL],
		&cropC.aglcis[LABELD], &soilC.csrsnk[LABELD],
		cropC.cisgra);
    }

    // Straw
    float const cstraw = cropC.aglivc * (1.0f - parcp.aglrem) - cropC.cgrain;
    // Straw removal
    cropC.crmvst = parcp.rmvstr * cstraw;
    cropC.accrst += cropC.crmvst;
    float accum[ISOS] = { 0.0, 0.0 };			// accumulator
    ScheduleCFlow ( st->time, cropC.crmvst,
    	cropC.aglcis[LABELD] / cropC.aglivc, 1.0f,
	&cropC.aglcis[UNLABL], &soilC.csrsnk[UNLABL],
	&cropC.aglcis[LABELD], &soilC.csrsnk[LABELD],
	accum);
    // Some straw will remain as standing dead
    float const addsdc = parcp.remwsd * (cstraw - cropC.crmvst);
    ScheduleCFlow ( st->time, addsdc,
	cropC.aglcis[LABELD] / cropC.aglivc, 1.0f,
    	&cropC.aglcis[UNLABL], &cropC.stdcis[UNLABL],
	&cropC.aglcis[LABELD], &cropC.stdcis[LABELD],
	accum);

    // Other elements
    float recres[NUMELEM];	// aboveground E:C
    for (short e = 0; e < site.nelem; ++e)
    {
	// Grain
	if (parcp.flghrv == 1)
	{
	    if (parcp.himax < 0.0001f)
		throw TCentException (
			TCentException::CE_PARMIV,
			"HarvestCrop - crop parameter HIMAX <= 0");
	    nps.egrain[e] = parcp.efrgrn[e] * nps.aglive[e] *
				(1.0f - parcp.aglrem) *
				std::sqrt (cropC.hi / parcp.himax);
	    flows->Schedule (&nps.aglive[e], &nps.esrsnk[e],
			    st->time, nps.egrain[e]);
	}
	else
	    nps.egrain[e] = 0.0f;

	if (e == N)
	{
	    // Volatilization of N from plants
            float const volatileLoss = parcp.vlossp * nps.aglive[e];
	    nps.volpl += volatileLoss;
	    nps.volpla += volatileLoss;
	    // N/C ratio in straw
	    Assert (AmountIsSignificant(cstraw));
	    recres[e] = ((nps.aglive[e] - volatileLoss) *
			  (1.0f - parcp.aglrem) - nps.egrain[e]) / cstraw;
	    flows->Schedule (&nps.aglive[e], &nps.esrsnk[e],
			    st->time, volatileLoss);
	}
	else
	{
	    // P/C, or S/C ratio in straw
	    Assert (AmountIsSignificant(cstraw));
	    recres[e] = (nps.aglive[e] * (1.0f - parcp.aglrem)
			       - nps.egrain[e]) / cstraw;
	}
	// Straw removal
	nps.ermvst[e] = cropC.crmvst * recres[e];
	flows->Schedule (&nps.aglive[e], &nps.esrsnk[e],
			st->time, nps.ermvst[e]);
	// Some straw remains as standing dead
	float const addsde = addsdc * recres[e];
	flows->Schedule (&nps.aglive[e], &nps.stdede[e], st->time, addsde);
    }

    // Partition c, n, p, and s in remaining straw into top layer
    // of structural and metabolic
    float const resid = cstraw - cropC.crmvst - addsdc;
    float const fr14 = std::max (0.0f, cropC.aglcis[LABELD] / cropC.aglivc);
    PartitionResidue (resid, recres, SRFC, cropC.aglcis, nps.aglive,
		      pltlig[ABOVE], fr14);

    // Below ground removal (root harvest) -lh 8/91
    if ( parcp.hibg > 0.0f )
    {
	float const ctubes = parcp.hibg * cropC.bglivc * (1.0f - parcp.bglrem);
	cropC.cgrain += ctubes;
	ScheduleCFlow ( st->time, ctubes,
			cropC.bglcis[LABELD] / cropC.bglivc, 1.0f,
    			&cropC.bglcis[UNLABL], &soilC.csrsnk[UNLABL],
			&cropC.bglcis[LABELD], &soilC.csrsnk[LABELD],
			cropC.cisgra);
	float cisbgd[ISOS];
	if ( AmountIsSignificant (cropC.bglivc) )
	{
		cisbgd[LABELD] =
			(cropC.bglivc * (1.0f - parcp.bglrem) - ctubes) *
			(cropC.bglcis[LABELD] / cropC.bglivc);
	}
	else
	{
		cisbgd[LABELD] = 0.0f;
	}
	cisbgd[UNLABL] =
		cropC.bglivc * (1.0f - parcp.bglrem) - ctubes - cisbgd[LABELD];

	float recres[NUMELEM];	// aboveground E:C
	for (short e = 0; e < site.nelem; ++e)
	{
	    float etubes = parcp.hibg * (1.0f - parcp.bglrem) * nps.bglive[e];
	    flows->Schedule (&nps.bglive[e], &nps.esrsnk[e], st->time, etubes);
	    nps.egrain[e] += etubes;
	    Assert (AmountIsSignificant (cropC.bglivc));
	    recres[e] = nps.bglive[e] / cropC.bglivc;
	    // Remove from crop storage as well
	    etubes = parcp.hibg * (1.0f - parcp.bglrem) * nps.crpstg[e];
	    flows->Schedule (&nps.bglive[e], &nps.esrsnk[e], st->time, etubes);
	}

	// Calculation of accumulator for grain production
	cropC.cgracc += cropC.cgrain;
	for (short e = 0; e < site.nelem; ++e)
		nps.egracc[e] += nps.egrain[e];

	// Partition c, n, p, and s in remaining roots into bottom layer of
	// structural and metabolic
	float const bgd = cisbgd[LABELD] + cisbgd[UNLABL];
	PartitionResidue (bgd, recres, SOIL, cropC.bglcis, nps.bglive,
			  pltlig[BELOW], fr14);
    }

    Update ();				// Update the flows and sums

    // Check status of carbon values to make sure that everything
    // has been reset correctly; if carbon = 0, reset elements to 0 as well
    if ( !AmountIsSignificant (cropC.aglcis[UNLABL] + cropC.aglcis[LABELD]) )
	cropC.aglcis[UNLABL] = cropC.aglcis[LABELD] = 0.0f;
    if (cropC.aglcis[UNLABL] + cropC.aglcis[LABELD] == 0.0f)
    {
	for (short e = 0; e < site.nelem; ++e)
	    nps.aglive[e] = 0.0f;
    }
    if ( !AmountIsSignificant (cropC.bglcis[UNLABL] + cropC.bglcis[LABELD]) )
	cropC.bglcis[UNLABL] = cropC.bglcis[LABELD] = 0.0f;
    if (cropC.bglcis[UNLABL] + cropC.bglcis[LABELD] == 0.0f)
    {
	for (short e = 0; e < site.nelem; ++e)
	    nps.bglive[e] = 0.0f;
    }
    if ( !AmountIsSignificant (cropC.stdcis[UNLABL] + cropC.stdcis[LABELD]) )
	cropC.stdcis[UNLABL] = cropC.stdcis[LABELD] = 0.0f;
    if (cropC.stdcis[UNLABL] + cropC.stdcis[LABELD] == 0.0f)
    {
	for (short e = 0; e < site.nelem; ++e)
	    nps.stdede[e] = 0.0f;
    }

    // limit pool sizes
    for (short e = 0; e < site.nelem; ++e)
    {
	if ( !AmountIsSignificant (nps.aglive[e]) )
	    nps.aglive[e] = 0.0f;
	if ( !AmountIsSignificant (nps.bglive[e]) )
	    nps.bglive[e] = 0.0f;
	if ( !AmountIsSignificant (nps.stdede[e]) )
	    nps.stdede[e] = 0.0f;
    }
}	// HarvestCrop
