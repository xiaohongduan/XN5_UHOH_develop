#ifndef INC_nrel_dcirc_TCenturySiteMgmtPairs_h
#define INC_nrel_dcirc_TCenturySiteMgmtPairs_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC
//	File:	  TCenturySiteMgmtPairs.h
//	Class:	  TCenturySiteMgmtPairs
//
//	Description:
//	Class for file input of site-mgmt. paired file names
//	for the Century models.
//	Responsibilities:
//	* Knowing the pairs file name.
//	* Reading in the file at construction.
//	* Being a singleton.
//	* Providing public interface to the file name pairs.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, June 2002
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------
//	Notes:
//	* Expects the file name pairs to be whitespace-delimited.
//	* Does not currently extract file names/paths with whitespace
//	  (later we can use the Boost::tokenizer to handle this better.)
//	* Does not currently check for validity and existance of files
//	  specified in the pair (later we can use TEH::TFileName to do this.)
// ----------------------------------------------------------------------------

#include <utility>
#include <string>
#include <vector>

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class TCenturySiteMgmtPairs
{
  public:
	//---- types
	typedef	std::string				TSiteFileName;
	typedef	std::string				TMgmtFileName;
	typedef std::pair<TSiteFileName, TMgmtFileName>	TFileNamePair;
	typedef	std::vector<TFileNamePair>		TListOfPairs;

	//---- constructors and destructor
	TCenturySiteMgmtPairs (
	  std::string const & fileName)		// read from this file
	  {
	    Initialize ();
	    if ( ReadPairsFile (fileName) )
	    {
		// To Do: handle read failure
	    }
	  }
	~TCenturySiteMgmtPairs ()
	  {
	    Clear ();
	  }
	TCenturySiteMgmtPairs (			// copy constructor
	  TCenturySiteMgmtPairs const & object)
	  {
	    Initialize ();
	    Copy (object);
	  }

	//---- operator overloads

	//---- functions
	unsigned int NumberOfPairs () const	// number of pairs in list
	  { return list.size(); }
	TFileNamePair const & GetPair (		// Get file name pair
	  unsigned int index)			//   at this index
	  { return list.at (index); }
	void Clear ()					// "Clear" data members
	  {
	    list.clear ();
	  }

	//---- functions: Queries
	bool IsEmpty () const				// True if no data
	  {
	    return list.empty();
	  }

  protected:
	//---- constants

	//---- data
	TListOfPairs list;			// list of file name pairs

	//---- functions
	bool ReadPairsFile (			// Read site/mgmt pairs
	  std::string const & fileName);	//   from this file

  private:
	//---- constants

	//---- data

	//---- functions
	void Initialize ()				// Initialize members
	  {
	  }
	void Copy (					// Copy to this
	  TCenturySiteMgmtPairs const & object)
	  {
	    if ( &object )
	    {
	    	if ( object.list.size() > 0 )
	    		list = object.list;
	    }
	  }
};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_TCenturySiteMgmtPairs_h
