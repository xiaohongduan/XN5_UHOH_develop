#ifndef INC_nrel_dcirc_IRCUtil_h
#define INC_nrel_dcirc_IRCUtil_h

// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  IRCUtil.h
//
//	Description:
//	Utility functions for DayCentIRC and the Grid-Cohort Framework.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, June 2005
//	History:
// ----------------------------------------------------------------------------

#include "DayCentIRCTypes.h"
#include "INIData.h"

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

//	ToOutputVariablesConfig
//	Convert values from an INI record to output variables configuration.
//	Returns false if successful, else true if error.
bool ToOutputVariablesConfig (
	::nrel::ini::INIData::Values const & values,
	TOutputVarConfig & config);

//	FromOutputVariablesConfig
//	Convert output variables configuration to an INI values list.
//	Returns false if successful, else true if error.
bool FromOutputVariablesConfig (
	TOutputVarConfig const & config,
	::nrel::ini::INIData::Values & values);


  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_IRCUtil_h
