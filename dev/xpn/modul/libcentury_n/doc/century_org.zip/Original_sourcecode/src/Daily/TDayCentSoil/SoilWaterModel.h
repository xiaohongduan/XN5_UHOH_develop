#ifndef INC_SoilWaterModel_h
#define INC_SoilWaterModel_h
// ----------------------------------------------------------------------------
//	Copyright 1999-2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model, daily version
//	File:     SoilWaterModel.h
//	Class:    SoilWaterModel
//
//	Description:
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec99
//		Melannie Hartman, melannie@nrel.colostate.edu (DayCent updates)
//	History:
// ----------------------------------------------------------------------------
//	Notes:
//	Partially extracted from class TDayCentSoil. Tom Hilinski, Nov2004.
// ----------------------------------------------------------------------------

#include <algorithm>
#include "TSoilProperty.h"
#include "arraytypes.h"

class SoilWaterModel
{
  public:
	SoilWaterModel ()
	  {
	  }
	~SoilWaterModel ()
	  {
	  }

	static float MinimumWaterPotential ()		// bars
	  { return minimumWaterPotentialBars; }
	static float MinimumTheta ()			// cm H2O
	  { return minimumTheta; }

	float HydraulicConductivity (	// Hydraulic conductivity (cm/sec)
	  float  const Ksat, 		//   saturated hydraulic cond. (cm/sec)
	  double const theta,		//   volumetric soilwater content (frac)
	  double const thetaSat,	//   saturated H2O content (vol. frac)
	  float  const soilTavg);	//   average soil temperature (deg C)
	float HydraulicConductivity (	// Hydraulic conductivity (cm/sec)
	  float  const Ksat,		//   saturated hydraulic cond. (cm/sec)
	  double const theta,		//   volumetric H2O content (frac)
	  double const thetaSat,	//   saturated vol. H2O content (frac)
	  float  const soilTavg,	//   average soil temperature (deg C)
	  float  const b);		//   slope of retention curve
	  				//    (Clapp & Hornberger)
	float SoilWaterPotential (	// Soil water potential (bars)
	  double const theta,		//   soil H2O (vol. fraction)
	  double const thetaSat,	//   saturated H2O (vol. fraction)
	  double const psiSat,		//   "saturation" matric potential (cm)
	  double const b);		//   slope of the retention curve
	void WaterEquation (		// Compute water content eq. parameters
	  TSoilProperty const & sand,	//   sand fraction
	  TSoilProperty const & clay,	//   clay fraction
	  T1DDoubleArray & thetaSat,	//   saturated volumetric water content
	  T1DDoubleArray & psiSat,	//   saturation matric potential (cm)
	  T1DDoubleArray & b);		//   slope of the retention curve
	void DrainToFieldCapacity (	// Drain soil layers to field capacity
	  T1DDoubleArray const & swcFieldCapacity, // swc at field cap (cm H2O)
	  T1DDoubleArray & swc,		//   soilwater content (cm H2O)
	  T1DFloatArray & amtTrans,	//   amount transferred next layer (cm)
	  double & drainageOut);	//   drainage out of soil profile (cm H2O)

	// Water-filled pore space
	float WFPS (			// H2O-filled pore space in layer (0-1)
	  float const bulkDensity,	//   bulk density (gm cm-3)
	  float const waterContent,	//   water constent (cm)
	  float const thickness		//   layer thickness (cm)
	  ) const
	  {
	    float const porosity = 1.0f - bulkDensity / PARTDENS;
	    float const waterFraction = waterContent / thickness;
	    // Assert (waterFraction <= porosity);
	    // assume that the water content is more correct than the
	    // porosity calc'd from PARTDENS (the latter is an approximation)
	    float const wfps = std::min(waterFraction / porosity, 1.0f);
	    return wfps;
	  }
	inline
	float ThetaAtSaturation (	// Saturated volumetric water content
	  float const sand,		// sand fraction
	  float const clay		// clay fraction
	  ) const
	  {
	    return ( -14.2f * sand - 3.7f * clay + 50.5f ) / 100.0f;
	  }

	//	CheckForImpedence
	//	Return true if turn on impedence.
	inline bool CheckForImpedence (
	  double const soilTemp,
	  double const poreSpace)
	{
	  return ( soilTemp < frozenSoilTemp &&
	  	   poreSpace < maximumFrozenPoreSpace );
	}


  protected:

  private:
	static float const PARTDENS;		// Particle Density (g/cm^3)
	static float const BAR2CM; 			// 1 bar = 1024 cm H2O
	static float const CM2BAR; 			// 1024 cm = 1 bar H2O
	static float const minimumWaterPotentialBars;	// min. potential (bars)
	static float const minimumTheta;		// min. theta (cm)
	static float const frozenSoilTemp;		// temp. soil freezes (deg C)
	static float const maximumFrozenPoreSpace;	// max pore space to freeze
	static float const MIN_FRZN_COND;	// min. hydraulic conductivity
						//  in frozen soil (cm/sec)



};

#endif // INC_SoilWaterModel_h
