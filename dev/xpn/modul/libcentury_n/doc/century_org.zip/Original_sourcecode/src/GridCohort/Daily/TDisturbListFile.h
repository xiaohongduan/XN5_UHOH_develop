#ifndef INC_nrel_dcirc_TDisturbListFile_h
#define INC_nrel_dcirc_TDisturbListFile_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  TDisturbListFile.h
//	Class:	  TDisturbListFile
//
//	Description:
//	Class which reads an agricultural cohort file, and provides access
//	to the data.
//
//	Responsibilities:
//	* Reads the agricultural cohort file.
//	* Provides a public interface to access the data.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, July 2003
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TFileStream.h"
#include "TDisturbanceList.h"

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class TDisturbListFile
	: public ::nrel::io::TFileStream
{
  public:
	//---- types
	typedef TDisturbanceList::size_type	size_type;

	//---- constructors and destructor
	TDisturbListFile (
	  TDisturbanceList & useList,		// list of disturbance events
	  std::string const & useFileName,	// name of disturbance file
	  TAccess const useAccess =		// Allowed access
		Access_ReadWrite)
	  : ::nrel::io::TFileStream (useFileName, DevImp_CSV, useAccess),
	    disturbanceList (useList)
	  {
	  }
	~TDisturbListFile ()
	  {
	  }
	TDisturbListFile (
	  TDisturbListFile const & object)
	  : ::nrel::io::TFileStream (object),
	    disturbanceList (object.disturbanceList)
	  {
	  }

	//---- operator overloads

	//---- functions
	size_type Read ();			// Read the disturbance file
						//   Return number of
						//   disturbance records read.
	size_type Write ();			// Write the disturbance file
						//   Return number of
						//   records written.
	TDisturbanceList const & GetList (	// Get disturbance list
	  ) const
	  { return disturbanceList; }

	//---- functions: Queries

  protected:
	//---- constants

	//---- data

	//---- functions

  private:
	//---- constants

	//---- data
	TDisturbanceList & disturbanceList;	// list of disturbances

	//---- functions
	bool Extract (					// Get event
	  std::string const & record,			//   from text line
	  ScheduledDisturbanceEvent & disturbEvent);	//   store in struct
	bool IsComment (			// True if a comment char
	  char const * const s
	  ) const
	  {
	    return *s == '#' || *s == '!' || *s == ';' ||
	    	(*s == '/' && *(s + 1) == '/');
	  }
};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_TDisturbListFile_h
