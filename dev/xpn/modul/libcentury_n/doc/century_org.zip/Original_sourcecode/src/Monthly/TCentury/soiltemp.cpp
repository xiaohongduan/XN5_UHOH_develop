// ----------------------------------------------------------------------------
//	Copyright 2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  soiltemp.cpp
//	Class:	  TCentury
//	Function: SoilTemperatureModel
//
//	Description:
//	Things to do at the end of the simulation year.
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------

#include "TCentury.h"

void TCentury::SoilTemperatureModel (
	short const month)	// simulation month (1-12)
{
    // Code introduced with POTSDAM 11/95 -rm
    if ( !SimMicrocosm() )
    {
	if (wt.snow > 0.0f)		// Added check for snow  -rm 8/91
		wt.stemp = 0.0f;	// Average surface temperature
	// Calc a "lagged temp. effect", needed because
	// deeper soil layers warm or cool slower than the air temperature.
	// NOTE: This is very simplistic soil temperature model.
	// This should be replaced with a proper soil temperature model.
	float prevMoAvgTemp;	// previous month's avg. air temperature
	if ( month == 1 )					// January?
		prevMoAvgTemp = weather->MeanMonthlyTemp (12);	// use Dec mean
	else // use previous month's
		prevMoAvgTemp = weather->MeanMonthlyTemp (month-1);
	if ( wt.tave - prevMoAvgTemp > 2.0f )	// if warming significantly
		wt.stemp -= 2.0f;			// so soil temp < air
	else if ( prevMoAvgTemp - wt.tave > 2.0f )	// else cooling
		wt.stemp += 2.0f;			// so soil temp > air
    }
}

//--- end of soiltemp.cpp ---

