// ----------------------------------------------------------------------------
//    Copyright 1998-2000 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//    Project:  Century Soil Organic Matter Model, daily version
//    File:	rainflux.cpp
//    Class:	TDayCentSoil
//    Function: AddWaterToSoil
//
//    Description:
//    Add rain and snowmelt into the soil profile,
//    and run off what cannot infiltrate
//
//    Author: Melannie Hartman, Bill Parton
// ----------------------------------------------------------------------------
//    History:
//    Mar1996   Melannie Hartman, melannie@NREL.colostate.edu
//    * Created original rainflux.c for FORTRAN/C version of DayCent
//    Mar2001   Melannie Hartman, melannie@NREL.colostate.edu
//    * Translated rainflux.c to rainflux.cpp
//    13Jul01   Melannie Hartman, melannie@NREL.colostate.edu
//    * Added inter-layer flow (amtTrans[*]) update. This was
//      not previously acounted for in this routine.
//	Nov02   Tom Hilinski, tom.hilinski@colostate.edu
//	* Misc. clean up, const-correctness, optimization.
// ----------------------------------------------------------------------------
//    Class Members:
//      Ksat() -  saturated hydraulic conductivity by layer (cm/sec)
//      amtTrans[] - total net water flux thru the bottom of each layer
//        (cm/H2O, positive is downward, negative is upward).
// ----------------------------------------------------------------------------
//    Calls:
//      DrainToFieldCapacity()
// ----------------------------------------------------------------------------
//    Notes:
//    * Need better error handling? -mdh 5/25/01
// ----------------------------------------------------------------------------

#include "TDayCentException.h"
#include "TDayCentSoil.h"
#include <cmath>
#include <sstream>
using namespace std;

void TDayCentSoil::AddWaterToSoil (
    int const infiltTime,	// duration of rainfall/snowmelt event (hours)
    float const waterInput,	// amount of rain and snowmelt (cm)
    float const infiltCapacity,	// infilt. capacity of top layer (cm/sec)
    T1DFloatArray const & soilTempAvg,	// avg soil temperature by layer (deg C)
    T1DDoubleArray const & thetaSat,	// vol. swc at saturation (frac)
    T1DDoubleArray const & swcFieldCapacity, // swc at field cap (cm H2O)
    T1DDoubleArray & swc,		// soilwater content (cm H2O)
    double & cumTime,		// time elapsed to infiltrate water (sec)
    double & runoff,		// amount of water (rain or snowmelt) which did
				//   not infiltrate soil profile (cm)
    double & cumInfilt,		// amount of water that infiltrated (cm)
    double & drainageOut)	// drainage from bottom of soil profile (cm H2O)

{
    // Check input parameters
    Assert (infiltTime != 0);

    // initialize function parameters
    cumTime = 0.0;
    runoff = 0.0;
    cumInfilt = 0.0;

    if ( waterInput == 0.0 )			// anything to do?
    	return;					// ...no

    double const maxInfiltrationTime =
	static_cast<double>(infiltTime * SEC_PER_HOUR);
    // rate at which water is arriving (cm/sec)
    double const inputRate = waterInput / maxInfiltrationTime;

    // Initial infiltration rate (cm/sec)
    // The infiltration rate to layer "i" is the minimum of the infiltration
    // capacities of layers 0..i.
    bool impedance = false;	 	// false if layer frozen or impermeable
    double theta = swc(0) / thickness[0]; // vol. soilwater content (frac)
    double infiltrationRate;
    if ( soilWaterModel->CheckForImpedence (
    		soilTempAvg(0), (thetaSat(0) - theta) ) )
    {
	infiltrationRate = std::min (MIN_FRZN_COND, inputRate);
	impedance = true;
    }
    else if (inputRate > infiltCapacity)
	infiltrationRate = infiltCapacity;
    else
	infiltrationRate = inputRate;

    // initialize local variables
    double waterAvailable = waterInput;	// water input not infiltrated (cm)

    // fill each layer to saturation until water inputs are used, or time is up
    short layer = 0;
    while ( waterAvailable > 0.0 &&
	    layer < GetLayerCount() &&
	    cumTime < maxInfiltrationTime )
    {
	theta = swc(layer) / thickness[layer];
	// amount of water which could be added to
	//   a layer to bring it to saturation (cm).
	double const waterToSaturation =
		thetaSat(layer) * thickness[layer] - swc(layer);
	if ( soilWaterModel->CheckForImpedence (
		soilTempAvg(layer), (thetaSat(layer) - theta) ) )
	{
	    infiltrationRate = std::min (MIN_FRZN_COND, infiltrationRate);
	    impedance = true;
	 }
	else if (infiltrationRate > Ksat(layer))
	{
	  //  The layer can not absorb water at infiltration rate.
	  //  infiltration is now limited by this layer
	    infiltrationRate = Ksat(layer);
	}
	Assert (infiltrationRate > 0.0);

	// if the amount of water needed to bring the layer to saturation is
	// greater than the amount left to infiltrate...
	double waterIntoLayer;	// amount of water added to a layer (cm)
	double dt;		// time elapsed to add water to a layer (sec)
	if (waterToSaturation > waterAvailable)
	{
	    dt = waterAvailable / infiltrationRate;
	    if (cumTime + dt > maxInfiltrationTime)
		dt = maxInfiltrationTime - cumTime;
	    waterIntoLayer = dt * infiltrationRate;
	    waterAvailable -= waterIntoLayer;
	}

	// if the amount of water needed to bring the layer to saturation is
	// less than the amount left to infiltrate...
	else // waterAvailable >= waterToSaturation
	{
	    dt = waterToSaturation / infiltrationRate;
	    if ((cumTime + dt) > maxInfiltrationTime)
		dt = maxInfiltrationTime - cumTime;
	    waterIntoLayer = dt * infiltrationRate;
	    // runoff?
//	    if (layer == 0)
//	    {
//		// runoff += (inputRate - infiltrationRate) * dt;
//		runoff += waterAvailable - waterIntoLayer;
//		waterAvailable -= runoff;
//	    }
	    waterAvailable -= waterIntoLayer;
	}

	cumTime += dt;
	cumInfilt += waterIntoLayer;
	swc(layer) += waterIntoLayer;
	// Inter-layer flow should be accounted for. -mdh 7/13/01
	if (layer > 0)
	{
	    // water flow from layer above layer
	    amtTrans(layer - 1) += waterIntoLayer;
	}

        // Re-calculate impedence based on new soil water content of layer
        // -cindyk 9/18/00
	theta = swc(layer) / thickness[layer]; // vol. water content fraction
	impedance =
	    soilWaterModel->CheckForImpedence (
	    	soilTempAvg(layer), (thetaSat(layer) - theta) );

	layer++;
    }  // end while

    runoff += waterInput - cumInfilt;

    // Error checking

    // error check water balance
    double const wdiff = cumInfilt + runoff - waterInput;
    if (fabs(wdiff) > 1.0e-5)
    {
	ostringstream os;
	os << "rainflux water balance = " << wdiff
	   << "  cumInflit = " << cumInfilt
	   << "  runoff = "    << runoff
	   << "  waterInput = " << waterInput
	   << ends;
	ThrowDayCentException ( TDayCentException::DCE_SWMERR,
        			os.str().c_str() );
    }
    // error check time count
    double const tdiff = cumTime - maxInfiltrationTime;
    if (fabs(tdiff) > 1.0e-3)
    {
	if (layer != GetLayerCount())
	{
	    ostringstream os;
	    os << "rainflux time accumulation: "
	       << " seconds_rain = " << maxInfiltrationTime
	       << " cumtime = " << cumTime
	       << " tdiff = " << tdiff
	       << ends;
	    ThrowDayCentException ( TDayCentException::DCE_SWMERR,
        				os.str().c_str() );
	}
    }

    // Reset cumtime in case of floating point operations have
    // caused it to drift
    // cumTime = maxInfiltrationTime;

    // Now that all water has been added, drain each layer to field capacity
    // if there is no layer (frozen) impeding the flow. -mdh 7/16/96
    // Note: to allow soil to saturate, bypass call to DrainToFieldCapacity()

    if (!impedance)
    {
	soilWaterModel->DrainToFieldCapacity (
		swcFieldCapacity, swc, amtTrans, drainageOut);
    }
}

//--- end of file ---
