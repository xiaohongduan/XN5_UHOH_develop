#ifndef INC_TOutVarInfoBase_h
#define INC_TOutVarInfoBase_h
// ----------------------------------------------------------------------------
//	Copyright (c) 2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TOutVarInfoBase.h
//	Class:	  TOutVarInfoBase
//
//	Description:
//	Pure virtual base class for reading and storing names and
//	descriptions of the Century output variables from the netCDF file,
//	OutVarInfo,nc / OutVarInfo.cdl.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Oct01
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TFileName.h"

//	-----------------------------------------------------------------------
//	TOVICategory
// 	Which output variable category.
//	In derived classes:
//	(1) Add your variables' category names before numCategories.
//	(2) Un-comment numCategories as the last item.

enum TOVICategory
{
	// To Do: enum TOVICategory: make an expandable "inheritable" struct
#ifdef DAILY_CENTURY
	WaterTemp, SoilC, CropGrassC, ForestC, CO2, NPS,
        DailyWaterTemp, DailyTraceGas, DailyCFluxStore, numCategories
#else
	WaterTemp, SoilC, CropGrassC, ForestC, CO2, NPS, numCategories
#endif
};

// ----------------------------------------------------------------------------
//	TOutVarInfoBase
//	Contains the data describing individual parameters.
class TOutVarInfoBase
{
  public:
	//---- constructors and destructor
	TOutVarInfoBase ()				// default constructor
	  {
	    Initialize ();
	  }
	virtual ~TOutVarInfoBase ()
	  {
	  }

	//---- operator overloads

	//---- functions
	virtual short GetCategoryCount () const		// Get no. of categories
	  {
	    return (short)numCategories;
	  }
	char const** GetCategories () const		// Get categories
	  {
	    return const_cast<char const**>(categories);
	  }
	virtual char const** GetNameList (		// Get the name list
	  TOVICategory whichCategory) const = 0;
	virtual char const** GetDescList (		// Get descriptions
	  TOVICategory whichCategory) const = 0;
	virtual short GetListSize (			// Get list size
	  TOVICategory whichCategory) const = 0;

	//---- functions: Queries
	bool IsEmpty () const				// True if no data
	  { return (categories == 0); }

  protected:
	//---- constants

	//---- data
	// Note: Lists of names and descriptions are NULL-terminated.
	char **categories;		// Names of categories

	// Example names and description arrays:
	/*
	char **soilNames;		// list of parameter names
	char **soilDescs;		// list of parameter descriptions
	short soilCount;		// size of list
	*/

	//---- functions
	virtual bool ReadNamesDescs (			// Read names, desc's.
	  TEH::TFileName const & outVarDefsPath	//   from this file
	  ) = 0;
	virtual void Clear () = 0;			// "Clear" data members

  private:
	//---- constants

	//---- data

	//---- functions
	void Initialize ()				// Initialize members
	  {
	  }

	// The following should never be used:
	TOutVarInfoBase& operator= (TOutVarInfoBase const & object)
	  { return *this; }
	TOutVarInfoBase (
	  TOutVarInfoBase const & object)		// copy constructor
	  {
	  }
};

#endif // INC_TOutVarInfoBase_h
