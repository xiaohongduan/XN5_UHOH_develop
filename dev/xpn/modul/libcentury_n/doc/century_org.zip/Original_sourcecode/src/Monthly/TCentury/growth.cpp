// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  growth.cpp
//	Class:	  TCentury
//	Function: CropGrassGrowth
//
//	Description:
//	Simulate crop production for the month.
// ----------------------------------------------------------------------------
//	History:
//	Dec01   Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to use new mineral E pools.
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include <cmath>

void TCentury::CropGrassGrowth ()
{
    // Initialize monthly production and uptake variables
    float monthlyProduction[CPARTS] = { 0.0f, 0.0f };
    float uptake[12];	// was [EPOOLS][NUMELEM]
    float* pUptake = uptake;
    for ( short i = 0; i < 12; ++i, ++pUptake )
    	*pUptake = 0.0f;
#define uptake_ref(a_1,a_2)	uptake[(a_2)*EPOOLS + a_1]

    // Determine actual production values, restricting the C/E ratios
    if ( parcp.IsGrowing() &&
         potentProd.cropC > 0.0f &&
         !sched->DoingSenescence() )
    {
	// mineral available fractions
	float availableE[3];			// available N,P,S
	availableE[N] = nps.tminrl[N];
	if ( sysType.IsSavanna() )		// N in savana
	{
	    float const gNFraction =
		std::exp (
		    std::exp (-0.00102f *
			std::min (nps.tminrl[N], 1.5f) * site.sitpot ) *
		    -1.664f * parcp.basfc2 * param.trbasl );
	    // Bound gNFraction between 0 and 1
	    Assert (gNFraction >= 0.0f);
	    Assert (gNFraction <= 1.0f);
	    if ( gNFraction < 0.0f || gNFraction > 1.0f )
	    {
	    	// To Do: gnfrac - throw exception
		Assert (gNFraction >= 0.0f);
		Assert (gNFraction <= 1.0f);
	    }
	    availableE[N] *= gNFraction;
	}
	if ( site.nelem > 1 )
		// availableE[P] = nps.tminrl[P]; // ??? should use nps.plabil?
		availableE[P] = nps.plabil;
	if ( site.nelem > 2 )
		availableE[S] = nps.tminrl[S];

	// Calculate carbon fraction in each part
	float cFraction[CPARTS];
	Assert (potentProd.total != 0.0f);
	cFraction[ABOVE] = potentProd.aboveGround / potentProd.total;
	cFraction[BELOW] = 1.0f - cFraction[ABOVE];
	float plantNfix = 0.0f;
	RestrictProduction ( availableE, comput.cercrp, CPARTS,
		cFraction, potentProd.cropC,
		RootImpactOnNutrients (cropC.bglivc),
		nps.crpstg, param.snfxmx[CRPSYS],
		// parameters returning values
		cropC.cprodc, nps.eprodc, uptake, plantNfix );

	// The following N-fixation accumulations were moved from
	//   NutrientLimitation() because RestrictProduction() is sometimes
	//   called twice (for trees). -mdh 10/9/02
	nps.snfxac[CRPSYS] += plantNfix;  // annual accumulation crop
	nps.nfixac += plantNfix;          // annual accumulation
	nps.nfix += plantNfix;            // monthly accumulation

	// If growth occurs...
	if (cropC.cprodc > 0.0f)
	{
	    // Update accumulators for N, P, and S uptake
	    for (short e = 0; e < site.nelem; ++e)
	    {
		nps.eupacc[e] += nps.eprodc[e];
		// fraction of element allocated to aboveground/belowground
		nps.eupaga[e] += elementUptake_ref (ABOVE, e);
		nps.eupbga[e] += elementUptake_ref (BELOW, e);
	    }

	    // C/N ratio for production
	    Assert (nps.eprodc[N] != 0.0f);
	    nps.tcnpro = cropC.cprodc / nps.eprodc[N];
	    // Growth of shoots
	    Assert (potentProd.total != 0.0f);
	    float const abovegroundProdFraction =
	    	potentProd.aboveGround / potentProd.total;
	    monthlyProduction[ABOVE] = cropC.cprodc * abovegroundProdFraction;
	    ScheduleCFlow ( st->time, monthlyProduction[ABOVE],
	    	param.cisofr, 1.0f,
	    	&soilC.csrsnk[UNLABL], &cropC.aglcis[UNLABL],
		&soilC.csrsnk[LABELD], &cropC.aglcis[LABELD],
		cropC.agcisa);

	    // Growth of roots
	    monthlyProduction[BELOW] =
	    	cropC.cprodc * (1.0f - abovegroundProdFraction);
	    ScheduleCFlow ( st->time, monthlyProduction[BELOW],
	    	param.cisofr, 1.0f,
	    	&soilC.csrsnk[UNLABL], &cropC.bglcis[UNLABL],
		&soilC.csrsnk[LABELD], &cropC.bglcis[LABELD],
		cropC.bgcisa );

	    // Actual uptake
	    for (short e = 0; e < site.nelem; ++e)	// each element...
	    {
		float euf[CPARTS];		// fraction of element uptake
	    	Assert (nps.eprodc[e] != 0.0f);
		euf[ABOVE] = elementUptake_ref (ABOVE, e) / nps.eprodc[e];
		euf[BELOW] = elementUptake_ref (BELOW, e) / nps.eprodc[e];

		// Take up nutrients from internal storage pool
		float flowAmount = std::max ( 0.0f,
					uptake_ref (ESTOR, e) * euf[ABOVE] );
		flows->Schedule (&nps.crpstg[e], &nps.aglive[e],
				st->time, flowAmount);
		flowAmount = std::max ( 0.0f,
					uptake_ref (ESTOR, e) * euf[BELOW] );
		flows->Schedule (&nps.crpstg[e], &nps.bglive[e],
				st->time, flowAmount);

		// Take up nutrients from soil over the rooting depth
		float const fractionInSolution =
			(e == P ?
				FractionMinPInSolution (
					water.depthOfRoots,
					soil->MineralP() ) :
				1.0f);
		float const amountUptake = std::max ( 0.0f,
				uptake_ref (ESOIL, e) * fractionInSolution );
		// aboveground demand
		flowAmount = std::max ( 0.0f, amountUptake * euf[ABOVE] );
		soilFlows->FlowNPSfromMineralSoil (
			(TMineralElements)e, &nps.aglive[e],
			flowAmount, water.depthOfRoots );
		// belowground demand
		flowAmount = std::max ( 0.0f, amountUptake * euf[BELOW] );
		soilFlows->FlowNPSfromMineralSoil (
			(TMineralElements)e, &nps.bglive[e],
			flowAmount, water.depthOfRoots );

		// Take up nutrients from nitrogen fixation
		if (e == N && plantNfix > 0.0f)
		{
		    flowAmount = std::max ( 0.0f,
					uptake_ref (ENFIX, e) * euf[ABOVE] );
		    flows->Schedule (&nps.esrsnk[e], &nps.aglive[e],
		    		    st->time, flowAmount);
		    flowAmount = uptake_ref (ENFIX, e) * euf[BELOW];
		    flows->Schedule (&nps.esrsnk[e], &nps.bglive[e],
		    	 	    st->time, flowAmount);
		}

		// Take up nutrients from fertilizer
		if (param.aufert != 0.0f && uptake_ref (EFERT, e) > 0.0f)
		{
		    // Automatic fertilizer added to plant pools
		    flowAmount = std::max ( 0.0f,
					uptake_ref (EFERT, e) * euf[ABOVE] );
		    flows->Schedule (&nps.esrsnk[e], &nps.aglive[e],
		    		    st->time, flowAmount);
		    flowAmount = std::max ( 0.0f,
					uptake_ref (EFERT, e) * euf[BELOW] );
		    flows->Schedule (&nps.esrsnk[e], &nps.bglive[e],
		    		    st->time, flowAmount);

		    // Automatic fertilizer added to surface mineral pool
		    Assert (fixed.favail[e] != 0.0f);
		    flowAmount = std::max ( 0.0f,
					uptake_ref (EFERT, e) *
					  (1.0f / fixed.favail[e] - 1.0f) );
		    flowAmount = soilFlows->FlowNPSintoMineralSoil (
		    		(TMineralElements)e,
				&nps.esrsnk[e], flowAmount, wt.simDepth );
		    nps.fertot[e] += uptake_ref (EFERT, e) + flowAmount;
		}
	    }

	    // annual accumulation
	    forestC.cproda += cropC.cprodc;

	} // cropC.cprodc > 0.0f
    }
    // Else no production this month

#undef uptake_ref
}

//--- end of file ---
