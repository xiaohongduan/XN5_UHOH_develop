// ----------------------------------------------------------------------------
//	Copyright 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  SiteEditorDataSrcFile.cpp
//	Class:	  SiteEditorDataSrcFile
//
//	Description:
//	Template class for the data source for the Site Editor for Century5
//	site parameters from a file.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Dec04
//	History: See header file.
// ----------------------------------------------------------------------------

#include "SiteEditorDataSrcFile.h"
#include "SiteEditorDlg.h"
#include "TFileSelDlg.h"
#include "charutil.h"
#include "AssertEx.h"
#include <v/vnotice.h>

#define pathLength 257				// maximum path length

// ----------------------------------------------------------------------------
//	template stuff
// ----------------------------------------------------------------------------

#define TEMPLATE_DECLARATION 		\
	template 			\
	< 				\
	  class SiteParameters,		\
	  class SiteParamInfo		\
	>

#define	SITEEDITORDATASRCFILE			\
	SiteEditorDataSrcFile			\
	<					\
	  SiteParameters, SiteParamInfo		\
	>

//	specialization for monthly site parameters
class TMCSiteParameters;
class TMCSiteParamInfo;
template class SiteEditorDataSrcFile<TMCSiteParameters, TMCSiteParamInfo>;

//	specialization for daily site parameters
class TDCSiteParameters;
class TDCSiteParamInfo;
template class SiteEditorDataSrcFile<TDCSiteParameters, TDCSiteParamInfo>;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	Read
//	Read the parameters file.
//	Return false if successful, else true if failed or error.
TEMPLATE_DECLARATION
bool SITEEDITORDATASRCFILE::Read (
	TSharedPtr<SiteParameters> & siteParameters)
{
	bool failed = false;			// return value
	try
	{
		if ( fileName.empty() )
		{
			errorMsg = "File name was not specified.";
			throw true;
		}
		else
		{
			siteParameters.reset (			// read the file
			    new SiteParameters (
				fileName, templatePath, workPath, info ) );
			if ( siteParameters.get() == 0 )
			{
				throw true;
			}
			else if ( siteParameters->IsError() )
			{
				siteParameters.reset ();
				throw true;
			}
		}
	}
	catch (...)
	{
		failed = true;
	}
	if ( failed )
	{
		error = ReadFailed;
		if ( errorMsg.empty() )
		{
		    if ( siteParameters.get() != 0 &&
		    	 !siteParameters->GetNcFileName().IsEmpty() )
		    {
			errorMsg =
				"Failed reading the site parameters "
				"from the following file:\n";
			errorMsg +=
				siteParameters->GetNcFileName().GetFullName();
			if ( siteParameters->IsError() )
			{
			    errorMsg += "\nSite parameters error message:\n";
			    errorMsg += siteParameters->GetErrorMsg();
			}
		    }
		    else
		    {
			errorMsg = "Failed reading the site parameters.";
		    }
		}
	}
	return failed;
}

//	Write
//	Write the parameters file.
//	Return false if successful, else true if failed or error.
TEMPLATE_DECLARATION
bool SITEEDITORDATASRCFILE::Write ()
{
	bool failed = false;			// return value
	try
	{
		if ( fileName.empty() )
		{
			errorMsg = "File name was not specified.";
			throw true;
		}
		else
		{
			failed = dataPtr->WriteNcFile ();
			if ( failed )
				throw true;
		}
	}
	catch (...)
	{
		failed = true;
	}
	if ( failed )
	{
		error = WriteFailed;
		if ( dataPtr.get() != 0 )
		{
			errorMsg =
				"Failed writing the site parameters "
				"to the following file:\n";
			errorMsg += dataPtr->GetNcFileName().GetFullName();
			if ( dataPtr->IsError() )
			{
				errorMsg += "\nNetCDF error message:";
				errorMsg += dataPtr->GetErrorMsg();
			}
		}
		else
		{
			errorMsg = "Failed writing the site parameters.";
		}
	}
	return failed;
}

TEMPLATE_DECLARATION
void SITEEDITORDATASRCFILE::ReadWriteErrorNotice (
	char const * const msgFirstPart)
{
	vNoticeDialog dlg ( parent, "Error - Site Parameters" );
	std::string msg = msgFirstPart;
	msg += "\n\nFile name: ";
	msg += fileName;
	if ( !GetErrorMessage().empty() )
	{
		msg += NL_CHAR;
		msg += GetErrorMessage();
	}
	dlg.Notice ( msg.c_str() );
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

TEMPLATE_DECLARATION
SITEEDITORDATASRCFILE::TUserAction SITEEDITORDATASRCFILE::DoOpen (
	TSharedPtr<SiteParameters> & siteParameters)
{
	char const* filter[] =
	{
		"Site Parameter Files|*-ST.nc|"
		"Century 4 Site Files|*.100|"
		"All (*.*)|*.*|",
		NULL
	};
	int filterIndex = 0;			// filter index
	std::string initPath = workPath;	// starting folder
	char newFileName[pathLength];
	*newFileName = NULL_CHAR;
	char const * const prompt = "Select a Site Parameter Set";
	vFileSelect fileSelectDlg (parent);
	int result = fileSelectDlg.FileSelect (
				prompt,
				newFileName, pathLength - 1,
				const_cast<char**>(filter), filterIndex,
				initPath.c_str() );
	if ( result == 1 )				// OK button
	{
	    fileName = newFileName;
	    bool const readFailed = Read ( siteParameters );
	    if ( readFailed || HaveError() )
	    {
		ReadWriteErrorNotice (
			"Read (Open) of site parameters failed." );
		return ActionOK;
	    }
	    MyBaseClass::Copy (*siteParameters);
	    siteParameters->SetModified (false);
	}
	return (result == 0 ? ActionCancel : ActionOK );
}

TEMPLATE_DECLARATION
SITEEDITORDATASRCFILE::TUserAction SITEEDITORDATASRCFILE::DoSave (
	SiteParameters const & siteParameters)
{
	MyBaseClass::Copy (siteParameters);
	Assert (siteParameters.GetSetCount() > 0);
	Assert (dataPtr.get() != 0);
	Assert (dataPtr.get()->GetSetCount() > 0);
	if ( HaveError() )
		return ActionCancel;
	else if ( siteParameters.IsModified() )
	{
	    bool writeFailed = Write ();
	    if ( writeFailed || HaveError() )
	    {
		ReadWriteErrorNotice (
			"Write (Save) of site parameters failed." );
	    }
	}
	return ActionOK;
}

TEMPLATE_DECLARATION
SITEEDITORDATASRCFILE::TUserAction SITEEDITORDATASRCFILE::DoSaveAs (
	SiteParameters & siteParameters)
{
	MyBaseClass::Copy (siteParameters);
	char const* filter[] =
	{
		"Site Parameter Files|*-ST.nc|"
		"Century 4 Site Files|*.100|"
		"All (*.*)|*.*|",
		NULL
	};
	int filterIndex = 0;			// filter index
	std::string initPath = workPath;	// starting folder
	char newFileName[pathLength];
	*newFileName = NULL_CHAR;
	char const * const prompt = "Save Site Parameter Set";
	vFileSelect fileSelectDlg (parent);
	int result = fileSelectDlg.FileSelect (
				prompt,
				newFileName, pathLength - 1,
				const_cast<char**>(filter), filterIndex,
				initPath.c_str() );
	if ( result == 1 )				// Save/OK button
	{
	    fileName = newFileName;
	    siteParameters.SetBaseName (fileName);
	    bool writeFailed = Write ();
	    if ( writeFailed || HaveError() )
	    {
		ReadWriteErrorNotice (
			"Write (Save) of site parameters failed." );
		return ActionOK;
	    }
	}
	return (result == 0 ? ActionCancel : ActionOK );
}

//--- end of definitions for SiteEditorDataSrcFile ---
