// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  irrigt.cpp
//	Class:	  TCentury
//	Function: Irrigate
//
//	Description:
//	Irrigate the system when above freezing.
// ----------------------------------------------------------------------------
//	History:
//	Sep98	Tom Hilinski, tom.hilinski@colostate.edu
//	*Rewrote but did not change algorithm.
//	Apr00 Tom Hilinski, tom.hilinski@colostate.edu
//	* Variables twhc and awhc are used only here, so moved them here from
//	struct Twater.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TCentury.h"

float TCentury::Irrigate (
	short const month)		// simulation month
{
    wt.irract = 0.0f;		// initialize current irrigation amount

    // Check temperature that irrigation water is not added as snow
    if (wt.tave > 0.0f)			// Add amount given by user
    {
	float const awhc =
		soil->PlantWaterCapacityAmt (0.0f, water.depthOfRoots);
	Assert (awhc > 0.0f);
	float const twhc =
		soil->FieldCapacityQuantity (0.0f, water.depthOfRoots);
    	Assert (twhc > 0.0f);

    	switch (parcp.auirri)		// (1-3 = automatic irrigation)
    	{
    	  case 0:	//--- no auto irrigation; use amount from event
    	  	wt.irract = parcp.irramt;
    	  	break;

    	  case 1: 	//--- Add amount to field capacity
		if (wt.avh2o[0] / awhc <= parcp.fawhc)
		{
		  float rootZoneTotalWater =
		    weather->Precip(month) +
		    soil->WaterContent().Quantity (
		      		0.0f, water.depthOfRoots,
		      		soil->Depth(), soil->Thickness() );
		  wt.irract = std::max (twhc - rootZoneTotalWater, 0.0f);
		}
    	  	break;

    	  case 2:	//--- Add amount to nominated amount
	    	if (wt.avh2o[0] / awhc <= parcp.fawhc)
			wt.irract = parcp.irraut;
    	  	break;

	  case 3:	//--- Add amount to field capacity plus PET
	    	if (wt.avh2o[0] / awhc <= parcp.fawhc)
	    	{
		  float rootZoneTotalWater =
		    weather->Precip(month) +
		    soil->WaterContent().Quantity (
		      		0.0f, water.depthOfRoots,
		      		soil->Depth(), soil->Thickness() );
		  wt.irract =
		  	std::max (twhc + wt.pet - rootZoneTotalWater, 0.0f);
	    	}
    	  	break;

    	  default:	//--- error!
		// Need a Century exception here
    	  	break;
    	}
    	wt.irrtot += wt.irract;		// accumulate irrigation
    }
    return wt.irract;
}

