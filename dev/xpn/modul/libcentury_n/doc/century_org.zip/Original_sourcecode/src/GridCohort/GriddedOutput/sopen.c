
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "gridconst.h"

/* Global Variables */
FILE *fp_s[NSOILFILES];

/* Open SVF Soil Files */

int
sopen(FILE *fp_init)
{

     char junk[MAXR+1];
     int i, j;
     char line[MAXL];

     char sfname[NSOILFILES][FNAMEMAX];        /* VEMAP soil class */

	/* Open Soils SVF Files */
        fgets(line, MAXL, fp_init);

        for (i = 0; i < NSOILFILES; i++)
	{
                fgets(line, MAXL, fp_init);
                sscanf(line, "%s", sfname[i]);
                if((fp_s[i] = fopen(sfname[i], "r")) == NULL)
	        {
                   printf("sopen: Unable to open file %s\n", sfname[i]);
                   return 1;
                }

	        /* Read Header information */
	        for (j = 0; j < 5; j++)
	        {
	          fgets(junk, MAXR, fp_s[i]);
	        }
	}

	return 0;
}
