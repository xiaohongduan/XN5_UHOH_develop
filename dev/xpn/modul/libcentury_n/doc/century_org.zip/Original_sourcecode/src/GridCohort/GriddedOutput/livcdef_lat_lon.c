
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  livcll_ncid;			/* netCDF id */

/* variable ids */
int  aglivcll_id, bglivcll_id, stdedcll_id, rleavcll_id, frootcll_id, 
     fbrchcll_id, rlwodcll_id, crootcll_id, wood1cll_id, wood2cll_id, 
     wood3cll_id, pltlig1ll_id, pltlig2ll_id;
int  timell_id, lat_id, lon_id;

/* create livc.nc */
int
livcdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
           float *opltim, float *qtime) {

   int   status, istart_year, iend_year, ii;
   float fill, fstart_year, fend_year;
   char  timeunits[25], temp[5];

   /* dimension ids */
   int  time_dim = 0;
   int  lat_dim = 0;
   int  lon_dim = 0;

   /* variable shapes */
   int dims[3];

   /* Set fill, start_year, and end_year values */
   fill = NC_FILL_FLOAT;
   fstart_year = *opltim;
   fend_year = *qtime - 1;
   istart_year = fstart_year;
   iend_year = fend_year;

   for (ii = 0; ii < 25; ii++) {
     timeunits[ii] = '\0';
   }
   /* Get the start time for the time definition */
   sprintf(temp, "%d", istart_year); 
   strcat(timeunits, "days since ");
   strcat(timeunits, temp);
   strcat(timeunits, "-01-01");

   /* enter define mode */
   status = nc_create("livcll.nc", NC_CLOBBER, &livcll_ncid );
   if (status != NC_NOERR) handle_error("nc_create(livc.nc)", status);

   /* define dimensions */
   status = nc_def_dim(livcll_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(livcll_ncid, "lat", (size_t) *nlat, &lat_dim);
   status = nc_def_dim(livcll_ncid, "lon", (size_t) *nlon, &lon_dim);

   /* define variables */

   dims[0] = time_dim;
   status = nc_def_var (livcll_ncid, "time", NC_INT, 1, dims, &timell_id);

   dims[0] = lat_dim;
   status = nc_def_var (livcll_ncid, "lat", NC_FLOAT, 1, dims, &lat_id);

   dims[0] = lon_dim;
   status = nc_def_var (livcll_ncid, "lon", NC_FLOAT, 1, dims, &lon_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livcll_ncid, "aglivc", NC_FLOAT, 3, dims, &aglivcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livcll_ncid, "bglivc", NC_FLOAT, 3, dims, &bglivcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livcll_ncid, "stdedc", NC_FLOAT, 3, dims, &stdedcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livcll_ncid, "rleavc", NC_FLOAT, 3, dims, &rleavcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livcll_ncid, "frootc", NC_FLOAT, 3, dims, &frootcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livcll_ncid, "fbrchc", NC_FLOAT, 3, dims, &fbrchcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livcll_ncid, "rlwodc", NC_FLOAT, 3, dims, &rlwodcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livcll_ncid, "crootc", NC_FLOAT, 3, dims, &crootcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livcll_ncid, "wood1c", NC_FLOAT, 3, dims, &wood1cll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livcll_ncid, "wood2c", NC_FLOAT, 3, dims, &wood2cll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livcll_ncid, "wood3c", NC_FLOAT, 3, dims, &wood3cll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livcll_ncid, "pltlig1", NC_FLOAT, 3, dims, &pltlig1ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livcll_ncid, "pltlig2", NC_FLOAT, 3, dims, &pltlig2ll_id);

   /* assign attributes */
   status = nc_put_att_text (livcll_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (livcll_ncid, timell_id, "long_name", strlen("Time"), "Time");
   status = nc_put_att_text (livcll_ncid, timell_id, "units", strlen(timeunits), timeunits);
   status = nc_put_att_text (livcll_ncid, timell_id, "time_step", strlen("monthly"), "monthly");
   status = nc_put_att_text (livcll_ncid, timell_id, "calendar", strlen("gregorian"), "gregorian");
   status = nc_put_att_int (livcll_ncid, timell_id, "start_year", NC_INT, 1, &istart_year);
   status = nc_put_att_int (livcll_ncid, timell_id, "end_year", NC_INT, 1, &iend_year);

   status = nc_put_att_text (livcll_ncid, lat_id, "long_name", strlen("Latitude"), "Latitude");
   status = nc_put_att_text (livcll_ncid, lat_id, "units", strlen("degrees_north"), "degrees_north");
   status = nc_put_att_text (livcll_ncid, lat_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (livcll_ncid, lat_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (livcll_ncid, lon_id, "long_name", strlen("Longitude"), "Longitude");
   status = nc_put_att_text (livcll_ncid, lon_id, "units", strlen("degrees_east"), "degrees_east");
   status = nc_put_att_text (livcll_ncid, lon_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (livcll_ncid, lon_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (livcll_ncid, aglivcll_id, "long_name", 
        strlen("above_ground_live_carbon"), "above_ground_live_carbon");
   status = nc_put_att_text (livcll_ncid, aglivcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livcll_ncid, aglivcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livcll_ncid, bglivcll_id, "long_name", 
	strlen("below_ground_live_carbon"), "below_ground_live_carbon");
   status = nc_put_att_text (livcll_ncid, bglivcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livcll_ncid, bglivcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livcll_ncid, stdedcll_id, "long_name", 
	strlen("standing_dead_carbon"), "standing_dead_carbon");
   status = nc_put_att_text (livcll_ncid, stdedcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livcll_ncid, stdedcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livcll_ncid, rleavcll_id, "long_name", 
	strlen("live_leaf_carbon"), "live_leaf_carbon");
   status = nc_put_att_text (livcll_ncid, rleavcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livcll_ncid, rleavcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livcll_ncid, frootcll_id, "long_name", 
	strlen("live_fine_root_carbon"), "live_fine_root_carbon");
   status = nc_put_att_text (livcll_ncid, frootcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livcll_ncid, frootcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livcll_ncid, fbrchcll_id, "long_name", 
	strlen("live_fine_branch_carbon"), "live_fine_branch_carbon");
   status = nc_put_att_text (livcll_ncid, fbrchcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livcll_ncid, fbrchcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livcll_ncid, rlwodcll_id, "long_name", 
	strlen("live_large_wood_carbon"), "live_large_wood_carbon");
   status = nc_put_att_text (livcll_ncid, rlwodcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livcll_ncid, rlwodcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livcll_ncid, crootcll_id, "long_name", 
	strlen("live_coarse_root_carbon"), "live_coarse_root_carbon");
   status = nc_put_att_text (livcll_ncid, crootcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livcll_ncid, crootcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livcll_ncid, wood1cll_id, "long_name", 
	strlen("dead_fine_branch_carbon"), "dead_fine_branch_carbon");
   status = nc_put_att_text (livcll_ncid, wood1cll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livcll_ncid, wood1cll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livcll_ncid, wood2cll_id, "long_name", 
	strlen("dead_large_wood_carbon"), "dead_large_wood_carbon");
   status = nc_put_att_text (livcll_ncid, wood2cll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livcll_ncid, wood2cll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livcll_ncid, wood3cll_id, "long_name", 
	strlen("dead_coarse_root_carbon"), "dead_coarse_root_carbon");
   status = nc_put_att_text (livcll_ncid, wood3cll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livcll_ncid, wood3cll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livcll_ncid, pltlig1ll_id, "long_name", 
	strlen("lignin_fraction_of_surface_material"), "lignin_fraction_of_surface_material");
   status = nc_put_att_text (livcll_ncid, pltlig1ll_id, "units", 
	strlen("unitless"), "unitless");
   status = nc_put_att_float(livcll_ncid, pltlig1ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livcll_ncid, pltlig2ll_id, "long_name", 
	strlen("lignin_fraction_of_sub-surface_material"), 
	"lignin_fraction_of_sub-surface_material");
   status = nc_put_att_text (livcll_ncid, pltlig2ll_id, "units", 
	strlen("unitless"), "unitless");
   status = nc_put_att_float(livcll_ncid, pltlig2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   /* leave define mode */
   status = nc_enddef (livcll_ncid);
   return 0;
}
