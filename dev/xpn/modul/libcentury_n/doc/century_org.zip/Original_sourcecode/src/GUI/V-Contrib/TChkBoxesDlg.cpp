// ----------------------------------------------------------------------------
// Copyright (c) 1999 Thomas E. Hilinski. All rights reserved.
// Unauthorized distribution, duplication, sale, and use is prohibited by law.
//
//	This software is made available under the terms of the
//	GNU LIBRARY GENERAL PUBLIC LICENSE.
//	This copyright notice must remain intact and in place.
// ----------------------------------------------------------------------------
//	Project:  V GUI Enhancement
//	File:	  TChkBoxesDlg.cpp
//	Class:	  TCheckBoxesDialog
//
//	Description:
//	Declaration of class for a V dialog displaying a variable number of
//	checkboxes.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, hilinski@lamar.colostate.edu, Nov99
//	History:
//	See the header file.
// ----------------------------------------------------------------------------

#include "TChkBoxesDlg.h"
#include <v/vapp.h>
#include <v/vutil.h>
#include <cstring>

// Borland flags
#pragma warn -sig

// check for minimum V version
#if (V_VersMajor < 1) || (V_VersMinor < 16)
  #error V version 1.16 or higher is required.
#endif

//--- static member data

char const * const TCheckBoxesDialog::version = "1.11";	// class version string


//--- constructors and destructor

TCheckBoxesDialog::TCheckBoxesDialog (
	vBaseWindow * const bw,	// pointer to window
	char const * const msg,		// message at top of choices
	short const numChoices,		// number of choices
	char const * const title, 	// title of dialog
	bool const centerMe)		// flag to center the dialog
	: vModalDialog (bw, title),
	  centered (centerMe)
{
	Initialize (msg, numChoices);
}

TCheckBoxesDialog::TCheckBoxesDialog (
	vApp * const app,	// pointer to application
	char const * const msg,		// message at top of choices
	short const numChoices,		// number of choices
	char const * const title, 	// title of dialog
	bool const centerMe)		// flag to center the dialog
	: vModalDialog (app, title),
	  centered (centerMe)
{
	Initialize (msg, numChoices);
}

TCheckBoxesDialog::~TCheckBoxesDialog ()
{
	// delete memory for text items
	if ( strlen(coList[0].title) )		// default has no length
		delete [] coList[0].title;	// has length, so was new'd
	for (short i = 0; i < bntCount; i++)
		if ( strlen(coList[2+i].title) )
			delete [] coList[2+i].title;
	// delete memory for lists
	delete [] coList;
	delete [] results;
}

//	DialogDisplayed
//	Overrides the vModelDialog method.
void TCheckBoxesDialog::DialogDisplayed ()
{
	//vModalDialog::DialogDisplayed ();
	if ( centered )
	{
		// center the dialog in the app window
		int xApp, yApp;				// app window location
		unsigned int widthApp, heightApp; 	// app window dimensions
		unsigned int widthDlg, heightDlg; 	// dialog dimensions

#if defined(V_VersionWindows) || defined(V_VersionWin95)
		// MS Windows-specific!
		RECT rectApp, rectDlg;			// app & dlg corners
		BOOL success = ::GetWindowRect ( theApp->winHwnd(), &rectApp );
		success &= ::GetWindowRect ( myHwnd(), &rectDlg );
		if ( !success )
			return;		// Get*Rect() failed - nothing to do!
		xApp = rectApp.left;
		yApp = rectApp.top;
		widthApp = rectApp.right - rectApp.left;
		heightApp = rectApp.bottom - rectApp.top;
		widthDlg = rectDlg.right - rectDlg.left;
		heightDlg = rectDlg.bottom - rectDlg.top;

		// Common to all platforms
		int left, top;				// dlg upper-left corner
		// don't add to left - SetDialogPosition does
		if ( widthApp > widthDlg )
			left = (widthApp - widthDlg) / 2;
		else
			left = xApp;
		if ( heightApp > heightDlg )
			top = (heightApp - heightDlg) / 2;
		else
			top = yApp;
		SetDialogPosition (left , top);	      // set position V coords
#else
		// X11R6-specific
		// See vDialog::ShowDialog
#endif
	}
}

//	DialogCommand
//	Overrides the vModelDialog method.
void TCheckBoxesDialog::DialogCommand (ItemVal id, ItemVal val, CmdType type)
{
	if ( id == M_OK )
	{
		buttonSelected = M_OK;		// return button selection
		try
		{
			results = new bool [bntCount + 1];	// mem for list
			results[bntCount] = 0;			// null-term
		}
		catch (...)
		{
			lastError = MemoryAlloc;
			goto error_done;
		}
		bool* pResults = results;
		for (int i = 0; i < bntCount; ++i, ++pResults)
		{
			if ( GetValue(CID_Button1 + i) == isChk )
				*pResults = true;
			else
				*pResults = false;
		}
	}
	else if ( id == M_Cancel )
	{
		buttonSelected = M_Cancel;	// return button selection
	}
	// Default event processing
    error_done:
	vModalDialog::DialogCommand (id, val, type);
}

//--- private functions

void TCheckBoxesDialog::Initialize (
	char const *  const msg,
	short const numChoices)
{
	// error checks
	if ( numChoices <= 0 )
	{
		lastError = ZeroChoices;	// non-fatal error
		bntCount = 0;
	}
	else
		bntCount = numChoices;		// save the number of buttons

	// create the CommandObject list
	try
	{
		coList = new CommandObject [bntCount + 5];
	}
	catch (...)
	{
		lastError = MemoryAlloc;
		return;				// fatal error
	}

	// add C_Text for user's message
	CommandObject c0 = {C_Text, CID_Msg, 0, "",
		NoList, CA_NoBorder, isSens, NoFrame, 0, 0};
	coList[0] = c0;
	// add C_Frame for radio buttons
	CommandObject c1 = {C_Frame, CID_Frame, 0, "",
		NoList, CA_None, isSens, NoFrame, 0, CID_Msg};
	coList[1] = c1;
	// add OK button
	CommandObject c2 = {C_Button, M_OK, M_OK, "&Select",
		NoList,	CA_DefaultButton, isSens, NoFrame, 0, CID_Frame,
		0, "Accepts the selection and closes this dialog."};
	coList[numChoices + 2] = c2;
	// add Cancel button
	CommandObject c3 = {C_Button, M_Cancel, M_Cancel, "&Cancel",
		NoList,	CA_None, isSens, NoFrame, M_OK, CID_Frame,
		0, "Cancels this selection."};
	coList[numChoices + 3] = c3;
	// add end of list
	CommandObject c4 = {C_EndOfList, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	coList[numChoices + 4] = c4;
	// Add the message to the text item
	if ( msg && *msg )
	{
		try
		{
			char *msgText = new char [strlen(msg) + 1];
			strcpy (msgText, msg);
			coList[0].title = msgText;
		}
		catch (...)
		{
			lastError = MemoryAlloc;
		}
	}
	// point to first radio button
	curBtn = 0;
	widestBtnID = 1;
	widestWidth = 0;
	toRightOf = belowOf = 0;
	// initialize choices
	results = 0;
	buttonSelected = 0;
	// misc
	lastError = NoError;
	bntHave = 0;
}

//--- public functions

void TCheckBoxesDialog::AddChoice (
	char const * const checkboxText)
{
	// error checks
	if ( curBtn >= bntCount )		// too many choices?
	{
		lastError = TooMany;
		return;				// fatal
	}
	if ( !checkboxText )			// anything there?
	{
		lastError = NullText;
		return;				// fatal
	}

	// set up the CommandObject
	CommandObject &c = coList[2 + curBtn];		// get button to add
	// fill in the CommandObject items
	c.cmdType = C_CheckBox;
	c.cmdId = CID_Button1 + curBtn;
	c.retVal = 0;					// default: not checked
	if ( checkboxText && *checkboxText )
	{
		try
		{
			char *text = new char [strlen(checkboxText) + 1];
			strcpy (text, checkboxText);
			c.title = text;
		}
		catch (...)
		{
			lastError = MemoryAlloc;	// non-fatal
			c.title = "";
		}
		++bntHave;				// count number added
	}
	else
	{
		c.title = "";
	}
	c.itemList = NoList;
	c.attrs = CA_NoNotify;
	c.Sensitive = isSens;
	c.cFrame = CID_Frame;
	c.cRightOf = toRightOf;
	c.cBelow = belowOf;
	c.size = 0;
	c.tip = "You can select this choice.";
	// get width of title, and see if it is the widest
	int numLines, lineWidth;
	lineWidth = ::vTextLen (c.title, numLines);
	if ( lineWidth > widestWidth )
	{
		widestWidth = lineWidth;	// save width
		widestBtnID = curBtn;		// save button ID
	}
	belowOf = CID_Button1 + curBtn;
	++curBtn;
}

void TCheckBoxesDialog::NextColumn ()
{
	toRightOf = CID_Button1 + widestBtnID;
	belowOf = 0;
	widestBtnID = curBtn;		// reset to current
	widestWidth = 0;		// reset
}

int TCheckBoxesDialog::GetChoices (
	bool const * &choices)
{
	if ( bntHave == 0 )
		lastError = NoChoices;
	AddDialogCmds ((CommandObject*)coList);	// add dialog controls
	ItemVal retVal;
	ShowModalDialog ("", retVal);		// display it now
	// return results to user
	choices = results;			// ptr to array of bools
	return buttonSelected;			// button selection
}

//--- end of file ---

