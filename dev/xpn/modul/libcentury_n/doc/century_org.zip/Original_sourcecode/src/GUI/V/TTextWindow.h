#ifndef INC_TTextWindow_h
#define INC_TTextWindow_h
// ----------------------------------------------------------------------------
//	Project:  Century Model Interface - V GUI
//	File:	TTextWindow.h
//
//	Class Type for GUI Window: TTextWindow
//	Overrides vTextEditor
//
//	Author:	Tom Hilinski, Feb98, tom.hilinski@colostate.edu
// ----------------------------------------------------------------------------

#include <v/vtexted.h>
#include <v/vpopmenu.h>
#include <memory>

class TTextWindow : public vTextEditor
{
  public:
	//--- constructors and destructor
	TTextWindow (
	  vCmdWindow * const parent,
	  const bool readOnlyFlag = false,	// true if file is read-only
	  const bool userCloseFlag = true);	// true if user can close win.
	~TTextWindow ();

	//--- functions overridden
	virtual void Redraw (int x, int y, int width, int height)
	  {
	    vTextEditor::Redraw (x, y, width, height);
	  }
	void TextMouseDown (int row, int col, int button);

	//--- functions
	void AppendText (
	  char const * const text);		// text on canvas
	void CloseWin ();


  private:
	//--- data
	static vMenu popupMenuDef[];		// popup menu definition
	std::auto_ptr<vPopupMenu> popupMenu;	// right-click popup menu
	char *buf;				// output buffer
	int bufLen;				// length of output buffer
	bool readOnly;	 			// true if file is read-only
	bool userClose;				// true if user can close win.
};

#endif 	// INC_TTextWindow_h

