
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  prod_ncid;			/* netCDF id */

/* variable ids */
int  agcprd_id, bgcprd_id, rlvprd_id, frtprd_id, fbrprd_id, 
     rlwprd_id, crtprd_id;

int
proddef(int *ntimes, char *history) {		/* create prod.nc */

   int status;

   /* dimension ids */
   int  time_dim = 0;
   int  cell_dim = 0;

   /* variable shapes */
   int dims[2];

   /* enter define mode */
   status = nc_create("prod.nc", NC_CLOBBER, &prod_ncid);
   if (status != NC_NOERR) handle_error("nc_create(prod.nc)", status);

   /* define dimensions */
   status = nc_def_dim(prod_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(prod_ncid, "cell", NC_UNLIMITED, &cell_dim);

   /* define variables */

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (prod_ncid, "agcprd", NC_FLOAT, 2, dims, &agcprd_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (prod_ncid, "bgcprd", NC_FLOAT, 2, dims, &bgcprd_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (prod_ncid, "rlvprd", NC_FLOAT, 2, dims, &rlvprd_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (prod_ncid, "frtprd", NC_FLOAT, 2, dims, &frtprd_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (prod_ncid, "fbrprd", NC_FLOAT, 2, dims, &fbrprd_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (prod_ncid, "rlwprd", NC_FLOAT, 2, dims, &rlwprd_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (prod_ncid, "crtprd", NC_FLOAT, 2, dims, &crtprd_id);

   /* assign attributes */
   status = nc_put_att_text (prod_ncid, NC_GLOBAL, "history", strlen(history), history);
   status = nc_put_att_text (prod_ncid, agcprd_id, "long_name", 
	strlen("above_ground_carbon_production"), "above_ground_carbon_production");
   status = nc_put_att_text (prod_ncid, agcprd_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (prod_ncid, bgcprd_id, "long_name", 
	strlen("below_ground_carbon_production"), "below_ground_carbon_production");
   status = nc_put_att_text (prod_ncid, bgcprd_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (prod_ncid, rlvprd_id, "long_name", 
	strlen("leaf_carbon_production"), "leaf_carbon_production");
   status = nc_put_att_text (prod_ncid, rlvprd_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (prod_ncid, frtprd_id, "long_name", 
	strlen("fine_root_carbon_production"), "fine_root_carbon_production");
   status = nc_put_att_text (prod_ncid, frtprd_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (prod_ncid, fbrprd_id, "long_name", 
	strlen("fine_branch_carbon_production"), "fine_branch_carbon_production");
   status = nc_put_att_text (prod_ncid, fbrprd_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (prod_ncid, rlwprd_id, "long_name", 
	strlen("large_wood_carbon_production"), "large_wood_carbon_production");
   status = nc_put_att_text (prod_ncid, rlwprd_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (prod_ncid, crtprd_id, "long_name", 
	strlen("coarse_root_carbon_production"), "coarse_root_carbon_production");
   status = nc_put_att_text (prod_ncid, crtprd_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   /* leave define mode */
   status = nc_enddef (prod_ncid);
   return 0;
}
