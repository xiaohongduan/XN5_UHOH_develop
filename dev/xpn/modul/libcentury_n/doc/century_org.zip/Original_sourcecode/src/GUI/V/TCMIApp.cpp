// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TCMIApp.cpp
//	Class:	  TCMIApp
//
//	Description:
//	Class Type for GUI Application Main. Inherits vApp
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Dec98
//	History: See header file.
// ----------------------------------------------------------------------------

#include "externals.h"
#include "TCentury.h"
#include "TRunProgressDlg.h"
#include "TAboutDlg.h"
#include "TMgmtSummaryDlg.h"
#include "fnutil.h"
#include "SiteException.h"
#include "WeatherException.h"
#include "HelpDisplay.h"
#include "MCSiteCreator.h"
// #include "UtilGUI.h"
#include <v/vutil.h>
#include <v/vynreply.h>
#include <v/vreply.h>
#include <exception>
#include <memory>
#include <sstream>
using namespace std;

extern std::auto_ptr<TCentury> century;		// Century model instance

// ----------------------------------------------------------------------------
//	local variables
// ----------------------------------------------------------------------------

static char const * const helpFileName = "cmi.hlp";

//--- Pointers to application data
TSharedPtr<CenturyPaths> defPaths;	// default directory paths
std::string helpPath;			// Windows Help file name =
					//   "appPath/name.hlp"

//--- Globally-accessable Dialogs
std::auto_ptr<TRunProgressDlg> progDlg;		// progress display dialog

// ----------------------------------------------------------------------------
//	global functions for messaging
// ----------------------------------------------------------------------------

//	DisplayToMsgWindow
//	Writes the string contents to the message window.
//	This is mainly for Century to have a function pointer that is not
//	a class member for its century->UseMsgFunction() method.
static void DisplayToMsgWindow (
	std::string const & str)
{
	if ( !str.empty() )
	{
		MsgText ( str.c_str() );
		::myApp.CheckEvents ();		// V will process the event
	}
}

static void DisplayToMsgWindow (
	char const * const str)
{
	if ( str )
	{
		MsgText (str);
		::myApp.CheckEvents ();		// V will process the event
	}
}

//	UpdateProgressDialog
//	Updates the progress bar in the progress dialog.
//	This is mainly for Century to have a function pointer that is not
//	a class member for its century->UseYearMsgFunction() method.
static void UpdateProgressDialog (
	const long year)
{
	if ( !::progDlg.get() )				// anything to do?
		return;

	static long numYears = 0, yearStart = 0;

	// calc only once
	if ( !numYears )
	{
		yearStart = ::centuryConfig->GetManagement()->
					GetSimInfo().yearStart;
		numYears = ::centuryConfig->GetManagement()->
					GetSimInfo().yearEnd - yearStart + 1;
	}
	// calc percent completed
	int const percent = static_cast<int>(
		static_cast<float>(year - yearStart + 1) /
		numYears * 100.0f + 0.5f );
	::progDlg->Update (percent);
}

//	DoTimeSlice
//	Calls V's vApp::CheckEvents() to allow time slicing.
static void DoTimeSlice (
	char const * const dummyStr)	// place-holder
{
	::myApp.CheckEvents();
}

//	PostCancelRequest
//	Posts a cancel request to the Century process.
//	This is mainly for TRunProgressDlg to have a function pointer that is not
//	a class member for its UseCancelFunction() method.
static void PostCancelRequest ()
{
	if ( ::century.get() )				// anything to do?
		::century->PostCancelRequest ();
}

bool WriteSiteFile (
	std::string const & newSiteFileName,
	TCenturyConfig const & config,
	TCentury const & century)
{
	// update the site information
	TSharedPtr<TMCSiteParameters const> oldSite = century.GetSite();
	EditorsInfo editInfo = oldSite->GetEditInfo();
	editInfo.SetEditorName ( config.GetUserName() );
	editInfo.SetEditDate( ::DateTimeStr() );

	// Create new site parameter set from century model internal values
	TMCSiteParameters newSite (
		config.GetPaths()->GetPath(CenturyPaths::Templates),
		config.GetPaths()->GetPath(CenturyPaths::Work),
		oldSite->GetSiteParamInfo() );
	::nrel::century::MCSiteCreator siteCreator (	// create from
		century, editInfo, newSite );
	newSite.SetName ( oldSite->GetName() );
	newSite.SetDescription ( oldSite->GetDescription() );
	newSite.SetSiteType ( oldSite->GetSiteType() );
	siteCreator.MakeParameters ();

	// write the parameter set to a file
	bool failed = false;				// return value
	std::string errorMsg;
	try
	{
	    if ( newSiteFileName.empty() )
	    {
		errorMsg = "File name was not specified.";
		throw true;
	    }
	    newSite.SetBaseName (newSiteFileName);
	    failed = newSite.WriteNcFile ();
	    if ( failed )
		throw true;
	}
	catch (...)
	{
		failed = true;
	}
	if ( failed )
	{
		if ( !newSite.GetNcFileName().GetFullName().empty() )
		{
		    errorMsg +=
			"Failed writing the site parameters "
			"to the NetCDF file:\n";
		    errorMsg += newSite.GetNcFileName().GetFullName();
		}
		if ( newSite.IsError() )
		{
			errorMsg += "\nSite parameter set error message:\n";
			errorMsg += newSite.GetErrorMsg();
		}
	}
	if ( !errorMsg.empty() )
		throw errorMsg;
	return failed;
}

// ----------------------------------------------------------------------------
//	contstructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	overridden methods
// ----------------------------------------------------------------------------

vWindow* const TCMIApp::NewAppWin (
	vWindow * const win,		// parent window
	char const * const name,	// window name
	int const h,			// height
	int const w,			// width
	vAppWinInfo * const winInfo)	// window information
{
	// Window name
	char const * myName = name;			// local copy
	if (!name || !(*name))
		myName = "Untitled";			// default name

	// Create a new window
	TTextCmdWindow *thisWin = (TTextCmdWindow*) win;	// local copy
	if (!thisWin)
	{
		thisWin = new TTextCmdWindow (this, myName);
	}

	// Save info about window
	vAppWinInfo* myWinInfo = winInfo;
	if (!myWinInfo)
		myWinInfo = new vAppWinInfo (myName);

	// Register and return
	return vApp::NewAppWin (thisWin, myName, h, w, myWinInfo);
}

int TCMIApp::CloseAppWin (
	vWindow* const win)
{
	if ( inExit ||
	     // do not close the Message and History windows!
	     ( win != (vWindow*) historyWindow &&
	       win != (vWindow*) messageWindow ) )
	{
		vApp::CloseAppWin (win);
		return 1;				// close app
	}
	else
		return 0;				// abort close
}

void TCMIApp::Exit (void)
{
	vYNReplyDialog dlg (this, "Confirm Exit");
	if ( 1 == dlg.AskYN ("Do you want to exit now?") )
	{
		Delete_MgmtSummary ();		// delete previous instance
		::HelpDisplay (winHwnd(), ::helpPath, HELP_QUIT, 0); // close help

		// do the exit now
		inExit = true;
		vApp::Exit ();
	}
}

// ----------------------------------------------------------------------------
//	TCMIApp functions
// ----------------------------------------------------------------------------

//	DisplayMsg
//	Writes message to message window and displays message in message dialog.
void TCMIApp::DisplayMsg (
	char const * const title,	// window title
	char const * const msg) const	// the message
{
	// 1. write to message window
	messageWindow->Text ( title );
	messageWindow->Text ( msg );
	// 2. user dialog message box
	vNoticeDialog dlg ( (TCMIApp*)this, title);
	dlg.Notice ( msg );
}

//	DisplayMsg
//	Writes message to message window and displays message in message dialog.
void TCMIApp::DisplayMsg (
	char const * const title,	// window title
	std::string const & msg) const	// the message
{
	DisplayMsg ( title, msg.c_str() );
}

//	ConfigureCentury
//	Setup a Century configuration.
//	Returns false if successful, else true if failed or error.
bool TCMIApp::ConfigureCentury (
	int const argc,
	char const * const * const argv)
{
	bool failed = false;
	char const * const errorTitle = "\nCentury Configuration Error";
	try
	{
		//--- Get command line arguments
		cmdLine.reset (
		    new TCenturyCmdLine (
			argc,
			const_cast<char const * const * const>(argv),
			configInfo,
			true, false ) );
		if ( cmdLine->GetMessageCount() > 0 )
			MsgText ( cmdLine->GetMessages().c_str() );
		if ( cmdLine->ArgError() )
			MsgText ("Error in the command line options.");

		//--- Setup the Century configuration

		// Get the executable path
		std::string exePath = TEH::ActualPath (argv[0]);
		Assert (!exePath.empty());

		// Check for an .INI file
		std::string workPath;
		std::string userName = configInfo.GetUserName();
		if ( !cmdLine->GetIniFile().empty() )
		{
			::userPref.SetIniFile ( cmdLine->GetIniFile() );
			if ( userPref.ReadIniFile() )
			{
				// warning message
				MsgText (
				  "Could not read the initialization file.");
			}
			else
			{
			    workPath = userPref.GetWorkPath().GetFullPath();
			    userName = userPref.GetName();
			}
		}
		configInfo.SetUserName (userName);

		// set defaults
		TAsynchCommunication asynchCom (
			::DisplayToMsgWindow,		// message function
			::DisplayToMsgWindow,		// warning function
			::UpdateProgressDialog);	// sim. year function
			// ::DoTimeSlice );		// time slice function

		// build config object
		::centuryConfig.reset (
		    new TCenturyConfig (
			configInfo.GetSiteFileName(),
			configInfo.GetManagementFileName(),
			configInfo.GetOutputFileName(),
			configInfo.GetOutputType(),
			configInfo.GetOutputAccess(),
			configInfo.ProduceOutput(),
			exePath,		// home or "exe" path
			workPath,		// path to work files
			"",			// parameters path (use default)
			configInfo.GetParameterSearchPaths(),
			"",			// templates path (use default)
			"",			// textdata path (use default)
			configInfo.GetFixFileName(),
			configInfo.GetUserName(),
			&asynchCom ) );

		//--- Setup default directories
		// Copy default paths ptr to a global object for easy access
		::defPaths = ::centuryConfig->GetPaths();
		// work path in user prefs.?
		if ( workPath.empty() )				// empty?
			::userPref.SetWorkPath (
				::defPaths->GetPath(CenturyPaths::Work) );
		// user name into user prefs.?
		if ( configInfo.GetUserName().empty() )				// empty?
			::userPref.SetName (
				::centuryConfig->GetUserName().c_str() );

		// help file path
		::helpPath = ::defPaths->GetPath (CenturyPaths::Executable);
		::helpPath += ::helpFileName;

		// Error checks
#ifdef NDEBUG
		if ( myApp.CheckAppPaths () )
			return 1;			// terminate app now
#else
		myApp.CheckAppPaths ();			// message; continue on
#endif
		// config can fail if no site or mgmt. are supplied,
		// but that's ok.
		// ::centuryConfig->FindAndThrowError ();	// check for errors

		// Initial user messages
		MsgText ("Ready.\n");
	}
	catch (TCentException const & ce)	// exceptions thrown by Century
	{
		DisplayMsg ( errorTitle, ce.GetMsg() );
		failed = true;
	}
	catch (nrel::weather::WeatherException const & e)
	{
		string msg (
			"A weather dataset error "
			"terminates the simulation.\nError is: ");
		msg += e.what();
		DisplayMsg ( errorTitle, msg );
		failed = true;
	}
	catch (nrel::site::SiteException const & e)
	{
		string msg (
			"A site parameter set error "
			"terminates the simulation.\nError is: ");
		msg += e.what();
		DisplayMsg ( errorTitle, msg );
		failed = true;
	}
	catch (std::exception const & e)	// other exceptions (elaborate!)
	{
		string msg (
			"An error occurred during initialization.\nError is: ");
		msg += e.what();
		DisplayMsg ( errorTitle, msg );
		failed = true;
	}
	catch ( CenturyPaths::TDefPathErr pathErr )
	{
		char const* errStr[] =
		{
			"no error",
			"no path",
			"invalid path index",
			"invalid executable file path",
			"invalid parameters path",
			"invalid templates path",
			"invalid management library path",
			"invalid site library path",
			"invalid block library path",
			"memory allocation failed",
			"unknown error",
			0
		};
		string msg ("Directory path error: ");
		msg += errStr[pathErr];
		DisplayMsg ( errorTitle, msg );
		failed = true;
	}
	catch (char const * const aMsg)
	{
		DisplayMsg ( errorTitle, aMsg );
		failed = true;
	}
	catch (std::string const & aMsg)
	{
		DisplayMsg ( errorTitle, aMsg );
		failed = true;
	}
	catch (...)			// anything else not caught
	{
		DisplayMsg ( errorTitle,
			"An unknown error terminates the simulation.");
		failed = true;
	}
	return failed;
}

//	IsReadyToRun
//	Returns true if have what is needed to run the simulation.
//	If not ready, displays a message to user explaining the problem.
bool TCMIApp::IsReadyToRun () const
{
	std::string msg;		// user message; 3 lines of 40 chars
	// line 1
	if ( !::centuryConfig->HaveSite() )
		msg = "Site parameters are not specified.\n";
	else if ( ::centuryConfig->GetSite()->IsEmpty() )
		msg = "Site parameter set is empty.\n";
	// line 2
	if ( !::centuryConfig->HaveManagement() )
		msg += "Site management is not specified.\n";
	else if ( ::centuryConfig->GetManagement()->IsEmpty () )
		msg += "Site management scheme is empty.\n";
	// line 3
	if ( msg.size() > 0 )			// is there a user message?
	{
		DisplayMsg ( "Simulation is not ready to run:", msg );
		return false;
	}
	return true;
}

//	RunCentury
//	Run the Century simulation using the current configuration.
//	Returns false if run w/out error, else true if error or canceled.
bool TCMIApp::RunCentury ()
{
	int exitCode = 0;		// simulation exit code
	char const * const errorTitle = "\nCentury Simulation Error";
	TDebugInfo debugInfo;
	debugInfo.execTime = true;	// execution elapsed time
	debugInfo.writeTime = true;	// display times

	if ( !IsReadyToRun() )				// ready to run?
		return true;				// ...no

	// run the simulation
	try			// exception-handling for the entire simulation
	{
		// check configuration
		if ( ::centuryConfig->HaveWarningMsg() )
		{
			std::string msg = "Configuration messages:\n";
			msg += ::centuryConfig->GetWarningMsg();
			MsgText ( msg.c_str() );
		}
		::centuryConfig->FindAndThrowError ();	// check for errors

		//--- initialize the model
		// 1. class instance
		haveFinishedSim = false;		// set flag
		if ( century.get() )			// already instantiated?
		{
		    // ::century->ClearForNewSimulation();
		    if ( ::centuryConfig->ProduceOutput() )
		    {
			if ( ::centuryConfig->GetOutput()->Reset() !=
			     TOutputBase::State_Open )
			{
				throw (
				  "Failed re-initializing the output file.");
			}
		    }
		}
		// else					// ...no
		{
			::century.reset (
				new TCentury (*::centuryConfig, debugInfo) );
		}

		//--- set up the progress bar dialog
		char const * const caption =
			"Century simulation is running.\n"
			"Press Cancel to stop the simulation.";
		char const * const prefix = "Year \n";
		std::ostringstream yrStartStr;
		yrStartStr
		    << prefix
		    << ::centuryConfig->GetManagement()->GetSimInfo().yearStart;
		std::ostringstream yrEndStr;
		yrEndStr
		    << prefix
		    << ::centuryConfig->GetManagement()->GetSimInfo().yearEnd;
		const char *title = "Simulation Status";
		::progDlg.reset (
			new TRunProgressDlg (this, caption,
				yrStartStr.str().c_str(),
				yrEndStr.str().c_str(),
				true, title, CA_Large) );
		::progDlg->UseCancelFunction ( ::PostCancelRequest );

		//--- run the simulation
		HistText ("Running the simulation. Output file is");
		HistText (
		    dynamic_cast<TCentOutFileBase*>(
			::centuryConfig->GetOutput().get() )->
				GetFileName().c_str() );
		if ( ::century->InitializeModel () )	// init failed?
			exitCode = 1;
		if ( exitCode == 0 )
		{
			if ( ::century->RunToCompletion() )	// run failed?
				exitCode = 1;			// ...no
		}
		if ( ::century->GetModelState().GetState() ==
		     TModelState::State_Completed )
			HistText ("Simulation completed successfully.");
		else
			HistText ("Simulation aborted.");
		::progDlg.reset ();	// close the progress dialog
		// display a notice that simulation has completed normally
		vNoticeDialog dlg (this, "Simulation Finished");
		dlg.Notice ("Your output file(s) "
			    "contain the simulation results.");

		// new site file?
		if ( exitCode == 0 && !cmdLine->GetNewSiteFile().empty() )
		{
			// write a site file
			if ( cmdLine->GetDebugInfo().verbose )
				::DisplayToMsgWindow (
					"Writing the new site file..." );
			bool failed = WriteSiteFile (
				cmdLine->GetNewSiteFile(),
				*::centuryConfig,
				*::century);
			if ( failed )
			{
				exitCode = 1;
				if ( cmdLine->GetDebugInfo().verbose )
					::DisplayToMsgWindow ( "Failed!" );
			}
			else
			{
				if ( cmdLine->GetDebugInfo().verbose )
					::DisplayToMsgWindow ( "Successful!" );
			}
		}
	}

	catch (TCentException const & ce)	// exceptions thrown by Century
	{
		::progDlg.reset ();	// close the progress dialog
		DisplayMsg ( errorTitle, ce.GetMsg().c_str() );
		exitCode = ce.GetCode();
	}

	catch (nrel::weather::WeatherException const & e)
	{
		::progDlg.reset ();	// close the progress dialog
		std::string msg (
			"A weather dataset error "
			"terminates the simulation.\nError is: ");
		msg += e.what();
		DisplayMsg ( errorTitle, msg );
		exitCode = 1;
	}

	catch (nrel::site::SiteException const & e)
	{
		::progDlg.reset ();	// close the progress dialog
		std::string msg (
			"A site parameter set error "
			"terminates the simulation.\nError is: ");
		msg += e.what();
		DisplayMsg ( errorTitle, msg );
		exitCode = 1;
	}

	catch (std::exception const & e)	// other exceptions (elaborate!)
	{
		::progDlg.reset ();	// close the progress dialog
		DisplayMsg ( errorTitle, e.what() );
		exitCode = 1;
	}

	catch ( CenturyPaths::TDefPathErr pathErr )
	{
		::progDlg.reset ();	// close the progress dialog
		char const* errStr[] =
		{
			"no error",
			"no path",
			"invalid path index",
			"invalid executable file path",
			"invalid parameters path",
			"invalid templates path",
			"invalid management library path",
			"invalid site library path",
			"invalid block library path",
			"memory allocation failed",
			"unknown error",
			0
		};
		std::string msg = "Directory path error: ";
		msg += errStr[pathErr];
		DisplayMsg ( errorTitle, msg.c_str() );
		exitCode = 1;
	}

	catch (char const * const aMsg)
	{
		::progDlg.reset ();	// close the progress dialog
		DisplayMsg ( errorTitle, aMsg );
		exitCode = 1;
	}

	catch (std::string const & aMsg)
	{
		::progDlg.reset ();	// close the progress dialog
		DisplayMsg ( errorTitle, aMsg.c_str() );
		exitCode = 1;
	}

	catch (...)			// anything else not caught
	{
		::progDlg.reset ();	// close the progress dialog
		DisplayMsg ( errorTitle,
				"An unknown error terminates the simulation.");
		exitCode = 1;
	}

	if ( exitCode == 0 )			// completed simulation ok?
		haveFinishedSim = true;		// ...yes
	else
	{
		haveFinishedSim = false;	// ...no
		HistText ("Simulation failed.");
	}
	return exitCode != 0;	// if zero, no error
}

//	ReadSite
//	Read the specified file name into the current site parameter object.
//	Returns false if successful, else true if error occurred.
bool TCMIApp::ReadSite (
	char const * const fileNameBase)
{
	if ( !fileNameBase )			// base name specified?
		return true;
	bool retVal = false;			// return value

	std::string msg;
	msg = "Selected the site parameter file:\n\"";
	msg += fileNameBase;
	msg += "\"";
	HistText ( msg.c_str() );

	// Retrieve the specified site parameters
	std::string exceptionMsg;
	try
	{
		::centuryConfig->UseSite ( std::string (fileNameBase) );
	}

	catch (TCentException const & ce)	// exceptions thrown by Century
	{
		exceptionMsg = ce.GetMsg();
		retVal = true;
	}

	catch (std::exception const & e)	// other exceptions (elaborate!)
	{
		exceptionMsg = e.what();
		retVal = true;
	}

	catch (char const * const aMsg)
	{
		exceptionMsg = aMsg;
		retVal = true;
	}

	catch (std::string const & aMsg)
	{
		exceptionMsg = aMsg;
		retVal = true;
	}

	catch (...)			// anything else not caught
	{
		exceptionMsg = "An unknown error reading the site parameters.";
		retVal = true;
	}


	if ( retVal ||
	     !::centuryConfig->HaveSite() ||		  // no pointer?
	     ::centuryConfig->GetSite()->IsEmpty() ||	  // anything there?
	     ::centuryConfig->GetSite()->GetBaseName().empty() ) // no base name
	{
		std::string errMsg;
		errMsg = "Error reading site parameters:\n\"";
		errMsg += fileNameBase;
		errMsg += "\"\nError message:\n";
		if ( exceptionMsg.size() > 0 )
			errMsg += exceptionMsg;
		else if ( ::centuryConfig->GetSite()->IsEmpty() )
			errMsg += "Site parameter sets are empty.";
		else
			errMsg += "No further information is available.";
		errMsg += "\nSite parameters were not read.";

		// display error message
		MsgText (errMsg.c_str());

		// clean up and return
		::centuryConfig->GetSite()->Clear ();
		retVal = true;
	}
	if ( !retVal )
	{
		MsgText ("Site parameters successfully retrieved.");
		// display description
		msg = "Current site parameter set description:\n\"";
		msg += ::centuryConfig->GetSite()->GetDescription();
		msg += "\"";
		HistText ( msg.c_str() );
	}
	return retVal;
}

//	ReadMgmt
//	Read the specified file name into the current management scheme.
//	Returns false if successful, else true if error occurred.
bool TCMIApp::ReadMgmt (
	char const * const fileNameBase)
{
	if ( !fileNameBase )			// anything there?
		return true;			// ...no
	bool retVal = false;			// return value

	std::string msg;
	msg = "Selected the management scheme file:\n\"";
	msg += fileNameBase;
	msg += "\"";
	HistText ( msg.c_str() );

	// open the selected management scheme
	std::string exceptionMsg;
	try
	{
		::centuryConfig->UseManagement (
			TSharedPtr<TManagementScheme> (
				new TManagementScheme (fileNameBase) ) );
		TEH::TFileName tmpltPath (
			::defPaths->GetPath (CenturyPaths::Templates),
			TEH::TFileName::FT_Directory );
		::centuryConfig->GetManagement()->SetPaths (
					&tmpltPath, &::userPref.GetWorkPath() );
	}

	catch (TCentException const & ce)	// exceptions thrown by Century
	{
		exceptionMsg = ce.GetMsg();
		retVal = true;
	}

	catch (std::exception const & e)	// other exceptions (elaborate!)
	{
		exceptionMsg = e.what();
		retVal = true;
	}

	catch (char const * const aMsg)
	{
		exceptionMsg = aMsg;
		retVal = true;
	}

	catch (std::string const & aMsg)
	{
		exceptionMsg = aMsg;
		retVal = true;
	}

	catch (...)			// anything else not caught
	{
		exceptionMsg = "An unknown error reading the management.";
		retVal = true;
	}

	// read the management scheme
	if ( retVal ||
	     !::centuryConfig->HaveManagement() ||	// no pointer?
	     ::centuryConfig->GetManagement()->IsEmpty() ||  // anything there?
	     !::centuryConfig->GetManagement()->
					GetBaseName() )	// base name saved?
	{
		// build error message
		std::string errMsg;
		errMsg = "Error reading management scheme:\n\"";
		errMsg += fileNameBase;
		errMsg += "\"\nError message:\n";
		if ( exceptionMsg.size() > 0 )
			errMsg += exceptionMsg;
		else
			errMsg +=
				::centuryConfig->GetManagement()->GetErrorMsg();
		errMsg += "\nManagement scheme was not read.";

		// display error message
		MsgText (errMsg.c_str());

		// clean up and return
		::centuryConfig->GetManagement()->Clear ();
		TEH::TFileName tmpltPath (
				::defPaths->GetPath(CenturyPaths::Templates),
				TEH::TFileName::FT_Directory );
		::centuryConfig->GetManagement()->SetPaths (
					&tmpltPath, &::userPref.GetWorkPath() );
		retVal = true;
	}
	if ( !retVal &&
	     ::centuryConfig->GetManagement()->GetSimDescription() )
	{
		MsgText ("Management successfully retrieved.");
		// display description
		msg = "Current management description:\n\"";
		msg += ::centuryConfig->GetManagement()->GetSimDescription();
		msg += "\"";
		HistText ( msg.c_str() );
	}
	return retVal;
}

//	WriteMgmt
//	Returns false if successful, else true if error occurred.
bool TCMIApp::WriteMgmt ()
{
	// error checks
	if ( !::centuryConfig->HaveManagement() )
		return true;

	bool retVal = false;

	// check if files exist; if so, verify overwite with user.
	if ( ::centuryConfig->GetManagement()->GetFile(MFT_Scheme).Exists() )
	{
		vYNReplyDialog ynDlg (this);
		int result;
		result = ynDlg.AskYN (
			"This management already exists on disk.\n\n"
			"Do you want to replace the contents with\n"
		  	"the displayed management scheme?");
		if ( result != 1 )		// cancel?
		{
			HistText ("Cancelled \"Save\".\n");
			return true;
		}
	}

	// Write the management scheme to the files.
	if ( ::centuryConfig->GetManagement()->Write() )	// failed?
	{
		// give user error message
		char const * const dlgTitle = "Error";
		char const * const msgParts[3] =
		{
			"Error write management scheme:\n\"",
			"\"\nError message: ",
			"\nManagement scheme was not saved to disk."  // last
		};
		std::string errMsg;
		errMsg += msgParts[0];
		errMsg += ::centuryConfig->GetManagement()->GetBaseName();
		errMsg += msgParts[1];
		errMsg += ::centuryConfig->GetManagement()->GetErrorMsg();
		errMsg += msgParts[2];
		MsgText ( errMsg.c_str() );
		vNoticeDialog dlg ( this, dlgTitle );
		dlg.Notice ( errMsg.c_str() );
		retVal = true;
	}
	else
		MsgText ("Management scheme was successfully saved.");
	return retVal;
}

//	InitialIniFileName
//	Determines the initial ".ini" file name.
//	Saves in the global variable "userPref".
void TCMIApp::InitialIniFileName (
	char const * const useIniFileName)
{
	// Check if an INI file already specified
	if ( !( ::userPref.GetIniFile().IsEmpty() ) &&		// have name?
	     ::userPref.GetIniFile().Exists() )			// file exists?
		return;						// ...yes

	char const * const theName =
		(useIniFileName && *useIniFileName) ?	// anything there?
		useIniFileName :			// ...yes, use it
		::userPref.GetDefaultIniFileName();	// ...no, get default
	TEH::TFileName tmpName (theName);

	// check the current directory first
	if ( tmpName.Exists() )
	{
		::userPref.SetIniFile (tmpName);
		if ( !::userPref.ReadIniFile() )	// successful?
			return;				// ...yes
	}

	// Check if the working directory has an INI file
	if ( !( ::userPref.GetWorkPath().IsEmpty() ) )		// have path?
	{
		// create a default name in the working directory
		TEH::TFileName tmpPath ( ::userPref.GetWorkPath() );
		tmpPath.SetName ( tmpName.GetName() );
		tmpPath.SetExtension ( tmpName.GetExtension() );
		// if exists, save it in the user preferences
		if ( tmpPath.Exists() )
		{
			::userPref.SetIniFile (tmpPath);
			::userPref.ReadIniFile ();
			return;
		}
	}

	// Check if the executable directory has an INI file
	char const* exePath =
		::defPaths->GetDefaultPath (CenturyPaths::Executable);
	if ( exePath )
	{
		// create a default name in the working directory
		TEH::TFileName tmpPath ( exePath,
					 TEH::TFileName::FT_Directory );
		tmpPath.SetName ( tmpName.GetName() );
		tmpPath.SetExtension ( tmpName.GetExtension() );
		// if exists, save it in the user preferences
		if ( tmpPath.Exists() )
		{
			::userPref.SetIniFile (tmpPath);
			::userPref.ReadIniFile ();
			return;
		}
	}

	// do a simple name and let the user figure things out from the
	// preferences editor
	::userPref.SetIniFile (tmpName);
}

//	CheckAppPaths
//	Checks the application paths to see if they exist.
//	If not, gives a message to the user
//	Returns false if all is ok, else true if a path doesn't exist.
bool TCMIApp::CheckAppPaths ()
{
	std::vector<bool> havePath;		// true if path exists
	havePath.resize (CenturyPaths::Work - CenturyPaths::Parameters);
	// size = TDefPathIdx::Work - TDefPathIdx::Parameters
	bool haveAllPaths = true;		// sum of all path flags

	// check the paths for existance
	short j = 0;				// index to havePath[]
	for ( CenturyPaths::TDefPathIdx i = CenturyPaths::Parameters;
		i < CenturyPaths::Work;
		i = (CenturyPaths::TDefPathIdx)(i + 1) )
	{
	    havePath[j] = ::defPaths->Exists (i);
	    haveAllPaths &= havePath[j];
            ++j;
	}

	if ( !haveAllPaths )			// found them all?
	{					// ...no
		vNoticeDialog dlg (this, "Application Startup Error");
		char msg[2048];
		strcpy (msg, "Folders required for this application "
				"were not found.\n"
			     "Please notify your system administrator "
				"of the following missing paths:\n\n");
		// add the path string to the message for each missing path
		for ( CenturyPaths::TDefPathIdx i = CenturyPaths::Parameters;
		      i < CenturyPaths::Work;
			i = (CenturyPaths::TDefPathIdx)(i + 1) )

		{
		    if ( !havePath[i] )
		    {
			strcat (msg,
				::defPaths->GetPath (
				    (CenturyPaths::TDefPathIdx)i ).c_str() );
			strcat (msg, "\n");
		    }
		}
#ifdef NDEBUG
		strcat (msg, "\nThis application will terminate now.");
#endif
		dlg.Notice (msg);
		return true;
	}
	return !haveAllPaths;
}

void TCMIApp::DisplayStatus () const
{
	if ( !messageWindow )		// should never occur
		return;

	const char *notSpecStr = "not specified.";
	const char *isStr = " is ";

	std::string msg;				// text to display
	msg += "---------- Simulation Status ----------";

	// user preferences
	msg += "\nYour Preferences";
	if ( userPref.IsEmpty() )
	{
		msg += " are ";
		msg += notSpecStr;
	}
	else
	{
		msg += "\n   Name: ";
		if ( !::userPref.GetName().empty() )
			msg += ::userPref.GetName();
		else
			msg += notSpecStr;

		msg += "\n   Site library folder: ";
		std::string const sitesPath =
			::userPref.GetSitesPath().GetFullPath ();
		if ( !sitesPath.empty() )
			msg += sitesPath;
		else
			msg += notSpecStr;

		msg += "\n   Management library folder: ";
		std::string const mgmtLibPath =
			::userPref.GetMgmtPath().GetFullPath ();
		if ( !mgmtLibPath.empty() )
			msg += mgmtLibPath;
		else
			msg += notSpecStr;

		msg += "\n   Work folder: ";
		std::string const workPath =
			::userPref.GetWorkPath().GetFullPath ();
		if ( !workPath.empty() )
			msg += workPath;
		else
			msg += notSpecStr;

		msg += "\n   Preferences File: ";
		std::string const preferencesFile =
			::userPref.GetIniFile().GetFullPath ();
		if ( !preferencesFile.empty() )
			msg += preferencesFile;
		else
			msg += notSpecStr;

		if ( ::userPref.IsModified() )
			msg += "\n   Preferences have been modified"
				" but not saved.";
	}

	// site parameters
	msg += "\nSite Parameter Set";
	if ( ::centuryConfig->HaveSite() &&
	     !::centuryConfig->GetSite()->IsEmpty() )
	{
		msg += "\n   Type: ";
		msg += ::centuryConfig->GetSite()->GetSiteTypeStr();
		msg += "\n   Name: ";
		if ( !::centuryConfig->GetSite()->GetName().empty() )
			msg += ::centuryConfig->GetSite()->GetName();
		else
			msg += notSpecStr;
		msg += "\n   Description: ";
		if ( !::centuryConfig->GetSite()->GetDescription().empty() )
			msg += ::centuryConfig->GetSite()->GetDescription();
		else
			msg += notSpecStr;
		msg += "\n   File Name: ";
		if ( !::centuryConfig->GetSite()->GetBaseName().empty() )
			msg += ::centuryConfig->GetSite()->GetBaseName();
		else
			msg += notSpecStr;
		if ( ::centuryConfig->GetSite()->IsModified() )
			msg += "\n   Site parameter set has been "
				     "modified but not saved.";
	}
	else
	{
		msg += isStr;
		msg += notSpecStr;
	}

	// site management
	msg += "\nSite Management";
	if ( ::centuryConfig->HaveManagement() )
	{
		msg += "\n   Simulation Description: ";
		if ( ::centuryConfig->GetManagement()->GetSimDescription() )
			msg +=
			  ::centuryConfig->GetManagement()->GetSimDescription();
		else
			msg += notSpecStr;
		if ( ::centuryConfig->GetManagement()->IsEmpty() )
			msg += "\n   No blocks have been defined.";
		msg += "\n   File Name: ";
		if ( ::centuryConfig->GetManagement()->GetBaseName() )
			msg += ::centuryConfig->GetManagement()->GetBaseName();
		else
			msg += notSpecStr;
		msg += "\n   Management scheme has ";
		if ( ::centuryConfig->GetManagement()->IsModified() )
			msg += "been modified but not saved, and ";
		if ( ::centuryConfig->GetManagement()->IsVerified() )
			msg += "been verified.";
		else
			msg += "not been verified.";
	}
	else
	{
		msg += isStr;
		msg += notSpecStr;
	}

	// output file
	msg += "\nSimulation Output File";
	if ( ::centuryConfig->HaveOutput() )
	{
		TSharedPtr<TCentOutFileBase> outputPtr =
			::centuryConfig->GetOutput();
		msg += "\n   Name: ";
		msg += outputPtr->GetFileName();
		msg += "\n   Type: ";
		msg += ::oFFDescrip[outputPtr->GetOutputType()];
	}
	else
	{
		msg += isStr;
		msg += notSpecStr;
	}

	// simulation run status
	if ( haveFinishedSim )
	{
		// write to msg in case want to add more info later
		msg += "\nSimulation completed successfully.\n";
	}
	else
	{
		// write to msg in case want to add more info later
		msg += "\nSimulation has not been run.\n";
	}

	msg += "---------- End Status ----------";
	MsgText ( msg.c_str() );
}

//	DisplayAbout
//	Display the About modal dialog.
void TCMIApp::DisplayAbout () const
{
	//TAboutDialog dlg (this);
	TAboutDialog dlg (myApp.historyWindow);
}

//	Display_MgmtSummary
//	Displays a summary of the currently active management scheme and
//	site parameters.
//	Parameter displayNow should be true only upon call from
//	the menu selection, and false for all dialog display updates.
void TCMIApp::Display_MgmtSummary (
	bool const createIfNeeded)
{
	// anything to display?
	if ( !::centuryConfig->HaveManagement() )
	{
		if ( mgmtSummaryDlg.get() != 0 )
			mgmtSummaryDlg.reset ();
		vNoticeDialog nd (this);
		nd.Notice ("Management has not been specified.");
		return;
	}

	if ( mgmtSummaryDlg.get() == 0 && createIfNeeded )
	{
		mgmtSummaryDlg.reset (
			new TMgmtSummaryDlg (
				this, *::centuryConfig->GetManagement() ) );
	}
	if ( mgmtSummaryDlg.get() != 0 )
		mgmtSummaryDlg->UpdateList ();
}

//	Delete_MgmtSummary
//	Delete the display of the mgmt summary dialog.
void TCMIApp::Delete_MgmtSummary ()
{
	mgmtSummaryDlg.reset ();
}

//--- end of definitions for TCMIApp ---
