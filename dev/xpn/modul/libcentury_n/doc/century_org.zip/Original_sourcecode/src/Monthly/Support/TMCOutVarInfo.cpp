// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TMCOutVarInfo.cpp
//	Class:	  TMCOutputVariableInfo
//
//	Description:
//	Reads names and descriptions of the Century output variables
//	from the netCDF file, OutVarInfo,nc / OutVarInfo.cdl.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Sep98
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TMCOutVarInfo.h"
#include "TNcFileOutVarDef.h"
#include "charutil.h"

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

TMCOutputVariableInfo::TMCOutputVariableInfo (
	TEH::TFileName const & outVarDefsPath)
{
	Initialize ();
	if ( ReadNamesDescs (outVarDefsPath) )		// read it now
	{
		// need error handling here
		return;
	}
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	GetNameList
//	Returns a NULL-terminated list of output variable names.
// inline
char const** TMCOutputVariableInfo::GetNameList (TOVICategory which) const
{
	char** retVal = 0;
	// Note: using if-else here because Borland C++ 5 does not expand
	// switch statements inline.
	if ( which == WaterTemp )
		retVal = wtNames;
	else if ( which == SoilC )
		retVal = soilNames;
	else if ( which == CropGrassC )
		retVal = cgNames;
	else if ( which == ForestC )
		retVal = forestNames;
	else if ( which == CO2 )
		retVal = co2Names;
	else if ( which == NPS )
		retVal = npsNames;
	return const_cast<char const**>(retVal);
}

//	GetDescList
//	Returns a NULL-terminated list of output variable descriptions.
// inline
char const** TMCOutputVariableInfo::GetDescList (TOVICategory which) const
{
	char** retVal = 0;
	// Note: using if-else here because Borland C++ 5 does not expand
	// switch statements inline.
	if ( which == WaterTemp )
		retVal = wtDescs;
	else if ( which == SoilC )
		retVal = soilDescs;
	else if ( which == CropGrassC )
		retVal = cgDescs;
	else if ( which == ForestC )
		retVal = forestDescs;
	else if ( which == CO2 )
		retVal = co2Descs;
	else if ( which == NPS )
		retVal = npsDescs;
	return const_cast<char const**>(retVal);
}

//	GetListSize
//	Returns the number of items in the list for the
//	specified output variable category.
// inline
short TMCOutputVariableInfo::GetListSize (
	TOVICategory which) const
{
	short retVal = 0;
	// Note: using if-else here because Borland C++ 5 does not expand
	// switch statements inline.
	if ( which == WaterTemp )
		retVal = wtCount;
	else if ( which == SoilC )
		retVal = soilCount;
	else if ( which == CropGrassC )
		retVal = cgCount;
	else if ( which == ForestC )
		retVal = forestCount;
	else if ( which == CO2 )
		retVal = co2Count;
	else if ( which == NPS )
		retVal = npsCount;
	return retVal;
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	Clear
// 	clear member data
void TMCOutputVariableInfo::Clear ()
{
	// delete mem for parameter names and descriptions (only here!)
	::DeleteNTCStringList (categories);
	::DeleteNTCStringList (wtNames);
	::DeleteNTCStringList (wtDescs);
	::DeleteNTCStringList (soilNames);
	::DeleteNTCStringList (soilDescs);
	::DeleteNTCStringList (cgNames);
	::DeleteNTCStringList (cgDescs);
	::DeleteNTCStringList (forestNames);
	::DeleteNTCStringList (forestDescs);
	::DeleteNTCStringList (co2Names);
	::DeleteNTCStringList (co2Descs);
	::DeleteNTCStringList (npsNames);
	::DeleteNTCStringList (npsDescs);
	Initialize ();
}

//	ReadNamesDescs
//	Reads in the names and descriptions of the output variables
//	from the specified netCDF file name.
//	Stores in member variables.
bool TMCOutputVariableInfo::ReadNamesDescs (
	TEH::TFileName const & outVarDefsPath)
{
	TNcFileOutVarDef nc (outVarDefsPath);	// class to access netCDF data
	if ( nc.Read (*this) )
	{
		Clear ();
		// To do: retrieve ncErrStr from "nc" and throw or save
		// See TMCSiteParameters::ReadNcFile for an example.
		return true;				// failed
	}
	else
		return false;				// successful
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Initialize
//	initialize members
void TMCOutputVariableInfo::Initialize ()
{
	wtNames = wtDescs = soilNames = soilDescs =
	  cgNames = cgDescs = forestNames = forestDescs =
	  co2Names = co2Descs = npsNames = npsDescs =
	  categories = 0;
	wtCount = soilCount = cgCount = forestCount =
	  co2Count = npsCount = 0;
}

//--- end of definitions for TMCOutputVariableInfo ---
