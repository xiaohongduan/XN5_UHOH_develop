// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TCmdWinBaseMenuResults.cpp
//	Class:	  TCmdWinBase
//	Function: DoMenuEvent_Results
//
//	Description:
//	Processes selection events from the "Results" Drop-Down Menu.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Aug98
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------

#include "TCmdWinBase.h"
#include "externals.h"
//#include "TSelectOutVarsDlg.h"

void TCmdWinBase::DoMenuEvent_Results (ItemVal itemId)
{
	switch (itemId)
	{
	  case M_Res_View:	// View results - not currently used
		break;
	  case M_Res_Plot:	// Plot results - not currently used
		break;
	  case M_Res_Export:	// Export results - not currently used
		break;
	  case M_Res_Browse:	// Browse results files - not currently used
		break;
	  default:
		break;
	}
	ActionMsg ("Idle");
}
