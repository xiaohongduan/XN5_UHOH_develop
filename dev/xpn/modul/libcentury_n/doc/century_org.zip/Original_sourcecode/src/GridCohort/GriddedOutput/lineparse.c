
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include <string.h>

void
lineparse(char *line, float value[], int maxval)
{
	char *cptr;
	int i;


	/* printf("lineparse: %s\n", line); */
	cptr = strtok(line, " ");
	sscanf(cptr, "%f", &value[0]);
	/* printf("%2d  %4.1f\n", 0, value[0]); */

	i = 1;
	while (((cptr = strtok((char*)NULL, " ")) != (char*)NULL) &&
		 i < maxval)
	{
		sscanf(cptr, "%f", &value[i]);
		/* printf("%2d  %4.1f\n", i, value[i]); */
		i++;
	}

	return;
}
