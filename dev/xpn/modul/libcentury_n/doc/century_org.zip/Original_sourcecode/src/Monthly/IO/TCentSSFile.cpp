// ----------------------------------------------------------------------------
//	Copyright 1999-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCentSSFile.cpp
//	Class:	  TCentSprShtFile
//
//	Description:
//	Century output file class which builds an ASCII file containing
//	Century output variables in a comma-delimited format,
//	which can be imported into a spreadsheet.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Jan99
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TCentSSFile.h"
#include "TManagement.h"
#include "TMCSiteParameters.h"
#include "version.h"
#include "timeutil.h"
using namespace std;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

short const TCentSprShtFile::numMonthlySets =  6;
char const * const
	TCentSprShtFile::suffix[] =			// file name suffixes
	{ "wt", "soilC", "cropC", "forestC", "co2", "nps", 0 };
char const * const
	TCentSprShtFile::extenstion[3] = 	// default file extensions
	{
	  // correspond to TOutputBase::TFileFormat - 2
	  "csv", "prn", "txt"
	};
const char TCentSprShtFile::separator[3] =		// item separators
	{
	  // correspond to TOutputBase::TFileFormat - 2
	  ',', ' ', '\t'
	};

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

TCentSprShtFile::TCentSprShtFile (
	std::string const & useFileName, 	// file name instance
	TOutputBase::TAccessMode const useAccess,	// file access mode
	TOutputBase::TFileFormat const useFormat,	// file format type
	TManagementScheme & useMgmt,		// simulation mgmt. scheme
	TMCSiteParameters & useSite,		// site parameter set
	std::string const & useUserName,	// user name for output file
	TEH::TFileName const & useOVDefFile)	// name+path to netCDF file with
						//   the names and definitions
						//   of the output variables.
	: TMCOutputFileBase (
		useFileName, Type_CSV, useAccess, useFormat,
		useMgmt, useSite, useUserName, useOVDefFile )
{
	Initialize ();
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	WriteRecord
//	Write one record to the file stream.
//	Returns false if successful, else true if failed or error.
//	Notes:
//	The output variables are organized into variable sets;
//	each set gets its own file. The order of writing the files is the same
//	as the order of the categories in OutVarsDef.cdl and the
//	enum TOVICategory in common/T_OutVarInfo.h.
bool TCentSprShtFile::WriteRecord (
	float const simTime)		//   simulation time
{
	if ( !state == State_Open )	// not open?
		if ( Open() )		// Open failed?
			return true;	// ...yes

	short const numSets = outputSetList.size();
	for ( short outputSet = 0; outputSet < numSets; ++outputSet )
	{
		ofstream* const ps = os[outputSet];	// current stream
		//--- Get list of values and the size of the list
		float ** p =				// ptr to data array
			outputSetList[outputSet]->p;
		short numValues = outputSetList[outputSet]->GetNumValues ();
		//--- write data
		char const sepChar = 			// separator character
			separator[fileFormat - 2];
		if ( !(*ps << simTime << sepChar) )	// simulation time
		{
	    		errorState = Error_WriteFailed;
	    		return true;			// write failed
		}
		register short lastOne = numValues - 1;
		for ( short i = 0; i < numValues; ++i )	// write data array
		{
			if ( !(*ps << **(p++)) )
			{
	    			errorState = Error_WriteFailed;
	    			return true;		// write failed!
			}
			if ( i != lastOne )		// if not last item,
			{
				if ( !(*ps << sepChar) )    // separator char
				{
		    			errorState = Error_WriteFailed;
	    				return true;		// write failed
				}
			}
		}
		*ps << endl;
	}
	++lastRecord;			// increment record number

	// all done!
	modified = true;		// files have been modified
	return false;			// successful write
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Initialize
// 	initialize members
void TCentSprShtFile::Initialize ()
{
	Close ();		// make sure the streams are closed.
}

//	MakeFileName
//	Creates a new file name given the root and suffix.
//	The two parts are concatinated, separated by a hyphen.
//	Returns the string.
std::string TCentSprShtFile::MakeFileName (
	char const * const root, 	// file name root
	char const * const suffix)	// file name suffix
{
	// error checks
	if ( !root || !(*root) )		// anything there?
	{
		errorState = Error_InvalidFile;
		return 0;
	}
	Assert (suffix != 0);

	// create new name
	string newName (root);
	newName += '.';
	newName += suffix;
	return newName;
}

//	WriteHeader
// 	Write file header to stream
bool TCentSprShtFile::WriteHeader (
	ofstream & fs,		// file stream
	char const * const category,	// category description
	char const * const * colHeads,	// array of column headers
	short const count)		// size of array
{
	char const sepChar = separator[fileFormat - 2];	// separator character
	char const quote = '"';				// quote character
	char const * const  blankCell = "\"\"";		// blank cell
	char const EOL = '\n';				// end of line char.

	// write output variable set title
	fs << quote << CenturyName << quote << EOL;
	if ( !fs )				// check if stream is still OK
	{
		errorState = Error_WriteFailed;
		return true;			// it's not
	}
	fs << quote << CenturyVersion << quote << EOL << EOL;
	if ( !fs )				// check if stream is still OK
	{
		errorState = Error_WriteFailed;
		return true;			// it's not
	}
	fs << quote << "Simulation Description: " << quote << sepChar
	   << blankCell << sepChar
	   << quote << mgmt.GetSimDescription() << quote
	   << EOL;
	if ( !fs )				// check if stream is still OK
	{
		errorState = Error_WriteFailed;
		return true;			// it's not
	}
	fs << quote << "Managment Scheme File: " << quote << sepChar
	   << blankCell << sepChar
	   << quote << mgmt.GetBaseName() << quote
	   << EOL;
	if ( !fs )				// check if stream is still OK
	{
		errorState = Error_WriteFailed;
		return true;			// it's not
	}
	fs << quote << "Site Parameters File: " << quote << sepChar
	   << blankCell << sepChar
	   << quote << site.GetBaseName() << quote
	   << EOL;
	if ( !fs )				// check if stream is still OK
	{
		errorState = Error_WriteFailed;
		return true;			// it's not
	}
	fs << quote << "Site Description: " << quote << sepChar
	   << blankCell << sepChar
	   << quote << site.GetDescription() << quote
	   << EOL;
	if ( !fs )				// check if stream is still OK
	{
		errorState = Error_WriteFailed;
		return true;			// it's not
	}
	fs << quote << "Simulation run by " << quote << sepChar
	   << blankCell << sepChar
	   << quote << userName << quote
	   << EOL;
	if ( !fs )				// check if stream is still OK
	{
		errorState = Error_WriteFailed;
		return true;			// it's not
	}
	fs << quote << "Date of simulation: " << quote << sepChar
	   << blankCell << sepChar
	   << quote << ::DateTimeStr().c_str() << quote
	   << EOL << EOL;
	if ( !fs )				// check if stream is still OK
	{
		errorState = Error_WriteFailed;
		return true;			// it's not
	}
	fs << quote << "Output variables for " << quote << sepChar
	   << blankCell << sepChar
	   << quote << category << quote
	   << EOL << EOL;
	if ( !fs )				// check if stream is still OK
	{
		errorState = Error_WriteFailed;
		return true;			// it's not
	}

	// write column heads
	fs << quote << "Time" << quote << sepChar;
	register short lastOne = count- 1;
	for ( short i = 0; i < count; ++i )
	{
		fs << quote << *colHeads << quote;	// write col header
		if ( !fs )				// check stream state
		{
			errorState = Error_WriteFailed;
			return true;			// write failed!
		}
		++colHeads;				// next header
		if ( i != lastOne )			// if not last item,
			if ( !(fs << sepChar) )		// separator char
			{
				errorState = Error_WriteFailed;
				return true;		// write failed!
			}
	}
	if ( !(fs << endl) )
	{
		errorState = Error_WriteFailed;
		return true;				// write failed!
	}
	return false;
}

//	DoOpen
//	Open the output file.
//	Return state of output engine..
//	Assumes that the site parameters and management scheme is already
//	specified in the member pointers.
TCentSprShtFile::TState TCentSprShtFile::DoOpen ()
{
	Assert (ovi.get());

	// if already open, close it
	if ( state == State_Open )
		Close ();

	// get access mode specifier for stream
	std::ios_base::openmode mode;
	switch ( accessMode )
	{
	  // case New:	mode = ios::noreplace;		break; // obsolete
	  case Mode_New:
	  {
		// check for file existence
		TEH::TFileName tempName (fileName.c_str());
		if ( tempName.Exists() )
		{
			errorState = Error_OpenFailed;
			return state;
		}
		mode = ios::out;
		break;
	  }
	  case Mode_Replace:	mode = ios::out | ios::trunc;	break;
	  case Mode_Append:	mode = ios::out | ios::app;	break;
	  default:	errorState = Error_InvalidAccess;	return state;
	}

	// allocate memory for the file streams
	Assert (outputSetList.size() == numMonthlySets);
	short const numFiles = outputSetList.size();
	os.assign (numFiles, 0);
	if ( os.size() != (unsigned int)numFiles )	// allocation failed?
	{
		errorState = Error_MemoryAlloc;
		return state;
	}

	// open the files
	TEH::TFileName newName (fileName.c_str());	// use for new name
	string const root (newName.GetName());		// name root
	for ( short i = 0; i < numFiles; ++i )
	{
		// get next file name
		string const name =
			MakeFileName (root.c_str(), suffix[i]);	// new name
		if ( name.empty() )				// failed?
		{
			errorState = Error_InvalidFile;
			return state;
		}
		newName.SetName ( name.c_str() );		// change name
		newName.SetExtension (extenstion[fileFormat - 2]);// & extension
		std::string const fullPath = newName.GetFullName ();
		if ( fullPath.empty() )				// failed?
		{
			errorState = Error_MemoryAlloc;
			return state;
		}

		// open stream
		os[i] = new ofstream (fullPath.c_str(), mode);
		if ( !os[i]->is_open() )			// open failed?
		{
			errorState = Error_OpenFailed;
			return state;
		}
		os[i]->setf (ios::scientific);
		os[i]->precision (5);
	}
	state = State_Open;

	// write description and column headers for each file
	char const** category = ovi->GetCategories ();	// variable set names
	for ( short f = 0; f < numFiles; ++f )		// for each file...
		WriteHeader ( *os[f], category[f],
			      const_cast<char const**>(
			      	ovi->GetNameList ((TOVICategory)f) ),
			      ovi->GetListSize ((TOVICategory)f) );

	// all done!
	return state;
}

//	DoClose
//	Close the output file.
//	Return state of output engine.
TCentSprShtFile::TState TCentSprShtFile::DoClose ()
{
	if ( os.size() > 0 )
	{
		short const numStreams = outputSetList.size();
		for ( short i = 0; i < numStreams; ++i ) // delete each stream
		{
			// this doesn't just rely upon the destructor of the
			// stream to close everything, in case the version
			// of the std::library has problems.
			if ( os[i]->is_open() )
				os[i]->close();
			delete os[i];
			os[i] = 0;
		}
		os.clear();				// delete stream array
		state = State_Closed;
	}
	return state;
}

//	DoReset
//	Reset the output file to its initialized state.
//	Return state of output engine.
TCentSprShtFile::TState TCentSprShtFile::DoReset ()
{
	Close ();
	accessMode = Mode_Replace;
	Open ();
	if ( state != State_Open || errorState != Error_NoError )
	{
		Assert (state == State_Open);
		Assert (errorState == Error_NoError);
		// To do: Handle DoReset Open failed
	}
	return state;
}

//--- end of definitions for TCentSprShtFile ---
