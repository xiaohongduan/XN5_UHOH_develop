// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  co2eff.cpp
//	Class:	  TCenturyBase
//	Function: AtmCO2Effect
//
//	Description:
//	Compute the effect of atmospheric CO2 concentration on
//	production, PET, C/E, root/shoot.
// ----------------------------------------------------------------------------
//	History:
//	Jan00	Tom Hilinski, tom.hilinski@colostate.edu
//	* General cleanup and optimization.
//	* Fix use of step vs. ramp function.
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "TCenturyMath.h"

inline float CalcEffect (
	float const co2input,	//
	float const co2conc)	//
{
    // Reference co2 concentration = 350.0 at 1.0
    // Fortran: 1 + (co2input-1) / (log10(2.0))*(log10(co2conc/350.0))
    // constants used:
    //	1/350 = 2.857142857e-3
    //	1/log10(2.0) =   3.321928094887
    return 1.0 + (co2input - 1.0) * 3.321928094887 *
    			std::log10(co2conc * 2.857142857e-3);
}

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::AtmCO2Effect (
	float const time)	// simulation time in "year.yearfraction".
{
    // Reset all effects to 1.0
    for (short system = CRPSYS; system <= FORSYS; ++system) // for crop, tree
    {
	co2.co2cpr[system] = co2.co2ctr[system] = co2.co2crs[system] = 1.0f;
	for (short mnmx = 0; mnmx < 2; ++mnmx)		// for minimum, maximum
	    for (short e = 0; e < site.nelem; ++e)	// for N, P, S
	    {
		co2cce_ref(system, mnmx, e) = 1.0f;
	    }
    }

    if ((int)param.co2sys == 0)    // If there is no co2 effect, return;
	return;

    //--- co2 concentration
    float co2conc;		// CO2 concentration
    if ( time <= param.co2tm[0] )		// time < start of effect?
	co2conc = fixed.co2ppm[0];		// ...use initial concentration
    else if ((int)fixed.co2rmp == 0)		// Use step function?
	co2conc = fixed.co2ppm[1];		// ...use final concentration
    else					// Ramping
    {
	if ( time < param.co2tm[1] )
	{
		co2conc = ramp (time, param.co2tm[0], fixed.co2ppm[0],
					param.co2tm[1], fixed.co2ppm[1]);
	}
	else	// at end of year so use final value
	{
		co2conc = fixed.co2ppm[1];
	}
    }

    //--- effect on production
    co2.co2cpr[CRPSYS] = ::CalcEffect (param.co2ipr[CRPSYS], co2conc);
    co2.co2cpr[FORSYS] = ::CalcEffect (param.co2ipr[FORSYS], co2conc);

    //--- effect on PET
    co2.co2ctr[CRPSYS] = ::CalcEffect (param.co2itr[CRPSYS], co2conc);
    co2.co2ctr[FORSYS] = ::CalcEffect (param.co2itr[FORSYS], co2conc);

    //--- effect on C/E due to atm. CO2 doubling from 350 to 750 ppm
    for (short e = 0; e < site.nelem; ++e)		// for N, P, S
	for (short mnmx = 0; mnmx < 2; ++mnmx)		// for minimum, maximum
	    for (short system = CRPSYS; system <= FORSYS; ++system)
	    {
		co2cce_ref (system, mnmx, e) =
			::CalcEffect (co2ice_ref(system, mnmx, e), co2conc);
	    }

    //---- effect on root/shoot
    // Reference co2 concentration = 350.0 at 1.0
    co2.co2crs[CRPSYS] =
	YOnLine (co2conc, 350.0f, 1.0f, 700.0f, param.co2irs[CRPSYS]);
    co2.co2crs[FORSYS] =
	YOnLine (co2conc, 350.0f, 1.0f, 700.0f, param.co2irs[FORSYS]);
}

//--- end of file co2eff.cpp ---
