// ----------------------------------------------------------------------------
//	Copyright 1999-2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TDefPaths.cpp
//	Class:	  CenturyPaths
//
//	Description: See header file.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Feb99
//	History: See header file.
// ----------------------------------------------------------------------------

#include "CenturyPaths.h"
#if defined(_Windows) || defined(__WIN32__) || defined(MSWINDOWS)
  #include <windows.h>
#else
  // *nix
  #include <cstdlib>
#endif

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

char const * const CenturyPaths::defaultPaths[] =  // list of default paths
{
	".",		// executable path (should be set!)
	"parameter",	// default parameter files path
	"template", 	// default template files path
	"textdata",	// text data files for model
	"sitelib",  	// default managment library path
	"blocklib", 	// default site library path
	"mgmtlib",  	// default block library path
	".",        	// default working directory
	0		// LAST ONE ALWAYS
};

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

CenturyPaths::CenturyPaths (
	std::string const & useExePath,	// home or "exe" path
	std::string const & useParamPath,	// path to parameters
	std::string const & useTemplatePath,	// path to templates
	std::string const & useTextDataPath,	// path to text data
	std::string const & useSiteLibPath,	// path to site library
	std::string const & useBlockLibPath,	// path to mgmt block library
	std::string const & useMgmtLibPath,	// path to mgmt library
	std::string const & useWorkPath,	// path to work files
	std::string const & useSubdirectory)	// subdirectory name
	: subdirectory (useSubdirectory),
	  error (NoError),
	  errorPathIndex (NumberOfPaths),
	  modified (false)
{
	actualPaths.resize (NumberOfPaths);
	// save paths
	SetPath (useExePath, Executable);
	UseDefaultPaths ();
	SetPath (useParamPath, Parameters);
	SetPath (useTemplatePath, Templates);
	SetPath (useTextDataPath, TextData);
	SetPath (useSiteLibPath, SiteLib);
	SetPath (useBlockLibPath, BlockLib);
	SetPath (useMgmtLibPath, MgmtLib);
	SetPath (useWorkPath, Work);
	// modify the default paths for the correct subdirectory
	AppendToDefaultSubdirectory (Parameters, subdirectory);
	AppendToDefaultSubdirectory (Templates, subdirectory);
	AppendToDefaultSubdirectory (TextData, subdirectory);
}

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	UseDefaultPaths
//	Use the default paths.
bool CenturyPaths::UseDefaultPaths ()
{
	bool haveError = false;				// return value
	if ( actualPaths[Executable].empty() )		// no executable path?
	{
		haveError = SetPath ( defaultPaths[Executable], Executable );
		for ( TDefPathIdx i = (TDefPathIdx)(Executable + 1);
		      i < NumberOfPaths;
		      i = (TDefPathIdx)(i + 1) )
		{
			haveError = SetPath (defaultPaths[i], i);
		}
	}
	else				// don't have executable path
	{
		// set the path for everything except the executable
		TEH::TFileName curPath;			// current path
		for ( TDefPathIdx i = (TDefPathIdx)(Executable + 1);
		      i < Work;
		      i = (TDefPathIdx)(i + 1) )
		{
		    TEH::TFileName curPath ( 			// base path
					actualPaths[Executable],
		    			TEH::TFileName::FT_Directory);
		    curPath.AppendToPath (defaultPaths[i]);	// & subdir of
		    haveError = SetPath ( curPath, i );
		}
		SetPath ( defaultPaths[Work], Work );		// work path
	}
	return haveError;
}

//	UseDefaultPath
//	Set the path using default specified by the index.
bool CenturyPaths::UseDefaultPath (
	TDefPathIdx const which)	// index to path
{
	bool haveError = false;				// return value
	if ( which >= Executable && which < NumberOfPaths )
		haveError = SetPath (defaultPaths[which], which);
	return haveError;
}

//	SetPath
//	Set the specified path.
//	If the new path is empty, then the current path is retained.
//	Returns false if the path was saved else true.
bool CenturyPaths::SetPath (
	TEH::TFileName const & newPath,	// path
	TDefPathIdx const which)	// index to path
{
	bool haveError = true;				// return value
	if ( newPath.IsEmpty() )			// anything there?
		error = NoPath;
	else if ( !newPath.IsValid() )
		error = (TDefPathErr)(InvalidExecPath + which);
	else if ( which < Executable || which > NumberOfPaths )
		error = InvalidPathIndex;
	else
	{
	    std::string const fullPath = newPath.GetFullPath ();
	    if ( which == Executable )			// exe path
	    {
		std::string exePath;
		if ( FindExePath (fullPath, exePath) )
		{
			// no Executable path found
			haveError = true;
		}
		actualPaths[which] = exePath;
	    }
	    else if ( which == Work )			// work path
	    {
		std::string workPath;
		if ( FindWorkPath (fullPath, workPath) )
		{
			// no Work path found
			haveError = true;
		}
		actualPaths[which] = workPath;
	    }
	    else					// all other paths
	    {
	    	std::string newPathStr;
	    	CheckAndUsePath (which, newPath, newPathStr);
		actualPaths[which] = newPathStr;
	    }
	    haveError = false;
	}
	if ( haveError )
		errorPathIndex = which;
	return haveError;
}

//	IsValid
//	Returns true if the specified path is a valid path.
bool CenturyPaths::IsValid (
	TDefPathIdx const which) const	// index to path
{
	bool retVal = false;		// return value
	if ( which < NumberOfPaths && !actualPaths[which].empty() )
	{
		TEH::TFileName name ( actualPaths[which],
					TEH::TFileName::FT_Directory );
		retVal = name.IsValid ();
	}
	return retVal;
}

//	Exists
//	Returns true if the specified path exists.
bool CenturyPaths::Exists (
	TDefPathIdx const which) const	// index to path
{
	bool retVal = false;		// return value
	if ( which < NumberOfPaths && !actualPaths[which].empty() )
	{
		TEH::TFileName name (actualPaths[which],
					TEH::TFileName::FT_Directory);
		retVal = name.Exists ();
	}
	return retVal;
}

//	GetHomeEnvVar
//	Get "CENTURY_HOME"
std::string CenturyPaths::GetHomeEnvVar ()
{
	char const * const homeEnvVar = "CENTURY_HOME";
	std::string contents;			// contents of env. variable

#if defined(_Windows) || defined(__WIN32__) || defined(MSWINDOWS)
	// MS Windows
	int const bufferSize = 512;
	char buffer[bufferSize];
	int size = ::GetEnvironmentVariable (homeEnvVar, buffer, bufferSize);
	if ( size < bufferSize )	// fits in buffer?
		contents = buffer;

#else
	// Unix
	char const * const centuryHome = getenv (homeEnvVar);
	if ( centuryHome && *centuryHome )
		contents = centuryHome;
#endif

	return contents;
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	AppendToDefaultSubdirectory
//	Append the member subdirectory to path at index "which".
//	Returns false if successful, else true if error.
bool CenturyPaths::AppendToDefaultSubdirectory (
	TDefPathIdx const which,		// index to the path array
	std::string const & useSubDirectory)	// subdirectory or subpath
{
	bool haveError = false;
	if ( which < Executable || which > NumberOfPaths )
		error = InvalidPathIndex;
	else
	{
		TEH::TFileName newPath ( actualPaths[which],
					 TEH::TFileName::FT_Directory );
		newPath.AppendToPath ( useSubDirectory.c_str() );
		actualPaths[which] = newPath.GetFullPath ();
	}
	if ( haveError )
		errorPathIndex = which;
	return haveError;
}

//	FindExePath
//	Find the path to the model's exectuble file.
//	Return false if successful, else true if path is empty.
bool CenturyPaths::FindExePath (
	std::string const & suggestedPath,	// initial guess at the path
	std::string & exePath)			// "found" path
{
	TEH::TFileName exePathName;
	if ( suggestedPath.empty() )			// anything there?
	{
	    exePathName.Assign ( 			// ...no; find it
		GetHomeEnvVar(),
		TEH::TFileName::FT_Directory );
	}
	else 						// ...yes; use it
	{
	    exePathName.Assign (
		suggestedPath,
		TEH::TFileName::FT_Directory );
	}
	CheckAndUsePath (Executable, exePathName, exePath);
	return exePath.empty();				// return the found path
}

//	FindWorkPath
//	Find the work directory.
//	Return false if successful, else true if path is empty.
bool CenturyPaths::FindWorkPath (
	std::string const & suggestedPath,	// initial guess at the path
	std::string & workPath)			// "found" path
{
	TEH::TFileName workPathName (
		suggestedPath, TEH::TFileName::FT_Directory);
	CheckAndUsePath (Work, workPathName, workPath);
	return workPath.empty();		// return the found path
}

//	CheckAndUsePath
//	Check if path ok. If so, use it, else use default path.
void CenturyPaths::CheckAndUsePath (
	TDefPathIdx const which,		// index to the path array
	TEH::TFileName const & pathName,	// path to check
	std::string & pathUsed)			// path used after check
{
	if ( pathName.IsEmpty() || !pathName.Exists() )	// invalid path?
	{
		// path not found or is invalid, so use the default path
		pathUsed = defaultPaths[which];
	}
	else						// path is good
	{
		pathUsed = pathName.GetFullPath();
	}
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------


//--- end of definitions for CenturyPaths ---
