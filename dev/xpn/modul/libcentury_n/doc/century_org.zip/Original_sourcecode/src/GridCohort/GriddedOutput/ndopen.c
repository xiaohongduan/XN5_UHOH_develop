
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "gridconst.h"

/* Global Variables */
FILE *fp_ndep = (FILE *) NULL;
FILE *fp_scaler = (FILE *) NULL;
int curr_row;

/* Open SVF and Scaler Multiplier N Deposition Files */

int
ndopen(FILE *fp_init, int ndpyrs, float noxsc[])
{

     char junk[MAXR+1];
     int i;
     char line[MAXL];

     char ndep_fname[FNAMEMAX];
     char ndep_scaler[FNAMEMAX];

	/* Open N Deposition SVF File */
        fgets(line, MAXL, fp_init);

        fgets(line,MAXL, fp_init);
        sscanf(line, "%s", &ndep_fname[0]);
	if ((fp_ndep = fopen(ndep_fname, "r")) == NULL)
	{
           printf("ndopen: Unable to open file %s\n", ndep_fname);
        }

	for (i=0; i<5; i++)
	{
		fgets(junk, MAXR, fp_ndep);
	}

	/* Open N Deposition Scaler File */
        fgets(line, MAXL, fp_init);

        fgets(line,MAXL, fp_init);
        sscanf(line, "%s", &ndep_scaler[0]);
	if ((fp_scaler = fopen(ndep_scaler, "r")) == NULL)
	{
           printf("ndopen: Unable to open file %s\n", ndep_scaler);
        }

	/* Read N Deposition scalers into an array */
	for (i = 0; i < ndpyrs; i++)
	{
	 	fscanf(fp_scaler, "%f", &noxsc[i]);
	}

	return 0;
}
