#ifndef INC_arraydefs_h
#define INC_arraydefs_h

// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  arraydefs.h
//	Class:	  TCentury
//
//	Description:
//	Preprocessor macros for accessing 2-D and 3-D arrays.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Jun98
//	History:
//	May99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Appended underscore (_) to macro arg. names to prevent conflicts.
// ----------------------------------------------------------------------------

#include "centconsts.h"

// ccefor[2][FPARTS][NUMELEM]
#define ccefor_ref(a_,b_,c_)	parfs.ccefor[((c_)*FPARTS + (b_))*2 + (a_)]
// cercrp[2][CPARTS][NUMELEM]
#define cercrp_ref(a_,b_,c_)	comput.cercrp[((c_)*CPARTS + (b_))*2 + (a_)]
// cerfor[3][FPARTS][NUMELEM]
#define cerfor_ref(a_,b_,c_)	parfs.cerfor[((c_)*FPARTS + (b_))*3 + (a_)]
#define clittr_ref(layer_,isotope_) soilC.clittr[(isotope_)*NUMLAYERS + (layer_)]
#define co2cce_ref(a_,b_,c_)	co2.co2cce[((c_)*2 + (b_))*2 + (a_)]
#define co2ice_ref(a_,b_,c_)	param.co2ice[((c_)*2 + (b_))*2 + (a_)]
#define damr_ref(a_,b_)		fixed.damr[(b_)*2 + (a_)]
#define eflCL_ref(pool_,fraction_) site.eflCL[(pool_)*ELF_NumFractions + (fraction_)]
#define eflCU_ref(pool_,fraction_) site.eflCU[(pool_)*ELF_NumFractions + (fraction_)]
#define eflN_ref(pool_,fraction_) site.eflN[(pool_)*ELF_NumFractions + (fraction_)]
#define eupprt_ref(a_,b_)		nps.eupprt[(b_)*FPARTS + (a_)]
#define elementUptake_ref(a_,b_)	potentProd.elementUptake[(b_)*FPARTS + (a_)]
#define fcfrac_ref(a_,b_)		parfs.fcfrac[(b_)*FPARTS + (a_)]
#define fligni_ref(a_,b_)		parcp.fligni[(b_)*2 + (a_)]
#define metabe_ref(a_,b_)		nps.metabe[(b_)*NUMLAYERS + (a_)]
#define metcis_ref(layer,isotope) soilC.metcis[(isotope)*NUMLAYERS + (layer)]
#define metmnr_ref(a_,b_)		nps.metmnr[(b_)*NUMLAYERS + (a_)]
#define minerl_ref(a_,b_)		nps.minerl[(b_)*MAXLYR + (a_)]
#define pcemic_ref(a_,b_)		fixed.pcemic[(b_)*3 + (a_)]
#define ppdf_ref(a_,b_)		param.ppdf[(b_)*4 + (a_)]
#define pramn_ref(a_,b_)		parcp.pramn[(b_)*NUMELEM + (a_)]
#define pramx_ref(a_,b_)		parcp.pramx[(b_)*NUMELEM + (a_)]
#define prbmn_ref(a_,b_)		parcp.prbmn[(b_)*NUMELEM + (a_)]
#define prbmx_ref(a_,b_)		parcp.prbmx[(b_)*NUMELEM + (a_)]
#define rad1p_ref(a_,b_)		fixed.rad1p[(b_)*3 + (a_)]
#define rcelit_ref(a_,b_)		param.rcelit[(b_)*2 + (a_)]
#define rces1_ref(a_,b_)		param.rces1[(b_)*2 + (a_)]
#define retf_ref(a_,b_)		forrem.retf[(b_)*3 + (a_)]
#define rnewas_ref(a_,b_)		comput.rnewas[(b_)*NUMELEM + (a_)]
#define rnewbs_ref(a_,b_)		comput.rnewbs[(b_)*NUMELEM + (a_)]
#define rneww1_ref(a_,b_)		comput.rneww1[(b_)*NUMELEM + (a_)]
#define rneww2_ref(a_,b_)		comput.rneww2[(b_)*NUMELEM + (a_)]
#define rneww3_ref(a_,b_)		comput.rneww3[(b_)*NUMELEM + (a_)]
#define s1mnr_ref(a_,b_)		nps.s1mnr[(b_)*NUMLAYERS + (a_)]
#define som1ci_ref(a_,b_)		soilC.som1ci[(b_)*NUMLAYERS + (a_)]
#define som1e_ref(a_,b_)		nps.som1e[(b_)*NUMLAYERS + (a_)]
#define strcis_ref(a_,b_)		soilC.strcis[(b_)*NUMLAYERS + (a_)]
#define strmnr_ref(a_,b_)		nps.strmnr[(b_)*NUMLAYERS + (a_)]
#define struce_ref(a_,b_)		nps.struce[(b_)*NUMLAYERS + (a_)]
#define varat1_ref(a_,b_)		fixed.varat1[(b_)*3 + (a_)]
#define varat2_ref(a_,b_)		fixed.varat2[(b_)*3 + (a_)]
#define varat3_ref(a_,b_)		fixed.varat3[(b_)*3 + (a_)]

#endif // INC_arraydefs_h
