// ----------------------------------------------------------------------------
//    Copyright 1998-2000 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//    Project:   Century Soil Organic Matter Model, daily version
//    File:	 fracbslos.cpp
//    Class:	 TDayCent
//    Function:  BareSoilEvapFrac
//
//    Description:
//    Return fraction of water loss from bare soil evaporation (fbse)
//    Note:   1 - fbse = fraction of transpiration water loss
// ----------------------------------------------------------------------------
//    Author: Susan Chaffee, Melannie Hartman, Bill Parton
//    History:
//    Apr1992  Susan L. Chaffee
//    * Created fracbslos.f
//    Sep1993  Melannie Hartman  melannie@NREL.colostate.edu
//    * Translated fracbslos.f to potbst.c
//    MMMYYYY  Melannie Hartman  melannie@NREL.colostate.edu
//    * Updated for FORTRAN/C version of DayCent model
//    Apr2001  Melannie Hartman  melannie@NREL.colostate.edu
//    * Translated fracbslos.c to fracbslos.cpp
// ----------------------------------------------------------------------------

#include "TDayCent.h"
#include "AssertEx.h"
#include <cmath>

float TDayCent::BareSoilEvapFrac(
    float const blivelai	// live biomass leaf area index (projected)
    ) const
{
    Assert ( blivelai >= 0.0f );
//  Assert ( blivelai <= 15.0f );
    Assert ( blivelai <= 20.0f );

    // float const bsepar1 = 1.0f;
    float const bsepar1 = 1.5f;		// from Century 4.5
    float const bsepar2 = 0.0f;
    float const bsemax = 0.995f; // max frac of water loss from bare soil evap

    // frac of water loss from bare soil evap (0-1)
    float fbse = std::exp (-blivelai * bsepar1) + bsepar2;
    if (fbse > bsemax)
        fbse = bsemax;

    Assert ( fbse >= 0.0f );
    Assert ( fbse <= 1.0f );
    return fbse;
}
