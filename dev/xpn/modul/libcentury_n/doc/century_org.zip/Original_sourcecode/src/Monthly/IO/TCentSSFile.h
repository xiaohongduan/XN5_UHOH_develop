#ifndef INC_TCentSprShtFile_h
#define INC_TCentSprShtFile_h
// ----------------------------------------------------------------------------
//	Copyright 1999-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCentSSFile.h
//	Class:	  TCentSprShtFile
//
//	Description:
//	Century output file class which builds an ASCII file containing
//	Century output variables in a comma-delimited format,
//	which can be imported into a spreadsheet.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Jan99
//	History:
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added copy constructor, operator=
//	* Added Clone member function.
//	Aug01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Virtual-ized several member functions so this could be used as
//	  a base class.
//	Sep01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified Open/Close to work with new output engine base class.
//	* Added operator==
//	Oct01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Changes for the modified base classes TCentOutFileBase, TOutputBase.
//	* Added notes on usage.
//	* Moved variables into the protected section.
//	* Constructor does not open the file streams.
//	  This must be done explicitly after the output variable sets
//	  have been added to the vector.
//	* The number of output files is no longer fixed, but depends upon
//	  the number of output sets added to the vector.
//	* Moved format types into the base class TOutputBase.
//	* Open and Close replaced by virtual DoOpen and DoClose. See base
//	  class TOutputBase.
//	Sep03	Tom Hilinski
//	* Implemented new pure virtual base class member DoReset.
// ----------------------------------------------------------------------------
//	Notes:
//	* Six output files are created, one for each of the output variable
//	sets. Each file contains a sequence of records, one record per
//	output request. Each record contains the full set of data values
//	for the output class.
//	* The pointers to the output variable sets should be initialized by
//	the Century instance which owns them. e.g.:
//		TCentSprShtFile myOutput (...);
//		myOutput.GetOutputSetList().push_back (&wt);
//		myOutput.GetOutputSetList().push_back (&soilC);
//		   (etc.)
//		myOutput.Open ();
//		for (each simulation time step)
//			myOutput.WriteRecord (simulationTime);
//	* The order should match the netCDF definitions file order.
//	* This class can be used as base class.
// ----------------------------------------------------------------------------

#include "TMCOutputFileBase.h"
#include <vector>
#include <fstream>

class TCentSprShtFile : public TMCOutputFileBase
{
  public:
	//--- constructors and destructor
	TCentSprShtFile (
	  std::string const & useFileName, 		// file name
	  TOutputBase::TAccessMode const useAccess,	// file access mode
	  TOutputBase::TFileFormat const useFormat,	// file format type
	  TManagementScheme & useMgmt,		// simulation mgmt. scheme
	  TMCSiteParameters & useSite,		// site parameter set
	  std::string const & useUserName,	// user name for output file
	  TEH::TFileName const & useOVDefFile);	// name+path to netCDF file with
						//   the names and definitions
						//   of the output variables.
	virtual ~TCentSprShtFile ()
	 {
	   Close ();
	 }
	TCentSprShtFile (			// copy constructor
	  TCentSprShtFile const & object)
	  : TMCOutputFileBase (object)
	  {
	    Copy (object);
	  }

	//---- operator overloads
	TCentSprShtFile & operator= (
	  TCentSprShtFile const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	TMCOutputFileBase::operator= (object);
		Copy (object);
	    }
	    return *this;
	  }
	bool operator== (
	  TCentOutFileBase const & object) const
	  {
	    if (outputType == object.GetOutputType())
	    {
	    	return fileName == object.GetFileName();
	    }
	    else
		return false;
	  }

	//--- functions
	bool WriteRecord (			// Write 1 record
	  float const simTime);			//   simulation time
	short NumberOfFiles () const		// Get number of output files.
	  { return outputSetList.size(); }
	char const* NameSuffix (		// Get file name suffix
	  unsigned int const which) const	//   at this index
	  {
	    if ( which < outputSetList.size() )
		return suffix[which];
	    else
		return 0;
	  }
	char const* Extension () const		// Get file name extension
	  { return extenstion[fileFormat]; }
	TCentSprShtFile* const Clone () const	// Clone this
	  { return new TCentSprShtFile (*this); }

  protected:
	//--- static constant data
	static char const * const suffix[];	// file name suffixes
	static char const * const extenstion[];	// default file name extensions
	static const char separator[];		// item separators
        static const short numMonthlySets;	// # of monthly output sets

	//--- data
	std::vector<std::ofstream*> os;		// output file streams


  private:
	//--- functions
	void Initialize ();			// Initialize members.
	virtual std::string MakeFileName (	// Creates a new file name.
	  char const * const root, 		//   file name root
	  char const * const suffix);		//   file name suffix
	virtual bool WriteHeader (		// Write file header to stream
	  std::ofstream & fs,		//   file stream
	  char const * const category,		//   category description
	  char const * const * colHeads,	//   array of column headers
	  short const count);			//   size of array
	void Copy (				// Copy to this
	  TCentSprShtFile const & object)
	  {
	    if ( &object )
	    {
	    	// do not copy the stream -
	    	// should be opened by the copy of this.
	    }
	  }

	//---- functions: Virtual
	virtual TState DoOpen ();		// Open the output engine
	virtual TState DoClose ();		// Close the output engine
	virtual TState DoReset ();		// Reset the output engine
};

#endif // INC_TCentSprShtFile_h
