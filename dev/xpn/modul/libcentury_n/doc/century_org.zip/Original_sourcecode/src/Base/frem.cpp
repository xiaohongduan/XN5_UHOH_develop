// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  frem.cpp
//	Class:	  TCenturyBase
//	Function: ForestRemoval
//
//	Description:
//	Forest removal - fire or cutting (cutting includes storms)
//	Includes litter burning in forest systems.
// ----------------------------------------------------------------------------
//	History:
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
//	* Added enum TForestEventType to centconts.h and
//	  redefined forrem.evntyp as that type.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::ForestRemoval ()
{
    float accum[ISOS] = { 0.0f, 0.0f };
    // Removal for both CUT and FIRE events
    if ( forrem.evntyp == Tforrem::FORESTCUT ||
	 forrem.evntyp == Tforrem::FORESTFIRE )		// valid event types?
    {
	ForestLiveBiomassRem (accum);		// Live Removal
	RemoveDeadWood (accum);			// Dead Removal
	KillRoots (accum);			// Death of Roots
    }
    if (forrem.evntyp == Tforrem::FORESTCUT)		// cutting event?
	CuttingEvent (accum);
    else					// fire event?
	FireEvent ();
}

//--- end of file frem.cpp ---
