// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  outputvars.cpp
//	Class:	  Century output variable classes.
//
//	Description:
//	Implementation of member functions for the Century output variable
//	classes.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jun98
// ----------------------------------------------------------------------------
//	History: See header file.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "outputvars.h"

//	------------------------------------------------------------
//	Constants
//	------------------------------------------------------------
float const TCenturyOutputSet::memCheckValue = 524287.0e-32f;

//	------------------------------------------------------------
//	TWaterTemp

void TWaterTemp::Clear ()
{
	adefac = 0.0f;
	anerb = 0.0f;
	defac = 0.0f;
	evap = 0.0f;
	irract = 0.0f;
	irrtot = 0.0f;
	pet = 0.0f;
	petann = 0.0f;
	prcann = 0.0f;
	prcfal = 0.0f;
	pttr = 0.0f;
	rain = 0.0f;
	runoff = 0.0f;
	snlq = 0.0f;
	snow = 0.0f;
	stemp = 0.0f;
	tave = 0.0f;
	tran = 0.0f;
	for ( short i = 0; i < 3; i++ )
		avh2o[i] = 0.0f;
	for ( short i = 0; i < MAXLYR; i++ )
	{
	 	asmos[i] = 0.0f;
		rwcf[i] = 0.0f;
	}
	for ( short i = 0; i < 8; i++ )
		stream[i] = 0.0f;
	simDepth = soilDepth = 0.0f;
}	// TWaterTemp::Clear

void TWaterTemp::AssignPointers ()
{
	float **v = p;
	*(v++) = &adefac;
	*(v++) = &anerb;
	for ( short i = 0; i < MAXLYR; i++ )
	 	*(v++) = &asmos[i];
	for ( short i = 0; i < 3; i++ )
		*(v++) = &avh2o[i];
	*(v++) = &defac;
	*(v++) = &evap;
	*(v++) = &irract;
	*(v++) = &irrtot;
	*(v++) = &pet;
	*(v++) = &petann;
	*(v++) = &prcann;
	*(v++) = &prcfal;
	*(v++) = &pttr;
	*(v++) = &rain;
	*(v++) = &runoff;
	for ( short i = 0; i < MAXLYR; i++ )
		*(v++) = &rwcf[i];
	*(v++) = &snlq;
	*(v++) = &snow;
	*(v++) = &stemp;
	for ( short i = 0; i < 8; i++ )
		*(v++) = &stream[i];
	*(v++) = &tave;
	*(v++) = &tran;
	*(v++) = &simDepth;
	*v = &soilDepth;
}	// TWaterTemp::AssignPointers

//	------------------------------------------------------------
//	TSoilC

void TSoilC::Clear ()
{
	dblit = dslit = 0.0f;
	dsom2c = dsom3c = dsomsc = dsomtc = 0.0f;
	lhzcac = lhsomtc = 0.0f;
	eroCcum = eroC = 0.0f;			// erosion
	depCcum = depC = 0.0f;			// deposition
	som2c = som3c = somsc = 0.0f;
	somtpc = somtc = totalc = totc = 0.0f;
	for ( short i = 0; i < NUMLAYERS; i++ )
	{
		csrsnk[i] = 0.0f;
		dmetc[i] = 0.0f;
		dsom1c[i] = 0.0f;
		dstruc[i] = 0.0f;
		metabc[i] = 0.0f;
		som1c[i] = 0.0f;
		som2ci[i] = 0.0f;
		som3ci[i] = 0.0f;
		somsci[i] = 0.0f;
		somtci[i] = 0.0f;
		strlig[i] = 0.0f;
		strucc[i] = 0.0f;
		tomres[i] = 0.0f;
	}
	for ( short i = 0; i < 4; i++ )
	{
		clittr[i] = 0.0f;
		cltfac[i] = 0.0f;
		metcis[i] = 0.0f;
		som1ci[i] = 0.0f;
		strcis[i] = 0.0f;
	}
}	// TSoilC::Clear

void TSoilC::AssignPointers ()
{
	register short i, j;
	float **v = p;

#define clittr_ref(layer,isotope)	clittr[(isotope)*NUMLAYERS + layer]
	for ( short i = 0; i < NUMLAYERS; i++ )		// layer
		for ( j = 0; j < ISOS; j++ )		// C isotope
			*(v++) = &clittr_ref (i, j);
#undef clittr_ref
	for ( i = 0; i < 4; i++ )
		*(v++) = &cltfac[i];
	*(v++) = &csrsnk[0];
	*(v++) = &csrsnk[1];
	*(v++) = &dblit;
	*(v++) = &dmetc[0];
	*(v++) = &dmetc[1];
	*(v++) = &dslit;
	*(v++) = &dsom1c[0];
	*(v++) = &dsom1c[1];
	*(v++) = &dsom2c;
	*(v++) = &dsom3c;
	*(v++) = &dsomsc;
	*(v++) = &dsomtc;
	*(v++) = &dstruc[0];
	*(v++) = &dstruc[1];
	*(v++) = &lhzcac;
	*(v++) = &lhsomtc;
	*(v++) = &metabc[0];
	*(v++) = &metabc[1];
#define metcis_ref(layer,isotope)	metcis[(isotope)*NUMLAYERS + layer]
	for ( short i = 0; i < NUMLAYERS; i++ )		// layer
		for ( j = 0; j < ISOS; j++ )		// C isotope
			*(v++) = &metcis_ref (i, j);
#undef metcis_ref
	*(v++) = &eroCcum;
	*(v++) = &eroC;
	*(v++) = &depCcum;
	*(v++) = &depC;
	*(v++) = &som1c[0];
	*(v++) = &som1c[1];
#define som1ci_ref(a,b)		som1ci[(b)*NUMLAYERS + a]
	for ( short i = 0; i < NUMLAYERS; i++ )		// layer
		for ( j = 0; j < ISOS; j++ )		// C isotope
			*(v++) = &som1ci_ref (i, j);
#undef som1ci_ref
	*(v++) = &som2c;
	*(v++) = &som2ci[0];
	*(v++) = &som2ci[1];
	*(v++) = &som3c;
	*(v++) = &som3ci[0];
	*(v++) = &som3ci[1];
	*(v++) = &somsc;
	*(v++) = &somsci[0];
	*(v++) = &somsci[1];
	*(v++) = &somtc;
	*(v++) = &somtci[0];
	*(v++) = &somtci[1];
	*(v++) = &somtpc;
#define strcis_ref(a,b)		strcis[(b)*NUMLAYERS + a]
	for ( short i = 0; i < 2; i++ )			// layer
		for ( j = 0; j < 2; j++ )		// C isotope
			*(v++) = &strcis_ref (i, j);
#undef strcis_ref
	*(v++) = &strlig[0];
	*(v++) = &strlig[1];
	*(v++) = &strucc[0];
	*(v++) = &strucc[1];
	*(v++) = &tomres[0];
	*(v++) = &tomres[1];
	*(v++) = &totalc;
	*v = &totc;
}	// TSoilC::AssignPointers

//	------------------------------------------------------------
//	TCropGrassC

void TCropGrassC::Clear ()
{
	accrst = 0.0f;
	agcacc = 0.0f;
	aglcn = 0.0f;
	aglivc = 0.0f;
	bgcacc = 0.0f;
	bglcn = 0.0f;
	bglivc = 0.0f;
	cgracc = 0.0f;
	cgrain = 0.0f;
	cinput = 0.0f;
	cprodc = 0.0f;
	creta = 0.0f;
	crmvst = 0.0f;
	crpval = 0.0f;
	harmth = 0.0f;
	hi = 0.0f;
	ptagc = 0.0f;
	ptbgc = 0.0f;
	sdrema = 0.0f;
	shrema = 0.0f;
	stdedc = 0.0f;
	for ( short i = 0; i < 2; i++ )
	{
		agcisa[i] = 0.0f;
	    	aglcis[i] = 0.0f;
		bgcisa[i] = 0.0f;
		bglcis[i] = 0.0f;
	    	cisgra[i] = 0.0f;
		sdrmai[i] = 0.0f;
		shrmai[i] = 0.0f;
		stdcis[i] = 0.0f;
	}
}	// TCropGrassC::Clear

void TCropGrassC::AssignPointers ()
{
	float **v = p;
	*(v++) = &accrst;
	*(v++) = &agcacc;
	*(v++) = &agcisa[0];
	*(v++) = &agcisa[1];
	*(v++) = &aglcis[0];
	*(v++) = &aglcis[1];
	*(v++) = &aglcn;
	*(v++) = &aglivc;
	*(v++) = &bgcacc;
	*(v++) = &bgcisa[0];
	*(v++) = &bgcisa[1];
	*(v++) = &bglcis[0];
	*(v++) = &bglcis[1];
	*(v++) = &bglcn;
	*(v++) = &bglivc;
	*(v++) = &cgracc;
	*(v++) = &cgrain;
	*(v++) = &cinput;
	*(v++) = &cisgra[0];
	*(v++) = &cisgra[1];
	*(v++) = &cprodc;
	*(v++) = &creta;
	*(v++) = &crmvst;
	*(v++) = &crpval;
	*(v++) = &harmth;
	*(v++) = &hi;
	*(v++) = &ptagc;
	*(v++) = &ptbgc;
	*(v++) = &sdrema;
	*(v++) = &sdrmai[0];
	*(v++) = &sdrmai[1];
	*(v++) = &shrema;
	*(v++) = &shrmai[0];
	*(v++) = &shrmai[1];
	*(v++) = &stdcis[0];
	*(v++) = &stdcis[1];
	*v = &stdedc;
}	// TCropGrassC::AssignPointers

//	------------------------------------------------------------
//	TForestC

void TForestC::Clear ()
{
	cproda = 0.0f;
	cprodf = 0.0f;
	crootc = 0.0f;
	crtacc = 0.0f;
	fbracc = 0.0f;
	fbrchc = 0.0f;
	fcacc = 0.0f;
	frootc = 0.0f;
	frstc = 0.0f;
	frtacc = 0.0f;
	fsysc = 0.0f;
	rleavc = 0.0f;
	rlvacc = 0.0f;
	rlwacc = 0.0f;
	rlwodc = 0.0f;
	sumrsp = 0.0f;
	tcrem = 0.0f;
	wood1c = 0.0f;
	wood2c = 0.0f;
	wood3c = 0.0f;
	woodc = 0.0f;
	for ( short i = 0; i < 2; i++ )
	{
		acrcis[i] = 0.0f;
		afbcis[i] = 0.0f;
		afrcis[i] = 0.0f;
		alvcis[i] = 0.0f;
		alwcis[i] = 0.0f;
		crtcis[i] = 0.0f;
		fbrcis[i] = 0.0f;
		frtcis[i] = 0.0f;
		rlvcis[i] = 0.0f;
		rlwcis[i] = 0.0f;
		wd1cis[i] = 0.0f;
		wd2cis[i] = 0.0f;
		wd3cis[i] = 0.0f;
	}
}	// TForestC::Clear

void TForestC::AssignPointers ()
{
	float **v = p;
	*(v++) = &acrcis[0];
	*(v++) = &acrcis[1];
	*(v++) = &afbcis[0];
	*(v++) = &afbcis[1];
	*(v++) = &afrcis[0];
	*(v++) = &afrcis[1];
	*(v++) = &alvcis[0];
	*(v++) = &alvcis[1];
	*(v++) = &alwcis[0];
	*(v++) = &alwcis[1];
	*(v++) = &cproda;
	*(v++) = &cprodf;
	*(v++) = &crootc;
	*(v++) = &crtacc;
	*(v++) = &crtcis[0];
	*(v++) = &crtcis[1];
	*(v++) = &fbracc;
	*(v++) = &fbrchc;
	*(v++) = &fbrcis[0];
	*(v++) = &fbrcis[1];
	*(v++) = &fcacc;
	*(v++) = &frootc;
	*(v++) = &frstc;
	*(v++) = &frtacc;
	*(v++) = &frtcis[0];
	*(v++) = &frtcis[1];
	*(v++) = &fsysc;
	*(v++) = &rleavc;
	*(v++) = &rlvacc;
	*(v++) = &rlvcis[0];
	*(v++) = &rlvcis[1];
	*(v++) = &rlwacc;
	*(v++) = &rlwcis[0];
	*(v++) = &rlwcis[1];
	*(v++) = &rlwodc;
	*(v++) = &sumrsp;
	*(v++) = &tcrem;
	*(v++) = &wd1cis[0];
	*(v++) = &wd1cis[1];
	*(v++) = &wd2cis[0];
	*(v++) = &wd2cis[1];
	*(v++) = &wd3cis[0];
	*(v++) = &wd3cis[1];
	*(v++) = &wood1c;
	*(v++) = &wood2c;
	*(v++) = &wood3c;
	*v = &woodc;
}	// TForestC::AssignPointers

//	------------------------------------------------------------
//	TCO2

void TCO2::Clear ()
{
	amt1c2 = 0.0f;
	amt2c2 = 0.0f;
	as11c2 = 0.0f;
	as21c2 = 0.0f;
	as2c2 = 0.0f;
	as3c2 = 0.0f;
	ast1c2 = 0.0f;
	ast2c2 = 0.0f;
	for ( short i = 0; i < 2; i++ )
	{
		co2cpr[i] = 0.0f;
		co2crs[i] = 0.0f;
		co2ctr[i] = 0.0f;
		mt1c2[i] = 0.0f;
		mt2c2[i] = 0.0f;
		resp[i] = 0.0f;
		s11c2[i] = 0.0f;
		s21c2[i] = 0.0f;
		s2c2[i] = 0.0f;
		s3c2[i] = 0.0f;
		st1c2[i] = 0.0f;
		st2c2[i] = 0.0f;
	}
	for ( short i = 0; i < 12; i++ )
		co2cce[i] = 0.0f;
}	// TCO2::Clear

void TCO2::AssignPointers ()
{
	float **v = p;
	*(v++) = &amt1c2;
	*(v++) = &amt2c2;
	*(v++) = &as11c2;
	*(v++) = &as21c2;
	*(v++) = &as2c2;
	*(v++) = &as3c2;
	*(v++) = &ast1c2;
	*(v++) = &ast2c2;
#define co2cce_ref(a,b,c)	co2cce[((c)*2 + (b))*2 + a]
	for ( short i = 0; i < 2; i++ )
	    for ( short j = 0; j < 2; j++ )
		for ( short k = 0; k < 3; k++ )
			*(v++) = &co2cce_ref(i, j, k);
#undef co2cce_ref
	*(v++) = &co2cpr[0];
	*(v++) = &co2cpr[1];
	*(v++) = &co2crs[0];
	*(v++) = &co2crs[1];
	*(v++) = &co2ctr[0];
	*(v++) = &co2ctr[1];
	*(v++) = &mt1c2[0];
	*(v++) = &mt1c2[1];
	*(v++) = &mt2c2[0];
	*(v++) = &mt2c2[1];
	*(v++) = &resp[0];
	*(v++) = &resp[1];
	*(v++) = &s11c2[0];
	*(v++) = &s11c2[1];
	*(v++) = &s21c2[0];
	*(v++) = &s21c2[1];
	*(v++) = &s2c2[0];
	*(v++) = &s2c2[1];
	*(v++) = &s3c2[0];
	*(v++) = &s3c2[1];
	*(v++) = &st1c2[0];
	*(v++) = &st1c2[1];
	*(v++) = &st2c2[0];
	*v = &st2c2[1];
}	// TCO2::AssignPointers

//	------------------------------------------------------------
//	TNPS

void TNPS::Clear ()
{
	elimit = 0.0f;
	nfix = 0.0f;
	nfixac = 0.0f;
	occlud = 0.0f;
	plabil = 0.0f;
	rnpml1 = 0.0f;
	satmac = 0.0f;
	sirrac = 0.0f;
	tcnpro = 0.0f;
	volex = 0.0f;
	volexa = 0.0f;
	volgm = 0.0f;
	volgma = 0.0f;
	volpl = 0.0f;
	volpla = 0.0f;
	wdfx = 0.0f;
	wdfxa = 0.0f;
	wdfxaa = 0.0f;
	wdfxas = 0.0f;
	wdfxma = 0.0f;
	wdfxms = 0.0f;
	wdfxs = 0.0f;
	for ( short i = 0; i < 2; i++ )
		snfxac[i] = 0.0f;
	for ( short i = 0; i < 3; i++ )
	{
		aglive[i] = 0.0f;
		aminrl[i] = 0.0f;
		bglive[i] = 0.0f;
		croote[i] = 0.0f;
		crpstg[i] = 0.0f;
		egracc[i] = 0.0f;
		egrain[i] = 0.0f;
		eprodc[i] = 0.0f;
		eprodf[i] = 0.0f;
		ereta[i] = 0.0f;
		ermvst[i] = 0.0f;
		esrsnk[i] = 0.0f;
		eupacc[i] = 0.0f;
		eupaga[i] = 0.0f;
		eupbga[i] = 0.0f;
		fbrche[i] = 0.0f;
		fertot[i] = 0.0f;
		forstg[i] = 0.0f;
		froote[i] = 0.0f;
		frste[i] = 0.0f;
		fsyse[i] = 0.0f;
		gromin[i] = 0.0f;
		lhzeac[i] = 0.0f;
		parent[i] = 0.0f;
		rleave[i] = 0.0f;
		rlwode[i] = 0.0f;
		s2mnr[i] = 0.0f;
		s3mnr[i] = 0.0f;
		sdrmae[i] = 0.0f;
		secndy[i] = 0.0f;
		shrmae[i] = 0.0f;
		soilnm[i] = 0.0f;
		som2e[i] = 0.0f;
		som3e[i] = 0.0f;
		somse[i] = 0.0f;
		somte[i] = 0.0f;
		stdede[i] = 0.0f;
		sumnrs[i] = 0.0f;
		tcerat[i] = 0.0f;
		terem[i] = 0.0f;
		tminrl[i] = 0.0f;
		tnetmn[i] = 0.0f;
		totale[i] = 0.0f;
		w1mnr[i] = 0.0f;
		w2mnr[i] = 0.0f;
		w3mnr[i] = 0.0f;
		wood1e[i] = 0.0f;
		wood2e[i] = 0.0f;
		wood3e[i] = 0.0f;
		woode[i] = 0.0f;
	}
	for ( short i = 0; i < 6; i++ )
	{
		metabe[i] = 0.0f;
		metmnr[i] = 0.0f;
		strmnr[i] = 0.0f;
		s1mnr[i] = 0.0f;
		som1e[i] = 0.0f;
		struce[i] = 0.0f;
	}
	for ( short i = 0; i < 15; i++ )
		eupprt[i] = 0.0f;
	for ( short i = 0; i < 30; i++ )
		minerl[i] = 0.0f;
}	// TNPS::Clear

void TNPS::AssignPointers ()
{
	register short i, j;
	float **v = p;
	*(v++) = &elimit;
	*(v++) = &nfix;
	*(v++) = &nfixac;
	*(v++) = &rnpml1;
	*(v++) = &snfxac[0];
	*(v++) = &snfxac[1];
	*(v++) = &tcnpro;
	*(v++) = &volex;
	*(v++) = &volexa;
	*(v++) = &volgm;
	*(v++) = &volgma;
	*(v++) = &volpl;
	*(v++) = &volpla;
	*(v++) = &wdfx;
	*(v++) = &wdfxa;
	*(v++) = &wdfxaa;
	*(v++) = &wdfxas;
	*(v++) = &wdfxma;
	*(v++) = &wdfxms;
	*(v++) = &wdfxs;
	*(v++) = &occlud;
	*(v++) = &plabil;
	*(v++) = &satmac;
	*(v++) = &sirrac;
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &aglive[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &aminrl[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &bglive[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &croote[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &crpstg[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &egracc[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &egrain[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &eprodc[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &eprodf[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &ereta[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &ermvst[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &esrsnk[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &eupacc[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &eupaga[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &eupbga[i];
#define eupprt_ref(a,b)		eupprt[(b)*FPARTS + a]
	for ( i = 0; i < NUMELEM; i++ )				// N,P,S
		for ( j = 0; j < FPARTS; ++j )			// FPARTS
			*(v++) = &eupprt_ref (j, i);
#undef eupprt_ref
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &fbrche[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &fertot[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &forstg[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &froote[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &frste[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &fsyse[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &gromin[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &lhzeac[i];
#define metabe_ref(a,b)		metabe[(b)*NUMLAYERS + a]
	for ( i = 0; i < NUMLAYERS; i++ )			// layer
		for ( j = 0; j < NUMELEM; j++ )			// N,P,S
			*(v++) = &metabe_ref (i, j);
#undef metabe_ref
#define metmnr_ref(a,b)		metmnr[(b)*NUMLAYERS + a]
	for ( i = 0; i < NUMLAYERS; i++ )			// layer
		for ( j = 0; j < NUMELEM; j++ )			// N,P,S
			*(v++) = &metmnr_ref (i, j);
#undef metmnr_ref
#define minerl_ref(a,b)		minerl[(b)*MAXLYR + a]
	for ( i = 0; i < NUMELEM; i++ )				// N,P,S
		for ( j = 0; j < MAXLYR; ++j )			// soil layer
			*(v++) = &minerl_ref (j, i);
#undef minerl_ref
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &parent[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &rleave[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &rlwode[i];
#define s1mnr_ref(a,b)		s1mnr[(b)*NUMLAYERS + a]
	for ( i = 0; i < NUMLAYERS; i++ )			// layer
		for ( j = 0; j < NUMELEM; j++ )			// N,P,S
			*(v++) = &s1mnr_ref (i, j);
#undef s1mnr_ref
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &s2mnr[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &s3mnr[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &sdrmae[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &secndy[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &shrmae[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &soilnm[i];
#define som1e_ref(a,b)		som1e[(b)*NUMLAYERS + a]
	for ( i = 0; i < NUMLAYERS; i++ )			// layer
		for ( j = 0; j < NUMELEM; j++ )			// N,P,S
			*(v++) = &som1e_ref (i, j);
#undef som1e_ref
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &som2e[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &som3e[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &somse[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &somte[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &stdede[i];
#define strmnr_ref(a,b)		strmnr[(b)*NUMLAYERS + a]
	for ( i = 0; i < NUMLAYERS; i++ )			// layer
		for ( j = 0; j < NUMELEM; j++ )			// N,P,S
			*(v++) = &strmnr_ref (i, j);
#undef strmnr_ref
#define struce_ref(a,b)		struce[(b)*NUMLAYERS + a]
	for ( i = 0; i < NUMLAYERS; i++ )			// layer
		for ( j = 0; j < NUMELEM; j++ )			// N,P,S
			*(v++) = &struce_ref (i, j);
#undef struce_ref
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &sumnrs[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &tcerat[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &terem[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &tminrl[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &tnetmn[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &totale[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &w1mnr[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &w2mnr[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &w3mnr[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &wood1e[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &wood2e[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &wood3e[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &woode[i];

}	// TNPS::AssignPointers

