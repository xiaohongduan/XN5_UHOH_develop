// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  dshoot.cpp
//	Class:	  TCenturyBase
//	Function: DeathOfShoots
//
//	Description:
//	Simulate death of shoots for the month.
//	Death of shoots.  Most shoots die during the month of senescence.
//	During other months, only a small fraction of the shoots die.
// ----------------------------------------------------------------------------
//	History:
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* fixed.vlosse was changed in the loop. Changed to a local variable.
//	* Changed variable names to descriptive names.
//      Jul02   Melannie Hartman, melannie@nrel.colostate.edu
//      * Added nps.volpl calculation.
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::DeathOfShoots (
	float const wfunc)	// water functions
{
	register short index;	// index to parcp.fsdeth
	float accum[ISOS];	// holds returned values (not used)
	float dthppt;		//

	if (cropC.aglivc <= 0.0f)
    		return;


	// death fraction
	if ( sched->DoingSenescence() )
	{
	    index = 1;
	    dthppt = 1.0f;
	}
	else
	{
	    index = 0;
	    dthppt = 1.0f - wfunc;
	}
	float fractionDeath = parcp.fsdeth[index] * dthppt;

	// Increase death rate of shoots to account for effect of shading.
	// This is not done during senescence (when the death rate is greater
	// than or equal to 0.4)
	if (parcp.fsdeth[index] < 0.4f && cropC.aglivc > parcp.fsdeth[3])
	    fractionDeath += parcp.fsdeth[2];
	fractionDeath = std::min (fractionDeath, 0.95f);  // limit maximum

	// Calculate the amounts and flow
	parcp.sdethc = cropC.aglivc * fractionDeath;
	ScheduleCFlow ( st->time, parcp.sdethc,
		cropC.aglcis[LABELD] / cropC.aglivc, 1.0f,
		&cropC.aglcis[UNLABL], &cropC.stdcis[UNLABL],
		&cropC.aglcis[LABELD], &cropC.stdcis[LABELD],
		accum);
	for (short element = 0; element < site.nelem; ++element)
	{
	    float amountShootDeath = fractionDeath * nps.aglive[element];
	    if (element == N)
	    {
		float const volatileLoss = parcp.vlossp * amountShootDeath;
		flows->Schedule (&nps.aglive[element], &nps.esrsnk[element],
				st->time, volatileLoss);
                nps.volpl += volatileLoss;
		nps.volpla += volatileLoss;
		amountShootDeath -= volatileLoss;
	    }
	    // calc the retranslocation storage element pool for grass/crop
	    float amountToStore = amountShootDeath * parcp.crprtf[element];
	    flows->Schedule (&nps.aglive[element], &nps.crpstg[element],
	    		    st->time, amountToStore);
	    // amount retranslocated from leaves at death
	    amountShootDeath *= (1.0f - parcp.crprtf[element]);
	    flows->Schedule (&nps.aglive[element], &nps.stdede[element],
	    		    st->time, amountShootDeath);
	}
}

//--- end of file dshoot.cpp ---
