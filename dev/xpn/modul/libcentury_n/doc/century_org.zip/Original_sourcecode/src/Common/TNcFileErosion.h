#ifndef INC_T_NcFileErosion_h
#define INC_T_NcFileErosion_h

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TNcFileErosion.h
//	Class:	  TNcErosionFile
//
//	Description:
//	Class for I/O of the netCDF file for the TErosion and TDeposition
//	classes. Derived from the class TNcFile.
//	File can be both read from and written to in the same instance.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jan99
// ----------------------------------------------------------------------------
//	History:
//	Jun01	Tom Hilinski
//	* A bit of cleaning up and const-correctness.
//	* Added copy constructor, operator=
//	Mar03	Tom Hilinski
//	* Made a derived class of nrel::io::TIOSourceSinkBase
// ----------------------------------------------------------------------------
//	Copyright 1999-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TIOSourceSinkBase.h"
#include "TNcFile.h"
#include "AssertEx.h"

class TNcErosionFile
	: public nrel::io::TIOSourceSinkBase,
	  public TNcFile
{
  public:
	//--- constructors and destructor
	TNcErosionFile (			// For creating file:
	  TEH::TFileName const & file,		//   name of erosion file
	  char const* useUserName, 		//   user's name
	  char const* useMgmtDesc,		//   management description
	  char const* useMgmtFile,		//   management file name
	  char const* useSiteDesc,		//   site description
	  char const* useSiteFile);		//   site file name
	TNcErosionFile (			// For reading file:
	  TEH::TFileName const & file);		//   name of erosion file
	~TNcErosionFile ()
	  {
	    CloseNcFile ();
	  }
	TNcErosionFile (TNcErosionFile const & object)	// copy constructor
	  : nrel::io::TIOSourceSinkBase (object),
	    TNcFile (object)
	  {
	    Initialize ();
	    Copy (object);
	  }

	//---- operator overloads
	TNcErosionFile& operator= (TNcErosionFile const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
		nrel::io::TIOSourceSinkBase::operator= (object);
	    	TNcFile::operator= (object);
	    	Initialize ();
		Copy (object);
	    }
	    return *this;
	  }

	//--- functions
	void Create ();			// Creates a new file
	bool ReadAbout (		// Read the descriptive attibutes:
		char*& title,		//   title of file
		char*& simDesc,		//   simulation description
		char*& mgmtFile,	//   management file name
		char*& siteFile,	//   site file name
		char*& siteDesc,	//   site description
		char*& whoMod,		//   who modified this file
		char*& whenMod);	//   modified date
	bool ReadRecord (		// Reads one record
		float& simTime,		//   simulation time (years w/fraction)
		float& thickness,	//   thickness eroded (cm)
		float& bulkDen,		//   bulk density (g/cm^3)
		float& sand,		//   fraction of sand-sized
		float& silt,		//   fraction of silt-sized
		float& clay,		//   fraction of clay-sized
		float* data);		//   data[EE_NumElements][EPT_NumPools]
	bool WriteRecord (		// Write (replace) one record
		float const simTime,	//   simulation time (years w/fraction)
		float const thickness,	//   thickness eroded (cm)
		float const bulkDen,	//   bulk density (g/cm^3)
		float const sand,	//   fraction of sand-sized
		float const silt,	//   fraction of silt-sized
		float const clay,	//   fraction of clay-sized
		float const* data);	//   data[EE_NumElements][EPT_NumPools]
	long SetRecordRead (		// set the next record for reading
		const long recordNumber);
	long SetRecordWrite (		// set the next record for writing
		const long recordNumber);
	long GetRecordRead () const	// get the next record for reading
		{ return curRecRd; }
	long GetRecordWrite () const	// get the next record for writing
		{ return curRecWr; }
	long GetRecordCount ();		// get the number of time-step records.

	virtual TIOState Reset ()			// Reset to start state
	  {
		Assert (0);	// To Do: Reset
		return ioState;
	  }
	virtual TNcErosionFile * const Clone () const	// Clone this
	  {
	    return new TNcErosionFile (*this);
	  }

  private:
	//--- constant data
	char const* userName;		// user's name
	char const* mgmtDesc;		// management description
	char const* mgmtFile;		// management file name
	char const* siteDesc;		// site description
	char const* siteFile;		// site file name

	//--- data
	NcFile::FileMode curAccMode;	// current access mode
	long curRecRd, curRecWr;	// current read/write records

	//--- functions
	void Initialize ()			// initialize vars
	  {
	    curAccMode = NcFile::New;
	    curRecRd = curRecWr = 0;
	  }
	void Copy (TNcErosionFile const & object)	// Copy to this
	  {
	    if (&object)
	    {
	    	curAccMode = object.curAccMode;
	    }
	  }
	bool IsFileOpen (			// true if file is open
		const NcFile::FileMode accessMode);
	char* GetOneStrAttribute (		// Get string attribute
		short const which);		//   index to attribute
};

#endif // INC_T_NcFileErosion_h
