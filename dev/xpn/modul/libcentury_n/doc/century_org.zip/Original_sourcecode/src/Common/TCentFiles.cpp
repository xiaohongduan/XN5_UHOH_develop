// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TCentFiles.cpp
//	Class:	  TCenturyFiles
//
//	Description:
//	Files used by class TCentury.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jan01
// ----------------------------------------------------------------------------
//	History:
//	See header file.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TCentFiles.h"
using namespace std;

// ----------------------------------------------------------------------------
//	Member constants
// ----------------------------------------------------------------------------

char const* const TCenturyFiles::defaultWorkPath = "/simulations";
char const* const TCenturyFiles::defaultParamPath = "./parameter";
char const* const TCenturyFiles::defaultTemplatePath = "./template";
char const* const TCenturyFiles::defaultOutputFileName = "output";
char const* const TCenturyFiles::defaultC14FileName 	= "c14data";

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	Constructors
TCenturyFiles::TCenturyFiles ()
{
	Initialize ();
}

//	Clear
//	Clear the member data.
void TCenturyFiles::Clear ()
{
	workPath.clear ();
	paramPath.clear ();
	templatePath.clear ();
	outputName.clear ();
	c14Name.clear ();
}

//	SetWorkPath
//	Set the work folder path
bool TCenturyFiles::SetWorkPath (
	char const * useName)		// use this name
{
	if ( useName )					// anything there?
	{
		workPath = useName;			// save it
		return false;
	}
	else
		return true;
}

bool TCenturyFiles::SetWorkPath (
	string const & useName)		// use this name
{
	if ( !useName.empty() )				// anything there?
	{
		workPath = useName;			// save it
		return false;
	}
	else
		return true;
}

//	SetParamPath
//	Set parameter folder path
bool TCenturyFiles::SetParamPath (
	char const * useName)		// use this name
{
	if ( useName )					// anything there?
	{
		paramPath = useName;			// save it
		return false;
	}
	else
		return true;
}

bool TCenturyFiles::SetParamPath (
	string const & useName)		// use this name
{
	if ( !useName.empty() )				// anything there?
	{
		paramPath = useName;			// save it
		return false;
	}
	else
		return true;
}

//	SetTemplatePath
//	Set template folder path
bool TCenturyFiles::SetTemplatePath (
	char const * useName)		// use this name
{
	if ( useName )					// anything there?
	{
		templatePath = useName;			// save it
		return false;
	}
	else
		return true;
}

bool TCenturyFiles::SetTemplatePath (
	string const & useName)		// use this name
{
	if ( !useName.empty() )				// anything there?
	{
		templatePath = useName;			// save it
		return false;
	}
	else
		return true;
}

//	SetOutputName
//	Set output file name
bool TCenturyFiles::SetOutputName (
	char const * useName)		// use this name
{
	if ( useName )					// anything there?
	{
		outputName = useName;			// save it
		return false;
	}
	else
		return true;
}

bool TCenturyFiles::SetOutputName (
	string const & useName)		// use this name
{
	if ( !useName.empty() )				// anything there?
	{
		outputName = useName;			// save it
		return false;
	}
	else
		return true;
}

//	SetC14Name
//	Set the 14C data file name
bool TCenturyFiles::SetC14Name (
	char const * useName)		// use this name
{
	if ( useName )					// anything there?
	{
		c14Name = useName;			// save it
		return false;
	}
	else
		return true;
}

bool TCenturyFiles::SetC14Name (
	string const & useName)		// use this name
{
	if ( !useName.empty() )				// anything there?
	{
		c14Name = useName;			// save it
		return false;
	}
	else
		return true;
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

void TCenturyFiles::Initialize ()
{
	workPath = defaultWorkPath;
	paramPath = defaultParamPath;
	templatePath = defaultTemplatePath;
	outputName = defaultOutputFileName;
	c14Name = defaultC14FileName;
}

//	Copy
// 	copy to this
void TCenturyFiles::Copy (TCenturyFiles const & object)
{
	if ( &object )
	{
		workPath = object.workPath;
		paramPath = object.paramPath;
		templatePath = object.templatePath;
		outputName = object.outputName;
		c14Name = object.c14Name;
	}
}

//--- end of file ---
