#ifndef INC_TChkBoxesDlg_h
#define INC_TChkBoxesDlg_h

// ----------------------------------------------------------------------------
// Copyright (c) 1999 Thomas E. Hilinski. All rights reserved.
// Unauthorized distribution, duplication, sale, and use is prohibited by law.
//
//	This software is made available under the terms of the
//	GNU LIBRARY GENERAL PUBLIC LICENSE.
//	This copyright notice must remain intact and in place.
// ----------------------------------------------------------------------------
//	Project:  V GUI Enhancement
//	File:	  TChkBoxesDlg.h
//	Class:	  TCheckBoxesDialog
//
//	Description:
//	Declaration of class for a V dialog displaying a variable number of
//	checkboxes.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, hilinski@lamar.colostate.edu, Nov99
//	History:
//	Feb03 - version 1.10
//	* Changed name from TCheckBoxesDlg to TCheckBoxesDialog.
//	* Misc. cleanup and added const-ness.
//	* Tested on MS Windows 2000 and X11R6/Motif.
// ----------------------------------------------------------------------------
//	To use:
//	In the constructor, provide (1) a multi-line message telling the user
//	what the buttons are about; (2) the number of radiobuttons to be
//	added, and (3) optionally, a title for the dialog box (the default
//	is "Select:").
//	Add checkboxes with the member function "AddChoice".
//	If you want to have your checkboxes in multiple columns, use
//	the function "NextColumn" before the "AddChoice" which will begin
//	the new column.
//	When ready to get a response from the user, use the member function
//	"GetChoices", which returns a pointer to an array of bools
//	which corresponds to the checkboxes. If the return value is M_Cancel,
//	the user pressed "Cancel".
// ----------------------------------------------------------------------------

#include <v/vmodald.h>

class TCheckBoxesDialog : public vModalDialog
{
public:
	//--- types
	enum TCDErrors		// error flags
	{
	  NoError, 		// no error - FIRST ENUM ITEM ALWAYS
	  MemoryAlloc,		// memory allocation error
	  NullText,		// null pointer to choice text
	  NoChoices,		// empty choices list
	  ZeroChoices,		// choice count in constructor is zero
	  TooMany,		// exceeded the number of choices requested
	  UnknownError		// unknown error - LAST ENUM ITEM ALWAYS
	};

	//--- constructors and destructor
	TCheckBoxesDialog (
	  vBaseWindow * const bw,		// pointer to window
	  char const * const msg,		// message at top of choices
	  short const numChoices,		// number of choices
	  char const * const title = "Select",	// title of dialog
	  bool const centerMe = true);		// flag to center the dialog

	TCheckBoxesDialog (
	  vApp * const app,			// pointer to application
	  char const * const msg,		// message at top of choices
	  short const numChoices,		// number of choices
	  char const * const title = "Select",	// title of dialog
	  bool const centerMe = true);		// flag to center the dialog
	~TCheckBoxesDialog ();

	//--- functions
	void AddChoice (			// Add a checkbox
	  char const * const checkboxText);
	void NextColumn ();			// Start a new column
	int GetChoices (			// Get user's response
	  bool const * &choices);		//   class owns array!

	//--- Retrieve info
	TCDErrors LastError () const		// Get last error code
	  { return lastError; }
	char const * const GetVersion () const	// Get version of this class.
	  { return version; }
private:
	//--- static data
	static char const * const version;		// class version string

	//--- data
	enum TCmdObjIDs	 		// IDs for CommandObjects
	{
	  CID_Msg     = 1000,		// ID for text above buttons
	  CID_Button1 = 2000,		// ID for first button
	  CID_Frame   = 3000,		// ID for frame
	  CID_EndOfList			// Last one always
	};
	CommandObject* coList;		// CommandObject list
	short bntCount;			// number of choices wanted
	short bntHave;			// number of choices added
	short curBtn;			// last radio button created
	short widestBtnID;		// ID of widest button in column
	short widestWidth;		// width of widest button in column
	int toRightOf;			// ID of button to be right of
	int belowOf;			// ID of button to below of
	bool* results;			// array of flags for final state
	int buttonSelected;		// button selected by user
	char* msgText;			// message text
	bool const centered;		// True if dialog is centered in appWin
	TCDErrors lastError;		// last error code

	//--- functions
	void Initialize (
	  char const * const msg,
	  short const numChoices);

public:
	//--- functions overridden: NOT FOR PUBLIC CONSUMPTION!
	void DialogDisplayed ();
	void DialogCommand (ItemVal id, ItemVal val, CmdType type);
};

#endif // INC_TChkBoxesDlg_h
