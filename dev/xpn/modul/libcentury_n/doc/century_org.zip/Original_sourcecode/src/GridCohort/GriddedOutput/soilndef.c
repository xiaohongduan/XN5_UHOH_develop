
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  soiln_ncid;			/* netCDF id */

/* variable ids */
int  som1n1_id, som1n2_id, som2n_id, som3n_id, strucn1_id, 
     strucn2_id, metabn1_id, metabn2_id;

int
soilndef(int *ntimes, char *history) {		/* create soiln.nc */

   int status;

   /* dimension ids */
   int  time_dim = 0;
   int  cell_dim = 0;

   /* variable shapes */
   int dims[2];

   /* enter define mode */
   status = nc_create("soiln.nc", NC_CLOBBER, &soiln_ncid);
   if (status != NC_NOERR) handle_error("nc_create(soiln.nc)", status);

   /* define dimensions */
   status = nc_def_dim(soiln_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(soiln_ncid, "cell", NC_UNLIMITED, &cell_dim);

   /* define variables */

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soiln_ncid, "som1n1", NC_FLOAT, 2, dims, &som1n1_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soiln_ncid, "som1n2", NC_FLOAT, 2, dims, &som1n2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soiln_ncid, "som2n", NC_FLOAT, 2, dims, &som2n_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soiln_ncid, "som3n", NC_FLOAT, 2, dims, &som3n_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soiln_ncid, "strucn1", NC_FLOAT, 2, dims, &strucn1_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soiln_ncid, "strucn2", NC_FLOAT, 2, dims, &strucn2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soiln_ncid, "metabn1", NC_FLOAT, 2, dims, &metabn1_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soiln_ncid, "metabn2", NC_FLOAT, 2, dims, &metabn2_id);

   /* assign attributes */
   status = nc_put_att_text (soiln_ncid, NC_GLOBAL, "history", strlen(history), history);
   status = nc_put_att_text (soiln_ncid, som1n1_id, "long_name", 
	strlen("surface_microbial_nitrogen"), "surface_microbial_nitrogen");
   status = nc_put_att_text (soiln_ncid, som1n1_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (soiln_ncid, som1n2_id, "long_name", 
	strlen("soil_microbial_nitrogen"), "soil_microbial_nitrogen");
   status = nc_put_att_text (soiln_ncid, som1n2_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (soiln_ncid, som2n_id, "long_name", 
	strlen("som2_nitrogen"), "som2_nitrogen");
   status = nc_put_att_text (soiln_ncid, som2n_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (soiln_ncid, som3n_id, "long_name", 
	strlen("som3_nitrogen"), "som3_nitrogen");
   status = nc_put_att_text (soiln_ncid, som3n_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (soiln_ncid, strucn1_id, "long_name", 
	strlen("surface_structural_nitrogen"), "surface_structural_nitrogen");
   status = nc_put_att_text (soiln_ncid, strucn1_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (soiln_ncid, strucn2_id, "long_name", 
	strlen("soil_structural_nitrogen"), "soil_structural_nitrogen");
   status = nc_put_att_text (soiln_ncid, strucn2_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (soiln_ncid, metabn1_id, "long_name", 
	strlen("surface_metabolic_nitrogen"), "surface_metabolic_nitrogen");
   status = nc_put_att_text (soiln_ncid, metabn1_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (soiln_ncid, metabn2_id, "long_name", 
	strlen("soil_metabolic_nitrogen"), "soil_metabolic_nitrogen");
   status = nc_put_att_text (soiln_ncid, metabn2_id, "units", strlen("g/m2"), "g/m2");

   /* leave define mode */
   status = nc_enddef (soiln_ncid);
   return 0;
}
