#ifndef INC_TDataGridDlg_h
#define INC_TDataGridDlg_h

// ----------------------------------------------------------------------------
// Copyright (c) 1999 Thomas E. Hilinski. All rights reserved.
// Unauthorized distribution, duplication, sale, and use is prohibited by law.
//
//	This software is made available under the terms of the
//	GNU LIBRARY GENERAL PUBLIC LICENSE.
//	This copyright notice must remain intact and in place.
// ----------------------------------------------------------------------------
//	Project:  V GUI Enhancement
//	File:	  TDataGridDlg.h
//	Class:	  TDataGridDlg
//
//	Description:
//	A class for a modal dialog displaying a Data Grid.
//	Requires the V GUI library, version 1.22 or higher.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, hilinski@lamar.colostate.edu, Aug99
//	History:
//	Feb03	Tom Hilinski
//	* Version 1.10
//	* Misc. cleanup.
//	* Changed some arrays to std::vector and std::string,
//	  and made use of std algorithms.
//	* Testing with V 1.27 in Windows 2000 and X11R6.
// ----------------------------------------------------------------------------

#include <v/vmodald.h>
#include <vector>
#include <string>

class TDataGridDlg : public vModalDialog
{
public:
	//--- types
	enum TDtGrdErrors	// error flags
	{
	  NoError, 		// no error - FIRST ENUM ITEM ALWAYS
	  MemoryAlloc,		// memory allocation error
	  NoData,		// null pointer to data
	  NoFormat,		// empty or null format string
	  BadDimension,		// row or col dimension <= 0
	  NoTitles,		// empty or null list of column titles
	  UnknownError		// unknown error - LAST ENUM ITEM ALWAYS
	};

	//--- constructors and destructor
	TDataGridDlg (
	    vApp * const parent,		// ptr to parent
	    short useCellsWide = 4,		// num. cells in grid width
	    short useCellsTall = 4,		// num. cells in grid height
	    char const * const useTitle		// dialog title
	    			 = "Data",
						//   NULL-term string
	    char const * const useCaption	// caption (multiline)
	    			 = NULL,
						//   NULL-term string
	    char const * const * useColTitles	// column titles
	    			 = NULL,
						//   NULL-term list of
						//   NULL-term strings.
	    bool roFlag = false);		// true if read-only data
	TDataGridDlg (
	    vBaseWindow * const parent,		// ptr to parent
	    vApp * const useAppParent,		// ptr to application parent
	    short useCellsWide = 4,		// num. cells in grid width
	    short useCellsTall = 4,		// num. cells in grid height
	    char const * const useTitle		// dialog title
	    			 = "Data",
						//   NULL-term string
	    char const * const useCaption	// caption (multiline)
	    			 = NULL,
						//   NULL-term string
	    char const * const * useColTitles	// column titles
	    			 = NULL,
						//   NULL-term list of
						//   NULL-term strings.
	    bool roFlag = false);		// true if read-only data
	~TDataGridDlg ();

	//--- functions
	//--- Specify the data to display.
	// Arguments:
	//	useData		data array (char*, float, double, int, long)
	//	useRowDim	row dimension of data
	//	useColDim	column dimension of data
	// Returns false if successful, else true if not.
	bool UseData (				// array of char*
		char** useData,
		const short useRowDim,
		const short useColDim);
	bool UseData (				// array of const char*
		const char** useData,
		const short useRowDim,
		const short useColDim);
	bool UseData (				// array of char
		char* useData,
		const short useRowDim,
		const short useColDim);
	bool UseData (	      			// array of const char
		const char* useData,
		const short useRowDim,
		const short useColDim);
	bool UseData (	      			// array of float
		float* useData,
		const short useRowDim,
		const short useColDim);
	bool UseData (	      			// array of const float
		const float* useData,
		const short useRowDim,
		const short useColDim);
	bool UseData (	      			// float with format
		float* useData,
		const char* format,
		const short useRowDim,
		const short useColDim);
	bool UseData (	      			// const float w/format
		const float* useData,
		const char* format,
		const short useRowDim,
		const short useColDim);
	bool UseData (	      			// array of double
		double* useData,
		const short useRowDim,
		const short useColDim);
	bool UseData (			      	// array of const double
		const double* useData,
		const short useRowDim,
		const short useColDim);
	bool UseData (			     	// double with format
		double* useData,
		const char* format,
		const short useRowDim,
		const short useColDim);
	bool UseData (			     	// const double with format
		const double* useData,
		const char* format,
		const short useRowDim,
		const short useColDim);
	bool UseData (				// array of short
		short* useData,
		const short useRowDim,
		const short useColDim);
	bool UseData (				// array of const short
		const short* useData,
		const short useRowDim,
		const short useColDim);
	bool UseData (				// array of int
		int* useData,
		const short useRowDim,
		const short useColDim);
	bool UseData (				// array of const int
		const int* useData,
		const short useRowDim,
		const short useColDim);
	bool UseData (				// array of long
		long* useData,
		const short useRowDim,
		const short useColDim);
	bool UseData (				// array of const long
		const long* useData,
		const short useRowDim,
		const short useColDim);

	//--- Specify functions to call upon corresponding events.
	void UseHelpFunction (				// "Help" button
		const void (*useFunction)(vApp * const parent) );

	//--- Set flags
	void SetReadOnly (const bool roFlag);		// true if readonly
	void DisplayRowNumbers (const bool rowNumFlag);	// true if row numbers

	//--- Display and interact with the data grid
	bool DisplayGrid ();			// Display the dialog.

	//--- Retrieve info
	TDtGrdErrors LastError () const		// get last error code
		{ return lastError; }
	const char* GetVersion () const		// Get version of this class.
		{ return version; }

private:
	//--- data types
	// Constants for CommandObject identifiers
	enum
	{
		CO_Start = 0,			// start of enum
		CO_Caption, 			// caption
		CO_ColTitle1,			// first column title
		CO_RowNumber1 = 1002,		// first row number
		CO_GridFrame = 2002,		// frame for data grid
		CO_UpperLeftSpacer,		// upper left corner spacer
		CO_ColTitlesFrame,		// frame for column titles
		CO_RowNumbersFrame,		// frame for row numbers
		CO_CellsFrame,			// frame for data grid cells
		CO_Cell1 = 3001,		// first grid cell (~16K max)
		CO_SliderVer = 20000,		// vertical slider
		CO_SliderHor,			// horizontal slider
		CO_ButtonRowSpace,		// space between slider/buttons
		CO_End_Of_List			// last entry always!
	};
	// Specifier for type of data
	enum TDataType
	{
		DT_Unknown,		// first one always!
		DT_char,		// char data type
		DT_string,		// char*
		DT_float,		// float
		DT_double,		// double
		DT_short,		// short int
		DT_int,			// int
		DT_long,		// long int
		DT_End_Of_List		// last entry always!
	};
	typedef unsigned short			TSize;
	typedef std::vector<TSize>		TSizeArray;

	//--- static data
	static const char* version;		// class version string
	static const short maxColTitles;	// max col titles displayed
	static const short maxRowNumbers;	// max row #s displayed
	static const unsigned int maxCells;	// max cells displayed
	static const char* rowNumMaxWidthStr;	// row number max width
	static const short maxCellChars;	// maximum length of cell text
	static const char* defFltFmt;		// default float format
	static const short defFltFmtLen;	// default float fmt char len
	static const char* defDblFmt;		// default double format
	static const short defDblFmtLen;	// default double fmt char len
	static const char* defShortFmt;		// default short format
	static const short defShortFmtLen;	// default short fmt char len
	static const char* defIntFmt;		// default int format
	static const short defIntFmtLen;	// default int fmt char len
	static const char* defLongFmt;		// default long format
	static const short defLongFmtLen;	// default long fmt char len
	static const char* emptyStr;		// empty string pointer ("")

	//--- data
	vApp * const appParent;			// ptr to parent vApp
	CommandObject* cmdList;			// dialog elements
						//--- grid display
	std::string caption;			// caption text (multiline)
	TSize gridCols, gridRows;		// grid dimensions
	TSize cellsDisplayed;		// number of displayed cells
	TSizeArray colWidth;			// V's column size of cells
	bool fixedWidth;			// true if column width fixed
	TSize sumColWidths;			// width - displayed columns
	const char** colTitles;			// column titles
	TSize numColTitles;			// number of column titles
	char** rowNumStrings;			// row number strings
						//--- data
	const void* userData;			// ptr to user's data
	TDataType dataType;			// user's data type
	char** data;				// displayed data array
	TSize dataRows, dataCols;		// data dimensions
	TSize dataSize;				// size of linear data array
	TSize leftCol, topRow;			// left/top displayed data
						//   internally.
						//--- function pointers
	const void (*helpEvtFunc)(		// save event function
		vApp * const useParent);
						//--- flags
	bool initDialog;			// true when initializing
	bool readOnly;				// true if read-only data
	bool rowNumbers;			// true if display row numbers
	int termStatus;				// true if OK pressed, or false
	bool* dataChanged;			// array - true if data changed
	bool modified;				// true if any data changed
	TDtGrdErrors lastError;			// last error code

	//--- functions
	void ConstructMe (			// common constructor
		short useCellsWide,		//   num. cells in grid width
		  short useCellsTall,		//   num. cells in grid height
		  const char* useCaption);	//   caption (multiline)

	void Initialize ();		// initialize data members
	void CopyThisData (		// copy to data: const char*
		const char** useData);
	void CopyThisData (		// copy to data: const char
		const char* useData);
	void CopyThisData (		// copy to data: const float
		const float* useData);
	void CopyThisData (		// copy to data: const float w/format
		const float* useData,
		const char* format);
	void CopyThisData (		// copy to data: const double
		const double* useData);
	void CopyThisData (		// copy to data: const double w/format
		const double* useData,
		const char* format);
	void CopyThisData (		// copy to data: const short
		const short* useData);
	void CopyThisData (		// copy to data: const int
		const int* useData);
	void CopyThisData (		// copy to data: const long
		const long* useData);
	void BuildCmdList ();		// build the list of dialog controls
					// display data the grid
	void LoadGrid (const short ulRow, const short ulCol);
	void UpdateRowNumbers (		// display row numbers
	  const short newTopRow);
	void UpdateColTitles (		// display column titles
	  const short newLeftCol);
	void EnableSaveButton ();	// Enable/Disable the save button.
	void Clear ();			// reset spreadsheet to default state
					//--- Clear the data members
	void ClearData ();		// clear the data array
	void ClearColTitles ();		// clear the column titles
	void ClearRowNumStrings ();	// clear the row number strings
					//--- Clear the displayed elements:
	void ClearDispCaption ();	// Erase the caption
	void ClearDispColTitles ();	// Erase the column titles
	void ClearDispRowNumbers ();	// Erase the row number strings
	void ClearDispData ();		// Erase data in displayed grid
					//--- utility functions
	void CalcColWidths ();		// calculate width of columns
	void BuildRowNumList ();	// builds a list of row number strings
	TSize GridSizeVertV ();		// calc V vertical size of cell grid
	TSize GridSizeHorV ();		// calc V horizontal size of cell grid
	bool NewDataMemory (		// Allocate memory for data array;
					// returns false if successful.
	  const short useRowDim,	//   row dimension
	  const short useColDim);	//   column dimension
	bool SaveColTitles (		// Save col titles in member array
	  char const * const * useColTitles);
	void ResetChangedFlags ();	// Reset the dataChanged array.
	void strtrim (			// Trim lead/trailing spaces from string
	  char* s);			// string to trim blanks from.
	void strtrtr (			// Trim trailing spaces from string.
	  char* s);			// string to trim blanks from.
	void DelStrListNT (		// Delete a list of strings
	  char** &list);		//   null-terminated string list
					//--- Event handlers
	void Evt_GetCellData (const int cellNum);
	void Evt_VerticalSlider (const int value);
	void Evt_HorizontalSlider (const int value);
	void Evt_SaveData ();
					//--- User-interaction functions
	void ConfirmSave ();		// ask user to save data

	//--- functions that are platform-specific
	TSize CharToTextLabelLengthV (	// Transform length of a text label
	  TSize const labelLength	//   to native display units
	  ) const;
	TSize CharToTextDataLengthV (	//Transform length of input box text
	  TSize const dataLength	//   to native display units
	  ) const;
	TSize LabelToBeDataLength (	// Adjust string length to data length
	  TSize const stringLength	//   will be label, but want data len.
	  ) const;

public:
	//--- functions overridden: NOT FOR PUBLIC CONSUMPTION!
	void DialogDisplayed ();
	void DialogCommand (ItemVal id, ItemVal val, CmdType type);
};

#endif // INC_TDataGridDlg_h
