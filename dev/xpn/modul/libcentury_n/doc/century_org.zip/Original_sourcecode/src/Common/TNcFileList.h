#ifndef _TNcFileList_h_
#define _TNcFileList_h_

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TNcFileList.h
//	Classes:  TNcFileList
//
//	Description:
//	Class for building a list of netCDF files of a particular type.
//
//	Author:	Tom Hilinski, Sep98, tom.hilinski@colostate.edu
// ----------------------------------------------------------------------------
//	History:
//	Jan00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Operator= : added check for assignment to self, and changed to return
//	  a reference to this rather than a copy of this.
// ----------------------------------------------------------------------------
//	Copyright 1998-2000 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "ncftypes.h"
// STL
// Borland C++ 5.x flags
#pragma warn -csu
#include <vector>
#include <string>
#pragma warn +csu

class TNcFileList
{
  public:
	//--- constructors and destructor
	TNcFileList (
		char const** const usePathList,	// null-term list of paths
		const TNcFileType useType);	// netCDF file type
	~TNcFileList ();
	TNcFileList (const TNcFileList &obj);	// copy constructor
	//--- operator overloads
	TNcFileList& operator = (const TNcFileList &obj);
	TNcFileList operator + (const TNcFileList &obj);
	char const* operator [] (const int i) const
		{ if (i >= 0 && (unsigned int)i < nameList.size() )
			return nameList[i].c_str();
		   else return 0;
		}

	//--- functions
	char const** GetList () const;		// returns pointer to list
	short GetCount () const			// returns size of list
		{ return (short) nameList.size(); }
	bool IsError () const			// true if error occurred
		{ return errFlag; }
	bool IsEmpty () const			// returns true if null list
		{ return nameList.size() == 0; };
	void Clear ();				// "clear" data members

  private:
	// type for STL name list vector
	typedef std::vector<std::string> TNcFileNameList;

	//--- data
	char const** const pathList;	// list of paths to search in
	TNcFileType const type;		// netCDF file type
	TNcFileNameList nameList;	// list of fully-qualified file names
	bool errFlag;			// true if error occurred

	//--- functions
	void Initialize ();			// initialize members
	bool BuildFileList ();			// builds list of valid files
	bool IsCenturyOutput (char const* name);	// true if output file
	bool AddToList (char const* name);	// add name to name list
	void Copy (const TNcFileList &fromObj);	// copy to this
};

#endif // _TNcFileList_h_
