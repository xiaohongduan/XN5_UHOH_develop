// ----------------------------------------------------------------------------
//	Copyright (c) 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  nutrlm.cpp
//	Class:	  TCentury
//	Function: NutrientLimitation
//
//	Description:
//	Nutrient limitation for plants is based on cProdDemand.
//	Called by RestrictProduction.
// ----------------------------------------------------------------------------
//	History:
//	Apr00   Tom Hilinski, tom.hilinski@colostate.edu
//	* Cleaned up code and optimized.
//	Apr05 Tom Hilinski
//	* Added parameter giving C to biomass conversion factor
//	  (from DayCent4.5).
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include <sstream>

void TCentury::NutrientLimitation (
	short const nparts,		// no. of parts (values: CPARTS, FPARTS)
	float const * const cfrac,	// array [nparts]:
	float const * const eAvailable, // array [NUMELEM]:
	float const * const maxec,	// array [NUMELEM]:
	float const * const maxeci,	// array [FPARTS,NUMELEM]:
					//   maximum average E/C of whole plant
	float const * const mineci,	// array [FPARTS,NUMELEM]:
					//   minimum average E/C of whole plant
	float const snfxmx,		// Symbiotic N fixation maximum
					//   (gN fixed/gC new growth)
	float const factorCtoBiomass,	// C to biomass conversion factor
	float & cprodl,			// NPP: modified here
	float * const eprodl,		// array [NUMELEM]:
	float & plantNfix)		// symbiotic N-fixation (gN/m2)
{
#define mineci_ref(a_1,a_2)	mineci[(a_2)*FPARTS + (a_1)]
#define maxeci_ref(a_1,a_2)	maxeci[(a_2)*FPARTS + (a_1)]

    // check function parameters
    Assert (nparts <= FPARTS);
    Assert (site.nelem >= N && site.nelem <= NUMELEM);

    // initialize return values
    plantNfix = 0.0f;
    // locals
    float const maxSymNFixation = snfxmx * cprodl; // Max symbiotic N fixation
    float totalAvailableE[NUMELEM];	// total available E
    float cpbe[NUMELEM] = { 0.0f, 0.0f, 0.0f };	// C production limited by E
    float ecRatio[15];		// [FPARTS][NUMELEM]: Actual E/C ratio by part
#define ecRatio_ref(a_1,a_2)	ecRatio[(a_2)*FPARTS + (a_1)]

    // Compute production limitation
    // P and S first so that potential N fixation accounts for P and S
    // limitation on yield, AKM 18/8/2000
    // for (short e = 0; e < site.nelem; ++e)
    for (short e = site.nelem - 1; e >= 0; --e)
    {
	// Carbon production demand for E based on max. E/C ratio.
	float const cProdDemand = cprodl * maxec[e];
	if (cProdDemand <= 1.0e-8f)
	{
	    std::ostringstream os;
	    os << "Nutrient limitation: C production demand = 0:"
		<< "\n Element = " << (e == N ? 'N' : e == P ? 'P' : 'S')
		<< "\n C in production = " << cprodl
		<< "\n C:E maximum = " << (1.0f / maxec[e]);
	    asynchCom.SendWarningMessage ( os.str() );
	    return;	// cannot continue
	}

	totalAvailableE[e] =
		( e == N ? (eAvailable[e] + maxSymNFixation) : eAvailable[e] );
	if (totalAvailableE[e] <= 1.0e-6f)
	{
	    std::ostringstream os;
	    os << "Nutrient limitation: total available E = 0:"
		<< "\n Element = " << (e == N ? 'N' : e == P ? 'P' : 'S')
		<< "\n available N = " << totalAvailableE[e];
	    asynchCom.SendWarningMessage ( os.str() );
	    nps.elimit = (float)(e + 1);	// save limiting element
	    return;	// cannot continue
	}


	// New C/E ratios by part based on E available.
	if (totalAvailableE[e] - cProdDemand > 1.0e-6f) // avail. E > C demand?
	{
	    for (short part = 0; part < nparts; ++part)
		ecRatio_ref (part, e) = maxeci_ref (part, e);
	}
	else	// C demand for E > available E
	{
	    // available/demand ratio
	    float ecRatioDemand = totalAvailableE[e] / cProdDemand;
	    // constrain ratio to 0-1 -mdh 5/10/01
	    // ecRatioDemand = std::min (1.0f, ratio);
	    // ecRatioDemand =  std::max (0.0f, ratio);
	    Assert (ecRatioDemand <= 1.0f);
	    Assert (ecRatioDemand >= 0.0f);
	    for (short part = 0; part < nparts; ++part)
	    {
		ecRatio_ref (part, e) =
			mineci_ref (part, e) +
			( maxeci_ref (part, e) - mineci_ref (part, e) ) *
			ecRatioDemand;
		Assert (ecRatio_ref (part, e) > 1.0e-6f); // exceeded precision?
	    }
	}

	// Total potential production with nutrient limitation
	cpbe[e] = 0.0f;				// C production limited
	for (short part = 0; part < nparts; ++part)
	{
		// Calculate the average nutrient content
		// OLD:
		// cpbe[e] += cfrac[part] * ecRatio_ref (part, e);
		// NEW:
		if ( part < 2 )
			cpbe[e] += cfrac[part] * ecRatio_ref (part, e) / 2.5f;
		else
	    		cpbe[e] += cfrac[part] * ecRatio_ref (part, e) / 2.0f;
	}
	cpbe[e] *= factorCtoBiomass;
	Assert (cpbe[e] != 0.0f);
	// potential production for the element with nutrient limitation
	cpbe[e] = totalAvailableE[e] / cpbe[e];

	// Put automatic fertilization here when necessary
//c ....... Automatic fertilization, AKM 18/8/2000
//          if ((aufert .gt. 0).and.(cpbe(iel)/cprodl .lt. aufert)) then
//            cpbe(iel) = cprodl * aufert
//c ......... Mathcad equations
//            do ipart = 1, nparts
//              sum = sum + cfrac(ipart) *
//     &              (maxeci(ipart,iel)-mineci(ipart,iel))
//            end do
//            afert(iel) = max((-aufert * cprodl * demand * minec(iel) /
//     &                       (aufert * cprodl * sum - demand)) -
//     &                        totale, 0.0)
//          endif

    } // for each element

    // Compute the limiting element
    for (short e = 0; e < site.nelem; ++e)
	if (cprodl > cpbe[e])
	{
	    cprodl = cpbe[e];			// save as NPP
	    nps.elimit = (float)(e + 1);	// save limiting element
	}

    // Adjust so that the N/P ratio of the leaves does not exceed the
    // observed critical value of 13.5, cak - 04/05/02
    // Note:
    // Needs new parameter, maximum N/P ratio, for phosphorus code
    // from tree.100 parameter set.
//    if ( site.nelem >= P )
//    {
//	if ( ecRatio_ref (LEAF, N) / ecRatio_ref (LEAF, P) > parfs.maxnp )
//		ecRatio_ref (LEAF, N) = ecRatio_ref (LEAF, P) * parfs.maxnp;
//    }

    // Recompute EPRODL
    for (short e = 0; e < site.nelem; ++e)
    {
	eprodl[e] = 0.0f;
	// Total potential production with nutrient limitation
	for (short part = 0; part < nparts; ++part)
	{
	    elementUptake_ref (part, e) =
		cprodl * cfrac[part] * ecRatio_ref (part, e);
	    eprodl[e] += elementUptake_ref (part, e);
	}
	Assert (eprodl[e] != 0.0f);
    }
    // Check to make sure the total production won't exceed what's available.
    float const excessNFraction =
    	(eprodl[N] - (totalAvailableE[N] + maxSymNFixation)) /
    	(totalAvailableE[N] + maxSymNFixation);
    if ( excessNFraction > 0.0f )
    {
	if ( excessNFraction > 0.07f )
	// if ( excessNFraction > 0.001f )
	{
	    std::ostringstream os;
	    os << "Nutrient limitation: Precision error:"
		<< "\n excess N fraction = " << excessNFraction
		<< "\n available N = " << (totalAvailableE[N] + maxSymNFixation)
		<< "\n N in production = " << eprodl[N]
		<< "\n C in production = " << cprodl
		<< "\n C demand = " << (cprodl * maxec[N])
		<< "\n C potential production = " << cpbe[N]
		<< "\n C:N ratio of veg parts =";
	    for (short part = 0; part < nparts; ++part)
		os << ' ' << (1.0f / ecRatio_ref(part, N));
	    os << "\n N uptake of veg parts =";
	    for (short part = 0; part < nparts; ++part)
	    	os << ' ' << elementUptake_ref(part, N);
	    os << std::endl;
	    asynchCom.SendWarningMessage ( os.str() );
	}
	// rebalance
	eprodl[N] = totalAvailableE[N]; // prevent precision error - mdh 10/8/02
    }

    // Compute N fixation which actually occurs and add to the
    //   N fixation accumulator.
    plantNfix = std::max (eprodl[N] - eAvailable[N], 0.0f);

#undef maxeci_ref
#undef mineci_ref
#undef ecRatio_ref
}

//--- end of file nutrlm.cpp ---
