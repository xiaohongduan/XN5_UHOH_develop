
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include "gridconst.h"

/* Prototypes */
void lineparse(char*, float[], int);

/* Externally defined variables */
extern int curr_row;
extern FILE *fp_s[NSOILFILES];

/* Read soil type for current simulation from SVF files */

/* This function reads the POTSDAM soil classifications and
 * returns the sand and clay fractions as well as the soil
 * classification number for use in parsing file names.
 */
int
getsoil_(float *bulkd, float *clay, float *sand, float *rock, float *zminrl,
	int *nrow, int *ncol)
{
	static char lineS[NSOILFILES][MAXR];
	static float aclay[MAXE]; 	/* Array of clay fractions from grid */
	static float asand[MAXE]; 	/* Array of sand fractions from grid */
	static float abulkd[MAXE]; 	/* Array of bulk density values from grid */
	static float arock[MAXE]; 	/* Array of rock fraction values from grid */
	static float azminrl[MAXE]; 	/* Array of mineral soil depths from grid */
	int i, retval;

	while (*nrow >= curr_row)
	{
		for (i=0; i<NSOILFILES; i++)
		{
			fgets(lineS[i], MAXR, fp_s[i]);
		}

		if (curr_row == *nrow)
			lineparse(lineS[0], abulkd, (int)MAXE);
			lineparse(lineS[1], aclay, (int)MAXE);
			lineparse(lineS[2], asand, (int)MAXE);
			lineparse(lineS[3], arock, (int)MAXE);
			lineparse(lineS[4], azminrl, (int)MAXE);

		/* Increment current row counter */
		curr_row += 1;
	}

	/* Do you have the correct row? */
	if (curr_row == *nrow + 1)
	{
		*bulkd = (int) abulkd[*ncol];
		*clay  = (int) aclay[*ncol];
		*sand  = (int) asand[*ncol];
		*rock  = (int) arock[*ncol];
		*zminrl  = (int) azminrl[*ncol];
	}

        printf("nrow = %d\n", *nrow);
	printf("curr_row = %d\n", curr_row);
	printf("sand = %f\n", *sand);
	printf("clay = %f\n", *clay);
	printf("bulkd = %f\n", *bulkd);
	printf("rock = %f\n", *rock);
	printf("zminrl = %f\n", *zminrl);

	/* Determine if the cell values are valid */

	retval = 0;
	if (*sand < 0) retval = 1;
	if (*clay < 0) retval = 1;
	if (*bulkd < 0) retval = 1;
	if (*rock < 0) retval = 1;
	if (*zminrl < 0) retval = 1;

        if (retval > 0) fprintf(stderr, "Error in getsoil\n");

	return retval;
}
