// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCentException.cpp
//	Class:	  TCentException
//
//	Description:
//	Implementation of class for exception messages,
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TCentException.h"

std::string TCentException::msg;

// The order of these strings matches the order of the enum values in the
// class declaration.
char const * const TCentException::errorString
	[TCentException::CE_NUM_ERRORS + 1] =
{
    "",							// CE_NOERR
    // misc. errors
    "Century error.",					// CE_UNKNOWN_ERROR
    "Total of forest C fractions is not equal to 1.",	// CE_FCFRAC
    "Error in ran1: j > 97 or j < 1",			// CE_RAN1
    "Microcosm is only for a crop/grassland system.",	// CE_MICRO
    "Error calculating solution mineral P fraction.",	// CE_PFRAC
    "Memory allocation error.",				// CE_MEMALC
    "Output variable class has invalid float count.",	// CE_OVCFCI
    "Error in the physical soil: ",			// CE_PHSOIL
    // parameter database errors
    "A parameters database has not been specified:",	// CE_NSPPDB
    "A parameters database is empty:",			// CE_EMPPDB
    "Option parameter count is not what is expected.",	// CE_OPCBAD
    "Failed attempting to read a parameters database.",	// CE_RDPDBF
    "Invalid parameter value.",				// CE_PARMIV
    // parameter file option set errors
    "Tree option not in the parameter file.",		// CE_ONFTRE
    "Tree removal option not in the parameter file.",	// CE_ONFTRR
    "Crop option not in the parameter file.",		// CE_ONFCRP
    "Cultivation option not in the parameter file.",	// CE_ONFCUL
    "Fertilization option not in the parameter file.",	// CE_ONFFER
    "Fire option not in the parameter file.",		// CE_ONFFIR
    "Grazing option not in the parameter file.",	// CE_ONFGRA
    "Harvest option not in the parameter file.",	// CE_ONFHAR
    "Irrigation option not in the parameter file.",	// CE_ONFIRR
    "Organic matter option not in the parameter file.",	// CE_ONFORM
    "Error reading the fixed parameters database.",	// CE_RDFIXD
    // weather file errors
    "Unable to open the weather file.",			// CE_WTHRNO
    "Error reading the weather data file",		// CE_RDWTHR
    "Weather file has data that is out of sequence.",	// CE_WTHROS
    // management scheme errors
    "Management scheme failed verification.",		// CE_MGTINV
    "Management scheme has no block definitions.",	// CE_MGTNOB
    "Management scheme has no instances of blocks.",	// CE_NOINST
    "Weather source = file, but no file name given.",	// CE_WTHRFL
    "Block instance start year != to simulation year.",	// CE_INSTOS
    "Block has no instances in simulation time.",	// CE_BLKNOI
    "Management scheme is not specified or not found.",	// CE_NOMGMT
    "Management file specified is invalid.",		// CE_MGTFNV
    "Error in the management scheme.",			// CE_MGTERR
    // site parameter errors
    "Site parameters are not specified or not found.",	// CE_NOSITE
    "Site parameter sets are all empty.",		// CE_SITENS
    "Site parameter NLAYER is an invalid value.",	// CE_BDNLYR
    "Site parameter NLAYPG is an invalid value.",	// CE_BDNLPG
    "Unable to initialize the physical soil.",		// CE_NOSOIL
    "Error reading the site parameter descriptions.",	// CE_NOSTPD
    "Error writing the site parameters file.",		// CE_SITWNF
    "Error reading the site file.",			// CE_STRDER
    "Error in the site parameters.",			// CE_SITERR
    // output file errors
    "Output file of the same name already exists.",	// CE_PRVOUT
    "Output destination has not been specified.",	// CE_NOOUTF
    "Invalid output file type was specified.",		// CE_INVOFT
    "Previous output file is missing or invalid.",	// CE_NOPRVF
    "Unable to open the output file.",			// CE_OPNOUT
    "Error writing to the output file.",		// CE_WRTOUT
    "Invalid output file access mode was specified.",	// CE_IOFAMD
    "Invalid output file format was requested.",	// CE_IOFFMT
    "Unable to access output variable descriptions.",	// CE_NAOVND
    "Error in the output object.",			// CE_OUTERR
    // flow stack errors
    "Flow stack error.",				// CE_FLWERR
    "Flow schedule: Failed in add to the stack.",	// CE_FLWFAS
    "Flow schedule: Value of the source variable < 0.",	// CE_FLWSVN
    "Flow schedule: Amount to flow is too large.",	// CE_FLWHUG
    "Flow schedule: NULL pointer to source.",		// CE_FLWNFP
    "Flow schedule: NULL pointer to sink.",		// CE_FLWNTP
    "Flow schedule: source, sink pointers are equal.",	// CE_FLWTFE
    // 14C data file errors
    "Error reading the 14C data file.",			// CE_14CRDF
    "14C data file cannot match labeling year.",	// CE_14CNMY
    "14C data file name was not specified.",		// CE_14CNFN
    "Unable to access the 14C data file.",		// CE_14CFNA
    // Erosion/Deposition errors
    "Invalid erosion file name specified:",		// CE_IEROFN
    "Invalid deposition file name specified:",		// CE_IDEPFN
    "Deposition event without an erosion input file.",	// CE_DEPNEF
    "Invalid rate value in an erosion event.",		// CE_IREROD
    // all done!
    0							// last one always
};


//	ConstructMe
//	The common constructor.
void TCentException::ConstructMe (
	TCEIndex exceptionCode,			// type of exception
	std::string const & newMsg,		// message string
	char const * const fileLineStr)		// file and line string
{
	//--- Save the exception code
	if ( exceptionCode >= CE_UNKNOWN_ERROR &&
	     exceptionCode < CE_NUM_ERRORS)
		exitCode = exceptionCode;
	else
		exitCode = CE_UNKNOWN_ERROR;

	//--- Build the exception message string
	// add the exception code
	msg.reserve (1024);			// plenty of room in string
	msg = errorString[exitCode];
	if ( !newMsg.empty() )			// anything there?
	{
		msg += ":\n";
		msg += newMsg;
	}
	// add the file name an line number
	if ( fileLineStr && *fileLineStr )	// anything there?
	{
		msg += '\n';
		msg += fileLineStr;
	}
	msg += "\nEnding the simulation now.";
}

//--- end of file TCentException.cpp ---

