// ----------------------------------------------------------------------------
//	Copyright (c) 1998-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  About.cpp
//	Class:	  TAboutDialog
//
//	Description:
//	Class for the "About...' dialog for Century Model Interface & Century.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Jul98, tom.hilinski@colostate.edu
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TAboutDlg.h"
#include "externals.h"
#include "versionCMI.h"
#include "version.h"


char const * const TAboutDialog::title =
	"About Century and the Century Model Interface";

char const * const TAboutDialog::version =
		CMINickname " - the " CMIName " " CMIVersionLong "\n"
		CenturyName " " CenturyVersion "\n"
		"Operating System: " PLATFORM_NAME;

char const * const TAboutDialog::where =
		"Natural Resource Ecology Laboratory\n"
		"Colorado State University\n"
		"Web address: www.nrel.colostate.edu";

char const * const TAboutDialog::who =
		"Concept by William J. Parton.\n\n"
		"Design and implementation by Thomas E. Hilinski.\n"
		"Programmers: Thomas E. Hilinski, Sridhar Jillella,\n"
		"and Cindy Keough.\n\n"
		"Additional assistance from Robin Kelly,\n"
		"Rebecca McKeown, and Susan Lutz.";

char const * const TAboutDialog::notes =
		"Century 5 web site:\n"
		"www.nrel.colostate.edu/projects/century5/";

char const * const TAboutDialog::netCDF =
		"Database management uses the netCDF library\n"
		"from the Unidata Program Center.\n"
		"Web address: www.unidata.ucar.edu";

char const * const TAboutDialog::VLib =
		"Graphical User Interface uses the library\n"
		V_Version " for "
		#if defined(V_VersionWindows) || defined(MSWINDOWS)
			"Microsoft Windows 95/98/ME/NT/2000/XP"
		#elif defined(V_VersionX)
			"X Window System"
		#elif defined(V_VersionMotif)
			"OSF/Motif"
		#elif defined(V_VersionOS2)
			"OS/2"
		#else
			"(unknown operating system)"
		#endif
		".\n\n"
		"Copyright 1995-2000, Bruce E. Wampler.\n"
		"Web address: www.objectcentral.com";

char const * const TAboutDialog::copyright = CMICopyright;

CommandObject TAboutDialog::cmdList[] =
{
	// CMI version
	{C_Frame, 801, 0, "", NoList, CA_NoBorder, isSens, NoFrame, 0, 0},
	{C_Text, 105, 0, version, NoList, CA_NoBorder, isSens, 801, 0, 0},

	// Frame the following two frames together
	{C_Frame, 805, 0, "",
		NoList, CA_NoBorder, isSens, NoFrame, 0, 801},

	// who and where
	{C_Frame, 901, 0, "", NoList, CA_None, isSens, 805, 0, 0},
	{C_Text, 110, 0, where, NoList, CA_NoBorder, isSens, 901, 0, 0},
	{C_Text, 115, 0, who, NoList, CA_NoBorder, isSens, 901, 0, 110},

	// notes and acknowledgements
	{C_Frame, 905, 0, "", NoList, CA_None, isSens, 805, 901, 0},
	{C_Text, 120, 0, notes, NoList, CA_NoBorder, isSens, 905, 0, 0},
	{C_Text, 125, 0, netCDF, NoList, CA_NoBorder, isSens, 905, 0, 120},
	{C_Text, 130, 0, VLib, NoList, CA_NoBorder, isSens, 905, 0, 125},

	// copyright
	{C_Frame, 910, 0, "", NoList, CA_NoBorder, isSens, 805, 0, 901},
	{C_Text, 135, 0, copyright, NoList, CA_NoBorder, isSens, 910, 0, 0},

	// buttons
	{C_Button, M_OK, M_OK, " &OK ",
		NoList,	CA_DefaultButton, isSens, NoFrame, 0, 805},

	// all done!
	{C_EndOfList, 0, 0, 0, 0, CA_None, 0, 0}
};


void TAboutDialog::DialogCommand (ItemVal id, ItemVal val, CmdType type)
{
	switch (id)
	{
	  default:
		break;
	}
	// Default event processing
	vModalDialog::DialogCommand (id, val, type);
}

//--- end of file ---
