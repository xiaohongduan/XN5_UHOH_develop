// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  rdsiminfo.cpp
//	Class:	  TCenturyBase
//	Function: ReadSimulationInfo
//
//	Description:
// 	Read the entire management simulation into the member variable, mgmt.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jan98
//	History:
//	Jan99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved creation of 14C data file class instance to here from prelim.
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Uses new class members activeBlock and activeInstance.
//	* Added retrieval of the microcosm temperature.
//	Jun02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Remove block of code just above creating the instance list, which
//	  was an unused residual vestige (calc'd "vecSize").
//	Oct02	Tom Hilinski
//	* Moved into class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "TVerifyMgmt.h"
#include <cstring>

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::ReadSimulationInfo ()
{
	if ( !GetManagement().get() )			// anything to do?
		ThrowCentException (TCentException::CE_NOMGMT, 0);
	if ( GetManagement()->GetBlockCount() == 0 )		// any blocks?
	{
		if ( GetManagement()->IsError() )
			ThrowCentException (TCentException::CE_MGTNOB,
					    GetManagement()->GetErrorMsg());
		else
			ThrowCentException (TCentException::CE_MGTNOB, 0);
	}

	// To do: these error checks should be done elsewhere (config?)
	// check for fatal errors
	TVerifyMgmt verifyMgmt (
		const_cast<TMyManagement &>( *GetManagement() ) );
	bool const verifiedSimInfo = !verifyMgmt.VerifySimInfo ();
	if ( !verifiedSimInfo )
	{
		std::string errMsg = verifyMgmt.GetMsg();
		ThrowCentException (TCentException::CE_MGTINV, errMsg.c_str());
	}
	// check for non-fatal errors
	if ( GetManagement()->IsError() )
		asynchCom.SendWarningMessage ( GetManagement()->GetErrorMsg() );

	// save in the original Century variables
	TSimInfo const & si = GetManagement()->GetSimInfo ();
	st->startYear = si.yearStart;		// simulation start year
	st->endYear = si.yearEnd;		// simulation end year
	param.labtyp = si.labelType;		// CO2 labeling type
	if (param.labtyp == Lbl_14C)		// Open the c14 data file?
	{
		// get the 14C data file name
		if ( !si.c14FileName )				// empty?
			ThrowCentException (TCentException::CE_14CNFN, 0);
		std::string const c14FileName = si.c14FileName->GetFullName ();
		if ( c14FileName.empty() )			// empty?
			ThrowCentException (TCentException::CE_14CNFN, 0);
		// get a 14C class instance
    		c14.reset (new T14CData (c14FileName, si.labelYear) );
    		// TO DO: need validity check on class here
	}
	if ( si.microcosm )
	{
		microcosm.reset (new TMicrocosm);
		if ( si.microcosmTemp == 0.0f )
			microcosm->SetTemperature (1.0f);
		else
			microcosm->SetTemperature (si.microcosmTemp);
	}
	param.co2sys = (si.co2Effect ? 1.0f : 0.0f);	// CO2 effect flag
	if ((int)param.co2sys == 1)			// have effect?
	{
		param.co2tm[0] = si.co2YearStart; // CO2 effect year start
		param.co2tm[1] = si.co2YearEnd;	  // CO2 effect year end
	}
	sysType.Type() = si.initManagement;		// initial prod. sys.
	strcpy ( sysType.CropName(), si.initCrop );	// initial crop
	strcpy ( sysType.TreeName(), si.initTree );	// initial tree
	// To Do: should verify sysType here (see end of readblk.cpp)

	// create a list of block instances sorted by year, and save
	try
	{
	    blockInstanceList.reset ( new TInstanceList (*GetManagement()) );
	}
	catch (...)
	{
	    ThrowCentException (TCentException::CE_MEMALC, 0);
	}
	if ( blockInstanceList->GetCount() == 0)	// anything to do?
		ThrowCentException (TCentException::CE_NOINST, 0);  // ...no
}

//--- end of file ---
