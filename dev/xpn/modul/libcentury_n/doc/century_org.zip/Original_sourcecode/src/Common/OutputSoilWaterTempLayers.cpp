// ----------------------------------------------------------------------------
//	Copyright (c) 2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  OutputSoilWaterTempLayers.cpp
//	Class:	  OutputSoilWaterTempLayers
//
//	Description:
//	Writes soil water content and temperature by layer interval
//	to an output file in CSV format.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, July 2005
//	History: See header file.
// ----------------------------------------------------------------------------

#include "OutputSoilWaterTempLayers.h"
#include "AssertEx.h"
#include <fstream>
#include <sstream>
#include <iterator>

// write each interval
bool OutputSoilWaterTempLayers::Write (		// write the data
	float const outputTime)			// time of output
{
	if ( Open (std::ios::out | std::ios::app) )
		return true;	// failed

	char const comma = ',';
	fs << outputTime << comma << intervalThickness;

	float const soilDepth = depth[ depth.size() - 1 ];
	short const numIntervals =
	    std::min ( intervalMaxCount,
			static_cast<short>( soilDepth / intervalThickness ) );
	if ( soilDepth < intervalThickness )
		goto all_done;

	// soil water
	{
	    float top = 0.0f;
	    float bottom = intervalThickness;
	    for ( short i = 0; i < numIntervals; ++i )
	    {
		float const value = soilH2O.Quantity (
			top, bottom, depth, thickness);
		fs << comma << value;
		top = bottom;
		bottom += intervalThickness;
	    }
	    // blank cells?
	    for ( short i = numIntervals; i < intervalMaxCount; ++i )
		fs << comma << 0.0f;
	}

	// soil field capacity
	{
	    float top = 0.0f;
	    float bottom = intervalThickness;
	    for ( short i = 0; i < numIntervals; ++i )
	    {
		float const value =
		    fldCapacity.WtdMean (
			top, bottom, depth, thickness) *
		    intervalThickness;
		fs << comma << value;
		top = bottom;
		bottom += intervalThickness;
	    }
	    // blank cells?
	    for ( short i = numIntervals; i < intervalMaxCount; ++i )
		fs << comma << 0.0f;
	}

	// soil water content at saturation
	{
	    float top = 0.0f;
	    float bottom = intervalThickness;
	    for ( short i = 0; i < numIntervals; ++i )
	    {
		float const value =
		    WtdMean (thetaSat, top, bottom, depth, thickness) *
		    intervalThickness;
		fs << comma << value;
		top = bottom;
		bottom += intervalThickness;
	    }
	    // blank cells?
	    for ( short i = numIntervals; i < intervalMaxCount; ++i )
		fs << comma << 0.0f;
	}

	// soil temperature
	{
	    float top = 0.0f;
	    float bottom = intervalThickness;
	    for ( short i = 0; i < numIntervals; ++i )
	    {
		float const value = soilTemp.WtdMean (
			top, bottom, depth, thickness);
		fs << comma << value;
		top = bottom;
		bottom += intervalThickness;
	    }
	    // blank cells?
	    for ( short i = numIntervals; i < intervalMaxCount; ++i )
		fs << comma << 0.0f;
	}

    all_done:
	fs << std::endl;
	Close ();
	return false;		// successful
}

void OutputSoilWaterTempLayers::CreateTitles (
	TStringArray & titles)		// list of column titles
{
	titles.reserve (intervalMaxCount * 2 + 2);
	titles.push_back ("time");
	titles.push_back ("thickness");
	// soil water
	for ( short i = 0; i < intervalMaxCount; ++i )
	{
		std::stringstream swcStr;
		swcStr << "swc" << i;
		titles.push_back ( swcStr.str() );
	}
	// soil field capacity
	for ( short i = 0; i < intervalMaxCount; ++i )
	{
		std::stringstream stStr;
		stStr << "fc" << i;
		titles.push_back ( stStr.str() );
	}
	// soil water content at saturation
	for ( short i = 0; i < intervalMaxCount; ++i )
	{
		std::stringstream swcStr;
		swcStr << "swcSat" << i;
		titles.push_back ( swcStr.str() );
	}
	// soil temperature
	for ( short i = 0; i < intervalMaxCount; ++i )
	{
		std::stringstream stStr;
		stStr << "st" << i;
		titles.push_back ( stStr.str() );
	}
}

bool OutputSoilWaterTempLayers::DoWriteColumnTitles (
	TStringArray const & titles)		// list of column titles
{
	if ( titles.empty() )
		return true;	// failed

	if ( Open (std::ios::out | std::ios::trunc) )
		return true;	// failed

	char const quote = '\"';
	char const comma = ',';
	TStringArray::const_iterator iTitles = titles.begin();
	while ( iTitles != titles.end() )
	{
		if ( iTitles != titles.begin() )
			fs << comma;
		fs << quote << (*iTitles) << quote;

		++iTitles;
	}
	fs << std::endl;
	Close ();
	return false;			// successful
}

//	WtdMean
//	Weighted average of property over the depths specified.
//	Notes:
//	Snipped from class TSoilProperty.
//	The weighted mean of a property is different than the
//	mean of an amount. Within a layer, the property is constant
//	(assuming a homogenous layer) no matter the amount of the layer.
//	The thickness weighting is only needed across layers;
//	General formula:
//		sum(layer thickness * value) / total thickness
float OutputSoilWaterTempLayers::WtdMean (
	T1DDoubleArray const & values,		// values to get mean of
	float const topDepth, 			// depth to top of layer (cm)
	float const bottomDepth,		// depth to bottom of layer (cm)
	TFloatArray const & depth,		// depth values
	TFloatArray const & thickness		// thickness values
	) const
{
	// error checks
	Assert ( topDepth >= 0.0f );
	Assert ( topDepth < bottomDepth );
	Assert ( bottomDepth > 0.0f );
	Assert ( bottomDepth <= depth[depth.size()-1] );
	if ( topDepth < 0.0f ||
	     topDepth > bottomDepth ||
	     bottomDepth < 0.0f ||
	     bottomDepth > depth[depth.size()-1] ||
	     depth.size() == 0 || thickness.size() == 0 )
		return 0.0f;

	// get indicies to the top and bottom layers
	size_type topIdx = ( topDepth == 0.0f ?
		0 :
		GetLayerIndex (topDepth) );
	size_type botIdx = GetLayerIndex (bottomDepth);
	if ( topIdx == botIdx )			// in same layer?
		return values(topIdx);		// return the property value

	// range spans layers, so get the weighted average
	float wtdSum;				// weighted sum of property
	// 1. upper fractional layer
	wtdSum = values(topIdx) * (depth[topIdx] - topDepth);
	// 2. lower fractional layer
	wtdSum += values(botIdx) * (bottomDepth - depth[botIdx - 1]);
	// 3. remaining layers
	if ( topIdx + 1 < botIdx )		// any more layers?
	{
		++topIdx;		// next full-thickness layer
		--botIdx;		// previous full-thickness layer
		// T1DDoubleArray::const_iterator v = values.begin() + topIdx;
		T1DDoubleArray::const_iterator v = values.begin();
		std::advance (v, topIdx); // make blitz happy
		TFloatArray::const_iterator t = thickness.begin() + topIdx;
		for ( size_type i = topIdx; i <= botIdx; ++i, ++v, ++t )
			wtdSum += *v * *t;
	}
	// 4. return the mean property
	return wtdSum / (bottomDepth - topDepth);
}

//	GetLayerIndex
// 	Returns zero-based layer index, given depth
//	Returns depth.size() if depth to search for is out of range.
OutputSoilWaterTempLayers::size_type
  OutputSoilWaterTempLayers::GetLayerIndex (
	float const findDepth		// depth to search for
	) const
{
	size_type layerIndex = (short)depth.size();
	if ( findDepth == 0.0f )
		layerIndex = 0U;
	else if ( findDepth > 0.0f && findDepth <= depth[depth.size() - 1])
	{
	    TFloatArray::const_iterator d = depth.begin ();
	    while ( d != depth.end () )
	    {
		if ( findDepth <= *d )			// in this layer?
		{
			layerIndex =
			  static_cast<short>( distance(depth.begin(), d) );
			break;				// search successful
		}
		++d;					// to next layer
	    }
	}
	return layerIndex;
}


//--- end of file ---
