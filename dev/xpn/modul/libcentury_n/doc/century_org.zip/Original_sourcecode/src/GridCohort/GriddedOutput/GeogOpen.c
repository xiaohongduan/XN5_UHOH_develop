
/*              Copyright 1998 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "gridconst.h"
#include "netcdf.h"

/* Global Variables */
int GeogNcid;
size_t maskRows, maskCols;

/* Open Transient NetCDF Weather Files */

void
GeogOpen(FILE *fp_init, int row[2], int col[2])
{

	char line[MAXL+1];
	int rowid, colid;
        int status;

	static char gfname[FNAMEMAX+1];

	/* Get Name of Geographic Information file */
	fgets(line, MAXL, fp_init);
	fgets(line, MAXL, fp_init);
	sscanf(line, "%s", gfname);

/*        printf("GeogNcid = %1d\n", GeogNcid); */
	/* Open files */
	if ((status = nc_open(gfname, NC_NOWRITE, &GeogNcid)) != NC_NOERR)
	   printf("GeogOpen: Unable to open file %s\n", gfname);

	/* Inquire Geographic Information to get # of rows and columns */
	status = nc_inq_dimid(GeogNcid, "row", &rowid);
	status = nc_inq_dimlen(GeogNcid, rowid, &maskRows);
	status = nc_inq_dimid(GeogNcid, "col", &colid);
	status = nc_inq_dimlen(GeogNcid, colid, &maskCols);

        row[0] = 0;
        row[1] = maskRows;
        col[0] = 0;
        col[1] = maskCols;      

	return;
}
