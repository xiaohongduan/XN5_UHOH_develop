#ifndef INC_TParameter_h
#define INC_TParameter_h

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TParameter.h
//	Class:	  TParameter, TParameterSet
//
//	Description:
//	Classes for Century parameters. NOT CURRENTLY USED.
//
//	Author: Tom Hilinski, Jan98
// ----------------------------------------------------------------------------
//	History:
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* A bit of cleaning up and const-correctness.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

//	-----------------------------------------------------------------------
// 	TParameter
//	Holds one parameter.
// 	Century parameters are mostly float but some are int.
// 	Since the parameters will be stored in NetCDF files,
//	we can pretend all are floats.
struct TParameter
{
	float value;		// parameter value
	float min, max;		// minimum/maximum values of parameter
	char  *descrip;		// description string
	char  *name;		// parameter text name
	bool  modified;		// true if value has been changed
};

//	-----------------------------------------------------------------------
//	TParameterSet
//	Class for holding a set of related parameters.
//	There can be multiple parameter sets per parameter file.
class TParameterSet
{
  public:
	//--- constructors and destructor
	TParameterSet ();
	virtual ~TParameterSet ();
	TParameterSet (const TParameterSet &obj);	// copy constr.

	//--- operator overloads
	TParameterSet operator=(TParameterSet &obj);	// Assignment
	bool operator==(TParameterSet &obj);		// Is Equal To
	bool operator!=(TParameterSet &obj)		// Is Not Equal To
		{ return !(*this == obj); }

	//--- functions
	int GetParamCount ()
		{ return count; }
	bool GetParameter (const char *paramName);

  protected:
	//--- data
	TParameter *param;		// array of parameters
	int count;			// number of parameters

	//--- functions

  private:
	//--- data

	//--- functions
	Initialize ();					// initialize members
	bool Copy (const TParameterSet &fromObj);	// copy to this
};


#endif // INC_TParameter_h
