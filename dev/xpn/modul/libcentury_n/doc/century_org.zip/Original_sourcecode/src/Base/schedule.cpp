// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  schedl.cpp
//	Class:	  TDayCent
//	Function: Schedule
//
//	Description:
//	Determine the next set of scheduling options from the schedule file
//	at the start of a new month's simulation.
// ----------------------------------------------------------------------------
//	History:
//	May99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added exception handling for failure of read of parameters
//	  (i.e., when the Get...() functions return false.)
//      Jun01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Replaced wt.soilTemp with dwt.soilTemp, OKAY?
//	Jun-Jul02	Tom Hilinski
//	* Move static variables to their appropriate structs:
//	  savedfert -> Tparam::savedfert
//	  isCropPlanted -> Tparcp::isCropPlanted
//	* Uses new scheduler class, TMgmtSchedule.
//      Jan02 Melannie Hartman, melannie@nrel.colostate.edu
//      * Updated to keep consistent with TCentury::Schedule()
//      * Added soilTemp (soil temperature) as a parameter, no longer
//        using dwt.soilTemp
//	Jul02	Tom Hilinski
//	* Move static variables to their appropriate structs:
//	  savedfert -> Tparam::param.savedfert
//	  isCropPlanted -> Tparcp::parcp.isCropPlanted
//	* Uses new scheduler class, TMgmtSchedule.
//	May03	Tom Hilinski
//	* Moved into base class from monthly and daily versions.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "util.h"
#include <cstdio>

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::Schedule (
	float const soilTemp)	// monthly avg soil surface temp (deg C)
{
    // Turn off functions that needed to operate through the previous month.
    // 1. if crop last month growth, reset parcp.growing,
    //    so crop grows through the last month of growth
    if ( sched->EndCropGrassGrowth() )
    {
	parcp.SetGrowingFlag (false);
	parcp.SetMonthsSincePlanting (0);	// turn off
    }
    // 2. if forest last month growth, reset growing
    //    so forest grows through the last month of growth
    if ( sched->DoingEndTreeGrowth() )
	parfs.SetGrowingFlag (false);

    // Check if months since planting needs to be updated
    if ( parcp.IsPlanted() &&
    	 soilTemp >= parcp.rtdtmp )
    	parcp.SetMonthsSincePlanting ( parcp.MonthsSincePlanting() + 1 );

    sched->Actions().Initialize ();	// Reset the action flags to false
    param.aufert = 0.0f;
    cropC.harmth = 0.0f;

    // get year in the block's event sequence which we are at
    short curEventYear = (short)
		( (st->year - st->blockStartYear + 1) %
			sched->GetActiveBlock()->GetYearLength() );
    if ( curEventYear == 0 )
	curEventYear = sched->GetActiveBlock()->GetYearLength();

    if ( sched->IsEmpty() )			// any events to process?
	return;					// no

    short i = sched->currentEventIndex;		// index to event arrays
    Assert (i <= sched->GetActiveBlock()->GetEventCount());

    while (true)
    {
      // Restart event sequence?
      if ( i == sched->GetActiveBlock()->GetEventCount() )	// end of block?
	i = 0;							// ...restart

      //--- Process events
      // get current event
      TManagementEvent const * const currentEvent =
	sched->GetActiveBlock()->GetEvent(i);

      if ( currentEvent->year == curEventYear &&
	   currentEvent->month == (short)st->month )
      {
	// pointer to additional info
	char const * const addInfo = currentEvent->additional;
	// process the current event
	switch ( currentEvent->type )
	{
	  //--- Century 4.0 events

	  case ET_Crop:				// Crop type
	  	sched->Actions().currentEvent[ET_Crop] = currentEvent;
		if ( strcmp(sched->curCrop, addInfo) )		// differ?
		{
		    //if ( *addInfo != 'F' )
		    //{
			if ( !GetCrop (addInfo) )
				ThrowCentException (
					TCentException::CE_ONFCRP, addInfo);
			AtmCO2Effect (st->time);
		    //}
		}
		strncpy ( sysType.CropName(), sched->curCrop, 6 );
		break;

	  case ET_Cultivate:			// Cultivation
	  	sched->Actions().currentEvent[ET_Cultivate] = currentEvent;
		sched->Actions().flags[ET_Cultivate] = true;
		if ( strcmp(sched->curCult, addInfo) )		// differ?
		    if ( !GetCultivation (addInfo) )
			ThrowCentException (
				TCentException::CE_ONFCUL, addInfo);
		break;

	  case ET_Fertilize:			// Fertilization
	  	sched->Actions().currentEvent[ET_Fertilize] = currentEvent;
		sched->Actions().flags[ET_Fertilize] = true;
		param.aufert = param.savedfert;
		if ( strcmp (sched->curFert, addInfo ) )	// differ?
		{
		    if ( !GetFertilization (addInfo) )
			ThrowCentException (
				TCentException::CE_ONFFER, addInfo);
		    param.savedfert = param.aufert;
		}
		break;

	  case ET_Fire:				// Fire
	  {
	  	sched->Actions().currentEvent[ET_Fire] = currentEvent;
		sched->Actions().flags[ET_Fire] = true;
		sched->Actions().fireType[sysType.TypeAsIndex()] = true;
		if ( strcmp (sched->curFire, addInfo ) )	// differ?
		    if ( !GetFire (addInfo) )
			ThrowCentException (
				TCentException::CE_ONFFIR, addInfo);
		break;
	  }

	  case ET_Graze:			// Grazing
	  	sched->Actions().currentEvent[ET_Graze] = currentEvent;
		sched->Actions().flags[ET_Graze] = true;
		if ( strcmp (sched->curGraz, addInfo ) )	// differ?
		    if ( !GetGrazing (addInfo) )
			ThrowCentException (
				TCentException::CE_ONFGRA, addInfo);
		break;

	  case ET_Harvest:			// Harvest crop
	  	sched->Actions().currentEvent[ET_Harvest] = currentEvent;
		sched->Actions().flags[ET_Harvest] = true;
		parcp.SetPlantedFlag (false);
		param.falprc = true;			// in fallow period
		wt.prcfal = 0.0f;
		cropC.harmth = 1.0f;
		if ( strcmp(sched->curHarv, addInfo) )		// differ?
		    if ( !GetHarvest (addInfo) )
			ThrowCentException (
				TCentException::CE_ONFHAR, addInfo);
		break;

	  case ET_Irrigate:			// Irrigation
	  	sched->Actions().currentEvent[ET_Irrigate] = currentEvent;
		sched->Actions().flags[ET_Irrigate] = true;
		if ( strcmp(sched->curIrri, addInfo) )		// differ?
		    if ( !GetIrrigation (addInfo) )
			ThrowCentException (
				TCentException::CE_ONFIRR, addInfo);
		break;

	  case ET_AddOM:			// Organic matter addition
	  	sched->Actions().currentEvent[ET_AddOM] = currentEvent;
		sched->Actions().flags[ET_AddOM] = true;
		if ( strcmp(sched->curOMAd, addInfo) )		// differ?
		    if ( !GetOMAddition (addInfo) )
			ThrowCentException (
				TCentException::CE_ONFORM, addInfo);
		break;

	  case ET_Tree:				// Tree type
	  	sched->Actions().currentEvent[ET_Tree] = currentEvent;
		if ( strcmp(sched->curTree, addInfo) )		// differ?
		{
			if ( !GetTree (addInfo) )
				ThrowCentException (
					TCentException::CE_ONFTRE, addInfo);
			AtmCO2Effect (st->time);
		}
		strncpy ( sysType.TreeName(), sched->curTree, 6 );
		break;

	  case ET_TreeRemoval:			// Tree removal
	  	sched->Actions().currentEvent[ET_TreeRemoval] = currentEvent;
		sched->Actions().flags[ET_TreeRemoval] = true;
		if ( strcmp(sched->curTRem, addInfo) )		// differ?
			if ( !GetTreeRemoval (addInfo) )
				ThrowCentException (
					TCentException::CE_ONFTRR, addInfo);
		break;

	  case ET_Plant:			// Plant crop/grass
	  	sched->Actions().currentEvent[ET_Plant] = currentEvent;
		sched->Actions().flags[ET_Plant] = true;
		parcp.seedl = 1;
		parcp.SetPlantedFlag (true);
		parcp.SetMonthsSincePlanting (0);
		parcp.SetGrowingFlag (false);	// crop/grass is growing
		param.falprc = false;		// not in fallow period
		wt.prcfal = 0.0f;
		break;

	  case ET_StartCrop:			// Crop/grass growth starts
	  	sched->Actions().currentEvent[ET_StartCrop] = currentEvent;
		sched->Actions().flags[ET_StartCrop] = true;
		parcp.SetGrowingFlag (true);	// crop/grass is growing
		break;

	  case ET_EndCrop:			// Crop/grass growth ends
	  	sched->Actions().currentEvent[ET_EndCrop] = currentEvent;
		sched->Actions().flags[ET_EndCrop] = true;
		break;

	  case ET_Senesce:			// Crop/grass senescence
	  	sched->Actions().currentEvent[ET_Senesce] = currentEvent;
		sched->Actions().flags[ET_Senesce] = true;
		break;

	  case ET_StartTree:			// Tree growth starts
	  	sched->Actions().currentEvent[ET_StartTree] = currentEvent;
		sched->Actions().flags[ET_StartTree] = true;
		parfs.SetGrowingFlag (true);
		break;

	  case ET_EndTree:			// Tree growth ends
	  	sched->Actions().currentEvent[ET_EndTree] = currentEvent;
		sched->Actions().flags[ET_EndTree] = true;
		break;

	  case ET_Erosion:			// Erosion
	  	sched->Actions().currentEvent[ET_Erosion] = currentEvent;
		if ( addInfo && *addInfo )		// anything there?
		    if ( !InitErosionEvent (addInfo) )	// initialize?
			sched->Actions().flags[ET_Erosion] = true;  // ...yes
		break;

	  //--- Century 5 events

	  case ET_Deposition:			// Deposition
	  	sched->Actions().currentEvent[ET_Deposition] = currentEvent;
		if ( addInfo && *addInfo )		// anything there?
		    if ( !InitDepositionEvent () )	// initialize?
			sched->Actions().flags[ET_Deposition] = true;
		break;

	  case ET_External:			// External action
	  	sched->Actions().currentEvent[ET_External] = currentEvent;
		sched->Actions().flags[ET_External] = true;
		if ( addInfo && *addInfo )		// anything there?
			asynchCom.SaveExternalEventInfo (addInfo);
		break;

	  //--- Unimplemented events

	  case ET_FertRange:	// Fertilation year/amt. range + mo. fractions
		break;

	  case ET_OMAddRange:	// Org. matter year/amt. range + mo. fractions
		break;

	  case ET_IrrRange:	// Irrigation year/amt. range + mo. fractions
		break;

	  case ET_IrrAuto:	// Irrigation - automatic
		break;

	  case ET_NIndustrial:	// N deposition - industrial year/amt. range
		break;

	  case ET_NAtmos:	// N deposition - atmospheric
		break;

	  case ET_KRange:	// K addition year/amt. range + mo. fractions
		break;

	  case ET_SRange:	// S addition year/amt. range + mo. fractions
		break;

	  case ET_PRange:	// P addition year/amt. range + mo. fractions
		break;

	  case ET_ErosionRange:	// Erosion year/amt. range + mo. fractions
		break;

	  case ET_GrazeIntens:	// Grazing intensity
		break;

	  default:		//--- unknown event type
		break;
	}
	++i;			// increment to next event
      }
      else // done scheduling for now
      {
      	break;
      }
    }
    sched->currentEventIndex = i;	// save index in case have to repeat
					// the event sequence.
}

//--- end of file ---


