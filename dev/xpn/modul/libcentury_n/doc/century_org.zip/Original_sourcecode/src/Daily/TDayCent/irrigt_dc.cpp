// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  irrigt.cpp
//	Class:	  TDayCent
//	Function: Irrigate
//
//	Description:
//	Irrigate the system when above freezing.
// ----------------------------------------------------------------------------
//	History:
//      See Century/irrigt.cpp
//      May01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Made this function a TDayCent function, formerly a TCentury function
//      * Use variable IrrigationEventsPerMonth to compute irract
//      * Function returns irrigation amount, and no longer sets wt.irract
//        and wt.irrtot variables
//      Sep01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Added function argument tave to replace use of wt.tave
//      11Jan02 Melannie Hartman, melannie@nrel.colostate.edu
//      * Updated to keep consistent with TCentury::Irrigate()
//      * Added pet and precip as parameter, no longer using dwt.pet
//        or weather->DlyPrecip(day).  Removed day parameter.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//      Notes:
// ----------------------------------------------------------------------------

#include "TDayCent.h"

float TDayCent::Irrigate (
        float const tave,       // Mean air temp over irrigation period (deg C)
        float const pet,        // PET over irrigation period (cm H2O)
        float const precip)     // Precipitation over irrigation period (cm H2O)
{
    float irract = 0.0f;		// initialize current irrigation amount

    // Check temperature that irrigation water is not added as snow
    if (tave > 0.0f)			// Add amount given by user
    {
	float const awhc =
		soil->PlantWaterCapacityAmt (0.0f, water.depthOfRoots);
    	Assert (awhc > 0.0f);
	float const twhc =
		soil->FieldCapacityQuantity (0.0f, water.depthOfRoots);
    	Assert (twhc > 0.0f);
	Assert (IrrigationEventsPerMonth == 4);
	switch (parcp.auirri)		// (1-3 = automatic irrigation)
    	{
    	  case 0:	//--- no auto irrigation; use amount from event
                //wt.irract = parcp.irramt;
                // Assuming arcp.irramt is a monthly irrigation amount -mdh 5/02/01
    	  	irract = parcp.irramt / IrrigationEventsPerMonth;
    	  	break;

    	  case 1: 	//--- Add amount to field capacity
		if (wt.avh2o[0] / awhc <= parcp.fawhc)
		{
                    float rootZoneTotalWater = precip +
		      soil->WaterContent().Quantity (
		      		0.0f, water.depthOfRoots,
		      		soil->Depth(), soil->Thickness() );
		    irract = std::max (twhc - rootZoneTotalWater, 0.0f);
		}
    	  	break;

    	  case 2:	//--- Add amount to nominated amount
                // Assuming parcp.irraut is a monthly irrigation amount -mdh 5/02/01
	    	if (wt.avh2o[0] / awhc <= parcp.fawhc)
			//wt.irract = parcp.irraut;
                        irract = parcp.irraut / IrrigationEventsPerMonth;
    	  	break;

	  case 3:	//--- Add amount to field capacity plus PET
	    	if (wt.avh2o[0] / awhc <= parcp.fawhc)
	    	{
                    float rootZoneTotalWater = precip +
		      soil->WaterContent().Quantity (
		      		0.0f, water.depthOfRoots,
		      		soil->Depth(), soil->Thickness() );
                    irract = std::max (twhc + pet - rootZoneTotalWater, 0.0f);
	    	}
    	  	break;

    	  default:	//--- error!
		// Need a Century exception here
    	  	break;
    	}
    }
    return irract;
}

