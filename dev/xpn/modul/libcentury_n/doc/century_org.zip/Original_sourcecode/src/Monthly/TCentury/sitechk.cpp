// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  sitechk.cpp
//	Class:	  TCentury
//	Function: CheckSiteParamValues
//
//	Description:
//	Checks the site parameters for valid values.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec98
//	History:
//	2005Oct	Tom Hilinski
//	* Most checks moved into class nrel::site::VerifySiteParameters
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include "VerifySiteParameters.h"
#include <sstream>
using namespace std;

void TCentury::CheckSiteParamValues ()
{
	// char const * const msgInvalidValue = "Invalid Value: ";
	char const * const msgValueEquals = "value = ";
	// float const minFloat = 1.0e-10f;  // minimum acceptable float value

	if ( soil->SoilDepth() < fixed.edepth )		// too shallow?
	{
		std::ostringstream os;
		os << "Soil depth < minimum required depth = "
		   << fixed.edepth << "cm.: "
		   << msgValueEquals << soil->SoilDepth();
	    	ThrowCentException ( TCentException::CE_SITERR,
	    				os.str().c_str() );
	}
}

//--- end of file ---
