
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  nremv_ncid;			/* netCDF id */

/* variable ids */
int shremn_id, sdremn_id, rlvremn_id, fbrremn_id, rlwremn_id, wd1remn_id, wd2remn_id,
   stremn_id, metrmn_id, fstgrmn_id;

int
nremvdef(int *ntimes, char *history) {		/* create nremv.nc */

   int status;

   /* dimension ids */
   int  time_dim = 0;
   int  cell_dim = 0;

   /* variable shapes */
   int dims[2];

   /* enter define mode */
   status = nc_create("nremv.nc", NC_CLOBBER, &nremv_ncid );

   /* define dimensions */
   status = nc_def_dim(nremv_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(nremv_ncid, "cell", NC_UNLIMITED, &cell_dim);

   /* define variables */

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nremv_ncid, "shremn", NC_FLOAT, 2, dims, &shremn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nremv_ncid, "sdremn", NC_FLOAT, 2, dims, &sdremn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nremv_ncid, "rlvremn", NC_FLOAT, 2, dims, &rlvremn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nremv_ncid, "fbrremn", NC_FLOAT, 2, dims, &fbrremn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nremv_ncid, "rlwremn", NC_FLOAT, 2, dims, &rlwremn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nremv_ncid, "wd1remn", NC_FLOAT, 2, dims, &wd1remn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nremv_ncid, "wd2remn", NC_FLOAT, 2, dims, &wd2remn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nremv_ncid, "stremn", NC_FLOAT, 2, dims, &stremn_id);
 
   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nremv_ncid, "metrmn", NC_FLOAT, 2, dims, &metrmn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nremv_ncid, "fstgrmn", NC_FLOAT, 2, dims, &fstgrmn_id);

   /* assign attributes */
   status = nc_put_att_text (nremv_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (nremv_ncid, shremn_id, "long_name", 
        strlen("above_ground_live_nitrogen_removed"), "above_ground_live_nitrogen_removed");
   status = nc_put_att_text (nremv_ncid, shremn_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (nremv_ncid, sdremn_id, "long_name", 
	strlen("standing_dead_nitrogen_removed"), "standing_dead_nitrogen_removed");
   status = nc_put_att_text (nremv_ncid, sdremn_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (nremv_ncid, rlvremn_id, "long_name", 
	strlen("live_leaf_nitrogen_removed"), "live_leaf_nitrogen_removed");
   status = nc_put_att_text (nremv_ncid, rlvremn_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (nremv_ncid, fbrremn_id, "long_name", 
	strlen("live_fine_branch_nitrogen_removed"), "live_fine_branch_nitrogen_removed");
   status = nc_put_att_text (nremv_ncid, fbrremn_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (nremv_ncid, rlwremn_id, "long_name", 
	strlen("live_large_wood_nitrogen_removed"), "live_large_wood_nitrogen_removed");
   status = nc_put_att_text (nremv_ncid, rlwremn_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (nremv_ncid, wd1remn_id, "long_name", 
	strlen("dead_fine_branch_nitrogen_removed"), "dead_fine_branch_nitrogen_removed");
   status = nc_put_att_text (nremv_ncid, wd1remn_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (nremv_ncid, wd2remn_id, "long_name", 
	strlen("dead_large_wood_nitrogen_removed"), "dead_large_wood_nitrogen_removed");
   status = nc_put_att_text (nremv_ncid, wd2remn_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (nremv_ncid, stremn_id, "long_name", 
	strlen("surface_structural_nitrogen_removed"), "surface_structural_nitrogen_removed");
   status = nc_put_att_text (nremv_ncid, stremn_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (nremv_ncid, metrmn_id, "long_name", 
	strlen("surface_metabolic_nitrogen_removed"), 
	"surface_metabolic_nitrogen_removed");
   status = nc_put_att_text (nremv_ncid, metrmn_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (nremv_ncid, fstgrmn_id, "long_name", 
	strlen("retranslocated_nitrogen_removed"), 
	"retranslocated_nitrogen_removed");

   /* leave define mode */
   status = nc_enddef (nremv_ncid);
   return 0;
}
