// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  ufwater.cpp
//	Class:	  TCenturyBase
//	Function: UpdateFromSoilWater
//
//	Description:
//	Updates variables and parameters based upon soil water content.
// ----------------------------------------------------------------------------
//	History:
//	Aug00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Now uses the exponential depth distribution of C rather than the
//	  geometric-by-layer distribution.
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::UpdateFromSoilWater ()
{
    // update soil org. matter percent amounts
    soilC.somsc = soilC.som1c[SOIL] + soilC.som2c + soilC.som3c;
    // Following function is replaced - see YearEndTasks().
    // soil->GeometricOMPC (soilC.somsc);	// re-calc OMPC
    // soil->ExponentialOMPC (soilC.somsc, lowerSoil->GetTotalC(),
    //			   wt.simDepth, lowerSoil->Thickness() );

    // Since SOM content has changed, update any soil properties that
    // are affected by the SOM content:
    if (param.swflag > 0)
    {
	soil->CalcWPandFC (param.swflag);	// re-calc from texture & ompc
    	UpdateWaterVariables ();		// water content calcs
    }
}

//--- end of file ufwater.cpp ---
