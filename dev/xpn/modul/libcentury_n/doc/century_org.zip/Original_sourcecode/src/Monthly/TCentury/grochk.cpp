// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  grochk.cpp
//	Class:	  TCentury
//	Function: StartDeciduousGrowth
//
//	Description:
//	Determines whether or not there is potential growth
//	and if it is the first month of the growing season.
//	Returns true if month of greenup in deciduous forests else false.
// ----------------------------------------------------------------------------
//	History:
//	Jun02	Tom Hilinski
//	* Moved static local variable "startd" into Tparfs::startedDecidGrowth
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TCentury.h"

bool TCentury::StartDeciduousGrowth ()
{
    bool doStartDecidGrowth = false;

    // If this is the first year for this management block, reset STARTD.
    if ( st->IsBlockStart() )
	parfs.startedDecidGrowth = false;

    // If it is spring and the temperature is high enough and
    // you haven't already reapportioned carbon to leaves,
    // then this is the greenup month
    if ( siteEnv.IsDayIncreasing() &&
         wt.tave > 10.0f &&
         !parfs.startedDecidGrowth )
    {
	doStartDecidGrowth = parfs.startedDecidGrowth = true;
    }
    else // if ( !siteEnv.IsDayIncreasing() )
	parfs.startedDecidGrowth = false;

    return doStartDecidGrowth;
}
