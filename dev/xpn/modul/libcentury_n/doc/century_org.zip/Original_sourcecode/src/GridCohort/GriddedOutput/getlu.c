
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include "gridconst.h"

/* Prototypes */
void lineparse(char*, float[], int);

/* Externally defined variables */
extern int curr_row;
extern FILE *fp_l;
extern int veg_class[MAXLU];
extern int no_of_lu;

/* Read landuse for current simulation from SVF files */

    int getlu_(int *lu, int *nrow, int *ncol)
    {
      static char lineL[MAXR+1];
      static float alu[MAXE];
      int ii;
      int retval;
      int save_row;

      /* Save the value of curr_row so it can be reset before */
      /* getsoil is called */
      save_row = curr_row;

      while (*nrow >= curr_row) {
        /* Read in line from landuse file */
        fgets(&lineL[0], MAXR, fp_l);

        /* Parse records into storage arrays */
        if (curr_row == *nrow) {
          /* Parse records to pull out data by cell */
          lineparse(lineL, alu, (int)MAXE);
        }

        /* Increment current row counter */
        curr_row += 1;
      }

/*      for(ii=0; ii<MAXE; ii++) {
        printf("%4.1f ",  alu[ii]);
	if ((ii % 10) == 9) printf("\n");
      } */

      /* Do you have the correct row if you are returning to this function? */
      if (curr_row == *nrow + 1) {
        *lu = (int) alu[*ncol];
      }

      curr_row = save_row;

      /* Determine if the cell values are valid */

      retval = 1;
      for (ii=0; ii<no_of_lu; ii++) {
        if (*lu == veg_class[ii]) {
          retval = 0;
          break;
        }
/*        printf("veg_class[%1d] = %1d\n", ii, veg_class[ii]); */
      }
      printf("lu = %1d\n", *lu);

/*      if (retval > 0) fprintf(stderr, "Error in getlu\n"); */

      return retval;
    }
