#ifndef INC_nrel_dcirc_TDayCentModel_h
#define INC_nrel_dcirc_TDayCentModel_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TDayCentModel.h
//	Class:	  TDayCentModel
//
//	Description:
//	Interface class for the IRC adaptor to the DayCent model.
//
//	Responsibilities:
//	* Provides a public interface to the DayCent model.
//	* Owns a derived class of TDayCent.
//	* Initializes and runs the model.
//	* Has a unique ID.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, June 2002
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TModelBase.h"
#include "TDayCentGCF.h"
#include "TDayCentSimController.h"
#include "TDayCentIRCConfig.h"
#include "fnutil.h"
#include "TSharedPtr.h"
#include <sstream>

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class TDayCentModel
	: public ::nrel::gcf::TModelBase
{
  public:
	//---- types
	typedef TSharedPtr<TDailyCenturyConfig>		TDailyCenturyConfigPtr;
	typedef TSharedPtr<TDayCentGCF>			TDayCentGCFPtr;

	//---- constructors and destructor
	TDayCentModel (
	  ::nrel::gcf::TCohort * const useOwner,		// owner = cohort
	  ::nrel::gcf::TDecision * const useDecision,	// decision object
	  ::nrel::gcf::TFactories * const factories,	// class factories
	  bool const timeThisRun);		// True if timing the model run
	TDayCentModel (TDayCentModel const & object)  // copy constructor
	  : ::nrel::gcf::TModelBase (object),
	    mySimController (object.mySimController),
	    myCloneSource (&object)
	  {
	    MakeIDString ();
	  }
	TDayCentModel (  				// copy constructor
	  TDayCentModel const & object,			//   source object
	  ::nrel::gcf::TCohort * const useOwner,	//   owner = cohort
	  ::nrel::gcf::TEvent const * const data = 0)	//   event triggering it
	  : ::nrel::gcf::TModelBase (object, useOwner),
	    mySimController (object.mySimController),
	    myCloneSource (&object)
	  {
	    MakeIDString ();
	    Copy (object, data);
	  }
	virtual ~TDayCentModel ()
	  {
	    // msg = idString;
	    // msg += " destroyed.";
	    // WriteToSim (msg);
	  }
	virtual TDayCentModel * const Clone (		// Clone this instance
	  ::nrel::gcf::TCohort * const useOwner,	//   owner = cohort
	  ::nrel::gcf::TEvent const * const data	//   event triggering it
	  ) const
	  {
	    std::auto_ptr<TDayCentModel> newModel (
		new TDayCentModel (*this, useOwner, data) );
	    // modify clone here, if needed
	    return newModel.release();
	  }

	//---- functions
	std::string const & GetIDString () const
	  { return idString; }
	void WriteToSim (			// write to sim. controller
	  std::string const & msg
	  ) const
	  { mySimController->Write (msg); }
	void WriteToSim (			// write to sim. controller
	  char const * const msg
	  ) const
	  { mySimController->Write (msg); }
	void WriteEventToSim (
	  std::string const & eventStr,
	  ::nrel::gcf::TCohortID const cohortID);
	void WriteEventToSim (
	  char const * const eventStr,
	  ::nrel::gcf::TCohortID const cohortID)
	  {
	    WriteEventToSim ( std::string (eventStr), cohortID );
	  }
	bool HaveModel () const				// True if have a
	  { return century.get(); }			//   a model object
	TDayCentGCF const & GetModel () const	// Access Century
	  { return *century; }
	TDayCentIRCConfig const & GetConfiguration () const
	  {
	    return dynamic_cast<TDayCentIRCConfig const &>(
		mySimController->GetConfiguration() );
	  }

  private:
	//---- data
	TDayCentSimController * const mySimController;
	TDayCentModel const * const myCloneSource;
	std::string idString;		// model ID in a string
	std::string msg;

	// Century instance lifetime is <= lifetime of configuration object
	TDailyCenturyConfigPtr centuryConfig;	// Century configuration
	TDayCentGCFPtr century;			// Century instance

	//---- functions
	void Copy (					// Copy to this
	  TDayCentModel const & object,
	  ::nrel::gcf::TEvent const * const data = 0);	//   event triggering it
	void MakeIDString ()
	  {
	    std::ostringstream ss;
	    ss << "Model " << GetID();
	    idString = ss.str();
	  }
	void MakeOutputFileName (
	  std::string & outputFile)
	  {
	    TEH::AppendSeparator (outputFile);
	    outputFile += "Output_";
	    outputFile += idString;
	    std::string::size_type index =
	    	outputFile.rfind (" ");	// find space
	    outputFile[index] = '_';	// replace with underscore
	  }
	std::string & MakeExceptionMsg (
	  std::string & msg);
	void SimStartMsg ();
	void SimEndMsg ();

	// --- the required virtual functions ---
	virtual bool DoInitializeModel ();	//--- Initialize the model
	virtual bool DoRunToCompletion ();	//--- Run model to completion
	virtual bool DoRunIteration ();		//--- Run model one iteration
	virtual TState DoPauseRun ()		//--- Pause model run
	  {
	    state.SetState (TModelState::State_Paused);
	    return state.GetState();		// Return new model state
	  }
	virtual TState DoTerminateRun ()	//--- Terminate model run
	  {
	    msg = idString;
	    msg += " terminating.";
	    WriteToSim (msg);
	    if ( century.get() )
	    	century->PostCancelRequest ();
	    state.SetState (TModelState::State_Terminated);
	    return state.GetState();		// Return new model state
	  }
	virtual void DoCombineModelPools (
	  ::nrel::gcf::TModelBase const & otherModel);

	//---- Functions: utility
	bool OneIterationTasks ()		// Does one iteration's tasks
	  {
	    return century->RunIteration(); // Return true if can continue
	  }
	void CombineSoilCPools (
	  TDayCentGCF const & otherCentury,
	  float const myFraction,
	  float const yourFraction);
	void CombineCropGrassBiomassCPools (
	  TDayCentGCF const & otherCentury,
	  float const myFraction,
	  float const yourFraction);
	void CombineForestBiomassCPools (
	  TDayCentGCF const & otherCentury,
	  float const myFraction,
	  float const yourFraction);
	void CombineNPools (
	  TDayCentGCF const & otherCentury,
	  float const myFraction,
	  float const yourFraction);
	void CombineH2OPools (
	  TDayCentGCF const & otherCentury,
	  float const myFraction,
	  float const yourFraction);
	void CombineCO2Pools (
	  TDayCentGCF const & otherCentury,
	  float const myFraction,
	  float const yourFraction);

	//---- Functions: DayCent
	TDailyCenturyConfigPtr ConfigureCentury ();
	TDayCentGCFPtr InstantiateCentury ();

	//---- Functions: should not be called!
	virtual TDayCentModel * const Clone (		// Clone this instance
	  ::nrel::gcf::TEvent const * const data	//   event triggering it
	  ) const
	  { return 0; }
};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_TDayCentModel_h
