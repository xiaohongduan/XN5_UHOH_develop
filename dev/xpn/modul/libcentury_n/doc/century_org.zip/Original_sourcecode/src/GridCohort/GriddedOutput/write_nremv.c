
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include "netcdf.h"
#include "wrtcdf.h"

int
write_nremv(float N_remv[][12])
{
        int status;
        float *p = (float *) N_remv;

	/* Write output to NetCDF file */
	status = nc_put_vara_float(nremv_ncid, shremn_id, start, count, p);
	status = nc_put_vara_float(nremv_ncid, sdremn_id, start, count, p + 12);
	status = nc_put_vara_float(nremv_ncid, rlvremn_id, start, count, p + 24);
	status = nc_put_vara_float(nremv_ncid, fbrremn_id, start, count, p + 36);
	status = nc_put_vara_float(nremv_ncid, rlwremn_id, start, count, p + 48);
	status = nc_put_vara_float(nremv_ncid, wd1remn_id, start, count, p + 60);
	status = nc_put_vara_float(nremv_ncid, wd2remn_id, start, count, p + 72);
	status = nc_put_vara_float(nremv_ncid, stremn_id, start, count, p + 84);
	status = nc_put_vara_float(nremv_ncid, metrmn_id, start, count, p + 96);
	status = nc_put_vara_float(nremv_ncid, fstgrmn_id, start, count, p + 108);

	/* Reset memory for variable N_remv */
	 memset(p, '\0', (sizeof(float) * 10 * 12));

	return 0;
}
