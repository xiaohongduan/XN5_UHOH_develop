#ifndef INC_nrel_dcirc_TCenturyOutputFactory_h
#define INC_nrel_dcirc_TCenturyOutputFactory_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TCenturyOutputFactory.h
//	Class:	  TCenturyOutputFactory
//
//	Description:
//	Output class factory.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, tom.hilinski@colostate.edu, June 2002
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TGEOutputFactoryBase.h"		// output object factory base
#include "TCellCSVFileOutput.h"			// cell output
#include "TFileStream.h"			// simulation output
#include "TGridCell.h"				// for cell owner
using namespace std;

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class TCenturyOutputFactory
	: public ::nrel::gcf::TGEOutputFactoryBase
{
  public:
	//---- types
	typedef ::nrel::gcf::TGEOutputFactoryBase		TMyBaseClass;
	typedef TSharedPtr< ::nrel::io::TIOSourceSinkBase >	TOutputPtr;
	typedef	::nrel::gcf::TCellCSVFileOutput			TCellOutput;
	typedef ::nrel::io::TFileStream				TSimOutput;

	//---- constructors and destructor
	TCenturyOutputFactory ()
	  : TMyBaseClass ()
	  {
	  }
	virtual ~TCenturyOutputFactory ()
	  {
	  }

	//---- functions
	void SetSimFileName (
	  std::string const & useSimFileName)
	  { simFileName = useSimFileName; }
	void SetSimFileName (
	  char const * const useSimFileName)
	  { simFileName = useSimFileName; }

  protected:
	//--- data
	std::string simFileName;

	//--- functions: Virtual
	virtual TOutputPtr CreateCellIOObject ()
	  {
	    // Assert ( !ofs.str().empty() );
	    // To Do: CreateCellIOObject - extension should match file type
	    std::string myOutputName (outputFileName);
	    myOutputName += ".csv";
	    TOutputPtr newObject ( new TCellOutput ( myOutputName ) );
	    return newObject;
	  }
	virtual TOutputPtr CreateSimulationIOObject ()
	  {
	    TOutputPtr newObject;
	    if ( simFileName.length() > 0 )
		newObject.reset (
			new TSimOutput (
				simFileName,
				TSimOutput::DevImp_Text,
				TSimOutput::Access_WriteOnly) );
	    return newObject;
	  }
};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_TCenturyOutputFactory_h
