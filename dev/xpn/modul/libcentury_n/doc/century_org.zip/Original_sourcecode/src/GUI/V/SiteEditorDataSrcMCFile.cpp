// ----------------------------------------------------------------------------
//	Copyright 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  SiteEditorDataSrcMCFile.cpp
//	Class:	  SiteEditorDataSrcMCFile
//
//	Description:
//	Class for the data source for the Site Editor for monthly Century5
//	site parameters from a file.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Dec04
//	History: See header file.
// ----------------------------------------------------------------------------

#include "SiteEditorDataSrcMCFile.h"
#include "SiteEditorDlg.h"
#include "TFileSelDlg.h"
#include "charutil.h"
#include "AssertEx.h"
#include <v/vnotice.h>

#define pathLength 257				// maximum path length

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	Read
//	Read the parameters file.
//	Return false if successful, else true if failed or error.
bool SiteEditorDataSrcMCFile::Read (
	TSharedPtr<TMCSiteParameters> & siteParameters)
{
	bool failed = false;			// return value
	try
	{
		if ( fileName.empty() )
		{
			errorMsg = "File name was not specified.";
			throw true;
		}
		else
		{
			siteParameters.reset (			// read the file
			    new TMCSiteParameters (
				fileName, templatePath, workPath, info ) );
			if ( siteParameters.get() == 0 )
			{
				throw true;
			}
			else if ( siteParameters->IsError() )
			{
				siteParameters.reset ();
				throw true;
			}
		}
	}
	catch (...)
	{
		failed = true;
	}
	if ( failed )
	{
		error = ReadFailed;
		if ( errorMsg.empty() )
		{
		    if ( siteParameters.get() != 0 &&
		    	 !siteParameters->GetNcFileName().IsEmpty() )
		    {
			errorMsg =
				"Failed reading the site parameters "
				"from the following file:\n";
			errorMsg +=
				siteParameters->GetNcFileName().GetFullName();
			if ( siteParameters->IsError() )
			{
			    errorMsg += "\nSite parameters error message:\n";
			    errorMsg += siteParameters->GetErrorMsg();
			}
		    }
		    else
		    {
			errorMsg = "Failed reading the site parameters.";
		    }
		}
	}
	return failed;
}

//	Write
//	Write the parameters file.
//	Return false if successful, else true if failed or error.
bool SiteEditorDataSrcMCFile::Write ()
{
	bool failed = false;			// return value
	try
	{
		if ( fileName.empty() )
		{
			errorMsg = "File name was not specified.";
			throw true;
		}
		else
		{
			failed = dataPtr->WriteNcFile ();
			if ( failed )
				throw true;
		}
	}
	catch (...)
	{
		failed = true;
	}
	if ( failed )
	{
		error = WriteFailed;
		if ( dataPtr.get() != 0 )
		{
			errorMsg =
				"Failed writing the site parameters "
				"to the following file:\n";
			errorMsg += dataPtr->GetNcFileName().GetFullName();
			if ( dataPtr->IsError() )
			{
				errorMsg += "\nNetCDF error message:";
				errorMsg += dataPtr->GetErrorMsg();
			}
		}
		else
		{
			errorMsg = "Failed writing the site parameters.";
		}
	}
	return failed;
}

void SiteEditorDataSrcMCFile::ReadWriteErrorNotice (
	char const * const msgFirstPart)
{
	vNoticeDialog dlg ( parent, "Error - Site Parameters" );
	std::string msg = msgFirstPart;
	msg += "\n\nFile name: ";
	msg += fileName;
	if ( !GetErrorMessage().empty() )
	{
		msg += NL_CHAR;
		msg += GetErrorMessage();
	}
	dlg.Notice ( msg.c_str() );
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

SiteEditorDataSrcMCFile::TUserAction SiteEditorDataSrcMCFile::DoOpen (
	DataTypePtr siteParameters)
{
	char const* filter[] =
	{
		"Site Parameter Files|*-ST.nc|"
		"Century 4 Site Files|*.100|"
		"All (*.*)|*.*|",
		NULL
	};
	int filterIndex = 0;			// filter index
	std::string initPath = workPath;	// starting folder
	char newFileName[pathLength];
	*newFileName = NULL_CHAR;
	char const * const prompt = "Select a Site Parameter Set";
	vFileSelect fileSelectDlg (parent);
	int result = fileSelectDlg.FileSelect (
				prompt,
				newFileName, pathLength - 1,
				const_cast<char**>(filter), filterIndex,
				initPath.c_str() );
	if ( result == 1 )				// OK button
	{
	    fileName = newFileName;
	    bool const readFailed = Read ( siteParameters );
	    if ( readFailed || HaveError() )
	    {
		ReadWriteErrorNotice (
			"Read (Open) of site parameters failed." );
		return ActionOK;
	    }
	    MyBaseClass::Copy (*siteParameters);
	    siteParameters->SetModified (false);
	}
	return (result == 0 ? ActionCancel : ActionOK );
}

SiteEditorDataSrcMCFile::TUserAction SiteEditorDataSrcMCFile::DoSave (
	TMCSiteParameters const & siteParameters)
{
	MyBaseClass::Copy (siteParameters);
	Assert (siteParameters.GetSetCount() > 0);
	Assert (dataPtr.get() != 0);
	Assert (dataPtr.get()->GetSetCount() > 0);
	if ( HaveError() )
		return ActionCancel;
	else if ( siteParameters.IsModified() &&
		  !siteParameters.GetBaseName().empty() )
	{
	    bool writeFailed = Write ();
	    if ( writeFailed || HaveError() )
	    {
		ReadWriteErrorNotice (
			"Write (Save) of site parameters failed." );
	    }
	}
	return ActionOK;
}

SiteEditorDataSrcMCFile::TUserAction SiteEditorDataSrcMCFile::DoSaveAs (
	DataTypePtr siteParameters)
{
	MyBaseClass::Copy (*siteParameters);
	char const* filter[] =
	{
		"Site Parameter Files|*-ST.nc|"
		"Century 4 Site Files|*.100|"
		"All (*.*)|*.*|",
		NULL
	};
	int filterIndex = 0;			// filter index
	std::string initPath = workPath;	// starting folder
	char newFileName[pathLength];
	*newFileName = NULL_CHAR;
	char const * const prompt = "Save Site Parameter Set";
	vFileSelect fileSelectDlg (parent);
	int result = fileSelectDlg.FileSelectSave (
				prompt,
				newFileName, pathLength - 1,
				const_cast<char**>(filter), filterIndex,
				initPath.c_str() );
	if ( result == 1 )				// Save/OK button
	{
	    fileName = newFileName;
	    siteParameters->SetBaseName (fileName);
	    bool writeFailed = Write ();
	    if ( writeFailed || HaveError() )
	    {
		ReadWriteErrorNotice (
			"Write (Save) of site parameters failed." );
		return ActionOK;
	    }
	}
	return (result == 0 ? ActionCancel : ActionOK );
}

//--- end of definitions for SiteEditorDataSrcMCFile ---
