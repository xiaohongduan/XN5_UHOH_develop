// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  litburn.cpp
//	Class:	  TCenturyBase
//	Function: BurnLitter
//
//	Description:
//	Simulate removal of litter by fire for the month.
// ----------------------------------------------------------------------------
//	History:
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
//	* Cleaned up, renamed variables, and added const-correctness.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::BurnLitter (
	float * const removedE)	// array [site.nelem]:
				// Total N,P,S returned to system after burn.
				// All carbon is assumed lost.
{
    // Remove carbon fraction of structural component of litter
    if (soilC.strucc[SRFC] > 0.0f)
    {
	float const structuralCRemoved = parcp.fdfrem[1] * soilC.strucc[SRFC];
	cropC.sdrema += structuralCRemoved;
	ScheduleCFlow ( st->time, structuralCRemoved,
			strcis_ref (SRFC,LABELD) / soilC.strucc[SRFC], 1.0f,
			&strcis_ref (SRFC,UNLABL), &soilC.csrsnk[UNLABL],
			&strcis_ref (SRFC,LABELD), &soilC.csrsnk[LABELD],
			cropC.sdrmai);
	// Remove element fraction of structural component of litter
	// in the same fraction as the structural C removed
	for (short layer = 0; layer < site.nelem; ++layer)
	{
	    float const structuralERemoved =
	    	structuralCRemoved * struce_ref (SRFC, layer) /
	    	soilC.strucc[SRFC];
	    removedE[layer] += structuralERemoved;
	    // Corrected SDRMAE from SDRMAI 8-30-90  -rm
	    nps.sdrmae[layer] += structuralERemoved;
	    flows->Schedule (&struce_ref (SRFC, layer), &nps.esrsnk[layer],
			     st->time, structuralERemoved);
	}
    }

    // Remove carbon fraction of metabolic component of litter
    if (soilC.metabc[SRFC] > 0.0f)
    {
	float const metabolicCRemoved = parcp.fdfrem[1] * soilC.metabc[SRFC];
	cropC.sdrema += metabolicCRemoved;
	ScheduleCFlow ( st->time, metabolicCRemoved,
			metcis_ref (SRFC,LABELD) / soilC.metabc[SRFC], 1.0f,
			&metcis_ref (SRFC,UNLABL), &soilC.csrsnk[UNLABL],
			&metcis_ref (SRFC,LABELD), &soilC.csrsnk[LABELD],
			cropC.sdrmai);
	// Remove element fraction of metabolic component of litter
	// in the same fraction as the metabolic C removed
	for (short layer = 0; layer < site.nelem; ++layer)
	{
	    float const metabolicERemoved =
	    	metabolicCRemoved * metabe_ref (SRFC, layer) /
	    	soilC.metabc[SRFC];
	    removedE[layer] += metabolicERemoved;
	    // Corrected SDRMAE from SDRMAI 8-30-90  -rm
	    nps.sdrmae[layer] += metabolicERemoved;
	    flows->Schedule (&metabe_ref (SRFC, layer), &nps.esrsnk[layer],
			    st->time, metabolicERemoved);
	}
    }
}

//--- end of file litburn.cpp ---
