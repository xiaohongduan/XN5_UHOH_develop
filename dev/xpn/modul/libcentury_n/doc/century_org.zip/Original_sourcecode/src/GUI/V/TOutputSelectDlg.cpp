// ----------------------------------------------------------------------------
//	Copyright 2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TOutputSelectDlg.cpp
//	Class:	  TOutputSelectDlg
//
//	Description:
//	Class for a dialog to select the name, path, and type of output
//	for a Century simulation.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Nov03, tom.hilinski@colostate.edu
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TOutputSelectDlg.h"
#include "constants.h"			// Century constants
#include "charutil.h"
#include "TFileSelDlg.h"
#include "TFileName.h"
using TEH::TFileName;
#include <v/vapp.h>


// ----------------------------------------------------------------------------
//	static member variables
// ----------------------------------------------------------------------------

const char * TOutputSelectDlg::toolTips[] =	// tool tips text
{
	// 0 = radiobutton: CVS output type
	"Output file format = Comma-Separated Values (CSV)",
	// 1 = radiobutton: NetCDF output type
	"Output file format = NetCDF",
	// 2 = path text box
	"Specify file path + name - will add suffix + extension.",
	// 3 = button: browse for path
	"Browse for the file location and name.",
	// 4 = Accept button
	"Save selections and close this dialog.",
	// 5 = Cancel button
	"Cancel selections and close this dialog.",
	// 6 = Help button
	"View help for this dialog.",
	// 7 = "clear path" button
	"Clear the file name display.",
	// last item always
	0
};

#define NoTitle (char*)0

CommandObject TOutputSelectDlg::cmdList[] =
{
	{C_Frame, D_FrameOutputType, 0, NoTitle, NoList,
		CA_None, isSens,
		NoFrame, 0, 0},
	{C_Label, 101, 0, "Output file format:",
		NoList, CA_None, isSens,
		D_FrameOutputType, 0, 0},
	{C_RadioButton, D_OutType_CVS, 1,
		::oFFDescrip[1],
		NoList, CA_None, isSens,
		D_FrameOutputType, 0, 101,
		0, toolTips[0]},
	{C_RadioButton, D_OutType_NetCDF, 0,
		::oFFDescrip[2],
		NoList, CA_None, isSens,
		D_FrameOutputType, 0, D_OutType_CVS,
		0, toolTips[1]},

	{C_Frame, D_FrameOutputFile, 0, NoTitle, NoList,
		CA_None, isSens,
		NoFrame, 0, D_FrameOutputType},
	{C_Label, 201, 0, "Output file path + name base:",
		NoList, CA_None, isSens,
		D_FrameOutputFile, 0, 0},
	{C_TextIn, D_FileName, 0, NoTitle, NoList,
		CA_TextInNotify, isSens,
		D_FrameOutputFile, 0, 201,
		60, toolTips[2]},
	{C_Button, D_BrowseFileName, D_BrowseFileName, "Browse",
		NoList, CA_None, isSens,
		D_FrameOutputFile, 0, D_FileName,
		0, toolTips[3]},
	{C_Button, D_ClearFileName, D_ClearFileName, "Clear",
		NoList, CA_None, isSens,
		D_FrameOutputFile, D_BrowseFileName, D_FileName,
		0, toolTips[7]},

	{C_Frame, D_FrameCommonButtons, 0, NoTitle, NoList,
		CA_NoBorder, isSens,
		NoFrame, 0, D_FrameOutputFile},
	{C_Button, M_OK, M_OK, "&Accept",
		NoList,	CA_DefaultButton, isSens,
		D_FrameCommonButtons, 0, 0,
		0, toolTips[4]},
	{C_Button, M_Cancel, M_Cancel, "&Cancel",
		NoList,	CA_None, isSens,
		D_FrameCommonButtons, M_OK, 0,
		0, toolTips[5]},
	{C_Button, M_Help, M_Help, "&Help",
		NoList,	CA_None, notSens,
		D_FrameCommonButtons, M_Cancel, 0,
		0, toolTips[6]},

	{C_EndOfList, 0, 0, 0, NoList, CA_None, notSens, NoFrame, 0, 0}
};

char const * const TOutputSelectDlg::defaultDlgTitle =	// default dialog title
	"Select Simulation Output Options";

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

TOutputSelectDlg::TOutputSelectDlg (
	vApp * const useParent,				// parent application
	std::string & initFileNameBase,			// output file name
	TOutputBase::TOutputType & initOutputType,	// output type
	char const * const title)			// dialog title
	: TModalDlg (useParent, title),
	  fileNameBase (initFileNameBase),
	  outputType (initOutputType),
	  cancelled (false),
	  origFileNameBase (initFileNameBase),
	  origOutputType (initOutputType)
{
	//--- display dialog
	AddDialogCmds ((CommandObject*)cmdList);	// add dialog controls
	ItemVal retVal;
	ShowModalDialog (title, retVal);		// display dialog now
}

TOutputSelectDlg::TOutputSelectDlg (
	vBaseWindow * const useParent,			// parent window
	std::string & initFileNameBase,			// output file name
	TOutputBase::TOutputType & initOutputType,	// output type
	char const * const title)			// dialog title
	: TModalDlg (useParent, title),
	  fileNameBase (initFileNameBase),
	  outputType (initOutputType),
	  cancelled (false),
	  origFileNameBase (initFileNameBase),
	  origOutputType (initOutputType)
{
	//--- display dialog
	AddDialogCmds ((CommandObject*)cmdList);	// add dialog controls
	ItemVal retVal;
	ShowModalDialog (title, retVal);		// display dialog now
}

void TOutputSelectDlg::DialogDisplayed ()
{
	TModalDlg::DialogDisplayed ();
	// Load the dialogs here
	LoadDlg ();
}

void TOutputSelectDlg::DialogCommand (
	ItemVal cmdID,
	ItemVal cmdValue,
	CmdType cmdType)
{
	switch (cmdID)
	{
	  case M_OK:			EventOK ();		break;
	  case M_Cancel:		EventCancel ();		break;
	  case D_OutType_CVS:		EventOutTypeCVS ();	break;
	  case D_OutType_NetCDF:	EventOutTypeNetCDF ();	break;
	  case D_BrowseFileName:	EventBrowseFileName ();	break;
	  case D_ClearFileName:		EventClearFileName ();	break;
	  default:						break;
	}
	// Default event processing
	TModalDlg::DialogCommand (cmdID, cmdValue, cmdType);
}

void TOutputSelectDlg::Clear ()			// "clear" data members
{
	fileNameBase.clear();
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

void TOutputSelectDlg::LoadDlg ()		// Load the dialog
{
	if ( outputType == TOutputBase::Type_CSV )
		SetValue (D_OutType_CVS, isChk, Value);
	else if ( outputType == TOutputBase::Type_NetCDF )
		SetValue (D_OutType_NetCDF, isChk, Value);
	SetString ( D_FileName, fileNameBase.c_str() );
}

void TOutputSelectDlg::ClearDialog ()		// Clears the entire dialog
{
	SetValue (D_OutType_CVS, isChk, Value);
	SetString ( D_FileName, "" );
}

void TOutputSelectDlg::EventOK ()		// button: OK
{
	// Get file name base
	char newName[maxFileNameSize];		// maxFileNameSize = v/v_defs.h
	GetTextIn ( D_FileName, newName, maxFileNameSize );
	::strtrim (newName);
	fileNameBase = newName;
}

inline
void TOutputSelectDlg::EventCancel ()		// button: Cancel
{
	cancelled = true;
	// reset to the original values
	fileNameBase = origFileNameBase;
	outputType = origOutputType;
}

inline
void TOutputSelectDlg::EventOutTypeCVS ()	// radiobutton: CVS/spreadsheet
{
	outputType = TOutputBase::Type_CSV;
}

inline
void TOutputSelectDlg::EventOutTypeNetCDF ()	// radiobutton: NetCDF file
{
	outputType = TOutputBase::Type_NetCDF;
}

void TOutputSelectDlg::EventBrowseFileName ()	// button: change file name
{
	// retrieve name from dialog
	char newName[maxFileNameSize];		// maxFileNameSize = v/v_defs.h
	GetTextIn ( D_FileName, newName, maxFileNameSize );
	::strtrim (newName);
	TFileName origFileNameBase (newName, TFileName::FT_Normal);
	std::string initPath = origFileNameBase.GetFullPath ();
	if ( !initPath.empty() )
	{
	    // check for valid path
	    TFileName origFileNamePath (initPath, TFileName::FT_Directory);
	    if ( !origFileNamePath.Exists() )
	    {
		// to do
		return;
	    }
	}

	// initial values
	char const* filter[] =
	{
		"CSV files (*.csv)|*.csv|"
		"NetCDF files (*.nc)|*.nc|"
		"All (*.*)|*.*|",
		NULL
	};
	int filterIdx;				// filter index
	if ( outputType == TOutputBase::Type_CSV )
		filterIdx = 0;
	else if ( outputType == TOutputBase::Type_NetCDF )
		filterIdx = 1;

	// browse for file
	TFileSelectDlg fileBrowserDlg (this);	// instance of
	int result = fileBrowserDlg.FileSelectSave (
				"Select Output File Name Base",
				newName, maxFileNameSize,
				filter, filterIdx, initPath.c_str() );

	if ( result )				// not cancelled?
	{
		fileNameBase = newName;
		SetString ( D_FileName, newName );
		if ( filterIdx == 0 )
		{
			outputType = TOutputBase::Type_CSV;
			SetValue (D_OutType_CVS, isChk, Value);
		}
		else if ( filterIdx == 1 )
		{
			outputType = TOutputBase::Type_NetCDF;
			SetValue (D_OutType_NetCDF, isChk, Value);
		}
	}
}

void TOutputSelectDlg::EventClearFileName ()
{
	SetString ( D_FileName, "" );
}

//--- end of file ---

