
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  nflux_ncid;			/* netCDF id */

/* variable ids */
int  minerl_id, nfix_id, volex_id, volgm_id, volpl_id, wdfxma_id, wdfxms_id;

/* added volpl -mdh 8/1/00 */

int
nfluxdef(int *ntimes, char * history) {		/* create nflux.nc */

   int status;

   /* dimension ids */
   int  layer_dim = 0;
   int  time_dim = 0;
   int  cell_dim = 0;

   /* variable shapes */
   int dims[3];

   /* enter define mode */
   status = nc_create("nflux.nc", NC_CLOBBER, &nflux_ncid);
   if (status != NC_NOERR) handle_error("nc_create(nflux.nc)", status);

   /* define dimensions */
   status = nc_def_dim(nflux_ncid, "layer", 10L, &layer_dim);
   status = nc_def_dim(nflux_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(nflux_ncid, "cell", NC_UNLIMITED, &cell_dim);

   /* define variables */

   dims[0] = cell_dim;
   dims[1] = layer_dim;
   dims[2] = time_dim;
   status = nc_def_var (nflux_ncid, "minerl", NC_FLOAT, 3, dims, &minerl_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nflux_ncid, "nfix", NC_FLOAT, 2, dims, &nfix_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nflux_ncid, "volex", NC_FLOAT, 2, dims, &volex_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nflux_ncid, "volgm", NC_FLOAT, 2, dims, &volgm_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nflux_ncid, "volpl", NC_FLOAT, 2, dims, &volpl_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nflux_ncid, "wdfxma", NC_FLOAT, 2, dims, &wdfxma_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nflux_ncid, "wdfxms", NC_FLOAT, 2, dims, &wdfxms_id);

   /* assign attributes */
   status = nc_put_att_text (nflux_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (nflux_ncid, minerl_id, "long_name", 
	strlen("mineral_N"), "mineral_N");
   status = nc_put_att_text (nflux_ncid, minerl_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (nflux_ncid, nfix_id, "long_name", 
	strlen("symbiotic_N_fixation"), "symbiotic_N_fixation");
   status = nc_put_att_text (nflux_ncid, nfix_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   status = nc_put_att_text (nflux_ncid, volex_id, "long_name", 
	strlen("Volatilization_after_uptake"), "Volatilization_after_uptake");
   status = nc_put_att_text (nflux_ncid, volex_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   status = nc_put_att_text (nflux_ncid, volgm_id, "long_name", 
	strlen("Volatilization_gross_min"), "Volatilization_gross_min");
   status = nc_put_att_text (nflux_ncid, volgm_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   status = nc_put_att_text (nflux_ncid, volpl_id, "long_name", 
	strlen("Volatilization_of_N_from_plants"), "Volatilization_of_N_from_plants");
   status = nc_put_att_text (nflux_ncid, volpl_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   status = nc_put_att_text (nflux_ncid, wdfxma_id, "long_name", 
	strlen("Atmospheric_N_fixation"), "Atmospheric_N_fixation");
   status = nc_put_att_text (nflux_ncid, wdfxma_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   status = nc_put_att_text (nflux_ncid, wdfxms_id, "long_name", 
	strlen("Non-symbiotic_soil_N_fixation"), "Non-symbiotic_soil_N_fixation");
   status = nc_put_att_text (nflux_ncid, wdfxms_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   /* leave define mode */
   status = nc_enddef (nflux_ncid);
   return 0;
}
