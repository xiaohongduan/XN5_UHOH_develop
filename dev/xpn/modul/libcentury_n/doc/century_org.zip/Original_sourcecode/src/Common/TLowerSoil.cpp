// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TLowerSoil.cpp
//	Class:	  TLowerSoil
//
//	Description:
//	Class to manage Century's soil C and element pools in the soil
//	below the simulation layer.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Oct98
// ----------------------------------------------------------------------------
//	History: See header file.
// ----------------------------------------------------------------------------
//	Notes:

//	1. There are two soil structures here,
//	(1) the physical structure containing texture, bulk density, and
//	water content described by class TCenturySoil, and
//	(2) Century's C and N,P,S simulation pools superimposed on the
//	physical soil. The simulation pools are located in the surface to
//	"topDepth"; the soil pools below "topDepth" are in the lower
//	simulation soil layer, described by this class.
//
//	2. The surface, or simulation layer, is "topDepth" (cm) deep. This
//	layer can span less than one, or multiple physical soil layers. The
//	simulation pools are stored in the Century variables: som1ci, som2ci,
//	som3ci, metabc, and strucc in class TSoilC; and som1e, som2e, som3e,
//	metabe, and struce in class TNPS.
//
//	3. All units for pool sizes are in mass/area (g m-2). Since the unit
//	area for the simulation is 1 m^2, the pool sizes units are mass (g).
//
//	4. The "lower horizon" in Century 4 was implicitely assummed to have
//	a thickness equal the simulation layer (EDEPTH), but infinitely
//	refillable, so all erosion-based transfers did not diminish its'
//	thickness. Century 4 units in the simulation layer are explicitely
//	mass/area/depth (g m-2/EDEPTH), but since thicknesses and bulk
//	densities are constant in Century 4, the depth dimension was ignored
//	for convenience. In this class, all pool sizes are in mass/area (or
//	mass, ignoring unit area) in order to account for varying
//	depths of layers. Use CGI units for densities, g cm-3. Transfers
//	into/out of these pools are in g m-2 (or g, ignoring area).
//
// ----------------------------------------------------------------------------
//	Algorithm for lower layer management:
//
//	The lower layer is initialized with pools of a specified density
//	(g cm-3) or amount (gof C isotopes and N, P, and S. The ratio of
//	C to N, P, and S is assummed to be constant throughout the thickness
//	of the lower layer.
//
//	Changes to lower soil layer depth behavior with erosion and deposition
//	assume a time scale of hundreds of years and erosion amounts not
//	exceeding a few mm month-1.
//
//	EDEPTH from the fixed parameter set is the both the default and
//	minimum depth for the bottom of the simulation layer. The lower layer
//	bottom depth is the depth of the soil profile, specified in the class
//	TCenturySoil.
//
//	Upon deposition, the boundary between the simulation layer and the
//	lower layer pools, "topDepth", can increase to 50 cm maximum. As
//	"topDepth" increases, the depth of the soil profile increases by the
//	same amount. In this case, the lower simulation layer thickness is
//	constant.
//
//	With "topDepth" at maximum (50 cm), additional deposition transfers
//	material downward from the simulation layer to the lower layer. When
//	the transfer occurs, homogenization of the lower layer occurs.
//	The bulk density of the transferred material, taken from the
//	bulk density in the soil physical class over the corresponding
//	depth range, is used to calculate the amount of each pool transferred
//	to the lower layer.
//
//	Upon erosion, "topDepth" can decrease to the initial and minimum value
//	(20 cm). As "topDepth" decreases, the depth of the soil profile
//	increases by the same amount. In this case, the lower simulation layer
//	thickness is constant.
//
//	With "topDepth" at minimum (20 cm), additional erosion transfers
//	material upward from the lower layer pools to the simulation layer
//	pools. The bulk density of the transferred material, taken from the
//	bulk density in the soil physical class over the corresponding depth
//	range, is used to calculate the amount of each pool transferred to the
//	simulation layer.
// ----------------------------------------------------------------------------

#include "TLowerSoil.h"
#include "NSUnits.h"
#include "AssertEx.h"
#include <string>
#include <limits>
using namespace std;

// ----------------------------------------------------------------------------
//	Member constants
// ----------------------------------------------------------------------------

// The following two constants should match that in class TDepEroBase;
float const
    TLowerSoil::poolMinThreshold = 1.0e-6f,	// min. pool size (g/m2)
    TLowerSoil::minLayerThickness = 1.0e-3f;	// min. layer thickness (cm)

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

TLowerSoil::TLowerSoil (
	float const useMinTopDepth,	// min. depth to top (cm)
	float const useMaxTopDepth)	// max. depth to top (cm)
	: minTopDepth (useMinTopDepth),
	  maxTopDepth (useMaxTopDepth)
{
	Initialize ();
}

// ----------------------------------------------------------------------------
//	public functions - general
// ----------------------------------------------------------------------------

//	SetSoil
// 	set physical soil instance
// inline
void TLowerSoil::SetSoil (TCenturySoil* useSoil)
{
	soil = useSoil;
}

//	SetPoolsFromDensity
//	Initialize the C and E pools.
//	Input pools are densities (g cm-3), not amounts.
void TLowerSoil::SetPoolsFromDensity (
	float const (&densityC)[sizeC],	// C [NUMPOOLS][NUMISO] (g cm-3)
	float const (&densityE)[sizeE])	// E [NUMPOOLS][NUMELEM] (g cm-3)
{
#define C_DENSITY(pool,isotope)	(densityC[(pool) * NUMISO + (isotope)])
#define E_DENSITY(pool,element)	(densityE[(pool) * NUMELEM + (element)])

	// Convert densities (g cm-3) to amount (g in 1 m2 * thickness)
	// amount (g m-2) = density (g cm-3) * volume
	// volume = (1e4 cm2 m-2) * thickness (cm)
	register float const volFactor = Thickness() * NSUnits_cm2m2;
	for ( short pool = 0; pool < NUMPOOLS; ++pool )
	{
	    for (short isotope = 0; isotope < NUMISO; ++isotope)
		C(pool, isotope) = C_DENSITY(pool, isotope) * volFactor;
	    for (short element = 0; element < NUMELEM; ++element)
		E(pool, element) = E_DENSITY(pool, element) * volFactor;
	}
#undef C_DENSITY
#undef E_DENSITY

	CalcCERatios ();			// Calc the C:E ratios
}

//	SetPoolsFromAmounts
//	Initialize the C and E pools.
//	Input pools are amounts (g m-2/cm * 180cm).
void TLowerSoil::SetPoolsFromAmounts (
	float (&amountC)[sizeC],	//   C [NUMPOOLS][NUMISO]
	float (&amountE)[sizeE])	//   E [NUMPOOLS][NUMELEM]
{
#define C_AMOUNT(pool,isotope)	(amountC[(pool) * NUMISO + (isotope)])
#define E_AMOUNT(pool,element)	(amountE[(pool) * NUMELEM + (element)])
	for ( short pool = 0; pool < NUMPOOLS; ++pool )
	{
	    for (short isotope = 0; isotope < NUMISO; ++isotope)
		C(pool, isotope) = C_AMOUNT(pool, isotope);
	    for (short element = 0; element < NUMELEM; ++element)
		E(pool, element) = E_AMOUNT(pool, element);
	}
#undef C_AMOUNT
#undef E_AMOUNT

	CalcCERatios ();			// Calc the C:E ratios
}

//	SetPoolsFromC
//	Initialize from C pools
void TLowerSoil::SetPoolsFromC (
	float (&amountC)[sizeC])	// C [NUMPOOLS][NUMISO]
{
#define C(pool,isotope)	(amountC[(pool) * NUMISO + (isotope)])
#define E(pool,element)	(poolE[(pool) * NUMELEM + (element)])
#define ratio(pool,element)	(ratioCE[(pool) * NUMELEM + (element)])
    for ( short pool = 0; pool < NUMPOOLS; ++pool )
    {
	register float cSum = C(pool,0) + C(pool,1);
	for ( short element = 0; element < NUMELEM; ++element)
	    if ( ratio(pool,element) > 0.0f )
		E(pool,element) = cSum / ratio(pool,element);
    }
#undef C
#undef E
#undef ratio
}

//	Add
// 	Add material of "thickness" to the top of the lower layer;
//	add C isotopes and minerals N, P, S (E) (g m-2).
//	Returns the amount of material NOT transferred to the lower layer,
//	in the parameter arrays amountC, amountE (g m-2),
//	and the thickness transferred in the parameter thickness (cm).
//	Returns the new top depth (cm).
//	Note: Assumes the physical soil has NOT been adjusted yet when
//	the bulk densities are retrieved.
float TLowerSoil::Add (
	float& thickness,		// thickness of added layer (cm)
	float (&amountC)[sizeC],	// new C [NUMPOOLS][NUMISO] (g m-2)
	float (&amountE)[sizeE])	// new E [NUMPOOLS][NUMELEM] (g m-2)
{
	// Contract
	Assert (thickness >= 0.0f);
	Assert (thickness <= maxTopDepth);
	Assert (&amountC != 0);
	Assert (&amountE != 0);

	// check if anything to do
	if ( thickness < minLayerThickness )		// limit = 1/1000 cm
	{
		thickness = 0.0f;
		ZeroThesePools (amountC, amountE);
		return topDepth;
	}

	// initial value of the new simulation layer depth
	register float newTopDepth = topDepth + thickness;
	Assert (newTopDepth >= 0.0f);
	Assert (newTopDepth <= soil->SoilDepth());
	register float wtFraction = 1.0f;

	// Simplest case:
	// Extend depth of simulation layer; no material is transferred.
	// Thickness of lower layer stays the same.
	if ( newTopDepth <= maxTopDepth )
	{
		topDepth = newTopDepth;
		thickness = 0.0f;
		return topDepth;			// all done
	}

	else if ( topDepth < maxTopDepth )	// && newTopDepth > maxTopDepth
	{
		// ------------------------------------------ topDepth
		//   increase of topDepth
		// ------------------------------------------ maxTopDepth
		//   thickness transferred to lower layer
		//   from the simulation layer
		//   (variable thicknessAdded)
		// ------------------------------------------ newTopDepth

		// Transfer material from simulation to lower layer.
		// When getting a value for the bulk density, assume the
		// physical soil has NOT been adjusted for the deposition.
		register float thicknessAdded = newTopDepth - maxTopDepth;
		register float useTop, useBottom;	// for weight mean
		if ( thicknessAdded <= topDepth )
		{
			useTop = topDepth - thicknessAdded;
			useBottom = topDepth;
		}
		else // if ( thicknessAdded > topDepth )
		{
			useTop = 0.0f;
			useBottom = thicknessAdded;
		}
		// weighted mean mass fraction of the pools to be transferred
 		register float numerator =
		    thicknessAdded * soil->BulkDensity().WtdMean (
					useTop, useBottom,
					soil->Depth(), soil->Thickness() );
		register float denominator =
		    thickness * soil->BulkDensity().WtdMean (
					0.0f, topDepth,
					soil->Depth(), soil->Thickness() );
		Assert (denominator != 0.0f);
		wtFraction = numerator / denominator;
		// update
		topDepth = maxTopDepth;
		thickness = thicknessAdded;	// transferred to lower layer
	}

	else // topDepth == maxTopDepth && newTopDepth > maxTopDepth
	{
		// ------------------------------------------ topDepth ==
		//                                            maxTopDepth
		//   thickness transferred to lower layer
		//   from the simulation layer
		//   (variable thicknessAdded)
		// ------------------------------------------ newTopDepth

		// Transfer material from simulation to lower layer.
		// When getting a value for the bulk density, assume the
		// physical soil has NOT been adjusted for the deposition.
		register float thicknessAdded = thickness;
		// weighted mean mass fraction of the pools to be transferred
		register float numerator =
		    thicknessAdded * soil->BulkDensity().WtdMean (
					topDepth - thicknessAdded, topDepth,
					soil->Depth(), soil->Thickness() );
		register float denominator =
		    thickness * soil->BulkDensity().WtdMean (
					0.0f, topDepth,
					soil->Depth(), soil->Thickness() );
		Assert (denominator != 0.0f);
		wtFraction = numerator / denominator;
	}
	Assert (wtFraction >= 0.0f);
	Assert (wtFraction <= 1.0f);

	// add material assuming immediate homogenization
	// Does NOT accomodate decrease in C pools w/depth in the sim. layer.

#define C_add(pool,isotope)	(amountC[(pool) * NUMISO + (isotope)])
#define E_add(pool,element)	(amountE[(pool) * NUMELEM + (element)])

	register float amtAdded;			// amount added (g)
	for ( short pool = 0; pool < NUMPOOLS; ++pool )
	{
	    for (short isotope = 0; isotope < NUMISO; ++isotope)
	    {
		amtAdded = wtFraction * C_add(pool, isotope);
		if ( amtAdded >= poolMinThreshold )
		{
			C(pool, isotope) += amtAdded;		// transfer
			C_add(pool, isotope) -= amtAdded;	// remove
			CCA(pool, isotope) += amtAdded;		// accumulate
		}
	    }
	    for (short element = 0; element < NUMELEM; ++element)
	    {
		amtAdded = wtFraction * E_add(pool, element);
		if ( amtAdded >= poolMinThreshold )
		{
			E(pool, element) += amtAdded;		// transfer
			E_add(pool, element) -= amtAdded;	// remove
			ECA(pool, element) += amtAdded;		// accumulate
		}
	    }
	}
#undef C_add
#undef E_add

	return topDepth;
}

//	Remove
// 	Remove a thickness of the lower layer; pools are the
//	C isotopes and minerals N, P, S (E).
//	Returns the amounts to be transferred to the simulation layer
//	in the parameter arrays removedC, removedE (g m-2),
//	and the thickness transferred to the simulation layer
//	in the parameter thickness (cm).
//	Returns the new top depth (cm).
//	Note: Assumes the physical soil has NOT been adjusted yet when
//	the bulk densities are retrieved.
float TLowerSoil::Remove (
	float& thickness,		// thickness of layer (cm)
	float (&removedC)[sizeC],	// removed C [NUMPOOLS][NUMISO] (g m-2)
	float (&removedE)[sizeE]) 	// removed E [NUMPOOLS][NUMELEM] (g m-2)
{
	// Contract
	Assert (thickness >= 0.0f);
	Assert (thickness <= maxTopDepth);
	Assert (&removedC != 0);
	Assert (&removedE != 0);

	//--- make sure pools are empty
	ZeroThesePools (removedC, removedE);

	//--- check if anything to do
	if ( thickness < minLayerThickness )
	{
		thickness = 0.0;
		return topDepth;
	}

	//--- initial value for the new top depth
	register float newTopDepth = topDepth - thickness;
	Assert (newTopDepth >= 0.0f);
	Assert (newTopDepth <= soil->SoilDepth());

	if ( newTopDepth >= minTopDepth )
	{
		// simplest case: decrease depth of simulation layer
		// ------------------------- minTopDepth
		//   ignored
		// ------------------------- newTopDepth
		//   thickness
		// ------------------------- topDepth

		// material is kept in the lower layer
		topDepth = newTopDepth;		// update
		thickness = 0.0f;		// none transferred
		return topDepth;
	}

	//--- else if ( newTopDepth < minTopDepth )

	// some material is transferred to the simulation layer
	// ------------------------------------------ newTopDepth
	//		thickness removed; i.e.,
	//		transferred to simulation layer
	//		(variable transThick)
	//   thickness  ----------------------------- minTopDepth
	//		thickness of amount of
	//		of lower layer
	//		(variable raisedThick)
	// ------------------------------------------ topDepth

	// Calc amount of soil containing the mass to transfer upwards.

	// raisedThick is the amount topDepth advances upwards
	float raisedThick = topDepth - minTopDepth;

	// transThick is the amount transferred to the sim layer,
	// and is in the same bulk density as parameter thickness
	float transThick = minTopDepth - newTopDepth;

	// The bulk density will change with the transfer, generally
	// being less in the simulation layer. So, calc an equivalent
	// thickness using the bulk den. of the sim. layer, letting
	// the mass be constant, and using the relationships:
	//    bd = g/t (area is constant, so ignored here)
	//    t1 * bd1 = t2 * bd2 (or g = g)
	// If the lower bulk density is higher, then the equivalent
	// thickness should be lower.
	// The thickness ("equivalent transferred thickness")
	// at the lower soil bulk density is:
	float equivThick = transThick *
	  soil->BulkDensity().WtdMean (
				minTopDepth - transThick, minTopDepth,
				soil->Depth(), soil->Thickness() ) /
	  soil->BulkDensity().WtdMean (
				minTopDepth, minTopDepth + transThick,
				soil->Depth(), soil->Thickness() );

	// weight fraction removed
	register float wtFraction =
	    equivThick * soil->BulkDensity().WtdMean (
				minTopDepth, minTopDepth + equivThick,
				soil->Depth(), soil->Thickness() ) /
	    ( (soil->SoilDepth() - minTopDepth) *
			soil->BulkDensity().WtdMean (
				minTopDepth, soil->SoilDepth(),
				soil->Depth(), soil->Thickness() ) );

	Assert (wtFraction >= 0.0f);
	Assert (wtFraction <= 1.0f);

	topDepth = minTopDepth;		// raise top depth to minimum allowed
	thickness -= raisedThick;	// amt transferred

	Assert (wtFraction >= 0.0f);
	Assert (wtFraction <= 1.0f);

	//--- remove material

#define C_rem(pool,isotope)	(removedC[(pool) * NUMISO + (isotope)])
#define E_rem(pool,element)	(removedE[(pool) * NUMELEM + (element)])

	register float amtRemoved;			// amount removed (g)
	for ( short pool = 0; pool < NUMPOOLS; ++pool )
	{
	    for (short isotope = 0; isotope < NUMISO; ++isotope)
	    {
		amtRemoved = wtFraction * C(pool, isotope);
		if ( amtRemoved >= poolMinThreshold )
		{
			C(pool, isotope) -= amtRemoved;		// remove
			C_rem(pool, isotope) = amtRemoved;	// transfer
			CCR(pool, isotope) += amtRemoved;	// accumulate
		}
		else
			C_rem(pool, isotope) = 0.0f;
	    }
	    for (short element = 0; element < NUMELEM; ++element)
	    {
		amtRemoved = wtFraction * E(pool, element);
		if ( amtRemoved >= poolMinThreshold )
		{
			E(pool, element) -= amtRemoved;		// remove
			E_rem(pool, element) = amtRemoved;	// transfer
			ECR(pool, element) += amtRemoved;	// accumulate
		}
		else
			E_rem(pool, element) = 0.0f;
	    }
	}
#undef C_rem
#undef E_rem

	//--- all done!
	return topDepth;
}

//	GetTotalC
//	Return total C in C pools.
float TLowerSoil::GetTotalC () const
{
	register float sum = 0.0f;
	for ( short pool = 0; pool < NUMPOOLS; ++pool )
	    for (short isotope = 0; isotope < NUMISO; ++isotope)
		sum += C(pool, isotope);
	return sum;
}

//	ZeroThesePools
//	Sets the values of the pools to zero.
void TLowerSoil::ZeroThesePools (
	float (&poolsC)[sizeC],		// C [NUMPOOLS][NUMISO] (g m-2)
	float (&poolsE)[sizeE])		// E [NUMPOOLS][NUMELEM] (g m-2)
{
	float *pC = (float*) poolsC;
	float *pE = (float*) poolsE;
	for ( short i = 0; i < sizeC; ++i )
		*(pC++) = 0.0f;
	for ( short i = 0; i < sizeE; ++i )
		*(pE++) = 0.0f;
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Initialize
// 	initialize members
void TLowerSoil::Initialize ()
{
	// scalars and pointers
	topDepth = minTopDepth;
	soil = 0;
	// pools
	for ( short i = 0; i < sizeC; ++i )
		poolC[i] = cumAddC[i] = cumRemC[i] = 0.0f;
	for ( short i = 0; i < sizeE; ++i )
		poolE[i] = cumAddE[i] = cumRemE[i] = ratioCE[i] = 0.0f;
}

//	Copy
// 	copy to this
void TLowerSoil::Copy (TLowerSoil const & object)
{
	if ( &object )
	{
		// scalars and pointers
		topDepth = object.topDepth;
		soil = object.soil;
		// pools
		for ( short i = 0; i < sizeC; ++i )
		{
			poolC[i] = object.poolC[i];
			cumAddC[i] = object.cumAddC[i];
			cumRemC[i] = object.cumRemC[i];
		}
		for ( short i = 0; i < sizeE; ++i )
		{
			poolE[i] = object.poolE[i];
			cumAddE[i] = object.cumAddE[i];
			cumRemE[i] = object.cumRemE[i];
			ratioCE[i] = object.ratioCE[i];
		}
	}
}

//	CalcCERatios
//	Calc the C:E ratios, each pool and each element
void TLowerSoil::CalcCERatios ()
{
#define C(pool,isotope)	(poolC[(pool) * NUMISO + (isotope)])
#define E(pool,element)	(poolE[(pool) * NUMELEM + (element)])
#define ratio(pool,element)	(ratioCE[(pool) * NUMELEM + (element)])
    for ( short pool = 0; pool < NUMPOOLS; ++pool )
    {
	register float cSum = C(pool,0) + C(pool,1);
	for ( short element = 0; element < NUMELEM; ++element)
	    if ( E(pool,element) > 0.0f )
		ratio(pool,element) = cSum / E(pool,element);
    }
#undef C
#undef E
#undef ratio
}

//--- End of file TLowerSoil.cpp ---
