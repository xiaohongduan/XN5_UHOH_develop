
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Global declarations used in writing out NetCDF files */

	/* From the File Definitions */

/* Crop File */
extern int      cropll_ncid, crpvalll_id, crmvstll_id, cgrainll_id, feramtll_id,
		irractll_id, egrainll_id, ermvstll_id, timell_id, lat_id, lon_id;

/* H2O File */
extern	int	h2oll_ncid, avh2o1ll_id, avh2o2ll_id, avh2o3ll_id, asmosll_id, 
		evapll_id, petll_id, rwcfll_id, snlqll_id, snowll_id, stempll_id, 
		stream1ll_id, stream2ll_id, stream5ll_id, stream6ll_id, 
		tranll_id, runoll_id, timell_id, lat_id, lon_id;

/* LIVC File */
extern	int	livcll_ncid, aglivcll_id, bglivcll_id, stdedcll_id, rleavcll_id, 
		frootcll_id, fbrchcll_id, rlwodcll_id, crootcll_id, wood1cll_id, 
		wood2cll_id, wood3cll_id, pltlig1ll_id, pltlig2ll_id, timell_id,
                lat_id, lon_id;

/* LIVN File */
extern	int	livnll_ncid, aglivnll_id, bglivnll_id, stdednll_id, 
		rleavnll_id, frootnll_id, fbrchnll_id, rlwodnll_id, 
		crootnll_id, wood1nll_id, wood2nll_id, wood3nll_id,
                crpstgnll_id, forstgnll_id, timell_id, lat_id, lon_id;

/* NFLUX File */
extern	int     nfluxll_ncid, minerlll_id, nfixll_id, volexll_id, volgmll_id, 
		volplll_id, wdfxmall_id, wdfxmsll_id, timell_id, lat_id, lon_id;

/* NMNR File */
extern 	int     nmnrll_ncid, grominll_id, strmnr1ll_id, strmnr2ll_id, metmnr1ll_id, 
		metmnr2ll_id, s1mnr1ll_id, s1mnr2ll_id, s2mnrll_id, s3mnrll_id, 
		wd1mnrll_id, wd2mnrll_id, wd3mnrll_id, timell_id, lat_id, lon_id;

/* NUPT File */
extern	int	nuptll_ncid, agcnupll_id, bgcnupll_id, rlvnupll_id, frtnupll_id, 
		fbrnupll_id, rlwnupll_id, crtnupll_id, timell_id, lat_id, lon_id;

/* PROD File */
extern	int	prodll_ncid, agcprdll_id, bgcprdll_id, rlvprdll_id, frtprdll_id, 
		fbrprdll_id, rlwprdll_id, crtprdll_id, timell_id, lat_id, lon_id;

/* RESP File */
extern	int	respll_ncid, s11c2ll_id, s21c2ll_id, s2c2ll_id, s3c2ll_id, 
		st1c2ll_id, st2c2ll_id, mt1c2ll_id, mt2c2ll_id, wd1c2ll_id,
		wd2c2ll_id, wd3c2ll_id, timell_id, lat_id, lon_id;

/* SOILC File */
extern	int	soilcll_ncid, defacll_id, som1c1ll_id, som1c2ll_id, som2cll_id, 
		som3cll_id, strucc1ll_id, strucc2ll_id, metabc1ll_id, metabc2ll_id,
                timell_id, lat_id, lon_id;

/* SOILN File */
extern	int	soilnll_ncid, som1n1ll_id, som1n2ll_id, som2nll_id, som3nll_id, 
		strucn1ll_id, strucn2ll_id, metabn1ll_id, metabn2ll_id, timell_id,
                lat_id, lon_id;

/* CREMV File */
extern int 	cremvll_ncid, shremcll_id, sdremcll_id, rlvremcll_id, fbrremcll_id, 
		rlwremcll_id, wd1remcll_id, wd2remcll_id, stremcll_id, metrmcll_id,
                timell_id, lat_id, lon_id;

/* NREMV File */
extern int      nremvll_ncid, shremnll_id, sdremnll_id, rlvremnll_id, fbrremnll_id, 
		rlwremnll_id, wd1remnll_id, wd2remnll_id, stremnll_id, metrmnll_id, 
		fstgrmnll_id, timell_id, lat_id, lon_id;
