// ----------------------------------------------------------------------------
//	Copyright (c) 1998, T.E. Hilinski. All rights reserved.
//	This software is made freely available for non-commercial use.
//	This copyright notice must remain intact and in place.
// ----------------------------------------------------------------------------
//	File:	  TRunProgressDlg.cpp
//	Class:	  TRunProgressDlg
//
//	Description:
//	Class for Displaying the progress of an action in a progress bar.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu
// ----------------------------------------------------------------------------

#include "TRunProgressDlg.h"
#include <v/vapp.h>
#include <v/vutil.h>
#include <v/vynreply.h>
#pragma warn -sig

// ----------------------------------------------------------------------------
//	local variables
// ----------------------------------------------------------------------------

static char *toolTips[] =		// tool tips text
{
	// 0 = progress bar
	"Percent of completion of the task.",
	// 1 = cancel button
	"Cancel this task before completion.",
	// last item always
	NULL
};

CommandObject TRunProgressDlg::cmdList[] =
{
	//--- Dialiog objects
	{C_Text, DC_Caption, 0, 0, NoList, CA_NoBorder, isSens, NoFrame, 0, 0},
	//--- Frame provides a border for bar
	{C_Frame, 101, 0, 0, NoList, CA_None, isSens, NoFrame, 0, DC_Caption},
	{C_Text, DC_LeftLabel, 0, 0, NoList, CA_NoBorder, isSens, 101, 0, 0},
	{C_ProgressBar, DC_ProgressBar, 0, 0,
		NoList, CA_Horizontal, isSens, 101, DC_LeftLabel, 0,
		0, toolTips[0]},
	{C_Text, DC_RightLabel, 0, 0,
		NoList, CA_NoBorder, isSens, 101, DC_ProgressBar, 0},
	//--- buttons are below frame border
	{C_Button, M_Cancel, M_Cancel, " &Cancel ",
		NoList,	CA_DefaultButton, isSens, NoFrame, 0, 101,
		0, toolTips[1]},
	//--- all done!
	{C_EndOfList, 0, 0, 0, NoList, CA_None, notSens, NoFrame}
};

// ----------------------------------------------------------------------------
//	methods
// ----------------------------------------------------------------------------

//--- constructors and destructor

TRunProgressDlg::TRunProgressDlg (
	vApp* const useParent,		// ptr to parent app
	char const* newCaption,		// explanatory caption for bar
	char const* newLeftLabel,	// text for label on left end of bar
	char const* newRightLabel,	// text for label on right end of bar
	bool showPct,			// true if displaying percent progress
	char const* title, 		// text for dialog title bar
	CmdAttribute newSize)		// size: CA_None, CA_Small, CA_Large
	: parent (useParent),
	  vDialog (useParent, 0, title)
{
	Initialize (newCaption, newLeftLabel, newRightLabel, showPct, newSize);

	//--- display dialog
	AddDialogCmds ((CommandObject*)cmdList);	// add dialog controls
	ShowDialog (NULL);
}

TRunProgressDlg::TRunProgressDlg (
	vBaseWindow * const parent,
	vApp* const useParent,		// ptr to parent app
	char const* newCaption,		// explanatory caption for bar
	char const* newLeftLabel,	// text for label on left end of bar
	char const* newRightLabel,	// text for label on right end of bar
	bool showPct,			// true if displaying percent progress
	char const* title, 		// text for dialog title bar
	CmdAttribute newSize)		// size: CA_None, CA_Small, CA_Large
	: parent (useParent),
	  vDialog (useParent, 0, title)
{
	Initialize (newCaption, newLeftLabel, newRightLabel, showPct, newSize);

	//--- display dialog
	AddDialogCmds ((CommandObject*)cmdList);	// add dialog controls
	ShowDialog (NULL);
}

TRunProgressDlg::~TRunProgressDlg ()
{
	if ( IsDisplayed() )
		CloseDialog ();
	Reset ();
}


//--- functions overridden

void TRunProgressDlg::DialogDisplayed ()
{
	vDialog::DialogDisplayed ();
}

void TRunProgressDlg::DialogCommand (ItemVal id, ItemVal val, CmdType type)
{
	// if cancel button is pressed, confirm with user first
	if ( id == M_Cancel )
	{
		vYNReplyDialog dlg (this, "Confirm Cancelation");
		int result = dlg.AskYN ("You pressed the Cancel button.\n\n"
					"Press Yes to cancel, "
					"or No to continue:");
		if ( result == 1 )	// yes, cancel
		{
			if ( cancelFunction )
				(*cancelFunction)();
			CloseDialog ();
		}
		else	// resdisplay dialog
		{
			SetValue (DC_ProgressBar, curValue, Value);
			return;
		}
	}
	// Default event processing
	vDialog::DialogCommand (id, val, type);
}


//--- public functions

//	UseCancelFunction
// 	Set the function to call upon cancel.
void TRunProgressDlg::UseCancelFunction ( void (*newCancelFunction)() )
{
	cancelFunction = newCancelFunction;
}

//	Update
// 	Update the bar display
void TRunProgressDlg::Update (int percent)
{
	curValue = percent;
	SetValue (DC_ProgressBar, curValue, Value);
	// allow other updates to occur
	const_cast<vApp*>(parent)->CheckEvents ();
}

//	Reset
// 	Reset to original state
void TRunProgressDlg::Reset ()
{
	Initialize (NULL, NULL, NULL, false, CA_None);
}


//--- private functions

//	Initialize
// 	Initialize data members
void TRunProgressDlg::Initialize (
	char const* newCaption,		// explanatory caption for bar
	char const* newLeftLabel,	// text for label on left end of bar
	char const* newRightLabel,	// text for label on right end of bar
	bool showPct,			// true if displaying percent progress
	CmdAttribute newSize)		// size: CA_None, CA_Small, CA_Large
{
	// set caption
	short i = ::vGetcmdIdIndex (DC_Caption, cmdList);	// item index
	if ( newCaption )
		cmdList[i].title = const_cast<char*>(newCaption);
	else
		cmdList[i].title = "";

	// set left label text
	i = ::vGetcmdIdIndex (DC_LeftLabel, cmdList);	// item index
	if ( newLeftLabel )
		cmdList[i].title = const_cast<char*>(newLeftLabel);
	else
		cmdList[i].title = "";

	// set right label text
	i = ::vGetcmdIdIndex (DC_RightLabel, cmdList);	// item index
	if ( newRightLabel )
		cmdList[i].title = const_cast<char*>(newRightLabel);
	else
		cmdList[i].title = "";

	// set progress bar attributes
	i = ::vGetcmdIdIndex (DC_ProgressBar, cmdList);	// item index
	if ( showPct )
		cmdList[i].attrs = CA_Horizontal | CA_Percent;
	else
		cmdList[i].attrs = CA_Horizontal | CA_NoLabel;

	// bar size
	if ( newSize == CA_Small ||  newSize == CA_Large )
		cmdList[i].attrs |= newSize;

	// initialize member variables
	curValue = 0;
	cancelFunction = 0;
}
