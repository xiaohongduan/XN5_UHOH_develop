// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TCmdWinBaseMenuTools.cpp
//	Class:	  TCmdWinBase
//	Function: DoMenuEvent_Tools
//
//	Description:
//	Processes selection events from the Options Drop-Down Menu
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Jan98, tom.hilinski@colostate.edu
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------

#include "TCmdWinBase.h"
#include "externals.h"
#include "TUserPreferencesDlg.h"

void TCmdWinBase::DoMenuEvent_Tools (ItemVal itemId)
{
	switch (itemId)
	{
	  case M_Preferences:
	  {
		ActionMsg ("Specifying your preferences");
		vModalDialog* const dlg =
			new TUserPreferencesDlg (&myApp, ::userPref);
		delete (TUserPreferencesDlg*)dlg;
		break;
	  }

	  case M_Tools_Environment:
	  {
		ActionMsg ("Configure display environment");
		break;
	  }

	  case M_Tools_Projects:
	  {
		ActionMsg ("Manage simulation projects");
		break;
	  }

	  case M_Tools_SiteLib:
	  {
		ActionMsg ("Manage site libraries");
		break;
	  }
	  case M_Tools_MgmtLib:
	  {
		ActionMsg ("Manage management libraries");
		break;
	  }

	  case M_Tools_BlkLib:
	  {
		ActionMsg ("Manage management block libraries");
		break;
	  }

	  case M_Tools_PlantWiz:
	  {
		ActionMsg ("Plant parameterization wizard");
		break;
	  }

	  case M_Tools_SoilWiz:
	  {
		ActionMsg ("Soil design wizard");
		break;
	  }

	  case M_Tools_ErosionWiz:
	  {
		ActionMsg ("Erosion design wizard");
		break;
	  }

	  case M_Tools_ClimateWiz:
	  {
		ActionMsg ("Climate generator wizard");
		break;
	  }
/*
	  case :
	  {
		ActionMsg ("");
		break;
	  }
*/
	  default:
		break;
	}
	ActionMsg ("Idle");
}

