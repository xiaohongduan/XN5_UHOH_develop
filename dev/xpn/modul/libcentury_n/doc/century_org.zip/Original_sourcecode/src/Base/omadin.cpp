// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  omadin.cpp
//	Class:	  TCentury
//	Function: GetOMAddition
//
//	Description:
//	Read the new organic matter addition parameter set.
//	Returns true if successful match in database, else false if not.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
// ----------------------------------------------------------------------------
//	History:
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Parameter set is now read in once only during a simulation,
//	  and stored in a TCentury member variable.
//	Jul01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to use new TEventDBList class.
//	Oct01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Fixed loop reading ASTREC (bug found by Melannie Hartman).
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "TEventDBList.h"
#include "util.h"
#include "constants.h"

MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::GetOMAddition (
	char const* omadToMatch)
{
	// error checks
	if ( !omadToMatch || !(*omadToMatch) )		// anything there?
		return false;

	// get the option set
	TEventOptionSet const & optionSet =
		*paramDbList->Get (TEventDBList::DBI_Omad);
	if ( !&optionSet )				// database not there?
		ThrowCentException (TCentException::CE_NSPPDB,
					::eventName[ET_AddOM]);
	if ( !optionSet.GetOptionCount () )		// empty database?
		ThrowCentException (TCentException::CE_EMPPDB,
					::eventName[ET_AddOM]);

	// get the option matching the parameter string
    	TEventOption const * const option = optionSet.GetOption (omadToMatch);
	if ( !option )					// match found?
		return false;

	// retrieve values from option and save in Century's variables
	short const numParams = 6;			// total for an option
	short count = option->GetParamCount ();
	if ( count != numParams )			// counts match?
		ThrowCentException (TCentException::CE_OPCBAD,
					::eventName[ET_AddOM]);

	register short k = 0;			// index to param values

	parcp.astgc = option->GetParameter(k++)->GetValue();
	parcp.astlbl = option->GetParameter(k++)->GetValue();
	parcp.astlig = option->GetParameter(k++)->GetValue();
    	for (short element = 0; element < NUMELEM; ++element)
    	{
		parcp.astrec[element] = option->GetParameter(k++)->GetValue();
		if ( parcp.astrec[element] != 0.0f )
			parcp.astrec[element] = 1.0f / parcp.astrec[element];
	}

	// save option name in Century class variable
	strcpy (sched->curOMAd, omadToMatch);		// save it

	return true;
}	// GetOMAddition
