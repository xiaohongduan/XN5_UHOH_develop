// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  sitein.cpp
//	Class:	  TCentury
//	Function: ReadSiteParameters
//
//	Description:
//	Read the site parameter file.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
// ----------------------------------------------------------------------------
//	History:
//	14Dec99 Tom Hilinski, tom.hilinski@colostate.edu
//	* Drainage layer (NlAYER+1) was not properly initialized in the
//	  physical soil-> Fixed.
//	Mar01 Tom Hilinski, tom.hilinski@colostate.edu
//	* Fixed bug in retrieve of minerl(j,i) parameters - incorrect calc of
//	offset in the parameter set.
//	Dec01 Tom Hilinski, tom.hilinski@colostate.edu
//	* Added initialization of the mineral N,P,S pools.
//	2005Oct	Tom Hilinski
//	* Checks of parameter values moved into classes
//	  nrel::site::VerifySiteParameters, SiteFillDefaultValues
// ----------------------------------------------------------------------------
//	To Do:
//	* Merge the ReadSiteParameters for monthly and daily versions,
//	  to avoid duplicate code and tasks.
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include "TMCSiteParameters.h"
#include "TNcFileErosion.h"
#include <cmath>

//--- debugging start
//#include <iostream>
//using std::cout;
//using std::endl;
//--- debugging end

void TCentury::ReadSiteParameters ()
{
	if ( !GetSite().get() )				// anything to do?
		ThrowCentException ( TCentException::CE_NOSITE,
					"From ReadSiteParameters()" );
	if ( GetSite()->GetSetCount() == 0 )		// any parameter sets?
		ThrowCentException (TCentException::CE_SITENS, 0);

	TMCSiteParIndices const & idx = GetSite()->indices;

	// 1. climate set
	TSiteParamSet const * set = &GetSite()->GetSet (idx.SPGI_Climate);
	float
		precip[12], 		// mean precipitation
		precipStdDev[12], 	// mean precipitation: std. deviation
		precipSkewness[12], 	// mean precipitation: skewness
		tempMin[12],		// minimum mean temp at 2 m (deg C)
		tempMax[12];		// maximum mean temp at 2 m (deg C)
	for ( short i = 0; i < MPY; i++ )
	{
	    precip[i] = set->GetParameter(i + idx.SPI_precip).GetValue();
	    precipStdDev[i] = set->GetParameter(i + idx.SPI_prcstd).GetValue();
	    precipSkewness[i] = set->GetParameter(i + idx.SPI_prcskw).GetValue();
	    tempMin[i] = set->GetParameter(i + idx.SPI_tmn2m).GetValue();
	    tempMax[i] = set->GetParameter(i + idx.SPI_tmx2m).GetValue();
	}
	weather->SetReferenceValues ( precip, precipStdDev, precipSkewness,
					tempMin, tempMax );
	weather->InitAnnualData ( WS_Means );

	// 2. soil and physical set
	set = &GetSite()->GetSet (idx.SPGI_Soil);

	// Note: the index enum values are linear, so need to subtract a
	// base value from enum when in parameter sets beyond the first.
	short base = idx.SPI_ivauto;
	param.ivauto = (int) set->GetParameter(idx.SPI_ivauto - base).GetValue();
	site.nelem = (short) set->GetParameter(idx.SPI_nelem - base).GetValue();
	Assert (site.nelem >= 1 && site.nelem <= NUMELEM);
	siteEnv.SetLatLong (set->GetParameter(idx.SPI_sitlat - base).GetValue(),
			    set->GetParameter(idx.SPI_sitlng - base).GetValue() );

	// Soil physical composition by layer
	short const numLayers =
	    static_cast<short>(
		set->GetParameter(idx.SPI_nlayer - base).GetValue() );
	if ( numLayers > MAXLYR - 1 )	// exceeded maximum num. layers?
		ThrowCentException (TCentException::CE_BDNLYR, 0);
	// initialize soil
	Assert (soil.get() != 0);
	soil->SetNumLayers ( numLayers );

	// retrieve soil components into temp. arrays
	TSoilBase::TFloatArray
		sand(numLayers, 0.0f),
		silt(numLayers, 0.0f),
		clay(numLayers, 0.0f),
		bd(numLayers, 0.0f),
		thick(numLayers, 0.0f),
		wp(numLayers, 0.0f),
		fc(numLayers, 0.0f);

	for ( short i = 0; i < numLayers; i++ )
	{
		sand[i] = set->GetParameter(i + idx.SPI_sand - base).GetValue();
		silt[i] = set->GetParameter(i + idx.SPI_silt - base).GetValue();
		clay[i] = set->GetParameter(i + idx.SPI_clay - base).GetValue();
		bd[i] = set->GetParameter(i + idx.SPI_bulkd - base).GetValue();
		thick[i] = set->GetParameter(i + idx.SPI_thick - base).GetValue();
		wp[i] = set->GetParameter(i + idx.SPI_awilt - base).GetValue();
		fc[i] = set->GetParameter(i + idx.SPI_afiel - base).GetValue();
	}

	// initialize the soil physical structure;
	soil->UseThicknesses (thick);

	//--- debugging start
//	{
//	  char const space = '\t';
//	  char const nl = '\n';
//	  cout << nl
//	       << "sand" << space << "silt"  << space << "clay" << space
//	       << "bd"   << space << "thick" << space << "wp" << space
//	       << "fc"   << space << "adep"
//	       << nl;
//	  for ( short i = 0; i < numLayers; i++ )
//	  {
//		cout
//		  << sand[i]  << space
//		  << silt[i]  << space
//		  << clay[i]  << space
//		  << bd[i]    << space
//		  << thick[i] << space
//		  << wp[i]    << space
//		  << fc[i]    << space
//		  << fixed.adep[i] << space
//		  << nl;
//	  }
//	  cout << endl;
//	}
	//--- debugging end

	// build the soil
	// Calls to soil->AddComponent must be in the same order!
	//  	index	component	Where created:		Type:
	//	0	bulk density	ReadSiteParameters	property
	//	1	sand fraction	ReadSiteParameters	property
	//	2	silt fraction	ReadSiteParameters	property
	//	3	clay fraction	ReadSiteParameters	property
	//	4	wilting point	ReadSiteParameters	property
	//	5	field capacity	ReadSiteParameters 	property
	//	6	water content   ReadSiteParameters	pool
	//	7	SOM wt %	ReadSiteParameters 	property
	//	8	mineral N	ReadSiteParameters 	pool
	// If site.nelem > 1
	//	9	mineral P	ReadSiteParameters	pool
	// If site.nelem == 3
	//	10	mineral S	ReadSiteParameters 	pool

	std::string const names[] =
	{
		"bulk density", "sand fraction", "silt fraction",
		"clay fraction", "wilting point", "field capacity",
		"water content", "SOM wt %",
		"mineral N", "mineral P", "mineral S",
		""
	};
	{ // for local variables
		TSoilProperty bdComp (names[0], bd, 0.1f, 2.5f);
		if ( soil->AddComponent (bdComp) )
			ThrowCentException ( TCentException::CE_NOSOIL,
						names[0].c_str() );
		TSoilProperty sandComp (names[1], sand, 0.0f, 1.0f);
		if ( soil->AddComponent (sandComp) )
			ThrowCentException ( TCentException::CE_NOSOIL,
						names[1].c_str() );
		TSoilProperty siltComp (names[2], silt, 0.0f, 1.0f);
		if ( soil->AddComponent (siltComp) )
			ThrowCentException ( TCentException::CE_NOSOIL,
						names[2].c_str() );
		TSoilProperty clayComp (names[3], clay, 0.0f, 1.0f);
		if ( soil->AddComponent (clayComp) )
			ThrowCentException ( TCentException::CE_NOSOIL,
						names[3].c_str() );
		TSoilProperty wpComp (names[4], wp, 0.0f, 1.0f);
		if ( soil->AddComponent (wpComp) )
			ThrowCentException ( TCentException::CE_NOSOIL,
						names[4].c_str() );
		TSoilProperty fcComp (names[5], fc, 0.0f, 1.0f);
		if ( soil->AddComponent (fcComp) )
			ThrowCentException ( TCentException::CE_NOSOIL,
						names[5].c_str() );

		// the following components don't have data yet
		// soil water
		TSoilBase::TFloatArray waterCm (MAXLYR - 1, 0.0f);
		TSoilPool wcComp (names[6], waterCm, 0.0f, 100.0f);
		if ( soil->AddComponent (wcComp) )
			ThrowCentException ( TCentException::CE_NOSOIL,
						names[6].c_str() );
		// OMPC
		TSoilBase::TFloatArray ompc (MAXLYR - 1, 0.0f);
		TSoilProperty omwpComp (names[7], ompc, 0.0f, 1.0f);
		if ( soil->AddComponent (omwpComp) )
			ThrowCentException ( TCentException::CE_NOSOIL,
						names[7].c_str() );
	}

	// remaining parameters for set
	water.nlaypg = (int) set->GetParameter(idx.SPI_nlaypg - base).GetValue();
	water.depthOfRoots = soil->Depth (water.nlaypg - 1);
	water.drain = set->GetParameter(idx.SPI_drain - base).GetValue();
	float const baseFlowFraction =
		set->GetParameter(idx.SPI_basef - base).GetValue();
	float const stormFlowFraction =
		set->GetParameter(idx.SPI_stormf - base).GetValue();
	soil->SetFractions (baseFlowFraction, stormFlowFraction);
	water.runoff[0] = set->GetParameter(idx.SPI_runoff - base).GetValue();
	water.runoff[1] = set->GetParameter(idx.SPI_runoff - base + 1).GetValue();
	water.runoff[2] = set->GetParameter(idx.SPI_runoff - base + 2).GetValue();
	param.swflag = (int) set->GetParameter(idx.SPI_swflag - base).GetValue();
	param.pH = set->GetParameter(idx.SPI_ph - base).GetValue();
	param.pslsrb = set->GetParameter(idx.SPI_pslsrb - base).GetValue();
	param.sorpmx = set->GetParameter(idx.SPI_sorpmx - base).GetValue();

	// 3.external nutrients set
	set = &GetSite()->GetSet (idx.SPGI_ExtNut);
	base = idx.SPI_epnfa;
	for ( short i = 0; i < 2; i++ )
	{
	    param.epnfa[i] = set->GetParameter(i + idx.SPI_epnfa - base).GetValue();
	    param.epnfs[i] = set->GetParameter(i + idx.SPI_epnfs - base).GetValue();
	    param.satmos[i] = set->GetParameter(i + idx.SPI_satmos - base).GetValue();
	}
	param.sirri = set->GetParameter(idx.SPI_sirri - base).GetValue();

	// If extending, do not read in initial conditions
	// Note: this is a feature of Century 4 that is not implemented here.
	// if ( prevOutput )
	//	return;

	// 4.initial soil and crop/grass organic matter set
	set = &GetSite()->GetSet (idx.SPGI_InitOrg);
	base = idx.SPI_som1ci;
	short k = 0;
	for ( short i = 0; i < 2; i++ )		// for surface and soil->..
	  for ( short j = 0; j < 2; j++ )	// for unlabeled and labeled...
	  {
	    som1ci_ref(i, j) = set->GetParameter(k + idx.SPI_som1ci - base).GetValue();
	    clittr_ref(i, j) = set->GetParameter(k + idx.SPI_clittr - base).GetValue();
	    ++k;
	  }
	for ( short i = 0; i < 2; i++ )		// for unlabeled and labeled...
	{
	  soilC.som2ci[i] = set->GetParameter(i + idx.SPI_som2ci - base).GetValue();
	  soilC.som3ci[i] = set->GetParameter(i + idx.SPI_som3ci - base).GetValue();
	  cropC.aglcis[i] = set->GetParameter(i + idx.SPI_aglcis - base).GetValue();
	  cropC.bglcis[i] = set->GetParameter(i + idx.SPI_bgcis - base).GetValue();
	  cropC.stdcis[i] = set->GetParameter(i + idx.SPI_stdcis - base).GetValue();
	}
	k = 0;
	for ( short i = 0; i < 2; i++ )		// for surface and soil->..
	  for ( short j = 0; j < NUMELEM; j++ )	// for each in N,P,S...
	  {
	    rces1_ref(i, j) = set->GetParameter(k + idx.SPI_rces1 - base).GetValue();
	    rcelit_ref(i, j) = set->GetParameter(k + idx.SPI_rcelit - base).GetValue();
	    ++k;
	  }
	for ( short i = 0; i < 3; i++ )		// for each in N,P,S...
	{
	    param.rces2[i] = set->GetParameter(i + idx.SPI_rces2 - base).GetValue();
	    param.rces3[i] = set->GetParameter(i + idx.SPI_rces3 - base).GetValue();
	    nps.aglive[i] = set->GetParameter(i + idx.SPI_aglive - base).GetValue();
	    nps.bglive[i] = set->GetParameter(i + idx.SPI_bglive - base).GetValue();
	    nps.stdede[i] = set->GetParameter(i + idx.SPI_stdede - base).GetValue();
	}

	// 5.initial forest organic matter set
	set = &GetSite()->GetSet (idx.SPGI_ForOrg);
	base = idx.SPI_rlvcis;
	for ( short i = 0; i < 2; i++ )		// for unlabeled and labeled...
	{
	  forestC.rlvcis[i] = set->GetParameter(i + idx.SPI_rlvcis - base).GetValue();
	  forestC.fbrcis[i] = set->GetParameter(i + idx.SPI_fbrcis - base).GetValue();
	  forestC.rlwcis[i] = set->GetParameter(i + idx.SPI_rlwcis - base).GetValue();
	  forestC.frtcis[i] = set->GetParameter(i + idx.SPI_frtcis - base).GetValue();
	  forestC.crtcis[i] = set->GetParameter(i + idx.SPI_crtcis - base).GetValue();
	  forestC.wd1cis[i] = set->GetParameter(i + idx.SPI_wd1cis - base).GetValue();
	  forestC.wd2cis[i] = set->GetParameter(i + idx.SPI_wd2cis - base).GetValue();
	  forestC.wd3cis[i] = set->GetParameter(i + idx.SPI_wd3cis - base).GetValue();
	}
	for ( short i = 0; i < NUMELEM; i++ )	// for each in N,P,S...
	{
	    nps.rleave[i] = set->GetParameter(i + idx.SPI_rleave - base).GetValue();
	    nps.fbrche[i] = set->GetParameter(i + idx.SPI_fbrche - base).GetValue();
	    nps.rlwode[i] = set->GetParameter(i + idx.SPI_rlwode - base).GetValue();
	    nps.froote[i] = set->GetParameter(i + idx.SPI_froote - base).GetValue();
	    nps.croote[i] = set->GetParameter(i + idx.SPI_croote - base).GetValue();
	}

	// 6. Initial mineral N, P, S set
	set = &GetSite()->GetSet (idx.SPGI_MinNPS);
	base = idx.SPI_minerl;

	// mineral N
	TSoilBase::TFloatArray mineralN (numLayers, 0.0f);
	for ( short layer = 0; layer < numLayers; ++layer )
	{
	    mineralN[layer] = set->GetParameter(layer).GetValue();
	}
	TSoilPool mineralNComp (names[8], mineralN, 0.0f, 100.0f);
	if ( soil->AddComponent (mineralNComp) )
		ThrowCentException ( TCentException::CE_NOSOIL,
					names[8].c_str() );
	water.deepStoreE[N] = mineralN[numLayers - 1];		// deep E store

	// mineral P
	//if ( site.nelem > 1 )
	//{
	    TSoilBase::TFloatArray mineralP (numLayers, 0.0f);
	    for ( short layer = 0; layer < numLayers; ++layer )
	    {
		short const k = layer + MAXLYR;
		mineralP[layer] = set->GetParameter(k).GetValue();
	    }
	    TSoilPool mineralPComp (names[9], mineralP, 0.0f, 100.0f);
	    if ( soil->AddComponent (mineralPComp) )
		ThrowCentException (TCentException::CE_NOSOIL,
					names[9].c_str() );
	    water.deepStoreE[P] = mineralP[numLayers - 1];	// deep E store
	//}

	// mineral S
	//if ( site.nelem > 2 )
	//{
	    TSoilBase::TFloatArray mineralS (numLayers, 0.0f);
	    for ( short layer = 0; layer < numLayers; ++layer )
	    {
		short const k = layer + 2 * MAXLYR;
		mineralS[layer] = set->GetParameter(k).GetValue();
	    }
	    TSoilPool mineralSComp (names[10], mineralS, 0.0f, 100.0f);
	    if ( soil->AddComponent (mineralSComp) )
		ThrowCentException (TCentException::CE_NOSOIL,
					names[10].c_str() );
	    water.deepStoreE[S] = mineralS[numLayers - 1];	// deep E store
	//}

	// parent, secondary, occluded
	base = idx.SPI_minerl;
	for ( short i = 0; i < NUMELEM; i++ )		// for each in N,P,S...
	{
	    nps.parent[i] = set->GetParameter(i + idx.SPI_parent - base).GetValue();
	    nps.secndy[i] = set->GetParameter(i + idx.SPI_secndy - base).GetValue();
	}
	nps.occlud = set->GetParameter(idx.SPI_occlud - base).GetValue();

	// 7. Initial plant-extractable water content fraction (rwcf)
	set = &GetSite()->GetSet (idx.SPGI_Water);
	base = idx.SPI_rwcf;
	for ( short layer = 0; layer < numLayers; ++layer )
	{
	    wt.rwcf[layer] = set->GetParameter(layer).GetValue();
	    Assert (wt.rwcf[layer] <= 1.0f);
	    Assert (wt.rwcf[layer] >= 0.0f);
	}
	wt.snlq = set->GetParameter(idx.SPI_snlq - base).GetValue();
	wt.snow = set->GetParameter(idx.SPI_snow - base).GetValue();

	// 8. lower simulation soil layer pools' initial values
	set = &GetSite()->GetSet (idx.SPGI_LowerHor);
	base = idx.SPI_lhicu;
	for ( short pool = 0; pool < NUMPOOLS; ++pool )
	{
	  site.lhiCU[pool] =
	  	set->GetParameter(idx.SPI_lhicu - base + pool).GetValue();
	  site.lhiCL[pool] =
	  	set->GetParameter(idx.SPI_lhicl - base + pool).GetValue();
	  site.lhiN[pool] =
	  	set->GetParameter(idx.SPI_lhin - base + pool).GetValue();
	  site.lhiP[pool] =
	  	set->GetParameter(idx.SPI_lhis - base + pool).GetValue();
	  site.lhiS[pool] =
	  	set->GetParameter(idx.SPI_lhip - base + pool).GetValue();
	}

	// 9. Erosion and Deposition parameters
	set = &GetSite()->GetSet (idx.SPGI_ErosDep);
	for ( short pool = 0; pool < EPT_NumPools; ++pool )
	    for ( short fraction = 0; fraction < ELF_NumFractions; ++fraction )
	    {
		eflCU_ref (pool, fraction) =
			set->GetParameter(pool).GetValue();
		eflCL_ref (pool, fraction) =
			set->GetParameter(10 + pool).GetValue();
		eflN_ref (pool, fraction) =
			set->GetParameter(20 + pool).GetValue();
	    }

	//--- have values; now do final tasks
	CheckSiteParamValues ();		// verify values

	// all done!
}

//--- end of file sitein.cpp ---

