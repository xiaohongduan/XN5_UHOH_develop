// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  grazin.cpp
//	Class:	  TCentury
//	Function: GetGrazing
//
//	Description:
//	Read the new grazing parameter set.
//	Returns true if successful match in database, else false if not.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
// ----------------------------------------------------------------------------
//	History:
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Parameter set is now read in once only during a simulation,
//	  and stored in a TCentury member variable.
//	Jul01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to use new TEventDBList class.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "TEventDBList.h"
#include "util.h"
#include "constants.h"

MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::GetGrazing (
	char const* grazeToMatch)
{
	// error checks
	if ( !grazeToMatch || !(*grazeToMatch) )	// anything there?
		return false;

	// get the option set
	TEventOptionSet const & optionSet =
		*paramDbList->Get (TEventDBList::DBI_Graz);
	if ( !&optionSet )				// database not there?
		ThrowCentException (TCentException::CE_NSPPDB,
			::eventName[ET_Graze]);
	if ( !optionSet.GetOptionCount () )		// empty database?
		ThrowCentException (TCentException::CE_EMPPDB,
			::eventName[ET_Graze]);

	// get the option matching the parameter string
    	TEventOption const * const option = optionSet.GetOption (grazeToMatch);
	if ( !option )					// match found?
		return false;

	// retrieve values from option and save in Century's variables
	short const numParams = 11;			// total for an option
	short count = option->GetParamCount ();
	if ( count != numParams )			// counts match?
		ThrowCentException (TCentException::CE_OPCBAD,
			::eventName[ET_Graze]);

	register short k = 0;			// index to param values
	register short i;			// loop indices

	parcp.flgrem = option->GetParameter(k++)->GetValue();
	parcp.fdgrem = option->GetParameter(k++)->GetValue();
	parcp.gfcret = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 3; ++i)
		parcp.gret[i] = option->GetParameter(k++)->GetValue();
	parcp.grzeff = (int) option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 3; ++i)
		parcp.fecf[i] = option->GetParameter(k++)->GetValue();
	parcp.feclig = option->GetParameter(k)->GetValue();

	// save option name in Century class variable
	strcpy (sched->curGraz, grazeToMatch);		// save it

	return true;
}
