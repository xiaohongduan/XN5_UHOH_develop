#ifndef INC_nrel_dcirc_TCohortAgModelPercent_h
#define INC_nrel_dcirc_TCohortAgModelPercent_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC
//	File:	  TCohortAgModelPercent.h
//	Class:	  TCohortAgModelPercent
//
//	Description:
//	Class for a simple Cohort Aggregation Model.
//	Specifies a set of rules for cohort similarity, and
//	analyzes cohorts within a landscape type to determine which can
//	be combined.
//	Comparisons are based upon percent variation in model pools.
//	The percentage is constant for the object, and specified in the
//	constructor.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, July 2002
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TCohortAgModelBase.h"
#include "TDayCentIRCConfig.h"
#include "DayCentIRCTypes.h"

using ::nrel::gcf::TCohortList;
using ::nrel::gcf::TCohortListIterator;
using ::nrel::gcf::TCohortIteratorList;

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class TCohortAgModelPercent
	: public ::nrel::gcf::TCohortAgModelBase
{
  public:
	//---- constructors and destructor
	TCohortAgModelPercent (
	TDayCentIRCConfig const & useConfiguration)
	  : ::nrel::gcf::TCohortAgModelBase (useConfiguration)
	  {
	    Initialize ();
	  }
	virtual ~TCohortAgModelPercent ()
	  {
	  }
	TCohortAgModelPercent (
	  TCohortAgModelPercent const & object)	// copy constructor
	  : ::nrel::gcf::TCohortAgModelBase (object)
	  {
	    Initialize ();
	    Copy (object);
	  }

	//---- operator overloads
	TCohortAgModelPercent& operator= (
	  TCohortAgModelPercent const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	::nrel::gcf::TCohortAgModelBase::operator= (object);
	    	Clear ();
		Copy (object);
	    }
	    return *this;
	  }
	bool operator== (TCohortAgModelPercent const & object) const
	  {
	    if ( &object )
	    {
		return true;	// TO DO! TCohortAgModelPercent::operator==
	    }
	    else
		return false;
	  }
	bool operator!= (TCohortAgModelPercent const & object) const
	  {
	    return !(*this == object);
	  }

	//---- functions
	virtual bool AggregateNow (		// True if it is time to
						// aggregate cohorts
	  TCohortList const & cohortList,	//   List of cohorts
	  TTimeManager::TTime const simTimeStep	//   simulation time step
	  ) const
	  {					//   aggregate cohorts
	    return dynamic_cast<TDayCentIRCConfig const &> (
		GetConfiguration() ).GetCATSI().IsTime (simTimeStep);
	  }
	void Clear ()				// "Clear" data members
	  {
	  }
	virtual TCohortAgModelPercent* const Clone () const	// Clone this
	  { return new TCohortAgModelPercent (*this); }

	//---- functions: Queries

  protected:
	//---- constants

	//---- data

	//---- functions
	bool ValuesWithinPercentRange (	// True if value2 within +/- % of value1
	  float baseValue,
	  float compareValue) const
	  {
	    float const range =
		baseValue *
		dynamic_cast<TDayCentIRCConfig const &>(
			GetConfiguration() ).GetCohortVariationFraction();
	    return ( compareValue >= baseValue - range &&
			compareValue <= baseValue + range );
	  }

  private:
	//---- constants

	//---- data

	//---- functions: Virtual
	virtual bool CompareCohorts (		// True if similar cohorts
	  ::nrel::gcf::TCohort const * const cohort1,	//   this cohort
	  ::nrel::gcf::TCohort const * const cohort2	//   and this cohort
	  ) const;
	virtual unsigned int CompareCohorts (	// List of similar cohorts
	  TCohortListIterator begin,		//   start of list of cohorts
	  TCohortListIterator end,		//   end of list of cohorts
	  TTimeManager::TTime const minimumAge,	//   minimum age of cohorts
	  TTimeManager::TTime const currentTime,//   current simulation time
	  TCohortIteratorList & listOfIndices	//   list of indices
	  ) const;

	//---- functions
	void Initialize ()				// Initialize members
	  {
	  }
	void Copy (TCohortAgModelPercent const & object)	// Copy to this
	  {
	  }
};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_TCohortAgModelPercent_h
