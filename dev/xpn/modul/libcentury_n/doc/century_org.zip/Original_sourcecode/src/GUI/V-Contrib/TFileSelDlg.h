// ----------------------------------------------------------------------------
//	Project:  V GUI Enhancement
//	File:	  TFileSelDlg.h
//	Class:	  TFileSelectDlg
//
//	Description:
//	Class for file selection dialog box.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, 19Aug99
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// Copyright (c) 1999 Thomas E. Hilinski. All rights reserved.
// Unauthorized distribution, duplication, sale, and use is prohibited by law.
// ----------------------------------------------------------------------------

#ifndef INC_TFileSelectDlg_h_
#define INC_TFileSelectDlg_h_

#include <v/vfilesel.h>
#include <v/vos.h>

class TFileSelectDlg : public vFileSelect
{
  public:
	//--- constructors and destructor
	TFileSelectDlg (
		const vApp* parentApp)
		: vFileSelect (const_cast<vApp*>(parentApp))
		{ Initialize (); }
	TFileSelectDlg (
		const vBaseWindow* parentWin)
		: vFileSelect (const_cast<vBaseWindow*>(parentWin))
		{ Initialize (); }
	~TFileSelectDlg ()
		{ }

	//--- functions
	bool FileSelect (		// Open a new or existing file
	  char const* const prompt,	//   user prompt
	  char* fileName, 		//   selected file name
	  int const maxLen, 		//   maximum length of fileName
	  char const** const filters, 	//   list of filters
	  int& filterIndex,		//   starting & ending filter
	  char const * const initialPath); // starting path
	bool FileSelectSave (		// Save to a file.
	  char const* const prompt,	//   user prompt
	  char* fileName, 		//   selected file name
	  int const maxLen, 		//   maximum length of fileName
	  char const** const filters, 	//   list of filters
	  int& filterIndex,		//   starting & ending filter
	  char const * const initialPath); // starting path

  private:
	//--- data
	vOS os;					// OS instance
	char prevPath[1024];			// save current path

	//--- functions
	inline void Initialize ()		// initialize members
		{ *prevPath = '\0'; }
	bool ToInitialPath (
		char const* initialPath);
	bool ToPreviousPath ();
	bool DoFileSelection (		// Do the file selection.
	  char const * const prompt,	//   user prompt
	  char* fileName, 		//   selected file name
	  int const maxLen, 		//   maximum length of fileName
	  char const** const filters, 	//   list of filters
	  int& filterIndex,		//   starting & ending filter
	  char const * const initialPath, // starting path
	  bool const save);		//   true if save file else open
};

#endif // INC_TFileSelectDlg_h_
