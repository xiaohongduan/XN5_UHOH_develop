// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  anerob.cpp
//	Class:	  TCentury
//	Function: AnaerobicImpact
//
//	Description:
// 	Ccalculates the impact of soil anerobic conditions on decomposition.
//	Returns a multiplier 'anerob', range: 0-1.
// 	If a microcosm is being simulated, return the value for ANEREF(3)
// 	which is set by the user.
// 	Called From InitMonthlyCycle().
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TCentury.h"

float TCentury::AnaerobicImpact (
	float const ratioPrecPET)	// new (RAIN+IRRACT+AVH2O(3))/PET
{
	float impact = 1.0f;			// return value
	if ( SimMicrocosm() )
		impact = fixed.aneref[2];	// constant soil moisture

	// Determine if RAIN/PET is greater than the ratio with maximum impact.
	else if (ratioPrecPET > fixed.aneref[0] && wt.tave > 2.0f)
	{
		float const xh2o = (ratioPrecPET - fixed.aneref[0]) * wt.pet *
					(1.0f - water.drain);
		if (xh2o > 0.0f)
		{
			/* --- simplified the following ---
			float const newrat = fixed.aneref[0] + xh2o / wt.pet;
			float const slope = (1.0f - fixed.aneref[2]) /
	    				(fixed.aneref[0] - fixed.aneref[1]);
			impact = slope * (newrat - fixed.aneref[0]) + 1.0f;
			*/
			Assert (fixed.aneref[0] - fixed.aneref[1] != 0.0f);
			float const slope = (1.0f - fixed.aneref[2]) /
				(fixed.aneref[0] - fixed.aneref[1]);
			impact = slope * xh2o / wt.pet + 1.0f;
		}
		impact = std::max (impact, fixed.aneref[2]);
	}
	return impact;
}

//--- end of anerob.cpp ---

