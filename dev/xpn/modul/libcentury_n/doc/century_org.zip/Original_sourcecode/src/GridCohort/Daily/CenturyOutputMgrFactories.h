#ifndef INC_nrel_dcirc_CenturyOutputMgrFactories_h
#define INC_nrel_dcirc_CenturyOutputMgrFactories_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  CenturyOutputMgrFactories.h
//
//	Description:
//	Output manager factories.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, tom.hilinski@colostate.edu, June 2002
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TOutputMgrFactoryBase.h"	// output mgr. factory base
#include "TCenturyCellOutputMgr.h"	// cell output manager
#include "TCenturySimOutputMgr.h"	// simulation output manager

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

// ----------------------------------------------------------------------------
//	Cell output manager factory
// ----------------------------------------------------------------------------

class TCenturyCellOutMgrFactory
	: public ::nrel::gcf::TOutputMgrFactoryBase
{
  public:
  	//---- types for CreateInstance
	typedef TCenturyCellOutputMgr::TOwner		OwnerType;
	typedef TCenturyCellOutputMgr::TOutput		OutputType;
	typedef TCenturyCellOutputMgr			OutputMgrType;
	typedef ::nrel::gcf::TOutputMgrFactoryBase	MyBase;

	//---- constructors and destructor
	TCenturyCellOutMgrFactory ()
	  : ::nrel::gcf::TOutputMgrFactoryBase ()
	  {
	  }
	~TCenturyCellOutMgrFactory ()
	  {
	  }
	virtual TSharedPtr<MyBase::OutputMgrType>
					CreateInstance (	// Make output
								// mgr instance
	  MyBase::OwnerType * const useOwner,			//   owner*
	  TSharedPtr<MyBase::OutputType> useOutput 		//   output*
	  ) const
	  {
	    TSharedPtr<OutputMgrType> managerPtr;
	    if ( sizeof(OutputMgrType) > sizeof(::nrel::gcf::NullClass) )
	    {
		managerPtr.reset (

//		    new OutputMgrType (useOwner, useOutput) );

		    new OutputMgrType (
		    	dynamic_cast<OwnerType * const>(useOwner),
		    	static_cast
		    		< TSharedPtr<OutputType> >
		    		(useOutput) ) );
	    }
	    return managerPtr;
	  }

};

// ----------------------------------------------------------------------------
//	Simulation controller output manager factory
// ----------------------------------------------------------------------------

class TCenturySimOutMgrFactory
	: public ::nrel::gcf::TOutputMgrFactoryBase
{
  public:
  	//---- types for CreateInstance
	typedef TCenturySimOutputMgr::TOwner		OwnerType;
	typedef TCenturySimOutputMgr::TOutput		OutputType;
	typedef TCenturySimOutputMgr			OutputMgrType;
	typedef ::nrel::gcf::TOutputMgrFactoryBase	MyBase;

	//---- constructors and destructor
	TCenturySimOutMgrFactory ()
	  : ::nrel::gcf::TOutputMgrFactoryBase ()
	  {
	  }
	~TCenturySimOutMgrFactory ()
	  {
	  }
	virtual TSharedPtr<MyBase::OutputMgrType>
					CreateInstance (	// Make output
								// mgr instance
	  MyBase::OwnerType * const useOwner,			//   owner*
	  TSharedPtr<MyBase::OutputType> useOutput 		//   output*
	  ) const
	  {
	    TSharedPtr<OutputMgrType> managerPtr;
	    if ( sizeof(OutputMgrType) > sizeof(::nrel::gcf::NullClass) )
	    {
		managerPtr.reset (

//		    new OutputMgrType (useOwner, useOutput) );

		    new OutputMgrType (
		    	dynamic_cast<OwnerType * const>(useOwner),
		    	static_cast
		    		< TSharedPtr<OutputType> >
		    		(useOutput) ) );
	    }
	    return managerPtr;
	  }

};


  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_CenturyOutputMgrFactories_h
