// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  anerob.cpp
//	Class:	  TDayCent
//	Function: AnaerobicImpact
//
//	Description:
// 	Calculates the impact of soil anerobic conditions on decomposition.
//	Returns a multiplier 'anerob', range: 0-1.
// 	If a microcosm is being simulated, return the value for ANEREF(3)
// 	which is set by the user.
// 	Called From InitMonthlyCycle().
// ----------------------------------------------------------------------------
//	History:
//	31Jul01 Melannie Hartman, melannie@nrel.colostate.edu
//	* Changed this function from TCentury member to TDayCent member
//        since it initializes daily output variables dwt.*.
//      08Jan02 Melannie Hartman, melannie@nrel.colostate.edu
//      * Updated to keep consistent with TCentury::AnaerobicImpact
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//      To Do - does use of daily PET (dwt.pet) vs. monthly PET (wt.pet)
//      work with this function?
// ----------------------------------------------------------------------------

#include "TDayCent.h"

float TDayCent::AnaerobicImpact (
	float const ratioPrecPET)	// new (RAIN+IRRACT+AVH2O(3))/PET
{
	float impact = 1.0f;			// return value
	if ( SimMicrocosm() )
		impact = fixed.aneref[2];	// constant soil moisture

	// Determine if RAIN/PET is greater than the ratio with maximum impact.
	else if (ratioPrecPET > fixed.aneref[0] && dwt.tave > 2.0f)
	{
		float const xh2o = (ratioPrecPET - fixed.aneref[0]) * dwt.pet *
					(1.0f - water.drain);
		if (xh2o > 0.0f)
		{
			/* --- simplified the following ---
			float const newrat = fixed.aneref[0] + xh2o / dwt.pet;
			float const slope = (1.0f - fixed.aneref[2]) /
	    				(fixed.aneref[0] - fixed.aneref[1]);
			impact = slope * (newrat - fixed.aneref[0]) + 1.0f;
			*/
			Assert (fixed.aneref[0] - fixed.aneref[1] != 0.0f);
			float const slope = (1.0f - fixed.aneref[2]) /
				(fixed.aneref[0] - fixed.aneref[1]);
			impact = slope * xh2o / dwt.pet + 1.0f;
		}
		impact = std::max (impact, fixed.aneref[2]);
	}
	return impact;
}

//--- end of anerob.cpp ---
