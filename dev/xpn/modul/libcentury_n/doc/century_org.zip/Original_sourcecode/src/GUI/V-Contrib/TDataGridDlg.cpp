// ----------------------------------------------------------------------------
// Copyright (c) 1999 Thomas E. Hilinski. All rights reserved.
// Unauthorized distribution, duplication, sale, and use is prohibited by law.
//
//	This software is made available under the terms of the
//	GNU LIBRARY GENERAL PUBLIC LICENSE.
//	This copyright notice must remain intact and in place.
// ----------------------------------------------------------------------------
//	Project:  V GUI Enhancement
//	File:	  TDataGridDlg.cpp
//	Class:	  TDataGridDlg
//
//	Description:
//	A class for a modal dialog displaying a Data Grid.
//	Requires the V GUI library, version 1.22 or higher.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, hilinski@lamar.colostate.edu, Aug99
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TDataGridDlg.h"
#include <v/vutil.h>
#include <v/vnotice.h>
#include <v/vynreply.h>
#include <algorithm>
#include <numeric>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cassert>
using namespace std;

// check for minimum V version
#if (V_VersMajor < 1) || (V_VersMinor < 22)
  #error V version 1.22 or higher is required.
#endif

//--- static member data

const char* TDataGridDlg::version = "1.11";	// class version string
const short TDataGridDlg::maxColTitles =	// max col titles displayed
	CO_RowNumber1 - CO_ColTitle1;
const short TDataGridDlg::maxRowNumbers =	// max row #s displayed
	CO_GridFrame - CO_RowNumber1;
const unsigned int TDataGridDlg::maxCells =	// max cells displayed
	CO_SliderVer - CO_Cell1;
const char* TDataGridDlg::rowNumMaxWidthStr =	// for row number max width
	"9999";
const short TDataGridDlg::maxCellChars = 1024;	// maximum length of cell text

// Note on formats:
// The format sizes assume the sizes for ANSI Std. C are in force.
// float = 4 byte, double = 8 byte,
// short = 2 byte, int = 2 byte, long = 4 byte
const char* TDataGridDlg::defFltFmt = "%-.5f";	// default float format
const short TDataGridDlg::defFltFmtLen = 13;	// default float fmt char len
const char* TDataGridDlg::defDblFmt = "%-.9lf";	// default double format
const short TDataGridDlg::defDblFmtLen = 18;	// default double fmt char len
const char* TDataGridDlg::defShortFmt = "%-6hd";// default short format
const short TDataGridDlg::defShortFmtLen = 7;	// default short fmt char len
const char* TDataGridDlg::defIntFmt = "%-6d";	// default int format
const short TDataGridDlg::defIntFmtLen = 7;	// default int fmt char len
const char* TDataGridDlg::defLongFmt = "%-10d";	// default long format
const short TDataGridDlg::defLongFmtLen = 11;	// default long fmt char len
const char* TDataGridDlg::emptyStr = "";	// empty string pointer


//--- constructors and destructor

TDataGridDlg::TDataGridDlg (
	vApp * const parent,			// ptr to parent
	short useCellsWide,			// num. cells in grid width
	short useCellsTall,			// num. cells in grid height
	char const * const useTitle,		// dialog title
						//   NULL-term string
	char const * const useCaption,		// caption (multiline)
						//   NULL-term string
	char const * const * useColTitles,	// column titles
						//   NULL-term list of
						//   NULL-term strings.
	bool roFlag)				// true if read-only data
	: appParent (parent),
	  userData (0),
	  readOnly (roFlag),
	  vModalDialog ( parent, useTitle )
{
	Initialize ();
	ConstructMe (useCellsWide, useCellsTall, useCaption);
	if ( SaveColTitles (useColTitles) )
		return;					// error
}

TDataGridDlg::TDataGridDlg (
	vBaseWindow * const parent,		// ptr to parent
	vApp * const useAppParent,		// ptr to application parent
	short useCellsWide,			// num. cells in grid width
	short useCellsTall,			// num. cells in grid height
	char const * const useTitle,		// dialog title
						//   NULL-term string
	char const * const useCaption,		// caption (multiline)
						//   NULL-term string
	char const * const * useColTitles,	// column titles
						//   NULL-term list of
						//   NULL-term strings.
	bool roFlag)				// true if read-only data
	: appParent (useAppParent),
	  userData (0),
	  readOnly (roFlag),
	  vModalDialog ( parent, useTitle )
{
	Initialize ();
	ConstructMe (useCellsWide, useCellsTall, useCaption);
	if ( SaveColTitles (useColTitles) )
		return;					// error
}

TDataGridDlg::~TDataGridDlg ()
{
	Clear ();
	delete [] cmdList;
}


//--- functions overridden

void TDataGridDlg::DialogDisplayed ()
{
	//vDialog::DialogDisplayed ();
	vModalDialog::DialogDisplayed ();
	LoadGrid (0, 0);
	initDialog = false;
}

void TDataGridDlg::DialogCommand (ItemVal id, ItemVal val, CmdType type)
{
	switch (id)
	{
	  //--- sliders
	  case CO_SliderVer:			// vertical slider
		Evt_VerticalSlider (val);
		break;
	  case CO_SliderHor:			// horizontal slider
		Evt_HorizontalSlider (val);
		break;

	  //--- dialog buttons
	  case M_OK:				// OK button
		termStatus = true;
		if ( !readOnly && modified )
			ConfirmSave ();
		break;
	  case M_Cancel:			// Cancel button
		termStatus = false;
		break;
	  case M_Save:				// Save button
		if ( !readOnly )
			Evt_SaveData ();
		break;
	  case M_Help:				// Help button
		if ( helpEvtFunc )
			helpEvtFunc (appParent);
		break;

	  //--- everything else!
	  default:
		// need to check for saving a cell's contents?
		if ( !initDialog && !readOnly  &&
		     val == M_TextInLeaveFocus &&
		     id >= CO_Cell1 && id < CO_Cell1 + cellsDisplayed )
		{
			Evt_GetCellData (id - CO_Cell1);
		}
		// else
		// {
		// }
		break;
	};
	EnableSaveButton ();

	// Default event processing
	//vDialog::DialogCommand (id, val, type);
	vModalDialog::DialogCommand (id, val, type);
}


//--- public functions

//	UseData
// 	Specify the data to display.
// 	Arguments:
//	  useData	data array
//			types = char, char*, float, double, short int, long
//	  useRowDim	row dimension of data
//	  useColDim	column dimension of datas
//	  format	format string of the type used by the stdio functions.
//	  roFlag	true if read-only data
//	Returns false if successful, else true if not.

/*
template<T>
bool TDataGridDlg::UseData (
	T useData,		// array of data
	const short useRowDim,	// row dimension
	const short useColDim)	// column dimension
{
	if ( !useData )					// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
	{
		assert ( false );
		return true;					// error
	}
	CopyThisData ( useData );
	return false;
}
*/

//	data element type = char*
bool TDataGridDlg::UseData (char** useData,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )					// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( (const char**)useData );
	return false;
}

//	data element type = char*
bool TDataGridDlg::UseData (const char** useData,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )					// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData );
	return false;
}

//	data element type = char
bool TDataGridDlg::UseData (char* useData,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )					// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData );
	return false;
}

//	data element type = char
bool TDataGridDlg::UseData (const char* useData,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )					// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData );
	return false;
}

//	data element type = float - default format
bool TDataGridDlg::UseData (float* useData,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )				// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData );
	return false;
}

//	data element type = const float - default format
bool TDataGridDlg::UseData (const float* useData,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )				// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData );
	return false;
}

//	data element type = float - specified format
bool TDataGridDlg::UseData (float* useData, const char* format,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )				// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( !format || !(*format) )		// check format
	{
		lastError = NoFormat;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData, format );
	return false;
}

//	data element type = const float - specified format
bool TDataGridDlg::UseData (const float* useData, const char* format,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )				// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( !format || !(*format) )		// check format
	{
		lastError = NoFormat;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData, format );
	return false;
}

//	data element type = double - default format
bool TDataGridDlg::UseData (double* useData,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )				// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData );
	return false;
}

//	data element type = const double - default format
bool TDataGridDlg::UseData (const double* useData,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )				// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData );
	return false;
}

//	data element type = double - specified format
bool TDataGridDlg::UseData (double* useData, const char* format,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )				// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( !format || !(*format) )		// check format
	{
		lastError = NoFormat;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData, format );
	return false;
}

//	data element type = const double - specified format
bool TDataGridDlg::UseData (const double* useData, const char* format,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )				// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( !format || !(*format) )		// check format
	{
		lastError = NoFormat;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData, format );
	return false;
}

//	data element type = short
bool TDataGridDlg::UseData (short* useData,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )				// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData );
	return false;
}

//	data element type = const short
bool TDataGridDlg::UseData (const short* useData,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )				// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData );
	return false;
}

//	data element type = int
bool TDataGridDlg::UseData (int* useData,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )				// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData );
	return false;
}

//	data element type = const int
bool TDataGridDlg::UseData (const int* useData,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )				// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData );
	return false;
}

//	data element type = long
bool TDataGridDlg::UseData (long* useData,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )				// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData );
	return false;
}

//	data element type = const long
bool TDataGridDlg::UseData (const long* useData,
			    const short useRowDim, const short useColDim)
{
	if ( !useData )				// anything there?
	{
		lastError = NoData;
		return true;
	}
	if ( NewDataMemory (useRowDim, useColDim) )
		return true;					// error
	CopyThisData ( useData );
	return false;
}


//	UseHelpFunction
//	Specify function to receive the data upon "Help" button event.
// inline
void TDataGridDlg::UseHelpFunction (
	const void (*useFunction)(vApp * const parent) )
{
	if ( useFunction )
		helpEvtFunc = useFunction;
}

// Set flags

//	SetReadOnly
//	Set the read-only flag.
// inline
void TDataGridDlg::SetReadOnly (const bool roFlag)
{
	readOnly = roFlag;
}

//	DisplayRowNumbers
//	Set the display-row-numbers flag.
// inline
void TDataGridDlg::DisplayRowNumbers (const bool rowNumFlag)
{
	rowNumbers = rowNumFlag;
}


// Actions

//	DisplayGrid
//	Display the data grid.
//	Returns true if OK button pressed, else false if Canceled.
bool TDataGridDlg::DisplayGrid ()
{
	CalcColWidths ();
	if ( rowNumbers )
		BuildRowNumList ();
	BuildCmdList ();
	EnableSaveButton ();
	// display dialog
	AddDialogCmds (cmdList);	// add dialog controls
	ItemVal retVal;
	ShowModalDialog (NULL, retVal);
	return termStatus;	// termStatus == true when retVal == M_OK
}


//--- private functions

//	Initialize
//	Initialize member variables
void TDataGridDlg::Initialize ()
{
	cmdList = 0;
	//--- grid display
	gridCols = gridRows = cellsDisplayed = 0;
	fixedWidth = false;
	sumColWidths = 0;
	colTitles = 0;
	numColTitles = 0;
	rowNumStrings = 0;
	//--- data
	dataType = DT_Unknown;
	data = 0;
	dataRows = dataCols = dataSize = 0;
	leftCol = topRow = 0;
	helpEvtFunc = 0;
	//--- flags
	initDialog = rowNumbers = termStatus = false;
	dataChanged = 0;
	modified = false;
	lastError = NoError;
}

//	ConstructMe
//	Common code to contructors.
void TDataGridDlg::ConstructMe (
	short useCellsWide,
	short useCellsTall,
	const char* useCaption)
{
	// save grid dimensions
	gridCols = useCellsWide;
	gridRows = useCellsTall;
	cellsDisplayed = gridCols * gridRows;
	while ( cellsDisplayed > maxCells )	// don't exceed maximum cells
	{
		if ( gridRows > 2 )		// reduce number of rows?
			--gridRows;
		else if ( gridCols > 2 )	// reduce number of columns?
			--gridCols;
		cellsDisplayed = gridCols * gridRows;
	}
	// save caption
	if ( useCaption && *useCaption )
	{
		try		// allocate memory
		{
			caption = useCaption;
		}
		catch (...)	// something failed!
		{
			lastError = MemoryAlloc;
		}
	}
	// all done!
	initDialog = true;
}

//	copy to data: const char
void TDataGridDlg::CopyThisData (
	const char* useData)
{
	// allocate memory for individual elements and save data
	userData = useData;
	dataType = DT_char;
	char** p = data;
	for ( short i = 0; i < dataSize; ++i )
	{
		try		// allocate memory
		{
			*p = new char [2];		// alloc string
			*(*p + 1) = 0;			// NULL term the string
			**(p++) = *(useData++);		// copy the data
		}
		catch (...)	// something failed!
		{
			lastError = MemoryAlloc;
		}
	}
	fixedWidth = true;
}

// 	copy to data: const char*
void TDataGridDlg::CopyThisData (
	const char** useData)
{
	// allocate memory for individual elements and save data
	userData = useData;
	dataType = DT_string;
	char** p = data;
	const char** q = useData;
	for ( short i = 0; i < dataSize; ++i )
	{
		try					// allocate memory
		{
			*p = new char [strlen(*q) + 1];	// alloc string
			strcpy ( *p, *q );		// copy the data
			++p;
			++q;
		}
		catch (...)				// something failed!
		{
			lastError = MemoryAlloc;
		}
	}
}

//	copy to data: const float
void TDataGridDlg::CopyThisData (
	const float* useData)
{
	// save data as array of strings
	fixedWidth = true;
	userData = useData;
	dataType =DT_float;
	char** p = data;
	const float* q = useData;
	for ( short i = 0; i < dataSize; ++i )
	{
		try		// allocate memory
		{
			*p = new char [defFltFmtLen + 1];	// alloc string
			sprintf ( *p, defFltFmt, *(q++) );
			++p;
		}
		catch (...)	// something failed!
		{
			lastError = MemoryAlloc;
			return;
		}
	}
}

//	copy to data: const float w/format
void TDataGridDlg::CopyThisData (
	const float* useData,
	const char* format)
{
	// save data as array of strings
	userData = useData;
	dataType =DT_float;
	char** p = data;
	const float* q = useData;
	for ( short i = 0; i < dataSize; ++i )
	{
		try		// allocate memory
		{
			*p = new char [defFltFmtLen + 1];	// alloc string
			sprintf ( *p, format, *(q++) );
			++p;
		}
		catch (...)	// something failed!
		{
			lastError = MemoryAlloc;
			return;
		}
	}
}

//	copy to data: const double
void TDataGridDlg::CopyThisData (
	const double* useData)
{
	// save data as array of strings
	fixedWidth = true;
	userData = useData;
	dataType = DT_double;
	char** p = data;
	const double* q = useData;
	for ( short i = 0; i < dataSize; ++i )
	{
		try		// allocate memory
		{
			*p = new char [defDblFmtLen + 1];	// alloc string
			sprintf ( *p, defDblFmt, *(q++) );
			++p;
		}
		catch (...)	// something failed!
		{
			lastError = MemoryAlloc;
			return;
		}
	}
}

//	copy to data: const double w/format
void TDataGridDlg::CopyThisData (
	const double* useData,
	const char* format)
{
	// save data as array of strings
	userData = useData;
	dataType = DT_double;
	char** p = data;
	const double* q = useData;
	for ( short i = 0; i < dataSize; ++i )
	{
		try		// allocate memory
		{
			*p = new char [defFltFmtLen + 1];	// alloc string
			sprintf ( *p, format, *(q++) );
			++p;
		}
		catch (...)	// something failed!
		{
			lastError = MemoryAlloc;
			return;
		}
	}
}

// 	copy to data: const short
void TDataGridDlg::CopyThisData (
	const short* useData)
{
	// save data as array of strings
	fixedWidth = true;
	userData = useData;
	dataType = DT_short;
	char** p = data;
	const short* q = useData;
	for ( short i = 0; i < dataSize; ++i )
	{
		try		// allocate memory
		{
			*p = new char [defShortFmtLen + 1];	// alloc string
			sprintf ( *p, defShortFmt, *(q++) );
			strtrtr (*p);
			++p;
		}
		catch (...)	// something failed!
		{
			lastError = MemoryAlloc;
 			return;
		}
	}
}

// 	copy to data: const int
void TDataGridDlg::CopyThisData (
	const int* useData)
{
	// save data as array of strings
	fixedWidth = true;
	userData = useData;
	dataType = DT_int;
	char** p = data;
	const int* q = useData;
	for ( short i = 0; i < dataSize; ++i )
	{
		try		// allocate memory
		{
			*p = new char [defIntFmtLen + 1];	// alloc string
			sprintf ( *p, defIntFmt, *(q++) );
			strtrtr (*p);
			++p;
		}
		catch (...)	// something failed!
		{
			lastError = MemoryAlloc;
			return;
		}
	}
}

// 	copy to data: const long
void TDataGridDlg::CopyThisData (
	const long* useData)
{
	// save data as array of strings
	fixedWidth = true;
	userData = useData;
	dataType = DT_long;
	char** p = data;
	const long* q = useData;
	for ( short i = 0; i < dataSize; ++i )
	{
		try		// allocate memory
		{
			*p = new char [defLongFmtLen + 1];	// alloc string
			sprintf ( *p, defLongFmt, *(q++) );
			strtrtr (*p);
			++p;
		}
		catch (...)	// something failed!
		{
			lastError = MemoryAlloc;
			return;
		}
	}
}

//	BuildCmdList
//	Build the list of dialog controls
void TDataGridDlg::BuildCmdList ()
{
	// number of elements entries in the list is:
	// Default =
	//	no. of grid cells (gridCols * gridRows) +
	//	sliders (2) + buttons (1) + frames (2) +
	//	blanks (1) + end of list (1)
	// Optional =
	//	caption (0 or 1)
	//	row numbers ( 0 or gridRows + 1 spacer + 1 frame)
	//	column titles (0 or gridCols + 1 frame)
	//	editable (2 buttons)
	assert (gridCols > 0);
	assert (gridRows > 0);
	unsigned int listLen = gridCols * gridRows + 7;
	if ( !caption.empty() )
		++listLen;
	if ( rowNumbers )
		listLen += gridRows + 2;
	if ( colTitles )
		listLen += gridCols + 1;
	if ( !readOnly )
		listLen += 2;		// Save and Cancel buttons
	if ( helpEvtFunc )
		++listLen;		// Help button

	// allocate list memory
	try				// allocate memory
	{
		cmdList = new CommandObject [listLen];
	}
	catch (...)			// something failed!
	{
		lastError = MemoryAlloc;
		return;
	}

	// stock CommandObjects
	CommandObject
		coGridFrame = {C_Frame, CO_GridFrame, 0, emptyStr,
				NoList, CA_NoBorder | CA_NoSpace,
				isSens, NoFrame, 0, 0, 0, 0},
		coColTitlesFrame = {C_Frame, CO_ColTitlesFrame, 0, emptyStr,
				NoList, CA_NoBorder | CA_NoSpace,
				isSens, CO_GridFrame, 0, 0, 0, 0},
		coULSpacer = {C_Text, CO_UpperLeftSpacer, 0, emptyStr,
				NoList, CA_NoBorder,
				notSens, CO_GridFrame, 0, 0, 0, 0},
		coRowNumFrame = {C_Frame, CO_RowNumbersFrame, 0, emptyStr,
				NoList, CA_NoBorder | CA_NoSpace,
				isSens, CO_GridFrame, 0, 0, 0, 0},
		coCellsFrame = {C_Frame, CO_CellsFrame, 0, emptyStr,
				NoList, CA_NoBorder | CA_NoSpace,
				isSens, CO_GridFrame, 0, 0, 0, 0},
		coGridCell = {C_Text, 0, 0, emptyStr, NoList,
				CA_Small | CA_TextInNotify, isSens,
				CO_CellsFrame, 0, 0, 0, 0},
		coSliderHor = {C_Slider, CO_SliderHor, 0, emptyStr, NoList,
				CA_Horizontal, isSens, CO_GridFrame,
				0, CO_CellsFrame, 0, 0},
		coSliderVer = {C_Slider, CO_SliderVer, 0, emptyStr, NoList,
				CA_Vertical, isSens, CO_GridFrame,
				CO_CellsFrame, CO_ColTitlesFrame, 0, 0},
		coButtonRowSpace = {C_Blank, CO_ButtonRowSpace, 0, emptyStr,
				NoList, CA_None, notSens, NoFrame,
				0, CO_GridFrame, 0, 0},
		coOKBtn = {C_Button, M_OK, M_OK, "  &OK  ",
				NoList,	CA_DefaultButton, isSens, NoFrame,
				0, CO_ButtonRowSpace, 0, 0},
		coCancelBtn = {C_Button, M_Cancel, M_Cancel, "&Cancel",
				NoList,	CA_None, isSens, NoFrame,
				M_OK, CO_ButtonRowSpace, 0, 0},
		coSaveBtn = {C_Button, M_Save, M_Save, " &Save ",
				NoList,	CA_None, isSens, NoFrame,
				M_Cancel, CO_ButtonRowSpace, 0, 0},
		coHelpBtn = {C_Button, M_Help, M_Help, " &Help ",
				NoList,	CA_None, isSens, NoFrame,
				M_Save, CO_ButtonRowSpace, 0, 0},
		coEndOfList = {C_EndOfList, 0, 0, 0, 0, CA_None, 0, 0};

	// Build the list
	CommandObject* p = cmdList;		// pointer to cmdList array
	CmdType const cmdType =			// type of grid cell
		readOnly ? C_Text : C_TextIn;
	ItemVal lastAbove = 0, lastLeft;	// last items added at (x,y)
	// caption
	if ( !caption.empty() )
	{
		p->cmdType = C_Text;
		p->cmdId = CO_Caption;
		p->retVal = 0;
		p->title = const_cast<char*>( caption.c_str() );
		p->itemList = NoList;
		p->attrs = CA_NoBorder;
		p->Sensitive = isSens;
		p->cFrame = NoFrame;
		p->cRightOf = 0;
		p->cBelow = 0;
		p->size = 0;
		p->tip = 0;
		++p;
		lastAbove = CO_Caption;
	}
	// Frame for data grid
	*p = coGridFrame;
	p->cBelow = lastAbove;
	++p;
	lastAbove = lastLeft = 0;
	// if displaying row numbers, need a spacer
	if ( rowNumbers )
	{
		*p = coULSpacer;
		p->size = strlen (rowNumMaxWidthStr) + 2;
		++p;
		lastLeft = CO_UpperLeftSpacer;
	}
	// column titles
	if ( colTitles )
	{
		*p = coColTitlesFrame;		// Frame for column titles
		p->cRightOf = lastLeft;
		// add titles
		++p;
		int lastCol = 0;
		for ( short i = 0; i < gridCols; i++ )
		{
			p->cmdType = C_Text;
			p->cmdId = CO_ColTitle1 + i;
			p->retVal = 0;
			p->title = 0;
			p->itemList = const_cast<char*>(colTitles[i]);
			p->attrs = CA_NoBorder;
			p->Sensitive = isSens;
			p->cFrame = CO_ColTitlesFrame;
			p->cRightOf = lastCol;
			p->cBelow = lastAbove;
			p->size = LabelToBeDataLength (colWidth[i]);
			p->tip = 0;
			++p;
			lastCol = CO_ColTitle1 + i;
		}
		// set lastAbove for row numbers and cell grid frame
		lastAbove = CO_ColTitlesFrame;
	}
	//--- Frame for data cells
	*p = coCellsFrame;
	p->cRightOf = lastLeft;
	p->cBelow = lastAbove;
	++p;
	int lastRow = 0, lastCol = 0;
	//--- data cells
	int cmdID = CO_Cell1;				// cell cmd. ID
	for ( short j = 0; j < gridRows; j++ )		// each row...
	{
		for ( short i = 0; i < gridCols; i++ )	// each column...
		{
			*p = coGridCell;
			p->cmdType = cmdType;
			p->cmdId = cmdID;
			p->cRightOf = lastCol;
			p->cBelow = lastRow;
			p->size = colWidth[i];
 			p->tip = 0;
			++p;
			lastCol = cmdID;
			++cmdID;
		}
		lastCol =  0;
		lastRow = CO_Cell1 + j * gridCols;
	}
	// end of cells frame
	// row numbers
	if ( rowNumbers )
	{
		// Frame for row numbers
		*p = coRowNumFrame;
		p->cBelow = lastAbove;
		p->cRightOf = 0;
		// add row number labels
		++p;
		int lastRow = 0;
		int const rowNumLen = strlen (rowNumMaxWidthStr);
		// build CommandObjects
		assert (rowNumStrings != NULL);
		char** pRowStr = rowNumStrings;
		for ( short i = 0; i < gridRows; i++ )
		{
			p->cmdType = C_Text;
			p->cmdId = CO_RowNumber1 + i;
			p->retVal = 0;
			p->title = 0;
			p->itemList = *(pRowStr++);
			p->attrs = CA_NoBorder;
			p->Sensitive = isSens;
			p->cFrame = CO_RowNumbersFrame;
			p->cRightOf = 0;
			p->cBelow = lastRow;
			p->size = rowNumLen;
			p->tip = 0;
			++p;
			lastRow = CO_Cell1 + i * gridCols;
		}
	}
	//--- sliders
	// ...horizontal
	if ( gridCols < dataCols )
	{
		*p = coSliderHor;
		p->cRightOf = lastLeft;
		p->size = GridSizeHorV () + 2;		// size of slider
		++p;
	}
	// ...vertical
	if ( gridRows < dataRows )
	{
		*p = coSliderVer;
		p->cBelow = lastAbove;
		p->size = GridSizeVertV ();	// size of slider
		++p;
	}
	// end of grid frame
	//--- buttons
	*(p++) = coButtonRowSpace;
	*(p++) = coOKBtn;
	if ( !readOnly )
	{
		*(p++) = coCancelBtn;
		*(p++) = coSaveBtn;
		lastLeft = M_Save;
	}
	else
		lastLeft = M_OK;
	if ( helpEvtFunc )
	{
		*p = coHelpBtn;
		p->cRightOf = lastLeft;
 		// lastLeft = M_Help;
		++p;
	}
	//--- all done!
	*p = coEndOfList;
}

//	LoadGrid
// 	Display data the grid, starting at upper left corner = (ulRow, ulCol)
//	where these are zero-based coordinates.
void TDataGridDlg::LoadGrid (const short ulRow, const short ulCol)
{
	if ( !data )					// anything there?
		return;

	leftCol = ulCol;
	topRow = ulRow;
	char** pData = data + ulRow * dataCols + ulCol;	// starting point
	char** p;					// ptr to data array
	int cmdID = CO_Cell1;				// cell cmd. ID
	for ( short i = 0; i < gridRows; i++ )		// each cell row...
	{
	    p = pData + i * dataCols;			// start of next row
	    for ( short j = 0; j < gridCols; j++ )	// each cell col...
		SetString ( cmdID++, *(p++) );
	}
}

//	UpdateRowNumbers
//	Displays the row numbers.
void TDataGridDlg::UpdateRowNumbers (const short newTopRow)
{
	// display row numbers?
	if ( !rowNumbers || !rowNumStrings || !IsDisplayed() )
		return;				// ...no

	static bool firstTime = true;
	if ( !firstTime )
	{
		if ( newTopRow == topRow )		// anything to do?
			return;				// ...no
	}
	else
		firstTime = false;

	for ( short i = 0; i < gridRows; i++ )
		SetString (CO_RowNumber1 + i, rowNumStrings[newTopRow + i]);
}

//	UpdateColTitles
//	Displays the column titles.
void TDataGridDlg::UpdateColTitles (const short newLeftCol)
{
	if ( !colTitles || !IsDisplayed() )		// anything there?
		return;					// ...no

	static bool firstTime = true;
	if ( !firstTime )
	{
		if ( newLeftCol == leftCol )		// anything to do?
			return;				// ...no
	}
	else
		firstTime = false;

	for ( short i = 0; i < gridCols; i++ )
	    if ( i < numColTitles )
		SetString (CO_ColTitle1 + i,
			   const_cast<char*>(colTitles[newLeftCol + i]));
}

//	EnableSaveButton
//	Enable/Disable the save button.
void TDataGridDlg::EnableSaveButton ()
{
	if ( modified )
		SetValue (M_Save, isSens, Sensitive);
	else
		SetValue (M_Save, notSens, Sensitive);
}

//	Clear
// 	reset spreadsheet to default state (data and display)
void TDataGridDlg::Clear ()
{
	// clear the display
	ClearDispCaption ();
	ClearDispColTitles ();
	ClearDispRowNumbers ();
	ClearDispData ();
	// clear the data
	caption.clear();
	ClearColTitles ();
	ClearRowNumStrings ();
	ClearData ();
}

//	ClearData
// 	Reset the class' data members.
void TDataGridDlg::ClearData ()
{
	DelStrListNT (data);
	dataRows = dataCols = dataSize = 0;
	rowNumbers = false;
	delete [] dataChanged;
	dataChanged = 0;
}

//	ClearColTitles
// 	clear the column title member array
void TDataGridDlg::ClearColTitles ()
{
	if ( colTitles )
	{
		DelStrListNT (const_cast<char**>(colTitles));
		numColTitles = 0;
		colWidth.clear();
	}
}

//	ClearRowNumStrings
// 	clear the row number strings member array
void TDataGridDlg::ClearRowNumStrings ()
{
	DelStrListNT (rowNumStrings);
}

//	ClearDispCaption
// 	Erase the displayed caption.
inline void TDataGridDlg::ClearDispCaption ()
{
	if ( !caption.empty() && IsDisplayed () )
		SetString (CO_Caption, emptyStr);
}

//	ClearDispColTitles
// 	Erase the displayed column titles.
void TDataGridDlg::ClearDispColTitles ()
{
	if ( colTitles && IsDisplayed () )
	{
	    int cmdID = CO_ColTitle1;			// title cmd. ID
	    for ( short i = 0; i < numColTitles; i++ )
		    SetString (cmdID++, emptyStr);
	}
}

//	ClearDispRowNumbers
// 	Erase the displayed row number strings.
void TDataGridDlg::ClearDispRowNumbers ()
{
	if ( rowNumbers && IsDisplayed () )
	{
	    int cmdID = CO_RowNumber1;
	    for ( short i = 0; i < gridRows; i++ )
		    SetString (cmdID++, emptyStr);
	}
}

//	ClearDispData
// 	Erase displayed data.
void TDataGridDlg::ClearDispData ()
{
	if ( data && IsDisplayed () )
	{
	    int cmdID = CO_Cell1;			// cell cmd. ID
	    for ( short j = 0; j < gridRows; j++ )	// each row...
		for ( short i = 0; i < gridCols; i++ )	// each column...
		    SetString (cmdID++, emptyStr);
	}
}

//	NewDataMemory
//	Allocate the memory needed for the data array of pointers.
//	Used by all "UseData" functions.
//	Returns false if successful, else true if not.
bool TDataGridDlg::NewDataMemory (
	const short useRowDim,
	const short useColDim)
{
	// error checks
	if ( useRowDim < 0 || useColDim < 0 )	// valid dimensions?
	{
		lastError = BadDimension;
		assert ( false );
		return true;
	}

	// allocate memory
	ClearData ();				// previous data?
	dataRows = useRowDim;			// save data dimensions
	dataCols = useColDim;
	dataSize = dataRows * dataCols;		// potential overflow here!
	try
	{
		data = new char* [dataSize + 1];	// memory
	}
	catch (...)
	{
		if ( data )
		{
			delete [] data;
			data = 0;
		}
		lastError = MemoryAlloc;
		assert ( false );
		return true;
	}
	// set pointers to NULL
	char **p = data;
	for ( short i = 0; i < dataSize; i++ )
		*(p++) = 0;
	*p = 0;					// null-term the list
	// memory for changed flags
	if ( dataType != DT_char )
	{
		try
		{
			dataChanged = new bool [dataSize];
		}
		catch (...)	// something failed!
		{
			if ( dataChanged )
			{
				delete [] dataChanged;
				dataChanged = 0;
			}
			delete [] data;
			data = 0;
			lastError = MemoryAlloc;
			assert ( false );
			return true;
		}
		ResetChangedFlags ();
	}
	return false;				// all done!
}

//	ResetChangedFlags
//	Reset the dataChanged array to false
void TDataGridDlg::ResetChangedFlags ()
{
	if ( dataChanged )
	{
		bool* p = dataChanged;
		for ( short i = 0; i < dataSize; i++ )
			*(p++) = false;
	}
}

//	SaveColTitles
// 	Save the column titles in the member array.
//	Returns false if successful, else true if not.
//	Called only from the contructors.
bool TDataGridDlg::SaveColTitles (
	char const * const * useColTitles)
{
	// error checks
	if ( !useColTitles || !(*useColTitles) )	// anything there?
	{
		lastError = NoTitles;
		return false;				// ...no, but no error
	}

	// count the number of column titles
	char const * const * s = useColTitles;
	while ( *(s++) )
		++numColTitles;

	// allocate memory for the list
	try						// allocate memory
	{
		colTitles = new const char* [numColTitles + 1];
	}
	catch (...)					// something failed!
	{
		lastError = MemoryAlloc;
		return true;
	}
	char** p = const_cast<char**>(colTitles);	// point to new list
	char** q = const_cast<char**>(useColTitles);	// point to src list
	for ( short i = 0; i < numColTitles; i++ )	// copy each title
	{
		if ( *q )				// copy string
		{
			try		// allocate memory
			{
				*p = new char [strlen(*q) + 1];
				strcpy (*p, *q);
			}
			catch (...)	// something failed!
			{
				*p = 0;
				lastError = MemoryAlloc;
				return true;
			}
		}
		else					// no string to copy
			*p = 0;
		++p;					// next string
		++q;
	}
	*p = 0;						// NULL-term the list
	return false;
}

//	CalcColWidths
// 	Calculate the maximum V width of columns from data array.
//	If the width of the data == number of cells displayed, then
//	we can have variable column widths.
//	Otherwise, the column width is fixed at the largest needed.
//	This is due the inability to resize the columns once displayed.
//	This function should be called BEFORE BuildCmdList!
void TDataGridDlg::CalcColWidths ()
{
	// error checks
	assert (colTitles != NULL);
	assert (numColTitles != 0);

	// allocate memory for list of column widths
	try						// allocate memory
	{
	    colWidth.assign (numColTitles, 0);		// member array
	}
	catch (...)					// something failed!
	{
	    lastError = MemoryAlloc;
	    return;
	}

	// build an array of column widths in V units
	char const * const * p = colTitles;	// point to column titles
	TSizeArray::iterator iLength = colWidth.begin();
	while ( iLength != colWidth.end() )
	{
		// check the column titles
		*iLength = strlen (*p);
		++iLength;
		++p;
	}

	// if the number of displayed grid columns < columns of data,
	// then use constant-width columns
	if ( gridCols <= dataCols )
	{
		// reset all column widths to the maximum
		short const maxLength =
			*std::max_element ( colWidth.begin(), colWidth.end() );
		colWidth.assign (numColTitles, maxLength);
	}
}

//	BuildRowNumList
//	Builds a list of row number strings.
//	This function should be called BEFORE BuildCmdList!
void TDataGridDlg::BuildRowNumList ()
{
	if ( rowNumbers && rowNumStrings )	// already done?
		return;

	// length of strings
	// calc'd rather than const for future font width calc
	int numLines;		// temporary
	int const rowNumLen = ::vTextLen (rowNumMaxWidthStr, numLines);

	// create the row number array
	assert 	(dataRows >= gridRows);
	try						// allocate memory
	{
		rowNumStrings = new char* [dataRows + 1];
	}
	catch (...)					// something failed!
	{
		lastError = MemoryAlloc;
		return;
	}
	char** pRowStr = rowNumStrings;
	for ( TSize i = 0; i < dataRows; ++i )
	{
		try					// allocate memory
		{
			*pRowStr = new char [rowNumLen + 1];
		}
		catch (...)				// something failed!
		{
			lastError = MemoryAlloc;
			return;
		}
		**pRowStr = '\0';
		::IntToStr (i + 1, *pRowStr);
		++pRowStr;
	}
	*pRowStr = 0;
}

//	GridSizeHorV
// 	Get the horizontal size of cell grid in V units.
inline
TDataGridDlg::TSize TDataGridDlg::GridSizeHorV ()
{
	if ( sumColWidths == 0 )			// calc only once
	{
	    // calc the total column width
	    // sumColWidths = sum(A * length[i] + B)
	    //		    = A * sum(length[i]) + N * B
	    if ( readOnly )		// C_Text cells = constant-width
	    {
		sumColWidths = 4 * std::accumulate (
			colWidth.begin(), colWidth.begin() + gridCols, 0) +
			gridCols * 3;
		sumColWidths = (sumColWidths - 3) / 4 + 0.5f;
	    }
	    else			// C_TextIn cells = variable-width
	    {
		sumColWidths = 4 * std::accumulate (
			colWidth.begin(), colWidth.begin() + gridCols, 0) +
			gridCols * 6;
		sumColWidths = (sumColWidths - 6) / 4 + 0.5f;
	    }
	}
	return readOnly ?
		CharToTextLabelLengthV (sumColWidths) :
		CharToTextDataLengthV (sumColWidths);
}

//	GridSizeVertV
// 	Calculate the vertical size of cell grid in V units.
inline
TDataGridDlg::TSize TDataGridDlg::GridSizeVertV ()
{
	if ( readOnly )			// C_Text command object in grid
		return (int) (12 * gridRows + 1);
	else				// C_TextIn command object in grid
		return (int) (14 * gridRows + 1);
		//return (int) (14 * gridRows - 6);
}

//	strtrim
//	Trims the leading and trailing spaces from a string.
//	Modifies the string parameter.
void TDataGridDlg::strtrim (char* s)
{
	if ( !s || !(*s) )				// anything there?
		return;

	register short i = (short)(strlen(s) - 1);	// length - 1
	register char* p = s + i;			// point to end

	// trim trailing space
	while ( i >= 0 && (*p < '!' || *p > '~') )
	{
		--p;	// this will underrun "s" at i = 0
		--i;
	}
	*(++p) = '\0';			// terminate with NULL

	// trim leading space (if any)
	if ( *s && ( *s < '!' || *s > '~' ) )
	{
		char *pEnd = p;			// point to terminating NULL
		p = s + 1;			// start of string
		while ( *p < '!' || *p > '~' )	// find 1st non-white space
			++p;
		memmove (s, p, pEnd - p + 1);	// move to start of string
	}
}

//	strtrtr
//	Trims the trailing spaces from a string.
//	Used for speed when don't need to check for leading spaces.
//	Modifies the string parameter.
void TDataGridDlg::strtrtr (char* s)
{
	if ( !s || !(*s) )				// anything there?
		return;

	register short i = (short)(strlen(s) - 1);	// length - 1
	register char* p = s + i;			// point to end

	// trim trailing space
	while ( i >= 0 && (*p < '!' || *p > '~') )
	{
		--p;	// this will underrun "s" at i = 0
		--i;
	}
	*(++p) = '\0';			// terminate with NULL
}

//	DelStrListNT
//	Deletes memory for a null-terminated list of strings.
//	Sets list to NULL.
void TDataGridDlg::DelStrListNT (char** &list)
{
	if ( list )
	{
		char** p = list;
		while ( *p )
			delete [] *(p++);
		delete [] list;
		list = 0;
	}
}

//	CharToTextLabelLengthV
//	Transform a char string length of a label (C_Text) to native V units.
inline
TDataGridDlg::TSize TDataGridDlg::CharToTextLabelLengthV (
	TSize const labelLength) const
{
#if defined(V_VersionWindows) || defined(V_VersionWin95)
	// MS Windows-specific!
	// The col width calc is taken from the source file::function
	//   v/srcwin/vtextc.cpp::initialize
	return labelLength * 4 + 3;
#else
	// X11R6-specific
	return labelLength * ??? + ???;
#endif
}

//	CharToTextDataLengthV
//	Transform a char string length of a label (C_Text) to native V units.
inline
TDataGridDlg::TSize TDataGridDlg::CharToTextDataLengthV (
	TSize const dataLength) const
{
#if defined(V_VersionWindows) || defined(V_VersionWin95)
	// MS Windows-specific!
	// The col width calc is taken from the source file::function
	//   v/srcwin/vtextinc.cpp::initialize
	return dataLength * 4 + 6;
#else
	// X11R6-specific
	return dataLength * ??? + ???;
#endif
}

//	LabelToBeDataLength
//	Tranform string length (to be a label length) to data length.
//	Uses equations in CharToTextLabelLengthV and CharToTextDataLengthV.
//	  Label length = LL, Data length = DL, input string length = SL
//	  LL = f1(SL), DL = f2(SL)
inline
TDataGridDlg::TSize TDataGridDlg::LabelToBeDataLength (
	TSize const stringLength) const
{
    if ( readOnly )
	return stringLength;	// already ready for C_Text
    else
    	// LL(SL') = DL(SL); solve for SL' = SL + 3/4; round to nearest integer
	return ( (float)stringLength + 0.75f /* 3/4 */ + 0.5f /* round */ );
}


//--- Event handlers

//	Evt_VerticalSlider
//	Respond to slider event by displaying appropriate grid data.
//	"value" is in the range 0-100.
void TDataGridDlg::Evt_VerticalSlider (const int value)
{
	static int percent = 0;				// compare to value
	if ( value == percent )				// not changed?
		return;

	register short newTopRow;
	if ( value < percent )				// slider button up?
		newTopRow = topRow - 1;
	else						// slider button down
		newTopRow = topRow + 1;

	register short range = dataRows - gridRows + 1;	// range of topRow
	if ( newTopRow >= 0 && newTopRow < range )
	{
		// position the scroll bar button correctly
		percent = (int) ((float)newTopRow / (range - 1) * 100.0 + 0.5);
		SetValue (CO_SliderVer, percent, Value);
		// update the data
		UpdateRowNumbers (newTopRow);
		LoadGrid (newTopRow, leftCol);
	}
	else
		percent = value;			// save position
}

//	Evt_HorizontalSlider
//	Respond to slider event by displaying appropriate grid data.
//	"value" is in the range 0-100.
void TDataGridDlg::Evt_HorizontalSlider (const int value)
{
	static int percent = 0;				// compare to value
	if ( value == percent )				// not changed?
		return;

	register short newLeftCol;
	if ( value < percent )				// slider button up?
		newLeftCol = leftCol - 1;
	else						// slider button down
		newLeftCol = leftCol + 1;

	register short range = dataCols - gridCols + 1;	// range of leftCol
	if ( newLeftCol >= 0 && newLeftCol < range )
	{
		// position the scroll bar button correctly
		percent = (int) ((float)newLeftCol / (range - 1) * 100.0 + 0.5);
		SetValue (CO_SliderHor, percent, Value);
		// update the data
		UpdateColTitles (newLeftCol);
		LoadGrid (topRow, newLeftCol);
	}
	else
		percent = value;			// save position
}

//	Evt_GetCellData
//	Retrieve the data in a cell if it has changed.
//	Should be used only for data that is not read-only (i.e., uses
//	C_TextIn controls.)
void TDataGridDlg::Evt_GetCellData (
	const int cellNum)	// zero-based linear index to the cells.
{
	// Get the data currently in the cell
	// buffer to contain current cell data:
	char * const newData = new char [maxCellChars + 1];
	GetTextIn (CO_Cell1 + cellNum, (char*)newData, maxCellChars + 1);
	strtrim (newData);

	// get index to the data cell from the grid index, cellNum:
	//   gridCol = cellNum mod gridCols
	//   gridRow = cellNum / gridCols (truncated)
	div_t result = div (cellNum, gridCols);
	register short
		gridCol = result.rem,
		gridRow = result.quot;

	// Compare
	unsigned short idx = (topRow + gridRow) * dataCols +
				leftCol + gridCol;
	char** p = data + idx;			// pointer to data item

	if ( dataType == DT_char )	//--- special case = one character
	{
		if ( **p == *newData )			// changed?
			goto all_done;			// ...no
		**p = *newData;				// save new data
	}
	else				//--- strings
	{
		register unsigned short len = (unsigned short) strlen (newData);
		if ( !strcmp (*p, newData) )		// changed?
			goto all_done;			// ...no
		if ( len > (unsigned short) strlen (*p) )
		{
			// memory for new string
			char* oldData = *p;		// save for undo
			try
			{
				*p = new char [len + 1];
				delete [] oldData;
			}
			catch (...)			// something failed
			{
				*p = oldData;		// restore data
				lastError = MemoryAlloc;
				goto all_done;		// failed
			}
		}
		strcpy (*p, newData);			// save new data
	}

    all_done:
	*(dataChanged + idx) = true;		// flag changed data cell
	modified = true;			// flag dataset changed
	delete [] newData;
}

//	Evt_SaveData
//	Replaces all the data in the "userData" array with the displayed data.
void TDataGridDlg::Evt_SaveData ()
{
	char** pDD = data;			  // ptr to displayed data
	void* pUD = const_cast<void*>(userData);  // void ptr to user data
	bool successful = true;			  // true if successful save

	switch (dataType)			// change according to type
	{
	  case DT_char:
	  {
		char* pD = static_cast<char*>(pUD);	// ptr to char data
		for ( short i = 0; i < dataSize; ++i )
			*(pD++) = **(pDD++);
		break;
	  }
	  case DT_string:
	  {
		char** pD = static_cast<char**>(pUD);	// ptr to user data
		const bool* pF = dataChanged;		// ptr to chgd. flag
		for ( short i = 0; i < dataSize; ++i, ++pF, ++pD, ++pDD )
		    if ( *pF )				// changed?
		    {
			register unsigned short len =
				static_cast<unsigned short>( strlen(*pDD) );
			if ( len > (unsigned short) strlen(*pD) )
			{
				delete [] *pD;
				try		// allocate memory
				{
					*pD = new char [len + 1];
				}
				catch (...)	// something failed!
				{
					lastError = MemoryAlloc;
					successful = false;
					break;
				}
			}
			strcpy (*pD, *pDD);
		    }
		break;
	  }
	  case DT_float:
	  {
		float* pD = static_cast<float*>(pUD);	// ptr to user data
		const bool* pF = dataChanged;		// ptr to chgd. flag
		for ( short i = 0; i < dataSize; ++i, ++pF, ++pD, ++pDD )
		    if ( *pF )				// changed?
			sscanf (*pDD, "%f", pD);
		break;
	  }
	  case DT_double:
	  {
		double* pD = static_cast<double*>(pUD);	// ptr to user data
		const bool* pF = dataChanged;		// ptr to chgd. flag
		for ( short i = 0; i < dataSize; ++i, ++pF, ++pD, ++pDD )
		    if ( *pF )				// changed?
			sscanf (*pDD, "%lf", pD);
		break;
	  }
	  case DT_short:
	  {
		short* pD = static_cast<short*>(pUD);	// ptr to user data
		const bool* pF = dataChanged;		// ptr to chgd. flag
		for ( short i = 0; i < dataSize; ++i, ++pF, ++pD, ++pDD )
		    if ( *pF )				// changed?
			sscanf (*pDD, "%hd", pD);
		break;
	  }
	  case DT_int:
	  {
 		int* pD = static_cast<int*>(pUD);	// ptr to user data
		const bool* pF = dataChanged;		// ptr to chgd. flag
		for ( short i = 0; i < dataSize; ++i, ++pF, ++pD, ++pDD )
		    if ( *pF )				// changed?
			sscanf (*pDD, "%d", pD);
		break;
	  }
	  case DT_long:
	  {
		long* pD = static_cast<long*>(pUD);	// ptr to user data
		const bool* pF = dataChanged;		// ptr to chgd. flag
		for ( short i = 0; i < dataSize; ++i, ++pF, ++pD, ++pDD )
		    if ( *pF )				// changed?
			sscanf (*pDD, "%ld", pD);
		break;
	  }
	  default:
	  	successful = false;
	  	break;
	}
	if ( successful )
	{
		ResetChangedFlags ();
		modified = false;
	}
}


//--- User-interaction functions

//	ConfirmSave
//	Ask user to save data.
void TDataGridDlg::ConfirmSave ()
{
	vYNReplyDialog dlg (this, "Data Was Not Saved");
	int result = dlg.AskYN ("Your data was modified but not saved.\n"
				"Do you want to save your changes?");
	if ( result == 1 )	// save the data?
		Evt_SaveData ();
}




