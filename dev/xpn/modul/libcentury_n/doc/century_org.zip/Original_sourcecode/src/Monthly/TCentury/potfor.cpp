// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  potfor.cpp
//	Class:	  TCentury
//	Function: ForestProductionPotential
//
//	Description:
//	Compute monthly potential production for forest
// ----------------------------------------------------------------------------
//	History:
//	Apr00   Tom Hilinski, tom.hilinski@colostate.edu
//	* Cleaned up code and optimized.
//	Nov01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Changed many variable names to be descriptive and obvious.
//	* Moved moisture ratio to inline function in TCentury.h
//	* Removed "month" parameter - no longer needed.
//	* Changed name: to ForestProductionPotential.
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include "ranfun.h"

void TCentury::ForestProductionPotential ()
{
	if ( wt.stemp <= 0.0f )		// too cold?
	{
		potentProd.forestC = 0.0f;
		return;
	}

	// Estimate potential production based on temp & h2o
	// Calculate temperature effect on growth.
	// potential production:
	float soilTempEffectFraction =
		::gpdf ( wt.stemp, ppdf_ref (0, 1), ppdf_ref (1, 1),
			 ppdf_ref (2, 1), ppdf_ref (3, 1) );
	soilTempEffectFraction *= 0.8f;	 // Added to match version 3.0 -lh 4/93

	// Calculate moisture effect on growth -
	// Value for potential plant production is now calculated from the
	// equation of a line whose intercept changes depending on water
	// content based on soil type.  The function PPRDWC contains the
	// equation for the line.  -rm 9/91
	// Trees are allowed to access the whole soil profile -rm 2/97
	float const soilWaterEffectFraction = PotPlantProdFromSoilH2O (
		water.extrSoilH2OTree,
		MoistureRatioForGrowth ( water.extrSoilH2OTree ) );

	// For large wood, calculate the fraction which is live (sapwood)
	Assert (parfs.sapk != forestC.rlwodc);
	float const liveLargeWoodFraction =
		parfs.sapk / (parfs.sapk + forestC.rlwodc);

	// Calculate LAI and then use in function for LAI reducer on
	// production.  -rm 5/91
	float const lai = canopy.LAI (forestC.rleavc, forestC.rlwodc);
	float const totalPotentialProduction =
		param.prdx[1] *
		soilTempEffectFraction *
		soilWaterEffectFraction *
		co2.co2cpr[FORSYS] *
		WoodProductionFromLAI (lai, parfs.laitop);

	// Calculate monthly maintenance respiration:
	// respiration values for the forest system production components.
	float resppt[FPARTS];
	resppt[LEAF]  = ForestMaintRespiration (wt.tave,  nps.rleave[N]);
	resppt[FROOT] = ForestMaintRespiration (wt.stemp, nps.froote[N]);
	resppt[FBRCH] = ForestMaintRespiration (wt.tave,  nps.fbrche[N]);
	resppt[LWOOD] = ForestMaintRespiration (wt.tave,
				liveLargeWoodFraction * nps.rlwode[N]);
	resppt[CROOT] = ForestMaintRespiration (wt.stemp,
				liveLargeWoodFraction * nps.croote[N]);
	forestC.sumrsp = 0.0f;
	for (short part = 0; part < FPARTS; ++part)
	    forestC.sumrsp += resppt[part];

	// Use 0.5 to convert from biomass to carbon in forest system
	// - Mike Ryan & Dennis Ojima
	// Added calculation of maxForestC  -rm  11/91
	float const maxForestC =
		param.prdx[2] *
		soilTempEffectFraction *
		soilWaterEffectFraction *
		WoodProductionFromLAI (lai, parfs.laitop);
	potentProd.forestC = totalPotentialProduction * 0.5f - forestC.sumrsp;
	potentProd.forestC = std::max ( potentProd.forestC, 0.0f );
	potentProd.forestC = std::min ( potentProd.forestC, maxForestC );
}

