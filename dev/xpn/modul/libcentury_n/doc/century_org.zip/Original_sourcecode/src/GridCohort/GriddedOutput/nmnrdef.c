
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  nmnr_ncid;			/* netCDF id */

/* variable ids */
int  gromin_id, strmnr1_id, strmnr2_id, metmnr1_id, metmnr2_id, 
     s1mnr1_id, s1mnr2_id, s2mnr_id, s3mnr_id, wd1mnr_id, 
     wd2mnr_id, wd3mnr_id;

int
nmnrdef(int *ntimes, char *history) {			/* create nmnr.nc */

   int status;

   /* dimension ids */
   int  time_dim = 0;
   int  cell_dim = 0;

   /* variable shapes */
   int dims[2];

   /* enter define mode */
   status = nc_create("nmnr.nc", NC_CLOBBER, &nmnr_ncid);
   if (status != NC_NOERR) handle_error("nc_create(nmnr.nc)", status);

   /* define dimensions */
   status = nc_def_dim(nmnr_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(nmnr_ncid, "cell", NC_UNLIMITED, &cell_dim);

   /* define variables */

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nmnr_ncid, "gromin", NC_FLOAT, 2, dims, &gromin_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nmnr_ncid, "strmnr1", NC_FLOAT, 2, dims, &strmnr1_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nmnr_ncid, "strmnr2", NC_FLOAT, 2, dims, &strmnr2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nmnr_ncid, "metmnr1", NC_FLOAT, 2, dims, &metmnr1_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nmnr_ncid, "metmnr2", NC_FLOAT, 2, dims, &metmnr2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nmnr_ncid, "s1mnr1", NC_FLOAT, 2, dims, &s1mnr1_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nmnr_ncid, "s1mnr2", NC_FLOAT, 2, dims, &s1mnr2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nmnr_ncid, "s2mnr", NC_FLOAT, 2, dims, &s2mnr_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nmnr_ncid, "s3mnr", NC_FLOAT, 2, dims, &s3mnr_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nmnr_ncid, "wd1mnr", NC_FLOAT, 2, dims, &wd1mnr_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nmnr_ncid, "wd2mnr", NC_FLOAT, 2, dims, &wd2mnr_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nmnr_ncid, "wd3mnr", NC_FLOAT, 2, dims, &wd3mnr_id);

   /* assign attributes */
   status = nc_put_att_text (nmnr_ncid, NC_GLOBAL, "history", strlen(history), history);
   status = nc_put_att_text (nmnr_ncid, gromin_id, "long_name", 
	strlen("gross_N_mineralization"), "gross_N_mineralization");
   status = nc_put_att_text (nmnr_ncid, gromin_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nmnr_ncid, strmnr1_id, "long_name", 
	strlen("surface_structural_N_mineralization"), "surface_structural_N_mineralization");
   status = nc_put_att_text (nmnr_ncid, strmnr1_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nmnr_ncid, strmnr2_id, "long_name", 
	strlen("soil_structural_N_mineralization"), "soil_structural_N_mineralization");
   status = nc_put_att_text (nmnr_ncid, strmnr2_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nmnr_ncid, metmnr1_id, "long_name", 
	strlen("surface_metabolic_N_mineralization"), "surface_metabolic_N_mineralization");
   status = nc_put_att_text (nmnr_ncid, metmnr1_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nmnr_ncid, metmnr2_id, "long_name", 
	strlen("soil_metabolic_N_mineralization"), "soil_metabolic_N_mineralization");
   status = nc_put_att_text (nmnr_ncid, metmnr2_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nmnr_ncid, s1mnr1_id, "long_name", 
	strlen("surface_som1_N_mineralization"), "surface_som1_N_mineralization");
   status = nc_put_att_text (nmnr_ncid, s1mnr1_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nmnr_ncid, s1mnr2_id, "long_name", 
	strlen("soil_som1_N_mineralization"), "soil_som1_N_mineralization");
   status = nc_put_att_text (nmnr_ncid, s1mnr2_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nmnr_ncid, s2mnr_id, "long_name", 
	strlen("soil_som2_N_mineralization"), "soil_som2_N_mineralization");
   status = nc_put_att_text (nmnr_ncid, s2mnr_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nmnr_ncid, s3mnr_id, "long_name", 
	strlen("soil_som3_N_mineralization"), "soil_som3_N_mineralization");
   status = nc_put_att_text (nmnr_ncid, s3mnr_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nmnr_ncid, wd1mnr_id, "long_name", 
	strlen("dead_fine_branch_N_mineralization"), "dead_fine_branch_N_mineralization");
   status = nc_put_att_text (nmnr_ncid, wd1mnr_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nmnr_ncid, wd2mnr_id, "long_name", 
	strlen("dead_large_wood_N_mineralization"), "dead_large_wood_N_mineralization");
   status = nc_put_att_text (nmnr_ncid, wd2mnr_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nmnr_ncid, wd3mnr_id, "long_name", 
	strlen("dead_coarse_root_N_mineralization"), "dead_coarse_root_N_mineralization");
   status = nc_put_att_text (nmnr_ncid, wd3mnr_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   /* leave define mode */
   status = nc_enddef (nmnr_ncid);
   return 0;
}
