
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  prodll_ncid;			/* netCDF id */

/* variable ids */
int  agcprdll_id, bgcprdll_id, rlvprdll_id, frtprdll_id, fbrprdll_id, 
     rlwprdll_id, crtprdll_id;
int  timell_id, lat_id, lon_id;

/* create prod.nc */
int
proddef_ll(int *ntimes, int *nlat, int *nlon, char *history,
           float *opltim, float *qtime) {

   int   status, istart_year, iend_year, ii;
   float fill, fstart_year, fend_year;
   char  timeunits[25], temp[5];

   /* dimension ids */
   int  time_dim = 0;
   int  lat_dim = 0;
   int  lon_dim = 0;

   /* variable shapes */
   int dims[3];

   /* Set fill, start_year, and end_year values */
   fill = NC_FILL_FLOAT;
   fstart_year = *opltim;
   fend_year = *qtime - 1;
   istart_year = fstart_year;
   iend_year = fend_year;

   for (ii = 0; ii < 25; ii++) {
     timeunits[ii] = '\0';
   }
   /* Get the start time for the time definition */
   sprintf(temp, "%d", istart_year); 
   strcat(timeunits, "days since ");
   strcat(timeunits, temp);
   strcat(timeunits, "-01-01");

   /* enter define mode */
   status = nc_create("prodll.nc", NC_CLOBBER, &prodll_ncid);
   if (status != NC_NOERR) handle_error("nc_create(prod.nc)", status);

   /* define dimensions */
   status = nc_def_dim(prodll_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(prodll_ncid, "lat", (size_t) *nlat, &lat_dim);
   status = nc_def_dim(prodll_ncid, "lon", (size_t) *nlon, &lon_dim);

   /* define variables */

   dims[0] = time_dim;
   status = nc_def_var (prodll_ncid, "time", NC_INT, 1, dims, &timell_id);

   dims[0] = lat_dim;
   status = nc_def_var (prodll_ncid, "lat", NC_FLOAT, 1, dims, &lat_id);

   dims[0] = lon_dim;
   status = nc_def_var (prodll_ncid, "lon", NC_FLOAT, 1, dims, &lon_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (prodll_ncid, "agcprd", NC_FLOAT, 3, dims, &agcprdll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (prodll_ncid, "bgcprd", NC_FLOAT, 3, dims, &bgcprdll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (prodll_ncid, "rlvprd", NC_FLOAT, 3, dims, &rlvprdll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (prodll_ncid, "frtprd", NC_FLOAT, 3, dims, &frtprdll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (prodll_ncid, "fbrprd", NC_FLOAT, 3, dims, &fbrprdll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (prodll_ncid, "rlwprd", NC_FLOAT, 3, dims, &rlwprdll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (prodll_ncid, "crtprd", NC_FLOAT, 3, dims, &crtprdll_id);

   /* assign attributes */
   status = nc_put_att_text (prodll_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (prodll_ncid, timell_id, "long_name", strlen("Time"), "Time");
   status = nc_put_att_text (prodll_ncid, timell_id, "units", strlen(timeunits), timeunits);
   status = nc_put_att_text (prodll_ncid, timell_id, "time_step", strlen("monthly"), "monthly");
   status = nc_put_att_text (prodll_ncid, timell_id, "calendar", strlen("gregorian"), "gregorian");
   status = nc_put_att_int (prodll_ncid, timell_id, "start_year", NC_INT, 1, &istart_year);
   status = nc_put_att_int (prodll_ncid, timell_id, "end_year", NC_INT, 1, &iend_year);

   status = nc_put_att_text (prodll_ncid, lat_id, "long_name", strlen("Latitude"), "Latitude");
   status = nc_put_att_text (prodll_ncid, lat_id, "units", strlen("degrees_north"), "degrees_north");
   status = nc_put_att_text (prodll_ncid, lat_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (prodll_ncid, lat_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (prodll_ncid, lon_id, "long_name", strlen("Longitude"), "Longitude");
   status = nc_put_att_text (prodll_ncid, lon_id, "units", strlen("degrees_east"), "degrees_east");
   status = nc_put_att_text (prodll_ncid, lon_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (prodll_ncid, lon_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (prodll_ncid, agcprdll_id, "long_name", 
	strlen("above_ground_carbon_production"), "above_ground_carbon_production");
   status = nc_put_att_text (prodll_ncid, agcprdll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(prodll_ncid, agcprdll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (prodll_ncid, bgcprdll_id, "long_name", 
	strlen("below_ground_carbon_production"), "below_ground_carbon_production");
   status = nc_put_att_text (prodll_ncid, bgcprdll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(prodll_ncid, bgcprdll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (prodll_ncid, rlvprdll_id, "long_name", 
	strlen("leaf_carbon_production"), "leaf_carbon_production");
   status = nc_put_att_text (prodll_ncid, rlvprdll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(prodll_ncid, rlvprdll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (prodll_ncid, frtprdll_id, "long_name", 
	strlen("fine_root_carbon_production"), "fine_root_carbon_production");
   status = nc_put_att_text (prodll_ncid, frtprdll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(prodll_ncid, frtprdll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (prodll_ncid, fbrprdll_id, "long_name", 
	strlen("fine_branch_carbon_production"), "fine_branch_carbon_production");
   status = nc_put_att_text (prodll_ncid, fbrprdll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(prodll_ncid, fbrprdll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (prodll_ncid, rlwprdll_id, "long_name", 
	strlen("large_wood_carbon_production"), "large_wood_carbon_production");
   status = nc_put_att_text (prodll_ncid, rlwprdll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(prodll_ncid, rlwprdll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (prodll_ncid, crtprdll_id, "long_name", 
	strlen("coarse_root_carbon_production"), "coarse_root_carbon_production");
   status = nc_put_att_text (prodll_ncid, crtprdll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(prodll_ncid, crtprdll_id, "_FillValue", NC_FLOAT, 1, &fill);

   /* leave define mode */
   status = nc_enddef (prodll_ncid);
   return 0;
}
