// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  CenturySiteCreatorBase.cpp
//	Class:	  CenturySiteCreatorBase
//
//	Description:
//	Base class for creating site parameter files for the Century models.
//
//	Responsibilities:
//	* <what class is supposed to do>
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, June 2005
//	History: See header file.
// ----------------------------------------------------------------------------

#include "CenturySiteCreatorBase.h"
using namespace ::nrel::century;
#include "AssertEx.h"

// ----------------------------------------------------------------------------
//	Valid specializations
// ----------------------------------------------------------------------------
#if defined ( MONTHLY_CENTURY ) || defined ( ALL_CENTURY )

  #include "TCentury.h"
  template class CenturySiteCreatorBase < TCentury >;

#elif defined ( DAILY_CENTURY ) || defined ( ALL_CENTURY )

  #include "TDayCent.h"
  template class CenturySiteCreatorBase < TDayCent >;

#else
  #error No CenturySiteCreatorBase template specialization macro is defined!
#endif

// ----------------------------------------------------------------------------
//	Shortcut macros for dealing with template declarations
// ----------------------------------------------------------------------------
#define CenturySiteCreatorBase_TEMPLATE 	\
	template 				\
	< 					\
	  class CenturyType			\
	>

#define	CenturySiteCreatorBase_DECLARATION 	\
	CenturySiteCreatorBase 			\
	<					\
	  CenturyType 				\
	>

// ----------------------------------------------------------------------------
//	member functions
// ----------------------------------------------------------------------------

CenturySiteCreatorBase_TEMPLATE
void CenturySiteCreatorBase_DECLARATION::GetClimate (
	  TSiteParamSet & parameterSet)
{
	Assert ( !century.GetSite()->IsEmpty() );
	// climate can be copied directly from the model's site parameters
	parameterSet =
		century.GetSite()->GetSet(
			century.GetSite()->indices.SPGI_Climate );
}

CenturySiteCreatorBase_TEMPLATE
void CenturySiteCreatorBase_DECLARATION::GetSiteAndSoil (
	  TSiteParamSet & parameterSet)
{
    TSiteParamSet & s = parameterSet;
    typename century_type::site_params_type::indices_type const & idx =
    	century.GetSite()->indices;
    short const base = idx.SPI_ivauto;
    s.GetParameter(idx.SPI_ivauto - base).SetValue (century.param.ivauto);
    s.GetParameter(idx.SPI_nelem - base).SetValue (century.site.nelem);
    s.GetParameter(idx.SPI_sitlat - base).SetValue (century.siteEnv.GetLatitude());
    s.GetParameter(idx.SPI_sitlng - base).SetValue (century.siteEnv.GetLongitude());
    // retrieve soil components
    TCenturySoil const & soil = *century.GetSoil();
    short const numLayers =
    	std::min ((short) soil.GetLayerCount(), (short)(MAXLYR - 1));
    short const numLayersPG =
    	std::min (century.water.nlaypg, (short)(MAXLYR - 1));
    for ( short i = 0; i < numLayers; i++ )
    {
	s.GetParameter(i + idx.SPI_sand -  base).SetValue (soil.SandFraction(i));
	s.GetParameter(i + idx.SPI_silt -  base).SetValue (soil.SiltFraction(i));
	s.GetParameter(i + idx.SPI_clay -  base).SetValue (soil.ClayFraction(i));
	s.GetParameter(i + idx.SPI_bulkd - base).SetValue (soil.BulkDensity(i));
	s.GetParameter(i + idx.SPI_thick - base).SetValue (soil.Thickness(i));
	s.GetParameter(i + idx.SPI_awilt - base).SetValue (soil.WiltingPoint(i));
	s.GetParameter(i + idx.SPI_afiel - base).SetValue (soil.FieldCapacity(i));
    }
    s.GetParameter(idx.SPI_nlayer - base).SetValue (numLayers);
    s.GetParameter(idx.SPI_nlaypg - base).SetValue (numLayersPG);
    s.GetParameter(idx.SPI_drain - base).SetValue (century.water.drain);
    s.GetParameter(idx.SPI_basef - base).SetValue (soil.GetBaseFlowFraction());
    s.GetParameter(idx.SPI_stormf - base).SetValue (soil.GetStormFlowFraction());
    s.GetParameter(idx.SPI_runoff - base).SetValue (century.water.runoff[0]);
    s.GetParameter(idx.SPI_runoff - base + 1).SetValue (century.water.runoff[1]);
    s.GetParameter(idx.SPI_runoff - base + 2).SetValue (century.water.runoff[2]);
    s.GetParameter(idx.SPI_swflag - base).SetValue (century.param.swflag);
    s.GetParameter(idx.SPI_ph - base).SetValue (century.param.pH);
    s.GetParameter(idx.SPI_pslsrb - base).SetValue (century.param.pslsrb);
    s.GetParameter(idx.SPI_sorpmx - base).SetValue (century.param.sorpmx);
}

CenturySiteCreatorBase_TEMPLATE
void CenturySiteCreatorBase_DECLARATION::GetExternalNutrients (
	  TSiteParamSet & parameterSet)
{
    TSiteParamSet & s = parameterSet;
    typename century_type::site_params_type::indices_type const & idx =
    	century.GetSite()->indices;
    short const base = idx.SPI_epnfa;
    for ( short i = 0; i < 2; i++ )
    {
	s.GetParameter(i + idx.SPI_epnfa - base).SetValue (century.param.epnfa[i]);
	s.GetParameter(i + idx.SPI_epnfs - base).SetValue (century.param.epnfs[i]);
	s.GetParameter(i + idx.SPI_satmos - base).SetValue (century.param.satmos[i]);
    }
    s.GetParameter(idx.SPI_sirri - base).SetValue (century.param.sirri);
}

CenturySiteCreatorBase_TEMPLATE
void CenturySiteCreatorBase_DECLARATION::GetCropAndSOM (
	  TSiteParamSet & parameterSet)
{
    TSiteParamSet & s = parameterSet;
    typename century_type::site_params_type::indices_type const & idx =
    	century.GetSite()->indices;
    short const base = idx.SPI_som1ci;
    short k = 0;
    for ( short i = 0; i < 2; i++ )		// for surface and soil->..
      for ( short j = 0; j < 2; j++ )		// for unlabeled and labeled...
      {
	s.GetParameter(k + idx.SPI_som1ci - base).SetValue(century.som1ci_ref(i, j));
	s.GetParameter(k + idx.SPI_clittr - base).SetValue(century.clittr_ref(i, j));
	++k;
      }
    for ( short i = 0; i < 2; i++ )		// for unlabeled and labeled...
    {
      s.GetParameter(i + idx.SPI_som2ci - base).SetValue(century.soilC.som2ci[i]);
      s.GetParameter(i + idx.SPI_som3ci - base).SetValue(century.soilC.som3ci[i]);
      s.GetParameter(i + idx.SPI_aglcis - base).SetValue(century.cropC.aglcis[i]);
      s.GetParameter(i + idx.SPI_bgcis - base).SetValue(century.cropC.bglcis[i]);
      s.GetParameter(i + idx.SPI_stdcis - base).SetValue(century.cropC.stdcis[i]);
    }

    // C:E ratios - this is a kluge putting this update here, but the update
    // currently is not needed inside of century, so...

    // update C:E ratios
    // to do: move these into new century function "MonthEnd"
    for (short e = 0; e < century.site.nelem; ++e)
    {
    	if (century.som1e_ref (SRFC, e) > 0.0f)
    	  century.rces1_ref (SRFC, e) =
    	  	century.soilC.som1c[SRFC] / century.som1e_ref (SRFC, e);
    	if (century.som1e_ref (SOIL, e) > 0.0f)
    	  century.rces1_ref (SOIL, e) =
    	  	century.soilC.som1c[SOIL] / century.som1e_ref (SOIL, e);
    	if (century.nps.som2e[e] > 0.0f)
    	  century.param.rces2[e] = century.soilC.som2c / century.nps.som2e[e];
    	if (century.nps.som3e[e] > 0.0f)
    	  century.param.rces3[e] = century.soilC.som3c / century.nps.som3e[e];

//	if ( sysType.HaveTree() )
//	{
//		cerfor_ref (2, FBRCH, e) = forestC.wood1c / nps.wood1e[e];
//		cerfor_ref (2, LWOOD, e) = forestC.wood2c / nps.wood2e[e];
//		cerfor_ref (2, CROOT, e) = forestC.wood3c / nps.wood3e[e];
//	}
    }

    k = 0;
    for ( short i = 0; i < 2; i++ )		// for surface and soil->..
      for ( short j = 0; j < NUMELEM; j++ )	// for each in N,P,S...
      {
	s.GetParameter(k + idx.SPI_rces1 - base).SetValue(century.rces1_ref(i, j));
	s.GetParameter(k + idx.SPI_rcelit - base).SetValue(century.rcelit_ref(i, j));
	++k;
      }
    for ( short i = 0; i < 3; i++ )		// for each in N,P,S...
    {
      s.GetParameter(i + idx.SPI_rces2 - base).SetValue(century.param.rces2[i]);
      s.GetParameter(i + idx.SPI_rces3 - base).SetValue(century.param.rces3[i]);
      s.GetParameter(i + idx.SPI_aglive - base).SetValue(century.nps.aglive[i]);
      s.GetParameter(i + idx.SPI_bglive - base).SetValue(century.nps.bglive[i]);
      s.GetParameter(i + idx.SPI_stdede - base).SetValue(century.nps.stdede[i]);
    }
}

CenturySiteCreatorBase_TEMPLATE
void CenturySiteCreatorBase_DECLARATION::GetForestParts (
	  TSiteParamSet & parameterSet)
{
    TSiteParamSet & s = parameterSet;
    typename century_type::site_params_type::indices_type const & idx =
    	century.GetSite()->indices;
    short const base = idx.SPI_rlvcis;
    for ( short i = 0; i < 2; i++ )        // for unlabeled and labeled...
    {
      s.GetParameter(i + idx.SPI_rlvcis - base).SetValue(century.forestC.rlvcis[i]);
      s.GetParameter(i + idx.SPI_fbrcis - base).SetValue(century.forestC.fbrcis[i]);
      s.GetParameter(i + idx.SPI_rlwcis - base).SetValue(century.forestC.rlwcis[i]);
      s.GetParameter(i + idx.SPI_frtcis - base).SetValue(century.forestC.frtcis[i]);
      s.GetParameter(i + idx.SPI_crtcis - base).SetValue(century.forestC.crtcis[i]);
      s.GetParameter(i + idx.SPI_wd1cis - base).SetValue(century.forestC.wd1cis[i]);
      s.GetParameter(i + idx.SPI_wd2cis - base).SetValue(century.forestC.wd2cis[i]);
      s.GetParameter(i + idx.SPI_wd3cis - base).SetValue(century.forestC.wd3cis[i]);
    }
    for ( short i = 0; i < NUMELEM; i++ )    // for each in N,P,S...
    {
      s.GetParameter(i + idx.SPI_rleave - base).SetValue(century.nps.rleave[i]);
      s.GetParameter(i + idx.SPI_fbrche - base).SetValue(century.nps.fbrche[i]);
      s.GetParameter(i + idx.SPI_rlwode - base).SetValue(century.nps.rlwode[i]);
      s.GetParameter(i + idx.SPI_froote - base).SetValue(century.nps.froote[i]);
      s.GetParameter(i + idx.SPI_croote - base).SetValue(century.nps.croote[i]);
    }
}

CenturySiteCreatorBase_TEMPLATE
void CenturySiteCreatorBase_DECLARATION::GetSoilWater (
	  TSiteParamSet & parameterSet)
{
    TSiteParamSet & s = parameterSet;
    typename century_type::site_params_type::indices_type const & idx =
    	century.GetSite()->indices;
    TCenturySoil const & soil = *century.GetSoil();
    short const numLayers = std::min ((short) soil.GetLayerCount(), MAXLYR);
    short const base = idx.SPI_rwcf;
    for ( short layer = 0; layer < numLayers; ++layer )
	s.GetParameter(layer).SetValue(century.wt.rwcf[layer]);
    s.GetParameter(idx.SPI_snlq - base).SetValue(century.wt.snlq);
    s.GetParameter(idx.SPI_snow - base).SetValue(century.wt.snow);
}

CenturySiteCreatorBase_TEMPLATE
void CenturySiteCreatorBase_DECLARATION::GetLowerHorizonPools (
	  TSiteParamSet & parameterSet)
{
    TSiteParamSet & s = parameterSet;
    typename century_type::site_params_type::indices_type const & idx =
    	century.GetSite()->indices;
    short const base = idx.SPI_lhicu;
    for ( short pool = 0; pool < NUMPOOLS; ++pool )
    {
      s.GetParameter(idx.SPI_lhicu - base + pool).SetValue (
		century.lowerSoil->C(pool, TLowerSoil::UNLABELED) );
      s.GetParameter(idx.SPI_lhicl - base + pool).SetValue (
		century.lowerSoil->C(pool, TLowerSoil::LABELED) );
      s.GetParameter(idx.SPI_lhin - base + pool).SetValue (
		century.lowerSoil->E(pool, TLowerSoil::N) );
      s.GetParameter(idx.SPI_lhip - base + pool).SetValue (
		century.lowerSoil->E(pool, TLowerSoil::P) );
      s.GetParameter(idx.SPI_lhis - base + pool).SetValue (
      		century.lowerSoil->E(pool, TLowerSoil::S) );
    }
}

CenturySiteCreatorBase_TEMPLATE
void CenturySiteCreatorBase_DECLARATION::GetErosionDeposition (
	  TSiteParamSet & parameterSet)
{
    TSiteParamSet & s = parameterSet;
    for ( short pool = 0; pool < EPT_NumPools; ++pool )
    {
      for ( short fraction = 0; fraction < ELF_NumFractions; ++fraction )
      {
	s.GetParameter(pool).SetValue( century.eflCU_ref (pool, fraction) );
	s.GetParameter(10 + pool).SetValue( century.eflCL_ref (pool, fraction) );
	s.GetParameter(20 + pool).SetValue( century.eflN_ref (pool, fraction) );
      }
    }
}


//--- end of file ---

