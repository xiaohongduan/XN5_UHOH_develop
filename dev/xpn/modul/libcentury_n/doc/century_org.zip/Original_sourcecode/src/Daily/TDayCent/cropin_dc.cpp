// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  cropin.cpp
//	Class:	  TCentury
//	Function: GetCrop
//
//	Description:
//	Read the new crop/grassland parameter set.
//	Returns true if successful match in database, else false if not.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jun98
// ----------------------------------------------------------------------------
//	History:
//      See Century/cropin.cpp
//      25Apr01  Melannie Hartman, melannie@NREL.colostate.edu
//      * Added new parameters frtcindx, frtc[3], and kmrsp
//      25May01  Melannie Hartman, melannie@NREL.colostate.edu
//      * Added exception handling for "Value Out of Range" errors
//      Aug01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Changed this function from TCentury to TDayCent member
//      Sep01 Melannie Hartman, melannie@nrel.colostate.edu
//      * Read new parameter parcp.nitrateUptakePref
//      Nov01 Melannie Hartman, melannie@nrel.colostate.edu
//      * Added 2 kmrspMax parameters
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//      Notes:
// ----------------------------------------------------------------------------
#include "TDayCent.h"
#include "TEventDBList.h"
#include "stringutil.h"
#include "constants.h"

bool TDayCent::GetCrop (char const* cropToMatch)
{
	// error checks
	if ( !cropToMatch || !(*cropToMatch) )		// anything there?
		return false;

	char const * const invalidValueStr = "Invalid Value: ";
	float const minFloat = 1.0e-10f;  // minimum acceptable float value
        std::string msg;

	// get the option set
	TEventOptionSet const & optionSet =
		*paramDbList->Get (TEventDBList::DBI_Crop);
	if ( !&optionSet )				// database not there?
		ThrowCentException (TCentException::CE_NSPPDB,
			::eventName[ET_Crop]);
	if ( !optionSet.GetOptionCount () )		// empty database?
		ThrowCentException (TCentException::CE_EMPPDB,
			::eventName[ET_Crop]);

	// get the option matching the parameter string
    	TEventOption const * const option = optionSet.GetOption (cropToMatch);
	if ( !option )					// match found?
		return false;

	// retrieve values from option and save in Century's variables
	//short const numParams = 70;			// total for an option
        //short const numParams = 73;			// total for an option
        //short const numParams = 74;			// total for an option
        short const numParams = 76;			// total for an option
	short count = option->GetParamCount ();
	if ( count != numParams )			// counts match?
                ThrowCentException (TCentException::CE_OPCBAD,
			::eventName[ET_Crop]);

	register short k = 0;			// index to param values
	register short i, j;			// loop indices

	param.prdx[0] = option->GetParameter(k++)->value;
    	for (i = 0; i < 4; ++i)
		ppdf_ref (i, 0) = option->GetParameter(k++)->value;
	parcp.bioflg = (int) option->GetParameter(k++)->value;
	parcp.biok5 = option->GetParameter(k++)->value;
	parcp.pltmrf = option->GetParameter(k++)->value;
	parcp.fulcan = option->GetParameter(k++)->value;

        // Added frtcindx -mdh 4/25/01
        // frtcindx  - (0) Use Great Plains eqn, (1) perrenial plant,
        //  (2) annual plant.  Formerly, frtc[0] had the same definition
        //  as frtcindx.

        parcp.frtcindx = (int)(option->GetParameter(k++)->value);
        if ( parcp.frtcindx < FRTCINDX_MIN || parcp.frtcindx > FRTCINDX_MAX )
	{
		std::stringstream os;
		os << "Crop/grass " << cropToMatch << ": "
		   << invalidValueStr
		   << "FRTCINDX < " << FRTCINDX_MIN
		   << " OR FRTCINDX > " << FRTCINDX_MAX;
 		ThrowDayCentException ( TDayCentException::DCE_VORCRP,
					os.str().c_str() );
	}

        // Added parcp.frtc[3], and redefined parcp.frtc[0]..frtc[2] -mdh 4/25/01
        // frtc[0] - initial (maximum) fraction of C allocated to fine roots
        // frtc[1] - final (minimum) fraction of C allocated to fine roots
        // frtc[2] - months after planting at which final value is reached
        //           (annuals only)
        // frtc[3] - range about frtc[0] (annuals only)

    	//for (i = 0; i < 3; ++i)
        for (i = 0; i < 4; ++i)
		parcp.frtc[i] = option->GetParameter(k++)->value;

        // Added new error checking for frtc[0]..frtc[3]
        //if (parcp.frtc[2] == 0.0f)
	//	parcp.frtc[2] = 1.0f;

	if ( parcp.frtc[0] < 0.0f || parcp.frtc[0] > 1.0f )
        {
            msg = invalidValueStr;
            msg += "FRTC(1) < 0.0 or FRTC(1) > 1.0 for crop ";
            msg += cropToMatch;
            ThrowDayCentException ( TDayCentException::DCE_VORCRP, msg.c_str() );
        }
        if ( parcp.frtc[1] < 0.0f || parcp.frtc[1] > 1.0f )
        {
            msg = invalidValueStr;
            msg += "FRTC(2) <= 0.0 or FRTC(2) > 1.0 for crop ";
            msg += cropToMatch;
            ThrowDayCentException ( TDayCentException::DCE_VORCRP, msg.c_str() );
        }
        if (parcp.frtc[0] < parcp.frtc[1])
        {
            msg = invalidValueStr;
            msg += "FRTC(1) < FRTC(2) for crop ";
            msg += cropToMatch;
            ThrowDayCentException ( TDayCentException::DCE_VORCRP, msg.c_str() );
        }
     if ( parcp.frtcindx == 2 && parcp.frtc[2] <= 0.0f )
        {
            msg = invalidValueStr;
            msg += "FRTC(3) must be > 0 when FRTCINDX == 2 for crop ";
            msg += cropToMatch;
            ThrowDayCentException ( TDayCentException::DCE_VORCRP, msg.c_str() );
        }
        if ( parcp.frtcindx == 2 &&
             (parcp.frtc[3] < -minFloat || parcp.frtc[3] >= 1.0) )
        {
            msg = invalidValueStr;
            msg += "FRTC(4) must be >= 0.0 and < 1.0 when FRTCINDX == 2 for crop ";
            msg += cropToMatch;
            ThrowDayCentException ( TDayCentException::DCE_VORCRP, msg.c_str() );
        }

	parcp.biomax = option->GetParameter(k++)->value;
    	for (i = 0; i < 2; ++i)
    		for (j = 0; j < 3; ++j)
			pramn_ref (j, i) = option->GetParameter(k++)->value;
    	for (i = 0; i < 2; ++i)
    		for (j = 0; j < 3; ++j)
			pramx_ref (j, i) = option->GetParameter(k++)->value;
    	for (i = 0; i < 2; ++i)
    		for (j = 0; j < 3; ++j)
			prbmn_ref (j, i) = option->GetParameter(k++)->value;
    	for (i = 0; i < 2; ++i)
    		for (j = 0; j < 3; ++j)
			prbmx_ref (j, i) = option->GetParameter(k++)->value;
    	for (i = 0; i < 2; ++i)
    		for (j = 0; j < 2; ++j)
			fligni_ref (j, i) = option->GetParameter(k++)->value;
	parcp.himax = option->GetParameter(k++)->value;
	parcp.hiwsf = option->GetParameter(k++)->value;
	parcp.himon[0] = (short) option->GetParameter(k++)->value;
	parcp.himon[1] = (short) option->GetParameter(k++)->value;
    	for (i = 0; i < 3; ++i)
		parcp.efrgrn[i] = option->GetParameter(k++)->value;
	parcp.vlossp = option->GetParameter(k++)->value;
    	for (i = 0; i < 4; ++i)
		parcp.fsdeth[i] = option->GetParameter(k++)->value;
	parcp.fallrt = option->GetParameter(k++)->value;
	parcp.rdr = option->GetParameter(k++)->value;
	parcp.rtdtmp = option->GetParameter(k++)->value;
    	for (i = 0; i < 3; ++i)
            parcp.crprtf[i] = option->GetParameter(k++)->value;
	param.snfxmx[0] = option->GetParameter(k++)->value;
	float del13c = option->GetParameter(k++)->value;
	param.co2ipr[0] = option->GetParameter(k++)->value;
	param.co2itr[0] = option->GetParameter(k++)->value;
    	for (i = 0; i < 2; ++i)
            for (j = 0; j < 3; ++j)
                co2ice_ref (0, i, j) = option->GetParameter(k++)->value;
	param.co2irs[0] = option->GetParameter(k++)->value;

        // Added kmrsp -mdh 4/25/01
	parcp.kmrsp = option->GetParameter(k++)->value;
	// commented out the following so maint. resp. can be turned off
	// To Do: move check into new TSiteVerify class.
	// Tom H., Dec02
	if ( /* parcp.kmrsp < minFloat || */
	     parcp.kmrsp < 0.0f || parcp.kmrsp > 1.0f )
        {
            msg = invalidValueStr;
            msg += "KMRSP < 0.0 or KMRSP > 1.0";
            ThrowDayCentException ( TDayCentException::DCE_VORCRP, msg.c_str() );
        }
        // Added kmrspMax -mdh 11/30/01
        for (i = 0; i < 2; i++)
        {
            parcp.kmrspMax[i] = option->GetParameter(k++)->value;
	    // commented out the following so maint. resp. can be turned off
	    // To Do: move check into new TSiteVerify class.
	    // Tom H., Dec02
	    if ( /* parcp.kmrspMax[i] < minFloat || */
		 parcp.kmrspMax[i] < 0.0f || parcp.kmrspMax[i] > 1.0f )
            {
                msg = invalidValueStr;
                msg += "KMRSPMX < 0.0 or KMRSPMX > 1.0";
                ThrowDayCentException ( TDayCentException::DCE_VORCRP, msg.c_str() );
            }
        }

        // Added nitrateUptakePref -mdh 9/11/01
	parcp.nitrateUptakePref = option->GetParameter(k)->value;
	if ( parcp.nitrateUptakePref < minFloat ||
	     parcp.nitrateUptakePref > 1.0f )
        {
            msg = invalidValueStr;
            msg += "NO3PREF < 0.0 or NO3PREF > 1.0";
            ThrowDayCentException ( TDayCentException::DCE_VORCRP, msg.c_str() );
        }

	// save option name in Century class variable
	strcpy (sched->curCrop, cropToMatch);

    // Determine the 'numerical value' of the curCrop,
    // for use as an output variable
    cropC.crpval = 0.0f;
    for (i = 0; i < 5; ++i)
    {
    	if ( sched->curCrop[i] != ' ' && sched->curCrop[i] != '\0' )
	{
	    if ( sched->curCrop[i] >= '0' && sched->curCrop[i] <= '9' )
		cropC.crpval += (sched->curCrop[i] - '0') * 0.1f;
	    else
		cropC.crpval += sched->curCrop[i] - 'A' + 1;
	}
    }
    PlantLigninFraction ();		// Recalculate lignin

    // Calculate cisofr as 13C if 13C labeling
    if (param.labtyp == Lbl_13C)
    {
	param.cisofr = del13c * PEEDEE * 0.001f + PEEDEE;
	param.cisofr = 1.0f / (1.0f / param.cisofr + 1.0f);
    }

    return true;	// successful match
}	// GetCrop
