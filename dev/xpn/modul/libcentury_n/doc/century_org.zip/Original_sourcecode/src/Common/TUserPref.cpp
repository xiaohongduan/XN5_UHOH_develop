// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TUserPref.cpp
//	Class:	  TUserPref
//
//	Description:
//	Class for information about the user's preferences.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Feb98
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TUserPref.h"
#include "TInitFile.h"
#include "charutil.h"
#include "stringutil.h"
#include <sstream>
#include <cstring>
using namespace std;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

TEH::TFileName const TUserPref::nullFileName;	// empty file name

char const * const TUserPref::defaultIniFileName =   // default .INI file name
	"century.ini";

// std. parameter names for INI file
char const * const TUserPref::paramStdNames[] =
{
	"UserName",		"SiteFilesPath",	"MgmtFilesPath",
	"CurrentWorkPath",	"ProjectPathsCount",	NULL
};
// number of std. parameter names
short const TUserPref::paramStdNamesCount = 5;


// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// 	Is Equal To
bool TUserPref::operator == (TUserPref const & object) const
{
	if ( !(&object) )				// anything there?
		return false;
	bool retVal;						// return flag
	retVal = (userName == object.userName);
	if ( retVal )
		retVal = (numProjPaths == object.numProjPaths);	// paths
	if ( retVal )
		for ( short i = 0; i < numProjPaths; i++ )
		{
			if ( retVal )
				retVal = (projectPaths[i] ==
						  object.projectPaths[i]);
			else
				break;
		}
	if ( retVal )
		retVal = (siteLibPath == object.siteLibPath);
	if ( retVal )
		retVal = (mgmtLibPath == object.mgmtLibPath);
	if ( retVal )
		retVal = (workPath ==  object.workPath);

	return retVal;
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	Clear
//	Clear the filename variables.
void TUserPref::Clear ()
{
	iniFileName.Clear();
	userName.clear ();
	delete [] projectPaths;
	siteLibPath.Clear();
	mgmtLibPath.Clear();
	workPath.Clear();
	Initialize ();
}

//	IsEmpty
// 	Returns true if no prefs.
bool TUserPref::IsEmpty () const
{
	return ( iniFileName.IsEmpty() &&
		 userName.empty() &&
		 numProjPaths == 0 &&
		 siteLibPath.IsEmpty() &&
		 mgmtLibPath.IsEmpty() );
}

//	SetIniFile
//	Returns false if saved else true if not.
bool TUserPref::SetIniFile (
	TEH::TFileName const & newFile)
{
	if ( &newFile )
	{
		iniFileName = newFile;
		// make sure file name has an extension
		if ( iniFileName.GetExtension().empty() )	// empty?
			iniFileName.SetExtension ("ini");	// default
		return false;
	}
	else
		return true;
}

bool TUserPref::SetIniFile (
	char const * const newFile)
{
	if ( newFile && *newFile)
	{
		iniFileName.Clear ();
		iniFileName.Assign (newFile, TEH::TFileName::FT_Normal);
		// make sure file name has an extension
		if ( iniFileName.GetExtension().empty() )	// empty?
			iniFileName.SetExtension ("ini");	// default
		return false;
	}
	else
		return true;
}

//	SetName
//	Change the user name.
void TUserPref::SetName (
	char const * const newName)
{
	if ( newName )
	{
		userName = newName;
		modified = true;
	}
}

//	SetSitesPath
//	Specify path to user's site libs.
bool TUserPref::SetSitesPath (
	TEH::TFileName const & newPath)
{
	siteLibPath = newPath;
	siteLibPath.SetType (TEH::TFileName::FT_Directory);
	modified = true;
	return !siteLibPath.IsValid();
}

bool TUserPref::SetSitesPath (
	char const * const newPath)
{
	TEH::TFileName tmpName (newPath, TEH::TFileName::FT_Directory);
	return SetSitesPath (tmpName);
}

//	SetMgmtPath
//	Specify path to user's mgmt libs.
bool TUserPref::SetMgmtPath (
	TEH::TFileName const & newPath)
{
	mgmtLibPath = newPath;
	mgmtLibPath.SetType (TEH::TFileName::FT_Directory);
	modified = true;
	return !mgmtLibPath.IsValid();
}

bool TUserPref::SetMgmtPath (
	char const * const newPath)
{
	TEH::TFileName tmpName (newPath, TEH::TFileName::FT_Directory);
	return SetMgmtPath (tmpName);
}

//	SetWorkPath
//	set current work path
bool TUserPref::SetWorkPath (
	TEH::TFileName const & newPath)
{
	workPath = newPath;					// get path
	workPath.SetType (TEH::TFileName::FT_Directory);
	if ( !workPath.IsValid() || !workPath.Exists() )	// path ok?
		workPath.Clear ();				// ...no
	modified = true;
	return workPath.IsEmpty();
}

bool TUserPref::SetWorkPath (
	char const * const newPath)
{
	TEH::TFileName tmpName (newPath, TEH::TFileName::FT_Directory);
	return SetWorkPath (tmpName);
}

//	AddProjectPath
//	Add a project path to the list of paths.
//	Returns false if successful, else true if path was not added.
bool TUserPref::AddProjectPath (
	TEH::TFileName const & newPath)
{
	bool retVal = false;

	// error checks
	if ( !(&newPath) )			// anything to add?
		return !retVal;			// no, return true
	if ( CheckDuplicate (newPath) )		// check if duplicated path
		return !retVal;			// yes, return true

	// Add a path by reallocating the list and copying old and new.
	// We'll do this crudely here since there should typically only be
	// a few paths to store (one to a dozen would be expected.)
	if ( numProjPaths > 0 )
	{
		++numProjPaths;					// increment
		// create a new list that is one item larger than the previous
		TEH::TFileName* newList = new TEH::TFileName [numProjPaths];
		for ( short i = 0; i < numProjPaths; i++ )	// init. items
			newList[i].Clear ();
		// copy old list
		for ( short i = 0; i < numProjPaths - 1; i++ )
			newList[i] = projectPaths[i];
		// save new path
		newList[numProjPaths - 1] = newPath;
		// save new list in the member variable
		delete [] projectPaths;
		projectPaths = newList;
	}
	else	// first path to add, so no reallocation needed
	{
		projectPaths = new TEH::TFileName [1];
		numProjPaths = 1;
		*projectPaths = newPath;
	}
	modified = true;
	return retVal;
}

bool TUserPref::AddProjectPath (
	char const * const newPath)
{
	TEH::TFileName tmpName (newPath, TEH::TFileName::FT_Directory);
	return AddProjectPath (tmpName);
}


//	DelProjectPath
//	Removes a path from the projectPath list.
//	Returns the new count of paths in the list.
short TUserPref::DelProjectPath ( short which )
{
	if ( which >= 0 && which < numProjPaths )
	{
		// Use the reallocation method, for the reasons described
		// under "AddProjectPath".
		// create a new list that is one item smaller than the previous
		TEH::TFileName* newList = new TEH::TFileName [numProjPaths - 1];
		short j = 0;			// index to new list
		for ( short i = 0; i < numProjPaths; i++ )	// copy list
			if ( i != which )
				newList[j++] = projectPaths[i];
		// save new list in the member variable
		delete [] projectPaths;
		projectPaths = newList;
		--numProjPaths;					// decrement
		modified = true;
	}
	return numProjPaths;
}

//	GetParamNameList
//	Build a null-terminated list of parameters for INI file.
//	The calling function owns the returned pointer to the list.
//	List looks like:
//		UserName
//		SiteFilesPath
//		MgmtFilesPath
//		CurrentWorkPath
//		ProjectPathsCount
//		ProjectPath0
//		ProjectPath1
char** TUserPref::GetParamNameList (
	short & count)		// returns number of items in the list
{
	// count number of items in the list
	short const listLen = paramStdNamesCount + numProjPaths;

	// memory for the list
	char** nameList = new char* [listLen + 1];	// allocate pointers
	nameList[listLen] = 0;				// terminate w/NULL

	// add standard parameter names
	for ( short i = 0; i < paramStdNamesCount; i++ )
	{
		nameList[i] = new char [strlen(paramStdNames[i]) + 1];
		strcpy ( nameList[i], paramStdNames[i] );
	}

	// add parameters of form "ProjectPath0", "ProjectPath1", etc.
	std::ostringstream ss;
	for ( int i = paramStdNamesCount; i < listLen; i++ )
	{
		ss.seekp (0, ios::beg);
		ss << "ProjectPath" << (i - (listLen - numProjPaths)) << ends;
		nameList[i] = new char [ss.str().length() + 1];
		strcpy ( nameList[i], ss.str().c_str() );
	}

	// all done!
	count = listLen;	// return the number of items in the list
	return nameList;	// and the parameter string list
}

//	ReadIniFile
//	Reads the initialization file currently named in the member "inifile".
//	Returns false if successful, else true if not.
bool TUserPref::ReadIniFile ()
{
	// read the contents of the INI file
	TInitFile iniFile (iniFileName);
	short count = iniFile.Read ();			// read it
	if ( !count )					// anything there?
	{
		// TO DO: need error handling here
		return true; 				// ...no
	}

	// erase current preferences
	Clear ();				// delete current lists
	iniFileName = iniFile.GetFile ();	// restore file name

	// get the lists of parameter names and values
	char** const valueList = iniFile.GetValueList ();
	char** const nameList = const_cast<char**>( iniFile.GetNameList () );

	// retrieve valid data from the values list
	TEH::TFileName path;
	for ( short i = 0; i < count; i++ )		// each nameList item
	{
	    register char* paramName = nameList[i];	// next parameter name
	    if ( !paramName || !(*paramName) )		// anything there?
	    	continue;				// ...no
	    // look for project path
	    if ( strstr (paramName, "ProjectPath") &&
		 !strstr (paramName, "ProjectPathsCount") )	// match?
	    {
		path.Assign (valueList[i], TEH::TFileName::FT_Directory);
		AddProjectPath (path);
		continue;
	    }
	    // look for standard parameters
	    for ( short j = 0; j < paramStdNamesCount - 1; j++)	// find match
	    {
		if ( !strcmp( paramName, paramStdNames[j] ) )  // match?
		{
		    if ( j == 0 )			// user name
			SetName (valueList[i]);
		    else if ( j == 1 )			// site files path
		    {
			path.Assign (
				valueList[i], TEH::TFileName::FT_Directory);
			SetSitesPath (path);
		    }
		    else if ( j == 2 )			// mgmt. files path
		    {
			path.Assign (
				valueList[i], TEH::TFileName::FT_Directory);
			SetMgmtPath (path);
		    }
		    else if ( j == 3 )			// current work path
		    {
			path.Assign (
				valueList[i], TEH::TFileName::FT_Directory);
			SetWorkPath (path);
		    }
		    // ignore the project path count
		    break;
		}
	    }
	}

	// all done!
	modified = false;
	return false;
}

//	WriteIniFile
//	Writes the initialization file currently named in the member "inifile".
//	Returns false if successful, else true if not.
bool TUserPref::WriteIniFile ()
{
	bool retVal = false;			// return value

	// get the parameter name list
	short count = 0;
	char** nameList = GetParamNameList (count);	// pointer owned here

	// create a list of the values
	char** valueList = new char* [count + 1];	// memory for list
	valueList[count] = 0;				// null-terminate
	std::string str;
	for ( short i = 0; i < count; i++ )
	{
		str.clear ();
		switch (i)
		{
		  case 0:				// user name
			str = userName;
			break;
		  case 1:				// site files path
		  {
			std::string const path = GetSitesPath().GetFullPath ();
			if ( !path.empty() )
				str = path;
			break;
		  }
		  case 2:				// mgmt. files path
		  {
			std::string const path = GetMgmtPath().GetFullPath ();
			if ( !path.empty() )
				str = path;
			break;
		  }
		  case 3:				// current work path
		  {
			std::string const path = GetWorkPath().GetFullPath ();
			if ( !path.empty() )
				str = path;
			break;
		  }
		  case 4:			// project path list count
		  {
			str = ::ToString<short> ( GetProjPathCount() );
			break;
		  }
		  default:
		  {
			std::string const path =
				GetProjectPath(i-5).GetFullPath ();
			if ( !path.empty() )
				str = path;
			break;
		  }
		}
		if ( !str.empty() )
		{
			valueList[i] = new char	[str.length() + 1];
			strcpy ( valueList[i], str.c_str() );
		}
		else
		{
			valueList[i] = new char	[1];
			*valueList[i] = '\0';
		}
	}
	// write the file
	TInitFile iniFile (iniFileName, nameList, valueList);
	if ( iniFile.Write () )				// write INI file fail?
	{
		// To Do: need error handling here
		retVal = true;				// ...yes
	}
	else
		modified = false;			// ...no

	// all done!
	::DeleteNTCStringList (nameList);		// allocated here, so delete
	::DeleteNTCStringList (valueList);		// allocated here, so delete
	return retVal;
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Initialize
void TUserPref::Initialize ()
{
	projectPaths = 0;
	numProjPaths = 0;
	modified = false;
}

//	Copy
//	Copy member data to this.
void TUserPref::Copy (const TUserPref &object)
{
	// check for errors
	if ( &object )
	{
		iniFileName = object.iniFileName;
		userName = object.userName;
		// copy list of project paths
		numProjPaths = object.numProjPaths;
		if ( numProjPaths > 0 )
		{
			projectPaths = new TEH::TFileName [numProjPaths];
			for ( short i = 0; i < numProjPaths; i++ )
			{
				projectPaths[i].Clear ();
				projectPaths[i] = object.projectPaths[i];
			}
		}
		// copy remaining paths
		siteLibPath = object.siteLibPath;
		mgmtLibPath = object.mgmtLibPath;
		workPath =  object.workPath;
		// flags
		modified = object.modified;
	}
}

//	CheckDuplicate
//	Returns true if path is already in list, else false if not.
bool TUserPref::CheckDuplicate (TEH::TFileName const & newPath)
{
	bool retVal = false;
	std::string const str1 = newPath.GetFullPath();
	for (short i = 0; i < numProjPaths && !retVal; i++)
	{
		std::string const str2 = projectPaths[i].GetFullPath ();
		retVal = ( str1 == str2 );			// match?
	}
	return retVal;
}

//--- end of definitions for TUserPref ---

