// ----------------------------------------------------------------------------
//	Copyright 1997 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TCmdWinBaseMenuFile.cpp
//	Class:	  TCmdWinBase
//	Function: DoMenuEvent_File
//
//	Description:
//	Processes selection events from the File Drop-Down Menu
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Dec97
//	History:
//	Nov01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added Century4 site, mgmt. file extentions to filters.
// ----------------------------------------------------------------------------

#include "TCmdWinBase.h"
#include "externals.h"
#include "TFileSelDlg.h"
#include <v/vnotice.h>
#include <v/vynreply.h>
#include <v/vutil.h>
#include <v/vprinter.h>
#include <cstring>

void TCmdWinBase::DoMenuEvent_File (ItemVal itemId)
{
	vNoticeDialog msgDlg ( (vApp*)&myApp );	// instance of
	static short const pathLength = 257;
	char fileName[pathLength];		// current problem file name
	memset (fileName, '\0', pathLength);

	switch (itemId)
	{
	  case M_New:		// not currently used
		break;

	  case M_Open:
	    {
	    	/*
	    	   Add the following in after the model parameter editor is
	    	   completed (remove the comma before the NULL prior to
	    	   adding these):
			"Model Parameter Files|*.nc|",
			"Century 4 Parameter Files|*.100|",
		*/
		char const* filter[] =
		{
			"Initialization|*.ini|"		// case 0
			"Site Parameters|*-ST.nc|"	// case 1
			"Management Schemes|*-S.nc|"	// case 2
			"Century 4 Sites|*.100|"	// case 3
			"Century 4 Schedules|*.sch|",	// case 4
			NULL
		};
		int filterIdx = 0;			// filter index
		TFileSelectDlg fileOpenDlg (this);	// instance of

		ActionMsg ("Selecting file");
		std::string const initPath =
			::userPref.GetWorkPath().GetFullPath();
		int result = fileOpenDlg.FileSelect ("Open File",
					(char *)fileName, pathLength - 1,
					filter, filterIdx, initPath.c_str() );
		if (result && *fileName)
		{
			ActionMsg ("Opening file");
			switch ( filterIdx )
			{
			  case 0:		// initialization files
			  {
				TEH::TFileName iniFile (fileName);
				::userPref.SetIniFile (iniFile);	// save
				::userPref.ReadIniFile ();		// read
				break;
			  }
			  case 1:		// site parameters
			  case 3:		// Century 4 site parameters
				((TCMIApp*)(app))->ReadSite (fileName);
				break;
			  case 2:		// management schemes
			  case 4:		// Century 4 schedule files
				((TCMIApp*)(app))->ReadMgmt (fileName);
				break;
			  case 5:		// model parameters
			  case 6:		// Century 4 Parameter files
				break;
			  default:
				break;
			}
		}
		else
		{
			msgDlg.Notice ("No file opened.\n"
					"You did not select a file name.");
		}
		break;
	    }

	  case M_Close:				// close a parameter set/mgmt.
		ActionMsg ("Closing file");
		// 1. build a list of things that can be closed
		// 2. allow user to select from list
		// 3. close the selected item
		break;

	  case M_Print:
		ActionMsg ("Printing");
		break;

	  case M_PrintSetup:
	    {
		ActionMsg ("Printer setup");
		vPrinter printDlg;
		int result = printDlg.Setup (NULL);
		if (!result)
		{
			msgDlg.Notice ("Printer setup was not completed.");
		}
		break;
	    }

	  case M_Exit:
		((TCMIApp*)(app))->Exit();
		break;

	  default:
		break;
	}
	if ( itemId != M_Exit )
		ActionMsg ("Idle");
}

//--- end of file ---

