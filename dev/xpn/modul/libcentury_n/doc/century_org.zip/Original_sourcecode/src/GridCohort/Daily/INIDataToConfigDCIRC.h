#ifndef INC_nrel_dcirc_INIDataToConfigDCIRC_h
#define INC_nrel_dcirc_INIDataToConfigDCIRC_h
// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  INIDataToConfigDCIRC.h
//	Class:	  INIDataToConfigDCIRC
//
//	Description:
//	Class for transferring INI data to Configuration objects for the
//	DayCentIRC model.
//
//	Responsibilities:
//	* Provides private functions to transfer data from an
//	  INI object to a configuration object.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski (tom.hilinski@colostate.edu) Feb 2005
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "INIDataToConfigGCF.h"
#include "TINIDataDCIRC.h"
#include "TDayCentIRCConfig.h"

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class INIDataToConfigDCIRC
	: public ::nrel::gcf::INIDataToConfigGCF
{
  public:
	//---- types

	//---- constructors and destructor
	INIDataToConfigDCIRC (
	  TINIDataDCIRC const & useIniData,
	  TDayCentIRCConfig & useConfig)
	  : ::nrel::gcf::INIDataToConfigGCF (useIniData, useConfig)
	  {
	    if ( ToConfig() )	// failed?
	    {
	    	transferFailed = true;
		// To Do: handle transfer error
	    }
	  }
	INIDataToConfigDCIRC (
	  INIDataToConfigDCIRC const & object)
	  : ::nrel::gcf::INIDataToConfigGCF (object)
	  {
	  }
	virtual ~INIDataToConfigDCIRC ()
	  {
	  }

	//---- operator overloads

	//---- functions

  protected:
	//---- constants

	//---- data

	//---- functions

  private:
	//---- types

	//---- constants

	//---- data

	//---- functions
	virtual bool DoToConfig ();	// Transfer INI data to Config data
};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_INIDataToConfigDCIRC_h





