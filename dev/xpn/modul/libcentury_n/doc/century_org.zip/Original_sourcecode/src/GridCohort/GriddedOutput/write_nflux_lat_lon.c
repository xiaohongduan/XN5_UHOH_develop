
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Rewrite the nflux.nc netCDF file using COARDS standards */
/* The original file was organized variable(cell, time) */
/*                                 variable(cell, layer, time */
/* The new file is organized variable(time, lat, lon) */
/*                           variable(time, layer, lat, lon) */

#include <stdio.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf_ll.h"

    int write_nflux_ll_(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      /* INDX is dimensioned {CELL, TIME} */
      size_t indx[2]  = {0, 0};
      /* START_LAYER and COUNT_LAYER are dimensioned {TIME, LAYER, LAT, LON} */
      size_t start_layer[4] = {0, 0, 0, 0};
      size_t count_layer[4] = {0, 0, 0, 0};
      /* INDX_LAYER is dimensioned {CELL, LAYER, TIME} */
      size_t indx_layer[3]  = {0, 0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  minerl1_vals[MAXCELLS], minerl2_vals[MAXCELLS], minerl3_vals[MAXCELLS],
             minerl4_vals[MAXCELLS], minerl5_vals[MAXCELLS], minerl6_vals[MAXCELLS],
             minerl7_vals[MAXCELLS], minerl8_vals[MAXCELLS], minerl9_vals[MAXCELLS],
             minerl10_vals[MAXCELLS], nfix_vals[MAXCELLS], volex_vals[MAXCELLS],
             volgm_vals[MAXCELLS], volpl_vals[MAXCELLS], wdfxma_vals[MAXCELLS],
             wdfxms_vals[MAXCELLS];
      int status;
      int oldnfluxid;
      int oldminerlid, oldnfixid, oldvolexid, oldvolgmid, oldvolplid,
          oldwdfxmaid, oldwdfxmsid;
      int ii, jj, kk, ngrids;

      /* Open old version of nflux.nc file */
      status = nc_open("nflux.nc", NC_NOWRITE, &oldnfluxid);
      if (status != NC_NOERR) handle_error("nc_open(nflux.nc)", status);

      /* Get the indices for the nflux output variables */
      status = nc_inq_varid(oldnfluxid, "minerl", &oldminerlid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for minerl",status);
      status = nc_inq_varid(oldnfluxid, "nfix", &oldnfixid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for nfix",status);
      status = nc_inq_varid(oldnfluxid, "volex", &oldvolexid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for volex",status);
      status = nc_inq_varid(oldnfluxid, "volgm", &oldvolgmid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for volgm",status);
      status = nc_inq_varid(oldnfluxid, "volpl", &oldvolplid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for volpl",status);
      status = nc_inq_varid(oldnfluxid, "wdfxma", &oldwdfxmaid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wdfxma",status);
      status = nc_inq_varid(oldnfluxid, "wdfxms", &oldwdfxmsid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wdfxms",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        minerl1_vals[ii] = fill;
        minerl2_vals[ii] = fill;
        minerl3_vals[ii] = fill;
        minerl4_vals[ii] = fill;
        minerl5_vals[ii] = fill;
        minerl6_vals[ii] = fill;
        minerl7_vals[ii] = fill;
        minerl8_vals[ii] = fill;
        minerl9_vals[ii] = fill;
        minerl10_vals[ii] = fill;
        nfix_vals[ii] = fill;
        volex_vals[ii] = fill;
        volgm_vals[ii] = fill;
        volpl_vals[ii] = fill;
        wdfxma_vals[ii] = fill;
        wdfxms_vals[ii] = fill;
      }

      ngrids = 0;
      indx[0] = 0;
      indx[1] = 0;
      start[0] = 0;
      start[1] = 0;
      start[2] = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx_layer[0] = 0;
      indx_layer[1] = 0;
      indx_layer[2] = 0;
      start_layer[0] = 0;
      start_layer[1] = 0;
      start_layer[2] = 0;
      start_layer[3] = 0;
      count_layer[0] = 1;
      count_layer[1] = 1;
      count_layer[2] = *nlat;
      count_layer[3] = *nlon;
      /* Re-write the nflux output file */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            indx_layer[1] = 0;
            status = nc_get_var1_float(oldnfluxid, oldminerlid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for minerl1",status);
            }
            minerl1_vals[jj] = val;
            indx_layer[1] = 1;
            status = nc_get_var1_float(oldnfluxid, oldminerlid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for minerl2",status);
            }
            minerl2_vals[jj] = val;
            indx_layer[1] = 2;
            status = nc_get_var1_float(oldnfluxid, oldminerlid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for minerl3",status);
            }
            minerl3_vals[jj] = val;
            indx_layer[1] = 3;
            status = nc_get_var1_float(oldnfluxid, oldminerlid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for minerl4",status);
            }
            minerl4_vals[jj] = val;
            indx_layer[1] = 4;
            status = nc_get_var1_float(oldnfluxid, oldminerlid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for minerl5",status);
            }
            minerl5_vals[jj] = val;
            indx_layer[1] = 5;
            status = nc_get_var1_float(oldnfluxid, oldminerlid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for minerl6",status);
            }
            minerl6_vals[jj] = val;
            indx_layer[1] = 6;
            status = nc_get_var1_float(oldnfluxid, oldminerlid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for minerl7",status);
            }
            minerl7_vals[jj] = val;
            indx_layer[1] = 7;
            status = nc_get_var1_float(oldnfluxid, oldminerlid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for minerl8",status);
            }
            minerl8_vals[jj] = val;
            indx_layer[1] = 8;
            status = nc_get_var1_float(oldnfluxid, oldminerlid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for minerl9",status);
            }
            minerl9_vals[jj] = val;
            indx_layer[1] = 9;
            status = nc_get_var1_float(oldnfluxid, oldminerlid, indx_layer, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for minerl10",status);
            }
            minerl10_vals[jj] = val;
            status = nc_get_var1_float(oldnfluxid, oldnfixid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for nfix",status);
            }
            nfix_vals[jj] = val;
            status = nc_get_var1_float(oldnfluxid, oldvolexid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for volex",status);
            }
            volex_vals[jj] = val;
            status = nc_get_var1_float(oldnfluxid, oldvolgmid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for volgm",status);
            }
            volgm_vals[jj] = val;
            status = nc_get_var1_float(oldnfluxid, oldvolplid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for volpl",status);
            }
            volpl_vals[jj] = val;
            status = nc_get_var1_float(oldnfluxid, oldwdfxmaid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wdfxma",status);
            }
            wdfxma_vals[jj] = val;
            status = nc_get_var1_float(oldnfluxid, oldwdfxmsid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wdfxms",status);
            }
            wdfxms_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
            indx_layer[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        indx_layer[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        start_layer[1] = 0;
        status = nc_put_vara_float(nfluxll_ncid, minerlll_id, start_layer, count_layer, minerl1_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for minerl1",status);
        start_layer[1] = 1;
        status = nc_put_vara_float(nfluxll_ncid, minerlll_id, start_layer, count_layer, minerl2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for minerl2",status);
        start_layer[1] = 2;
        status = nc_put_vara_float(nfluxll_ncid, minerlll_id, start_layer, count_layer, minerl3_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for minerl3",status);
        start_layer[1] = 3;
        status = nc_put_vara_float(nfluxll_ncid, minerlll_id, start_layer, count_layer, minerl4_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for minerl4",status);
        start_layer[1] = 4;
        status = nc_put_vara_float(nfluxll_ncid, minerlll_id, start_layer, count_layer, minerl5_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for minerl5",status);
        start_layer[1] = 5;
        status = nc_put_vara_float(nfluxll_ncid, minerlll_id, start_layer, count_layer, minerl6_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for minerl6",status);
        start_layer[1] = 6;
        status = nc_put_vara_float(nfluxll_ncid, minerlll_id, start_layer, count_layer, minerl7_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for minerl7",status);
        start_layer[1] = 7;
        status = nc_put_vara_float(nfluxll_ncid, minerlll_id, start_layer, count_layer, minerl8_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for minerl8",status);
        start_layer[1] = 8;
        status = nc_put_vara_float(nfluxll_ncid, minerlll_id, start_layer, count_layer, minerl9_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for minerl9",status);
        start_layer[1] = 9;
        status = nc_put_vara_float(nfluxll_ncid, minerlll_id, start_layer, count_layer, minerl10_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for minerl10",status);
        status = nc_put_vara_float(nfluxll_ncid, nfixll_id, start, count, nfix_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for nfix",status);
        status = nc_put_vara_float(nfluxll_ncid, volexll_id, start, count, volex_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for volex",status);
        status = nc_put_vara_float(nfluxll_ncid, volgmll_id, start, count, volgm_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for volgm",status);
        status = nc_put_vara_float(nfluxll_ncid, volplll_id, start, count, volpl_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for volpl",status);
        status = nc_put_vara_float(nfluxll_ncid, wdfxmall_id, start, count, wdfxma_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wdfxma",status);
        status = nc_put_vara_float(nfluxll_ncid, wdfxmsll_id, start, count, wdfxms_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wdfxms",status);
        /* Increment the time index */
        start[0]++;
        start_layer[0]++;
        indx[1]++;
        indx_layer[2]++;
      } 

      /* Close the old output file */
      nc_close(oldnfluxid);

      return 0;
    }
