#ifndef INC_nrel_dcirc_CmdLine_h
#define INC_nrel_dcirc_CmdLine_h
// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  CmdLine.h
//	Class:	  CmdLine
//
//	Description:
//	Interface class for the IRC adaptor to the DayCent model.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, March 2005
//	History:
//	* Replaces the original class TDayCentIRCCmdLine.
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------
//	To Do:
//	(1) Add debug options.
//	(2) Make class a singleton.
// ----------------------------------------------------------------------------

#include "About.h"

namespace nrel
{

  namespace dcirc	// DayCentIRC
  {

class CmdLine
{
  public:
	//--- constructors and destructor
	CmdLine (
	  int const newArgc, 				// number of arguments
	  char const * const * const newArgv,		// list of arguments
	  void (*useMsgFunction)(char const * const),	// message function
	  bool const suppressWarnings = false);	// suppress warning messages?
	~CmdLine ()
	  {
	  }

	//--- functions
	short GetNumberOfArgsUsed () const
	  { return numArgsUsed; }
	bool HaveError () const			// true if have an error
	  { return error; }
	bool Terminate () const			// true if should terminate
	  { return terminate; }

	//--- functions: Queries
	short const NumberOfArgs () const
	  { return origArgc; }
	char const * const * const ArgList () const
	  { return origArgv; }
	std::string const & GetINIFileName () const
	  { return iniFile; }

  protected:
	//--- constants
	static std::string const helpMsg;	// user help text
	About about;
	static std::string const options[];	// options list
	static std::string const altOptions[];	// alternate options list
	enum TIndexOptionList	// indices into options string arrays
	{
	  Iini_file,
	  Iversion,
	  Icopyright,
	  Isupport,
	  Idisclaimer,
	  Idcl,
	  Ihelp,
	  ILastOneAlways	// last one always!
	};


	//--- const data
	short const origArgc;			// original argc (unmodified)
	char const * const * const origArgv;	// original argv (unmodified)
	void (*msgFunction)(char const * const); // Function displays message
	bool const displayWarnings;		// true if displaying messages

	//--- data
	short numArgsUsed;		// number of arguments in argv used
	bool error;			// for external use: true if have
					//   an error in argument list.
	bool terminate;			// true if program should terminate

	//--- data from command-line parameters
	std::string iniFile;			// INI file name

	//--- functions
	std::string const & GetCmdLineHelpStr ()	// Help text string
	  { return helpMsg; }
	void DisplayCommandLine ();			// Echo cmd. line
	bool ProcessCmdLineArgs ();			// Process options
	bool HaveOption (
	  TIndexOptionList const index,
	  std::string const & argStr);

  private:
	//--- data

	//--- functions

};

  } // namespace dcirc

} // namespace nrel

#endif // INC_nrel_dcirc_CmdLine_h
