// ----------------------------------------------------------------------------
//    Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model, daily version
//	File:	denitrify.cpp
//	Class:	TDayCentSoil
//	Function: Denitrify
//
//	Description:
//	Denitrification:	Calculate N2 and N2O gases flux, reduce
//	soil nitrate by amount of total nitrogen gas flux.
//	Total Nitrogen losses during denitrification are controlled by soil
//	water content, available soil Carbon, and soil nitrate (NO3-).
//	The fraction of Nitrogen losses as N2 or N2O are controlled by soil
//	water content and soil nitrate (NO3-).
// ----------------------------------------------------------------------------
//	Author: Melannie Hartman, Bill Parton, Cindy Keough, Steve DelGrosso
//	History:
//	??????  Melannie Hartman, melannie@NREL.colostate.edu
//	* Created original denitrify.c for FORTRAN/C version of DayCent
//	Apr2001	 Melannie Hartman, melannie@NREL.colostate.edu
//	* Translated denitrify.c to denitrify.cpp
//	Aug2002	 Melannie Hartman, melannie@NREL.colostate.edu
//	* The co2_correction was calculated but not used - add in proper usage.
//	  See remarks noted by "cak - 07/31/02".
//	* changed name of co2_correction to co2PPM_correction.
//	* clean up code and comments a bit
//	Nov02   Tom Hilinski, tom.hilinski@colostate.edu
//	* Misc. clean up, const-correctness, optimization.
//	Dec02   Tom Hilinski, tom.hilinski@colostate.edu
//	* Convert to use arraytypes.h for arrays
//	May03	Tom Hilinski
//	* Additional assertions and some minor cleanup.
//	* Uses the actual bulk density and field capacity of the soil,
//	  specified in the site parameters, rather than the values estimated
//	  from soil texture.
//	  (Removed function args stdFieldCap, stdBulkDen)
// ----------------------------------------------------------------------------
//	Notes:
//	* fDwfps is negative sometimes  -mdh 4/22/01
//	* Eventually remove type "double" declarations in favor of
//	  casting when necessary -mdh 4/25/01
// ----------------------------------------------------------------------------

#include "TDayCentSoil.h"
#include "TDayCent.h"
#include "pi_funcs.h"
using namespace std;

void TDayCentSoil::Denitrify (
    float const simDepth,	// simulation depth (cm)
    T1DFloatArray const & co2PPM, // soil CO2 concentration by lyr (ppm)
    T1DDoubleArray & nitrate,	// nitrate content by layer (gN/m^2)
    double & fluxN2Odenit,	// N2O flux from denitrification (gN/m2/day)
    double & fluxN2denit)	// N2 flux from denitrification (gN/m2/day)
{
    // initialize arguments
    fluxN2Odenit = 0.0;      // gN/m^2/day
    fluxN2denit = 0.0;

    // constants
    float const ug_per_gram = 1.0E6f;		// micrograms per gram (ppm)
    float const grams_per_ug = 1.0E-6f;		// grams per microgram
    float const cm2m2 = 100000.0f;		// cm^2 per m^2

    // min. nitrate concentration required in a lyr for trace gas calc. (ppm N)
    double const minNitratePPM = 0.1;
    // min. allowable nitrate per lyr at end of day (ppm N)
    double const minNitratePPM_final = 0.05;
    // Assert (minNitratePPM_final <= minNitratePPM);

    // grams of soil in a layer in a 1m x 1m section
    // T1DDoubleArray grams_soil (GetLayerCount());
    if ( grams_soil.size() != GetLayerCount() )
    	grams_soil.resize ( GetLayerCount() );
    for (short layer = 0; layer < GetLayerCount(); layer++)
	grams_soil(layer) = BulkDensity(layer) * thickness[layer] * cm2m2;

    // soil nitrate (NO3-) concentration (ppm)
    // T1DDoubleArray nitratePPM (GetLayerCount());
    if ( nitratePPM.size() != GetLayerCount() )
    	nitratePPM.resize ( GetLayerCount() );
    nitratePPM = nitrate / grams_soil * ug_per_gram;

    // soil (N2+N2O) denitrif. flux by lyr ( gN/m^2 or ppm N/day ?)
    // T1DDoubleArray fluxNTotal (GetLayerCount());
    if ( fluxNTotal.size() != GetLayerCount() )
    	fluxNTotal.resize ( GetLayerCount() );
    fluxNTotal = 0.0;

    // debug
//    Assert (co2PPM.size() == depth.size());
//    Assert (nitrate.size() == depth.size());
//    Assert (grams_soil.size() == depth.size());
//    Assert (nitratePPM.size() == depth.size());
//    Assert (fluxNTotal.size() == depth.size());
//    Assert (FieldCapacity().Size() == depth.size());

    double const initialTotalN = ARRAY_SUM (nitrate);

    // denitrification loop
    //  Dentrification occurs over all layers
    //  Convert nitrate (gN/m2) to nitratePPM (ppm N)
    for (short layer = 0; layer < GetLayerCount(); layer++)
    {
	if (nitratePPM(layer) < minNitratePPM)
	{
	    // To Do: consider warning here
	    // "CANNOT DENITRIFY: Nitrate(" << layer << ") = "
	    // << nitrate(layer) << endl;
	    continue;
	}

	// normalized diffusivity in aggregate soil
	//   media, at a standard field capacity (0-1)
	//dD0_fc = diffusiv(&stdfieldc, &stdbulkd, &wfps_fc);
	//dD0 calc changed 6/20/00 -mdh
	// water filled pore space at field capacity (0-1)
	float const porosity = 1.0f - BulkDensity(layer) / PARTDENS;
	float wfps_fc = FieldCapacity(layer) / porosity;
	wfps_fc = std::max ( 0.0f, wfps_fc );
	wfps_fc = std::min ( wfps_fc, 1.0f );
	float const dD0_fc =
		Diffusivity (FieldCapacity(layer), BulkDensity(layer),
				porosity, wfps_fc);

	// water filled pore space threshold (0-1)
	float const WFPS_threshold =
		(dD0_fc >= 0.15f) ? 0.80f : (dD0_fc * 250.0f + 43.0f) / 100.0f;
	Assert ((WFPS_threshold > 0.0f) && (WFPS_threshold < 1.0f));
	float const layerWFPS = WFPS (layer);

	// CO2 correction factor when WFPS has reached threshold
	Assert (co2PPM(layer) > 0.0f);
	double co2PPM_correction;
	if (layerWFPS <= WFPS_threshold)
	    co2PPM_correction = co2PPM(layer);
	else
	{
	    float const a =
		(dD0_fc >= 0.15f) ? 0.004f : (-0.1f * dD0_fc + 0.019f);
	    co2PPM_correction = co2PPM(layer)
		* (1.0f + a * (layerWFPS - WFPS_threshold) * 100.0f);
	}
	Assert (co2PPM_correction >= 0.0f);

	// Nitrate effect on denitrification
	// denitrification flux due to soil nitrate (ppm N/day)
	// Changed NO3 effect on denitrification based on
	// paper Del Grosso et. al, GBC, in press.  -mdh 5/16/00
	// fDno3 = 1.15 * std::pow(nitratePPM(layer), 0.57);
	double const A[4] =	        // parameters to parton-innis functions
		{ 9.23f, 1.556f, 76.91f, 0.00222f };
	double const fDno3 =
		std::max ( 0.0, f_arctangent (nitratePPM(layer), A) );

	//  Carbon Dioxide effect on denitrification (fDco2, ppm N)
	//  Changed CO2 effect on denitrification based on
	//  paper Del Grosso et. al, GBC, in press.  -mdh 5/16/00
	// fDco2 = 0.1 * std::pow(co2_conc[layer], 1.3);
	// The CO2 effect calculation should take into account the
	// corrected CO2 concentration, cak - 07/31/02
	// fDco2 = std::max(0.0,
	//	((0.1 * std::pow(co2PPM(layer), 1.3f)) - minNitratePPM));
	// denitrification flux due to CO2 concentration (ppm N/day)
	double const fDco2 = std::max(
		0.0,
		(0.1 * std::pow(co2PPM_correction, 1.3) - minNitratePPM) );

	// wfps effect on denitrification (fDwfps, 0-1?)
	// Changed wfps effect on denitrification based on
	// paper Del Grosso et. al, GBC, in press.  -mdh 5/16/00
	// The x_inflection calculation should take into account the
	// corrected CO2 concentration, cak - 07/31/02
	// double x_inflection = 9.0 - M;
	double const M = std::min(0.113f, dD0_fc) * (-1.25) + 0.145;
	double const x_inflection = 9.0 - M * co2PPM_correction;
	//  Changed fDwfps calculation -CAK 9/18/00
	// fDwfps = 0.5 +
	//	(atan(0.6*M_PI*(0.1*WFPS(layer)*100 - x_inflection)))/M_PI;
	// effect of wfps on denitrification (0-1).
	double const fDwfps = std::max ( 0.0,
		0.45 +
		(atan(0.6 * M_PI * (10.0 * layerWFPS - x_inflection))) / M_PI);

	//  N fluxes (N2 + N2O) for the current layer, ppm N
	double fluxTotalDenitPPM = // total (N2+N2O) denitrif. flux (ppm N/day)
		(fDno3 < fDco2) ? fDno3 : fDco2;
	Assert (fluxTotalDenitPPM >= 0.0);

	// Minimum value for potential denitrification in simulation layers.
	// -CAK 9/18/00
	// Changed to use simulation depth - Tom Hilinski Nov02
	// To Do: consider - adjust constant 0.066 for change in sim. depth?
	// if (layer < 2)
	if ( layer <= GetLayerIndex(simDepth) )
	    fluxTotalDenitPPM = std::max (0.066, fluxTotalDenitPPM);
	fluxTotalDenitPPM *= fDwfps;

	//  Nitrate effect on the ratio of N2 to N2O
	//  Maximum N2/N2O ratio soil respiration function
	//  Changed the NO3 and CO2 effect on the N2/N2O ratio based on
	//  paper Del Grosso et. al, GBC, in press.  -mdh 5/16/00
	//  Replace fRno3 and fRco2 with fRno3_co2
	//  fRno3_co2 estimates the ratio as a function of electron
	//  donor to substrate -mdh 5/17/00
	double const k1 = std::max (1.5, 38.4 - 350 * dD0_fc);
	Assert (k1 >= 0.0);
	double const fRno3_co2 = std::max (
		0.16 * k1,
		k1 * std::exp(-0.8 * nitratePPM(layer) / co2PPM(layer)) );
	Assert(fRno3_co2 >= 0.0);

	// WFPS effect on the N2/N2O Ratio
	// Changed wfps effect on the N2/N2O ratio based on
	// paper Del Grosso et. al, GBC, in press.  -mdh 5/16/00
	double const fRwfps = std::max (0.1f,
				0.015f * layerWFPS * 100.0f - 0.32f);

	// N2:N2O Ratio
	// ratioN2N2O = (fRno3 < fRco2) ? fRno3 : fRco2;
	// ratioN2N2O *= fRwfps;
	double const ratioN2N2O = std::max (0.1, fRno3_co2 * fRwfps);

	// Compute N2 and N2O flux by layer (fluxNTotal(layer))
	// convert ppm N to gN/m^2
	fluxNTotal(layer) =
		fluxTotalDenitPPM * grams_soil(layer) * grams_per_ug;
	Assert (fluxNTotal(layer) < 10.0);
	double const fluxN2O = fluxNTotal(layer) / (ratioN2N2O + 1.0);
	fluxN2Odenit += fluxN2O;
	fluxN2denit += fluxNTotal(layer) - fluxN2O;

    } // denitrification loop

    Assert (fluxN2Odenit >= 0.0);
    Assert (fluxN2denit >= 0.0);

    //  Reduce nitrate in soil by the amount of N2-N N2O-N that is lost
    //  Do not let nitrate in any layer go below minNitratePPM_final

    double excess = 0.0;	// amount of N flux in excess of what
				//   can actually be removed from soil (gN/m^2)
    double const totalFlux = fluxN2Odenit + fluxN2denit;
    if (totalFlux > 1.0E-30)	// have any flux?
    {
	double const n2oFrac = fluxN2Odenit / totalFlux; // N2O fraction of flux
	double const n2Frac  = fluxN2denit  / totalFlux; // N2 fraction of flux

	for (short layer=0; layer < GetLayerCount(); layer++)
	{
	    double const minNitrate_final =
	    	minNitratePPM_final * grams_soil(layer) * grams_per_ug;
	    if ( nitratePPM(layer) < minNitratePPM )	// No flux from layer?
	    {
		excess += fluxNTotal(layer);
	    }
	    else if ( nitrate(layer) - fluxNTotal(layer) > minNitrate_final )
	    {
		// remove N in calculated trace gas flux from the layer
		nitrate(layer) -= fluxNTotal(layer);
	    }
	    else
	    {
		// reduce trace gas flux in layer so soil N won't fall below min
		// actual total trace gas flux (gN/m^2)
		double const fluxOut =
			(nitratePPM(layer) - minNitratePPM_final) *
			grams_soil(layer) * grams_per_ug;
		excess += fluxNTotal(layer) - fluxOut;
		nitrate(layer) = minNitrate_final;
	    }
	}  // for layer

	fluxN2Odenit -= n2oFrac * excess;
	fluxN2denit  -= n2Frac * excess;

	Assert (fluxN2Odenit >= -1.0e-6);
	Assert (fluxN2denit >= -1.0e-6);
    }
    else
    {
	fluxN2Odenit = 0.0;
	fluxN2denit = 0.0;
    }

#ifndef NDEBUG
    double const totN2 = fluxN2Odenit + fluxN2denit + ARRAY_SUM (nitrate);
    dynamic_cast<TDailyCenturyBase const &>(owner).BalanceCheckWithMsg (
		initialTotalN, totN2, 5.0E-5,
		"Denitrify total N" );
#endif
}

//--- end of file ---
