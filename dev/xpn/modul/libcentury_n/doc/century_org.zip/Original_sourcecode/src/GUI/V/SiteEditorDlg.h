#ifndef INC_SiteEditorDlg_h
#define INC_SiteEditorDlg_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  SiteEditorDlg.h
//	Class:	  SiteEditorDlg
//
//	Description:
//	Class for Editing Site Files.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Feb98, tom.hilinski@colostate.edu
//	History:
//	Oct01	Tom Hilinski
//	* Modified so site parameter info. is passed via the constructor.
//	Sep03	Tom Hilinski
//	* Lots of cleanup, const-correctness, and mods to match the latest
//	  version of the site parameters classes.
//	* Pointers are now shared or auto_ptrs.
//	Nov03	Tom Hilinski
//	* Added "Clear Set" button, and method Event_ClearSet to handle event.
//	* More cleanup.
//	* Browse button replaced with "Save As" button.
//	* Added member Event_OK.
//	* Removed member ReadNcSiteFile.
//	Sep04	Tom Hilinski
//	* New class hierarchy holds data source info for site parameter set.
//	* Moved all open/save functions to the new data source object.
//	Dec04	Tom Hilinski
//	* Major rewrite.
//	* Removed "Import" button & functions; "Open" handles this.
//	* Now can handle DayCent site parameters. Parameter radiobutton group
//	  is built at runtime.
// ----------------------------------------------------------------------------

#include "EditDlgBase.h"
#include "SiteEditorDataSrcBase.h"
#include "TSiteParamSet.h"
#include "TSharedPtr.h"
#include "UtilGUI.h"
#include <utility>
#include <memory>
#include <v/vapp.h>
#include <v/vslist.h>

template
<
	class ParametersType,		// parameters class
	class ParametersInfoType	// parameters info class
>
class SiteEditorDlg
	: public EditDlgBase
{
  public:
	//--- types
	typedef UtilGUI::DlgCmdsArray		DlgCmdsArray;
	typedef SiteEditorDataSrcBase<ParametersType, ParametersInfoType>
		TSiteDataSrc;
	typedef	TSharedPtr< TSiteDataSrc >		TSiteDataSrcPtr;
	typedef typename ParametersType::TSiteType	TSiteType;
	typedef typename ParametersInfoType::TInfoPtr	TInfoPtr;
	enum {					// Command objects values
	  TSiteEdDlg_Start = 11000,	// first item!
	  D_FrameMaster,		// one frame to hold them all...
					//--- Site Header Data
	  D_FrameSiteInfo,
	  D_ParamDataType,		// type of parameters: daily, monthly
	  D_FileName,			// text: site file name
	  D_Mnemonic,			// edit: mnemonic for site
	  D_Description,		// edit: description of site
	  D_FrameSelectSiteType,
	  D_SiteType, 			// r/o text: site type
	  D_SiteTypeChg,		// button: choose site type from list
					//--- parameter sets
	  D_FrameSelectParamSet,
	  D_FrameParamSetButtons,
	  D_FirstParameterSet,
	  D_ParameterSetsEnd =
	      D_FirstParameterSet + 50,
					//--- parameters
	  D_FrameParameterList,
	  D_ParamList,			// list: parameters
	  D_FrameParameterEdit,
	  D_FrameParameterValue,
	  D_ParamValue,			// edit: parameter value
	  D_ChangeValue,		// button: change the value
	  D_ClearSet,			// button: zero all values in set
	  D_FrameParameterDesc,
	  D_ParamDesc,			// r/o text: parameter desription
					//--- status and state
	  D_FrameStatusMessages,
	  D_ReadOnly,			// checkbox: checked if read-only
	  D_Modified,			// color text: displayed if modified
					//--- Action buttons
	  D_FrameCommonButtons,
	  D_FromLib,			// copy from a library
					//--- all done!
	  TSiteEdDlg_End		// last item!
	};

	//--- constructors and destructor
	SiteEditorDlg (
	  vApp * const useParent,		// pointer to application
	  TSiteDataSrcPtr useSite,		// site instance to use
	  TInfoPtr useInfo,			// site parameters info
	  std::string const & useHelpPath,	// path to help file
	  std::string const & useSiteLibPath,	// path to site libraries
	  std::string const & useUserLibPath,	// user's site library path
	  std::string const & useTemplatePath,	// path to template folder
	  std::string const & useWorkPath,	// user's work path
	  std::string const & useUserName,	// user name for output file
	  char const * const title = defaultDlgTitle);	// default dialog title
	~SiteEditorDlg ();

	//--- functions overridden
	void DialogDisplayed ();
	void DialogCommand (ItemVal cmdID, ItemVal cmdValue, CmdType cmdType);

	//--- functions
	void Clear ();				// "clear" data members

  private:
  	//--- constants
  	static const char * const version;	// version of editor
	static const char * toolTips[];		// tool tips text
	static CommandObject cmdList1[];	// dialog elements before groups
	static CommandObject cmdList2[];	// dialog elements after groups
	static char const * const defaultDlgTitle;	// default dialog title

	//--- parameters (external data)
	vApp* const parent;			// pointer to parent
	TSiteDataSrcPtr siteDataSrc;		// source of the site params.
	TInfoPtr infoPtr;			// site parameters info
	std::string const helpFilePath;		// path to help file
	std::string const & siteLibPath;	// path to site library
	std::string const & userSiteLibPath;	// user's site library path
	std::string const & templatePath;	// path to template folder
	std::string const & workPath;		// user's work path
	std::string userName;			// user name for output file

	//--- data
	TSiteDataSrcPtr dispSite;		// site parameters displayed
	TSiteParamSet* dispSet;			// current set displayed
	short dispSetNum;			// number of current set
	TSiteParameter* dispParam;		// current parameter displayed
	std::vector<vSList> parameterNames;	// array of lists of param names
	char displayStr[21];			// string for text box
	CommandObject * cmdList;		// constructed command list
	unsigned short indexCmdObjList;		// index to params in cmdList
	unsigned int idLastParamGroup;		// id of last radiobutton
	vSList paramGroupToolTips;		// tooltips for radiobuttons

	//--- functions
	void Initialize ();		// Initialize members
	bool HaveDisplayedData ()	// True if have a displayed site
	  {
	    return dispSite.get() != 0 &&
		   !dispSite->IsEmpty();
	  }
	void SetDisplayedSiteParams (
	  TSiteDataSrcPtr & useSite);
	void SetSensitive ();		// Set sensitive attribute for controls
					//--- Load data into dialogs:
	void LoadDlg ();		// Load the dialog
	void UpdateDlg_ParamList (	// Update the parameter list
	  ItemVal const id);		//   this list ID
	void UpdateDlg_ParamData (	// Update the parameter data
	  ItemVal const indexSelectedItem);
					//--- Button events:
	int Event_OK ();		// close dialog; returns cmdID
	void Event_Cancel ()		// Cancel: restore to start
	  { /* no-op */ }
	void Event_Open ();		// Open a new site parameter file
	void Event_New ();		// Create a new file
	void Event_Save ();		// Save to the current file
	void Event_SaveAs ();		// Save to a different file
	void Event_FromLibrary ();	// Get a site from a library
	void Event_ChangeValue ();	// Change parameter value
	void Event_ClearSet ();		// Clear all parameters in set
	void Event_SiteTypeChg ();	// Choose the site file type from list
	void Event_ReadOnly ();		// Read-only checkbox
	void Event_Help ();		// Display Help information
	void Event_About ()		// Display About information
	  { /* no-op */ }
					//--- Clear dialog controls:
	void ClearDialog ()		// Clears the entire dialog
	  {
	    ClearDlgParamData ();
	    ClearDlgParamList ();
	    ClearDlgSiteInfo ();
	  }
	void ClearDlgSiteInfo ();	// Clear site information display
	void ClearDlgParamList ();	// Clear parameter list display
	void ClearDlgParamData ();	// Clear parameter data display
					//--- Get data functions
	void GetSiteInfo ();		// Get site information from dialog
	void GetParamData ();		// Get parameter data from dialog
					//--- Utility functions
 	bool ConfirmReplaceData ();	// User to confirm clear dialog
	bool ConfirmSaveSite ();	// User to confirm save site data
	void CopyParamsToOriginal ();	// *origSite = *dispSite
	bool VerifyFileName (		// verifies the file
	  char const* name);
	void ShowHideModified ();
	void BuildParamNameLists ();	// Build the lists of parameter names
	void DisplayParameterValue (	// Display a parameter value
	  TSiteParameter const * const p,
	  ItemVal const indexParamList);
	void BuildRadioButtonSetList (		// build dlg radiobutton list
	  char const * const siteSetNames[],	//    from these strings
	  int const startingButtonID,		//    first button ID
	  int const frameID,			//    inside this frame
	  DlgCmdsArray & cmdArray);		//    store here
};

#endif // INC_SiteEditorDlg_h
