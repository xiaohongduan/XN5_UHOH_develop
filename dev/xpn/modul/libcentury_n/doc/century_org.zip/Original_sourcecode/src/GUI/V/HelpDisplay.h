#ifndef INC_HelpDisplay_h
#define INC_HelpDisplay_h
// ----------------------------------------------------------------------------
//	Copyright 2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  HelpDisplay.h
//
//	Description:
//	Functions to display help windows on any platform.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Oct03
//	History:
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	Microsoft Windows
// ----------------------------------------------------------------------------
#if defined(V_VersionWindows) || defined(MSWINDOWS) || defined(V_VersionOS2)
#ifndef MSWindowsHelp
  #define MSWindowsHelp
#endif

#include "winhelpid.h"

// Succeeds, the return value is nonzero.
// Fails, the return value is zero.

inline static
BOOL HelpDisplay (
	HWND hWndMain,			// handle of window requesting Help
	std::string const & lpszHelp,	// address of directory-path string
	UINT uCommand,			// type of Help
	DWORD dwData)			// additional data
{
	return ::WinHelp ( hWndMain, lpszHelp.c_str(), uCommand, dwData );
}

// ----------------------------------------------------------------------------
//	X11
// ----------------------------------------------------------------------------
#elif defined(V_VersionX) || defined(V_VersionMotif)
#ifndef X11Help
  #define X11Help
#endif

#include "winhelpid.h"

// macros for type of help
// These are dummy values until an X help display is implemented.
#define HELP_CONTENTS		0x1001
#define HELP_FINDER		0x1002
#define HELP_CONTEXT		0x1003
#define HELP_HELPONHELP		0x1004
#define HELP_QUIT		0x1005

inline static
unsigned long winHwnd() { return 0; }	// no-op

inline static
bool HelpDisplay (
	unsigned long hWndMain,		// handle of window requesting Help
	std::string const & lpszHelp,	// address of directory-path string
	unsigned int uCommand,		// type of Help
	unsigned long dwData)		// additional data
{
	return false;
}

// ----------------------------------------------------------------------------
//	Who knows?
// ----------------------------------------------------------------------------
#else
#ifndef UnknownSystemHelp
  #define UnknownSystemHelp
#endif

inline static
bool HelpDisplay (
	unsigned long hWndMain,		// handle of window requesting Help
	std::string const & lpszHelp,	// address of directory-path string
	unsigned int uCommand,		// type of Help
	unsigned long dwData)		// additional data
{
	return false;
}

#endif

// ----------------------------------------------------------------------------
#endif // INC_HelpDisplay_h
