#ifndef	INC_TCentBaseTemplate_h
#define	INC_TCentBaseTemplate_h
// ----------------------------------------------------------------------------
//	Copyright (c) 2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCentBaseTemplate.h
//	Class:	  TCenturyBase
//
//	Description:
//	Shortcut macros for dealing with template declarations for
//	class TCenturyBase.
//	These have to be known outside the class header file.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, November 2002
//	History:
// ----------------------------------------------------------------------------

#ifndef INC_TCenturyBase_h
#error TCentBaseTemplate.h: TCenturyBase should be included before this file!
#endif

#define MY_TEMPLATE_DECLARATION 	\
	template 			\
	< 				\
	  class TMySiteParams,		\
	  class TMyManagement,		\
	  class TMySoil,		\
	  class TMyWeather,		\
	  class TMyFixed,		\
	  class TMyParams,		\
	  class TMyParcp,		\
	  class TMyParfs,		\
	  class TMySimTime,		\
	  class TMySoilFlows,		\
	  class TMyMicrobial,		\
	  class TMyDecomp		\
	>

#define	TCENTURYBASE 					\
	TCenturyBase 					\
	<						\
	  TMySiteParams, TMyManagement,			\
	  TMySoil, TMyWeather,				\
	  TMyFixed, TMyParams, TMyParcp, TMyParfs,	\
	  TMySimTime,					\
	  TMySoilFlows, TMyMicrobial, TMyDecomp 	\
	>

#endif // INC_TCentBaseTemplate_h
