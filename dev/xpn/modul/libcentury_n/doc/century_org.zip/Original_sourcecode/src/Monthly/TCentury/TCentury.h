#ifndef INC_TCentury_h
#define INC_TCentury_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCentury.h
//	Class:	  TCentury
//
//	Description:
//	Century soil organic matter model class, version 5, monthly time step.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
//	History: See the file TCentury-History.txt.
// ----------------------------------------------------------------------------
//	Notes:
//	* Additional documents:
//	  Asynchronous Messaging to/from Century
//		Century-UI-Communication.htm
//	  Creating derived classes of class TCentury
//		DerivingCenturyClass.htm
//	  Procedure for Adding an Event:
//		AddingEvents.htm
//	  Procedure for Adding site parameters:
//		AddingSiteParameters.htm
//	  Changes to monthly Century, class TCentury:
//		src/Monthly/doc/TCentury-History.txt
//		doc/HTMLHelp/html/releasenotesv5.htm
// ----------------------------------------------------------------------------

#include "version.h"		// monthly Century version information
#include "TCenturyBase.h"	// Base class
#include "TCentBaseSpecialized.h"	// specializations
#include "TCentConfig.h"	// configuration set for class TCentury
#include "TMCSoil.h"
#include "TMCSoilFlows.h"	// flows to/from physical soil
#include <algorithm>

// forward declarations
namespace nrel
{
  namespace century
  {
	class MCSiteCreator;

  } // namespace century
} // namespace nrel


typedef TCenturyBase		//--- shortcut to base class
	<
	  TMCSiteParameters,	// site parameters class
	  TManagementScheme,	// site management class
	  TMCSoil,		// physical soil submodel
	  TWeather,		// weather source
	  TFixed,		// fixed parameters
	  Tparam,		// site/mgmt parameters
	  Tparcp,		// crop parameters
	  Tparfs,		// forest/savanna parameters
	  TSimTime,		// simulation timing
	  TMCSoilFlows,		// flows to/from soil
	  TMCMicrobial,		// microbial submodel
	  TMCDecomposition	// decomposition submodel
	>
	TMonthlyCenturyBase;

class TCentury
	: public TMonthlyCenturyBase
{
  public:
	friend class ::nrel::century::MCSiteCreator;

  	//---- types

	//--- Constructor with explicit pointers to required objects
	/* obsolete - Feb04
	TCentury (
	  TMCSiteParameters * const useSite, 		// site params.
	  TManagementScheme * const useMgmt,		// management
	  TEventDBList * const useParamDbList,		// parameter databases
	  TOutputBase * const useOutput,		// output engine
	  CenturyPaths const * const usePaths,		// directories
	  char const * const useUserName,		// user's name
	  TAsynchCommunication const * const useAsynchCom, // asynch. com.
	  TDebugInfo const & useDebugFlags);		// debug flags
	*/
	//--- Constructor using configuration object
	TCentury (
	  TCenturyConfig const & config,		// configuration
	  TDebugInfo const & useDebugFlags);		// debug flags
	virtual ~TCentury ()
	  {
	  }

	//---- operator overloads

	//--- Retrieve the output variables (address owned by this class)

	//--- Retrieve the output variables (address owned by this class)
	TWaterTemp const &	  WaterTemp () const	{ return wt; }
	TSoilC const &	    	  SoilC () const	{ return soilC; }
	TCropGrassC const &	  CropGrassC () const	{ return cropC; }
	TForestC const &	  ForestC () const	{ return forestC; }
	TCO2 const &		  CO2 () const		{ return co2; }
	TNPS const &		  NPS () const		{ return nps; }
	TErosion const * const	  Erosion () const	{ return erosion.get(); }
	TDeposition const * const Deposition () const	{ return deposition.get(); }

	//--- Modify the output variables - CAREFUL!
	TWaterTemp &		WaterTemp ()	{ return wt; }
	TSoilC &		SoilC ()	{ return soilC; }
	TCropGrassC &		CropGrassC ()	{ return cropC; }
	TForestC &		ForestC ()	{ return forestC; }
	TCO2 &			CO2 ()		{ return co2; }
	TNPS &			NPS ()		{ return nps; }
	TErosion * const	Erosion ()	{ return erosion.get(); }
	TDeposition * const	Deposition ()	{ return deposition.get(); }

	//--- Utility functions
	virtual void Clear ()			// Reset to the initial state
	  {
	    TMonthlyCenturyBase::Clear ();
	  }
	virtual void ClearForNewSimulation ()	// Reset only computed data
	  {
	    TMonthlyCenturyBase::ClearForNewSimulation ();
	    Initialize ();
	    ClearOutputVars ();
	  }
	virtual TCentury * const Clone () const	// Clone this
	  { return new TCentury (*this); }

	//--- constants

  protected:
	//--- data
	float wfunc;		// water effect upon decomposition
	float			// To do: move into TDCComput;
	  dummyE[3],		// dummy E compartment values
	  dummyC[2];		// dummy C compartment values

	// --------------------------------------------------------------------
	// setup functions
	virtual bool InitializeRun ();		// Initialize a run
	virtual void OpenOutput ();		// Open the output file(s)

	// --------------------------------------------------------------------
	//--- I/O
	virtual void  ReadSiteParameters ();	// retrieve the site parameters
	virtual void  CheckSiteParamValues ();	// verify the site parameters
	virtual void  WriteOutputValues (	// writes to netCDF output
	  float time);

	// --------------------------------------------------------------------
	// Simulation functions
	virtual void  StartOfYearTasks ();
	virtual void  InitializePools ();
	virtual void  PreliminaryCalcs ();
	virtual void  InitMonthlyCycle ();
	virtual void  SimulateSOM ();

	// --------------------------------------------------------------------
	// Event handlers - both crop/grass and forest/savanna
	virtual void  FireEvent ();
	virtual float Irrigate (
	  short const month);	// simulation month

	// --------------------------------------------------------------------
	// Queries

	// --------------------------------------------------------------------
	// Forest Functions
	virtual void ForestLiveBiomassRem (
	  float *accum);	// Cumulative C: [0]=unlabeled, [1]=labeled
	virtual float ForestMaintRespiration (
	  float const temp,	// tave - for leaf and stem, stemp - for root
	  float const nitrog);	// rleave(0), rlwode(0), fbrche(0),
				// croote(0), or froote(0)
	virtual void ForestProductionPotential ();
	virtual void SimulateTrees ();
	virtual bool StartDeciduousGrowth ();
	virtual void TreeGrowth ();
	virtual void WoodDeath ();

	// --------------------------------------------------------------------
	// Crop Functions
	virtual void SimulateCrop ();
	virtual void CropGrassGrowth ();
	virtual void DeathOfRoots ();
	virtual void HarvestCrop (
	  short const month,	// current month
	  float const *pltlig);	// array:
	virtual void RemoveCropGrass ();
	virtual void SimulateCultivation ();

	// --------------------------------------------------------------------
	// Decomposition
	virtual void PSDecompChemistry (
	  float const dtDecomp);	// decomposition time step

	// TempEffectOnDecomp
	// Effect of temperature upon decomposition.
	// It is an exponential function.
	// Older versions of Century used a density function.
	// Author: 10/95 - rm
	virtual float TempEffectOnDecomp (
	  float const soilTemp			// soil temperature (C)
	  ) const
	  {
	    return fixed.teff[0] +
		std::exp (fixed.teff[2] * soilTemp) * fixed.teff[1];
	  }

	// WaterEffectOnDecomp
	// Effect of soil water content upon decomposition.
	virtual float WaterEffectOnDecomp ()
	  {
	  	// rwcf[0] should never be < 0.0 or > 1.0
	  	Assert (wt.rwcf[0] <= 1.0f);
	  	Assert (wt.rwcf[0] >= 0.0f);
	  	return 1.0f /
	  		(std::exp (wt.rwcf[0] * -6.0f) * 4.0f + 1.0f);
	  }

	// --------------------------------------------------------------------
	// Physical environment calculations

	float MoistureRatioForGrowth (
	  float const plantAvailableSoilWater)
	  {
	    return ( wt.pet < 0.01f ?
		0.01f :
		(plantAvailableSoilWater + weather->Precip(st->month) +
			wt.irract) / wt.pet );
	  }

	virtual void  SoilWaterModel (	// Soil water submodel
	  short const month,		    // month (1-12)
	  float const agLiveBiomass,	    // aboveground live biomass (g/m2)
	  float const surfaceLitterBiomass, // litter biomass (g/m2)
	  float const standingDeadBiomass,  // standing dead biomass (g/m2)
	  float const totalH2OInput,	    // total water applied to surface
	  float const availPET,		// PET
	  float & evaporation,		// evaporation
	  float & transpiration,	// transpiration
	  float & pttr,			// potential transpiration water loss
	  float & snow,			// water in snowpack
	  float & runoff);		// runoff

	virtual float SnowWaterModel (
	  float const availablePET,	// total available PET
	  float & remainingPT);		// net potential transpiration

	virtual void SoilTemperatureModel (	// Soil temperature submodel
	  short const month);	// simulation month (1-12)

	// --------------------------------------------------------------------
	// Leaching
	virtual void  LeachMineralNPS (	// Leaching of mineral N, P, and S
	  float const*
	      fractionLeached);	// array: fraction leached (from simsom.cpp)

	// --------------------------------------------------------------------
	// Others
				// --------------------------------------------
	virtual float AnaerobicImpact (
	  float const ratioPrecPET);	// new (RAIN+IRRACT+AVH2O(3))/PET
				// --------------------------------------------
	virtual void RestrictProduction (
	  float const* const availableE, // array [NUMELEM]:
	  float const* const ceRatio,	 // array [2, nparts, NUMELEM]:
	  short const nparts,		// no. parts (values: CPARTS, FPARTS)
	  float const* const cfrac,	// array [nparts]:
	  float const potenc,		// potential crop/grass/forest prod.
	  float const rimpct,		//
	  float const* const storage,	// array [NUMELEM]:
	  float const snfxmx,		//
	  float & cprodl,		// NPP: modified here
	  float* const eprodl,		// array [NUMELEM]:
	  float* const uptake,		// array [EPOOLS,NUMELEM]:
	  float & plantNfix);		// cum. symbiotic N-fixation (gN/m2)
				// --------------------------------------------
	virtual void  NutrientLimitation (
	  short const nparts,		// no. of parts (values: CPARTS, FPARTS)
	  float const * const cfrac,	// array [nparts]:
	  float const * const eAvailable, // array [NUMELEM]:
	  float const * const maxec,	// array [NUMELEM]:
	  float const * const maxeci,	// array [FPARTS,NUMELEM]:
					//   maximum average E/C of whole plant
	  float const * const mineci,	// array [FPARTS,NUMELEM]:
					//   minimum average E/C of whole plant
	  float const snfxmx,		// Symbiotic N fixation maximum
					//   (gN fixed/gC new growth)
	  float const factorCtoBiomass,	// C to biomass conversion factor
	  float & cprodl,		// NPP: modified here
	  float * const eprodl,		// array [NUMELEM]:
	  float & plantNfix);		// symbiotic N-fixation (gN/m2)
				// --------------------------------------------
	virtual void  PartitionResidue (
	  float const cpart,	// amount of carbon in the residue.
	  float const *recres,	// array: n/c, p/c, and s/c in the residue.
	  short const lyr,	// layer (values: SRFC, SOIL)
	  float* const cdonor,	// array: compartments
	  float* const edonor,	// array: compartments
	  float const frlign,	// fraction of incoming material = lignin.
	  float const friso);	// fraction of cpart = labeled.
				// --------------------------------------------
	virtual float CropGrassProductionPotential ( // Monthly protential C
	  float const canopyCover);	// canopy cover

	// --------------------------------------------------------------------
	// Update variables
	virtual void UpdateFromTexture ();
	virtual void UpdateMineralEVariables (); // Update total mineral E vars
	virtual void UpdateMineralEOutputVariables ();

  private:
	//--- data

	//--- functions
	virtual void Constructor ();		// Common constructor
	virtual void Initialize ();		// Initialize class
	void Duplicate (		 	// Duplicate this
	  TCentury const & object);

	//--- functions: Virtual
	virtual bool DoInitializeModel ();	// Initialize the model
	virtual bool DoRunToCompletion ();	// Run simulation to completion
						//   Return false if successful
						//   Set model state.
						//   Set the iteration counter.
	virtual bool DoRunIteration ();		// Run simulation one iteration
						//   Return true if can continue
						//   Set model state.
	virtual TState DoPauseRun ()		//--- Pause model run
	  {
 	    state = TModelState::State_Paused;	// Set model state.
	    return state.GetState();
	  }
	virtual TState DoTerminateRun ()	// Terminate model run
						//   Return new	model state
	  {
	    PostCancelRequest ();
	    state = TModelState::State_Terminating;
	    // To Do: wait for cancel?
	    DoRunIteration ();	// force termination check
	    // state = TModelState::State_Terminated;
	    return state.GetState();
	  }

	//---- functions: Not allowed
	TCentury (TCentury const & object)	// copy constructor
	  : TMonthlyCenturyBase (object)
	  {
	    Duplicate (object);
	  }
	TCentury& operator= (			// Assign TCentury object
	  TCentury const & object)
	  {
	    /*
	    if (this != &object)	// assigning self?
	    {
		TMonthlyCenturyBase::operator= (object);
	    	ClearForNewSimulation ();
		Transfer (object);
	    }
	    */
	    return *this;
	  }
	TCentury& operator= (			// Assign TCenturyConfig object
	  TCenturyConfig const & config)
	  {
	    /*
	    TMonthlyCenturyBase::operator= (config);
	    */
	    return *this;
	  }
};

#endif // INC_TCentury_h
