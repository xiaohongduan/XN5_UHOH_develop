#ifndef INC_TErosion_h
#define INC_TErosion_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TErosion.h
//	Class:	  TErosion
//
//	Description:
//	Class to perform erosion of Century's pools.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Oct98
//	History:
//	Jan01	Tom Hilinski
//	* Modified LowerToSimLayerPools to base the element transfer on the
//	  C:element of the sim layer pools. The return value of the element
//	  transfer array is modified to the actual amount transferred.
//	  The input amount the array is the max. element amount available.
//	* Made the reference to the physical soil class a const.
//	* Removed physical soil erosion from this class.
//	Jun01	Tom Hilinski
//	* Added copy constructor, operator=
//	Sep03	Tom Hilinski
//	* Added member ErodeLayers, extending original code in Erode to
//	  remove from multiple layers, if needed.
// ----------------------------------------------------------------------------

#include "TDepEroBase.h"

class TManagementScheme;
class TMCSiteParameters;

class TErosion : public TDepEroBase
{
  public:
	//--- constructors and destructor
	TErosion (
	  TSite & useSite,		// use this site class instance
	  TCenturySoil & useSoil,	// use this soil class instance
	  TLowerSoil & useLwrSoil,	// use this lower soil pool instance
	  TSoilC & useSoilC,		// soil C output variable instance
	  TNPS & useNPS,		// NPS output variable instance
	  TWater & useWater,		// water parameters class
	  TWaterTemp & useWT,		// water & temperature output class
	  TFlow & useFlows,		// flow manager class instance
	  short const useNumIso,		// number of isotopes
	  short const useNumElem,		// number of elements
	  char const * const useMgmtDesc,	// management description
	  char const * const useMgmtFile,	// management file name
	  char const * const useSiteDesc,	// site description
	  char const * const useSiteFile,	// site file name
	  char const * const useUserName);	// user name for output file
	~TErosion (  ) { }
	TErosion (TErosion const & object)	// copy constructor
	  : TDepEroBase ( static_cast<TDepEroBase const &>(object) ),
	    mgmtDesc (object.mgmtDesc),
	    mgmtFile (object.mgmtFile),
	    siteDesc (object.siteDesc),
	    siteFile (object.siteFile),
	    userName (object.userName)
	  {
	    Initialize ();
	    Copy (object);
	  }

	//---- operator overloads
	TErosion& operator= (TErosion const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	TDepEroBase::operator= (object);
		Copy (object);
	    }
	    return *this;
	  }

	//--- Initialization functions
	void SetRate (			// Set the erosion rate (kg/m^2/month)
	  float const newRate);		//   rate of erosion to use
	void SetEnrichFactor (		// Set the enrichment factor
	  float const newFactor);	//   factor to use
	bool UseErosionFile (		// Save eroded amounts to a file
	  char const * const filePath);	//   full path with file name
					//   Returns false if OK, else true.
	bool UseErosionFile (		// Save eroded amounts to a file
	  std::string const & filePath)	//   full path with file name
	  {				//   Returns false if OK, else true.
	    return UseErosionFile (
	    		filePath.c_str() );
	  }
	//--- Query functions
	bool HaveErosionFile () const	// True if using erosion output file
	  { return (eoFile.get() != 0); }
	float ErodedPoolAmt (
	  short const element,
	  short const pool) const
	  { return outData[element*EPT_NumPools + pool]; }
	float const* ErodedPools () const
	  { return outData; }
	float CumDisLoss (		// Cumulative erosion dissolution loss
	  const TErosionElements e, 	//   element, and
	  const TErosionPoolTypes p	//   pool
	  ) const
	  { return disLoss[e][p]; }
	float CumGasLoss (		// Cumulative erosion gaseous loss
	  const TErosionElements e, 	//   element, and
	  const TErosionPoolTypes p	//   pool
	  ) const
	  { return gasLoss[e][p]; }

	//--- Tasks functions
	float Erode (			// Erodes from the top of the soil
	  float const simTime); 	//   simulation time
	void Clear ();			// "Clear" data members

  protected:

	//--- constant data
	char const* mgmtDesc;		// management description
	char const* mgmtFile;		// management file name
	char const* siteDesc;		// site description
	char const* siteFile;		// site file name
	char const* const userName;	// user name for output file

	//--- data
	float rate; 		// rate of soil loss (kg/m^2/event).
				//   Value supplied with erosion event.
				//   Century 4 name: "psloss".
	float enrichFactor;	// enrichment factor: Compensates for SOM
				//   decreasing with depth in the simu. layer.
				//   fractions lost (calc'd only once
	float lossFraction[EE_NumElements][EPT_NumPools];
	static short const outDataSize;			// size of output data
	float outData[EE_NumElements * EPT_NumPools];	// output data

	//--- data - accumulators
				// amount of eroded material lost to (g/m2):
	float disLoss[EE_NumElements][EPT_NumPools];	// dissolution removal
	float gasLoss[EE_NumElements][EPT_NumPools];	// gaseous phase

	//--- functions
	float ErodeLayers (
	  float const simTime, 		//   simulation time
       	  float const fractionLost,	//   Fraction of soil lost by erosion
	  float const thicknessToErode); //   thickness (cm)
	float ThicknessEroded () const;	// Thickness of soil to erode
	void SimPoolsLosses (		// Do elemental losses for the pools.
	  float const simTime, 		//   simulation time
       	  float const fracLost,		//   Fraction of soil lost by erosion
	  float const thickness,	//   thickness (cm)
	  float const bulkDen,		//   bulk density (g/cm^3)
	  float const sand,		//   fraction of sand-sized
	  float const silt,		//   fraction of silt-sized
	  float const clay);		//   fraction of clay-sized
       	void LowerToSimLayerPools (	// Do transfers from lower layer pools
	  float const simTime, 		//   simulation time
       	  float const amtC[sizeC], 	//   C transfer amounts (g m-2)
       	  float amtE[sizeE]);		//   N, P, S transfer amounts (g m-2)
	float FractionLost (		// Weight fraction of material eroded
					//   within a soil layer.
	  float const bulkDensity,	//   bulk density (g/cm^3)
	  float const thickness) const;	//   thickness (cm)

  private:
	//--- functions
	void Initialize ();			// Initialize members
	void Copy (TErosion const & object);	// Copy to this
	void InitOutData ()		// Initialize output data array
	  {
	    float *p = outData, *pEnd = outData + outDataSize;
	    while ( p < pEnd )
		*(p++) = 0.0f;
	  }
};

#endif // INC_TErosion_h
