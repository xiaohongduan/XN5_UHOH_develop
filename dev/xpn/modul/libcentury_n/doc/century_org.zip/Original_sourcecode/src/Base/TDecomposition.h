#ifndef INC_TDecomposition_h
#define INC_TDecomposition_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TDecomposition.h
//	Class:	  TDecomposition
//
//	Description:
//	Class for plant decomposition.
//	Members were extracted from class TCenturyBase.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, April 2004
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TFlowsSchedulable.h"
#include "TSoilFlowsBase.h"
#include "TMicrobialBase.h"
#include "outputvars.h"
#include "centtypes.h"
#include "TFixed.h"
#include "TPlantSysType.h"
#include "precision.h"

class TLeachOrganicC;
class TCenturySoil;

// ----------------------------------------------------------------------------

class TDecomposition
	: public TFlowsSchedulable
{
  protected:
	//---- constructors and destructor
	TDecomposition (
	  // Instances of Century submodels
	  TLeachOrganicC & useLeachOC,
	  TCenturySoil & useSoil,
	  TSoilFlowsBase & useSoilFlows,
	  TMicrobialBase & useMicrobial,
	  // Century internal data
	  TSimTime const & useSimTime,
	  TFixed const & useFixed,
	  Tparfs const & useParfs,
	  Tcomput & useComput,
	  TSite & useSite,
	  // Century output variables
	  TCO2 & useCo2,
	  TForestC & useForestC,
	  TNPS & useNps,
	  TSoilC & useSoilC,
	  TWaterTemp const & useWT,
	  // other
	  TSystemType const systemType = SysType_Unknown );
	TDecomposition (				// copy constructor
	  TDecomposition const & object,		//   object to copy
	  // Instances of Century submodels - refs to owner's objects
	  TLeachOrganicC & useLeachOC,
	  TCenturySoil & useSoil,
	  TSoilFlowsBase & useSoilFlows,
	  TMicrobialBase & useMicrobial,
	  // Century internal data
	  TSimTime const & useSimTime,
	  TFixed const & useFixed,
	  Tparfs const & useParfs,
	  Tcomput & useComput,
	  TSite & useSite,
	  // Century output variables
	  TCO2 & useCo2,
	  TForestC & useForestC,
	  TNPS & useNps,
	  TSoilC & useSoilC,
	  TWaterTemp const & useWT,
	  // other
	  TSystemType const systemType);
	virtual ~TDecomposition ()
	  {
	  }

	//---- functions not allowed
	// (but needs to be here so refs get initialized from child classes)
	TDecomposition (				// copy constructor
	  TDecomposition const & object);

  public:

	// virtual TDecomposition * const Clone () const = 0;	// Clone this

	//---- operator overloads
	bool operator== (TDecomposition const & object) const
	  {
	    if ( &object )
	    {
		return true; // To Do: operator==
	    }
	    else
		return false;
	  }
	bool operator!= (TDecomposition const & object) const
	  {
	    return !(*this == object);
	  }

	//---- functions
	void Clear ();
	virtual void InitializeSOMDecomp ();
	virtual void  Decompose	(
	  float const dtDecomp,		// decomposition time step
	  float const anerb,		// Effect of soil anaerobic conditions
	  float const defac)		// Decomposition factor
	  {
	    DecomposeLitter (dtDecomp, anerb, defac);
	    if ( decompSystem.IsForest() || decompSystem.IsSavanna() )
		DecomposeWood (dtDecomp, anerb, defac);
	    DecomposeSOM (dtDecomp, anerb, defac);
	  }
	void UpdateMineralAccum (	// Update mineralization accumulators.
	  float const mineralEFlow,	// mineralization returned by esched
	  float & gross,		// returns gross mineralization
					//   (not immoblization)
	  float & net)			// returns net mineralization
					//   (mineralization - immoblization)
	  {
    	    if (mineralEFlow > 0.0f)
		gross += mineralEFlow;
    	    net += mineralEFlow;
	  }
	virtual float ScheduleNPSFlow (
          TMineralElements element,	// N, P, or S
	  float const cFlowAtoB,	// C flow from Box A to Box B
	  float const cATotal,		// total C (both isotopes) in Box A
	  float const rcetob,		// C/E of new E added to Box B
	  float* const eA,		// E pool in box A
	  float* const eB,		// E pool in box B
	  float const simDepth		// simulation depth
	  ) = 0;
	TPlantSystemType const & GetSystemType () const
	  { return decompSystem; }		// current plant system type
	void SetSystemType (
	  TSystemType useSystemType)		// new plant system type
	  {
	    decompSystem.Type() = useSystemType;
	  }
	static char const * const GetVersion ()		// Return version
	  { return version; }

	//---- functions: Queries

  protected:
	//---- constants

	//---- data: external
	// Century submodels
	TLeachOrganicC & leachOC;	// organic C,N,P,S leaching
	TCenturySoil & soil;		// physical soil submodel
	TSoilFlowsBase & soilFlows;	// flows to/from soil
	TMicrobialBase & microbial;	// microbial submodel
	// Century internal data
	TSimTime const & simTime;
	TFixed const & fixed;
	Tparfs const & parfs;
	Tcomput & comput;
	TSite & site;
	// Century output variables
	TCO2 & co2;
	TForestC & forestC;
	TNPS & nps;
	TSoilC & soilC;
	TWaterTemp const & wt;

	//---- data: members
	TPlantSystemType decompSystem;	// decomposition system type
    	float cemicb[NUMELEM]; 	// slope of the regression line for C/E of som1

	//---- functions
					// ------------------------------------
	virtual void  DecomposeLitter (
	  float const dtDecomp,		// decomposition time step
	  float const anerb,		// Effect of soil anaerobic conditions
	  float const defac);		// Decomposition factor
					// ------------------------------------
	// Decompose SOM1 (surface and soil), SOM2, and SOM3.
	//     defac = decomposition factor based on water and
	//             temperature computed in prelim and in cycle
	//     dtDecomp = time step (dt/ntspm)
	// Steps:
	// 1. Surface SOM1 decomposes to SOM2 with CO2 loss.
	// 2. Soil SOM1 decomposes to SOM2 and SOM3 with CO2 loss and leaching.
	// 3. SOM2 decomposes to soil SOM1 and SOM3 with CO2 loss
	// 4. SOM3 decomposes to soil SOM1 with CO2 loss.
	virtual void  DecomposeSOM (
	  float const dtDecomp,		// decomposition time step
	  float const anerb,		// Effect of soil anaerobic conditions
	  float const defac)		// Decomposition factor
	  {
	    DecomposeSurfaceSOM1 (dtDecomp, anerb, defac);
	    DecomposeSoilSOM1 (dtDecomp, anerb, defac);
	    DecomposeSOM2 (dtDecomp, anerb, defac);
	    DecomposeSOM3 (dtDecomp, anerb, defac);
	  }
					// ------------------------------------
	virtual void  DecomposeSurfaceSOM1 (
	  float const dtDecomp,		// decomposition time step
	  float const anerb,		// Effect of soil anaerobic conditions
	  float const defac);		// Decomposition factor
					// ------------------------------------
	virtual void  DecomposeSoilSOM1 (
	  float const dtDecomp,		// decomposition time step
	  float const anerb,		// Effect of soil anaerobic conditions
	  float const defac);		// Decomposition factor
					// ------------------------------------
	virtual void  DecomposeSOM2 (
	  float const dtDecomp,		// decomposition time step
	  float const anerb,		// Effect of soil anaerobic conditions
	  float const defac);		// Decomposition factor
					// ------------------------------------
	virtual void  DecomposeSOM3 (
	  float const dtDecomp,		// decomposition time step
	  float const anerb,		// Effect of soil anaerobic conditions
	  float const defac);		// Decomposition factor
					// ------------------------------------
	virtual void DecomposeWood (
	  float const dtDecomp,		// decomposition time step
	  float const anerb,		// Effect of soil anaerobic conditions
	  float const defac);		// Decomposition factor
					// ------------------------------------
	virtual	void DecomposeLignin (
	  float	const lignin,		// lignin content of Box A
	  short	const layer,		// layer (values: SRFC,	SOIL)
	  short	const numLayers,	// total number of layers for Box A;
					// =2 for structural, metabolic, som1;
					// =1 for som2, som3, wood compartments
	  float	const * const rnew,	// array: C/E of flow to som2
	  float	const tcflow,		// total C flow	out of Box A
	  float	const * const tcstva,	// array: total	C in layers of Box A.
	  float* const csrsnk,		// array: C source/sink
	  float* const cstatv,	// array: C state variables for	Box A;
				//   cstatv(lyr,iso) is	C in layer 'lyr',
				//   'iso' = [0] = unlabeled, [1] = labeled
	  float* const elstva,	// array: N, P,	S in Box A by layer & element
	  float* const gromin,	// array: gross	mineralization (iel=1,3)
	  float* const netmnr,	// array: net mineral. for layer lyr (N, P, S)
	  float* const resp);	// Cumulative C	flows from microbial resp.
				//   (g/y) for [0] = unlabeled,	[1] = labeled
					// ------------------------------------
	virtual float AboveGroundDecompRatio (
	  float const amountEinA,	// Amount of N, P, or S in Box A
	  float const totalCinA,	// total C in Box A
	  float const biocnv,		// C to biomass conversion factor
					//   (Use 2.0 for wood, 2.5 for other.)
	  short const element);		// index to element; 0 = N, 1 = P, 2 = S
					// ------------------------------------
	virtual float BelowGroundDecompRatio (
	  float const aminrl,	// Amount in layer 1 before plant uptake
	  float const * const varat, // (0,element) =
				//   max. C/E for E entering 'Box B'
			   	//   (1,iel) = min. C/E
			   	//   (2,iel) = E present at min. C/E
	  short const element);	// index to element; 0 = N, 1 = P, 2 = S
					// ------------------------------------
	virtual bool CanDecompose (
	  float const tca,		// total C in Box A
	  float const * const elstva,	// array [numLayers, site.nelem];
					//   N, P, and S in Box A
					//   by layer and element
	  short const numLayers,	// 1st dimension of elstva
	  short const layer,		// layer of Box A (values: SRFC, SOIL)
	  float const * const ratioNewCE); // array [site.nelem];
					//   C/N, C/P, and C/S ratios of new
					//   material being added to Box B

  private:
	//---- constants
	static char const * const version;		// class version number

	//---- data

	//---- functions

	//---- functions not allowed
	TDecomposition& operator= (
	  TDecomposition const & object)
	  {
	    return *this;
	  }

};

#endif // INC_TDecomposition_h
