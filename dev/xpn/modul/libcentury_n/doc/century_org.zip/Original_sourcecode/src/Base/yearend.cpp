// ----------------------------------------------------------------------------
//	Copyright 2000-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  yearend.cpp
//	Class:	  TCenturyBase
//	Function: EndOfYearTasks
//
//	Description:
//	Things to do at the end of the simulation year:
//	* adjust bulk density
//	* recalc the C depth distribution
//	* adjust the pools of the lower layer
// ----------------------------------------------------------------------------
//	History:
//	Jun02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved static local variables into struct Tcomput.
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "SoilErrorMsgs.h"
#include <numeric>
#include <cmath>
#include "AssertEx.h"
using namespace std;

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::EndOfYearTasks ()
{
	//--- error checks
	Assert (soil.get());

	//--- Modify soil pools and properties dependent upon soil C content
	bool doCDistribution = false;		// recalc the C distrib?

	//--- avg. annual somsc
	float annualSumSoilC = 0.0f;		// sum annual soil C
	for ( short i = 0; i < 3; ++i )
		annualSumSoilC += comput.annualSumSoilC[i];
	float avgMonthlySOMSC = annualSumSoilC / 12.0f;	// monthly average

	//--- Recalc bulk density and thickness in the sim. soil layers
	// Uses the mean soil C in the sim layer for comparison
    if ( lowerSoil.get() )				// have lower soil?
    {
	if ( comput.lastYearAvgMonthlySOMSC > 0.0f )	// not first time thru?
	{
		doCDistribution = true;
		bool updateDepths = false;

		// get number of soil layers to calc bd for
		short const maxLayerIndex =
				soil->GetLayerIndex (wt.simDepth);
		// total thickness of those layers
		float const totalThickness = accumulate (
				soil->Thickness().begin(),
				soil->Thickness().begin() + maxLayerIndex + 1,
				0.0f);

		// for each layer, calc a new bd and thickness
		for ( short i = 0; i <= maxLayerIndex; ++i )
		{
			// Change in mean bulk density and layer thickness from
			// simulation layer change in organic C content
			float const thicknessFraction =
				soil->Thickness()[i] / totalThickness;
			pair<float,float> change = soil->BDChangeFromOCgm2 (
			    comput.lastYearAvgMonthlySOMSC * thicknessFraction,
			    avgMonthlySOMSC * thicknessFraction );
			if ( change.first != 0.0f ) // change in bulk density?
			{
				// update bulk density for layer
				float const newBD =
					soil->BulkDensity(i) + change.first;
				if ( newBD > 0.0f )
					soil->BulkDensity(i) = newBD;
				else
					Assert (newBD > 0.0f);
				// update thickness of layer
				float const newThickness =
					soil->Thickness()[i] + change.second;
				if ( newThickness > 0.0f )
				{
					soil->Thickness()[i] = newThickness;
					updateDepths = true;
				}
				else
				{
					Assert (newThickness > 0.0f);
				}
				// change in thickness?
				// change rooting depth to match new soil depth
				if ( change.second != 0.0f )
				    water.UpdateRootingDepth (*soil);
			}
		}
		if ( updateDepths )
		{
			soil->CalcDepths ();
			water.UpdateRootingDepth (*soil);
		}

		// debug
//		Assert (soil->Depth().size() > 0);
//		Assert (soil->SandFraction().Size() == soil->Depth().size());
//		Assert (soil->SiltFraction().Size() == soil->Depth().size());
//		Assert (soil->ClayFraction().Size() == soil->Depth().size());
//		Assert (soil->BulkDensity().Size() == soil->Depth().size());
//		Assert (soil->WaterContent().Size() == soil->Depth().size());
//		Assert (soil->WiltingPoint().Size() == soil->Depth().size());
//		Assert (soil->FieldCapacity().Size() == soil->Depth().size());
//		Assert (soil->OMPC().Size() == soil->Depth().size());
//		Assert (soil->BulkDensity().Size() == soil->Depth().size());
//		Assert (soil->Thickness().size() == soil->Depth().size());
	}

	//--- Initialize and determine need to recalc the C distribution.
	if ( comput.lastYearAvgMonthlySOMSC == 0.0f )	// not initialized?
	{
		// save initial value
		comput.lastYearAvgMonthlySOMSC = avgMonthlySOMSC;
		doCDistribution = true;
	}
	if ( comput.prevYearSoilDepth == 0.0f )		// not initialized?
	{
		// save initial value
		comput.prevYearSoilDepth = soil->SoilDepth();
		doCDistribution = true;
	}

	// Look for signification change in sim. layer C or soil thickness.
	if ( !doCDistribution  )
	{
		if ( std::fabs (
			comput.lastYearAvgMonthlySOMSC - avgMonthlySOMSC) >
				0.05f * comput.lastYearAvgMonthlySOMSC ||
		     std::fabs (comput.prevYearSoilDepth - soil->SoilDepth()) >
	     			0.05f * comput.prevYearSoilDepth )
		{
			doCDistribution = true;
		}
	}

	//--- recalc the soil depth distribution curve
	bool soilError = ( soil->LastError() != NSSoilErrors::NoError );
	if ( !soilError && doCDistribution )
	{
	    // remember depth of roots
	    if ( lowerSoil->Thickness() > 0.0f )
	    {
		    soil->ExponentialOMPC (
			avgMonthlySOMSC, lowerSoil->GetTotalC(),
			wt.simDepth, lowerSoil->Thickness() );
		    soilError = ( soil->LastError() != NSSoilErrors::NoError );
	    }
	    else
	    {
		    soil->ExponentialOMPC (
			avgMonthlySOMSC, avgMonthlySOMSC * 0.5f,
			wt.simDepth, soil->SoilDepth() );
		    soilError = ( soil->LastError() != NSSoilErrors::NoError );
	    }
	    if ( !soilError )
	    {
		comput.lastYearAvgMonthlySOMSC = avgMonthlySOMSC; // remember
		soil->CalcDepths ();
		water.UpdateRootingDepth (*soil);
		UpdateFromSoilWater ();
	    }
	    if ( (short)soil->LastError() == (short)NSSoilErrors::NoSolutionC ||
		 (short)soil->LastError() == (short)NSSoilErrors::BadSolutionC )
	    {
		// display warning
		short const i =
			(short) soil->LastError() -
			(short) NSSoilErrors::NoSolutionC;
		std::ostringstream os;
		os << "Sim. time: " << st->time
		   << ": " << NSSoilErrors::errorMsgCentury[i];
		asynchCom.SendWarningMessage ( os );
		// turn off error flag
		soilError = false;
		soil->ClearError();
		return;
	    }
	}
	if ( soilError )
	{
		ThrowCentException (
			TCentException::CE_PHSOIL,
			NSSoilErrors::errorMsg[ soil->LastError() ].c_str() );
	}

#ifdef DBG_CENTURY_SOIL
	soil->dbg_nlaypg = water.nlaypg;
	soil->dbg_rootDepth = water.depthOfRoots;
#endif

	// get the new lower layer pool C amount
	float const newLLAmt =
		soil->GetCAmount (wt.simDepth, soil->SoilDepth());

	//--- update the lower layer soil pools
	float poolsC[sizeC];

#define poolsC_ref(pool_,_isotope_)	(poolsC[(pool_) * ISOS + (_isotope_)])
#define poolsE_ref(pool_,element_)	(poolsE[(pool_) * NUMELEM + (element_)])

	// calc the C pools
	register float ciFraction = soilC.somsci[UNLABL] / soilC.somsc;
	poolsC_ref(ACTIVE, UNLABL)  = newLLAmt * ciFraction;
	poolsC_ref(SLOW, UNLABL)    = newLLAmt * ciFraction;
	poolsC_ref(PASSIVE, UNLABL) = newLLAmt * ciFraction;
	ciFraction = 1.0f - ciFraction;
	poolsC_ref(ACTIVE, LABELD)  = newLLAmt * ciFraction;
	poolsC_ref(SLOW, LABELD)    = newLLAmt * ciFraction;
	poolsC_ref(PASSIVE, LABELD) = newLLAmt * ciFraction;
	/*
	register float factor = comput.ratioSC2LLC * ciFraction;
	poolsC_ref(ACTIVE, UNLABL)  = comput.annualSumSoilC[0] * factor;
	poolsC_ref(SLOW, UNLABL)    = comput.annualSumSoilC[1] * factor;
	poolsC_ref(PASSIVE, UNLABL) = comput.annualSumSoilC[2] * factor;
	ciFraction = 1.0f - ciFraction;
	poolsC_ref(ACTIVE, LABELD)  = comput.annualSumSoilC[0] * factor;
	poolsC_ref(SLOW, LABELD)    = comput.annualSumSoilC[1] * factor;
	poolsC_ref(PASSIVE, LABELD) = comput.annualSumSoilC[2] * factor;
	*/
	// update the lower soil layer using the original C:E ratios
	lowerSoil->SetPoolsFromC (poolsC);

#undef poolsC_ref
#undef poolsE_ref

    }	// if lowerSoil.get()
}

//--- end of file ---
