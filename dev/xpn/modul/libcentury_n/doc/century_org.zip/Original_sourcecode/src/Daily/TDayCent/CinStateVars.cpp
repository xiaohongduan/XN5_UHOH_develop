// ----------------------------------------------------------------------------
//    Project:  Century Soil Organic Matter Model, daily version
//    File:	CinStateVars.cpp
//    Class:	TDayCent
//    Function: CInStateVars, CInSoilStateVars
//
//    Description:
//
//    CInStateVars:  Returns the sum of carbon in all state variables
//    CInSoilStateVars:  Returns the sum of carbon in soil variables,
//      including surface and soil components.
//
//    Author: Melannie Hartman, melannie@NREL.colostate.edu, Oct2001
// ----------------------------------------------------------------------------
//    History:
// ----------------------------------------------------------------------------
//    Copyright 2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TDayCent.h"

float TDayCent::CInStateVars(
    short iso) const
{
    Assert ((iso == UNLABL) || (iso == LABELD));
    float soilCarbon = CInSoilStateVars(iso);
    float totalCarbon
        = soilCarbon
        + cropC.aglcis[iso] + cropC.bglcis[iso] + cropC.stdcis[iso]
        + forestC.rlvcis[iso] + forestC.frtcis[iso]
        + forestC.rlwcis[iso] + forestC.fbrcis[iso] + forestC.crtcis[iso]
        + forestC.wd1cis[iso] + forestC.wd2cis[iso] + forestC.wd3cis[iso]
        + soilC.csrsnk[iso];
    return (totalCarbon);
}

float TDayCent::CInSoilStateVars(
    short iso) const
{
    Assert ((iso == UNLABL) || (iso == LABELD));
    float soilCarbon
        = som1ci_ref(SRFC, iso) + som1ci_ref(SOIL, iso)
        + soilC.som2ci[iso] + soilC.som3ci[iso]
        + strcis_ref(SRFC, iso) + strcis_ref(SOIL, iso)
        + metcis_ref(SRFC, iso) + metcis_ref(SOIL, iso);
    return soilCarbon;
}


