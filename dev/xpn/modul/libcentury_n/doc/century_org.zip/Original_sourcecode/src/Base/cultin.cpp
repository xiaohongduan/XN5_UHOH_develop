// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  cultin.cpp
//	Class:	  TCentury
//	Function: GetCultivation
//
//	Description:
//	Retrieves a cultivation parameter set.
//	Returns true if successful match in database, else false if not.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jun98
// ----------------------------------------------------------------------------
//	History:
//	Jul01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to use new TEventDBList class.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "TEventDBList.h"
#include "util.h"
#include "constants.h"

MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::GetCultivation (
	char const* cultToMatch)
{
	// error checks
	if ( !cultToMatch || !(*cultToMatch) )		// anything there?
		return false;

	// get the option set
	TEventOptionSet const & optionSet =
		*paramDbList->Get (TEventDBList::DBI_Cult);
	if ( !&optionSet )				// database not there?
		ThrowCentException (TCentException::CE_NSPPDB,
			::eventName[ET_Cultivate]);
	if ( !optionSet.GetOptionCount () )		// empty database?
		ThrowCentException (TCentException::CE_EMPPDB,
			::eventName[ET_Cultivate]);

	// get the option matching the parameter string
    	TEventOption const * const option = optionSet.GetOption (cultToMatch);
	if ( !option )					// match found?
		return false;

	// retrieve values from option and save in Century's variables
	/*
		what to get - in order:
		parcp.cultra[0] to [6] - count = 7
		parcp.clteff[0] to [3] - count = 4
		total = 11
	*/
	short const numParams = 11;			// total for an option
	short count = option->GetParamCount ();
	if ( count != numParams )			// counts match?
		ThrowCentException (TCentException::CE_OPCBAD,
			::eventName[ET_Cultivate]);

	register short k = 0;			// index to Century arrays
	for (short i = 0; i < count; i++)	// for each parameter...
		if ( i <= 6 )
		{
			parcp.cultra[k] = option->GetParameter(i)->GetValue();
			// error checks
			Assert (parcp.cultra[k] >= 0.0f);
			Assert (parcp.cultra[k] <= 1.0f);
			++k;
		}
		else
		{
			if ( i == 7 )
				k = 0;
			parcp.clteff[k] = option->GetParameter(i)->GetValue();
			// error checks
			Assert (parcp.clteff[k] >= CLTEFF_MIN);
			Assert (parcp.clteff[k] <= CLTEFF_MAX);
			++k;
		}

	// save option name in Century class variable
	strcpy (sched->curCult, cultToMatch);
	return true;
}	/* GetCultivation */
