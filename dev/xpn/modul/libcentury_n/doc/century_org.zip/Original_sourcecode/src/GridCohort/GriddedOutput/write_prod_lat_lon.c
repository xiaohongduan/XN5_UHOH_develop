
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Rewrite the prod.nc netCDF file using COARDS standards */
/* The original file was organized variable(cell, time) */
/* The new file is organized variable(time, lat, lon) */

#include <stdio.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf_ll.h"

    int write_prod_ll_(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  agcprd_vals[MAXCELLS], bgcprd_vals[MAXCELLS], rlvprd_vals[MAXCELLS],
             frtprd_vals[MAXCELLS], fbrprd_vals[MAXCELLS], rlwprd_vals[MAXCELLS],
             crtprd_vals[MAXCELLS];
      int status;
      int oldprodid;
      int oldagcprdid, oldbgcprdid, oldrlvprdid, oldfrtprdid, oldfbrprdid,
          oldrlwprdid, oldcrtprdid;
      int ii, jj, ngrids;

      /* Open old version of prod.nc file */
      status = nc_open("prod.nc", NC_NOWRITE, &oldprodid);
      if (status != NC_NOERR) handle_error("nc_open(prod.nc)", status);

      /* Get the indices for the prod output variables */
      status = nc_inq_varid(oldprodid, "agcprd", &oldagcprdid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for agcprd",status);
      status = nc_inq_varid(oldprodid, "bgcprd", &oldbgcprdid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for bgcprd",status);
      status = nc_inq_varid(oldprodid, "rlvprd", &oldrlvprdid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for rlvprd",status);
      status = nc_inq_varid(oldprodid, "frtprd", &oldfrtprdid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for frtprd",status);
      status = nc_inq_varid(oldprodid, "fbrprd", &oldfbrprdid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for fbrprd",status);
      status = nc_inq_varid(oldprodid, "rlwprd", &oldrlwprdid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for rlwprd",status);
      status = nc_inq_varid(oldprodid, "crtprd", &oldcrtprdid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for crtprd",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        agcprd_vals[ii] = fill;
        bgcprd_vals[ii] = fill;
        rlvprd_vals[ii] = fill;
        frtprd_vals[ii] = fill;
        fbrprd_vals[ii] = fill;
        rlwprd_vals[ii] = fill;
        crtprd_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the prod output file */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldprodid, oldagcprdid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for agcprd",status);
            }
            agcprd_vals[jj] = val;
            status = nc_get_var1_float(oldprodid, oldbgcprdid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for bgcprd",status);
            }
            bgcprd_vals[jj] = val;
            status = nc_get_var1_float(oldprodid, oldrlvprdid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for rlvprd",status);
            }
            rlvprd_vals[jj] = val;
            status = nc_get_var1_float(oldprodid, oldfrtprdid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for frtprd",status);
            }
            frtprd_vals[jj] = val;
            status = nc_get_var1_float(oldprodid, oldfbrprdid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for fbrprd",status);
            }
            fbrprd_vals[jj] = val;
            status = nc_get_var1_float(oldprodid, oldrlwprdid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for rlwprd",status);
            }
            rlwprd_vals[jj] = val;
            status = nc_get_var1_float(oldprodid, oldcrtprdid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for crtprd",status);
            }
            crtprd_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(prodll_ncid, agcprdll_id, start, count, agcprd_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for agcprd",status);
        status = nc_put_vara_float(prodll_ncid, bgcprdll_id, start, count, bgcprd_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for bgcprd",status);
        status = nc_put_vara_float(prodll_ncid, rlvprdll_id, start, count, rlvprd_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for rlvprd",status);
        status = nc_put_vara_float(prodll_ncid, frtprdll_id, start, count, frtprd_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for frtprd",status);
        status = nc_put_vara_float(prodll_ncid, fbrprdll_id, start, count, fbrprd_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for fbrprd",status);
        status = nc_put_vara_float(prodll_ncid, rlwprdll_id, start, count, rlwprd_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for rlwprd",status);
        status = nc_put_vara_float(prodll_ncid, crtprdll_id, start, count, crtprd_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for crtprd",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldprodid);

      return 0;
    }
