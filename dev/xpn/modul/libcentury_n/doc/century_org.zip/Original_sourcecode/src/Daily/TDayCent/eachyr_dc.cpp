// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  eachyr.cpp
//	Class:	  TDayCent
//	Function: StartOfYearTasks
//
//	Description:
//	Perform tasks that only need to be done once a year.
// ----------------------------------------------------------------------------
//	History:
//      See Century/eachyr.cpp
//      May01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Made this function a TDayCent function, formerly a TCentury function
//      * Added parcp.a2drat[*], parfs.a2drat[*] initializations
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TDayCent.h"
#include <cmath>

void TDayCent::StartOfYearTasks ()
{
    ResetAnnualAccum ();
    // initial the annual weather;
    // If at the start of a block, then the block's first year's data
    // has already been obtained when the block was loaded at the end of
    // the last simulation iteration.
    if ( !st->IsBlockStart() )
	    weather->InitAnnualData (
		sched->GetActiveInstance()->weatherSource, (char*)0);
    if ( sched->GetActiveInstance()->weatherSource == WS_FileRewind )
    {
    	// weather->AdvanceToYear (st->year);
	// only rewind once this block
	TManagementInst * const inst =
		const_cast<TManagementInst * const>(
			sched->GetActiveInstance () );
	inst->weatherSource = WS_FileContinue;
	sched->SetActiveInstance (inst);
    }

    // Wet-dry fixation of N
    // Determine annual total precipitation and annual total PET
    wt.prcann = weather->MeanAnnualPrecip ();
    wt.petann = 0.0f;
    for (short month = 1; month <= MPY; ++month)
    {
	wt.petann += monthlyPET.PET (
		siteEnv.GetLatitude(),
		fixed.fwloss[3],		// PET loss factor
		weather->TempMin(month),
		weather->TempMax(month),
		weather->MinAnnualMeanTemp(),
		weather->MaxAnnualMeanTemp()
		/* elevation defaults to 0 */ );
    }

    // N fixation in atmosphere
    nps.wdfxa = param.epnfa[INTCPT] +
    		param.epnfa[SLOPE] * std::min (wt.prcann, 80.0f);
    if (nps.wdfxa < 0.0f)
	nps.wdfxa = 0.0f;
    nps.wdfxs = param.epnfs[INTCPT] +
    		param.epnfs[SLOPE] * std::min (wt.prcann, 100.0f);
    if (nps.wdfxs < 0.0f)
	nps.wdfxs = 0.0f;
    nps.wdfx = nps.wdfxa + nps.wdfxs;

    // Atmospheric S deposition
    param.satmt = std::max (0.0f,
    			    param.satmos[0] + param.satmos[1] * wt.prcann);

    // Determine what fraction of the carbon in new plant tissue is labeled
    if (param.labtyp == Lbl_None)
	param.cisofr =  param.cisotf = 0.0f;

    else if (param.labtyp == Lbl_14C)
	param.cisofr = param.cisotf = c14->GetFraction14C (st->year);

    //
    else if (param.labtyp == Lbl_13C)
    {
   	// GetCrop has set cisofr
	// GetTree has set cisotf
    }

    // Initialize co2 effects
    AtmCO2Effect (st->time);
    // Added effect of co2 for forest; done here because not calcualted
    // dynamically based on biomass like grassland/crop
    // Direct CO2 effects only C/E ratio of leaves.
    for (short e = 0; e < site.nelem; ++e)		// for N, P, S
    {
	ccefor_ref (0, LEAF, e) =
		cerfor_ref (0, LEAF, e) * co2cce_ref (FORSYS, 0, e);
	ccefor_ref (1, LEAF, e) =
		cerfor_ref (1, LEAF, e) * co2cce_ref (FORSYS, 1, e);
    }
    for (short part = FROOT; part < FPARTS; ++part)
	for (short e = 0; e < site.nelem; ++e)
	{
	    ccefor_ref (0, part, e) = cerfor_ref (0, part, e);
	    ccefor_ref (1, part, e) = cerfor_ref (1, part, e);
	}

    // Calculate leaf death rate multiplier for continuous forests 11/20/92
    // Initialize LDRMLT to 1.0
    parfs.ldrmlt = 1.0f;

    // Change leaf death rate multiplier if you have floating C/E ratios.
    if (ccefor_ref (0, LEAF, N) != ccefor_ref (1, LEAF, N))
    {
	if (forestC.rleavc > 0.0f)
	{
	    Assert (forestC.rleavc != 0.0f);
	    register float lfncon = nps.rleave[N] / forestC.rleavc;
	    Assert (ccefor_ref (0, LEAF, N) != 0.0f);
	    register float lfncmin = 1.0f / ccefor_ref (0, LEAF, N);
	    Assert (ccefor_ref (1, LEAF, N) != 0.0f);
	    register float lfncmax = 1.0f / ccefor_ref (1, LEAF, N);
	    Assert (lfncmax != lfncmin);
	    parfs.ldrmlt = 1.0f + (parfs.maxldr - 1.0f) * (lfncon - lfncmin) /
			    (lfncmax - lfncmin);
	}
    }
    if (!sysType.IsForest())
    {
	// Determine fraction of plant residue added this year that is lignin.
	PlantLigninFraction ();
    }
    for ( short element = 0; element < site.nelem; ++element )
        parcp.a2drat[element] = parfs.a2drat[element] = 1.0f;
    gpp.mRespAnn[CRPSYS] = 0.0f;
    gpp.mRespAnn[FORSYS] = 0.0f;
}

