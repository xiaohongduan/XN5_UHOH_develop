
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  nremvll_ncid;			/* netCDF id */

/* variable ids */
int  shremnll_id, sdremnll_id, rlvremnll_id, fbrremnll_id, rlwremnll_id, 
     wd1remnll_id, wd2remnll_id, stremnll_id, metrmnll_id, fstgrmnll_id;
int  timell_id, lat_id, lon_id;

/* create nremv.nc */
int
nremvdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
            float *opltim, float *qtime) {

   int   status, istart_year, iend_year, ii;
   float fill, fstart_year, fend_year;
   char  timeunits[25], temp[5];

   /* dimension ids */
   int  time_dim = 0;
   int  lat_dim = 0;
   int  lon_dim = 0;

   /* variable shapes */
   int dims[3];

   /* Set fill, start_year, and end_year values */
   fill = NC_FILL_FLOAT;
   fstart_year = *opltim;
   fend_year = *qtime - 1;
   istart_year = fstart_year;
   iend_year = fend_year;

   for (ii = 0; ii < 25; ii++) {
     timeunits[ii] = '\0';
   }
   /* Get the start time for the time definition */
   sprintf(temp, "%d", istart_year); 
   strcat(timeunits, "days since ");
   strcat(timeunits, temp);
   strcat(timeunits, "-01-01");

   /* enter define mode */
   status = nc_create("nremvll.nc", NC_CLOBBER, &nremvll_ncid);
   if (status != NC_NOERR) handle_error("nc_create(nremv.nc)", status);

   /* define dimensions */
   status = nc_def_dim(nremvll_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(nremvll_ncid, "lat", (size_t) *nlat, &lat_dim);
   status = nc_def_dim(nremvll_ncid, "lon", (size_t) *nlon, &lon_dim);

   /* define variables */

   dims[0] = time_dim;
   status = nc_def_var (nremvll_ncid, "time", NC_INT, 1, dims, &timell_id);

   dims[0] = lat_dim;
   status = nc_def_var (nremvll_ncid, "lat", NC_FLOAT, 1, dims, &lat_id);

   dims[0] = lon_dim;
   status = nc_def_var (nremvll_ncid, "lon", NC_FLOAT, 1, dims, &lon_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nremvll_ncid, "shremn", NC_FLOAT, 3, dims, &shremnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nremvll_ncid, "sdremn", NC_FLOAT, 3, dims, &sdremnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nremvll_ncid, "rlvremn", NC_FLOAT, 3, dims, &rlvremnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nremvll_ncid, "fbrremn", NC_FLOAT, 3, dims, &fbrremnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nremvll_ncid, "rlwremn", NC_FLOAT, 3, dims, &rlwremnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nremvll_ncid, "wd1remn", NC_FLOAT, 3, dims, &wd1remnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nremvll_ncid, "wd2remn", NC_FLOAT, 3, dims, &wd2remnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nremvll_ncid, "stremn", NC_FLOAT, 3, dims, &stremnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nremvll_ncid, "metrmn", NC_FLOAT, 3, dims, &metrmnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nremvll_ncid, "fstgrmn", NC_FLOAT, 3, dims, &fstgrmnll_id);

   /* assign attributes */
   status = nc_put_att_text (nremvll_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (nremvll_ncid, timell_id, "long_name", strlen("Time"), "Time");
   status = nc_put_att_text (nremvll_ncid, timell_id, "units", strlen(timeunits), timeunits);
   status = nc_put_att_text (nremvll_ncid, timell_id, "time_step", strlen("monthly"), "monthly");
   status = nc_put_att_text (nremvll_ncid, timell_id, "calendar", strlen("gregorian"), "gregorian");
   status = nc_put_att_int (nremvll_ncid, timell_id, "start_year", NC_INT, 1, &istart_year);
   status = nc_put_att_int (nremvll_ncid, timell_id, "end_year", NC_INT, 1, &iend_year);

   status = nc_put_att_text (nremvll_ncid, lat_id, "long_name", strlen("Latitude"), "Latitude");
   status = nc_put_att_text (nremvll_ncid, lat_id, "units", strlen("degrees_north"), "degrees_north");
   status = nc_put_att_text (nremvll_ncid, lat_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (nremvll_ncid, lat_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (nremvll_ncid, lon_id, "long_name", strlen("Longitude"), "Longitude");
   status = nc_put_att_text (nremvll_ncid, lon_id, "units", strlen("degrees_east"), "degrees_east");
   status = nc_put_att_text (nremvll_ncid, lon_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (nremvll_ncid, lon_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (nremvll_ncid, shremnll_id, "long_name", 
	strlen("above_ground_live_nitrogen_removed"), "above_ground_live_nitrogen_removed");
   status = nc_put_att_text (nremvll_ncid, shremnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(nremvll_ncid, shremnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nremvll_ncid, sdremnll_id, "long_name", 
	strlen("standing_dead_nitrogen_removed"), "standing_dead_nitrogen_removed");
   status = nc_put_att_text (nremvll_ncid, sdremnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(nremvll_ncid, sdremnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nremvll_ncid, rlvremnll_id, "long_name", 
	strlen("live_leaf_nitrogen_removed"), "live_leaf_nitrogen_removed");
   status = nc_put_att_text (nremvll_ncid, rlvremnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(nremvll_ncid, rlvremnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nremvll_ncid, fbrremnll_id, "long_name", 
	strlen("live_fine_branch_nitrogen_removed"), "live_fine_branch_nitrogen_removed");
   status = nc_put_att_text (nremvll_ncid, fbrremnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(nremvll_ncid, fbrremnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nremvll_ncid, rlwremnll_id, "long_name", 
	strlen("live_large_wood_nitrogen_removed"), "live_large_wood_nitrogen_removed");
   status = nc_put_att_text (nremvll_ncid, rlwremnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(nremvll_ncid, rlwremnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nremvll_ncid, wd1remnll_id, "long_name", 
	strlen("dead_fine_branch_nitrogen_removed"), "dead_fine_branch_nitrogen_removed");
   status = nc_put_att_text (nremvll_ncid, wd1remnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(nremvll_ncid, wd1remnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nremvll_ncid, wd2remnll_id, "long_name", 
	strlen("dead_large_wood_nitrogen_removed"), "dead_large_wood_nitrogen_removed");
   status = nc_put_att_text (nremvll_ncid, wd2remnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(nremvll_ncid, wd2remnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nremvll_ncid, stremnll_id, "long_name", 
	strlen("surface_structural_nitrogen_removed"), "surface_structural_nitrogen_removed");
   status = nc_put_att_text (nremvll_ncid, stremnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(nremvll_ncid, stremnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nremvll_ncid, metrmnll_id, "long_name", 
	strlen("surface_metabolic_nitrogen_removed"), "surface_metabolic_nitrogen_removed");
   status = nc_put_att_text (nremvll_ncid, metrmnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(nremvll_ncid, metrmnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nremvll_ncid, fstgrmnll_id, "long_name", 
	strlen("retranslocated_nitrogen_removed"), "retranslocated_nitrogen_removed");
   status = nc_put_att_text (nremvll_ncid, fstgrmnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(nremvll_ncid, fstgrmnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   /* leave define mode */
   status = nc_enddef (nremvll_ncid);
   return 0;
}
