// ----------------------------------------------------------------------------
//	Copyright 1998-2000 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//    Project:  Century Soil Organic Matter Model, daily version
//    File:	soiltransp.cpp
//    Class:	TDayCentSoil
//    Function: SoilTranspiration
//
//    Description:
//    Transpire water from soil
// ----------------------------------------------------------------------------
//    Author: Melannie Hartman, Bill Parton
//    History:
//    Apr1992  Susan L. Chaffee
//    * Created original soiltransp.f
//    Sep1993  Melannie Hartman, melannie@NREL.colostate.edu
//    * Translated soiltransp.f to soiltransp.c
//    Apr2001	 Melannie Hartman, melannie@NREL.colostate.edu
//    * Translated soiltransp.c to soiltransp.cpp
//	Nov02   Tom Hilinski, tom.hilinski@colostate.edu
//	* Misc. clean up, const-correctness, optimization.
//	Dec02   Tom Hilinski
//	* Removed duplicate swcMin array.
//	* Convert to use arraytypes.h for arrays
//	Jan04	Tom Hilinski
//	* Soil water potential array is now passed into the function.
//	Apr05	Tom Hilinski
//	* Transpiration is now limited to the rooting depth (nlaypg in Century).
// ----------------------------------------------------------------------------

#include "TDayCentSoil.h"
#include "TDayCent.h"
#include "precision.h"
#include "AssertEx.h"
using namespace std;

void TDayCentSoil::SoilTranspiration (
    float const potentialTransp, // potential transpiration rate (cm H2O/day)
    float const tcoeff[MAXLYR],  // transpiration coefficients of lyrs (frac)
				//    (fixed.awtl)
    T1DFloatArray & transp,	// actual transp rate from each lyr (cm H2O/day)
    float & actualTransp)	// total actual transpiration rate from all
				//  lyrs (cm H2O/day)
{
    // check function parameters
    Assert ( potentialTransp > 0.0f );

    // Get rooting depth
    TDayCent const & dayCent = dynamic_cast<TDayCent const &>(owner);
    size_type const rootDepthLayer =
	( dayCent.GetSystemType().IsCropGrass() ?
	  dayCent.GetRootDepthLayerCrop() :
	  dayCent.GetRootDepthLayerTree() ) - 1;

    // ratio of transpiration coefficient to soil water potential
    T1DFloatArray swpfrac ( GetLayerCount() ); // but only use to rootDepthLayer
    swpfrac = 0.0f;

    // re-initialize soil water potentials
    for (unsigned short layer = 0; layer <= rootDepthLayer; layer++)
    {
	Assert (soilWaterPotential(layer) > 0.0f);
	float const awtl =
		( layer < MAXLYR ? tcoeff[layer] : tcoeff[MAXLYR - 1] );
	swpfrac(layer) = awtl / soilWaterPotential(layer);
    }
    // sum of swpfrac over all layers (bars > 0)
    float sumswpf = ARRAY_SUM(swpfrac);
    Assert ( sumswpf > 0.0f );

    // calculate transpiration
    // For each layer, multiply potential transpiration by
    // the weighted average of soilwater potential.
    transp = swpfrac / sumswpf * (double) potentialTransp;
    for (unsigned short layer = 0; layer <= rootDepthLayer; layer++)
    {
	//  Check if amount of traspiration from the layer is going
	//  to bring it below its minimum soilwater content.
	//  Adjust transp(layer) if necessary.
	Assert ( transp(layer) >= 0.0f );
	if ( WaterContent(layer) < swcMin(layer) )
	{
	    // not enough water, so no transpiration
	    transp(layer) = 0.0f;
	}
	else if ( WaterContent(layer) - transp(layer) < swcMin(layer) )
	{
	    // have transpiration: limit to the available water
	    transp(layer) = std::max (
		0.0,
		WaterContent(layer) - swcMin(layer) );
	    WaterContent(layer) -= transp(layer);
	}
    }
    actualTransp = ARRAY_SUM(transp);

    // Does actual transpiration exceed potential transpiration?
    if ( actualTransp > potentialTransp &&
	 AmountIsSignificant(actualTransp - potentialTransp) )
    {
	Assert (!AmountIsSignificant(actualTransp - potentialTransp, 1.0e-5f));
	// To Do: handle AET > PET
    }
}

//--- end of file ---
