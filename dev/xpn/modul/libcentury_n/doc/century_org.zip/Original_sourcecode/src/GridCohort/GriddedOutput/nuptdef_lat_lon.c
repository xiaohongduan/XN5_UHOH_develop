
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  nuptll_ncid;			/* netCDF id */

/* variable ids */
int  agcnupll_id, bgcnupll_id, rlvnupll_id, frtnupll_id, fbrnupll_id, 
     rlwnupll_id, crtnupll_id;
int  timell_id, lat_id, lon_id;

void handle_error(char *funcname, int status);

/* create nupt.nc */
int
nuptdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
           float *opltim, float *qtime) {

   int   status, istart_year, iend_year, ii;
   float fill, fstart_year, fend_year;
   char  timeunits[25], temp[5];

   /* dimension ids */
   int  time_dim = 0;
   int  lat_dim = 0;
   int  lon_dim = 0;

   /* variable shapes */
   int dims[3];

   /* Set fill, start_year, and end_year values */
   fill = NC_FILL_FLOAT;
   fstart_year = *opltim;
   fend_year = *qtime - 1;
   istart_year = fstart_year;
   iend_year = fend_year;

   for (ii = 0; ii < 25; ii++) {
     timeunits[ii] = '\0';
   }
   /* Get the start time for the time definition */
   sprintf(temp, "%d", istart_year); 
   strcat(timeunits, "days since ");
   strcat(timeunits, temp);
   strcat(timeunits, "-01-01");

   /* enter define mode */
   status = nc_create("nuptll.nc", NC_CLOBBER, &nuptll_ncid);
   if (status != NC_NOERR) handle_error("nc_create(nupt.nc)", status);

   /* define dimensions */
   status = nc_def_dim(nuptll_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(nuptll_ncid, "lat", (size_t) *nlat, &lat_dim);
   status = nc_def_dim(nuptll_ncid, "lon", (size_t) *nlon, &lon_dim);

   /* define variables */

   dims[0] = time_dim;
   status = nc_def_var (nuptll_ncid, "time", NC_INT, 1, dims, &timell_id);

   dims[0] = lat_dim;
   status = nc_def_var (nuptll_ncid, "lat", NC_FLOAT, 1, dims, &lat_id);

   dims[0] = lon_dim;
   status = nc_def_var (nuptll_ncid, "lon", NC_FLOAT, 1, dims, &lon_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nuptll_ncid, "agcnup", NC_FLOAT, 3, dims, &agcnupll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nuptll_ncid, "bgcnup", NC_FLOAT, 3, dims, &bgcnupll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nuptll_ncid, "rlvnup", NC_FLOAT, 3, dims, &rlvnupll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nuptll_ncid, "frtnup", NC_FLOAT, 3, dims, &frtnupll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nuptll_ncid, "fbrnup", NC_FLOAT, 3, dims, &fbrnupll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nuptll_ncid, "rlwnup", NC_FLOAT, 3, dims, &rlwnupll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (nuptll_ncid, "crtnup", NC_FLOAT, 3, dims, &crtnupll_id);

   /* assign attributes */
   status = nc_put_att_text (nuptll_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (nuptll_ncid, timell_id, "long_name", strlen("Time"), "Time");
   status = nc_put_att_text (nuptll_ncid, timell_id, "units", strlen(timeunits), timeunits);
   status = nc_put_att_text (nuptll_ncid, timell_id, "time_step", strlen("monthly"), "monthly");
   status = nc_put_att_text (nuptll_ncid, timell_id, "calendar", strlen("gregorian"), "gregorian");
   status = nc_put_att_int (nuptll_ncid, timell_id, "start_year", NC_INT, 1, &istart_year);
   status = nc_put_att_int (nuptll_ncid, timell_id, "end_year", NC_INT, 1, &iend_year);

   status = nc_put_att_text (nuptll_ncid, lat_id, "long_name", strlen("Latitude"), "Latitude");
   status = nc_put_att_text (nuptll_ncid, lat_id, "units", strlen("degrees_north"), "degrees_north");
   status = nc_put_att_text (nuptll_ncid, lat_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (nuptll_ncid, lat_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (nuptll_ncid, lon_id, "long_name", strlen("Longitude"), "Longitude");
   status = nc_put_att_text (nuptll_ncid, lon_id, "units", strlen("degrees_east"), "degrees_east");
   status = nc_put_att_text (nuptll_ncid, lon_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (nuptll_ncid, lon_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (nuptll_ncid, agcnupll_id, "long_name", 
	strlen("above_ground_crop_N_uptake"), "above_ground_crop_N_uptake");
   status = nc_put_att_text (nuptll_ncid, agcnupll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(nuptll_ncid, agcnupll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nuptll_ncid, bgcnupll_id, "long_name", 
	strlen("below_ground_crop_N_uptake"), "below_ground_crop_N_uptake");
   status = nc_put_att_text (nuptll_ncid, bgcnupll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(nuptll_ncid, bgcnupll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nuptll_ncid, rlvnupll_id, "long_name", 
	strlen("leaf_N_uptake"), "leaf_N_uptake");
   status = nc_put_att_text (nuptll_ncid, rlvnupll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(nuptll_ncid, rlvnupll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nuptll_ncid, frtnupll_id, "long_name", 
	strlen("fine_root_N_uptake"), "fine_root_N_uptake");
   status = nc_put_att_text (nuptll_ncid, frtnupll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(nuptll_ncid, frtnupll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nuptll_ncid, fbrnupll_id, "long_name", 
	strlen("fine_branch_N_uptake"), "fine_branch_N_uptake");
   status = nc_put_att_text (nuptll_ncid, fbrnupll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(nuptll_ncid, fbrnupll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nuptll_ncid, rlwnupll_id, "long_name", 
	strlen("large_wood_N_uptake"), "large_wood_N_uptake");
   status = nc_put_att_text (nuptll_ncid, rlwnupll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(nuptll_ncid, rlwnupll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (nuptll_ncid, crtnupll_id, "long_name", 
	strlen("coarse_root_N_uptake"), "coarse_root_N_uptake");
   status = nc_put_att_text (nuptll_ncid, crtnupll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(nuptll_ncid, crtnupll_id, "_FillValue", NC_FLOAT, 1, &fill);

   /* leave define mode */
   status = nc_enddef (nuptll_ncid);
   return 0;
}
