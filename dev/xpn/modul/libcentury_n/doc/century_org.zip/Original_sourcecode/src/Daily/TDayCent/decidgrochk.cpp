// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  decidgrochk.cpp
//	Class:	  TDayCent
//	Function: StartDeciduousGrowth
//
//	Description:
//	Determines whether or not there is potential growth
//	and if it is the first month of the growing season.
//	Returns true if month of greenup in deciduous forests else false.
// ----------------------------------------------------------------------------
//	History:
//	06Jun01 Melannie Hartman, melannie@nrel.colostate.edu
//      * Modified TCentury::StartDeciduousGrowth() defined in grochk.cpp to
//        create TDayCent::DeciduousGreenUpPeriod()
// ----------------------------------------------------------------------------
//	Copyright 2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//      Notes:
//      * Assumes 4 WEEKLY time periods for deciduous greenup
//      * This routine assumes greenup will occur before day length
//        starts decreasing! -mdh 6/7/01
//	Jun02	Tom Hilinski
//	* Moved static local variable "startd" into Tparfs::startedDecidGrowth
//	* Moved static local variable "numGreenUpPeriods" to TDCStaticVars
// ----------------------------------------------------------------------------

#include "TDayCent.h"

bool TDayCent::DeciduousGreenUpPeriod (
    float tave)  // Average air temperature over a week or month
{
    bool retVal = false;

    // If this is the first year for this management block, reset STARTD.
    if ( st->IsBlockStart() )
    {
	parfs.startedDecidGrowth = false;
        staticVars.numGreenUpPeriods = 0;
    }

    // If it is spring and the temperature is high enough and
    // you haven't already reapportioned carbon to leaves...
    if ( IsDayIncreasing() &&
    	 !parfs.startedDecidGrowth &&
    	 tave > 10.0f )
    {
	retVal = true;
	parfs.startedDecidGrowth = true;
    }
    else if ( !IsDayIncreasing() )
    {
        parfs.startedDecidGrowth = false;
        staticVars.numGreenUpPeriods = 0;
    }

    // New block -mdh 6/6/01
    if ( parfs.startedDecidGrowth )
    {
       staticVars.numGreenUpPeriods++;
    }
    if ( staticVars.numGreenUpPeriods >= 1 &&
         staticVars.numGreenUpPeriods <= 4 )
    {
       retVal = true;
    }

    return retVal;
}


