
#include <stdlib.h>
#include "netcdf.h"
#include "wrtcdf.h"

void
syncit_(int *savall)
{
        int status;

	/* Synchronize all NetCDF files to disk */
	status = nc_sync (site_ncid);

	if (*savall == 1)
	{
		status = nc_sync (crop_ncid);
		status = nc_sync (h2o_ncid);
		status = nc_sync (livc_ncid);
		status = nc_sync (livn_ncid);
		status = nc_sync (nflux_ncid);
		status = nc_sync (nmnr_ncid);
		status = nc_sync (nupt_ncid);
		status = nc_sync (prod_ncid);
		status = nc_sync (resp_ncid);
		status = nc_sync (soilc_ncid);
		status = nc_sync (soiln_ncid);
		status = nc_sync (cremv_ncid);
		status = nc_sync (nremv_ncid);
	}

	return;
}
