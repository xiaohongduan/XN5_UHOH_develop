// ----------------------------------------------------------------------------
//	Copyright 1998-2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCmdLine.cpp
//	Class:	  TCenturyCmdLine
//
//	Description:
//	Class for processing command-line arguments for the Century model.
//	For a list of command-line options, see
//	TCenturyCmdLine::cmdLineHelpMsg.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Apr98
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TCmdLine.h"
#ifdef DAILY_CENTURY
  #include "version_dc.h"
#else
  #include "version.h"
#endif // DAILY_CENTURY
#include "TUserPref.h"
#include "charutil.h"
#include <sstream>
using namespace std;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

char const * const TCenturyCmdLine::cmdLineHelpMsg =
  "\n"
  "To run a "
  CenturyNickname
  " simulation, supply these arguments as needed:\n"
  "-s filename     (Required) Name of site parameter file.\n"
  "                To use a Century 4 site file, add extension \".100\"\n"
  "-m filename     (Required) Name of management file.\n"
  "                To use a Century 4 schedule file, add extension \".sch\"\n"
  "-o filename     Name of output file (omit extension).\n"
  "-tn or -ts      Output file type: netCDF (default) or ASCII spreadsheet.\n"
#ifdef DAILY_CENTURY
  "-t0             Do NOT produce monthly or daily output files.\n"
  "-td0            Do NOT produce daily output files.\n"
#else // monthly
  "-t0             Do NOT produce output files.\n"
#endif
  "-an, -ar, -aa   Output file access: New (default), Replace, or Append.\n"
  "-f filename\"   Use the Fix file name (with optional path) "
                     "supplied by the user.\n"
  "-fm filename    Use the Fix file of this name supplied with the model.\n"
  "-pp path        Find parameter files first in this path.\n"
  "-u \"user name\"  Your name (in quotes if using spaces)\n"
  "-i filename     Initialization file name and path.\n"
  "-sf filename    Write new site file at end of simulation with this name.\n"
  "-V              Display version information.\n"
  "-d?             Display debugging options.\n"
  "-?              Displays this help screen.\n"
  "\nExample:  "
  CenturyCommand
  " -s mySite -m myManagement -o myOutput -ts -ar -d1 -f myfix.100";

char const * const TCenturyCmdLine::cmdLineDebugHelpMsg =
  "\n"
  "Debugging Command-Line Options:\n"
  "-d1   Display total execution time.\n"
  "-d2   Display time to the screen at each write.\n"
  "-d3   Echo the command-line options.\n"
  "-d4   Display simulation time limits.\n"
  "-d5   Display verbose messages.\n"
  // "-d6   Do not display site and management warning messages.\n"
  "-da   Turn on all the debugging options.";

char const * const TCenturyCmdLine::optionList[ ] = // list of cmd-line options
{
	"-s",		// ISiteFile
	"-m",		// IMgmtFile
	"-o",		// IOutFile
	"-tn",		// IOutNetcdf
	"-ts",		// IOutSpread
	"-t0",		// IOutNone
#ifdef DAILY_CENTURY
	"-td0",		// IOutDailyNone
#endif
	"-an",		// IOutNew
	"-ar",		// IOutReplace
	"-aa",		// IOutAppend
	"-f",		// IUserFixFile
	"-fm",		// IModelFixFile
	"-pp",		// IParamPath
	"-u",		// IUserName
	"-i",		// IIniFile
	"-sf",		// IWriteSiteFile
	"-V", 		// IVersion
	"-?", 		// IHelp1
	"-help", 	// IHelp2
	"-d?",		// IDebugHelp
	"-d1",		// IExecTime
	"-d2",		// IWriteTime
	"-d3",		// IWriteCmdLine
	"-d4",		// ISimTimeLimits
	"-d5",		// IDebugVerbose
	"-d6",		// IDebugNoSMWarn
	"-da",		// IDebugAll
	0		// last one always!
};

enum indexOptionList	// indices into optionList
{
	ISiteFile,	// -s
	IMgmtFile,	// -m
	IOutFile,	// -o
	IOutNetcdf,	// -tn
	IOutSpread,	// -ts
	IOutNone,	// -t0
#ifdef DAILY_CENTURY
	IOutDailyNone,	// -td0
#endif
	IOutNew,	// -an
	IOutReplace,	// -ar
	IOutAppend,	// -aa
	IUserFixFile,	// -f
	IModelFixFile,	// -fm
	IParamPath,	// -pp
	IUserName,	// -u
	IIniFile,	// -i
	IWriteSiteFile,	// -sf
	IVersion,	// -V
	IHelp1,		// -?
	IHelp2,		// -help
	IDebugHelp,	// -d?
	IExecTime,	// -d1
	IWriteTime,	// -d2
	IWriteCmdLine,	// -d3
	ISimTimeLimits,	// -d4
	IDebugVerbose,	// -d5
	IDebugNoSMWarn,	// -d6
	IDebugAll,	// -da
	ILastOneAlways	// last one always!
};

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

TCenturyCmdLine::TCenturyCmdLine (
	short const argc,			// number of arguments
	char const * const * const argv,	// list of arguments
	nrel::century::CenturySimConfigInfo &
			useSimConfigInfo,	// configuration information
	bool suppressWarnings,			// suppress warning messages?
	bool requireSiteAndMgmt)		// require site & mgmt options?
	: TCmdLineBase (argc, argv),
	  simConfigInfo (useSimConfigInfo),
	  displayMessages (!suppressWarnings),
	  needSiteAndMgmt (requireSiteAndMgmt)
{
	Initialize ();
	if ( argc == 0 || !argv )		// anything there?
		error = true;
	else if ( ProcessArguments() )		// processed ok?
		terminate = true;
}

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	ProcessOption
//	Processes the current option.
void TCenturyCmdLine::ProcessOption (
	TArgListIterator const & beginArgList,
	TArgListIterator const & endArgList)
{
	++countOptionsUsed;			// be optimistic, and do once
	if ( *beginArgList == optionList[ ISiteFile ] &&
	     HaveNeededArgsForOption (beginArgList, endArgList, 2) )
	{
		std::string const siteFile = *(beginArgList + 1);
		simConfigInfo.SetSiteFileName (siteFile);
		CheckSiteName ();
	}
	else if ( *beginArgList == optionList[ IMgmtFile ] &&
		  HaveNeededArgsForOption (beginArgList, endArgList, 2) )
	{
		std::string const mgmtFile = *(beginArgList + 1);
		simConfigInfo.SetManagementFileName (mgmtFile);
		CheckMgmtName ();
	}
	else if ( *beginArgList == optionList[ IOutFile ] &&
		  HaveNeededArgsForOption (beginArgList, endArgList, 2) )
	{
		std::string const outputFile = *(beginArgList + 1);
		simConfigInfo.SetOutputFileName (outputFile);
	}
	else if ( *beginArgList == optionList[ IIniFile ] &&
		  HaveNeededArgsForOption (beginArgList, endArgList, 2) )
	{
		iniFile = *(beginArgList + 1);
		// CheckININame ();
	}
	else if ( *beginArgList == optionList[ IWriteSiteFile ] )
	{
		newSiteFile = *(beginArgList + 1);
	}
	else if ( *beginArgList == optionList[ IOutNetcdf] )
	{
		simConfigInfo.SetOutputType (TOutputBase::Type_NetCDF);
	}
	else if ( *beginArgList == optionList[ IOutSpread ] )
	{
		simConfigInfo.SetOutputType (TOutputBase::Type_CSV);
	}
	else if ( *beginArgList == optionList[ IOutNone ] )
	{
		simConfigInfo.SetProduceOutput (false);
	}
#ifdef DAILY_CENTURY
	else if ( *beginArgList == optionList[ IOutDailyNone ] )
	{
		doDailyOutput = false;;
	}
#endif
	else if ( *beginArgList == optionList[ IOutNew ] )
	{
		simConfigInfo.SetOutputAccess (TOutputBase::Mode_New);
	}
	else if ( *beginArgList == optionList[ IOutReplace ] )
	{
		simConfigInfo.SetOutputAccess (TOutputBase::Mode_Replace);
	}
	else if ( *beginArgList == optionList[ IOutAppend ] )
	{
		simConfigInfo.SetOutputAccess (TOutputBase::Mode_Append);
	}
	else if ( *beginArgList == optionList[ IUserFixFile ] )
	{
		std::string const fixFile = *(beginArgList + 1);
		simConfigInfo.SetFixFileName (fixFile);
	}
	else if ( *beginArgList == optionList[ IModelFixFile ] )
	{
		std::string fixFile = *(beginArgList + 1);
		//  prefix fixFile with path to installation directory
		TEH::TFileName fileName (fixFile, TEH::TFileName::FT_Normal);
		fileName.SetPath (exePath);
		fixFile = fileName.GetFullName ();
		simConfigInfo.SetFixFileName (fixFile);
	}
	else if ( *beginArgList == optionList[ IParamPath ] )
	{
		TStringArray parametersPath;
		parametersPath.push_back ( *(beginArgList + 1) );
		simConfigInfo.SetParameterSearchPaths (parametersPath);
	}
	else if ( *beginArgList == optionList[ IUserName ] &&
		  HaveNeededArgsForOption (beginArgList, endArgList, 2) )
	{
		std::string const userName = *(beginArgList + 1);
		simConfigInfo.SetUserName (userName);
	}
	else if ( *beginArgList == optionList[ IVersion ] )
	{
	    	std::string msg;
	    	msg = CenturyName;
	    	msg += '\n';
	    	msg += CenturyVersion;
	    	msg += "\nOperating system: ";
	    	msg += PLATFORM_NAME;
		WriteMessage ( msg );
		terminate = true;
	}
	else if ( *beginArgList == optionList[ IHelp1 ] ||
		  *beginArgList == optionList[ IHelp2 ] )
	{
		WriteMessage ( GetCmdLineHelpStr() );
		terminate = true;
	}
	else if ( *beginArgList == optionList[ IDebugHelp ] )
	{
		WriteMessage ( GetCmdLineDebugHelpStr() );
		terminate = true;
	}
	else if ( *beginArgList == optionList[ IExecTime ] )
	{
		dbgInfo.execTime = true;
	}
	else if ( *beginArgList == optionList[ IWriteTime ] )
	{
		dbgInfo.writeTime = true;
	}
	else if ( *beginArgList == optionList[ IWriteCmdLine ] )
	{
		dbgInfo.echoArgs = true;
		WriteCmdLine ();
	}
	else if ( *beginArgList == optionList[ ISimTimeLimits ] )
	{
		dbgInfo.writeTimeDetails = true;
	}
	else if ( *beginArgList == optionList[ IDebugVerbose ] )
	{
		dbgInfo.verbose = true;
	}
	else if ( *beginArgList == optionList[ IDebugNoSMWarn ] )
	{
		dbgInfo.noWarnings = true;
	}
	else if ( *beginArgList == optionList[ IDebugAll ] )
	{
		dbgInfo.execTime = true;
		dbgInfo.writeTime = true;
		dbgInfo.writeTimeDetails = true;
		dbgInfo.echoArgs = true;
		WriteCmdLine ();
		dbgInfo.verbose = true;
		dbgInfo.noWarnings = true;
	}
	else
	{
		--countOptionsUsed;	// wrong! misplaced optimism
		if (displayMessages)
		{
	    		std::string msg;
	    		msg = "An unknown command-line option ";
	    		msg += "was found and ignored.\n";
	    		msg += "The option is: ";
	    		msg += *beginArgList;
			WriteMessage ( msg );
	    	}
	}
}

//	ProcessArguments
//	Parses the command line arguments and saves the information.
//	Returns false if all required args are specified, else true if not.
//	Notes:
//	Sets 2 messages - (1) error in the arguments; (2) terminate execution.
//	Also, counts the number of args used = number of valid arguments.
bool TCenturyCmdLine::ProcessArguments ()
{
	if ( Size() >= 1 )		// executable arg available?
	{
		TEH::TFileName exeFN (argList[0], TEH::TFileName::FT_Normal);
		exePath = exeFN.GetFullPath ();
	}

	if ( Size() <= 1 )		// any command-line args to process?
	{
		if (displayMessages)
			WriteMessage ( GetCmdLineHelpStr() );
		return true;
	}
	// process each argument
	if ( indexList.size() > 0 )
	{
	    TIndexListIterator iIndex = indexList.begin();
	    TIndexListIterator const iLastIndex = indexList.end() - 1;
	    while ( iIndex < iLastIndex )
	    {
		ProcessOption ( *iIndex, *(iIndex + 1) );
		++iIndex;
	    }
	}
	// return status
	error =
	    ( (TIndexList::size_type)countOptionsUsed != indexList.size() - 1 );
	// required for the command-line version:
	if ( !terminate &&
	     ( needSiteAndMgmt &&
	       ( simConfigInfo.GetSiteFileName().empty() ||
		 simConfigInfo.GetManagementFileName().empty() ) ) )
	{
		if (displayMessages)
		    WriteMessage (
			"A required command-line option was not specified." );
		error = true;
	}
	return error;
}

//	CheckSiteName
//	Adds the site file netCDF suffic & extension to the name, if necessary.
void TCenturyCmdLine::CheckSiteName ()
{
	char const * const C4Extension = "100";
	char const * const ncSuffix = "-st";
	char const * const ncExtension = "nc";

	TEH::TFileName siteFileName (
		simConfigInfo.GetSiteFileName(),
		TEH::TFileName::FT_Normal );
	if ( siteFileName.GetExtension() == C4Extension )
	{
		return;				// ...is a Century 4 site file
	}
	else if ( siteFileName.GetExtension() == ncExtension )
	{
		std::string const & name = siteFileName.GetName();
		if ( name.size() >= 3 &&
		     name.substr( name.size() - 3 ) == ncSuffix )
		{
			return;			// ...is a netCDF site file
		}
	}

	// ...unknown file type
	// assume should be a netCDF site file, so add the suffix and extension
	siteFileName.SetExtension (ncExtension);
	std::string name = siteFileName.GetName();
	name += ncSuffix;
	siteFileName.SetName (name);
	// replace original
	simConfigInfo.SetSiteFileName ( siteFileName.GetFullName() );
}

//	CheckMgmtName
//	Adds the mgmt. file suffix and netCDF extension to the name.
void TCenturyCmdLine::CheckMgmtName ()
{
	char const * const C4Extension = "sch";
	char const * const ncSuffix[] = { "-s", "-d", "-i" };
	char const * const ncExtension = "nc";

	TEH::TFileName mgmtFileName (
		simConfigInfo.GetManagementFileName(),
		TEH::TFileName::FT_Normal );
	if ( mgmtFileName.GetExtension() == C4Extension )
	{
		return;				// ...is a Century 4 mgmt file
	}
	else if ( mgmtFileName.GetExtension() == ncExtension )
	{
		std::string const & name = mgmtFileName.GetName();
		for ( short i = 0; i < 3; ++i )
		{
		    if ( name.size() >= 2 &&
			 name.substr( name.size() - 2 ) == ncSuffix[i] )
		    {
			return;			// ...is a netCDF mgmt file
		    }
		}
	}

	// ...unknown file type
	// assume should be a netCDF site file, so add the suffix and extension
	mgmtFileName.SetExtension (ncExtension);
	std::string name = mgmtFileName.GetName();
	name += ncSuffix[0];
	mgmtFileName.SetName (name);
	// replace original
	simConfigInfo.SetManagementFileName ( mgmtFileName.GetFullName() );
}

//	WriteCmdLine
void TCenturyCmdLine::WriteCmdLine ()
{
	WriteMessage (argList[0]);
	if ( !indexList.empty() )
	{
		short const maxLineLength = 78;
		char const * const linePrefix = "  ";
		char const blank = ' ';
		std::string line = linePrefix;
		bool noBlank = true;
		for ( short i = 0; i < GetOptionCount(); ++i )
		{
		    std::string const & optionString = GetOptionString(i);
		    short const length = line.size() + optionString.size();
		    if ( length <= maxLineLength )
		    {
			if ( noBlank )
				noBlank = false;
			else
				line += blank;
			line += optionString;
		    }
		    else
		    {
			WriteMessage ( line );
			line = linePrefix;
			line += optionString;
		    }
		}
		WriteMessage ( line );
	}
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

void TCenturyCmdLine::Initialize ()
{
	countOptionsUsed = 0;
	error = terminate = false;
#ifdef DAILY_CENTURY
	doDailyOutput = true;
#endif
}

void TCenturyCmdLine::Copy (				// Copy to this
	TCenturyCmdLine const & object)
{
	if ( &object )
	{
		//--- data: internal
		countOptionsUsed = object.countOptionsUsed;
		error = object.error;
		terminate = object.terminate;
		displayMessages = object.displayMessages;
		needSiteAndMgmt = object.needSiteAndMgmt;

		//--- data: command-line
		exePath = object.exePath;
		iniFile = object.iniFile;
		newSiteFile = object.newSiteFile;
#ifdef DAILY_CENTURY
		doDailyOutput = object.doDailyOutput;
#endif
		dbgInfo = object.dbgInfo;
	}
}

//--- end of definitions for TCenturyCmdLine ---
