
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include "netcdf.h"
#include "wrtcdf.h"

void handle_error(char *funcname, int status);

void
wrtmask_(int *outcol, int *outrow, int *simgo, int *cellpos)
{
	static size_t	mstart[2]={0, 0};
	size_t 		mcount[2]={1, 1};
	static int      cellNo = 1;
	int             maskNo;
        int             status;

	mstart[0] = (size_t) *outrow;
	mstart[1] = (size_t) *outcol;

/*        printf("wrtmask_util: simgo = %1d  cellpos = %1d", *simgo, *cellpos); 
        printf("  cellNo = %1d  outrow = %1d  outcol = %1d\n", cellNo, *outrow, *outcol); */

	if (*simgo >= 1) 
	   maskNo = 0;
        else
           maskNo = *cellpos;

	status = nc_put_vara_int(site_ncid, mask_id, mstart, mcount, &maskNo);
        if (status != NC_NOERR) handle_error("nc_put_vara_int(wrtmask)", status);

	if (*simgo == 0) cellNo +=1;

	return;
}
