
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include "netcdf.h"
#include "wrtcdf.h"

int
write_resp(float resp[][12])
{
        int status;
        float *p = (float *) resp;

	/* Write output to NetCDF file */
	status = nc_put_vara_float(resp_ncid, s11c2_id, start, count, p);
	status = nc_put_vara_float(resp_ncid, s21c2_id, start, count, p + 12);
	status = nc_put_vara_float(resp_ncid, s2c2_id, start, count, p + 24);
	status = nc_put_vara_float(resp_ncid, s3c2_id, start, count, p + 36);
	status = nc_put_vara_float(resp_ncid, st1c2_id, start, count, p + 48);
	status = nc_put_vara_float(resp_ncid, st2c2_id, start, count, p + 60);
	status = nc_put_vara_float(resp_ncid, mt1c2_id, start, count, p + 72);
	status = nc_put_vara_float(resp_ncid, mt2c2_id, start, count, p + 84);
	status = nc_put_vara_float(resp_ncid, wd1c2_id, start, count, p + 96);
	status = nc_put_vara_float(resp_ncid, wd2c2_id, start, count, p + 108);
	status = nc_put_vara_float(resp_ncid, wd3c2_id, start, count, p + 120);

	/* Reset memory for variable resp */
	 memset(p, '\0', (sizeof(float) * 11 * 12));

	return 0;
}
