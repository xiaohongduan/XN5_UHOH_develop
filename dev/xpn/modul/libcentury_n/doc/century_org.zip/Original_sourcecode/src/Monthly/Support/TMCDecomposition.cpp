// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model (Monthly)
//	File:	  TMCDecomposition.cpp
//	Class:	  TMCDecomposition
//
//	Description:
//	Class for plant decomposition for monthly Century.
//	Members were extracted from class TCentury.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, April 2004
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TMCDecomposition.h"

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	Clone
//	Clone this
//TMCDecomposition * const TMCDecomposition::Clone () const
//{
//	try
//	{
//		TMCDecomposition* const clone = new TMCDecomposition (*this);
//		return clone;					// successful
//	}
//	catch (...)
//	{
//		return 0;					// failed
//	}
//}

//	ScheduleNPSFlow
// 	Schedule N, P, or S flow and associated mineralization or
// 	immobilization flow for decomposition from Box A to Box B.
//	This is used only in decomposition.
//	Return value = mineralized or immobilized N,P,S.
//   	  Positive flow = mineralization;
//   	  Negative flow = immobilization.
//
//	Author: vek 05/91
//	History:
//	Aug03	Tom Hilinski
//	* Added changes from TDayCent::ScheduleNPSFlow including:
//      - Added "element" as funtion parameter
//      - Replaced some flows->Schedule() calls that flow labile NPS with calls
//        to FlowNPSfromMineralSoil() and/or FlowNPSintoMineralSoil
//      - "labile" argument removed
float TMCDecomposition::ScheduleNPSFlow (
        TMineralElements element,	// Nitrogen=N, Phosphorus=P, Sulfur=S
	float const cFlowAtoB,		// C flow from Box A to Box B
	float const cATotal,		// total C (unlabeled+labeled) in Box A
	float const rcetob,		// C/E of new E added to Box B
	float* const eA,		// E pool in box A
	float* const eB,		// E pool in box B
	float const simDepth)		// simulation depth
{
    Assert (cFlowAtoB > 0.0f);
    Assert (cATotal > 0.0f);
    Assert (rcetob != 0.0f);

    float mineralFlow = 0.0f;	// mineralized or immobilized N,P,S.

    // Compute and schedule N, P, and S flows
    // N, P, or S flowing out of Box A is proportional to C flow.
    float const flowFromA = *eA * cFlowAtoB / cATotal;

    // Microcosm option can cause a 0/0 error on the pc.  This
    // was added to avoid that situation (mse 2/95)
    // Change from .AND. to .OR. could still get an underflow.
    // -rm 1/96
    if (cFlowAtoB <= 0.0f || flowFromA <= 0.0f)
	return 0.0f;   	// no negative flows

    // If C/E of Box A > C/E of new material entering Box B
    else if (cFlowAtoB / flowFromA > rcetob)		// IMMOBILIZATION
    {
	// Box A to Box B
	SCHEDULE_FLOW (flows, eA, eB, simTime.time, flowFromA);
	// Compute the amount of E immobilized.
	// since  rcetob = cFlowAtoB/(flowFromA+immobilizationFlow),
	// where immobilizationFlow is the extra E needed from the mineral pool
	float const immobilizationFlow = cFlowAtoB / rcetob - flowFromA;
	Assert (immobilizationFlow >= 0.0f);
	// Schedule flow from mineral pool to Box B (immobilizationFlow)
	mineralFlow =
		-( dynamic_cast<TMCSoilFlows&>(soilFlows).
			FlowNPSfromMineralSoil (
				element, eB, immobilizationFlow, simDepth ) );
    }
    else						// MINERALIZATION
    {
	// Box A to Box B
	float const flowAtoB = cFlowAtoB / rcetob;
	SCHEDULE_FLOW (flows, eA, eB, simTime.time, flowAtoB);
	// Schedule flow from Box A to mineral pool
	mineralFlow = flowFromA - flowAtoB;
	mineralFlow =
		dynamic_cast<TMCSoilFlows&>(soilFlows).FlowNPSintoMineralSoil (
			element, eA, mineralFlow, simDepth );
    }
    return mineralFlow;
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------


//--- end of definitions for TMCDecomposition ---
