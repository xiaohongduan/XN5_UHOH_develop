#ifndef INC_T_C14Data_h
#define INC_T_C14Data_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TC14Data.h
//	Class:	  T14CData
//
//	Description:
//	Class T14CData to manage the 14C data.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jun98
// ----------------------------------------------------------------------------
//	History:
//	Jan99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Incorporated param.lablyr into this class.
//	Jun01	Tom Hilinski
//	* Changed file name, T_C14Data.* to TC14Data.*
//	* Moved "using namespace std;" to .cpp file.
//	* Added copy constructor, operator=
//	* Change fileName type to std::string
//	Sep01	Tom Hilinski
//	* Added operator== and operator!=
//	Oct03	Tom Hilinski
//	* Added enum TError, members errorState, and GetError(), HaveError()
//	* Removed throws from the constructors.
//	* Added a constructor taking a std::string file name.
// ----------------------------------------------------------------------------
//	Notes:
//	14C data file structure:
//	Each record contains
//	(1) year in which 14C is added to the total C, followed by
//	(2) percent of 14C in new plant tissue.
//	Example records:
//		1950 1.0
//		1951 1.0
//	Years in which 14C is not added are not included in the data file.
// ----------------------------------------------------------------------------
//	To Do:
//	1. Replace use of TCentException with a more generic exception class
//	   (perhaps new class TFileException ?)
// ----------------------------------------------------------------------------

#include <fstream>
#include <string>

class T14CData
{
  public:
	//--- types
	enum TError				// error flags
	{
		Error_None,
		Error_NoFileName,
		Error_OpenFailed,
		Error_FileStream,
		Error_Unknown
	};

	//--- constructors and destructor
	T14CData (
	  char const * const newFileName,	// 14C data file name
	  const long useStartYear);		// year for start of C labeling
	T14CData (
	  std::string const & newFileName,	// 14C data file name
	  const long useStartYear);		// year for start of C labeling
	T14CData (
	  T14CData const & object)
	  {
	    Initialize ();
	    Copy (object);
	  }
	virtual ~T14CData ();

	//---- operator overloads
	T14CData& operator= (
	  T14CData const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	Clear ();
		Copy (object);
	    }
	    return *this;
	  }
	bool operator== (T14CData const & object) const;
	bool operator!= (T14CData const & object) const
	  { return !(*this == object); }

	//--- functions
	float GetFraction14C (
		short const simYear);		// simulation year
	bool EndOfData ()			// true if end of data
		{ return (!df || df.eof()); }
	short CurrentYear () const		// returns last year read
		{ return curYear; }
	float CurrentPercent () const		// returns last pct. read
		{ return curPct; }
	float CurrentFraction () const		// returns last fraction calc'd
		{ return fraction; }
	long LabelingStartYear () const		// Get labeling start year.
		{ return yearLabelStart; }
	TError GetError () const
	  { return errorState; }
	bool HaveError () const
	  { return errorState != Error_None; }
	void Clear ();				// clear member data

  protected:
	//--- data
	std::string fileName;			// 14C data file name
	std::ifstream df;			// data file stream
	float fraction;				// current 14C fraction
	short curYear;				// current year read
	float curPct;				// current percent read
	long yearLabelStart;			// year C labeling begins
	TError errorState;			// error condition

	//--- functions
	void OpenStream ();			// Open the input file stream
	bool GetRecord (			// next record in file
	  short *newYear,
	  float *pct);

  private:
	//--- functions
	void Initialize ();			// initialize member data
	void Copy (T14CData const & object);	// Copy to this
};

#endif // INC_T_C14Data_h
