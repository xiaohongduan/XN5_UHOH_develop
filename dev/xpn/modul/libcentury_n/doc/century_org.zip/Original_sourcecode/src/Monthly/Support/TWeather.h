#ifndef INC_TWeather_h
#define INC_TWeather_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TWeather.h
//	Class:	  TWeather
//
//	Description:
//	Class to manage weather variables.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jun98
// ----------------------------------------------------------------------------
//	History:
//	May99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Enhanced reading of the weather file with better error messages.
//	Jan00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Redesigned large portions of the class.
//	* Fixed bug in retrieving the current year's data.
//	* Added estimation of missing temperature values.
//	* Changed precip. missing value replacement, by first checking the
//	  site file precip value. If that is missing, then generate a
//	  stochastic value.
//	* Tighter encapuslation of weather data.
//	* Reorganized the input and rewrote the file read functions.
//	* No longer need the random seed flag.
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* A bit of cleaning up and const-correctness.
//	* Added copy constructor, operator=
//	Sep01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Created a simple base class which this now inherits.
//	* Added operator== and operator!=
//	Nov01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Cleaned up MonthlyPET calc and made const-correct.
//	Jun-Jul02	Tom Hilinski
//	* Little bit of cleanup.
//	* Moved parts common w/DayCent's weather into the base class.
//	* Added AdvanceToYear()
// ----------------------------------------------------------------------------
//	To Do:
//	* Float arrays should be std::vector or std::valarray.
//	* IsEmpty should then do empty() on current year values.
//	* Split each weather source type into a separate class.
// ----------------------------------------------------------------------------

#include "TWeatherBase.h"
#include <fstream>

class TWeather : public TWeatherBase
{
  public:
	//--- types

	//--- constructors and destructor
	TWeather (
	  TCalendarTools * const useCT);	// calendar functions
	~TWeather ();
	TWeather (TWeather const & object)	// copy constructor
	  : TWeatherBase (object)
	  {
	    Initialize ();
	    Copy (object);
	  }

	//---- operator overloads
	TWeather& operator= (TWeather const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	TWeatherBase::operator= (object);
	    	Clear ();
		Copy (object);
	    }
	    return *this;
	  }
	bool operator== (TWeather const & object) const;
	bool operator!= (TWeather const & object) const
	  { return !(*this == object); }

    //--- functions
    void InitAnnualData (			// Setup the next year's data
     	const TWeatherSrc source,		//   source of weather data
    	char const* newFileName = 0);		//   file name if source = file
   						//--- Queries
    bool EndOfData ()				// True if end of data
	{
	  if ( wf ) { wf >> std::ws; return wf.eof(); }
	  else return false;
	}
    bool IsEmpty () const;			// True if no data
    TYear AdvanceToYear (			// Advance to a year
      TYear findThisYear);			// ...this year

						//--- Calculations
    float GrowingSeasonPrecip (			// Total precip for growth
	short const month);			//   month (1-12)

    						//--- Initialization
    void Clear ();				// Reset to initial state
    TWeather * const Clone () const		// Clone this
	{ return new TWeather (*this); }

  protected:
	//--- static const data
	static char const * const labels[3];	// weather label strings

	//--- data
	TYear yearNext;			// next year
	float				//--- monthly values for next year:
		precipNY[12],		// precipitation
		minTempNY[12],		// min temp
		maxTempNY[12];		// max temp
	std::ifstream wf;		// file stream

	//--- functions
	void ReplaceMissingData (		// Replace missing vals. w/data
		float* precip,			//   precipitation
		float* minTemp,			//   minimum temperatures
		float* maxTemp);		//   maximum temperatures
	bool SearchForwardForValidValue (	// Search forward for value
		float const *& p,		//   data array
		short& i,			//   starting index (month - 1)
		short const distance		//   max. no. values to search
		) const;
	bool SearchBackwardForValidValue (	// Search backward for value
		float const *& p,		//   data array
		short& i,			//   starting index (month - 1)
		short const distance		//   max. no. values to search
		) const;
	float EstimateMonthlyValueLinear (	// Estimates a monthly value
		float const data[12],		//   data array
		short const month) const;	//   month index (0-11)
						//--- Weather file functions
	bool InitASCIIDataFile (		// Init a text data file
		char const* newFileName);	//   file name if source = file
	bool ReadAnnualData (			// Rd. 1 year's data
		TYear& newYear,			//   year of data
		float* precip,			//   precipitation
		float* minTemp,			//   minimum temperatures
		float* maxTemp);		//   maximum temperatures
	bool GetRecord (			// Get one record.
		char label[5],
		TYear& year,
		float values[12]);
	void CheckForRewind ();			// If rewinding needed, do it.
	void Rewind ();				// Rewind the file
	void WthrFileLabelError (
		char const *found,
		char const *expected
		) const;
	void WthrFileRdError (
		char const* recName,
		TYear const year
		) const;
	void ClearData ();			// Erase data arrays

  private:
	//--- functions
	void Initialize ();
	void Copy (TWeather const & object);	// Copy to this
};

#endif // INC_TWeather_h
