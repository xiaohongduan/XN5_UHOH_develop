// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TNcFileFTDesc.cpp
//	Class:	  TNcFileFTDesc
//
//	Description:
//	Class to read the NCFTypes.nc file, containing descriptions of the
//	netCDF file types used by Century and CMI.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Feb99
// ----------------------------------------------------------------------------
//	History: See header file.
// ----------------------------------------------------------------------------
//	Copyright 1999-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TNcFileFTDesc.h"
#include "charutil.h"
#include <algorithm>
#include <iterator>
#include <memory>

//--- constructors and destructor

//--- public functions

//	GetDesc
//	Returns the description corresponding to the matching enum value.
char const* TNcFileFTDesc::GetDesc (
	TNcFileType const enumValue) const
{
	TValueList::const_iterator i = std::find (
		valueList.begin(), valueList.end(), enumValue);
	if ( i != valueList.end() )
	{
		int d = static_cast<int>(
			std::distance (valueList.begin(), i) );
		return descList[d].c_str();		// found match
	}
	else
		return 0;				// no match found
}

//	Clear
// 	"clear" data members
void TNcFileFTDesc::Clear ()
{
	valueList.erase ( valueList.begin(), valueList.end() );
	descList.erase ( descList.begin(), descList.end() );
}


//--- private functions

//	Read
//	Reads in the list of values and strings from the netCDF file.
//	Returns false upon successful read, else true if not successful.
void TNcFileFTDesc::Read ()
{
	if ( ncErrStr )			// already have error message?
		return;			// ...yes

	if ( !OpenNcFile (NcFile::ReadOnly) )	// open the netCDF file
	{
	    // get pointers to netCDF data
	    NcVar* valVar = ncFile->get_var ("value");		// values
	    NcVar* descVar = ncFile->get_var ("description");	// descriptions
	    NcDim* descDim = ncFile->get_dim ("descLen");	// string dim.
	    NcDim* recDim = ncFile->rec_dim ();			// unlim. dim.

	    // memory for lists
	    Clear ();					// delete previous
	    short const count = (short) recDim->size();	// list size
	    valueList.reserve (count);
	    descList.reserve (count);

	    // Read values and strings
	    short* const tmpValList = new short [count];// temporary array
	    valVar->get (tmpValList, count);		// get values
	    short const descLen =
	    		(short) descDim->size();	// description length
	    char* curDesc = new char [descLen + 1];	// for one description
	    for ( short i = 0; i < count; i++ )		// get descriptions
	    {
		descVar->set_cur (i, 0);		// to next string
		descVar->get (curDesc, 1, descLen);	// get string
		curDesc[descLen] = '\0';
	    	::strtrim (curDesc);			// trim trailing space
	    	descList.push_back (curDesc);		// add to list
	    	valueList.push_back (tmpValList[i]);	// add to list
	    }
	    delete [] curDesc;

	    // check for errors
	    SetNcErrStr ();
	    CloseNcFile ();			// close the netCDF file
	}
	return;
}

//--- end of definitions for TNcFileFTDesc ---
