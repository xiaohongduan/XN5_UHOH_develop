// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TNcFileList.cpp
//	Classes:  TNcFileList
//
//	Description:
//	Class for building a list of netCDF files of a particular type.
//
//	Author:	Tom Hilinski, Sep98, tom.hilinski@colostate.edu
// ----------------------------------------------------------------------------
//	History:
//	See header file.
// ----------------------------------------------------------------------------
//	Copyright 1998-2000 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------


#include "TNcFileList.h"
#include "TFileList.h"
#include "TFileName.h"
using namespace TEH;
// netCDF C++ interface
#include "netcdf.hh"
// STL
// Borland C++ 5.x flags
#pragma warn -csu
#include <algorithm>
using namespace std;

//--- global variables
// pList is global so we can declare GetList() to be const.
static char const** pList = 0;		// pointer to that list as C-strings


//--- constructors and destructor

TNcFileList::TNcFileList (
	char const** const usePathList,		// null-term list of paths
	const TNcFileType useType )		// netCDF file type
	: pathList (usePathList), type (useType)
{
	Initialize ();
	if ( !pathList || type == NCFT_Unknown )	// args ok?
	{
		// need error handling here
		errFlag = true;
		return;
	}
	if ( BuildFileList () )				// build the list
	{
		Clear ();
		errFlag = true;
		// need error handling here
	}
}

TNcFileList::~TNcFileList ()
{
	Clear ();
}

// 	copy constructor
TNcFileList::TNcFileList (const TNcFileList &obj)
	: pathList (obj.pathList), type (obj.type)
{
	Initialize ();
	Copy (obj);
}


//--- operator overloads

inline TNcFileList& TNcFileList::operator = (const TNcFileList &object)
{
	if (this != &object)	// check for assignment to self
	{
		Clear ();
		Copy (object);
	}
	return *this;
}

inline TNcFileList TNcFileList::operator + (const TNcFileList &object)
{
	if ( type == object.type )
	{
		// copy the object name list to this' name list
		std::copy ( object.nameList.begin(), object.nameList.end(),
			    nameList.end() );
		// sort the list
		sort ( nameList.begin(), nameList.end() );
	}
	return *this;
}


//--- public functions

//	GetList
// 	Returns pointer to a null-terminated list of fully-qualified file names.
//	Pointer to list is only valid while (1) this class exists, (2) Clear()
//	is NOT called, and (3) no other strings are added to the list.
char const** TNcFileList::GetList () const
{
	// build a C-string list to return
	register short const count = (short) nameList.size();
	if ( ::pList )					// previous list?
		delete [] ::pList;			// yes... delete
	::pList = new char const* [count + 1];		// new memory
	::pList[count] = 0;				// null-terminate
	register short j = 0;				// index to pList
	// Note: for some reason, Borland C++ 5.02 wants the following cast.
	TNcFileNameList::const_iterator i = nameList.begin ();
	while ( i != nameList.end() )			// for each string...
	{
		::pList[j] = (*i).c_str ();		// get pointer
		++i;					// next string
		++j;					// next *pList
	}
	return ::pList;
}

//	Clear
// 	"clear" data members
void TNcFileList::Clear ()
{
	nameList.empty ();
	delete [] ::pList;
	Initialize ();
}


//--- private functions

//	Initialize
// 	initialize members
void TNcFileList::Initialize ()
{
	::pList = 0;
	errFlag = false;
}

//	BuildFileList
//	Builds list of valid files.
//	Returns false if successful, else true if error.
bool TNcFileList::BuildFileList ()
{
	char const** p = const_cast<char const**>(pathList);
	while ( *p )			// for each path, get a file list
	{
		// Search for files in the current path
		TEH::TFileName mask ( *p );  // build a name mask to search for
		mask.SetName ("*");
		mask.SetExtension ("nc");
		// get the list
		TFileNameList list ( mask.GetFullName().c_str(),
				     TFileNameList::FLT_Normal);
		if ( list.IsError() )				// errors?
		{
			Clear ();
			errFlag = true;
			// need error handling here
			return true;
		}
		if ( list.GetCount() == 0 )		// is list empty?
			continue;

		// Check each file to see if it is a Century output file.
		// If so, add to nameList.
		char const * const * pFiles = list.GetList ();
		while ( *pFiles )	// for each file in the list
		{
			// first add path to name
			string path = *p;
			string fullName = path + *pFiles;
			// now check it
			if ( IsCenturyOutput ( fullName.c_str() ) )
				AddToList ( fullName.c_str() );
			++pFiles;	// next file in the found list
		}
		++p;	// to next path in the path list
	}
	// sort the list
	sort ( nameList.begin(), nameList.end() );
	// all done!
	return false;
}

//	IsCenturyOutput
// 	Returns true if output file, else false if not.
bool TNcFileList::IsCenturyOutput (char const* name)
{
	bool retVal = false;
	NcAtt* pAttrib = NULL;

	// 1. open the netCDF file
	NcError* ncErr = new NcError (NcError::silent_nonfatal);
	NcFile* ncFile = new NcFile (name, NcFile::ReadOnly);
	if ( !ncFile->is_valid() || ncErr->get_err() )
	{
		// To Do: retrieve error string from netCDF

		errFlag = true;
		goto all_done;		// error accessing the file
	}

	// 2. does "FileType" attribute exist in the file?
	pAttrib = ncFile->get_att ("FileType");
	if ( !pAttrib )			// attribute exists?
		goto all_done;		// no... not a Century output file
	if ( pAttrib->type() != ncLong )	// check attribute type
		goto all_done;		// wrong... not a Century output file
	if ( pAttrib->num_vals() != 1 )	// check if has only 1 value
		goto all_done;		// wrong... not a Century output file

	// 3. is the "FileType" attribute say "output file"?
	if ( pAttrib->as_nclong(0) == 30 )	// correct file type?
		retVal = true;			// yes!

all_done:
	delete pAttrib;
	delete ncFile;
	delete ncErr;
	return retVal;
}

//	AddToList
//	add name to name list
//	Returns false if successful, else true if not.
bool TNcFileList::AddToList (char const* name)
{
	bool retVal = false;				// return value
	string str = name;				// store in string
	short prevSize = (short) nameList.size ();	// save current size
	nameList.push_back (str);			// add string
	if ( prevSize != (short) nameList.size() - 1 )	// added successfully?
	{
		errFlag = true;
		retVal = true;				// ...no
	}
	return retVal;					// return success flag
}

//	Copy
// 	copy to this
void TNcFileList::Copy (const TNcFileList &fromObj)
{
	errFlag = fromObj.errFlag;
	nameList = fromObj.nameList;
}
