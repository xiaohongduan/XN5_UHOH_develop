#ifndef INC_Cent_Exception_h
#define INC_Cent_Exception_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCentException.h
//	Class:	  TCentException
//
//	Description:
//	Class used for throwing Century exceptions.
//	Remember: These are thrown for fatal errors only!
//	Usage:
//	Throw exception using exit code from enum list below,
// 	optionally appending a message string.
//	Example:
//		ThrowCentException (TCentException::CE_MEMALC, "Hi!");
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
//	History:
//	* Added exception values for "parameter file option set errors".
//	Jun01	Tom Hilinski
//	* Added exception values for "Failed in add to the flow stack".
//	* Changed class name: Cent_Exception to TCentException.
//	Aug01	Tom Hilinski
//	* Made the destructor virtual so this can be base class.
//	* Moved enum inside the class.
//	* All data members are now private: New access funtions are provided.
//	* Changed constructors to include file and line number macros
//	  which are saved in the message string.
//	* The GetMsg member now returns std::string rather than char*.
//	Aug05	Tom Hilinski
//	* Added exception CE_PHSOIL.
// ----------------------------------------------------------------------------

#define stringize__(x)	#x
#define stringize2__(x)	stringize__(x)
#ifdef __BCPLUSPLUS__
  #define ThrowCentException(a,b) \
	throw TCentException (a, b, \
		"\nFile: " ## __FILE__ ## \
		"\nFunction: " ## __FUNC__ ## \
		"\nLine: " ## stringize2__(__LINE__) )
#else
  #define ThrowCentException(a,b) \
	throw TCentException (a, b, \
		"\nFile: " __FILE__ \
		"\nLine: " stringize2__(__LINE__) )
#endif

#include <string>

class TCentException
{
  public:
	//---- types
	// enum constants match order of the
	// TCentException::errorString[] strings.
	enum TCEIndex
	{
		// first one always!
		CE_NOERR,
		// misc. errors
		CE_UNKNOWN_ERROR,
		CE_FCFRAC, CE_RAN1,   CE_MICRO,  CE_PFRAC,  CE_MEMALC,
		CE_OVCFCI, CE_PHSOIL,
		// parameter database errors
		CE_NSPPDB, CE_EMPPDB, CE_OPCBAD, CE_RDPDBF, CE_PARMIV,
		// parameter database option set errors
		CE_ONFTRE, CE_ONFTRR, CE_ONFCRP, CE_ONFCUL, CE_ONFFER,
		CE_ONFFIR, CE_ONFGRA, CE_ONFHAR, CE_ONFIRR, CE_ONFORM,
		CE_RDFIXD,
		// weather file errors
 	 	CE_WTHRNO, CE_RDWTHR, CE_WTHROS,
		// management scheme errors
		CE_MGTINV, CE_MGTNOB, CE_NOINST, CE_WTHRFL, CE_INSTOS,
		CE_BLKNOI, CE_NOMGMT, CE_MGTFNV, CE_MGTERR,
		// site parameter errors
		CE_NOSITE, CE_SITENS, CE_BDNLYR, CE_BDNLPG, CE_NOSOIL,
		CE_NOSTPD, CE_SITWNF, CE_STRDER, CE_SITERR,
		// output file errors
		CE_PRVOUT, CE_NOOUTF, CE_INVOFT, CE_NOPRVF, CE_OPNOUT,
		CE_WRTOUT, CE_IOFAMD, CE_IOFFMT, CE_NAOVND, CE_OUTERR,
		// flow stack errors
		CE_FLWERR, CE_FLWFAS, CE_FLWSVN, CE_FLWHUG, CE_FLWNFP,
		CE_FLWNTP, CE_FLWTFE,
		// 14C data file errors
		CE_14CRDF, CE_14CNMY, CE_14CNFN, CE_14CFNA,
		// Erosion/Deposition errors
		CE_IEROFN, CE_IDEPFN, CE_DEPNEF, CE_IREROD,
		// all done!
		CE_NUM_ERRORS
	};

	//---- constructors and destructor

	TCentException (
	  TCEIndex const exceptionCode,			// type of exception
	  char const * const newMsgCStr = 0,		// message string
	  char const * const fileLineStr = 0)		// file & line
	  {
	    std::string const newMsg = newMsgCStr;
	    ConstructMe (exceptionCode, newMsg, fileLineStr);
	  }
	TCentException (
	  TCEIndex const exceptionCode,			// type of exception
	  std::string const newMsg,			// message string
	  char const * const fileLineStr = 0)		// file & line
	  {
	    ConstructMe (exceptionCode, newMsg, fileLineStr);
	  }
	virtual ~TCentException ()
	  {
	  }

	//---- functions
	short GetCode () const				// Get exception code
	  { return static_cast<short>(exitCode); }
	static std::string const & GetMsg ()		// Get message
	  { return msg; }

	//---- data

  protected:
	//---- constants
	static char const * const errorString[CE_NUM_ERRORS + 1];

	//---- data
	short exitCode;
	static std::string msg;

	//---- functions
	void ConstructMe ( // not thread-safe!
	  TCEIndex const exceptionCode,		// type of exception
	  std::string const & newMsg,		// message string
	  char const * const fileLineStr);	// file and line string

  private:
};


#endif // INC_Cent_Exception_h
