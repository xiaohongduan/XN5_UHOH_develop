// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TCenturySimOutputMgr.cpp
//	Class:	  TCenturySimOutputMgr
//
//	Description:
//	Class for managing simulation output at the simulation level for
//	the DayCent model.
//	Output object is TFileStream.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, June 2002
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TCenturySimOutputMgr.h"
#include "TDayCentSimController.h"
using namespace nrel::dcirc;

TCenturySimOutputMgr::TCenturySimOutputMgr (
	TOwner * const useParent,		// ptr to parent
	TSharedPtr<TOutput> useOutputSink)	// output sink
	: MyBase (
		dynamic_cast<MyBase::TOwner * const>(useParent),
		static_cast< TSharedPtr<MyBase::TOutput> >(useOutputSink) ),
	  ofs (useOutputSink)
	{
	}

//--- end of file ---
