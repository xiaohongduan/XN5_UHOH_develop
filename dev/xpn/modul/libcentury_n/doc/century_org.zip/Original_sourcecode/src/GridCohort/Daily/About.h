#ifndef INC_nrel_dcirc_About_h
#define INC_nrel_dcirc_About_h
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  About.h
//	Class:	  About
//
//	Description:
//	Provides version and status information about the DayCentIRC model,
//	and the subsystems and frameworks it uses.
//
//	Responsibilities:
//	* Provides version information for each part, if available.
//	* Provides one-line descriptions for each part, if available.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, March 2005
//	History:
//	<date, eg., 22May01>	<your name>, <your e-mail address>
//	<description>
// ----------------------------------------------------------------------------

#include "AboutBase.h"

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class About : public AboutBase
{
  public:
	//---- types

	//---- constructors and destructor
	About ();
	~About ()
	  {
	  }

	//---- operator overloads

	//---- functions

  protected:
	//---- data

	//---- functions

  private:
	//---- data

	//---- functions
	virtual void Initialize ()
	  {
	    CollectVersionInfo ();
	    CollectDescriptions ();
	    CollectPlatformInfo ();
	    CollectCopyright ();
	    CollectAcknowledgement ();
	    CollectAuthor ();
	    CollectLinks ();
	    CollectDisclaimer ();
	    CollectSupport ();
	    CollectContacts ();
	    CollectInternalInfo ();
	  }
	virtual void CollectVersionInfo ();
	virtual void CollectDescriptions ();
	virtual void CollectPlatformInfo ();
	virtual void CollectCopyright ();
	virtual void CollectAcknowledgement ();
	virtual void CollectAuthor ();
	virtual void CollectLinks ();
	virtual void CollectDisclaimer ();
	virtual void CollectSupport ();
	virtual void CollectContacts ();
	virtual void CollectInternalInfo ();
};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_About_h
