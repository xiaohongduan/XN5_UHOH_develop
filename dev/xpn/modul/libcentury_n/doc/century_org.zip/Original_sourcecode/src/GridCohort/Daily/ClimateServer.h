#ifndef INC_nrel_dcirc_ClimateServer_h
#define INC_nrel_dcirc_ClimateServer_h
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  ClimateServer.h
//
//	Climate interface for DayCentIRC.
//	Contains a DayCent5 weather server.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, tom.hilinski@colostate.edu, March 2005
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
//---------------------------------------------------------------------------

#include "TClimateBase.h"		// Climate model interface
#include "Century5WeatherServer.h"	// Weather server
#include "TSharedPtr.h"

namespace nrel
{

  namespace dcirc	// DayCentIRC
  {

class ClimateServer
	: public ::nrel::gcf::TClimateBase
{
  public:
	//---- types
	typedef TSharedPtr<nrel::weather::Century5WeatherServer>
		TWeatherServerPtr;

	//---- constructors and destructor
	ClimateServer (
	  std::string const & weatherINIFile)
	  : ::nrel::gcf::TClimateBase ()
	  {
	    if ( CreateServer(weatherINIFile) )
	    {
		// to do: constructor failed
	    }
	  }
	ClimateServer (ClimateServer const & object)
	  :  ::nrel::gcf::TClimateBase (object)
	  {
	  	// to do: copy constructor
	  }
	~ClimateServer ()
	  {
	  }
	ClimateServer * const Clone () const
	  { return new ClimateServer (*this); }

	//---- functions
	TWeatherServerPtr GetServer ()
	  { return weatherServer; }
	bool HaveServer () const
	  { return weatherServer.get(); }

  private:
  	//---- data
  	TWeatherServerPtr weatherServer;

	//---- functions
	bool CreateServer (
	  std::string const & weatherINIFile);
	bool InitWeatherObjects ();
};

  } // namespace dcirc

} // namespace nrel

#endif // INC_nrel_dcirc_ClimateServer_h
