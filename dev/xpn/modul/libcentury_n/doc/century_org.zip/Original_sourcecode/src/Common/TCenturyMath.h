#ifndef	INC_TCenturyMath_h
#define	INC_TCenturyMath_h
// ----------------------------------------------------------------------------
//	Copyright (c) 2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCenturyMath.h
//	Functions: atanf, ramp, YOnLine, Sum
//
//	Description:
//	Global functions for Century model math functions.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, August 2001
//	History:
//	Jul02	Tom Hilinski
//	* Moved from TCenturyBase::math.cpp to here. Made global and inline.
// ----------------------------------------------------------------------------

#include <cmath>
#ifndef M_PI
//const double M_PI = 3.14159265358979323846;
#define M_PI static_cast<double const>( 3.14159265358979323846 )
#endif

/* ******************** flowlib ********************* */
/* (run-time sub-set of modaid, exclusive of modctl) */
/* release 1.0  (first formal release of modaid) */
/* james m. vevea */
/* natural resource ecology lab */
/* colorado state university */
/* fort collins, colorado	80523 */
/* this routine is functionally equivalent to the routine of the */
/* same name, described in the publication: */
/* some graphs and their functional forms */
/* technical report no. 153 */
/* william parton and georgo innis	(1972) */
/* natural resource ecology lab. */
/* colorado state university */
/* fort collins, colorado  80523 */

inline
float atanf (
	float const x,
	float const a, float const b,
	double const c, float const d)
{
    return b + c / M_PI * std::atan(M_PI * d * (x - a));
}

//	YOnLine
//	Equation of a line from two points
//	Given 2 known points and a new X, calculate Y.
//	slope = (y2 - y1) / (x2 - x1)
//	y = slope * (x - x2) + y2
template <class T>
T YOnLine (
	T const x,
	T const x1, T const y1,
	T const x2, T const y2)
{
	return (y2 - y1) / (x2 - x1) * (x - x2) + y2;
}

/*	-----------------------------------------------------------------------
	ramp
	This function :
	       /-----
	      /
	-----/

*/
template <class T>
T ramp (
	T const x,
	T const x1, T const y1,
	T const x2, T const y2)
{
    float retVal;

    if (x < x1)					// use minimum
	retVal = y1;
    else if (x > x2)				// use maximum
	retVal = y2;
    else					// intermediate point
	retVal = YOnLine<T> (x, x1, y1, x2, y2);
    return retVal;
}

//	Sum
//	Sum the values of an array.
template <class T>
T Sum (
	T const * array,
	short const count)
{
	T sum = 0;
	for ( short i = 0; i < count; ++i, ++array )
		sum += *array;
	return sum;
}

#endif // INC_TCenturyMath_h
