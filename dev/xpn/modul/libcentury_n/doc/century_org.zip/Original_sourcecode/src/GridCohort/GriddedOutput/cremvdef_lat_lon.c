
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  cremvll_ncid;			/* netCDF id */

/* variable ids */
int  shremcll_id, sdremcll_id, rlvremcll_id, fbrremcll_id, rlwremcll_id, 
     wd1remcll_id, wd2remcll_id, stremcll_id, metrmcll_id;
int  timell_id, lat_id, lon_id;

/* create cremv.nc */
int
cremvdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
            float *opltim, float *qtime) {

   int   status, istart_year, iend_year, ii;
   float fill, fstart_year, fend_year;
   char  timeunits[25], temp[5];

   /* dimension ids */
   int  time_dim = 0;
   int  lat_dim = 0;
   int  lon_dim = 0;

   /* variable shapes */
   int dims[3];

   /* Set fill, start_year, and end_year values */
   fill = NC_FILL_FLOAT;
   fstart_year = *opltim;
   fend_year = *qtime - 1;
   istart_year = fstart_year;
   iend_year = fend_year;

   for (ii = 0; ii < 25; ii++) {
     timeunits[ii] = '\0';
   }
   /* Get the start time for the time definition */
   sprintf(temp, "%d", istart_year); 
   strcat(timeunits, "days since ");
   strcat(timeunits, temp);
   strcat(timeunits, "-01-01");

   /* enter define mode */
   status = nc_create("cremvll.nc", NC_CLOBBER, &cremvll_ncid);
   if (status != NC_NOERR) handle_error("nc_create(cremv.nc)", status);

   /* define dimensions */
   status = nc_def_dim(cremvll_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(cremvll_ncid, "lat", (size_t) *nlat, &lat_dim);
   status = nc_def_dim(cremvll_ncid, "lon", (size_t) *nlon, &lon_dim);

   /* define variables */

   dims[0] = time_dim;
   status = nc_def_var (cremvll_ncid, "time", NC_INT, 1, dims, &timell_id);

   dims[0] = lat_dim;
   status = nc_def_var (cremvll_ncid, "lat", NC_FLOAT, 1, dims, &lat_id);

   dims[0] = lon_dim;
   status = nc_def_var (cremvll_ncid, "lon", NC_FLOAT, 1, dims, &lon_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (cremvll_ncid, "shremc", NC_FLOAT, 3, dims, &shremcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (cremvll_ncid, "sdremc", NC_FLOAT, 3, dims, &sdremcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (cremvll_ncid, "rlvremc", NC_FLOAT, 3, dims, &rlvremcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (cremvll_ncid, "fbrremc", NC_FLOAT, 3, dims, &fbrremcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (cremvll_ncid, "rlwremc", NC_FLOAT, 3, dims, &rlwremcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (cremvll_ncid, "wd1remc", NC_FLOAT, 3, dims, &wd1remcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (cremvll_ncid, "wd2remc", NC_FLOAT, 3, dims, &wd2remcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (cremvll_ncid, "stremc", NC_FLOAT, 3, dims, &stremcll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (cremvll_ncid, "metrmc", NC_FLOAT, 3, dims, &metrmcll_id);

   /* assign attributes */
   status = nc_put_att_text (cremvll_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (cremvll_ncid, timell_id, "long_name", strlen("Time"), "Time");
   status = nc_put_att_text (cremvll_ncid, timell_id, "units", strlen(timeunits), timeunits);
   status = nc_put_att_text (cremvll_ncid, timell_id, "time_step", strlen("monthly"), "monthly");
   status = nc_put_att_text (cremvll_ncid, timell_id, "calendar", strlen("gregorian"), "gregorian");
   status = nc_put_att_int (cremvll_ncid, timell_id, "start_year", NC_INT, 1, &istart_year);
   status = nc_put_att_int (cremvll_ncid, timell_id, "end_year", NC_INT, 1, &iend_year);

   status = nc_put_att_text (cremvll_ncid, lat_id, "long_name", strlen("Latitude"), "Latitude");
   status = nc_put_att_text (cremvll_ncid, lat_id, "units", strlen("degrees_north"), "degrees_north");
   status = nc_put_att_text (cremvll_ncid, lat_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (cremvll_ncid, lat_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (cremvll_ncid, lon_id, "long_name", strlen("Longitude"), "Longitude");
   status = nc_put_att_text (cremvll_ncid, lon_id, "units", strlen("degrees_east"), "degrees_east");
   status = nc_put_att_text (cremvll_ncid, lon_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (cremvll_ncid, lon_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (cremvll_ncid, shremcll_id, "long_name", 
	strlen("above_ground_live_carbon_removed"), "above_ground_live_carbon_removed");
   status = nc_put_att_text (cremvll_ncid, shremcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(cremvll_ncid, shremcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (cremvll_ncid, sdremcll_id, "long_name", 
	strlen("standing_dead_carbon_removed"), "standing_dead_carbon_removed");
   status = nc_put_att_text (cremvll_ncid, sdremcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(cremvll_ncid, sdremcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (cremvll_ncid, rlvremcll_id, "long_name", 
	strlen("live_leaf_carbon_removed"), "live_leaf_carbon_removed");
   status = nc_put_att_text (cremvll_ncid, rlvremcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(cremvll_ncid, rlvremcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (cremvll_ncid, fbrremcll_id, "long_name", 
	strlen("live_fine_branch_carbon_removed"), "live_fine_branch_carbon_removed");
   status = nc_put_att_text (cremvll_ncid, fbrremcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(cremvll_ncid, fbrremcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (cremvll_ncid, rlwremcll_id, "long_name", 
	strlen("live_large_wood_carbon_removed"), "live_large_wood_carbon_removed");
   status = nc_put_att_text (cremvll_ncid, rlwremcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(cremvll_ncid, rlwremcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (cremvll_ncid, wd1remcll_id, "long_name", 
	strlen("dead_fine_branch_carbon_removed"), "dead_fine_branch_carbon_removed");
   status = nc_put_att_text (cremvll_ncid, wd1remcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(cremvll_ncid, wd1remcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (cremvll_ncid, wd2remcll_id, "long_name", 
	strlen("dead_large_wood_carbon_removed"), "dead_large_wood_carbon_removed");
   status = nc_put_att_text (cremvll_ncid, wd2remcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(cremvll_ncid, wd2remcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (cremvll_ncid, stremcll_id, "long_name", 
	strlen("surface_structural_carbon_removed"), "surface_structural_carbon_removed");
   status = nc_put_att_text (cremvll_ncid, stremcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(cremvll_ncid, stremcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (cremvll_ncid, metrmcll_id, "long_name", 
	strlen("surface_metabolic_carbon_removed"), "surface_metabolic_carbon_removed");
   status = nc_put_att_text (cremvll_ncid, metrmcll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(cremvll_ncid, metrmcll_id, "_FillValue", NC_FLOAT, 1, &fill);

   /* leave define mode */
   status = nc_enddef (cremvll_ncid);
   return 0;
}
