
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Rewrite the livc.nc netCDF file using COARDS standards */
/* The original file was organized variable(cell, time) */
/* The new file is organized variable(time, lat, lon) */

#include <stdio.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf_ll.h"

    int write_livc_ll_(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  aglivc_vals[MAXCELLS], bglivc_vals[MAXCELLS], stdedc_vals[MAXCELLS],
             rleavc_vals[MAXCELLS], frootc_vals[MAXCELLS], fbrchc_vals[MAXCELLS],
             rlwodc_vals[MAXCELLS], crootc_vals[MAXCELLS], wood1c_vals[MAXCELLS],
             wood2c_vals[MAXCELLS], wood3c_vals[MAXCELLS], pltlig1_vals[MAXCELLS],
             pltlig2_vals[MAXCELLS];
      int status;
      int oldlivcid;
      int oldaglivcid, oldbglivcid, oldstdedcid, oldrleavcid, oldfrootcid,
          oldfbrchcid, oldrlwodcid, oldcrootcid, oldwood1cid, oldwood2cid,
          oldwood3cid, oldpltlig1id, oldpltlig2id;
      int ii, jj, ngrids;

      /* Open old version of livc.nc file */
      status = nc_open("livc.nc", NC_NOWRITE, &oldlivcid);
      if (status != NC_NOERR) handle_error("nc_open(livc.nc)", status);

      /* Get the indices for the livc output variables */
      status = nc_inq_varid(oldlivcid, "aglivc", &oldaglivcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for aglivc",status);
      status = nc_inq_varid(oldlivcid, "bglivc", &oldbglivcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for bglivc",status);
      status = nc_inq_varid(oldlivcid, "stdedc", &oldstdedcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for stdedc",status);
      status = nc_inq_varid(oldlivcid, "rleavc", &oldrleavcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for rleavc",status);
      status = nc_inq_varid(oldlivcid, "frootc", &oldfrootcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for frootc",status);
      status = nc_inq_varid(oldlivcid, "fbrchc", &oldfbrchcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for fbrchc",status);
      status = nc_inq_varid(oldlivcid, "rlwodc", &oldrlwodcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for rlwodc",status);
      status = nc_inq_varid(oldlivcid, "crootc", &oldcrootcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for crootc",status);
      status = nc_inq_varid(oldlivcid, "wood1c", &oldwood1cid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wood1c",status);
      status = nc_inq_varid(oldlivcid, "wood2c", &oldwood2cid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wood2c",status);
      status = nc_inq_varid(oldlivcid, "wood3c", &oldwood3cid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wood3c",status);
      status = nc_inq_varid(oldlivcid, "pltlig1", &oldpltlig1id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for pltlig1",status);
      status = nc_inq_varid(oldlivcid, "pltlig2", &oldpltlig2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for pltlig2",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        aglivc_vals[ii] = fill;
        bglivc_vals[ii] = fill;
        stdedc_vals[ii] = fill;
        rleavc_vals[ii] = fill;
        frootc_vals[ii] = fill;
        fbrchc_vals[ii] = fill;
        rlwodc_vals[ii] = fill;
        crootc_vals[ii] = fill;
        wood1c_vals[ii] = fill;
        wood2c_vals[ii] = fill;
        wood3c_vals[ii] = fill;
        pltlig1_vals[ii] = fill;
        pltlig2_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the livc output file */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldlivcid, oldaglivcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for aglivc",status);
            }
            aglivc_vals[jj] = val;
            status = nc_get_var1_float(oldlivcid, oldbglivcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for bglivc",status);
            }
            bglivc_vals[jj] = val;
            status = nc_get_var1_float(oldlivcid, oldstdedcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for stdedc",status);
            }
            stdedc_vals[jj] = val;
            status = nc_get_var1_float(oldlivcid, oldrleavcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for rleavc",status);
            }
            rleavc_vals[jj] = val;
            status = nc_get_var1_float(oldlivcid, oldfrootcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for frootc",status);
            }
            frootc_vals[jj] = val;
            status = nc_get_var1_float(oldlivcid, oldfbrchcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for fbrchc",status);
            }
            fbrchc_vals[jj] = val;
            status = nc_get_var1_float(oldlivcid, oldrlwodcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for rlwodc",status);
            }
            rlwodc_vals[jj] = val;
            status = nc_get_var1_float(oldlivcid, oldcrootcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for crootc",status);
            }
            crootc_vals[jj] = val;
            status = nc_get_var1_float(oldlivcid, oldwood1cid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wood1c",status);
            }
            wood1c_vals[jj] = val;
            status = nc_get_var1_float(oldlivcid, oldwood2cid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wood2c",status);
            }
            wood2c_vals[jj] = val;
            status = nc_get_var1_float(oldlivcid, oldwood3cid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wood3c",status);
            }
            wood3c_vals[jj] = val;
            status = nc_get_var1_float(oldlivcid, oldpltlig1id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for pltlig1",status);
            }
            pltlig1_vals[jj] = val;
            status = nc_get_var1_float(oldlivcid, oldpltlig2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for pltlig2",status);
            }
            pltlig2_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(livcll_ncid, aglivcll_id, start, count, aglivc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for aglivc",status);
        status = nc_put_vara_float(livcll_ncid, bglivcll_id, start, count, bglivc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for bglivc",status);
        status = nc_put_vara_float(livcll_ncid, stdedcll_id, start, count, stdedc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for stdedc",status);
        status = nc_put_vara_float(livcll_ncid, rleavcll_id, start, count, rleavc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for rleavc",status);
        status = nc_put_vara_float(livcll_ncid, frootcll_id, start, count, frootc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for frootc",status);
        status = nc_put_vara_float(livcll_ncid, fbrchcll_id, start, count, fbrchc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for fbrchc",status);
        status = nc_put_vara_float(livcll_ncid, rlwodcll_id, start, count, rlwodc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for rlwodc",status);
        status = nc_put_vara_float(livcll_ncid, crootcll_id, start, count, crootc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for crootc",status);
        status = nc_put_vara_float(livcll_ncid, wood1cll_id, start, count, wood1c_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wood1c",status);
        status = nc_put_vara_float(livcll_ncid, wood2cll_id, start, count, wood2c_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wood2c",status);
        status = nc_put_vara_float(livcll_ncid, wood3cll_id, start, count, wood3c_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wood3c",status);
        status = nc_put_vara_float(livcll_ncid, pltlig1ll_id, start, count, pltlig1_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for pltlig1",status);
        status = nc_put_vara_float(livcll_ncid, pltlig2ll_id, start, count, pltlig2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for pltlig2",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldlivcid);

      return 0;
    }
