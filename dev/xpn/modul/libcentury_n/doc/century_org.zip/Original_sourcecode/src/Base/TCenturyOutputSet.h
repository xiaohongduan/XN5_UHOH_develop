#ifndef INC_TCenturyOutputSet_h
#define INC_TCenturyOutputSet_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCenturyOutputSet.h
//	Class:	  TCenturyOutputSet
//
//	Description:
//	Pure virtual base class for classes containing Century output variables.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jun98
//	History:
//	May99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added "simDepth" to TWaterTemp =
//	  simulation layer depth (thickness) in cm.
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added "lhsomtc" and "somtpc" to TSoilC.
//	* Added "soilDepth" to TWaterTemp
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Changed all "0.0" to "0.0f"
//	* Made TCenturyOutput::memCheckValue a static const instead of #define.
//	* Added copy constructor
//	Oct01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Changed base class name to TCenturyOutputSet.
//	* Moved class TCenturyOutputSet to its own file.
// ----------------------------------------------------------------------------
//	Notes:
//
//	(1) Each output class has a set of floating point values with unique
//	names. A list of pointers to the variables is built upon construction
//	of the class to allow the set of variables to be accessed as an array
//	of floats for speed upon output.
//
//	(2) The order in which the pointers to the variables is assigned must
//	match the list of output variable names! The order is alphabetical (as
//	of the original ordering). Any changes to variable names, or addition
//	of new variables, will have to accommodate ordering, and consider past
//	vs. new ordering.
//
//	(3) With any additions/removals of variables, adjust the number of
//	variables in the total specified in the call to the constructor for
//	TCenturyOutputSet. Also, add/remove the variables from the member
//	functions for the class: Clear, AssignPointers.
//
//	(4) The values for "numFloats" member variable for each class should
//	match the dimemsion for the number of variables in the netCDF file,
//	"OutVarsDef.cdl".
// ----------------------------------------------------------------------------

#include "AssertEx.h"
#include "TCentException.h"

class TCenturyOutputSet
{
  protected:
	//--- data
	short const numFloats;			// number of float values
	static float const memCheckValue;	// dogtag value

  public:
	//--- data
	float** p;				// pointers to output variables
						// (null-term'd list)
	//--- constructors and destructor
	TCenturyOutputSet (
	  short const floatCount )	// number of FP output values
	  : p (0),
	    numFloats ( floatCount )
	  {
	    Initialize ();
	  }
	virtual ~TCenturyOutputSet ()
	  {
	    delete [] p;
	    p = 0;
	  }
	TCenturyOutputSet (
	  TCenturyOutputSet const & object)	// copy constructor
	  : numFloats ( object.numFloats )
	  {
	    Initialize ();
	    Copy (object);
	  }

	//---- operator overloads
	TCenturyOutputSet& operator= (TCenturyOutputSet const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	// Assume array sizes are the same
		Copy (object);
	    }
	    return *this;
	  }

	//--- virtual functions
	virtual void Clear () = 0;		// set all floats to zero
	virtual bool IsMemoryOK () = 0;		// true if no corruption

	//--- inherited functions
	short GetNumValues () const		// number of float values
	  { return numFloats; }

  private:
	//---- functions
	void Initialize ()				// Initialize members
	  {
	    Assert (numFloats > 0);
	    if ( numFloats > 0 )
	    {
	    	p = new float* [numFloats + 1];
	    	p[0] = p[numFloats] = 0;
	    }
	    else
		throw TCentException (TCentException::CE_OVCFCI);
	  }
	void Copy (TCenturyOutputSet const & object)	// Copy to this
	  {
	    if ( &object && numFloats == object.numFloats )
	    {
		float** me = p;
		float** you = object.p;
		for ( short i = 0; i < numFloats; i++ )
		{ *me = *you; ++me; ++you; }
	    }
	  }
	virtual void AssignPointers () = 0;			// initialize p
};

#endif // INC_TCenturyOutputSet_h
