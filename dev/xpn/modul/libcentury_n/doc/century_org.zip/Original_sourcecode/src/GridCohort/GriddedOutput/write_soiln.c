
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include "netcdf.h"
#include "wrtcdf.h"

int
write_soiln(float soiln[][12])
{
	int status;
        float *p = (float *) soiln;

	/* Write output to NetCDF file */
	status = nc_put_vara_float(soiln_ncid, som1n1_id, start, count, p);
	status = nc_put_vara_float(soiln_ncid, som1n2_id, start, count, p + 12);
	status = nc_put_vara_float(soiln_ncid, som2n_id, start, count, p + 24);
	status = nc_put_vara_float(soiln_ncid, som3n_id, start, count, p + 36);
	status = nc_put_vara_float(soiln_ncid, strucn1_id, start, count, p + 48);
	status = nc_put_vara_float(soiln_ncid, strucn2_id, start, count, p + 60);
	status = nc_put_vara_float(soiln_ncid, metabn1_id, start, count, p + 72);
	status = nc_put_vara_float(soiln_ncid, metabn2_id, start, count, p + 84);

	/* Reset memory for variable soiln */
	 memset(p, '\0', (sizeof(float) * 8 * 12));

	return 0;
}
