#ifndef INC_TDayCentSoil_h
#define INC_TDayCentSoil_h
// ----------------------------------------------------------------------------
//	Copyright 1999-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model, daily version
//	File:     TDayCentSoil.h
//	Class:    TDayCentSoil
//
//	Description:
//	Derived from TSoilBase, implements DayCent-specific functions.
//
//	Member functions also in the following files:
//		Misc.:
//			getsoilprop.cpp
//		Leaching:
//			leachNPS.cpp
//			(leachOrg_dc.cpp is TDayCent)
//		Hydrology
//			calcswp.cpp
//			h2oflux.cpp
//			hwdrain.cpp
//			rainflux.cpp
//			soiltransp.cpp
//			swpotentl.cpp
//			watreqn.cpp
//		Soil temperature
//			soiltemp_dc.cpp
//			therm.cpp
//		Trace gas
//			denitrify.cpp
//			diffusiv.cpp
//			methane.cpp
//			nitrify.cpp
//			nox_pulse.cpp
//			tgmodel.cpp
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec99
//		Melannie Hartman, melannie@nrel.colostate.edu (DayCent updates)
//	History:
//	See TCenturySoil.h.
//	Mar2001 - Apr2001 Melannie Hartman, melannie@nrel.colostate.edu
//	* Added ksat and vSwcMin properties and hydrology functions for DayCent
//	Apr2001 Melannie Hartman, melannie@nrel.colostate.edu
//	* Added avg, min, max soil temperature properties and
//	  soil temperature functions for DayCent
//	* Added soil nitrate and ammonium for Trace Gas Model
//	30May01  Melannie Hartman, melannie@NREL.colostate.edu
//	* Added DisplayMsg() pointed to by msgFunction.
//	June2001 Melannie Hartman, melannie@nrel.colostate.edu
//	* Added phosphorus and sulfur soil components
// 	Added indexKsat, indexVSwcMin (Mar 2001)
// 		indexSoilTempAvg, indexSoilTempMin, indexSoilTempMax (4/4/01)
// 		indexNitrate, indexAmmonium (4/11/01)
// 		indexPhosphorus, indexSulfur (6/15/01)
//	Nov2001  Melannie Hartman, melannie@nrel.colostate.edu
//	* Dynamically allocate memory for soil temperature layers instead
//	  of statically allocating MAXSTLYR.
//	28Mar02  Melannie Hartman, melannie@NREL.colostate.edu
//	* Added member function DisplayMsg(), removed msgFunction.
//	Jul02   Tom Hilinski, tom.hilinski@colostate.edu
//	* Added function CheckValues.
//	* Added function MidPointsOfLayers.
//	* Substantial cleanup of CalcSoilTemperatures.
//	* Partial cleanup of CalcThermalDiffusivity.
//	* Arrays are now TFloatArray.
//	* Updated Copy() for new member types.
//	* Local arrays previously allocated in CalcSoilTemperatures and
//	  CalcThermalDiffusivity are now class members of TFloatArray.
//	Nov02   Tom Hilinski, tom.hilinski@colostate.edu
//	* Misc. clean up, const-correctness, optimization.
//	* Inlined and optimized several functions.
//	* Added the typedefs T1DFloatArray, T1DDoubleArray to base class.
//	* Replaced TFloatArray use with T1DFloatArray.
//	* Removed the member functions CopyArray.
//	* SEC_PER_DAY is now long; int is too small to hold the value.
//	* Removed function parameters "number of soil layers".
//	* Renamed pflag to noxPulseTag
//	Dec02   Tom Hilinski, tom.hilinski@colostate.edu
//	* Now uses array types defined in arraytypes.h for its arrays.
//	* Consolidated much of the various submodels' code into several
//	  functions in single files (anticipating more modularity)
// ----------------------------------------------------------------------------
//	Notes:
//	The following soil components are defined in this class:
//
//		    Pool or
//	Component:  Property:   Description:
//	----------  ---------   -------------------------------------------
//	Ksat          property    saturated hydraulic conductivity (cm/sec)
//	vSwcMin       property    minimum soil water content (volum. fraction)
//	soilTempAvg   property    average daily soil temperature (deg C)
//	soilTempMin   property    minimum daily soil temperature (deg C)
//	soilTempMax   property    maximum daily soil temperature (deg C)
//	nitrate       pool        soil nitrate (gN/m^2)
//	ammonium      pool        soil ammonium (gN/m^2)
//	phosphorus    pool        soil phosphorus (gP/m^2)
//	sulfur        pool        soil sulfur (gS/m^2)
//
//	Soil components are indexed in in TMCSoil:
//  	index	component	Where created:		Type:
//	------- --------------- ----------------------- --------
//      8       sat hydr cond     ReadSiteParameters    property
//      9       min vol swc       ReadSiteParameters    property
//     10       soil temp. avg    ReadSiteParameters    property
//     11       soil temp. min    ReadSiteParameters    property
//     12       soil temp. max    ReadSiteParameters    property
//     13       nitrate           ReadSiteParameters    pool
//     14       ammonium          ReadSiteParameters    pool
//     15       phosphorus        ReadSiteParameters    pool
//     16       sulfur            ReadSiteParameters    pool
// ----------------------------------------------------------------------------

#include "TCenturySoil.h"
#include "TDayCentException.h"		// exception class
#include "centconsts.h"
#include "SoilWaterModel.h"
#include <memory>

enum TSoilTextureIndex
{
	UNDEFINED = 0,
	COARSE  = 1,		// texture type for sandy soil
	MEDIUM = 2,		// texture type for medium (loamy) soil
	FINE = 3, 		// texture type for fine soil
	VERYFINE = 4 		// texture type for volcanic soil
};

class TDayCentSoil : public TCenturySoil
{
  public:
	//--- constructors and destructor
	TDayCentSoil (
	  nrel::eco::TEcosystemModelBase const & useOwner)	// owner = model
	  : TCenturySoil (useOwner)
	  {
	    Initialize ();
	  }
	TDayCentSoil (
	  nrel::eco::TEcosystemModelBase const & useOwner,	// owner = model
	  short const useNumLayers)
	  : TCenturySoil (useOwner, useNumLayers)
	  {
	    Initialize ();
	  }
	TDayCentSoil (					// copy constructor
	  TDayCentSoil const & object)
	  : TCenturySoil (object)
	  {
	    if (this != &object)	// check for assignment to self
	    {
		Initialize ();
		Copy (object);
	    }
	  }
	~TDayCentSoil ()
	  {
	  }

	//--- operator overloads
	TDayCentSoil& operator = (
	  TDayCentSoil const & object)
	  {
	    if (this != &object)	// check for assignment to self
	    {
		TCenturySoil::operator= (object);
		Copy (object);
	    }
	    return *this;
	  }

	// --------------------------------------------------------------------
	// Queries

	//--- Data Access functions
							//--- data vectors
	TSoilProperty& Ksat ()  			// Sat hydraulic cond (cm/sec)
	  { return static_cast<TSoilProperty&>(
	    *compList[indexKsat]); }
	TSoilProperty const & Ksat () const		// Sat hydraulic cond (cm/sec)
	  { return static_cast<TSoilProperty&>(
	    *compList[indexKsat]); }
	TSoilProperty& VSwcMin ()			// SWC lower limit (frac)
	  { return static_cast<TSoilProperty&>(
	    *compList[indexVSwcMin]); }
	TSoilProperty const & VSwcMin () const  	// SWC lower limit (frac)
	  { return static_cast<TSoilProperty&>(
	    *compList[indexVSwcMin]); }
	TSoilProperty& SoilTempAvg ()  			// Avg dly soil temp (deg C)
	  { return static_cast<TSoilProperty&>(
	    *compList[indexSoilTempAvg]); }
	TSoilProperty const & SoilTempAvg () const      // Avg dly soil temp (deg C)
	  { return static_cast<TSoilProperty&>(
	    *compList[indexSoilTempAvg]); }
	TSoilProperty& SoilTempMin ()  			// Min dly soil temp (deg C)
	  { return static_cast<TSoilProperty&>(
	    *compList[indexSoilTempMin]); }
	TSoilProperty const & SoilTempMin () const      // Min dly soil temp (deg C)
	  { return static_cast<TSoilProperty&>(
	    *compList[indexSoilTempMin]); }
	TSoilProperty& SoilTempMax ()  			// Max dly soil temp (deg C)
	  { return static_cast<TSoilProperty&>(
	    *compList[indexSoilTempMax]); }
	TSoilProperty const & SoilTempMax () const      // Max dly soil temp (deg C)
	  { return static_cast<TSoilProperty&>(
	    *compList[indexSoilTempMax]); }
	TSoilPool& Nitrate ()   			// Nitrate, NO3- (gN/m^2)
	  { return static_cast<TSoilPool&>(
	    *compList[indexNitrate]); }
	TSoilPool const & Nitrate () const		// Nitrate, NO3- (gN/m^2)
	  { return static_cast<TSoilPool&>(
	    *compList[indexNitrate]); }
	 TSoilPool& Ammonium ()  			// Ammonium, NH4+(gN/m^2)
	  { return static_cast<TSoilPool&>(
	    *compList[indexAmmonium]); }
	TSoilPool const & Ammonium () const		// Ammonium, NH4+(gN/m^2)
	  { return static_cast<TSoilPool&>(
	    *compList[indexAmmonium]); }
	TSoilPool& Phosphorus ()			// Phosphorus (gP/m^2)
	  { return static_cast<TSoilPool&>(
	    *compList[indexPhosphorus]); }
	TSoilPool const & Phosphorus () const		// Phosphorus (gP/m^2)
	  { return static_cast<TSoilPool&>(
	    *compList[indexPhosphorus]); }
	TSoilPool& Sulfur ()				// Sulfur (gS/m^2)
	  { return static_cast<TSoilPool&>(
	    *compList[indexSulfur]); }
	TSoilPool const & Sulfur () const		// Sulfur (gS/m^2)
	  { return static_cast<TSoilPool&>(
	    *compList[indexSulfur]); }
	T1DDoubleArray const & SaturationCapacity ()
	  { return thetaSat; }
							//--- data elements
	float& Ksat (       				// Sat hydraulic cond (cm/sec)
	  short const layerIndex)			//   index to layer
	  { return CompValue(indexKsat,layerIndex); }
	float const & Ksat (				// Sat hydraulic cond (cm/sec)
	  short const layerIndex) const			//   index to layer
	  { return CompValue(indexKsat,layerIndex); }
	float& VSwcMin (    				// SWC lower limit (frac)
	  short const layerIndex)			//   index to layer
	  { return CompValue(indexVSwcMin,layerIndex); }
	float const & VSwcMin ( 			// SWC lower limit (frac)
	  short const layerIndex) const			//   index to layer
	  { return CompValue(indexVSwcMin,layerIndex); }
	float& SoilTempAvg (				// Avg dly soil temp (deg C)
	  short const layerIndex)			//   index to layer
	  { return CompValue(indexSoilTempAvg,layerIndex); }
	float const & SoilTempAvg (			// Avg dly soil temp (deg C)
	  short const layerIndex) const			//   index to layer
	  { return CompValue(indexSoilTempAvg,layerIndex); }
	float & SoilTempMin (   			// Min dly soil temp (deg C)
	  short const layerIndex)			//   index to layer
	  { return CompValue(indexSoilTempMin,layerIndex); }
	float const & SoilTempMin (			// Min dly soil temp (deg C)
	  short const layerIndex) const			//   index to layer
	  { return CompValue(indexSoilTempMin,layerIndex); }
	float& SoilTempMax (				// Max dly soil temp (deg C)
	  short const layerIndex)			//   index to layer
	  { return CompValue(indexSoilTempMax,layerIndex); }
	float const & SoilTempMax (			// Max dly soil temp (deg C)
	  short const layerIndex) const			//   index to layer
	  { return CompValue(indexSoilTempMax,layerIndex); }
	float& Nitrate (    				// Nitrate (gN/m^2)
	  short const layerIndex)			//   index to layer
	  { return CompValue(indexNitrate,layerIndex); }
	float const & Nitrate ( 			// Nitrate (gN/m^2)
	  short const layerIndex) const			//   index to layer
	  { return CompValue(indexNitrate,layerIndex); }
	float& Ammonium (   				// Ammonium (gN/m^2)
	  short const layerIndex)			//   index to layer
	  { return CompValue(indexAmmonium,layerIndex); }
	float const & Ammonium (			// Ammonium (gN/m^2)
	  short const layerIndex) const			//   index to layer
	  { return CompValue(indexAmmonium,layerIndex); }
	float& Phosphorus ( 				// Phosphorus (gP/m^2)
	  short const layerIndex)			//   index to layer
	  { return CompValue(indexPhosphorus,layerIndex); }
	float const & Phosphorus (			// Phosphorus (gP/m^2)
	  short const layerIndex) const			//   index to layer
	  { return CompValue(indexPhosphorus,layerIndex); }
	float& Sulfur (					// Sulfur (gS/m^2)
	  short const layerIndex)			//   index to layer
	  { return CompValue(indexSulfur,layerIndex); }
	float const & Sulfur (  			// Sulfur (gS/m^2)
	  short const layerIndex) const			//   index to layer
	  { return CompValue(indexSulfur,layerIndex); }

	// Misc. public DayCent functions

	float WFPS (				// water filled pore space (0-1)
	  short const layerIndex		//   index to layer
	  ) const
	  {
	    return soilWaterModel->WFPS (
	    	BulkDensity(layerIndex),
	    	WaterContent(layerIndex),
		thickness[layerIndex] );
	  }
	float WtdMeanWFPS (
	  float const toDepth) const;		// depth into soil (cm)

	float GetSoilPH () const		// Get soil pH
	  { return pHsoil; }
	void SetSoilPH (			// soil pH (0-14)
	  float const useSoilPH)
	  {
	    Assert (useSoilPH > 0.0f);
	    Assert (useSoilPH < 14.0f);
	    pHsoil = useSoilPH;
	  }

	TSoilTextureIndex GetSoilTextureIndex () const
	  { return textureIndex; }
	void SetSoilTextureIndex (
	  float const simDepth)			// simulation depth (cm)
	  {
	    float const sandFraction =
		SandFraction().WtdMean (0.0f, simDepth,
   					depth, thickness);
	    SetSoilTextureIndexFromFraction (sandFraction);
	  }
	void SetSoilTextureIndex (
	  TSoilTextureIndex useTextureIndex)		// new texture index
	  {
	    Assert ( useTextureIndex == COARSE ||
	    	useTextureIndex == MEDIUM ||
		useTextureIndex== FINE ||
		useTextureIndex == VERYFINE );
	    textureIndex = useTextureIndex;
	  }
	void SetSoilTextureIndexFromFraction (
	  float const sandFraction);		// sand fraction (0-1)
	float AmmoniumFraction () const		// Fraction of mineral N = NH3
	  {
	    float const ammonium =
	    	Ammonium().Quantity (0, BottomLayer());
	    float fraction = 0.0f;
	    if (ammonium > 0.0f)
		fraction = 1.0f - NitrateFraction();
 	    return fraction;
	  }
	float AmmoniumFraction (		// Fraction of mineral N = NH3
	  float const topDepth,			//   top soil depth (cm)
	  float const bottomDepth) const	//   bottom soil depth (cm)
	  {
	    // error checks done in TSoilPool::Quantity
	    float const ammonium =
	    	Ammonium().Quantity (
			topDepth, bottomDepth, depth, thickness );
	    float fraction = 0.0f;
	    if (ammonium > 0.0f)
		fraction =
		  1.0f - NitrateFraction (topDepth, bottomDepth);
	    return fraction;
	  }
	float NitrateFraction () const;
	float NitrateFraction (
	  float const topDepth,			// top of soil region (cm)
	  float const bottomDepth) const;	// bottom of soil region (cm)
	float QuantityE (			// Mineralized N,P,S in layer
	  TMineralElements element,		//   this element
	  unsigned short const top,		//   top layer
	  unsigned short const bottom		//   bottom layer
	  ) const
	  {
	    float amount;
	    if (element == N)
		amount =
		  Ammonium().Quantity (top, bottom) +
		  Nitrate().Quantity (top, bottom);
	    else if (element == P)
		amount =
		  Phosphorus().Quantity (top, bottom);
	    else if (element == S)
		amount =
		  Sulfur().Quantity (top, bottom);
	    else
		amount = 0.0f;
	    return amount;
	  }
	float QuantityE (			// Mineralized N,P,S in layer
	  TMineralElements element,		//   this element
	  float const topDepth,			//   top soil depth (cm)
	  float const bottomDepth		//   bottom soil depth (cm)
	  ) const
	  {
	    float amount;
	    if (element == N)
		amount =
		  Ammonium().Quantity (topDepth, bottomDepth,
		  			depth, thickness) +
		  Nitrate().Quantity (topDepth, bottomDepth,
		  			depth, thickness);
	    else if (element == P)
		amount =
		  Phosphorus().Quantity (topDepth, bottomDepth,
					depth, thickness);
	    else if (element == S)
		amount =
		  Sulfur().Quantity (topDepth, bottomDepth,
		  			depth, thickness);
	    else
		amount = 0.0f;
	    return amount;
	  }

	// --------------------------------------------------------------------
	// Begin DayCent hydrology functions

	void InitializeSoilWaterArrays ();

	void SoilWaterFlux (		// DayCent hydrology model
	  float const rainDuration,	// rain duration (hours)
	  T1DFloatArray const & soilTavg,// avg soil temp by layer (deg C)
	  float const watrInput,	// rain+snowmelt+rig to be added to
					//   soil profile (cm/day)
	  float const bareSoilEvapMax,	// potential bare-soil evap (cm/day)
	  float const snowPack,		// snow water equivalent (cm H2O)
	  float & soilEvap,		// evaporation from soil(cm H2O)
	  float & outflow,		// water that runs off or drains out of
					//   soil profile (cm H2O)
	  float & runoff);              // inflitration excess/return flow (cm)

	void AddWaterToSoil (  		// Add rain+melt+irrig to soil
	  int const infiltTime,		// duration of rain/snow event (hours)
	  float const watrInput,	// amount of rain and snowmelt (cm)
	  float const infiltCapacity,	// ... at top of soil profile (cm/sec)
	  T1DFloatArray const & soilTavg, // avg soil temp by layer (deg C)
	  T1DDoubleArray const & thetaSat, // vol. swc at saturation (frac)
	  T1DDoubleArray const & swcFieldCapacity, // swc at field capac (cm)
	  T1DDoubleArray & swc, 		// soilwater content (cm H2O)
	  double & cumTime,		// elapsed time to infiltrate (sec)
	  double & runoff,		// rain/melt that did not infilt (cm)
	  double & cumInfilt,  		// amount of water infiltrated (cm)
	  double & drainageOut);	// drainage out of soil profile (cm H2O)

	void UpdateSoilWaterArrays ();  // Compute soil water potentials

	void SoilTranspiration (
	  float const potentialTransp,	// potential transp rate (cm H2O/day)
	  float const tcoeff[MAXLYR],	// transpiration coefficients of lyrs (frac)
    					//    (fixed.awtl)
	  T1DFloatArray & transp,	// actual transp rate from each lyr (cm H2O/day)
	  float & actualTransp);	// total actual transp rate from all lyrs (cm H2O/day)

       void LeachMineralNPS (		// Leach E; return amount to deep-store
	 short const numElements, 	// number of elements to be leached (1-3)
	 float const critflow,  	// critical interlayer water flow for leaching
					//   of inorganic soil minerls (cm H2O/day)
	 T1DFloatArray const & fractionLeached,	// leaching fraction for each minerl
	 float const baseFlowFraction,		// base flow fraction (0-1)
	 float const stormFlowFraction,		// storm flow fraction (0-1)
	 float * const stream);		// stream flows (updates stream[N+1],
					//   stream[P+1], and stream[S+1])

	float GetDeepSoilWatrStore () const     // Get deep water storage amount (cm)
	  { return deepSoilWaterStore; }
	double GetDeepSoilMnrlStore (		// Get deep minerl storage amount (gE/m^2)
	  short const element) const		// index to element (N, P, S)
	  { return deepSoilMnrlStore[element]; }
	T1DFloatArray const & GetSoilWaterPotential () const
	  { return soilWaterPotential; }

	// End DayCent hydrology functions
	// --------------------------------------------------------------------

	// --------------------------------------------------------------------
	// Begin DayCent soil temperature functions

	void SetAvgThermalDiffusivity (	// set unfrz and frz soil
	  				//   thermal diffusivities
	  float const avtd,		//   unfrozen soil diffusivity (units?)
	  float const avtdfz)	  	//   frozen soil diffusivity (units?)
	  {
	    Assert ( (avtd > 0.0f)   && (avtd <= 1.0f) );
	    Assert ( (avtdfz > 0.0f) && (avtdfz <= 1.0f) );
	    avgThermalDiffusivUnFrzn = avtd;
	    avgThermalDiffusivFrzn = avtdfz;
	  }

	std::pair		// unfrz and frz soil thermal diffusivity
	<
	  float,		// first = unfrozen soil diffusivity (units?)
	  float			// second = frozen soil diffusivity (units?)
	>
	  GetAvgThermalDiffusivity () const
	  {
	    return std::pair<float, float> (
		std::make_pair(
			avgThermalDiffusivUnFrzn,
			avgThermalDiffusivFrzn) );
	  }

	void SetTemperatureInterval (	// set interval for soil temp. calcs
	  float const stdx)		//   soil temp. depth interval (cm)
	  {
	    Assert ( (stdx >= 1.0f) && (stdx <= 5.0f) );
	    soilTemperatureInterval = stdx;
	  }
					// Get interval for soil temp. calcs
	float GetTemperatureInterval () const
	  { return soilTemperatureInterval; }

	void SetTemperatureDmpFactor (	// set soil temp. correction factor
	  float const stdmp)		//  time step correction factor (frac)
	  {
	    Assert ( (stdmp > 0.0f) && (stdmp <= 1.0f) );
	    soilTemperatureDmpFactor = stdmp;
	  }
					// Get soil temp.time step correction factor
	float GetTemperatureDmpFactor () const
	  { return soilTemperatureDmpFactor; }

	void SetSoilBottomParams (	// Set parameters for bottom of
	  				//   soil profile
	  float const tbotmn,		// min bottom soil temp during year (C)
	  float const tbotmx,		// max bottom soil temp during year (C)
	  float const timlag)	  	// time lag from year beginning to reach
					// min temp (days)
	  {
	    Assert ( (tbotmn > -50.0f) && (tbotmn < 75.0f) );
	    Assert ( (tbotmx > -50.0f) && (tbotmx < 75.0f) );
	    Assert ( (timlag >= 0.0f)  && (timlag < 366.0f) );
	    soilBottomTempMin = tbotmn;
	    soilBottomTempMax = tbotmx;
	    soilBottomTimeLag = timlag;
	  }
	float GetSoilBottomTempMin () const
	  { return soilBottomTempMin; }
	float GetSoilBottomTempMax () const
	  { return soilBottomTempMax; }
	float GetSoilBottomTimeLag () const
	  { return soilBottomTimeLag; }

	void CalcSoilTemperatures (	// Calculate soil temp profile
	  int const jday,		// day of the year (1..366)
	  float const biomass,  	// above ground biomass (gm/m**2)
	  float const airTempMin,	// min air temperature for jday (deg C)
	  float const airTempMax,	// max air temperature for jday (deg C)
	  float const dayLength,	// day length (hours)
	  float const snowPack, 	// current snow pack amount (cm SWE)
	  float const pmntmp,		// biomass effect on min soil srfc temp
	  float const pmxtmp,		// biomass effect on max soil srfc temp
	  float const pmxbio,		// max biomass value for soil surface
	  				//   temp calcs
	  float & surfTempAvg); 	// avg soil surface temp for jday (C)

	void InitTemperatureLayers (	// Initialzie soil temperature layers
	  int const numlyrs,		// # of soil layers in profile
	  				//   (1..MAXLYR)
	  TSoilBase::TFloatArray const &
	  		soilTemp);	// soil temperature of layers (deg C)

	void AllocSoilTemperatureLayers ();

  protected:
	void CalcThermalDiffusivity (
	  float const airTempMin,	// min air temp. for the day (deg C)
	  float const airTempMax,	// max air temp. for the day (deg C)
	  T1DFloatArray & thermDif,	// thermal diffusivity of soil temp
	  				//   layers (units?)
	  T1DFloatArray & vh2oc,	// volum swc of soil temp lyrs (frac)
	  T1DFloatArray & hcst);	// heat capacity of soil temp
	  				//   lyrs (cal/K)

	void InitializeSoilTempModel ();
	void CopySoilTempModel (	 // Copy soil temp data into this
	  TDayCentSoil const & fromObj);
	bool CheckSoilTempValues ();	// Check member data for validity
					//   Return true if failed check.
	// End DayCent soil temperature functions
	// --------------------------------------------------------------------

	// --------------------------------------------------------------------
	// Begin DayCent trace gas functions

  public:
	void TraceGasModel (		// Compute N2O and NO fluxes
	  float const simDepth,		  //   simulation depth (cm)
	  TSoilTextureIndex textureIndex, //   soil texture index
	  bool const isDeciduous,	// true if deciduous forest
	  bool const isAgriculture,	// true if crop or
					//   fertilized or cultivated grassland
	  float const surfTempAvg,	// avg soil surface temperature (deg C)
	  float const maxt,  		// max of montly max temps (deg C)
	  float const ppt,		// daily precip (cm)
	  float const snowPack,      	// snow cover (cm SWE)
	  float const newCO2,		// soil respiration (gC/m^2/day)
	  float & fluxNO,	        // NO flux (gN/m^2/day)
	  float & fluxNitrifN2O,	// nitrification N2O flux (gN/m^2/day)
	  float & fluxDenitrifN2O,	// denitrification N2O flux (gN/m^2/day)
	  float & fluxDenitrifN2);	// denitrification N2 flux (gN/m^2/day)

	double Nitrify (		// Nitrification (returns NO3)
	  TSoilTextureIndex textureIndex,  // soil texture index
	  float const surfTempAvg,	// average soil surface temperature
	  				//   (deg C)
	  float const maxt,		// Long term avg max monthly air temp of
					//   hottest month (deg C)
	  float const avgWFPS,		// avg wfps in top 15 cm of soil (0-1)
	  float const nitrifDepth,	// depth into soil over which
	  				//   nitrification occurs (cm)
	  double & ammonium);		// soil ammonium (gN/m^2)

	void Denitrify (		// Denitrifiction
	  float const simDepth,		// simulation depth (cm)
	  T1DFloatArray const & co2PPM,	// soil CO2 concentration
	  T1DDoubleArray & nitrate,	// nitrate content by layer (gN/m^2)
	  double & Dn2oflux,		// N2O flux during Denitrification
	  				//   (g N/m2/day)
	  double & Dn2flux);		// N2 flux during Denitrification
	  				//   (g N/m2/day)

	inline
	  float FracNetMinToNitrate ()	// Fraction of N mineralixation
					//   that goes to Nitrate (vs. Ammonium)
	  { return 0.0f; /* all new mineral N to NH4 */ }

					//----- NOx Pulse submodel ------------
	void InitializeNOxPulseModel (); // Initialize soil NOX pulse variables

	void CopyNOxPulseModel (
	  TDayCentSoil const & fromObj); // Copy Nox pulse model data into this

	bool CheckNOxPulseValues ();	// Check NOx pulse data for validity

	float NOxPulse (		// Effect of rain and snow on NOx
	  float const ppt,		// the current day's precipitation (cm)
	  float const snow);		// snow pack on the ground (cm SWE)

					//----- misc --------------------------
	float Diffusivity (		// Soil Diffusivity
	  float const A,		// frac of soil bed volume occupied by field capcity
					//   (intra-aggregate pore space, 0-1)
	  float const bulkden,		// bulk density of soil (g/cm^3)
	  float const porosity,		// porosity fraction (0-1)
	  float const wfps);		// Water Filled Pore Space (0-1)

	float MethaneOxidation (	// Methane Oxidation flux (gC/m^2/day)
	  bool const isDeciduous,	// true if deciduous forest
	  bool const isAgriculture);	// true if agricultural system or grassland
					//   that has been fertilized or cultivated,

	// End DayCent trace gas functions
	// --------------------------------------------------------------------

	void GetSoilProperties (
	  TSoilTextureIndex textureIndex, 	// coarseness/fineness of soil
	  float const sandFraction,		// soil sand fraction (0-1)
	  float const siltFraction,		// soil silt fraction (0-1)
	  float const clayFraction,		// soil clay fraction (0-1)
	  float & bulkDensity,			// bulk density (g/cm^3)
	  float & fieldCapacity);		// field capacity (0-1)

	//--- misc. functions
	void Clear ();  			// "clear" and delete data
	virtual TDayCentSoil * const Clone () const		// Clone this
	  { return new TDayCentSoil (*this); }

  protected:
	//--- constants
	static float const PARTDENS;		// Particle Density (g/cm^3)
	static float const BAR2CM; 		// 1 bar = 1024 cm H2O
	static long const SEC_PER_DAY;		// # of seconds per day
	static short const SEC_PER_HOUR;	// # of seconds per hour
	static short const HOURS_PER_DAY;	// # of hours per day
	// static float const frozenSoilTemp;		// temperature soil freezes (deg C)
	static double const MIN_FRZN_COND;	// hydraul cond in frz soil (cm/sec)

	// NOX submodel
	static short const PPTDAYS;		// nox_pulse.cpp
	static short const PLDAYS; 		// nox_pulse.cpp
	static short const PMDAYS; 		// nox_pulse.cpp
	static short const PHDAYS; 		// nox_pulse.cpp

	static short const			// component indices
		indexKsat,
		indexVSwcMin,
		indexSoilTempAvg,
		indexSoilTempMin,
		indexSoilTempMax,
		indexNitrate,
		indexAmmonium,
		indexPhosphorus,
		indexSulfur;

//	T1DDoubleArray depthArray;	// depth[] optimized array
//	void UpdateDepthArray ()
//	  {
//	    for ( short i = 0; i < depth.size(); ++i )
//	    	depthArray(i) = depth[i];
//	  }


	//--- submodels
	std::auto_ptr<SoilWaterModel> soilWaterModel;

	//----- N trace gas submodel -----

	void CalcNDistributionFactors (	// exponential redistribution factors
	  TSoilBase::TFloatArray const & depth,	// soil depth array
	  T1DDoubleArray & k);			// N redistribution factors

	// for Denitrify
	T1DDoubleArray grams_soil;
	T1DDoubleArray nitratePPM;
	T1DDoubleArray fluxNTotal;

	//--- data for NOX variables
	// The following (static) variables are now
	// protected TDayCentSoil members to avoid conflicts when more
	// than one TDayCentSoil object is instantiated.
	T1DFloatArray cumppt;			// [PPTDAYS]
	T1DFloatArray pl;  			// [PLDAYS]
	T1DFloatArray pm;  			// [PMDAYS]
	T1DFloatArray ph;  			// [PHDAYS]
	T1DFloatArray mtplr;			// [PHDAYS]
	int npl, npm, nph, nppt, mptr;
	int noxPulseTag;

	//--- data: SoilWaterFlux
	float deepSoilWaterStore;	// deep soil storage  (cm H2O)
	double deepSoilMnrlStore[NUMELEM]; // deep mineral storage (gE/m^2)
	// The following do NOT need to be copied in Copy()
	// They are here so as to prevent repeated allocations in SoilWaterFlux
	T1DDoubleArray swc;		// soilwater content by layer (cm H2O)
	T1DDoubleArray swcFieldCapacity; // swc at field capacity (cm H2O)
	T1DDoubleArray thetaSat;	// soilwater content at saturation
					//   (volumetric fraction)
	T1DDoubleArray hydrCond;	// hydraulic conductivity of a layer (cm/sec)
	T1DDoubleArray matricPotentl;	// matric potential head (-cm)
	T1DDoubleArray headPotentl;	// total head (-cm), surface = 0cm
	T1DDoubleArray flux;		// See above comment block
	T1DDoubleArray avgHydrCond;	// avg hydraulic conductivity of layers
					//   i-1 and i (cm/sec)
	T1DDoubleArray theta;		// vol. soilwater content fraction
	T1DDoubleArray swcMin;		// minimum soilwater content by layer
					//   (cm H20)
					// For SoilWaterPotential function:
	T1DFloatArray soilWaterPotential;	// (bars)
	T1DDoubleArray psiSat;		// saturation matric potential (cm H2O)
	T1DDoubleArray swrc;		// slope of the retention curve

	//--- data: Misc
	float pHsoil;			// Soil pH (0-14)
	TSoilTextureIndex textureIndex;	// soil texture index

	//--- data: soil temperature parameters
	T1DFloatArray dist;		// thickness of upper half of layers
	short numSoilTemperatureLayers;	// Number of soil temperature layers
	float soilTemperatureInterval;	// Depth interval for soil temp calcs (cm)
	float avgThermalDiffusivUnFrzn;	// Avg thermal diffusivity in unfrozen soil (units?)
	float avgThermalDiffusivFrzn;	// Avg theraml diffusivity in frozen soil (units?)
	float soilTemperatureDmpFactor;	// time step correction factor (frac)
	float soilBottomTempMin;	// Minimum temperature at the bottom of
					//   soil profile during the year (deg C)
	float soilBottomTempMax;	// Maximum temperature at the bottom of
					//   soil profile during the year (deg C)
	float soilBottomTimeLag;	// Time lag from beginning of year to reach
					//   minimum bottom temperature (days)

	//--- data: soil temperature layers
	// Soil temperature layers are small and equivalent in thickness,
	// and are used  to calculate temperatures of soil layers.
	T1DFloatArray soilTempLyrAvg;	// avg dly temp of soil temp lyrs (deg C)
	T1DFloatArray soilTempLyrMin;	// min dly temp of soil temp lyrs (deg C)
	T1DFloatArray soilTempLyrMax;	// max dly temp of soil temp lyrs (deg C)
	T1DFloatArray freezeEnergyPool;	// freeze energy pool of soil temp lyrs (deg C)
	T1DFloatArray depthToMidPt;	// layer midpoint depth

	// Local arrays for soil temperature layers.
	// Used only in CalcSoilTemperatures, and are reinitialized each entry.
	// Storage is allocated in CalcSoilTemperatures.
	T1DFloatArray dtemp;		// daily delta temp (deg C/day)
	T1DFloatArray thermDif;		// thermal diffusivity (units?)
	T1DFloatArray vh2oc;		// volum soil water content (frac)
	T1DFloatArray hcst;		// heat capacity (cal/K)
	T1DFloatArray freezeEnergy;	// freeze energy (deg C)

	// Local arrays for soil thermal diffusivity in layers.
	// Used only in CalcThermalDiffusivity, and are reinitialized each entry.
	// Storage is allocated in CalcThermalDiffusivity.
	T1DFloatArray heatCapacity;	// heat capacity (units?)
	T1DFloatArray weightFractionH2O;	// weight frac of moisture

	//--- functions
	void MidPointsOfLayers ();	// Calc depths to midpoints of layers

	//----- Water submodel -----

	// Saturation water content:
	// Use Bulk Density based thetaSat[] instead of one computed by
	// WaterEquation()
	double PartonThetaSaturation (
	  double const bulkDensity)
	  { return (0.95 * ( 1.0 - bulkDensity / PARTDENS ) ); }

  private:
	//--- functions
	void Initialize (); 				// initialize members
	void Copy (TDayCentSoil const & fromObj);	// copy to this
};

#endif // INC_TDayCentSoil_h
