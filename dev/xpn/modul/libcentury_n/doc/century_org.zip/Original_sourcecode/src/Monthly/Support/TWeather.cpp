// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TWeather.cpp
//	Class:	  TWeather
//
//	Description:
//	Class to manage weather variables.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jun98
// ----------------------------------------------------------------------------
//	History: See header file.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Notes:
//	* Uses two external random functions, one for normal, and one for
//	skewed normal distributions.
//	* Currently uses the Century exception function. This should be changed
//	to incorporate it's own exception methods.
// ----------------------------------------------------------------------------

#include "TWeather.h"
#include "TCentException.h"
#include "AssertEx.h"
#include "TCenturyMath.h"
#include <sstream>
using namespace std;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

char const * const TWeather::labels[3] = { "prec", "tmin", "tmax" };

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

TWeather::TWeather (
	TCalendarTools * const useCT)	// calendar functions
	: TWeatherBase (useCT)
{
	Initialize ();
	//::zufalli (25169);		// initialize random number generator
}

TWeather::~TWeather ()
{
	if ( wf.is_open() )				// close the file stream
		wf.close ();
}

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

bool TWeather::operator== (
	TWeather const & object) const
{
	if ( &object )
	{
		return TWeatherBase::operator== (object) &&
			fileName == fileName &&
			sourceData == sourceData;
	}
	else
		return false;
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	Clear
//	reset to initial state
void TWeather::Clear ()
{
	if ( wf.is_open() )			// close the file stream
		wf.close ();
	Initialize ();
}

//	InitAnnualData
//	Retrieves or generates the data for the next year.
//	Checks the specified year against the year in the data file.
//	There is always two years worth of data ready - current years and
//	next years data.
void TWeather::InitAnnualData (
	const TWeatherSrc newSource,	// weather source
	char const* newFileName) 	// file weather name
{
	//--- Use means from site file for current & next year
	if ( newSource == WS_Means )
	{
		if ( newSource == sourceData )
			return;			// site means don't change
		sourceData = WS_Means;
		// get data into the current year's arrays
		CopyArray (minTempSP, minTempCY, mpy);
		CopyArray (maxTempSP, maxTempCY, mpy);
		CopyArray (precipSP,  precipCY,  mpy);
		// get data into the next year's arrays
		CopyArray (minTempSP, minTempNY, mpy);
		CopyArray (maxTempSP, maxTempNY, mpy);
		CopyArray (precipSP,  precipNY,  mpy);
	}
	//--- Stochastic precipitation - site mean temps.
	else if ( newSource == WS_Stochastic )
	{
	    if ( sourceData == WS_Stochastic )	// previously stoch.?
	    {
		// put next year's precip data into this year's
		CopyArray (precipNY,  precipCY,  mpy);
		// keep previous temp data
	    }
	    else			// previous data was not stochastic
	    {
		// temps use the site parameter mean values
		if ( sourceData != WS_Means )	// previously done?
		{
			// get data into the current year's arrays
			CopyArray (minTempSP, minTempCY, mpy);
			CopyArray (maxTempSP, maxTempCY, mpy);
			// get data into the next year's arrays
			CopyArray (minTempSP, minTempNY, mpy);
			CopyArray (maxTempSP, maxTempNY, mpy);
		}
		// precip is stochastic
		StochasticPrecip (precipCY);	// this year's
		sourceData = WS_Stochastic;
	    }
	    // refill next year's precip data
	    StochasticPrecip (precipNY);
	}
	//--- Open/Rewind a weather file
	else if ( newSource == WS_FileRewind )
	{
		std::string aName;			// string to work with
		if ( newFileName )			// if a name...
			aName = newFileName;		// ...save it in string
		if ( aName.empty() ) 			// no new name?
		{
		    if ( fileName.empty() ) 		// no prev. name?
		    {
			ThrowCentException (TCentException::CE_WTHRFL,
						"File name is empty.");
		    }
		    else				// have a prev. name
			Rewind ();			// ...rewind file
		}
		else					// have a new name
		{
		    if ( aName == fileName &&		// same name?
		         wf.is_open() )			// and already open?
		    {
			Rewind ();			// ...rewind file
		    }
		    else				// ...open new file
		    {
			if ( wf.is_open() )		// file already open?
				wf.close ();		// ...close it
			if ( InitASCIIDataFile (newFileName) )
			{
				// error opening file
				// should never get here
				Assert (false);
			}
			Rewind ();		// put at known position
		    }
		}
		sourceData = WS_FileRewind;
		// read a year into this year's arrays
		if ( ReadAnnualData (year, precipCY, minTempCY, maxTempCY) )
		{
                    ThrowCentException (
                    	TCentException::CE_RDWTHR, fileName.c_str());
		}
		ReplaceMissingData (precipCY, minTempCY, maxTempCY);
		// read a year into next year's arrays
		ReadAnnualData (yearNext, precipNY, minTempNY, maxTempNY);
		ReplaceMissingData (precipNY, minTempNY, maxTempNY);
	}
	//--- Continue reading a weather file
	else if ( newSource == WS_FileContinue )
	{
		if ( !wf.is_open()  )			// file not open?
		{
			if ( InitASCIIDataFile (newFileName) )
			{
				// error opening file
				// should never get here
				Assert (false);
			}
			Rewind ();		// put at known position
		}
		sourceData = WS_FileContinue;
		// copy next year's data into this year's arrays
		CopyArray (precipNY, precipCY, mpy);
		CopyArray (minTempNY, minTempCY, mpy);
		CopyArray (maxTempNY, maxTempCY, mpy);
		year = yearNext;
		// read a year into next year's arrays
		ReadAnnualData (yearNext, precipNY, minTempNY, maxTempNY);
		ReplaceMissingData (precipNY, minTempNY, maxTempNY);
	}
	//--- Invalid source specified
	else
	{
		// invalid weather source
		// TO DO: handle this
		return;
	}
	AnnualSummaryCalcs ();		// annual summary stats
}

//	IsEmpty
//	Returns true if no data.
bool TWeather::IsEmpty () const
{
	return sourceData != WS_Unknown;
	// To Do: check arrays
}

//	AdvanceToYear
//	Advance to a year.
//	Return current year.
TYear TWeather::AdvanceToYear (
	TYear findThisYear)	// find this year
{
	TYear yearFound = -999999999L;
	while ( yearFound < findThisYear )		// search for year
	{
		// This is the slow and dirty method, but quick to write
		if ( ( sourceData == WS_FileRewind ||
		       sourceData == WS_FileContinue ) &&
		     year > findThisYear )
		{
			Rewind ();
		}
		InitAnnualData ( sourceData, fileName.c_str() );
		yearFound = year;
	}
	return yearFound;
}

//	GrowingSeasonPrecip
//	Returns the total precipitation for the growing season.
float TWeather::GrowingSeasonPrecip (
	short const month)	// month (1-12)
{
    register short
	endMonth = month - 1,
	m;

    register float gsPrecip = 0.0f;
    float const* p = &precipCY[endMonth];
    for (m = endMonth; m < mpy; ++m, ++p)	// months in current year
	gsPrecip += *p;
    p = precipNY;
    for (m = 0; m < endMonth; ++m, ++p)		// continue into next year
	gsPrecip += *p;
    return gsPrecip;
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	ClearData
//	Zero the data arrays.
void TWeather::ClearData ()
{
	TWeatherBase::ClearData ();
	float *n1 = precipNY, *n2 = minTempNY, *n3 = maxTempNY;
	for ( short i = 0; i < mpy; ++i )
	{
    	    	//--- next year's weather
    	    	*(n1++) = *(n2++) = *(n3++) = 0.0f;
 	}
}

//	ReplaceMissingData
//	Check for data = -99.99: if so, generate valid value.
//	First checks site file weather value - if valid, uses it.
//	If site parameter value is not valid, then
//	(1) for precip, generates a stochastic value
//	(2) for temp, does linear inter/extrapolation. If this estimate fails,
//	    then uses the annual means.
void TWeather::ReplaceMissingData (
	float* precip,		// precipitation
	float* minTemp,		// minimum temperatures
	float* maxTemp)		// maximum temperatures
{
	float *pp = precip, *pmin = minTemp, *pmax = maxTemp;
	for (short m = 0; m < mpy; ++m, ++pp, ++pmin, ++pmax)
	{
		//--- min temp
		if ( *pmin == missingValue )		// value missing?
		{
			if ( minTempSP[m] != missingValue )
				*pmin = minTempSP[m];	// use reference mean
			else
			 	*pmin = EstimateMonthlyValueLinear (minTemp, m);
		 	// estimate not available?
		 	if ( *pmin == missingValue )
		 		*pmin == MeanAnnualValue (minTemp);
		}
		Assert (*pmin > missingValue);
		//--- max temp
		if ( *pmax == missingValue )		// value missing?
		{
			if ( maxTempSP[m] != missingValue )
				*pmax = maxTempSP[m];	// use reference mean
			else
			 	*pmax = EstimateMonthlyValueLinear (maxTemp, m);
		 	// estimate not available?
		 	if ( *pmax == missingValue )
		 		*pmax == MeanAnnualValue (maxTemp);
		}
		*pmax = std::max (*pmax, *pmin);
		Assert (*pmax > missingValue);
		//--- precipitation
		// if (*pp <= missingValue)		// value missing?
		if (*pp < 0.0f)				// value missing?
		{
			if ( precipSP[m] != missingValue)
				*pp = precipSP[m];	// use reference mean
			else				// get random value
				*pp = StochasticPrecip (m);
		 	*pp = std::max (*pp, *pmin);
		}
	}
}

//	SearchForwardForValidValue
//	Search forward in array for a non-missing value.
//	Returns false if successful, else true if not.
bool TWeather::SearchForwardForValidValue (
	float const *& p,	// data array
	short& i,		// starting index (month - 1)
	short const distance	// max number of points to search to
	) const
{
	//--- error checks
	if ( i < 0 || i >= 12 || p == (float const *)0 )
		return true;
	//--- do search
	short count = 0;			// track distance
	// if missing, have points left, and within distance, check
	while (*p == missingValue && i < mpy && count < distance)
		++i, ++p, ++count;		// check next point
	if ( i == mpy || count == distance )	// failed?
		return true;
	else					// successful
		return false;
}

//	SearchBackwardForValidValue
//	Search backward in array for a non-missing value.
//	Returns false if successful, else true if not.
bool TWeather::SearchBackwardForValidValue (
	float const *& p,	// data array
	short& i,		// starting index (month - 1)
	short const distance	// max number of points to search to
	) const
{
	//--- error checks
	if ( i < 0 || i >= 12 || p == (float const *)0 )
		return true;
	//--- do search
	short count = 0;			// track distance
	// if missing, have points left, and within distance, check
	while (*p == missingValue && i < mpy && count < distance)
		--i, --p, ++count;		// check next point
	if ( i < 0 || count == distance )	// failed?
		return true;
	else					// successful
		return false;
}

//	EstimateMonthlyValueLinear
//	Estimates a monthly value from other values in the year.
//	Returns the missing value if fails.
//	Uses linear inter/extrapolation - nothing fancy here.
//	Works ok if only missing value is adjacent month.
//	Does not work well if several missing values in a row.
float TWeather::EstimateMonthlyValueLinear (
	float const data[12],	// data array
	short const m		// month index (0-11)
	) const
{
	//--- error checks
	Assert (m >= 0);
	Assert (m < 12);

	//--- find data points on the line
	float x1, y1, x2, y2;		// data points to use
	float const *p;			// ptr to data array
	short i;			// index to array
	short const distance = 3;	// max no. points to search over
	if ( m == 0 )			//--- jan. extrapolate forward
	{
		p = &data[m + 1];			// start value
		i = m + 1;				// start month
		if ( SearchForwardForValidValue (p, i, distance) )
			return missingValue;		// failed!
		else
			x1 = i, y1 = *p;		// save values
		++i, ++p;				// next starting point
		if ( SearchForwardForValidValue (p, i, distance) )
			return missingValue;		// failed!
		else
			x2 = i, y2 = *p;		// save values
	}
	else if ( m < 11 )		//--- within year interpolate
	{
		p = &data[m - 1];			// start value
		i = m - 1;				// start month
		if ( SearchBackwardForValidValue (p, i, distance) )
			return missingValue;		// failed!
		else
			x1 = i, y1 = *p;		// save values
		p = &data[m + 1];			// start value
		i = m + 1;				// start month
		if ( SearchForwardForValidValue (p, i, distance) )
			return missingValue;		// failed!
		else
			x2 = i, y2 = *p;		// save values
	}
	else				//--- dec. extrapolate back
	{
		p = &data[m - 1];			// start value
		i = m - 1;				// start month
		if ( SearchBackwardForValidValue (p, i, distance) )
			return missingValue;		// failed!
		else
			x1 = i, y1 = *p;		// save values
		--i, --p;				// next starting point
		if ( SearchBackwardForValidValue (p, i, distance) )
			return missingValue;		// failed!
		else
			x2 = i, y2 = *p;		// save values
	}
	//--- inter/extrapolate
	return YOnLine (static_cast<float const>(m), x1, y1, x2, y2);
}

//	InitASCIIDataFile
//	Init a text data file
//	Returns false if successful, else true if error.
bool TWeather::InitASCIIDataFile (
	char const* newFileName)	// file name if source = file
{
	// Expect the data to be in the format:
	// 	prec  1930  11.68 ...
	// 	tmin  1930  -1.11 ...
	// 	tmax  1930   9.44 ...
	// 	prec  1931   4.73 ...
	// 	...

	// ...save file name
	Assert ( newFileName != 0 );
	if ( newFileName && *newFileName )
		fileName = newFileName;
	else
		ThrowCentException (TCentException::CE_WTHRFL, 0);
	// ...open file
	wf.open (newFileName, ios::in);
	if ( !wf.is_open() || wf.fail() || wf.bad() )	// open failed?
		ThrowCentException (
			TCentException::CE_WTHRNO, fileName.c_str());
	return !wf.is_open();
}

//	ReadAnnualData
//	Reads one years worth of data from the weather data file.
//	Returns false if successful, else true if error.
bool TWeather::ReadAnnualData (
	TYear& newYear,		// year of data
	float* precip,		// precipitation
	float* minTemp,		// minimum temperatures
	float* maxTemp)		// maximum temperatures
{
	// to do:
	// * check that years read from each record are the same
	// * store "next year" in class member
	// * ability to handle request for a specific year?

	// check for end of data file
	if ( sourceData == WS_FileRewind )		// rewind?
		CheckForRewind ();
	else
	{
		// if at EOF, what to do???
		if (sourceData == WS_FileContinue)
		{
			CheckForRewind ();
		}
		else
		{
			//  For now, simply return gracefully.
			wf >> ws;		// remove leading white space
			if ( !wf || wf.eof() )
				return true;
		}
	}

	// arrays for new data, and some pointers for speed
	float newPrecip[12], newMinTemp[12], newMaxTemp[12];
	float *pp = newPrecip, *pmin = newMinTemp, *pmax = newMaxTemp;
	for ( short i = 0; i < mpy; ++i )
		*(pp++) = *(pmin++) = *(pmax++) = 0.0f;
	TYear yearRead[3] = {0, 0, 0};		// years read from file
	char newLabel[5];			// "prec", "tmin", or "tmax"

	// 1. Get precip values
	yearRead[0] = 0;
	if ( GetRecord (newLabel, yearRead[0], newPrecip) )	// read failed?
		WthrFileRdError (labels[0], yearRead[0]);
	if ( strcmp ( newLabel, labels[0] ) )		   // label differs?
		WthrFileLabelError (newLabel, labels[0]);  // throw exception

	// 2. Get minimum monthly temperatures
	yearRead[1] = 0;
	if ( GetRecord (newLabel, yearRead[1], newMinTemp) )	// read failed?
		WthrFileRdError (labels[1], yearRead[1]);
	if ( strcmp ( newLabel, labels[1] ) )		   // label differs?
		WthrFileLabelError (newLabel, labels[1]);  // throw exception

	// 3. Get maximum monthly temperatures
	yearRead[2] = 0;
	if ( GetRecord (newLabel, yearRead[2], newMaxTemp))	// read failed?
		WthrFileRdError (labels[2], yearRead[2]);
	if ( strcmp ( newLabel, labels[2] ) )		   // label differs?
		WthrFileLabelError (newLabel, labels[2]);  // throw exception

	// TO DO: Check that all three years are the same

	// save data in "next years" arrays
	pp = newPrecip, pmin = newMinTemp, pmax = newMaxTemp;
	newYear = yearRead[0];
	for ( short i = 0; i < mpy; ++i )
	{
		*(precip++) = *(pp++);
		*(minTemp++) = *(pmin++);
		*(maxTemp++) = *(pmax++);
	}
	// all done!
	return false;
}

//	GetRecord
//	Reads the next record from the weather file.
//	Returns false if successful, else true if not.
bool TWeather::GetRecord (
	char label[5],
	TYear& yearRead,
	float values[12])
{
	short const recLen = 201;
	char record[recLen];				// input line

	// get next line
	if ( wf )					// stream there?
	{
		wf.seekg (0L, ios::cur );		// borland 5.x kluge
		if ( !wf.getline (record, recLen) )	// ...read failed?
			goto error_done;
		if ( wf.fail() ||  wf.bad() )	// open failed?
			ThrowCentException (
				TCentException::CE_RDWTHR, fileName.c_str());
	}
	else						// ...no stream
		goto error_done;

	// parse the record
	if ( !IsComment( record ) )
	{
		string recordString = record;
		istringstream ir (recordString);
		ir.width (5);
		if ( !(ir >> label) )		     	// label
			goto error_done;
		if ( !(ir >> yearRead) )	     	// year
			goto error_done;
		ir.width (10);			     	// values
		for ( short i = 0; i < 12; i++ )	// each month's value...
			if ( !(ir >> values[i]) )	// parse failed?
				goto error_done;
	}
	else
		return true;
	return false;				// successful read of reacord!

    error_done:
	return true;				// read of record failed
}

//	CheckForRewind
//	If at end of file, goes to beginning.
void TWeather::CheckForRewind ()
{
	if ( wf.is_open() )
	{
		wf.clear ();			// clear any errors
		if ( !wf.eof() )		// at end-of-file?
			wf >> ws;		// lose whitespace
		if ( wf.eof() )			// at end-of-file?
			Rewind ();
	}
}

//	Rewind
//	Does the actual rewinding of the file.
void TWeather::Rewind ()
{
	if ( wf.is_open() )
	{
	    wf.clear ();			// clear any errors
	    wf.seekg (0L, ios::cur );		// borland 5.x kluge
	    wf.seekg (0L, ios::beg );		// ...to start of file
	    if ( wf.fail() )			// seekg failed?
	    {
		// try reopening the file
		wf.clear ();			// clear any errors
		wf.close ();			// close the stream
		wf.open (fileName.c_str(), ios::in);	// open stream
		Assert ( ! wf.fail() );
		Assert ( ! wf.bad() );
		if ( !wf.is_open() || wf.fail() ||  wf.bad() )	// open failed?
		    ThrowCentException (
		    	TCentException::CE_WTHRNO, fileName.c_str());
	    }
	}
}

//	WthrFileLabelError
//	Generate a message regarding an error in the error file.
void TWeather::WthrFileLabelError (
	char const *found,	// label found
	char const *expected	// label searching for
	) const
{
	std::ostringstream os;
	os << "A record for \"" << expected << "\" was expected."
	   << "The record found is \"" << found << "\"."
	   << "Year = " << year
	   << std::ends;
	ThrowCentException ( TCentException::CE_WTHROS,
	    				os.str().c_str() );
}

//	WthrFileRdError
void TWeather::WthrFileRdError (
	char const* recName,		// label searching for
	const TYear yearExpected	// year expected
	) const
{
	std::ostringstream os;
	os << "Record = " << recName << " << Year = " << yearExpected
	   << std::ends;
	ThrowCentException ( TCentException::CE_RDWTHR,
	    				os.str().c_str() );
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Initialize
//	Initialize member variables.
void TWeather::Initialize ()
{
	ClearData ();
	yearNext = 0L;
}

//	Copy
// 	copy to this
void TWeather::Copy (TWeather const & object)
{
	if ( &object )
	{
		if ( object.year != AdvanceToYear (object.year) )
		{
			// failed initialization!
			// To Do: Handle Copy failure
		}
	}
}

//--- end of definitions for TWeather ---
