// ----------------------------------------------------------------------------
//	Copyright 2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TMCOutputFileBase.cpp
//	Class:	  TMCOutputFileBase
//
//	Description:
//	Base class for monthly Century output files.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, June 2002
//	History:
//	Jun02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Created this to move the output variable names from the base class
//	  to here, in order to accomodate different output variable sets.
// ----------------------------------------------------------------------------

#include "TMCOutputFileBase.h"

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

char const * const
	TMCOutputFileBase::myOutputSetName[] =		// output set names
	{ "wt", "soilC", "cropC", "forestC", "co2", "nps", 0 };


//--- end of TMCOutputFileBase.cpp ---
