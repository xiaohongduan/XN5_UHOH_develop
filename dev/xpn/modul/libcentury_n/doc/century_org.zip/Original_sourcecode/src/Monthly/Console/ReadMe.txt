File:	Century/version5/src/Console/ReadMe.txt

This directory contains C++ source code for the non-GUI, console interface
to the CENTURY model, version 5.


--- end of file ---