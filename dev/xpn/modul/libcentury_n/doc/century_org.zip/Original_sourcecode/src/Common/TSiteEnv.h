#ifndef INC_TSiteEnv_h
#define INC_TSiteEnv_h

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TSiteEnv.h
//	Class:	  TSiteEnvironment
//
//	Description:
//	Site geographic and environmental data and functions.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec00
// ----------------------------------------------------------------------------
//	History:
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Extracted from the rest of Century.
//	Jul02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added copy constructor.
// ----------------------------------------------------------------------------
//	Copyright 2000 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

class TSiteEnvironment
{
  public:
	//--- functions
	TSiteEnvironment ()
	  {
	    Initialize();
	  }
	virtual ~TSiteEnvironment ()
	  {
	  }
	TSiteEnvironment (TSiteEnvironment const & object)  // copy constructor
	  {
	    Copy (object);
	  }

	//---- operator overloads

	//---- functions
	void SetLatLong (		// Save the latitude/longitude
	  float const useLatitude,	//   latitude
	  float const useLongitude);	//   longitude
	float GetLatitude () const	// Get the site latitude
	  { return latitude; }
	float GetLongitude () const	// Get the site longitude
	  { return longitude; }
	float GetDayLength (		// Get length of daylight in hours
	  short const month);		//   month of year (range: 1-12)
	bool IsDayIncreasing () const	// True if daylength is increasing
	  { return dayIncreasing; }
	void Clear ()			// Clear data members.
	  {
	    Initialize();
	  }

  protected:
	//--- data
	float latitude;			// site latitude
	float longitude;		// site longitude
	float dayHours;			// length of daylight in hours
	bool dayIncreasing;		// true if daylength is increasing

	//--- functions
	float CalcDayLength (		// Calc the number of hours in the day
	  short const month);		// month of year (range: 1-12)

  private:
	//--- data

	//--- functions
	void Initialize ()
	  {
	  	latitude = longitude = dayHours = 0.0f;
	  	dayIncreasing = false;
	  }
	void Copy (TSiteEnvironment const & object)	// Copy to this
	  {
	    if ( &object )
	    {
	    	latitude = object.latitude;
	    	longitude = object.longitude;
	    	dayHours = object.dayHours;
	    	dayIncreasing = object.dayIncreasing;
	    }
	  }
};


#endif // INC_TSiteEnv_h
