#ifndef INC_TCenturyConfigBase_h
#define INC_TCenturyConfigBase_h
// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  TCenturyConfigBase.h
//	Class:	  TCenturyConfigBase
//
//	Description:
//	Base class for initializing a configuration for the Century models.
//
//	Responsibilities:
//	* Know data common to all specific configuration set classes.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@attbi.com, May03
//	History:
//	Feb04	Tom Hilinski
//	* Added member fixFile to hold the path/name of the fix.100 file,
//	  and Get... function to retrieve it..
//	Feb05	Tom Hilinski
//	* Added error message with handlers.
//	Mar05	Tom Hilinski
//	* Changed auto_ptr's to shared ptrs.
//	* "Get" functions now return shared ptrs rather than raw ptrs.
//	* Moved error flags and associated functions into here from children.
//	* Moved "use" mgmt into here from children.
//	Aug05	Tom Hilinski
//	* Replaced function args accepting char* by std::string &
//	* param path includes a list of paths to be used by class TEventDBList.
//	* Moved BuildOutputFileName from children to here.
//	* Added more typedefs to shared ptrs.
//	* Moved "UseSite" to here from children.
//	* Removed template parameter TPaths. CenturyPaths is now used directly.
// ----------------------------------------------------------------------------
//	Notes:
//	* This class is not finished! Lots of common functions in
//	classes TCentConfig and TDailyCenturyConfig need to be moved here.
// ----------------------------------------------------------------------------

#include "TCentException.h"
#include "TManagement.h"
#include "TEventDBList.h"
#include "CenturyPaths.h"
#include "TCentOFBase.h"
#include "TAsynchCom.h"
#include "TSharedPtr.h"

template
<
	class TSite,			// type of TSiteParametersBase
	class TSiteInfo			// type of SiteParametersInfo
>
class TCenturyConfigBase
{
  public:
	//---- types
	typedef TSharedPtr<CenturyPaths>		TPathsPtr;
	typedef TSharedPtr<TSite>			TSitePtr;
	typedef TSharedPtr<TManagementScheme>		TMgmtPtr;
	typedef TSharedPtr<TEventDBList>		TDBListPtr;
	typedef TSharedPtr<TOutputBase>			TOutputPtr;
	typedef TSharedPtr<TAsynchCommunication>	TAsynchComPtr;
	typedef TEventDBList::TStringArray		TStringArray;

	//---- constructors and destructor
  protected:
	TCenturyConfigBase (
	  std::string const & useCentHomePath,		// home or "exe" path
	  std::string const & useWorkPath,	 	// path to work files
	  std::string const & useParamPath,		// path to parameters
	  TStringArray const & useParamPathList,	// parameter file search
	  std::string const & useTemplatePath,		// path to templates
	  std::string const & useTextDataPath,		// path to text data
	  std::string const & useSubdirectory,		// subdirectory name
	  std::string const & useFixFile,		// path/name to fix.100
	  std::string const & useUserName,		// user name
	  bool const useDoOutput)			// false if no output
	  : modified (false),
	    paramPathList (useParamPathList),
	    fixFile (useFixFile),
	    userName (useUserName),
	    doOutput (useDoOutput)
	  {
	    ClearErrors ();
	    InitializeDefaultPaths (
	    	useCentHomePath,
		useWorkPath, useParamPath,
		useTemplatePath, useTextDataPath, useSubdirectory );
	  }
	TCenturyConfigBase (
	  TCenturyConfigBase const & object)
	  {
	    Copy (object);
	  }

  public:
	virtual ~TCenturyConfigBase ()
	  {
	  }
	virtual TCenturyConfigBase * const Clone () const = 0;	// Clone this

	//---- operator overloads
	TCenturyConfigBase& operator= (
	  TCenturyConfigBase const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	Clear ();
		Copy (object);
	    }
	    return *this;
	  }
	bool operator== (
	  TCenturyConfigBase const & object) const;
	bool operator!= (
	  TCenturyConfigBase const & object) const
	  {
	    return !(*this == object);
	  }

	//---- functions
	TCentException::TCEIndex UseSite (		// Use site
	  std::string const & newSiteFile);		//   in this file
	TCentException::TCEIndex UseSite (		// Use site
	  TSitePtr newSiteFile);			//   this site
	TCentException::TCEIndex UseManagement (	// Use management
	  std::string const & newMgmtFile);		//   in this file
	TCentException::TCEIndex UseManagement (	// Use management
	  TMgmtPtr newMgmt);				//   this management

	bool VerifySite ();
	bool VerifyManagement ();
	void FindAndThrowError ();		// If error, throw exception

	void Clear ();					// "Clear" data members
	void ClearErrors ()				// Reset error flags
	  {
	    pathsError = siteError =
		spiError = mgmtError =
		dbListError = outputError =
		    TCentException::CE_NOERR;
	    warningMsg.clear ();
	    errorMsg.clear ();
	  }

	//---- functions: Queries
	static
	  char const * const GetDefaultSiteName ()	// default site name
	  { return defaultSiteName; }
	static
	  char const * const GetDefaultManagementName () // default mgmt name
	  { return defaultMgmtName; }
	static
	  char const * const GetDefaultOutputName ()	// default output name
	  { return defaultOutputName; }
	static
	  char const * const DefaultUserName ()		// default user name
	  { return defaultUserName; }
	TPathsPtr GetPaths () const			// paths
	  { return paths; }
	TSitePtr GetSite () const			// site
	  { return site; }
	// The following should be const * const, but then
	// have to mod how VerifyManagement() is given a mgmt object,
	// since it can correct mgmt errors.
	// (Tom H., Feb04)
	TMgmtPtr GetManagement () const			// managment
	  { return mgmt; }
	TDBListPtr GetParametersDBList () const		// param db's
	  { return dbList; }
	// The output object is not const, since it's data
	// (the output generated by the model) changes.
	TOutputPtr GetOutput () const			// output
	  { return output; }
	std::string const & GetFixFile () const		// fix.100 file name
	  { return fixFile; }
	std::string const & GetUserName () const	// user name
	  { return userName; }
	TAsynchComPtr GetAsynchCommunication () const	// async. com.
	  { return asynchCom; }
	bool & ProduceOutput ()				// true if output files
	  { return doOutput; }
	bool ProduceOutput () const			// true if output files
	  { return doOutput; }
	bool HavePaths () const				// True if have paths
	  { return (paths.get() ?
	  	!paths->IsEmpty() : false); }
	bool HaveSite () const				// True if have site
	  { return (site.get() ?
	  	!site->IsEmpty() : false); }
	bool HaveManagement () const			// True if have mgmt
	  { return (mgmt.get() ?
	  	!mgmt->IsEmpty() : false); }
	bool HaveParametersDBList () const		// True if have params
	  { return (dbList.get() ?
	  	!dbList->IsEmpty() : false); }
	bool HaveOutput () const			// True if have output
	  { return (output.get() ?
	  	!output->IsEmpty() : false); }
	bool HaveUserName () const			// True if have name
	  { return !userName.empty(); }
	bool HaveAsynchCommunication () const		// True if asynch. com.
	  { return (asynchCom.get() ?
	  	asynchCom->IsInitialilzed() : false); }
	bool IsInitialized () const			// True if all is ready
	  {
	    return HavePaths() &&
	    	HaveSite() &&
	    	HaveManagement() &&
		HaveParametersDBList() &&
		HaveOutput();
	  }
	bool IsEmpty () const				// True if no data
	  {
	    return false;	// to do: IsEmpty
	  }
	bool IsModified () const			// True if modified
	  { return modified; }
	bool HaveWarningMsg () const
	  { return !warningMsg.empty(); }
	bool HaveErrorMsg () const
	  { return !errorMsg.empty(); }
	std::string const & GetWarningMsg () const
	  { return warningMsg; }
	std::string const & GetErrorMsg () const
	  { return errorMsg; }

	//---- functions: Error flags
	bool HaveError () const			// True if no error flags set
	  {
	    TCentException::TCEIndex const
		noError = TCentException::CE_NOERR;
	    return pathsError != noError &&
		siteError != noError &&
		spiError != noError &&
		mgmtError != noError &&
		dbListError != noError &&
		outputError != noError;
	  }
	TCentException::TCEIndex GetPathsError () const	// paths error
	  { return pathsError; }
	TCentException::TCEIndex GetSiteError () const	// site error
	  { return siteError; }
	TCentException::TCEIndex GetSPIError () const	// site par info error
	  { return spiError; }
	TCentException::TCEIndex GetMgmtError () const	// mgmt error
	  { return mgmtError; }
	TCentException::TCEIndex
			GetEventDbListError () const	// event dbList error
	  { return dbListError; }
	TCentException::TCEIndex
			GetOutputError () const		// output error
	  { return outputError; }

  protected:
	//---- constants
	static char const * const defaultSiteName;	// default site name
	static char const * const defaultMgmtName;	// default mgmt name
	static char const * const defaultOutputName;	// default output name
	static char const * const defaultUserName;	// default user name

	//---- data: config info
	TPathsPtr paths;			// paths to sys dirs
	TSitePtr site; 				// site parameters
	TMgmtPtr mgmt;				// site management
	TDBListPtr dbList;			// parameter databases
	TOutputPtr output;			// model output sink
	TAsynchComPtr asynchCom;		// asynch communications
	std::string fixFile;			// fix.100 file
	std::string userName;			// user name
	bool doOutput;				// false if no output
	TStringArray paramPathList;		// parameter file search

	//---- data: other than config info
	bool modified;				// true if data changed

	//---- data: Error conditions
	std::string warningMsg;			// warning messages
	std::string errorMsg;			// error messages
	TCentException::TCEIndex pathsError;	// paths error state
	TCentException::TCEIndex siteError;	// site error state
	TCentException::TCEIndex spiError;	// site param info error state
	TCentException::TCEIndex mgmtError;	// mgmt error state
	TCentException::TCEIndex dbListError;	// event dbList error state
	TCentException::TCEIndex outputError;	// output error state

	//---- functions
	void InitializeDefaultPaths (	       	// Initialize paths
	  std::string const & useCentHomePath,		// home or "exe" path
	  std::string const & useWorkPath,	 	// path to work files
	  std::string const & useParamPath,		// path to parameters
	  std::string const & useTemplatePath,		// path to templates
	  std::string const & useTextDataPath,		// path to text data
	  std::string const & useSubdirectory);		// subdirectory name
	void FindFix100File (
	  std::string & fileName,
	  std::string const & outputPath,
	  CenturyPaths const & paths);
	void InitializeParamDBList ();		// Use the param. DB
	std::string BuildOutputFileName (	// Build output name
	  std::string const & fileName);	//   starting name

  private:
	//---- constants

	//---- data

	//---- functions
	void Copy (
	  TCenturyConfigBase const & object);	// Copy to this
};

// ----------------------------------------------------------------------------
//	Specializations
// ----------------------------------------------------------------------------

#if defined ( MONTHLY_CENTURY ) || defined ( ALL_CENTURY )

#include "TMCSiteParameters.h"
#include "TMCSiteParamInfo.h"
template class TCenturyConfigBase<TMCSiteParameters, TMCSiteParamInfo>;

// ----------------------------------------------------------------------------
#elif defined ( DAILY_CENTURY ) || defined ( ALL_CENTURY )

#include "TDCSiteParameters.h"
#include "TDCSiteParamInfo.h"
template class TCenturyConfigBase<TDCSiteParameters, TDCSiteParamInfo>;

// ----------------------------------------------------------------------------
#else
#error No TCenturyBase template specialization macro is defined!
#endif
// ----------------------------------------------------------------------------

#endif // INC_TCenturyConfigBase_h
