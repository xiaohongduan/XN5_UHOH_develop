// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  biomass.cpp
//	Class:	  TDayCent
//	Function: GetBiomass
//
//	Description:
//      Compute the amounts of above ground biomass (live, standing dead,
//      litter, and total biomass) that exists (grams/biomass/m^2)
// ----------------------------------------------------------------------------
//	History:
//      Jan02  Melannie Hartman, melannie@nrel.colostate.edu
//      * Pulled this code from InitDailyCycle
//	Jul02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Now uses variables in TDailyBiomass.
// ----------------------------------------------------------------------------

#include "TDayCent.h"

void TDayCent::GetBiomass()
{
    if ( sysType.IsForest() )
    {
	dailyBiomass.agLiveBiomass = forestC.rleavc * 2.5f;
	// Second mod to remove effect of woodc -rm 1/91
	dailyBiomass.surfaceLitterBiomass =
		(soilC.strucc[SRFC] + soilC.metabc[SRFC]) * 2.0f;
	dailyBiomass.standDeadBiomass = 0.0f;
    }
    else if ( sysType.IsSavanna() )
    {
	dailyBiomass.agLiveBiomass = (forestC.rleavc + cropC.aglivc) * 2.5f;
	dailyBiomass.surfaceLitterBiomass =
		(soilC.strucc[SRFC] + soilC.metabc[SRFC]) * 2.0f;
	dailyBiomass.standDeadBiomass = cropC.stdedc * 2.5f;
    }
    else // system = crop/grass
    {
	dailyBiomass.agLiveBiomass = cropC.aglivc * 2.5f;
	dailyBiomass.surfaceLitterBiomass =
		(soilC.strucc[SRFC] + soilC.metabc[SRFC]) * 2.5f;
	dailyBiomass.standDeadBiomass = cropC.stdedc * 2.5f;
    }

 
	dailyBiomass.biomass = std::min ( 		// total aboveground biomass
    	( dailyBiomass.agLiveBiomass + dailyBiomass.standDeadBiomass +
    		fixed.elitst * dailyBiomass.surfaceLitterBiomass ),
    	fixed.pmxbio );
}

//--- end of file ---
 
