
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include "netcdf.h"
#include "wrtcdf.h"

int
write_nupt(float nupt[][12])
{
        int status;
        float *p = (float *) nupt;

	/* Write output to NetCDF file */
	status = nc_put_vara_float(nupt_ncid, agcnup_id, start, count, p);
	status = nc_put_vara_float(nupt_ncid, bgcnup_id, start, count, p + 12);
	status = nc_put_vara_float(nupt_ncid, rlvnup_id, start, count, p + 24);
	status = nc_put_vara_float(nupt_ncid, frtnup_id, start, count, p + 36);
	status = nc_put_vara_float(nupt_ncid, fbrnup_id, start, count, p + 48);
	status = nc_put_vara_float(nupt_ncid, rlwnup_id, start, count, p + 60);
	status = nc_put_vara_float(nupt_ncid, crtnup_id, start, count, p + 72);

	/* Reset memory for variable nupt */
	 memset(p, '\0', (sizeof(float) * 7 * 12));

	return 0;
}
