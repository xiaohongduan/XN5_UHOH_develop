#ifndef INC_TUserPreferencesDlg_h
#define INC_TUserPreferencesDlg_h
// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TUserPreferencesDlg.h
//	Class:	  TUserPreferencesDlg
//
//	Description:
//	Dialog box for specifying application preferences.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Jan98
//	History:
// ----------------------------------------------------------------------------

#include "externals.h"
#include "TModalDlg.h"

//	Command objects values

#ifdef _TPrefDlg_ClassDefined_

enum {
	Enum_TPrefDlg_Start = 12000,	// first item!
					// application info:
	D_AppSiteLibPath,		// r/o text: site libs path
	D_AppMgmtLibPath,		// r/o text: mgmt. libs path
	D_AppBlkLibPath,		// r/o text: block libs path
	D_AppParamLibPath,		// r/o text: parameter files path
					// user info:
	D_Modified,			// color text: displayed if modified
	D_UserName,			// edit: user's name
	D_SiteLibPath,			// edit: user's site library path
	D_SiteLibPathBrowse,		// button: browse for site libs.
	D_MgmtLibPath,			// edit: user's block library path
	D_MgmtLibPathBrowse,		// button: browse for block libs.
	//D_BlkLibPath,			// edit: user's block library path
	//D_BlkLibPathBrowse,		// button: browse for block libs.
	D_ProjectPaths,			// list: project paths
	D_ProjectPathAdd,		// button: add project path
	D_ProjectPathDel,		// button: delete the highlighted path
	D_ProjectPathUse,		// button: select active project path
	D_ProjectPathCur,		// label: current project path
					// initialization file:
	D_OpenIniFile,			// button: open a .ini file
	D_SaveIniFile,			// button: save to a .ini file

	Enum_TPrefDlg_End		// last item!
};

#endif	// _TPrefDlg_ClassDefined_

//	-----------------------------------------------------------------------
//	TUserPreferencesDlg
//	Class for <describe class here>.
class TUserPreferencesDlg : public TModalDlg
{
  public:
	//--- constructors and destructor
	TUserPreferencesDlg (
		vApp* const parentApp, 		// pointer to application
		TUserPref & currentPref);	// current preferences
	TUserPreferencesDlg (
		vBaseWindow * const parentWin,  // pointer to parent window
		TUserPref & currentPref);	// current preferences
	~TUserPreferencesDlg ();

	//--- functions overridden
	void DialogDisplayed ();
	void DialogCommand (ItemVal id, ItemVal val, CmdType type);

	//--- functions

  private:
	//--- data
	static CommandObject cmdList[];		// dialog elements
	char **projPathList;			// list of project paths
	short idxProjPathList;			// index to cmdList for list
	TUserPref& origPref;			// original user preferences
	TUserPref dispPref;			// displayed user preferences

	//--- functions
	void ConstructMe ();			// common to constructors
	void Initialize ();			// initialize members
	void LoadDlg ();			// load data into dialog
	void GetDlg ();				// get data from dialog
	// event handlers
	void Evt_SiteLibPathBrowse ();		// browse for site lib path
	void Evt_MgmtLibPathBrowse ();		// browse for mgmt. lib path
	void Evt_ProjectPathAdd ();		// button: add project path
	void Evt_ProjectPathDel ();		// button: delete project path
	void Evt_ProjectPathUse ();		// button: select project path
	void Evt_OpenIniFile ();		// button: open a .ini file
	void Evt_SaveIniFile ();		// button: save to a .ini file
	// utility functions
	void ClearDlg ();			// clears user's info in dialog
	void ClearDlgProjPathList ();		// clear the project path list
	void DeleteProjPaths ();		// deletes memory for list
	void BuildProjPathList ();		// build the project path list
	void CheckButtons ();			// (de)activate buttons
	bool BrowseIniFile (TEH::TFileName& iniFile, bool save);
	bool CanAddPath (TEH::TFileName& path);	// true if can add path
	void ShowHideModified ();
	bool IsUserTextChanged ();		// true if text input changed
};

#endif // INC_TUserPreferencesDlg_h
