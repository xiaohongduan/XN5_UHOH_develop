// ----------------------------------------------------------------------------
//	Copyright (c) 2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  allocleaf1st.cpp
//	Class:	  TDayCent
//	Function: AllocateLeavesFirst
//
//	Description:
//
//      Allocate carbon first for leaves (LEAF), then for fine roots (FROOT),
//      then for woody components of trees (FBRCH, LWOOD, and CROOT).
// ----------------------------------------------------------------------------
//      Author: Melannie Hartman, melannie@nrel.colostate.edu 07June2001
//	History:
// ----------------------------------------------------------------------------
//	Notes:
//      * Assuming enum { LEAF, FROOT, FBRCH, LWOOD, CROOT, FPARTS };
// ----------------------------------------------------------------------------

#include "TDayCent.h"
#include <sstream>

void TDayCent::AllocateLeavesFirst(
    int const indexFCAF,	// index to forest C allocation fractions
				//   (0=new, 1=mature)
    float const cprodf,		// total potential forest production (gC/m^2)
    float treeCfrac[FPARTS])	// frac of carbon allocated to each tree part
				//   (0-1)
{
    float cprodfLeftToAllocate = cprodf;
    treeCfrac[LEAF] = FractionLeafAllocation(forestC.rleavc,
	    forestC.rlwodc, cprodfLeftToAllocate, cprodf);
    float remCfrac = 1.0f - treeCfrac[LEAF];

    if ( !AmountIsSignificant(remCfrac) )
    {
	for ( short ipart = 0; ipart < FPARTS; ++ipart)
	{
	    if (ipart != LEAF)
		treeCfrac[ipart] = 0.0f;
	}
    }
    else
    {
	treeCfrac[FROOT] = std::min( remCfrac,
		FractionRootAllocation (SysType_Forest,
					parfs.a2drat, parfs.pptprd));
	remCfrac = 1.0f - treeCfrac[LEAF] - treeCfrac[FROOT];
	//if (remCfrac < 0.0)
	//{
	//    cout << "treeCfrac[FROOT] = " << treeCfrac[FROOT] << endl;
	//    cout << "treeCfrac[LEAF] = " << treeCfrac[LEAF] << endl;
	//}
	if ( !AmountIsSignificant( std::fabs(remCfrac) ) )
		remCfrac = 0.0f;
	Assert (remCfrac >= 0.0f);
	float totCup = 0.0f;

	for ( short ipart = FBRCH; ipart < FPARTS; ++ipart)
	{
	    // use tree.100 parameters for woody components
	    treeCfrac[ipart] = fcfrac_ref (ipart, indexFCAF);
	    totCup += treeCfrac[ipart];
	}
	if (totCup > 0.0f)
	{
	    for ( short ipart = FBRCH; ipart < FPARTS; ++ipart)
	    {
		//treeCfrac[ipart] = remCfrac * treeCfrac[ipart]/totCup;
		treeCfrac[ipart] *= remCfrac / totCup;
	    }
	}
	else
	{
	    std::ostringstream os;
	    os << "Error in TreeDynamCarbonAlloc: "
	       << std::endl;
	    os << "FCFRAC(FBRCH) + FCFRAC(LWOOD) + FCFRAC(CROOT) = "
	       << totCup << ", and should be > 0.0 for deciduous tree."
	       << std::endl;
	    ThrowDayCentException ( TDayCentException::DCE_VORTRE,
					os.str().c_str() );
	}
    }
}
