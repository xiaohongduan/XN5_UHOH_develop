#ifndef INC_nrel_dcirc_TDayCentSimController_h
#define INC_nrel_dcirc_TDayCentSimController_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TDayCentSimController.h
//	Class:	  TDayCentSimController
//
//	Description:
//	DayCent simulation controller class.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, tom.hilinski@colostate.edu, June 2002
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TGriddedSimulationBase.h"	// Simulation controller base
#include "TCenturySimOutputMgr.h"	// simulation output manager
#include "DayCentIRCTypes.h"

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class TDayCentIRCConfig;

class TDayCentSimController
	: public ::nrel::gcf::TGriddedSimulationBase
{
  public:
	//---- types

	//---- constructors and destructor
	TDayCentSimController (
	  TDayCentIRCConfig const & useConfig,		// configuration
	  ::nrel::gcf::TClimateBase * const useClimate,	// climate source
	  TDecisionPtr useDecision,	   		// decision modules
	  TFactoriesPtr useFactories);			// factory modules
	~TDayCentSimController ()
	  {
	    WriteTerminationInfo ();
	  }

	//---- functions
	void Write (std::string const & msg)
	  { myOutputMgr->Write (msg); }
	void Write (char const * const msg)
	  { myOutputMgr->Write (msg); }
	virtual TDayCentSimController * const Clone () const
	  { return 0; /* not implemented */ }

  private:
	//---- data
	TCenturySimOutputMgr * myOutputMgr;	// Don't delete this! base owns!

	//---- functions
	void WriteStartupInfo ()
	  {
		Assert (myOutputMgr != 0);
		std::string msg = "Simulation started at ";
		msg += ::DateTimeStr().c_str();
		myOutputMgr->Write (msg);
	  }
	void WriteTerminationInfo ()
	  {
		Assert (myOutputMgr != 0);
		std::string msg = "Simulation stopped at ";
		msg += ::DateTimeStr().c_str();
		myOutputMgr->Write (msg);
	  }

	//---- Functions: should not be called!
	virtual TDayCentSimController * const Clone (	// Clone this instance
	  ::nrel::gcf::TEvent const * const data	//   event triggering it
	  ) const
	  { return 0; }
};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_TDayCentSimController_h
