// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  grem_dc.cpp
//	Class:	  TDayCent
//	Function: RemoveCropGrass
//
//	Description:
//	Simulate removal of crop/grass by fire or grazing for the month.
// ----------------------------------------------------------------------------
//	History:
//      See Century/grem.cpp
//      May01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Added IsTimeForGrazing() function call
//      * Added function arguments day, curYear
//      19June01 Melannie Hartman, melannie@nrel.colostate.edu
//      * Changed this function from a TCentury member to a TDayCent member.
//      * Replaced some flows->Schedule() calls that flow minerl_ref(SRFC, E)
//        with calls to FlowNPSfromMineralSoil() and/or FlowNPSintoMineralSoil
// ----------------------------------------------------------------------------
//	NOTES:
//	Initialize fractionAGLiveCRemoved, fdrem, and
//	fractionCExcreted based on fire or grazing.
//	Mod.0fire routines, created litburn() subroutine  -mse 4-94.
//	If dofire(cursys)=1 -> CRPSYS burns standing dead and litter.
//
//      * Don't need IsTimeFor_____() functions within this function
//        because they are part of the condition used to determine
//        if this function is called.  -mdh 5/01/01
//
//      * Check with Bill about flow from maintenance resp C storage pool
//        after live shoot harvest. -mdh 7/9/01. Followup: Bill says
//        maintenance respiration storage occurs in the roots, and should
//        be removed in proportion to cropC.bglivc. -mdh 9/5/01.
// ----------------------------------------------------------------------------

#include "TDayCent.h"

void TDayCent::RemoveCropGrass ()
{
    // Fractions of pools removed
    float
	fractionAGLiveCRemoved,		// fraction of abovegound live plant
	fractionStandingDeadCRemoved,	// fraction of standing dead plant
	// fractionLitterCRemoved,	// fraction of surface litter
	fractionCExcreted;		// fraction of carbon excreted
    if ( sched->DoingCropGrassFire() || sched->DoingSavannaFire() )
    {
	fractionAGLiveCRemoved = parcp.flfrem;
	fractionStandingDeadCRemoved = parcp.fdfrem[0];
	// fractionLitterCRemoved = parcp.fdfrem[1];
	fractionCExcreted = 0.0f;
    }
    else if ( sched->DoingGrazing() )
    {
	fractionAGLiveCRemoved = parcp.flgrem;
	fractionStandingDeadCRemoved = parcp.fdgrem;
	// fractionLitterCRemoved = 0.0f;
	fractionCExcreted = parcp.gfcret;
    }
    else					// nothing to do!
    {
    	Assert (false);
    	return;					// Should never get here
    }

    // Added for local initialization of variables which may not
    // get initialized during a run. 8-31-90 -rm
    float labeledC = 0.0f; 		// fraction of labeled C returned
    float cRemovedShoots = 0.0f;	// C removed from shoots
    float cRemovedStandingDead = 0.0f;	// C removed from standing dead
    float
	sdreme[NUMELEM],	// E removed from standing dead
	recres[NUMELEM],	// ratio E:C
	eret[NUMELEM],		// total E removed from aboveground
	shreme[NUMELEM],	// E removed from shoots
	litrme[NUMELEM];	// E removed from structural component of litter
    for (short element = 0; element < site.nelem; ++element)
	sdreme[element] =  shreme[element] =  litrme[element] = 0.0f;

    // Shoots removed
    if (cropC.aglivc > 0.0f)
    {
	register float const recip = 1.0f / cropC.aglivc;	// optimize
	// carbon
	cRemovedShoots = fractionAGLiveCRemoved * cropC.aglivc;
	cropC.shrema += cRemovedShoots;
	ScheduleCFlow ( st->time, cRemovedShoots,
			cropC.aglcis[LABELD] / cropC.aglivc, 1.0f,
			&cropC.aglcis[UNLABL], &soilC.csrsnk[UNLABL],
			&cropC.aglcis[LABELD], &soilC.csrsnk[LABELD],
		 	cropC.shrmai );
	labeledC += cRemovedShoots * cropC.aglcis[LABELD] * recip;
	// elements
	for (short element = 0; element < site.nelem; ++element)
	{
	    shreme[element] = cRemovedShoots * nps.aglive[element] * recip;
	    nps.shrmae[element] += shreme[element];
	    flows->Schedule (&nps.aglive[element], &nps.esrsnk[element],
	    		    st->time, shreme[element]);
	}
    }

    // Standing dead removed
    if (cropC.stdedc > 0.0f)
    {
	register float const recip = 1.0f / cropC.stdedc;	// optimize
	// carbon
	cRemovedStandingDead = fractionStandingDeadCRemoved * cropC.stdedc;
	cropC.sdrema += cRemovedStandingDead;
	ScheduleCFlow ( st->time, cRemovedStandingDead,
			cropC.stdcis[LABELD] / cropC.stdedc, 1.0f,
			&cropC.stdcis[UNLABL], &soilC.csrsnk[UNLABL],
			&cropC.stdcis[LABELD], &soilC.csrsnk[LABELD],
			cropC.sdrmai );
	labeledC += cRemovedStandingDead * cropC.stdcis[LABELD] * recip;
	// elements
	for (short element = 0; element < site.nelem; ++element)
	{
	    sdreme[element] =
	    	cRemovedStandingDead * nps.stdede[element] * recip;
	    nps.sdrmae[element] += sdreme[element];
	    flows->Schedule (&nps.stdede[element], &nps.esrsnk[element],
	    		    st->time, sdreme[element]);
	}
    }

    // FIRE
    if ( sched->DoingCropGrassFire() || sched->DoingSavannaFire() )
    {
	// Residue (surface litter) removed by fire       vek 5/26/90
	BurnLitter (litrme);

	// Note: the following is never used in this "if" block:
	// labeledC += fractionLitterCRemoved *
	//	strcis_ref (SRFC, LABELD);
	// labeledC += fractionLitterCRemoved *
	//	metcis_ref (SRFC, LABELD);

	// Assume no Carbon return from fire.  If the next 2 statements are
	// reactivated, it will be necessary to partition the flow into
	// strcis(1) and strcis(2) instead of strucc(1):
	//     cReturned = fractionCExcreted *
	//		(cRemovedShoots + cRemovedStandingDead)
	//     call flow(csrsnk(1),strucc(1),time,cReturned)

	// E return from fire
	for (short element = 0; element < site.nelem; ++element)
	{
	    // sheret - elemental return for shoots
	    float sheret = parcp.fret[element] * shreme[element];
	    sdreme[element] += litrme[element];
	    // sderet - elemental return for standing dead and litter
	    float sderet = parcp.fret[element] * sdreme[element];
	    eret[element] = sheret + sderet;
            float const fracToNitrate = 0.0;   // All N to ammonium -mdh 9/5/01
	    soilFlows->FlowNPSintoMineralSoil ( 
	    		(TMineralElements)element,
			&nps.esrsnk[element], eret[element], wt.simDepth,
			fracToNitrate);
	}
    }
    // END FIRE

    // GRAZE
    else
    {
	// NOTES:
	// Grazing return with feces and urine explicitly separated.
	// All carbon returned by grazing is in the form of feces.
	// To adjust for the changing lignin content of added material
	// strucc(1) and strlig are recomputed.
	float const abovegroundCRemoved = cRemovedShoots + cRemovedStandingDead;
	float cExcreted = fractionCExcreted * abovegroundCRemoved;
	if (cExcreted <= 0.0f)
	{
	    cExcreted = 0.0f;
	    for (short element = 0; element < site.nelem; ++element)
		eret[element] = 0.0f;
	}
	else
	{
	    for (short element = 0; element < site.nelem; ++element)
	    {
		// sheret - elemental return for shoots
		float sheret = parcp.gret[element] * shreme[element];
		// sderet - elemental return for standing dead and litter
		float sderet = parcp.gret[element] * sdreme[element];
		eret[element] = sheret + sderet;
		// urine - amount of urine returned
		float const urine =
			(1.0f - parcp.fecf[element]) * eret[element];
		// feces- amount of fecal material returned (N, P, S)
		float const feces = parcp.fecf[element] * eret[element];
		recres[element] = feces / cExcreted;
                float const fracToNitrate = 0.0; // All N from urine is ammonium
		soilFlows->FlowNPSintoMineralSoil ( 
			(TMineralElements)element,
			&nps.esrsnk[element], urine, wt.simDepth,
			fracToNitrate);
	    }

	    // Mod. to add structural & metabolic C into labeled (numerator)
	    // and total (denominator) C removed.  (vek  05/26/90)
	    // friso = fraction of the C returned is labeled
	    float const friso = labeledC / abovegroundCRemoved;
	    PartitionResidue (cExcreted, recres, SRFC, soilC.csrsnk, nps.esrsnk,
		     	      parcp.feclig, friso);
    	    cropC.creta += cExcreted;
	}
    }
    // **** END GRAZE

    // **** Accumulate amounts returned
    for (short element = 0; element < site.nelem; ++element)
	nps.ereta[element] += eret[element];
}

//--- end of file ---

