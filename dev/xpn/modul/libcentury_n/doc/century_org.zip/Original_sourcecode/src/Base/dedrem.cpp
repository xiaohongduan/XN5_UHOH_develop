// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  dedrem.cpp
//	Class:	  TCenturyBase
//	Function: RemoveDeadWood
//
//	Description:
//	Removal of dead wood due to cutting or fire in a forest.
// ----------------------------------------------------------------------------
//	History:
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::RemoveDeadWood (
	float *accum)	// array [ISOS]; cumulative C; unlabeled, labeled
{
    float const minimumPoolAmount = 0.001f;

    // Remove dead FINE BRANCHES
    if ( forestC.wood1c > minimumPoolAmount )
    {
	float const closs = forrem.remf[3] * forestC.wood1c;
	forestC.tcrem += closs;
	ScheduleCFlow ( st->time, closs,
		forestC.wd1cis[LABELD]  / forestC.wood1c, 1.0f,
    		&forestC.wd1cis[UNLABL], &soilC.csrsnk[UNLABL],
	     	&forestC.wd1cis[LABELD], &soilC.csrsnk[LABELD],
	      	accum);
	for (short element = 0; element < site.nelem; ++element)
	{
		float const eloss =
			closs * nps.wood1e[element] / forestC.wood1c;
		nps.terem[element] += eloss;
		flows->Schedule (&nps.wood1e[element], &nps.esrsnk[element],
				st->time, eloss);
	}
    }

    // Remove dead LARGE WOOD
    if ( forestC.wood2c > minimumPoolAmount )
    {
	float const closs = forrem.remf[4] * forestC.wood2c;
	forestC.tcrem += closs;
    	ScheduleCFlow ( st->time, closs,
    		forestC.wd2cis[LABELD] / forestC.wood2c, 1.0f,
    		&forestC.wd2cis[UNLABL], &soilC.csrsnk[UNLABL],
	     	&forestC.wd2cis[LABELD], &soilC.csrsnk[LABELD],
	     	accum);
	for (short element = 0; element < site.nelem; ++element)
	{
		float const eloss =
			closs * nps.wood2e[element] / forestC.wood2c;
		nps.terem[element] += eloss;
		flows->Schedule (&nps.wood2e[element], &nps.esrsnk[element],
				st->time, eloss);
	}
    }
}

//--- end of file dedrem.cpp ---
