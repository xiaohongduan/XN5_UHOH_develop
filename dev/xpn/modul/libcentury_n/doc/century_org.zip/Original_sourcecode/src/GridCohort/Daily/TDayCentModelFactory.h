#ifndef INC_nrel_dcirc_TDayCentModelFactory_h
#define INC_nrel_dcirc_TDayCentModelFactory_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TDayCentModelFactory.h
//	Class:	  TDayCentModelFactory
//
//	Description:
//	Factory class for the DayCent model.
//	Responsibilities:
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, June 2002
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TModelFactoryBase.h"
#include "TDayCentModel.h"
#include "GCFfwd.h"

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class TDayCentModelFactory
	: public ::nrel::gcf::TModelFactoryBase
{
  public:
	//---- constructors and destructor
	TDayCentModelFactory ()
	  : ::nrel::gcf::TModelFactoryBase ()
	  {
	  }
	virtual ~TDayCentModelFactory ()
	  {
	  }

	//---- functions
	virtual std::auto_ptr< ::nrel::gcf::TModelBase> CreateInstance (
	  ::nrel::gcf::TCohort * const useOwner,	// owner = cohort
	  ::nrel::gcf::TDecision * const useDecision,	// decision object
	  ::nrel::gcf::TFactories * const factories,	// factories modules
	  bool const timeThisRun = false)	// True if timing the model run
	  {
	    std::auto_ptr< ::nrel::gcf::TModelBase> newModel (
		new TDayCentModel (
			useOwner, useDecision, factories, timeThisRun) );
	    return newModel;
	  }

  protected:
	//---- constants

	//---- data

	//---- functions

  private:
	//---- constants

	//---- data

	//---- functions
};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_TDayCentModelFactory_h
