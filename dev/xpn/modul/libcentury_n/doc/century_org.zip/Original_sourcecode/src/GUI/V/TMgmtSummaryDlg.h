#ifndef INC_TMgmtSummaryDlg_h
#define INC_TMgmtSummaryDlg_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	Class:	  TMgmtSummaryDlg
//	File:	  TMgmtSummaryDlg.h
//
//	Description:
//	Class for displaying "Management Summary" modeless dialog.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Jan98, tom.hilinski@colostate.edu
//	History:
//	Oct03	Tom Hilinski
//	* Extensive cleanup.
// ----------------------------------------------------------------------------

#include <v/vdialog.h>
#include <v/vslist.h>

class TCMIApp;
class TManagementScheme;

class TMgmtSummaryDlg
	: public vDialog
{
  public:
	TMgmtSummaryDlg (
	  TCMIApp * const app,
	  TManagementScheme & useMgmt,
	  char const * const title
	  	 = "Summary of Management");
	~TMgmtSummaryDlg();

	//---- functions
	void DialogCommand (ItemVal id, ItemVal val, CmdType type);
	void UpdateList ();

  private:
	//---- constant data
	static CommandObject cmdList[];		// dialog elements
  	static char const * const dummyList[];

	//---- data
	TManagementScheme & mgmt;		// external mgmt object
	vSList list;				// management summary list

	//---- functions
	void BuildList ();
};

#endif 	// INC_TMgmtSummaryDlg_h
