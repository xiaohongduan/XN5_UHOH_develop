#ifndef INC_nrel_util_WriteMonthlyCentWthrFile_h
#define INC_nrel_util_WriteMonthlyCentWthrFile_h

// ----------------------------------------------------------------------------
//	Copyright 2002, 2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  WriteMonthlyCentWthrFile.h
//	Class:	  WriteMonthlyCentWthrFile
//
//	Description:
//	Writes a Century monthly weather file from the data arrays specified.
//---------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May2005 (C++ driver)
//		Cindy Keough, 2002, file read, and statistical functions.
//	History:
//	
//---------------------------------------------------------------------------

#include <string>
#include "arraytypes.h"
#include "TInterval.h"

namespace nrel
{

  namespace util
  {

class WriteMonthlyCentWthrFile
{
  public:
	WriteMonthlyCentWthrFile (
	  std::string const & fileName,		// output file name
	  TInterval<long> const yearRange,	// year range of the data
	  T2DFloatArray const & precip,		// precip mean [year][month]
	  T2DFloatArray const & tempMin,	// temp. minimum [year][month]
	  T2DFloatArray const & tempMax,	// temp. maximum [year][month]
	  std::string const & headerStr)
	  {
	    Initialize ();
	    WriteData ( fileName, yearRange,
	    		precip, tempMin, tempMax, headerStr );
	  }
	~WriteMonthlyCentWthrFile ()
	  {
	  }

	std::string const & GetErrorMsg () const
	  { return errorMsg; }

  private:
	std::string errorMsg;

	void Initialize ()
	  {
	  }
	void WriteData (
	  std::string const & fileName,		// output file name
	  TInterval<long> const yearRange,	// year range of the data
	  T2DFloatArray const & precip,		// precip mean [year][month]
	  T2DFloatArray const & tempMin,	// temp. minimum [year][month]
	  T2DFloatArray const & tempMax,	// temp. maximum [year][month]
	  std::string const & headerStr);

	bool ErrorChecks (
	  std::string const & fileName,		// output file name
	  TInterval<long> const yearRange,	// year range of the data
	  T2DFloatArray const & precip,		// precip mean [year][month]
	  T2DFloatArray const & tempMin,	// temp. minimum [year][month]
	  T2DFloatArray const & tempMax);	// temp. maximum [year][month]

	void WriteHeaders (
	  std::ofstream & fs);

	void WriteRecord (
	  std::ofstream & fs,
	  long const year,
	  T2DFloatArray::const_iterator iPrecip,
	  T2DFloatArray::const_iterator iTempMin,
	  T2DFloatArray::const_iterator iTempMax);

};


  }	// namespace util

}	// namespace nrel

#endif // INC_nrel_util_WriteMonthlyCentWthrFile_h


 