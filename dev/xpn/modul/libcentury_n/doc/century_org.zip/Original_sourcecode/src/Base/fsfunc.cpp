// ----------------------------------------------------------------------------
//	Copyright 1992, 2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  fsfunc.cpp
//	Class:	  TCenturyBase
//	Function: FractionMinPInSolution
//
//	Description:
//	Calculates the fraction of mineral P that is in solution in the
//	specified depth of the soil.
// 	This fraction is a functon of the maximum sorption potential of the
// 	soil and sorption affinity. Both variables are site variables
// 	dependent on the soil mineralogy.
//	Returns the fraction.
// ----------------------------------------------------------------------------
//	Author: Alister Metherell March 23, 1992
//	History:
//	Aug03	Tom Hilinski
//	* Now uses P over rooting depth, to match other algorithms where
//	  this function is used.
//	* Moved into TCenturyBase from TCentury and TDayCent.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include <cmath>
#include <sstream>

MY_TEMPLATE_DECLARATION
float TCENTURYBASE::FractionMinPInSolution (
	  float const soilDepth,	// depth to calc the fraction
	  TSoilPool const & soilP)	// P pool in soil
{
       float const mineralP = 		// Mineral P in specified depth (g/m2)
            soilP.Quantity (
        	0.0f, soilDepth, soil->Depth(), soil->Thickness() );
        	//0.0f, wt.simDepth, soil->Depth(), soil->Thickness() );
	float const c = param.sorpmx * (2.0f - param.pslsrb) * 0.5f;
	float const b = param.sorpmx - mineralP + c;
	float const labile =
		( -b + std::sqrt (b * b + c * 4.0 * mineralP) ) * 0.5f;
	Assert (mineralP != 0.0f);
	float const fractionP = labile / mineralP;
	if (fractionP < 0.0f || fractionP > 1.0f)	// should never happen!
	{
	    std::ostringstream os;
	    os << "Ratio labile:mineral P = " << fractionP;
    	    ThrowCentException (TCentException::CE_PFRAC, os.str().c_str() );
	}
	return fractionP;
}

//--- end of file ---
