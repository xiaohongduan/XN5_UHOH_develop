
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  livnll_ncid;			/* netCDF id */

/* variable ids */
int  aglivnll_id, bglivnll_id, stdednll_id, rleavnll_id, frootnll_id, 
     fbrchnll_id, rlwodnll_id, crootnll_id, wood1nll_id, wood2nll_id, 
     wood3nll_id, crpstgnll_id, forstgnll_id;
int  timell_id, lat_id, lon_id;

/* crpstgn and forstgn added 7/14/00 - mdh */

/* create livn.nc */
int
livndef_ll(int *ntimes, int *nlat, int *nlon, char *history,
           float *opltim, float *qtime) {

   int   status, istart_year, iend_year, ii;
   float fill, fstart_year, fend_year;
   char  timeunits[25], temp[5];

   /* dimension ids */
   int  time_dim = 0;
   int  lat_dim = 0;
   int  lon_dim = 0;

   /* variable shapes */
   int dims[3];

   /* Set fill, start_year, and end_year values */
   fill = NC_FILL_FLOAT;
   fstart_year = *opltim;
   fend_year = *qtime - 1;
   istart_year = fstart_year;
   iend_year = fend_year;

   for (ii = 0; ii < 25; ii++) {
     timeunits[ii] = '\0';
   }
   /* Get the start time for the time definition */
   sprintf(temp, "%d", istart_year); 
   strcat(timeunits, "days since ");
   strcat(timeunits, temp);
   strcat(timeunits, "-01-01");

   /* enter define mode */
   status = nc_create("livnll.nc", NC_CLOBBER, &livnll_ncid );
   if (status != NC_NOERR) handle_error("nc_create(livn.nc)", status);

   /* define dimensions */
   status = nc_def_dim(livnll_ncid, "time", (size_t) *ntimes, &time_dim );
   status = nc_def_dim(livnll_ncid, "lat", (size_t) *nlat, &lat_dim);
   status = nc_def_dim(livnll_ncid, "lon", (size_t) *nlon, &lon_dim);

   /* define variables */

   dims[0] = time_dim;
   status = nc_def_var (livnll_ncid, "time", NC_INT, 1, dims, &timell_id);

   dims[0] = lat_dim;
   status = nc_def_var (livnll_ncid, "lat", NC_FLOAT, 1, dims, &lat_id);

   dims[0] = lon_dim;
   status = nc_def_var (livnll_ncid, "lon", NC_FLOAT, 1, dims, &lon_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livnll_ncid, "aglivn", NC_FLOAT, 3, dims, &aglivnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livnll_ncid, "bglivn", NC_FLOAT, 3, dims, &bglivnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livnll_ncid, "stdedn", NC_FLOAT, 3, dims, &stdednll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livnll_ncid, "rleavn", NC_FLOAT, 3, dims, &rleavnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livnll_ncid, "frootn", NC_FLOAT, 3, dims, &frootnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livnll_ncid, "fbrchn", NC_FLOAT, 3, dims, &fbrchnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livnll_ncid, "rlwodn", NC_FLOAT, 3, dims, &rlwodnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livnll_ncid, "crootn", NC_FLOAT, 3, dims, &crootnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livnll_ncid, "wood1n", NC_FLOAT, 3, dims, &wood1nll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livnll_ncid, "wood2n", NC_FLOAT, 3, dims, &wood2nll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livnll_ncid, "wood3n", NC_FLOAT, 3, dims, &wood3nll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livnll_ncid, "crpstgn", NC_FLOAT, 3, dims, &crpstgnll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (livnll_ncid, "forstgn", NC_FLOAT, 3, dims, &forstgnll_id);

   /* assign attributes */
   status = nc_put_att_text (livnll_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (livnll_ncid, timell_id, "long_name", strlen("Time"), "Time");
   status = nc_put_att_text (livnll_ncid, timell_id, "units", strlen(timeunits), timeunits);
   status = nc_put_att_text (livnll_ncid, timell_id, "time_step", strlen("monthly"), "monthly");
   status = nc_put_att_text (livnll_ncid, timell_id, "calendar", strlen("gregorian"), "gregorian");
   status = nc_put_att_int (livnll_ncid, timell_id, "start_year", NC_INT, 1, &istart_year);
   status = nc_put_att_int (livnll_ncid, timell_id, "end_year", NC_INT, 1, &iend_year);

   status = nc_put_att_text (livnll_ncid, lat_id, "long_name", strlen("Latitude"), "Latitude");
   status = nc_put_att_text (livnll_ncid, lat_id, "units", strlen("degrees_north"), "degrees_north");
   status = nc_put_att_text (livnll_ncid, lat_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (livnll_ncid, lat_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (livnll_ncid, lon_id, "long_name", strlen("Longitude"), "Longitude");
   status = nc_put_att_text (livnll_ncid, lon_id, "units", strlen("degrees_east"), "degrees_east");
   status = nc_put_att_text (livnll_ncid, lon_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (livnll_ncid, lon_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (livnll_ncid, aglivnll_id, "long_name",
	strlen("above_ground_live_nitrogen"), "above_ground_live_nitrogen");
   status = nc_put_att_text (livnll_ncid, aglivnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livnll_ncid, aglivnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livnll_ncid, bglivnll_id, "long_name", 
	strlen("below_ground_live_nitrogen"), "below_ground_live_nitrogen");
   status = nc_put_att_text (livnll_ncid, bglivnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livnll_ncid, bglivnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livnll_ncid, stdednll_id, "long_name", 
	strlen("standing_dead_nitrogen"), "standing_dead_nitrogen");
   status = nc_put_att_text (livnll_ncid, stdednll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livnll_ncid, stdednll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livnll_ncid, rleavnll_id, "long_name", 
	strlen("live_leaf_nitrogen"), "live_leaf_nitrogen");
   status = nc_put_att_text (livnll_ncid, rleavnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livnll_ncid, rleavnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livnll_ncid, frootnll_id, "long_name", 
	strlen("live_fine_root_nitrogen"), "live_fine_root_nitrogen");
   status = nc_put_att_text (livnll_ncid, frootnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livnll_ncid, frootnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livnll_ncid, fbrchnll_id, "long_name", 
	strlen("live_fine_branch_nitrogen"), "live_fine_branch_nitrogen");
   status = nc_put_att_text (livnll_ncid, fbrchnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livnll_ncid, fbrchnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livnll_ncid, rlwodnll_id, "long_name", 
	strlen("live_large_wood_nitrogen"), "live_large_wood_nitrogen");
   status = nc_put_att_text (livnll_ncid, rlwodnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livnll_ncid, rlwodnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livnll_ncid, crootnll_id, "long_name", 
	strlen("live_coarse_root_nitrogen"), "live_coarse_root_nitrogen");
   status = nc_put_att_text (livnll_ncid, crootnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livnll_ncid, crootnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livnll_ncid, wood1nll_id, "long_name", 
	strlen("dead_fine_branch_nitrogen"), "dead_fine_branch_nitrogen");
   status = nc_put_att_text (livnll_ncid, wood1nll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livnll_ncid, wood1nll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livnll_ncid, wood2nll_id, "long_name", 
	strlen("dead_large_wood_nitrogen"), "dead_large_wood_nitrogen");
   status = nc_put_att_text (livnll_ncid, wood2nll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livnll_ncid, wood2nll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livnll_ncid, wood3nll_id, "long_name", 
	strlen("dead_coarse_root_nitrogen"), "dead_coarse_root_nitrogen");
   status = nc_put_att_text (livnll_ncid, wood3nll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livnll_ncid, wood3nll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livnll_ncid, crpstgnll_id, "long_name", 
	strlen("N_in_crop_retranslocation_storage"), "N_in_crop_retranslocation_storage");
   status = nc_put_att_text (livnll_ncid, crpstgnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livnll_ncid, crpstgnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (livnll_ncid, forstgnll_id, "long_name", 
	strlen("N_in_forest_retranslocation_storage"), "N_in_forest_retranslocation_storage");
   status = nc_put_att_text (livnll_ncid, forstgnll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(livnll_ncid, forstgnll_id, "_FillValue", NC_FLOAT, 1, &fill);

   /* leave define mode */
   status = nc_enddef (livnll_ncid);
   return 0;
}
