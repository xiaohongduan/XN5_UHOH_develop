// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  harvin.cpp
//	Class:	  TCentury
//	Function: GetHarvest
//
//	Description:
//	Read the new harvest parameter set.
//	Returns true if successful match in database, else false if not.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
// ----------------------------------------------------------------------------
//	History:
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Parameter set is now read in once only during a simulation,
//	  and stored in a TCentury member variable.
//	Jul01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to use new TEventDBList class.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "TEventDBList.h"
#include "util.h"
#include "constants.h"

MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::GetHarvest (
	const char *harvestToMatch)
{
	// error checks
	if ( !harvestToMatch || !(*harvestToMatch) )	// anything there?
		return false;

	// get the option set
	TEventOptionSet const & optionSet =
		*paramDbList->Get (TEventDBList::DBI_Harv);
	if ( !&optionSet )				// database not there?
		ThrowCentException (TCentException::CE_NSPPDB,
			::eventName[ET_Harvest]);
	if ( !optionSet.GetOptionCount () )		// empty database?
		ThrowCentException (TCentException::CE_EMPPDB,
			::eventName[ET_Harvest]);

	// get the option matching the parameter string
    	TEventOption const * const option =
    		optionSet.GetOption (harvestToMatch);
	if ( !option )					// match found?
		return false;

	// retrieve values from option and save in Century's variables
	short const numParams = 6;			// total for an option
	short count = option->GetParamCount ();
	if ( count != numParams )			// counts match?
		ThrowCentException (TCentException::CE_OPCBAD,
			::eventName[ET_Harvest]);

	register short k = 0;			// index to param values

	parcp.aglrem = option->GetParameter(k++)->GetValue();
	parcp.bglrem = option->GetParameter(k++)->GetValue();
	parcp.flghrv = (int) option->GetParameter(k++)->GetValue();
	parcp.rmvstr = option->GetParameter(k++)->GetValue();
	parcp.remwsd = option->GetParameter(k++)->GetValue();
	parcp.hibg = option->GetParameter(k)->GetValue();

	// save option name in Century class variable
	strcpy (sched->curHarv, harvestToMatch);		// save it

	return true;
}	/* GetHarvest */
