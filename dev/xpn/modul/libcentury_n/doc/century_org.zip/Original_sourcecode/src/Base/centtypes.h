#ifndef INC_centtypes_h
#define INC_centtypes_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  centtypes.h
//	Class:	  TCentury
//
//	Description:
//	Types, structs, and classes for class TCentury and related classes:
//	Tcomput, Tforrem, Tparam, Tparcp, Tparfs, TPotentialProduction,
//	TSite, TWater, TIterationData, TDebugInfo
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
//	History:
//	Dec00	Tom Hilinski
//	* TPlantSystemType: made into a real class and moved into its own
//	  header file.
//	* Removed struct Tmonprd - 1-D vars are local vars only, and the
//	  2-D vars were calc'd but never used or output.
//	Feb01	Tom Hilinski
//	* Added external event flag to TActions.
//	* Added new class "TAsynchFunctions"
//	  to store and manage asynchronous function info.
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added copy constructors and operator= to several classes.
//	Jun-Jul02	Tom Hilinski
//	* Added new struct TIterationData to hold bookkeepting data
//	  to be passed between subsequent iterations.
//	* Added default constructors, virtual destructors, Clear() members.
//	* Replaced memset calls with explicit initialization of variables.
//	* Moved TFixed to TFixed.h/cpp.
//	* Moved TActions, TSchedule to TMgmtSchedule.h
//	Nov04	Tom Hilinski
//	* Moved remwsd from Tparam to Tparcp to be with other crop parameters.
// ----------------------------------------------------------------------------

#include "TFixed.h"
#include "TMgmtConst.h"
#include "TMgmtSchedule.h"
#include "TCenturySoil.h"	// for TWater
#include "PlantBase.h"
#include <string>
#include <cstring>
#include <sstream>

// ----------------------------------------------------------------------------
//	Tcomput
//	Computed global variables
//	History:
//	Apr00	Tom Hilinski
//	* Added evapLoss calc'd in SoilWaterModel (h2olos.cpp)
//	Jun02	Tom Hilinski
//	* Moved static local vars in TCentury::EndOfYearTasks to here:
//	   lastYearAvgMonthlySOMSC, prevYearSoilDepth
//	Dec02	Tom Hilinski
//	* Moved evapLoss to class TWater.
//	Aug03	Tom Hilinski
//	* Added orgCLeached, orgELeached.
//	Apr04	Tom Hilinski
//	* Removed leaching variables orglch, orgCLeached, orgELeached[NUMELEM];
//	  values are encapsulated in new class TLeachOrganicC.
//	* Remove eftext; calc is encapsulated in new class TMicrobial.
//	* Moved cemicb[3] into new class TDecomposition.
//	Nov04	Tom Hilinski
//	* Split TWater.wc into extrSoilH2OCrop and extrSoilH2OTree.
// ----------------------------------------------------------------------------
struct Tcomput
{
    Tcomput ()
      {
      	Clear ();
      }
    virtual ~Tcomput ()
      {
      }
    void Clear ()
      {
      	accum[0] = accum[1] = 0.0f;
      	for ( short i = 0; i < 12; ++i )
      	   cercrp[i] = 0.0f;
      	for ( short i = 0; i < MPY; ++i )
      	   defacm[i] = 0.0f;
	fps1s3 = fps2s3 = 0.0f;
	pltlig[0] = pltlig[1] = 0.0f;
      	p1co2[0] = p1co2[1] = 0.0f;
      	for ( short i = 0; i < 6; ++i )
      	{
      	   rnewas[i] = rnewbs[i] = 0.0f;
      	   rneww1[i] = rneww2[i] = rneww3[i] = 0.0f;
      	}
      	totco2 = 0.0f;
      	for ( short i = 0; i < NUMPOOLS; ++i )
      	   annualSumSoilC[i] = 0.0f;
      	ratioSC2LLC = 0.0f;
      	lastYearAvgMonthlySOMSC = 0.0f;
      	prevYearSoilDepth = 0.0f;
     }

    //---- public data
    float
	accum[ISOS],	// generally-available isotope accumulator in somdec
    	cercrp[12],	// [2][CPARTS][NUMELEM]
    	defacm[MPY], 	// monthly decomposition factor
	fps1s3,		// fraction of som1 decomposing to som3
	fps2s3,		// fraction of som2 decomposing to som3
	pltlig[2],	// fraction of current year's plant residue
			// that will be lignin.
			// [0] = aboveground; [1] = belowground.
	p1co2[2],	// parameters which control decomposition of som1
			//--- rnew??(iel,2) = C/E ratio for new material
			//   created when lignin component decomposes to som2.
			//   Dimensions = [NUMELEM][2]
	rnewas[6],	//   aboveground structural
	rnewbs[6],	//   belowground structural
	rneww1[6],	//   wood1
	rneww2[6],	//   wood2
	rneww3[6],	//   wood3
	totco2, 	// Total CO2 loss.
    	annualSumSoilC[NUMPOOLS],	// annual sum of som1c, 2c, 3c
    	ratioSC2LLC;			// ratio of simulation layer to
    					//   lower layer total C
    float lastYearAvgMonthlySOMSC;	// previous year's mean monthly SOMSC
    float prevYearSoilDepth;		// previous year's soil depth
};

// ----------------------------------------------------------------------------
//	Tforrem
//	Forest Removal variables.
// ----------------------------------------------------------------------------
struct Tforrem
{
    //---- types
    enum TForestEventType	//--- Forest event type
    {
	FORESTCUT,		// cutting event
	FORESTFIRE		// fire event
    };

    //---- constructors and destructor
    Tforrem ()
      {
      	Clear ();
      }
    virtual ~Tforrem ()
      {
      }
    void Clear ()
      {
      	evntyp = FORESTCUT;		// default = cutting event
      	fd[0] = fd[1] = 0.0f;
     	for ( short i = 0; i < FPARTS; ++i )
	  remf[i] = 0.0f;
     	for ( short i = 0; i < 12; ++i )
     	  retf[i] = 0.0f;
       }

    //---- public data
    TForestEventType evntyp;	// removal event type: 0 = cutting, 1 = fire
    float fd[2], 	// fine, coarse root fraction that dies
	remf[FPARTS], 	// fraction of component removed
	retf[12];	// was [3][4]
			// 1st dimension = leaf, fine branch, large wood
			// 2nd dimension = C, N, P, S
};

// ----------------------------------------------------------------------------
//	Tparam
//	Site and management parmaters.
//	History:
//	Apr04	Tom Hilinski
//	* Removed strm5l, strm5u; values are encapsulated in
//	  new class TLeachOrganicC.
// ----------------------------------------------------------------------------
struct Tparam
{
    Tparam ()
      {
      	Clear ();
      }
    virtual ~Tparam ()
      {
      }
    void Clear ()
      {
      	co2sys = pH = pslsrb = sorpmx = 0.0f;
      	ivauto = swflag = 0;
      	falprc = false;
      	satmt = trbasl = 0.0f;
      	sirri = cisofr = cisotf = 0.0f;
      	aufert = savedfert = 0.0f;
      	labtyp = Lbl_None;
      	for ( short i = 0; i < 2; ++i )
      	  co2ipr[i] = co2irs[i] = co2itr[i] = co2tm[i] = snfxmx[i] =
      	  epnfa[i] = epnfs[i] = satmos[i] = 0.0f;
      	for ( short i = 0; i < 3; ++i )
      	  prdx[i] = rces2[i] = rces3[i] = feramt[i] = 0.0f;
      	for ( short i = 0; i < 6; ++i )
      	  rcelit[i] = rces1[i] = 0.0f;
      	for ( short i = 0; i < 8; ++i )
      	  ppdf[i] = 0.0f;
      	for ( short i = 0; i < MPY; ++i )
      	  co2ice[i] = hpttr[i] = htran[i] = 0.0f;
       }

    //---- public data
    float		//--- boolean switches (should change to "boolean")
	co2sys;		// CO2 effect flag (1 = true)
    short		//--- tags
    	ivauto, 	// tag: Burke's eqs. to init. soil C
    	swflag;		// tag: src. of awilt, afield values
    float		//--- simulation surface soil layer - "edepth"
    	pH, 		// soil pH
	pslsrb, 	// slope term for labile mineral P over rooting depth
 	sorpmx; 	// Maximum P sorption potential, range: 1.0 -2.0
			//   Controls the slope of the sorption curve when
			//   mineral P = 0. Equals mineral P / sorption max
			//   when labile P = sorbed P.
    float		//--- category ???
    	co2ipr[2], 	//
    	co2ice[MPY],	// was [2][2][NUMELEM]
    			// [0][][] = crops, [1][][] = trees
    			// [][0][] = minimum, [][1][] = maximum
	co2irs[2],	//
	co2itr[2],	//
	co2tm[2];	//
    bool falprc;	// True if in period for fallow precipitation
    float		//--- category ???
    	hpttr[MPY], 	//
    	htran[MPY];	//
    float		//--- category ???
    	ppdf[8],	// was [4][2]:
    	prdx[3],	//
	rcelit[6],	// was [2][3]:
	rces1[6],	// was [2][3]
			//
	rces2[3], 	//
	rces3[3], 	//
	satmt, 		//
	snfxmx[2], 	//
	trbasl;		//
			//--- Site parameters: external nutrients
    float epnfa[2],	// intercept/slope: precip/atmos N fixation.
	epnfs[2],	// intercept/slope: precip/soil N fixation.
	satmos[2], 	// intercept/slope: atmos. S input.
	sirri; 		// S in irrigation water (mg/l).
			//--- isotope variables:
    TLabeling labtyp; 	// C labeling type (0 = none, 1 = 14C, 2 = 13C)
    float cisofr,	// isotope C fractions in new plant tissue - crops
	  cisotf;	// isotope C fractions in new plant tissue - trees
	  		//--- fertilization
    float aufert, 	// automatic fertilization (not functioning)
	savedfert,	// previous auto fert. option
    	feramt[3];	// amount of fertilizer (N, P, S)
};

// ----------------------------------------------------------------------------
//	Tparcp
//	Crop parameters
// ----------------------------------------------------------------------------
struct Tparcp
	: public ::nrel::century::PlantBase
{
    Tparcp ()
      : ::nrel::century::PlantBase ()
      {
      	Clear ();
      }
    virtual ~Tparcp ()
      {
      }
    float LAI (
      float const agLiveBiomass)
      {
	// reciprocal of biomass needed to produce an LAI of 1 (g/m**2)
	// source: ???
	#define CONVLAI 1.0f / 80.0f
	return agLiveBiomass * CONVLAI;
	#undef  CONVLAI
      }
    void Clear ()
      {
      	::nrel::century::PlantBase::Clear ();

      	// float
      	aglrem = astgc = astlbl = astlig = basfc2 = bglrem = 0.0f;
      	biok5 = biomax = fallrt = fawhc = fdgrem = feclig = 0.0f;
      	flfrem = flgrem = frtsh = fulcan = gfcret = grwprc = 0.0f;
      	hibg = himax = hiwsf = remwsd = irramt = irraut = pltmrf = 0.0f;
      	rdr = rmvstr = rtdtmp = sdethc = vlossp = 0.0f;
	// int
     	auirri = bioflg = flghrv = grzeff = 0;
	// short
	himon[0] = himon[1] = (short)0;
	seedl = 0;
	// bool
	// float arrays
      	for ( short i = 0; i < 2; ++i )
      	  fdfrem[i] = fnue[i] = 0.0f;
      	for ( short i = 0; i < 3; ++i )
      	  astrec[i] = crprtf[i] = efrgrn[i] = fecf[i] =
      	  fret[i] = frtc[i] = gret[i] = 0.0f;
      	for ( short i = 0; i < 4; ++i )
      	  clteff[i] = fligni[i] = fsdeth[i] = 0.0f;
      	for ( short i = 0; i < 6; ++i )
      	  pramn[i] = pramx[i] = prbmn[i] = prbmx[i] = 0.0f;
      	for ( short i = 0; i < 7; ++i )
      	  cultra[i] = 0.0f;
      }

    //---- public data
    float
    	astrec[3], 	//
    	aglrem, 	// crop.100 param
    	astgc, 		//
    	astlbl, 	//
    	astlig;		//
    int auirri;		//
    float
	basfc2,		//
	bglrem;		// crop.100 param
    int bioflg;		//
    float
    	biok5,		//
	biomax,		//
	clteff[4];	//
    float
    	crprtf[3],	//
	cultra[7],	//
	efrgrn[3],	//
	fallrt,		//
	fawhc,		//
	fdfrem[2],	//
	fdgrem,		//
	fecf[3],	//
	feclig,		//
	flfrem;		//
    int flghrv;		// crop.100 param
    float
    	flgrem,		//
	fligni[4],	// was [2][2]
	fnue[2],	//
	fret[3],	//
	frtc[3],	//
	frtsh,		//
	fsdeth[4],	//
	fulcan,		// crop.100 param
	gfcret,		//
	gret[3],	//
	grwprc;		// growing season precipitation
    int grzeff;		//
    float
    	hibg,		// crop.100 param
	himax;		// crop.100 param
    short himon[2];	//
    float
    	hiwsf,		// crop.100 param
	remwsd, 	// crop.100 param
	irramt,		//
	irraut;		//
    float
    	pltmrf,		//
	pramn[6],	// was [NUMELEM][2]
	pramx[6],	// was [NUMELEM][2]
	prbmn[6],	// was [NUMELEM][2]
	prbmx[6],	// was [NUMELEM][2]
	rdr,		//
	rmvstr,		//
	rtdtmp,		// crop.100 param
	sdethc;		//
    int seedl;		//
    float
	vlossp;		//
};

// ----------------------------------------------------------------------------
//	Tparfs
//	Forest-Savanna parameters
// ----------------------------------------------------------------------------
struct Tparfs
	: public ::nrel::century::PlantBase
{
    Tparfs ()
      : ::nrel::century::PlantBase ()
      {
      	Clear ();
      }
    virtual ~Tparfs ()
      {
      }
    void Clear ()
      {
      	::nrel::century::PlantBase::Clear ();

      	basfct = 0.0f;
      	for ( short i = 0; i < 30; ++i )
      	  ccefor[i] = 0.0f;
      	for ( short i = 0; i < 45; ++i )
      	  cerfor[i] = 0.0f;
      	decid = 0;
      	startedDecidGrowth = dropLeaves = false;
      	decw1 = decw2 = decw3 = 0.0f;
      	for ( short i = 0; i < 10; ++i )
      	  fcfrac[i] = 0.0f;
      	for ( short i = 0; i < 3; ++i )
      	  forrtf[i] = 0.0f;
       	laitop = ldrmlt = maxldr = sapk = swold = 0.0f;
      	for ( short i = 0; i < MPY; ++i )
      	  forrtf[i] = 0.0f;
      	for ( short i = 0; i < FPARTS; ++i )
      	  wdlig[i] = wooddr[i] = 0.0f;
     }

    //---- public data
    float
	basfct,		// (savanna only) ratio basal area to wood biomass
	ccefor[30],	// was [2][FPARTS][NUMELEM]
	cerfor[45];	// was [3][FPARTS][NUMELEM]
    short decid;		// >= 1 if deciduous tree forest; 2 = drought
    bool startedDecidGrowth;	// true if month of deciduous greenup
    bool dropLeaves;		// true if drop deciduous leaves
    float
	decw1,		//
	decw2,		//
	decw3,		//
	fcfrac[10];	// was [FPARTS][2] ;
    float forrtf[3],	//
	laitop,		//
	ldrmlt,		//
	leafdr[MPY],	//
	maxldr,		//
	sapk,		//
	swold,		//
	wdlig[FPARTS],	//
	wooddr[FPARTS];	//
};

// ----------------------------------------------------------------------------
//	TPotentialProduction
//	Potential production
// ----------------------------------------------------------------------------
struct TPotentialProduction
{
    TPotentialProduction ()
      {
      	Clear ();
      }
    virtual ~TPotentialProduction ()
      {
      }
    void Clear ()
      {
      	aboveGround = total = cropC = forestC = 0.0f;
     	for ( short i = 0; i < 15; ++i )
     	  elementUptake[i] = 0.0f;
       }

    //---- public data
    float
    	aboveGround,		// aboveground production potential
	total,			// total (above + belowground) potential
	cropC,			// potential crop C production
	forestC,		// potential forest C production
	elementUptake[15];	// Element uptake - was [FPARTS][NUMELEM]
};

// ----------------------------------------------------------------------------
//	TSite
//	Misc. site parameter data
// ----------------------------------------------------------------------------
struct TSite
{
    TSite ()
      {
      	Clear ();
      }
    virtual ~TSite ()
      {
      }
    void Clear ()
      {
      	sitpot = 0.0f;
      	nelem = 0;
      	for ( short i = 0; i < NUMPOOLS; ++i )
      	  lhiCU[i] = lhiCL[i] = lhiN[i] = lhiP[i] = lhiS[i] = 0.0f;
      	for ( short i = 0; i < 10; ++i )
      	  eflCU[i] = eflCL[i] = eflN[i] = 0.0f;
      }

    //---- public data
    float sitpot;	// (savanna only) relates grass N fraction to
			//   N availability (from tree parameter file)
    short nelem;	// number of elements (N, P, and S) to simulate
    float		//--- lower soil horizon pools' initial values
	lhiCU[NUMPOOLS],// unlabeled C
	lhiCL[NUMPOOLS],// labeled C
	lhiN[NUMPOOLS],	// N
	lhiP[NUMPOOLS],	// P
	lhiS[NUMPOOLS];	// S
			//--- erosion/deposition parameters
			// Fractions of eroded material lost to
			// respiration and dissolution in the
			// active. slow, passive, structural, and
			// metabolic pools:
    float		// Arrays are [pool][fraction].
	eflCU[10],	// [5][2] unlabeled C
	eflCL[10],	// [5][2] labeled C
	eflN[10];	// [5][2] N
};

// ----------------------------------------------------------------------------
//	TWater
//	Water parameters
//	History:
//	Apr05	Tom Hilinski
//	* Moved evapLoss to SoilWaterModel since it is not used outside it.
// ----------------------------------------------------------------------------
struct TWater
{
    TWater ()
      {
      	Clear ();
      }
    virtual ~TWater ()
      {
      }
    void Clear ()
      {
      	extrSoilH2OCrop = extrSoilH2OTree = 0.0f;
      	drain = 0.0f;
      	for ( short i = 0; i < 3; ++i )
      	  runoff[i] = deepStoreE[i] = 0.0f;
      	depthOfRoots = 0.0f;
	nlaypg = 0;
      }
    void UpdateRootingDepth (
      TCenturySoil const & soil)
      {
	depthOfRoots = soil.Depth(nlaypg - 1);
      }

    //---- public data
				//--- soil water content
    float extrSoilH2OCrop;	// crop/grass root-extractable soil water
    float extrSoilH2OTree;	// tree root-extractable soil water
	 			//--- Site parameters
    float
	drain,			// fraction of excess water drained
	runoff[3];		// runoff coefficients
    float
	depthOfRoots;		// depth of roots
				//   constant unless deposition/erosion
				//   this should go into a root submodel
    short nlaypg;		// # layers with h2o available for plant growth
    				//--- Leaching baseflow amounts
    float
	deepStoreE[3];		// N, P, S deep storage
};


// ----------------------------------------------------------------------------
//	TIterationData
//	History:
//	Holds bookkeepting data to be passed between subsequent iterations.
// ----------------------------------------------------------------------------
struct TIterationData
{
	//--- data
	short blockInstNum;		// management block instance #
	long updateInterval;		// interval for sendYearFunction
	std::ostringstream ms;		// user message stream

	//--- constructors and destructor
	TIterationData ()
	  {
	  	Clear ();
	  }
	void Clear ()
	  {
	  	blockInstNum = 0;
	  	updateInterval = 0;
	  	ms.str("");
	  }
	TIterationData& operator= (TIterationData const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	      blockInstNum = object.blockInstNum;
	      updateInterval = object.updateInterval;
	      ms.str() = object.ms.str();
	    }
	    return *this;
	  }
};

// ----------------------------------------------------------------------------
//	TDebugInfo
//	Debugging flags
//	History:
//	Sep03	Tom Hilinski
//	* Added verbose and noWarnings to TDebugInfo.
// ----------------------------------------------------------------------------
struct TDebugInfo
{
    //--- data
    bool
    	execTime,		// display execution time for simulation
    	writeTime,		// display the simulation time to the user
    	writeTimeDetails,	// display sim. time details
    	verbose,		// verbose messages displayed
    	noWarnings,		// no warning messages displayed
	echoArgs;		// display the command-line arguments
    //--- constructors and destructor
    TDebugInfo ()
    	{ Initialize (); }
    ~TDebugInfo ()
    	{ }
    TDebugInfo (TDebugInfo const & object)
    	{
    	  execTime = object.execTime;
    	  writeTime = object.writeTime;
    	  writeTimeDetails = object.writeTimeDetails;
    	  verbose = object.verbose;
    	  noWarnings = object.noWarnings;
    	  echoArgs = object.echoArgs;
    	}
    //--- functions
    void Initialize ()
    	{
    	  execTime = writeTime = writeTimeDetails =
    	  	verbose = noWarnings = echoArgs = false;
    	}
};

#endif // INC_centtypes_h
