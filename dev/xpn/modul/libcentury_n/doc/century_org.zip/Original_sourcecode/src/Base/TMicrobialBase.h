#ifndef INC_TMicrobialBase_h
#define INC_TMicrobialBase_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TMicrobialBase.h
//	Class:	  TMicrobialBase
//
//	Description:
//	Base class for microbial decomposition submodel for Century.
//	Members were extracted from class TCentury.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, April 2004
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TFlowsSchedulable.h"
#include "TSoilFlowsBase.h"


class TMicrobialBase
	: public TFlowsSchedulable
{
  public:
	//---- constructors and destructor
	virtual TMicrobialBase * const Clone () const = 0;	// Clone this

	//---- operator overloads

	//---- functions
	void CalcTextureEffect (		// Update the sand effect value
	  float const sandFraction)
	  {
	    textureFactor = peftxa + peftxb * sandFraction;
	  }
	float CFromActiveSOMSurface (
	  float const somC,		// Active SOM C pool for surface litter
	  float const defac,		// Decomposition factor
					//    based on water and temperature
	  float const dt)		// time step
	  {
	    return somC * defac * kActiveSOM[0] * dt;
	  }
	float CFromActiveSOMSoil (
	  float const somC,		// Active SOM C pool for soil
	  float const defac,		// Decomposition factor
					//    based on water and temperature
	  float const dt,		// time step
	  float const cultEffect,	// cultivation factor for som1
	  float const anaerobicEffect)	// Effect of soil anaerobic conditions
	  {
	    return somC * defac * kActiveSOM[1] * dt *
	    	cultEffect * textureFactor * anaerobicEffect;
	  }
	virtual void Respiration (
	  float const co2Loss, 		// CO2 loss from decomposition
	  short const numLayers,	// number of layers modeled for Box A;
					//   =2 for structural, metabolic, som1;
					//   =1 for som2, som3, wood pools.
					//   This is left dim. of the arrays
					//   cstatv, estatv, netMin.
	  short const layer,  		// soil layer (values: SRFC, SOIL)
	  float const * const tcstva,	// [numLayers]: C in each layer of Box A
	  float* const cstatv,		// [numLayers,ISOS]: C in Box A
	  float* const csrsnk,		// [ISOS]: C source/sink
	  float* const respiration,	// respiration; array[2]
	  float* const estatv,		// [numLayers,NUMELEM]: N,P,S for Box A
	  float* const grossMin,	// [NUMELEM]: gross mineralization
	  float* const netMin,		// [numLayers,NUMELEM]: net mineraliz.
	  float const simDepth		// simulation layer depth (cm)
	  ) = 0;
	static char const * const GetVersion ()		// Return version
	  { return version; }

  protected:
	//---- data: External
	TSoilFlowsBase & soilFlows;
	TSimTime const & simTime;

	//---- data: parameters
				// Parameters for regression equation
				//   to compute the effect of soil texture
				//   on the microbe decomposition rate
				//   (the effect of texture when there is
				//   no sand in the soil).
				//   From the fix.100 parameter set.
	float const peftxa;	//   Intercept; soil texture effect eq.
	float const peftxb;	//   Slope; soil texture effect eq.
	TLabeling const isotopeC; 	// C labeling
					//   (0 = none, 1 = 14C, 2 = 13C)
	float const df13C;	// Discrimination factor for 13C due to
				//   microbial respiration. (fixed.dresp)
	short const numElem;	// Number of elements (N=1, P=1, S=3)

	//---- data
	float kActiveSOM[2];	// Decomposition annual rate of surface & soil
				//   OM, respectively, with active turnover;
				//   pool fraction that turns over each year.
	float textureFactor;	// Sand effect upon leaching

	//---- functions

	//---- constructors and destructor
	TMicrobialBase (
	  TSoilFlowsBase & useSoilFlows,	// soil flows
	  TSimTime const & useSimTime,		// simulation timer
	  float const usePeftxa,	// Intercept; soil texture effect eq.
	  float const usePeftxb,	// Slope; soil texture effect eq.
	  float const useDecompRateActiveSOM[2],	// fixed.dec3[]
	  TLabeling const useIsotopeC, 	// C labeling
	  				//   (0=none, 1=14C, 2=13C)
	  float const useDf13C,		// discrimination factor for 13C due to
					//   microbial respiration.(fixed.dresp)
	  short const useNumElem)	// number of elements (N=1, P=1, S=3)
	  : TFlowsSchedulable (),
	    soilFlows (useSoilFlows),
	    simTime (useSimTime),
	    peftxa (usePeftxa),
	    peftxb (usePeftxb),
	    isotopeC (useIsotopeC),
	    df13C (useDf13C),
	    numElem (useNumElem)
	  {
	    kActiveSOM[0] = useDecompRateActiveSOM[0];
	    kActiveSOM[1] = useDecompRateActiveSOM[1];
	  }
	virtual ~TMicrobialBase ()
	  {
	  }
	TMicrobialBase (			// copy constructor
	  TMicrobialBase const & object,	//   object to copy
	  // Instances of Century submodels - refs to owner's objects
	  TSoilFlowsBase & useSoilFlows,
	  TSimTime const & useSimTime)
	  : TFlowsSchedulable (object),		// gets object to copy
	    soilFlows (useSoilFlows),		// get refs to owner's objects
	    simTime (useSimTime),
	    peftxa (object.peftxa),		// gets data to copy
	    peftxb (object.peftxb),
	    isotopeC (object.isotopeC),
	    df13C (object.df13C),
	    numElem (object.numElem)
	  {
	    Copy (object);			// gets data to copy
	  }

  private:
	//---- data
	static char const * const version;		// class version number

	//---- functions
	void Copy (TMicrobialBase const & object)	// Copy to this
	  {
	    kActiveSOM[0] = object.kActiveSOM[0];
	    kActiveSOM[1] = object.kActiveSOM[1];
	    textureFactor = object.textureFactor;
	  }
};

#endif // INC_TMicrobialBase_h
