// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC
//	File:	  TCenturySiteMgmtPairs.cpp
//	Class:	  TCenturySiteMgmtPairs
//
//	Description: See header file.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, June 2002
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TCenturySiteMgmtPairs.h"
#include <fstream>
using namespace std;
using namespace nrel::dcirc;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	ReadPairsFile
//	Read site/mgmt pairs.
//	Returns false if successful, else true if failed or error.
bool TCenturySiteMgmtPairs::ReadPairsFile (
	std::string const & fileName)	// read from this file
{
	bool result = false;

	ifstream fs ( fileName.c_str() );
	if ( fs.is_open() )
	{
		// read in the pairs
		TFileNamePair namePair;
		while ( !fs.eof() && fs.good() )
			fs >> namePair.first >> namePair.second;
	}
	else	// open failed
		result = true;
	return result;
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//--- end of definitions for TCenturySiteMgmtPairs ---
