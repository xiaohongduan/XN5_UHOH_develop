// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model, daily version
//	File:	  tgmodel.cpp
//	Class:	  TDayCentSoil
//	Function: TraceGasModel
//
//	Description:
//	N Trace Gas Model: calculates daily N2, N2O, NO fluxes from the soil.
// ----------------------------------------------------------------------------
//	Author: Melannie Hartman, Bill Parton
//	History:
//	??????    Melannie Hartman, melannie@NREL.colostate.edu
//	* Created original Trace Gas functions for FORTRAN/C version of DayCent
//	Jun2000   Melannie Hartman, melannie@NREL.colostate.edu
//	* Created original tgmodel.c for FORTRAN/C version of DayCent
//	Apr2001   Melannie Hartman, melannie@NREL.colostate.edu
//	* Translated tgmodel.c to tgmodel.cpp
//	Jun2001   Melannie Hartman, melannie@NREL.colostate.edu
//	* Major changes in the way mineralized N is flowed into the
//	  soil in other parts of DayCent, don't allow for mineralized
//	  N to be added to Nitrate and Ammonium layers in the TraceGasModel as
//	  it once was. ScheduleNPSFlow adds the mineralized N to soil Nitrate
//	  and Ammonium layers.
//	Oct2001   Melannie Hartman, melannie@NREL.colostate.edu
//	* Nitrate() updated through nitrate[] array to allow double precision
//	Dec02   Tom Hilinski
//	* Misc. clean up, const-correctness, optimization.
//	* Convert to use arraytypes.h for arrays
//	Apr03   Tom Hilinski
//	* Clean up to prevent NAN values from un-initialized variables.
//	May03	Tom Hilinski
//	* Additional assertions and some minor cleanup and optimization.
//	* Denitrify() now uses actual bulk density & field capacity, so
//	  removed call to GetSoilProperties.
//	* Moved k array calcs to new member CalcNDistributionFactors.
//	* Removed fracNetMinToNitrate (0.2); all mineralization N flux to NH4.
//	* Removed input arg "newNMinerl"; already added to soil.
//	* Moved methane oxidation to simsom_dc.cpp; not relavent to N cycle.
// ----------------------------------------------------------------------------
//	Notes:
//    * Need to distribute ammonium among layers? -mdh 4/12/01
//    * Is simDepth a good way to specify depth of soil properties? -mdh 4/14/01
//      methane_oxidation routine has a similar depth to specify -mdh 4/25/01
// ----------------------------------------------------------------------------

#include "TDayCentSoil.h"
#include "TDayCent.h"
#include "TCenturyMath.h"
using namespace std;

//	CalcNDistributionFactors
//	Calculates the exponential redistribution factors used to
//	distribute of nitrate, ammonium, and CO2 thru the soil profile.
void TDayCentSoil::CalcNDistributionFactors (
	TSoilBase::TFloatArray const & depth,	// soil depth array
	T1DDoubleArray & k)			// N redistribution factors
{
    if ( k.size() != depth.size() )
	k.resize ( GetLayerCount() );

    double const Kconst = -0.1;
    k(0) = 1.0 -  std::exp(Kconst * depth[0]);  // exp(K*0.0) - exp(K*depth[0]);
    for (short layer = 1; layer < GetLayerCount(); ++layer)
    {
	k(layer) = std::exp( Kconst * depth[layer - 1] ) -
		   std::exp( Kconst * depth[layer] );
	// Assert (k(layer) > 0.0);
    }
    double const kSum = ARRAY_SUM (k);
    Assert (kSum != 0.0);
    k = k / kSum;
    if ( !(std::fabs(ARRAY_SUM (k) - 1.0) < 1.0E-4) )
    {
	std::stringstream os;
	os << "!(std::fabs(ARRAY_SUM (k) - 1.0) < 1.0E-10)"
	   << "\n  std::fabs(ARRAY_SUM (k) - 1.0) = "
	   << std::fabs(ARRAY_SUM (k) - 1.0)
	   << "\n  kSum = " << kSum
	   << "\n  sum(k) = " << ARRAY_SUM (k)
	   << "\n  k = " << k
	   << std::endl;
	throw (os.str());
	// Assert (std::fabs(ARRAY_SUM (k) - 1.0) < 1.0E-10);
    }
}

//	TraceGasModel
//	N Trace Gas submodel
void TDayCentSoil::TraceGasModel (
    float const simDepth,		// simulation depth (cm)
    TSoilTextureIndex textureIndex,	// soil texture index
    bool const isDeciduous,		// true if deciduous forest
    bool const isAgriculture,		// true if crop or grassland
					//   fertilized or cultivated grassland
    float const surfTempAvg,	// avg soil surface temperature (deg C)
    float const maxt,		// max of montly max temperatures (deg C)
    float const ppt,		// daily precip (cm)
    float const snowPack,	// snow cover (cm SWE)
    float const newCO2,		// amount of soil respiration (gC/m^2/day)
    float & fluxNOtotal,	// total NO flux (gN/m^2/day)
    float & fluxN2Onit,		// nitrification N2O flux (gN/m^2/day)
    float & fluxN2Odenit,	// denitrification N2O flux (gN/m^2/day)
    float & fluxN2denit)	// denitrification N2 flux (gN/m^2/day)
{
    // error checks
    Assert (newCO2 > 0.0f);

    // initialize fluxes
    fluxNOtotal = 0.0f;
    fluxN2Onit = 0.0f;
    fluxN2Odenit = 0.0f;
    fluxN2denit = 0.0f;
    double fluxNOnit = 0.0;		// flux nitrified NO (gN/m^2/day)
    double fluxNOdenit = 0.0;		// flux denitrified NO (gN/m^2/day)
    double const fractionN03toN2O = 0.02;  // frac of new NO3 that goes to N2O
    double newNO3 = 0.0;		// new NO3 produced (gN/m^2/day)
					//    (gN/m^2/day)
    // newNO3 is the amount of nitrate available for trace gas production.
    // It is a portion of the existing Nitrate pool.
    double NH4_to_NO = 0.0; 		// ammonium converted to NO to reach
					//    potential NO flux (gN/m^2/day)
    float const avgWFPS = WtdMeanWFPS (simDepth);  // water-filled pore space

    // ammonium is accessed by total in soil rather by layer
    double ammonium = Ammonium().Quantity (0, BottomLayer());
    if (ammonium <= 0.0)				// anything to do?
	return;

    // nitrate work array
    T1DDoubleArray nitrate (GetLayerCount());
    for (short layer = 0; layer < GetLayerCount(); layer++)
	nitrate(layer) = Nitrate(layer);

    // For the balance check reporting at the end of the function
#ifndef NDEBUG
    float const initialTotalN =
	Nitrate().Quantity (0, BottomLayer()) +
	Ammonium().Quantity (0, BottomLayer());
#endif

    // N redistribution factors
    T1DDoubleArray k ( GetLayerCount() );
    CalcNDistributionFactors (depth, k);

    // --- Nitrification ---

    double const NH4_to_NO3 =
      Nitrify (textureIndex, surfTempAvg, maxt, avgWFPS, simDepth, ammonium);

    // --- Partition Nitrate ---

    //  multiplier NOx flux based on recent rain events and snowpack
    // increase of NO due to moisture and rain >= 1.0
    double const kPrecipNO = NOxPulse (ppt, snowPack);

    //  fraction of new NO3 that is converted to N2O and NO
    double NO_N2O_ratio = 0.0;  		// NO/N2O ratio <= 1.0
    newNO3 = NH4_to_NO3;
    if (newNO3 > 1.0E-10)
    {
	// normalized diffusivity in aggregate soil media (0-1)
	float const bulkDensity =
		BulkDensity().WtdMean(0.0f, simDepth, depth, thickness);
	float const porosity = 1.0f - bulkDensity / PARTDENS;
	float const dDO = Diffusivity (
		FieldCapacity().WtdMean(0.0f, simDepth, depth, thickness),
		bulkDensity, porosity, avgWFPS );

	// ratio NO:N2O
	NO_N2O_ratio = 15.23 + ( 35.45 *
		std::atan ( 0.676 * M_PI * (10.0f * dDO - 1.86f) )
		) / M_PI;
	Assert (NO_N2O_ratio >= 0.0);
	if (isAgriculture)
		NO_N2O_ratio *= 0.20;

	// N2O flux
	fluxN2Onit = newNO3 * fractionN03toN2O;
	newNO3 -= fluxN2Onit;

	// maximum possible nitrification NO flux (gN/m^2/day)
	double const potentialFluxNOnit = fluxN2Onit * NO_N2O_ratio * kPrecipNO;
	Assert (potentialFluxNOnit >= 0.0);

	if (potentialFluxNOnit <= newNO3)
	{
	    fluxNOnit = potentialFluxNOnit;
	    newNO3 -= fluxNOnit;
	    if ( newNO3 > 0.0 )
	    	nitrate = nitrate + k * newNO3;		// remaining NO3 to soil
	    newNO3 = 0.0;
	}
	else
	{
	    // take N out of ammonimum to get max fluxNOtotal possible
	    NH4_to_NO = std::min ( ammonium, potentialFluxNOnit - newNO3 );
	    Assert (NH4_to_NO >= 0.0);
	    fluxNOnit = newNO3 + NH4_to_NO;
	    newNO3 = 0.0;
	    ammonium -= NH4_to_NO;
	    Assert (ammonium >= 0.0);
	}
    }

    // --- Denitrification ---

    // Convert newCO2 (g/m2) to co2PPM[] (ppm) and distrbute it
    // thru the soil profile - new calculations 5/17/00
    T1DFloatArray co2PPM (GetLayerCount());	// CO2 concentration by layer
    for (short layer = 0; layer < GetLayerCount(); layer++)
    {
	float const gramsSoil = 		// soil mass in layer (g m-2)
		BulkDensity(layer) * thickness[layer] * 1.0e4f;
	Assert (gramsSoil > 0.0f);
	co2PPM(layer) = k(layer) * newCO2 / gramsSoil * 1.0E6f;
	Assert (co2PPM(layer) > 0.0f);
    }

    double newFluxN2Odenit, newFluxN2denit;
    Denitrify (simDepth, co2PPM, nitrate, newFluxN2Odenit, newFluxN2denit);

    // --- Partition denitratrification fluxes ---

    // For denitrification, kPrecipNO is >= 1.0 -mdh 6/22/00
    // potentialFluxDenitrifNO =
    //   maximum possible denitrification NO flux
    //   based on NO/N2O and kPrecipNO (gN/m^2/day)
    double potentialFluxDenitrifNO =
	newFluxN2Odenit * NO_N2O_ratio * std::min (1.0, kPrecipNO);
    Assert (potentialFluxDenitrifNO >= 0.0);
    if (potentialFluxDenitrifNO <= ammonium)	//  Take all N out of NH4
    {
	fluxNOdenit = potentialFluxDenitrifNO;
	ammonium -= potentialFluxDenitrifNO;
    }
    else					// NH4 limits; some N from N2O
    {
	// Convert all ammonium to NO
	fluxNOdenit = ammonium;
	potentialFluxDenitrifNO -= ammonium;
	ammonium = 0.0;
	// convert some N2O to NO
	if (potentialFluxDenitrifNO <= fluxN2Odenit)
	{
	    fluxNOdenit += potentialFluxDenitrifNO;
	    newFluxN2Odenit -= potentialFluxDenitrifNO;
	}
    }
    fluxN2Odenit = static_cast<float>( newFluxN2Odenit );
    fluxN2denit  = static_cast<float>( newFluxN2denit  );
    Assert (ammonium >= 0.0);

    // Check for very small values
    float const tolerance = 1.0E-30;
    Assert (fluxNOnit >= 0.0);
    if (fluxNOnit < tolerance)
	fluxNOnit = 0.0;
    Assert (fluxNOdenit >= 0.0);
    if (fluxNOdenit < tolerance)
	fluxNOdenit = 0.0;
    Assert (fluxN2Onit >= 0.0f);
    if (fluxN2Onit < tolerance)
	fluxN2Onit = 0.0f;
    Assert (fluxN2Odenit >= 0.0f);
    if (fluxN2Odenit < tolerance)
	fluxN2Odenit = 0.0f;
    Assert (fluxN2denit >= 0.0f);
    if (fluxN2denit < tolerance)
	fluxN2denit = 0.0f;

    // fluxNOtotal from denitrification (new calculation -mdh 6/1/00)
    fluxNOtotal = fluxNOnit + fluxNOdenit;

    // Redistribute ammonium among layers
    for (short layer = 0; layer < GetLayerCount(); layer++)
    {
	Ammonium(layer) = k(layer) * ammonium;
	//nitrate(layer) = std::max ( nitrate(layer), 0.0 );
	Nitrate(layer) = nitrate(layer);
    }
    //Assert (Ammonium().Quantity (0, BottomLayer()) - (float)ammonium > 1.0e5);

    // Final balance check
#ifndef NDEBUG
    float const finalTotalN =
	Nitrate().Quantity (0, BottomLayer()) +
	Ammonium().Quantity (0, BottomLayer()) +
	fluxNOtotal + fluxN2Onit + fluxN2Odenit + fluxN2denit;
    dynamic_cast<TDailyCenturyBase const &>(owner).BalanceCheckWithMsg (
	initialTotalN, finalTotalN, 1.0E-4f, "Trace gas submodel total N" );
#endif
}

//--- end of file ---
