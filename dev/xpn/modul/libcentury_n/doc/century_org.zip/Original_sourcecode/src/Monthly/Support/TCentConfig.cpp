// ----------------------------------------------------------------------------
//	Copyright (c) 2001-2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCentConfig.cpp
//	Class:	  TCenturyConfig
//
//	Description:
//	Class which initializes a configuration set for class TCentury.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, July 2001
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TCentConfig.h"
#include "TCentSSFile.h"
#include "TCentNcFile.h"
#include "TCentException.h"
#include "version.h"
#include <cstring>
using namespace std;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// subdirectory for monthly century
char const * const TCenturyConfig::mcSubdirectory = "Monthly";

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

TCenturyConfig::TCenturyConfig (
	std::string const & useSiteFile,	// site file name
	std::string const & useMgmtFile,	// management file name
	std::string const & useOutputFile,	// output file
	TOutputBase::TOutputType useOutputType,	// file format type
	TOutputBase::TAccessMode useAccess,	// file access mode
	bool const useDoOutput,			// false if no output
	std::string const & useCentHomePath,	// home or "exe" path
	std::string const & useWorkPath,	// path to work files
	std::string const & useParamPath,	// path to parameters
	TStringArray const & useParamPathList,	// parameter file search
	std::string const & useTemplatePath,	// path to templates
	std::string const & useTextDataPath,	// path to text data
	std::string const & useFixFile,		// path/name to fix.100
	std::string const & useUserName,	// user name
	TAsynchCommunication const * const
				useAsynchCom)	// asynch communication
	: TMyBase (
	    	useCentHomePath,
		useWorkPath, useParamPath, useParamPathList,
		useTemplatePath, useTextDataPath, mcSubdirectory,
		useFixFile, useUserName, useDoOutput )
{
	ConstructMe (
		useSiteFile, useMgmtFile,
		useOutputFile, useOutputType, useAccess,
		useAsynchCom );
	if ( VerifySite() )	// verification failed?
	{
		// to do: handle VerifySite failed
	}
	// to do: VerifyManagement
}

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	UseOutputFile
//	Use the output file name, output type, and access specified.
//	Returns the error state flag.
TCentException::TCEIndex TCenturyConfig::UseOutputFile (
	std::string const & useOutputFile,	// output file name
	TOutputBase::TOutputType useOutputType,	// file format type
	TOutputBase::TAccessMode useAccess)	// file access mode
{
	outputError = TCentException::CE_NOERR;		// reset
	if ( !ProduceOutput() )
		return outputError;

	// Is the output name there?
	if ( useOutputFile.empty() )
	{
		outputError = TCentException::CE_NOOUTF;
		output.reset ();			// ...clear output
		return outputError;
	}
	// Load the variables' names and definitions
	TEH::TFileName ovInfoFile ( paths->GetPath(CenturyPaths::TextData),
				TEH::TFileName::FT_Directory );
	ovInfoFile.SetName ("OutVarsDef");
	ovInfoFile.SetExtension ("nc");
	if ( !ovInfoFile.IsValid() || ovInfoFile.IsEmpty() )
	{
		outputError = TCentException::CE_NAOVND;
		output.reset ();			// ...clear output
		return outputError;
	}
	// Create output object
	// (1) netCDF format
	if ( useOutputType == TOutputBase::Type_NetCDF )
	{
		output.reset (
			new TCentNcFile (
				useOutputFile, useAccess,
				*mgmt, *site, userName, ovInfoFile ) );
	}
	// (2) default = spreadsheet CSV format
	else // if ( useOutputType == TOutputBase::Type_CSV )
	{
		output.reset ( new TCentSprShtFile (
			useOutputFile, useAccess,
			TOutputBase::Format_CommaDelim,
			*mgmt, *site,
			userName, ovInfoFile ) );
	}

	//--- error checks on success
	// Only checks those errors that could have occurred while
	// creating the output file instances.
	if ( !output.get() )				// instance created?
	{
		outputError = TCentException::CE_OPNOUT;
	}
	else
	{
		if ( output->GetErrorState() != TOutputBase::Error_NoError )
		{
			switch ( output->GetErrorState() )
			{
			  case TOutputBase::Error_InvalidType:
			  case TOutputBase::Error_InvalidFile:
				outputError = TCentException::CE_INVOFT;
				break;
			  case TOutputBase::Error_OpenFailed:
				outputError = TCentException::CE_OPNOUT;
				break;
			  case TOutputBase::Error_WriteFailed:
				outputError = TCentException::CE_WRTOUT;
				break;
			  case TOutputBase::Error_InvalidAccess:
				outputError = TCentException::CE_IOFAMD;
				break;
			  case TOutputBase::Error_InvalidFormat:
				outputError = TCentException::CE_IOFFMT;
				break;
			  case TOutputBase::Error_NoOutVarInfo:
				outputError = TCentException::CE_NAOVND;
				break;
			  default:
				outputError = TCentException::CE_UNKNOWN_ERROR;
				break;
			}
		}
	}
	if (outputError != TCentException::CE_NOERR)	// error?
		output.reset ();			// ...clear output
	return outputError;
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	Copy
// 	copy to this
void TCenturyConfig::Copy (TCenturyConfig const & object)
{
	if ( &object )
	{
	}
}

//	SetWorkPath
//	Figure out the work path default based upon the management and
//	site files. Assumes the site and mgmt members have been set already.
void TCenturyConfig::SetWorkPath ()
{
	bool haveWorkPath = false;
	// already have a work path?
	if ( paths->GetPathLength (CenturyPaths::Work) > 0 &&
	     paths->IsValid (CenturyPaths::Work) )
	{
		haveWorkPath = true;
	}
	// Check the site path
	if ( !haveWorkPath && HaveSite() )
	{
		TEH::TFileName sitePath (
			site->GetFileName(), TEH::TFileName::FT_Directory);
		if ( !sitePath.IsEmpty() )		// anything there?
		{
			paths->SetPath ( sitePath, CenturyPaths::Work );
			haveWorkPath = true;
		}
	}
	// Check the management path
	if ( !haveWorkPath && HaveManagement() )
	{
		TEH::TFileName mgmtPath (
			mgmt->GetFile(MFT_Scheme), TEH::TFileName::FT_Directory );
		if ( !mgmtPath.IsEmpty() )		// anything there?
		{
			paths->SetPath ( mgmtPath, CenturyPaths::Work );
			haveWorkPath = true;
		}
	}
	// Else, use the default path
	if ( !haveWorkPath )
	{
		paths->SetPath ( paths->GetDefaultPath (CenturyPaths::Work),
				 CenturyPaths::Work );
	}
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	ConstructMe
//	common constructor
void TCenturyConfig::ConstructMe (
	std::string const & useSiteFile,		// site file name
	std::string const & useMgmtFile,		// management file name
	std::string const & useOutputFile,		// output file
	TOutputBase::TOutputType useOutputType,		// file format type
	TOutputBase::TAccessMode useAccess,		// file access mode
	TAsynchCommunication const * const useAsynchCom) // asynch com.
{
	// Keep the following in order due to dependencies.
	UseSite (useSiteFile);
	UseManagement (useMgmtFile);
	InitializeParamDBList ();
	SetWorkPath ();
	UseOutputFile (
		BuildOutputFileName(useOutputFile),
			useOutputType, useAccess );
	asynchCom.reset ( new TAsynchCommunication (*useAsynchCom) );
}

//--- end of definitions for TCenturyConfig ---
