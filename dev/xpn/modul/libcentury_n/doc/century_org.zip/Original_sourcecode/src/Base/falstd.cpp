// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  falstd.cpp
//	Class:	  TCenturyBase
//	Function: SimulateFallStandingDead
//
//	Description:
//	Simulate fall of standing dead for the month.
// ----------------------------------------------------------------------------
//	History:
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::SimulateFallStandingDead ()
{
    if (cropC.stdedc > 0.0f)			// anything to do?
    {
	float const deadCToLitter = cropC.stdedc * parcp.fallrt;
	float deadECRatio[NUMELEM];		//
	for (short layer = 0; layer < site.nelem; ++layer)
	    deadECRatio[layer] = nps.stdede[layer] / cropC.stdedc;
	float const fractionLabeledC = cropC.stdcis[LABELD] / cropC.stdedc;
	PartitionResidue ( deadCToLitter, deadECRatio, SRFC,
			   cropC.stdcis, nps.stdede,
			   comput.pltlig[ABOVE], fractionLabeledC );
    }
}

//--- end of file falstd.cpp ---
