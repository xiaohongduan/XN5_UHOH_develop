
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include <time.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf.h"

/* Prototypes */
int cropdef(int *ntimes, char *history);
int h2odef(int *ntimes, char *history);
int livcdef(int *ntimes, char *history);
int livndef(int *ntimes, char *history);
int nfluxdef(int *ntimes, char *history);
int nmnrdef(int *ntimes, char *history);
int nuptdef(int *ntimes, char *history);
int proddef(int *ntimes, char *history);
int respdef(int *ntimes, char *history);
int soilcdef(int *ntimes, char *history);
int soilndef(int *ntimes, char *history);
int cremvdef(int *ntimes, char *history);
int nremvdef(int *ntimes, char *history);
int sitedef(int*, char*, int*, int*, int row[], int col[], int calendar_year[]);

/* Global variables */
int osite_ncid;

/* External variables */
extern char history[HISTL+1];

int
deffil_(int *ntimes, int *nrow, int *ncol, int *spinup, int *savall, int row[], int col[],
   int calendar_year[])
{
	/* Define NetCDF OUTPUT files */

	/* ARGUMENTS:
	 *	nrow	Number of rows
	 *	ncol	Number of columns
	 */

	 /*  Added row[], col[] to be passed to sitedef.  -mdh 8/18/98 */
	 /* row[0], row[1] - starting and ending rows */
	 /* col[0], col[1] - starting and ending columns */

	 /* Added calendar_year[] to be passed to sitedef. -mdh 10/6/98 */
         /* calendar_year[] is written to site file for post processing purposes only */
         /* calendar_year[0] - calendar year corresponding to initial simulation year */
         /* calendar_year[1] - calendar year corresponding to final simulation year */

	/* Local variables */
	int	defok;	/* Error flag for file definition functions	*/
	int	ferr_msg;	/* Error message from file definitions	*/
        int     status;
	char    thist[HISTL];
	time_t  tp;

	/* Get time and date for file history */
	tp = time(NULL);
	memset(thist, (char)NULL, sizeof(char)*HISTL);
	strncat(thist, history, strlen(history)-1);
        memset(history, (char)NULL, sizeof(char)*HISTL);
	strcat(thist,":  ");
	strncat(thist, ctime(&tp), strlen(ctime(&tp))-1);
	strcpy(history, thist);

	/* Define output files */

        if (*savall == 1)
	{
		defok = cropdef(ntimes, history);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = h2odef(ntimes, history);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = livcdef(ntimes, history);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = livndef(ntimes, history);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = nfluxdef(ntimes, history);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = nmnrdef(ntimes, history);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = nuptdef(ntimes, history);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = proddef(ntimes, history);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = respdef(ntimes, history);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = soilcdef(ntimes, history);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = soilndef(ntimes, history);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = cremvdef(ntimes, history);
		if (defok >= 1) 
			ferr_msg = ncerr;

		defok = nremvdef(ntimes, history);
		if (defok >= 1) 
			ferr_msg = ncerr;
	}

	/* Open file of state variable values from end of spinup */
	/* VEMAP ONLY */
	if (*spinup == 0)
		status = nc_open("RUNF/site.nc", NC_NOWRITE, &osite_ncid);

	defok = sitedef(ntimes, history, nrow, ncol, row, col, calendar_year);

	if (defok >= 1 || site_ncid < 0) 
		ferr_msg = ncerr;

	return 0;
}
