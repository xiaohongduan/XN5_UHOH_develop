#ifndef INC_TModalDlg_h
#define INC_TModalDlg_h
// ----------------------------------------------------------------------------
//	Copyright 1997-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  T_ModalDlg.h
//	Class:	  TModalDlg
//
//	Description:
//	Base class for dialogs that are centered in the application window.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Oct97
//	History:
//	Nov01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Fixed centering values when dialog size > app window size.
// ----------------------------------------------------------------------------

#include <v/vmodald.h>
#include <v/vapp.h>

class TModalDlg : public vModalDialog
{
  public:
	//--- constructors and destructor
	TModalDlg (
	  vApp * const parent,
	  char const * const title = "")
	  : vModalDialog (parent, title)
	  {
	  }
	TModalDlg (
	  vBaseWindow * const parent,
	  char const * const title = "")
	  : vModalDialog (parent, title)
	  {
	  }
	virtual ~TModalDlg ()
	  {
	  }

	//--- functions - over-ridden vDialog functions
	virtual void DialogDisplayed();
	virtual void DialogCommand (ItemVal id, ItemVal val, CmdType type);
	virtual ItemVal ShowModalDialog (const char *message, ItemVal &retVal);

	//--- functions
	short GetItemIndexInCmdObj (CommandObject *cmdObj, ItemVal cmdId);

  protected:

  private:
};

#endif 	// INC_TModalDlg_h
