// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  IRCUtil.cpp
//
//	Description:
//	Utility functions for DayCentIRC and the Grid-Cohort Framework.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, June 2005
//	History:
// ----------------------------------------------------------------------------

#include "IRCUtil.h"
using namespace nrel::dcirc;

// Following string arrays should have elements in the same order as the
// associated enum's.

static std::string outputVarScopeStr[] =	// enum TOVScope
{
	"cohort", "cell", "grid", ""
};

static std::string outputVarGroupByStr[] =	// enum TOVScopeGroup
{
	"none", "biome", "landscape", ""
};

//	ToOutputVariablesConfig
//	Convert values from an INI record to output variables configuration.
//	Returns false if successful, else true if error.
bool nrel::dcirc::ToOutputVariablesConfig (
	::nrel::ini::INIData::Values const & values,
	TOutputVarConfig & config)
{
	bool failure = false;

	//	# Output variables (scope, group by)
	//	# scope    = cohort, cell, grid
	//	# group by = none, biome, landscape

	if ( values.Size() > 0 )
	{
	    // scope
	    if ( values[0] == outputVarScopeStr[OVS_Cohort] )
		config.scope = OVS_Cohort;
	    else if ( values[0] == outputVarScopeStr[OVS_Cell] )
		config.scope = OVS_Cell;
	    else if ( values[0] == outputVarScopeStr[OVS_Grid] )
		config.scope = OVS_Grid;
	    else // error
	    {
		config.scope = OVS_Cell;		// safe value
		failure = true;
	    }

	    // group by
	    if ( values.Size() > 1 )
	    {
		if ( values[1] == outputVarGroupByStr[OVSG_None] )
			config.groupBy = OVSG_None;
		else if ( values[1] == outputVarGroupByStr[OVSG_Biome] )
			config.groupBy = OVSG_Biome;
		else if ( values[1] == outputVarGroupByStr[OVSG_Landscape] )
			config.groupBy = OVSG_Landscape;
		else // error
		{
			config.groupBy = OVSG_None;	// safe value
			failure = true;
		}
	    }
	}
	return failure;
}

//	FromOutputVariablesConfig
//	Convert output variables configuration to an INI values list.
//	Returns false if successful, else true if error.
bool nrel::dcirc::FromOutputVariablesConfig (
	TOutputVarConfig const & config,
	::nrel::ini::INIData::Values & values)
{
	bool failure = false;

	if ( config.scope < OVS_LastItem )
		values.Add ( outputVarScopeStr[ config.scope ] );
	else // error
	{
		// set to save value
		values.Add ( outputVarScopeStr[ OVS_Cell ] );
		failure = true;
	}
	if ( config.groupBy < OVSG_LastItem )
		values.Add ( outputVarGroupByStr[ config.groupBy ] );
	else // error
	{
		// set to save value
		values.Add ( outputVarGroupByStr[ OVSG_None ] );
		failure = true;
	}
	return failure;
}


//--- end of file ---

