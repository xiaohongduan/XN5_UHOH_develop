// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  wdeath.cpp
//	Class:	  TCentury
//	Function: WoodDeath
//
//	Description:
//	Death of leaves, fine branches, large wood, fine roots, and
//	coarse roots.
//
//	NOTE:  WOODDR(1) is the death rate in fall for deciduous forests
//	LEAFDR(MTH) is the monthly death rate for leaves in every
//	            case except for fall in deciduous forests.
// ----------------------------------------------------------------------------
//	History:
//	Jan00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Updated drought deciduous forest to check for available soil water.
//	Jun02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Move static local var drpdlv to struct Tparfs::dropLeaves
// ----------------------------------------------------------------------------

#include "TCentury.h"

void TCentury::WoodDeath ()
{
    float fr14;				// fraction 14C
    float accum[ISOS] = {0.0, 0.0 };	// cumulative C
    float ctodie,			//
	etodie,				//
	recres[NUMELEM];		// ratio E:C in residue
    float tostore;			//
    const register short
    	idx = (short)st->month - 1;	// monthly array index

    // do not drop leaves at the start of the block
    if ( st->year == st->blockStartYear )
	parfs.dropLeaves = false;

    // Added winter solstice calculation for northern and southern hemisphere.
    // drop deciduous leaves if they haven't already been dropped by
    // winter soltice. -mdh 2/99
    bool atWinterSolstice =
	( st->month == 12 && !siteEnv.IsDayIncreasing() ) ||
    	( st->month == 6  && !siteEnv.IsDayIncreasing() );

    //--- Death of leaves
    // NOTE:  WOODDR(LEAF) is the death rate in fall for deciduous forests.
    // LEAFDR(MTH) is the monthly death rate for leaves in every
    // case except for fall in deciduous forests.
    if ( AmountIsSignificant(forestC.rleavc) )	// Have minimum forest leaf C?
    {
	if ( IsDeciduousForest() )		// Deciduous forest?
	{
	    // If the daylight hours are increasing - it must be spring
	    if (siteEnv.IsDayIncreasing() && wt.tave > 7.0f)
		parfs.dropLeaves = false;
	    // If daylight hours are decreasing and the temperature is low
	    //  enough drop leaves for fall season.
	    if ( IsNormalDecidForest() )	// normal deciduous forest
	    {
	    	// need to drop leaves?
		if (wt.tave <= 7.0f && !parfs.dropLeaves || atWinterSolstice)
		{
		    ctodie = forestC.rleavc * parfs.wooddr[LEAF];
		    parfs.dropLeaves = true;
		}
		else					// drop leaves
		    ctodie = forestC.rleavc * parfs.leafdr[idx];
	    }
	    else if ( IsDroughtDecidForest() )	// drought deciduous forest
	    {
	    	// original code
		//ctodie = forestC.rleavc * (1.0f - wfunc) * parfs.wooddr[LEAF];
		// new code
		float const availH2O =			// root soil water
		    soil->PlantExtractableWater (0.0f, water.depthOfRoots);
		if ( availH2O > 0.0f )
		    parfs.dropLeaves = false;
		if ( availH2O < 0.001f && !parfs.dropLeaves )
		{
		    ctodie = forestC.rleavc * parfs.wooddr[LEAF];
		    parfs.dropLeaves = true;
		}
		else
		    ctodie = forestC.rleavc * parfs.leafdr[idx];
	    }
	}
	else						// Continuous forest
	{
	    // Use leaf death rate multiplier from EACHYR
	    ctodie = forestC.rleavc * parfs.leafdr[idx] * parfs.ldrmlt;
	}

	// Compute E/C ratios
	for (short element = 0; element < site.nelem; ++element)
	{
	    recres[element] = nps.rleave[element] / forestC.rleavc;
	    // Compute flow to retranslocation storage
	    tostore = recres[element] * ctodie * parfs.forrtf[element];
	    flows->Schedule (&nps.rleave[element], &nps.forstg[element],
	    		    st->time, tostore);
	    // Decrease E/C by the amount that is retranslocated
	    recres[element] *= 1.0f - parfs.forrtf[element];
	}
	float const fr14 = forestC.rlvcis[LABELD] / forestC.rleavc;
	PartitionResidue (ctodie, recres, SRFC, forestC.rlvcis, nps.rleave,
			  parfs.wdlig[LEAF], fr14);
    }

    // Death of fine roots
    if (forestC.frootc > 0.0f)
    {
	ctodie = forestC.frootc * parfs.wooddr[FROOT];
	register float recip = 1.0 / forestC.frootc;	// optimize
	for (short element = 0; element < site.nelem; ++element)
	    recres[element] = nps.froote[element] * recip;
	float const fr14 = forestC.frtcis[LABELD] * recip;
	PartitionResidue (ctodie, recres, SOIL, forestC.frtcis, nps.froote,
			  parfs.wdlig[FROOT], fr14);
    }

// Fine Branches, Large Wood, and Coarse Roots go to the dead wood
//   compartments: WOOD1, WOOD2, WOOD3

    // Death of fine branches
    if (forestC.fbrchc > 0.0f)
    {
	ctodie = forestC.fbrchc * parfs.wooddr[FBRCH];
	ScheduleCFlow ( st->time, ctodie, param.cisotf, 1.0f,
		&forestC.fbrcis[UNLABL], &forestC.wd1cis[UNLABL],
		&forestC.fbrcis[LABELD], &forestC.wd1cis[LABELD],
		accum);
	for (short element = 0; element < site.nelem; ++element)
	{
	    etodie = ctodie * (nps.fbrche[element] / forestC.fbrchc);
	    flows->Schedule (&nps.fbrche[element], &nps.wood1e[element],
	    		    st->time, etodie);
	}
    }

    // Death of large wood
    if (forestC.rlwodc > 0.0f)
    {
	ctodie = forestC.rlwodc * parfs.wooddr[LWOOD];
	ScheduleCFlow ( st->time, ctodie, param.cisotf, 1.0f,
			&forestC.rlwcis[UNLABL], &forestC.wd2cis[UNLABL],
			&forestC.rlwcis[LABELD], &forestC.wd2cis[LABELD],
			accum);
	for (short element = 0; element < site.nelem; ++element)
	{
	    etodie = ctodie * (nps.rlwode[element] / forestC.rlwodc);
	    flows->Schedule (&nps.rlwode[element], &nps.wood2e[element],
	    		    st->time, etodie);
	}
    }

    // Death of coarse roots
    if (forestC.crootc > 0.0f)
    {
	ctodie = forestC.crootc * parfs.wooddr[CROOT];
	ScheduleCFlow ( st->time, ctodie, param.cisotf, 1.0f,
			&forestC.crtcis[UNLABL], &forestC.wd3cis[UNLABL],
			&forestC.crtcis[LABELD], &forestC.wd3cis[LABELD],
			accum);
	for (short element = 0; element < site.nelem; ++element)
	{
	    etodie = ctodie * (nps.croote[element] / forestC.crootc);
	    flows->Schedule (&nps.croote[element], &nps.wood3e[element],
	    		    st->time, etodie);
	}
    }
}	// WoodDeath
