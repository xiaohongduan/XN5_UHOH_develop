#ifndef INC_TSoilFlowsBase_h
#define INC_TSoilFlowsBase_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TSoilFlowsBase.h
//	Class:	  TSoilFlowsBase
//
//	Description:
//	Class for managing flows to/from physical soil pools.
//	Members were extracted from class TCenturyBase.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, April 2004
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TSoilBase.h"
#include "TSimTime.h"
#include "TFlow.h"
#include "centconsts.h"
#include "precision.h"


class TSoilFlowsBase
{
  public:
	//---- constructors and destructor
	TSoilFlowsBase (
	  TSoilBase & useSoil,		// the soil
	  TFlow & useFlows,		// flow stack
	  TSimTime const & useST)	// simulation time manager
	  : soil (useSoil),
	    flows (useFlows),
	    simTime (useST)
	  {
	  }
	virtual ~TSoilFlowsBase ()
	  {
	  }

	//---- operator overloads

	//---- functions
	float FlowEIntoSoil ( 		// Flow mineralized E into soil.
	  float const eToAdd,		//   amount of mineral E to add (gE/m^2)
	  float * const source,		//   source of mineral element
	  TSoilPool & soilPool,		//   soil sink of mineral element
	  float const depth);		//   soil depth to receive E (cm)
	float FlowEFromSoil (		// Flow mineralized E from soil.
	  float const eDemand,		//   amount of mineral E demand (gE/m^2)
	  TSoilPool & soilPool,		//   soil source of mineral element
	  float * const sink,		//   sink of mineral element
	  float const depth);		//   soil depth to receive E (cm)

  protected:
	//---- data
	TSoilBase & soil;		// the soil
	TFlow & flows;			// flow stack
	TSimTime const & simTime;	// simulation time manager

	//---- functions
	TSoilFlowsBase (			// copy constructor
	  TSoilFlowsBase const & object,	//   object to copy
	  // Instances of Century submodels - refs to owner's objects
	  TSoilBase & useSoil,		// the soil
	  TFlow & useFlows,		// flow stack
	  TSimTime const & useST)	// simulation time manager
	  : soil (useSoil),
	    flows (useFlows),
	    simTime (useST)
	  {
	  }

  private:
	//---- data

	//---- functions
};

#endif // INC_TSoilFlowsBase_h
