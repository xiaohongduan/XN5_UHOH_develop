// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  droot.cpp
//	Class:	  TCentury
//	Function: DeathOfRoots
//
//	Description:
//	Simulate death of roots for the month.
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TCentury.h"

void TCentury::DeathOfRoots ()
{
    register short iel;		// loop index
    float
      rtdh,		//
      recres[NUMELEM],	//
      rdeath;		//

//	Mod. added (stemp .lt. 2.0) conditional since roots don't floatly
//	die in winter because it's too cold for physiological activity.
//	-rm  9-12-90
    if (cropC.bglivc <= 0.0f || wt.stemp < parcp.rtdtmp)
	return;

    // This is representing the death of fine surface roots.  They depend
    // on moisture in the top soil layers, so use avh2o(1).
    //	Also added rtdh term for drought conditions. -rm  9-12-90
    // Changed to use sim layer depth for moisture: root depth >> sim depth
    rtdh = 1.0f - wt.avh2o[2] / (fixed.deck5 + wt.avh2o[2]);
    rdeath = parcp.rdr * rtdh;
    rdeath = std::min (rdeath, 0.95f);	// limit maximum rdeath
    rdeath *= cropC.bglivc;
    for (iel = 0; iel < site.nelem; ++iel)
	recres[iel] = nps.bglive[iel] / cropC.bglivc;
    float const fr14 = cropC.bglcis[LABELD] / cropC.bglivc;
    PartitionResidue (rdeath, recres, SOIL, cropC.bglcis, nps.bglive,
    			comput.pltlig[BELOW], fr14);
}
