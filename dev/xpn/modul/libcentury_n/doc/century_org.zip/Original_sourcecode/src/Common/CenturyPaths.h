#ifndef INC_TDefPaths_h
#define INC_TDefPaths_h
// ----------------------------------------------------------------------------
//	Copyright 1999-2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TDefPaths.h
//	Class:	  CenturyPaths
//
//	Description:
//	Manages the default paths for the template, parameters, and
//	working directory for Century.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Feb99
//	History:
//	Jun01	Tom Hilinski
//	* Changed "path"to vector<string>; rewrote portions to use this.
//	* Added copy constructor, operator=
//	Oct01	Tom Hilinski
//	* Moved member data to the protected section.
//	* Added more const-correctness.
//	* Minor cleanup mods to various functions.
//	* Added function IsEmpty()
//	Dec2002	Tom Hilinski
//	* Made a base class. Daily and monthly versions specialize.
//	* Added std::string public members where appropriate.
//	* GetPath now returns std::string
//	* Default paths are now set in the constructor.
//	* Added member AppendToDefaultSubdirectory
//	* Constructor takes all initial paths (or NULL).
//	Jan2003	Tom Hilinski
//	* Enhanced error handling;
//	  added member errorPathIndex and associated functions.
//	* Derived classes must now implement Clone function.
//	Apr2003	Tom Hilinski
//	* Added "textdata" to the defaultPaths[].
//	* Added constructor argument for "textdata".
//	* Added to enum TDefPathIdx, "TextData".
//	Apr2005	Tom Hilinski
//	* Added operator==
//	Aug05	Tom Hilinski
//	* Changed all char* args in constructor to std::string &.
//	* Changed class name from TDefaultPaths to CenturyPaths.
//	* Change file names from TDefPaths.h/cpp to CenturyPaths.h/cpp
//	* Moved the subdirectory name from children to here.
//	  Deleted children classes (TMCDefaultPaths, TDCDefaultPaths).
// ----------------------------------------------------------------------------

#include "TFileName.h"
#include <vector>

class CenturyPaths
{
  public:
	//--- types
	typedef std::vector<std::string>		TStringArray;

	enum TDefPathIdx 	// Specifies indices to the paths
	{
	  Executable,		// path to executable file - FIRST ITEM ALWAYS!
	  Parameters, 		// parameter files path
	  Templates,  		// template files path
	  TextData,		// text data files for model
	  SiteLib,		// site library path
	  BlockLib,		// block library path
	  MgmtLib,		// managment library path
	  Work,  		// working directory - 2ND TO LAST ALWAYS!
	  NumberOfPaths		// count of paths - LAST ITEM ALWAYS!
	};
	enum TDefPathErr	// List of error codes
	{
	  NoError, 		// no error - FIRST ENUM ITEM ALWAYS
	  NoPath,		// a blank or null path specified
	  InvalidPathIndex,	// invalid index to path list
	  InvalidExecPath, 	// invalid executable path
	  InvalidParamPath, 	// invalid parameter files path
	  InvalidTmpltPath, 	// invalid template files path
	  InvalidMgmtLibPath,	// invalid managment library path
	  InvalidSiteLibPath, 	// invalid site library path
	  InvalidBlkLibPath, 	// invalid block library path
	  MemoryAlloc,		// memory allocation error
	  UnknownError		// unknown error - LAST ENUM ITEM ALWAYS
	};

	//--- constructors and destructor
	CenturyPaths (
	  std::string const & useExePath,	// home or "exe" path
	  std::string const & useParamPath,	// path to parameters
	  std::string const & useTemplatePath,	// path to templates
	  std::string const & useTextDataPath,	// path to text data
	  std::string const & useSiteLibPath,	// path to site library
	  std::string const & useBlockLibPath,	// path to mgmt block library
	  std::string const & useMgmtLibPath,	// path to mgmt library
	  std::string const & useWorkPath,	// path to work files
	  std::string const & useSubdirectory);	// subdirectory name
	  					//  "Monthly" | "Daily"
	CenturyPaths (
	  CenturyPaths const & object)
	  : subdirectory (object.subdirectory)
	  {
	    Copy (object);
	  }
	virtual ~CenturyPaths ()
	  {
	    ClearPaths ();
	  }
	virtual CenturyPaths * const Clone () const	// Clone this
	  {
	    return new CenturyPaths (*this);
	  }

	//---- operator overloads
	CenturyPaths& operator= (
	  CenturyPaths const & object)
	  {
	    if (this != &object)	// assigning self?
		Copy (object);
	    return *this;
	  }
	bool operator== (
	  CenturyPaths const & object) const
	  {
	    if ( &object )
	    {
		return actualPaths == object.actualPaths;
	    }
	    else
		return false;
	  }
	bool operator!= (
	  CenturyPaths const & object) const
	  { return !(*this == object); }

	//--- functions - setup and modify
	bool UseDefaultPaths ();		// Use the default paths
	bool UseDefaultPath (			// Set the path using default
	  TDefPathIdx const which);		//   index to path
	bool SetPath (				// Set the specified path
	  TEH::TFileName const & newPath,	//   path
	  TDefPathIdx const which);		//   index to path
	bool SetPath (				// Set the specified path
	  std::string const & newPath,		//   path
	  TDefPathIdx const which)		//   index to path
	  {
	    TEH::TFileName name ( newPath,
		TEH::TFileName::FT_Directory );
	    return SetPath (name, which);
	  }
	bool SetPath (				// Set the specified path
	  char const * const newPath,		//   path
	  TDefPathIdx const which)		//   index to path
	  {
	    TEH::TFileName name ( newPath,
	    	TEH::TFileName::FT_Directory );
	    return SetPath (name, which);
	  }
	bool SetPath (				// Set the specified path
	  TEH::TFileName const * const newPath,	//   path
	  TDefPathIdx const which)		//   index to path
	  {
	    return SetPath ( *newPath, which );
	  }
	void SetModified (			// Set modified flag
	  bool const modifiedFlag)		//   to this
	  { modified = modifiedFlag; }

	//--- functions - queries
	static
	  char const * const GetDefaultPath (	// Gets the default path
	  TDefPathIdx const which)		//   index to path
	  { return defaultPaths[which]; }
	std::string const & GetPath (		// Get the specified path
	  TDefPathIdx const which) const	//   index to path
	  { return actualPaths[which]; }
	TStringArray const & GetPathList () const	// Get the path list
	  { return actualPaths; }
	int GetPathLength (			// Get a path length (# chars)
	  TDefPathIdx const which) const	//   index to path
	  { return actualPaths[which].size(); }
	bool IsEmpty () const			// True if no paths
	  { return actualPaths.empty(); }
	bool IsValid (				// True if a valid path
	  TDefPathIdx const which) const;	//   index to path
	bool Exists (				// True if path exists
	  TDefPathIdx const which) const;	//   index to path
	bool IsModified () const		// True if paths modified
	  { return modified; }
	bool IsError () const			// True if error condition
	  { return error != NoError; }
	TDefPathErr LastError () const		// Return last error code.
	  { return error; }
	TDefPathIdx ErrorForPathIndex () const	// Path index associated w/error
	  { return errorPathIndex; }
	static std::string GetHomeEnvVar ();	 // Get "CENTURY_HOME"

	//--- functions
	void ClearError ()			// Clear the error code.
	  {
	    error = NoError;
	    errorPathIndex = NumberOfPaths;
	  }
	void ClearPaths ()			// "clear" the paths.
	  {
	    actualPaths.clear ();
	  }

  protected:
	//--- const data
	static
	  char const * const defaultPaths[];	// list of default paths

	//--- data
	TStringArray actualPaths;		// actual paths to be used
	std::string const subdirectory;		// subdirectory name
	TDefPathErr error;			// last error code
	TDefPathIdx errorPathIndex;		// error found in this path
	bool modified;				// true if data changed

	//--- functions
	bool AppendToDefaultSubdirectory (	// append subdirectory to path
	  TDefPathIdx const which,		//   index to the path array
	  std::string const & useSubDirectory);	//   subdirectory or subpath
	bool FindExePath (			// Find path to executable
	  std::string const & suggestedPath,	//   initial guess at the path
	  std::string & exePath);		//   "found" path
	bool FindWorkPath (			// Find path to work directory
	  std::string const & suggestedPath,	//   initial guess at the path
	  std::string & workPath);		//   "found" path
	void CheckAndUsePath (			// If path ok, use it
	  TDefPathIdx const which,		//   index to the path array
	  TEH::TFileName const & pathName,	//   path to check
	  std::string & pathUsed);		//   path used after check

  private:
	//--- functions
	void Copy (CenturyPaths const & object)	// Copy to this
	  {
	    actualPaths = object.actualPaths;
	    error = object.error;
	    modified = object.modified;
	  }
};

#endif // INC_TDefPaths_h
