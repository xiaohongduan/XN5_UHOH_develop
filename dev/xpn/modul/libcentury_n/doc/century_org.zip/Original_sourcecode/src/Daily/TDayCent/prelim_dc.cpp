// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  prelim.cpp
//	Class:	  TDayCent
//	Function: PreliminaryCalcs
//
//	Description:
//	Initialize variables and parameters.
// ----------------------------------------------------------------------------
//	History:
//      See Century/prelim.cpp
//	30Jul01 Melannie Hartman, melannie@nrel.colostate.edu
//	* Changed this function from TCentury member to TDayCent member
//        since it initializes daily output variables dwt.*.
//      14Jan02 Melannie Hartman, melannie@nrel.colostate.edu
//      * Updated to keep consistent with TCentury::PreliminaryCalcs()
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TDayCent.h"
#include "TCenturyMath.h"
#include <cstring>
#include <numeric>

void TDayCent::PreliminaryCalcs ()
{
    //--- Time initializations - time step is one month
    st->year = st->startYear;
    st->month = ::Jan;			// always start at beginning of year
    st->UpdateFloatTime ();

    //--- lower simulation layer and C depth distribution
    soilC.somsc = soilC.som1c[SOIL] + soilC.som2c + soilC.som3c;
    Assert (soilC.somsc > 0.0f);
    // Initialize the soil C depth distribution
    InitializeLowerLayer ();			// initialize lower layer
    Assert ( !soil->IsEmpty() );
    if ( lowerSoil.get() && lowerSoil->Thickness() > 0.0f )
    {
	soil->ExponentialOMPC (soilC.somsc, lowerSoil->GetTotalC(),
    				wt.simDepth, lowerSoil->Thickness() );
    }
    else
    {
	soil->ExponentialOMPC (soilC.somsc, soilC.somsc * 0.5f,
    				wt.simDepth, soil->SoilDepth() );
    }

    //--- Water contents
    // Field capacity and wilting point.
    if (param.swflag >= 1 && param.swflag <= 6)		// soil water flag > 0?
    	soil->CalcWPandFC (param.swflag);
    // Calculate initial asmos based on relative water content fraction (rwcf)
    // supplied in the site file.
    register short const numLayers = soil->GetLayerCount();	// loop limit
    for (short layer = 0; layer < numLayers; ++layer)
    {
	soil->WaterContent(layer) = ( soil->WiltingPoint(layer) +
	    wt.rwcf[layer] *
	    ( soil->FieldCapacity(layer) - soil->WiltingPoint(layer) ) ) *
	    soil->Thickness()[layer];
    }
    bool const calcRWCF =	// rwcf values supplied? if not, calc them
    	( 0.0f ==
    	  std::accumulate ( &wt.rwcf[0], &wt.rwcf[numLayers], 0.0f ) );
    UpdateWaterVariables (calcRWCF);

    //--- Computations related to decomposition of soil organic matter
    //      Added 08/91   vek
    decomp->InitializeSOMDecomp ();	// soil and wt.simDepth already set

    // Intercept for the texture equation of secondary P depends upon
    // pH input.  Note that this code changes the value of a
    // 'fixed' parameter (texesp(2))
    if (param.pH <= fixed.phesp[0])
	fixed.texesp[1] = fixed.phesp[1];
    else if (param.pH >= fixed.phesp[2])
	fixed.texesp[1] = fixed.phesp[3];
    else
    {
	float xslope = ( fixed.phesp[3] - fixed.phesp[1] ) /
		       ( fixed.phesp[2] - fixed.phesp[0] );
	fixed.texesp[1] = xslope * param.pH +
				( fixed.phesp[1] - xslope * fixed.phesp[0] );
    }

    //--- Initialize the decomposition factor
    if ( SimMicrocosm() )
    {
	// Microcosm works for cropping system only.
	// There is currently no check that only Fallow is chosen
    	// Microcosm has constant temperature and soil moisture.
	if ( !sysType.IsCropGrass() )
	    ThrowCentException (TCentException::CE_MICRO, 0);
	// monthly temperature is constant
	wt.tave = wt.stemp = dwt.tave = dwt.stemp =
		microcosm->GetTemperature();
	wt.rain = dwt.precip = 0.0f;				// no rain
	wt.irract = dwt.irract = 0.0f;
	// Bound defac to >= 0.0 rm - 12/21/92
	// Effect of temperature on decomposition
	dwt.tfunc = TempEffectOnDecomp (dwt.stemp);
	// Effect of moisture on decomposition
	dwt.wfunc = WaterEffectOnDecomp ( soil->GetSoilTextureIndex (),
    					  soil->WtdMeanWFPS(wt.simDepth),
    					  1.0f,
    					  2 /* fixed.idef */ );
	dwt.defac = std::max ( dwt.tfunc * dwt.wfunc, 0.0f );        // daily
	// initially, make the monthly value = daily initial value
	wt.defac = calendarTools.DaysInMonth (st->month, st->year); // monthly

	// Preset array which will contain monthly values of defac
	float *p = &comput.defacm[0];
	for (short m = 0; m < MPY; ++m)
	    *(p++) = wt.defac;
    }
    else			// no microcosm
    {
	// Preset array which will contain monthly values of defac
	float *p = &comput.defacm[0];
	for (short i = 0; i < MPY; ++i)
	    *(p++) = -1.0f;
	wt.adefac = wt.defac = 0.0f;
    }

    // texture values for simulation layer
    float const clayFraction = soil->ClayFraction().WtdMean (
			0.0f, fixed.edepth, soil->Depth(), soil->Thickness() );
    float const siltFraction = soil->SiltFraction().WtdMean (
			0.0f, fixed.edepth, soil->Depth(), soil->Thickness() );
    float const sandFrac = soil->SandFraction().WtdMean (
			0.0f, fixed.edepth, soil->Depth(), soil->Thickness() );

    //--- Effect of soil texture on the microbe decomposition rate
    microbial->CalcTextureEffect (sandFrac);

    //--- Compute parameters which control decomposition of som1
    // p1co2 must be computed for surface and soil.   vek  08/91
    // Note that p1co2b(1) must equal 0 because there is no
    // soil texture effect on the surface.
    comput.p1co2[SRFC] = fixed.p1co2a[SRFC];
    comput.p1co2[SOIL] = fixed.p1co2a[SOIL] + fixed.p1co2b[SOIL] * sandFrac;
    // Decomposition of som1 to som3 is a function of clay content
    //         vek june90
    comput.fps1s3 = fixed.ps1s3[INTCPT] + fixed.ps1s3[SLOPE] * clayFraction;
    comput.fps2s3 = fixed.ps2s3[INTCPT] + fixed.ps2s3[SLOPE] * clayFraction;
    if (fixed.texepp[0] == 1.0f)
    {
	// Calculate pparmn(2)
	// Include effect of texture; weathering factor should be per year
	fixed.pparmn[1] = 12.0f *
	    atanf ( clayFraction + siltFraction,
		    fixed.texepp[1], fixed.texepp[2],
		    fixed.texepp[3], fixed.texepp[4] );
    }
    if (fixed.texesp[0] == 1.0f)	// psecmn(2) - Include texture effect
	fixed.psecmn[1] = 12.0f *
		( fixed.texesp[1] + fixed.texesp[2] * sandFrac );
}

//--- end of PreliminaryCalcs ---

