#ifndef INC_CenturySubmodelBase_h
#define INC_CenturySubmodelBase_h
// ----------------------------------------------------------------------------
//	Copyright 2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  CenturySubmodelBase.h
//	Class:	  CenturySubmodelBase
//
//	Description:
//	Abstract Base Class for Century submodels.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Apr05
//	History:
// ----------------------------------------------------------------------------

class CenturySubmodelBase
{
  public:
	CenturySubmodelBase ()
	  {
	  }
	virtual ~CenturySubmodelBase()
	  {
	  }

	//----- interface
	void ResetDaily ()		// Reset daily variables
	  {
	    DoResetDaily ();
	  }
	void ResetMonthly ()		// Reset monthly accumulator variables
	  {
	    DoResetMonthly ();
	  }
	void ResetAnnual ()		// Reset annual accumulator variables
	  {
	    DoResetAnnual ();
	  }

  protected:

  private:
	virtual void DoResetDaily () = 0;
	virtual void DoResetMonthly () = 0;
	virtual void DoResetAnnual () = 0;

};


#endif // INC_CenturySubmodelBase_h
