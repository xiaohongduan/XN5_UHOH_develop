#ifndef INC_nrel_century_CenturySiteCreatorBase_h
#define INC_nrel_century_CenturySiteCreatorBase_h

// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  CenturySiteCreatorBase.h
//	Class:	  CenturySiteCreatorBase
//
//	Description:
//	Base class for creating site parameter files for the Century models.
//
//	Responsibilities:
//	* <what class is supposed to do>
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, June 2005
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "SiteCreatorBase.h"
#include "TSiteParametersBase.h"

namespace nrel
{
  namespace century
  {

template
<
  class CenturyType	// Century model object type
>
class CenturySiteCreatorBase
	: public ::nrel::site::SiteCreatorBase
{
  public:
	//---- types
	typedef CenturyType			century_type;

	//---- constructors and destructor
	CenturySiteCreatorBase (
	  CenturyType const & centuryInstance,		// model source
	  EditorsInfo const & useEditInfo,
	  TSiteParamUnknown & siteParameters)		// fill this
	  : ::nrel::site::SiteCreatorBase (useEditInfo, siteParameters),
	    century (centuryInstance)
	  {
	  }
	CenturySiteCreatorBase (
	  CenturySiteCreatorBase const & object)  // copy constructor
	  : ::nrel::site::SiteCreatorBase (object),
	    century (object.century)
	  {
	  }
	virtual ~CenturySiteCreatorBase ()
	  {
	  }

	//---- operator overloads

	//---- functions

  protected:
	//---- constants

	//---- data
	CenturyType const & century;			// model source

	//---- functions

  private:
	//---- constants

	//---- data

	//---- functions
	virtual void GetClimate (
	  TSiteParamSet & parameterSet );
	virtual void GetSiteAndSoil (
	  TSiteParamSet & parameterSet );
	virtual void GetExternalNutrients (
	  TSiteParamSet & parameterSet );
	virtual void GetCropAndSOM (
	  TSiteParamSet & parameterSet );
	virtual void GetForestParts (
	  TSiteParamSet & parameterSet );
	virtual void GetSoilWater (
	  TSiteParamSet & parameterSet );
	virtual void GetLowerHorizonPools (
	  TSiteParamSet & parameterSet );
	virtual void GetErosionDeposition (
	  TSiteParamSet & parameterSet );

};

  } // namespace century
} // namespace nrel

#endif // INC_nrel_century_CenturySiteCreatorBase_h
