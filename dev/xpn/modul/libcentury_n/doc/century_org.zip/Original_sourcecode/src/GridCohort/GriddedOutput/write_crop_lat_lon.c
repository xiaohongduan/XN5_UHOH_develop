
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Rewrite the crop.nc netCDF file using COARDS standards */
/* The original file was organized variable(cell, time) */
/* The new file is organized variable(time, lat, lon) */

#include <stdio.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf_ll.h"

/* Prototypes */
int write_crpval(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]);
int write_crmvst(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]);
int write_cgrain(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]);
int write_feramt(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]);
int write_irract(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]);
int write_egrain(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]);
int write_ermvst(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]);

    int write_crop_ll_(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      write_crpval(ntimes, nlat, nlon, lat_lon_mask);
      write_crmvst(ntimes, nlat, nlon, lat_lon_mask);
      write_cgrain(ntimes, nlat, nlon, lat_lon_mask);
      write_feramt(ntimes, nlat, nlon, lat_lon_mask);
      write_irract(ntimes, nlat, nlon, lat_lon_mask);
      write_egrain(ntimes, nlat, nlon, lat_lon_mask);
      write_ermvst(ntimes, nlat, nlon, lat_lon_mask);

      return 0;
    }


    int write_crpval(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  crpval_vals[MAXCELLS];
      int status;
      int oldcropid;
      int oldcrpvalid;
      int ii, jj, ngrids;

      /* Open old version of crop.nc file */
      status = nc_open("crop.nc", NC_NOWRITE, &oldcropid);
      if (status != NC_NOERR) handle_error("nc_open(crop.nc)", status);

      /* Get the index for the crpval output variable */
      status = nc_inq_varid(oldcropid, "crpval", &oldcrpvalid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for crpval",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        crpval_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the crpval output */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldcropid, oldcrpvalid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for crpval",status);
            }
            crpval_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(cropll_ncid, crpvalll_id, start, count, crpval_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for crpval",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldcropid);

      return 0;
    }


    int write_crmvst(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  crmvst_vals[MAXCELLS];
      int status;
      int oldcropid;
      int oldcrmvstid;
      int ii, jj, ngrids;

      /* Open old version of crop.nc file */
      status = nc_open("crop.nc", NC_NOWRITE, &oldcropid);
      if (status != NC_NOERR) handle_error("nc_open(crop.nc)", status);

      /* Get the index for the crmvst output variable */
      status = nc_inq_varid(oldcropid, "crmvst", &oldcrmvstid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for crmvst",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        crmvst_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the crmvst output */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldcropid, oldcrmvstid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for crmvst",status);
            }
            crmvst_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(cropll_ncid, crmvstll_id, start, count, crmvst_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for crmvst",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldcropid);

      return 0;
    }


    int write_cgrain(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  cgrain_vals[MAXCELLS];
      int status;
      int oldcropid;
      int oldcgrainid;
      int ii, jj, ngrids;

      /* Open old version of crop.nc file */
      status = nc_open("crop.nc", NC_NOWRITE, &oldcropid);
      if (status != NC_NOERR) handle_error("nc_open(crop.nc)", status);

      /* Get the index for the cgrain output variable */
      status = nc_inq_varid(oldcropid, "cgrain", &oldcgrainid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for cgrain",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        cgrain_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the cgrain output */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldcropid, oldcgrainid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for cgrain",status);
            }
            cgrain_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(cropll_ncid, cgrainll_id, start, count, cgrain_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for cgrain",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldcropid);

      return 0;
    }


    int write_feramt(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  feramt_vals[MAXCELLS];
      int status;
      int oldcropid;
      int oldferamtid;
      int ii, jj, ngrids;

      /* Open old version of crop.nc file */
      status = nc_open("crop.nc", NC_NOWRITE, &oldcropid);
      if (status != NC_NOERR) handle_error("nc_open(crop.nc)", status);

      /* Get the index for the feramt output variable */
      status = nc_inq_varid(oldcropid, "feramt", &oldferamtid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for feramt",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        feramt_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the feramt output */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldcropid, oldferamtid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for feramt",status);
            }
            feramt_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(cropll_ncid, feramtll_id, start, count, feramt_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for feramt",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldcropid);

      return 0;
    }


    int write_irract(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  irract_vals[MAXCELLS];
      int status;
      int oldcropid;
      int oldirractid;
      int ii, jj, ngrids;

      /* Open old version of crop.nc file */
      status = nc_open("crop.nc", NC_NOWRITE, &oldcropid);
      if (status != NC_NOERR) handle_error("nc_open(crop.nc)", status);

      /* Get the index for the irract output variable */
      status = nc_inq_varid(oldcropid, "irract", &oldirractid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for irract",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        irract_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the irract output */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldcropid, oldirractid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for irract",status);
            }
            irract_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(cropll_ncid, irractll_id, start, count, irract_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for irract",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldcropid);

      return 0;
    }


    int write_egrain(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  egrain_vals[MAXCELLS];
      int status;
      int oldcropid;
      int oldegrainid;
      int ii, jj, ngrids;

      /* Open old version of crop.nc file */
      status = nc_open("crop.nc", NC_NOWRITE, &oldcropid);
      if (status != NC_NOERR) handle_error("nc_open(crop.nc)", status);

      /* Get the index for the egrain output variable */
      status = nc_inq_varid(oldcropid, "egrain", &oldegrainid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for egrain",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        egrain_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the egrain output */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldcropid, oldegrainid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for egrain",status);
            }
            egrain_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(cropll_ncid, egrainll_id, start, count, egrain_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for egrain",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldcropid);

      return 0;
    }


    int write_ermvst(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  ermvst_vals[MAXCELLS];
      int status;
      int oldcropid;
      int oldermvstid;
      int ii, jj, ngrids;

      /* Open old version of crop.nc file */
      status = nc_open("crop.nc", NC_NOWRITE, &oldcropid);
      if (status != NC_NOERR) handle_error("nc_open(crop.nc)", status);

      /* Get the index for the ermvst output variable */
      status = nc_inq_varid(oldcropid, "ermvst", &oldermvstid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for ermvst",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        ermvst_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the ermvst output */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldcropid, oldermvstid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for ermvst",status);
            }
            ermvst_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(cropll_ncid, ermvstll_id, start, count, ermvst_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for ermvst",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldcropid);

      return 0;
    }
