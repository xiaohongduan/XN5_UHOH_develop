#ifndef INC_ranfun_h
#define INC_ranfun_h

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  ranfun.h
//	Function:
//
//	Description:
//	Declarations for global functions for
//	generating random values and values from distributions.
//	anorm	- ? random value from a normal distribution
//	sknorm	- ? random value from a skewed normal distribution
// ----------------------------------------------------------------------------
//	History:
//	Jan00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Removed the licensed functions gasdev, ran1, and the now
//	  obsolete function randu, and replaced them with the portable
//	  random generator functions in "zufall" (zufall.c, zufall.h).
// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

extern float anorm (float const mean, float const stdev);
extern float sknorm (float const mean, float const stddev, float const skew);
extern float gpdf (float const x, float const a, float const b,
			float const c, float const d);

#endif // INC_ranfun_h
