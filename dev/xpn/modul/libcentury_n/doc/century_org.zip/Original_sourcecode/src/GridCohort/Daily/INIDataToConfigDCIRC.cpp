// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  INIDataToConfigDCIRC.cpp
//	Class:	  INIDataToConfigDCIRC
//
//	Description:
//	Class for transferring INI data to Configuration objects for the
//	DayCentIRC model.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski (tom.hilinski@colostate.edu) Feb 2005
//	History: See header file.
// ----------------------------------------------------------------------------

#include "INIDataToConfigDCIRC.h"
using namespace nrel::dcirc;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	DoToConfig
//	Transfer INI data to Config data.
//	Return false if successful, else true if error.
bool INIDataToConfigDCIRC::DoToConfig ()
{
	bool error = false;

	TDayCentIRCConfig & myConfig =
		dynamic_cast<TDayCentIRCConfig &>(config);
	TINIDataDCIRC const & myINI =
		dynamic_cast<TINIDataDCIRC const &>(iniData);

	myConfig.SetLogFileName ( myINI.GetLogFileName() );
	myConfig.SetOutputVariablesConfig ( myINI.GetOutputVariablesConfig() );
	myConfig.SetDisturbFileNameMap ( myINI.GetDisturbFileNameMap() );
	myConfig.SetCohortAgConfig (
		myINI.GetMinCohortAgeToCombine(),
		myINI.GetCATSI(),
		myINI.GetCohortVariationFraction() );

	// Datasets
	myConfig.SetWeatherINIFile ( myINI.GetWeatherINIFileName() );
	myConfig.SetSoilSource (
		myINI.GetSoilSource(),
		myINI.GetSoilSourceFileName() );

	return error;
}

//--- end of definitions for INIDataToConfigDCIRC ---

