// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  CMIAppMain.cpp
//
//	Description:
//	AppMain for use with CMI.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Oct2003
//	History:
//	* Extracted from TCMIApp.cpp
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	global variables
// ----------------------------------------------------------------------------

#include "externals.h"
#include "versionCMI.h"
#include "TCentury.h"
#include <v/vutil.h>

//--- GUI:
TCMIApp myApp (CMIName);			// vApp class

//--- Application Data:
std::auto_ptr<TCenturyConfig> centuryConfig;	// Century model configuration
std::auto_ptr<TCentury> century;		// Century model instance
TUserPref userPref;				// user preferences


int AppMain (int argc, char** argv)
{
	::myApp.CheckEvents ();	// fix for text canvas problem

	// get info on application startup
	char timeStr[21], dateStr[21];
	vGetLocalTime (timeStr);		// startup time
	vGetLocalDate (dateStr);		// startup date

	// Create the main window FIRST - so we can display messages
	myApp.historyWindow = (TTextCmdWindow*)::myApp.NewAppWin (
				NULL, "Session History", 0, 0, 0);
	myApp.messageWindow = (TTextCmdWindow*)::myApp.NewAppWin (
				NULL, "Messages", 0, 0, 0);
	if (!myApp.historyWindow || !myApp.messageWindow)
	{
		// cannot continue - no window can be created!
		// TO DO: #ifdef windows, MessageBox() #else cerr a message
		return -1;
	}

#if defined(_Windows) || defined(__WIN32__) || \
    defined(V_VersionWindows) || defined(V_VersionWin95)
	// activate the first window
	myApp.historyWindow->RaiseWindow ();
	// tile the windows vertically
	::SendMessage ( myApp.winClientHwnd(), WM_MDITILE,
			(WPARAM)(UINT)MDITILE_VERTICAL, 0 );
			//(WPARAM)(UINT)MDITILE_HORIZONTAL, 0 );
#endif

	// Initial history message
	HistText( CMINickname " " CMIVersionLong );
	HistText( CenturyName " " CenturyVersion );
	std::string msg;
	msg = "Session started at ";
	msg += timeStr;
	msg += " on ";
	msg += dateStr;
	msg += "\n";
	HistText ( msg.c_str() );

	if ( myApp.ConfigureCentury (argc, argv) )
	{
		HistText ("Century configuration failed.");
	}

	return 0;
}

//--- end of file ---
