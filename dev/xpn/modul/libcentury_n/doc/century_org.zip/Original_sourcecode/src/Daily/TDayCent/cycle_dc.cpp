// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  cycle_dc.cpp
//	Class:	  TDayCent
//	Function: InitDailyCycle
//
//	Description:
//	Determine relative water content, available water, and
//	decomposition factor related to temperature and water.
//	Initialize mineralization accumulators.
//	Compute potential production.
// ----------------------------------------------------------------------------
//	History:
//      See Century/cycle.cpp
//      Apr01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Changed name from InitMonthlyCycle to InitDailyCycle
//      * Made this function a TDayCent function, formerly a TCentury function
//      May01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Added IsTimeFor____() function calls
//      * Replaced soil temperature calculations and soil water model
//      * Renamed ProductionPotential() to CropGrassPotProd()
//      * Replaced SoilWaterLoss() from monthly model with ComputeSoilWaterFluxes()
//      * wt.evap, wt.irract, wt.rain, wt.pet, wt.tran, wt.stream[*] are
//        now monthly accumulators
//      Jul01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Added maintenace respiration calculations.
//      Nov01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Consolidated monthly initializations in ResetMonthlyValues()
//      Jan02 Melannie Hartman, melannie@nrel.colostate.edu
//      * Updated to keep consistent with TCentury::InitMonthlyCycle()
//      * Replaced biomass calculation with a call to GetBiomass()
//	Jul02	Tom Hilinski
//	* Moved start of month calcs into InitMonthlyCycle
//	* GetBiomass was called at the start of every month, and again every
//	  day, w/no change in dependent values between the calls.
//	  Now only does it here if not 1st day of month.
//      Aug02   Melannie Hartman, melannie@nrel.colostate.edu
//      * Replaced nps mineralization members with dnps members
//      Aug02   Melannie Hartman, melannie@nrel.colostate.edu
//      * Replaced nps mineralization members with dnps members
//      * Replaced co2 heterotrophic respiration members with dco2 members
// ----------------------------------------------------------------------------
//      Notes:
//      * ignore fixed.idef value or use it? -mdh 5/16/01
//      * make sure calculation of ratioH2OtoPET makes sense for daily timestep!
//        -mdh 1/8/02
// ----------------------------------------------------------------------------

#include "TDayCent.h"
#include "precision.h"

void TDayCent::InitDailyCycle (
	float & prodMonthFraction,	// fraction of month over which
					// current production event occurs (0-1)
	float & wfunc,		// water effect upon decomposition
	float & prodTempMean)	// mean air temp over production period (deg C)
{
    int const daysInMonth = calendarTools.DaysInMonth (st->month, st->year);

    dnps.nfix = 0.0f;     // -mdh 1/15/02 - This is a "weekly" amount.

    // Initialize daily co2 accumlators (moved from simsom)
    for (short i = 0; i < ISOS; ++i)    // for each isotope...
    {
	dco2.st1c2[i] = dco2.st2c2[i] = dco2.mt1c2[i] = dco2.mt2c2[i] =
	dco2.s11c2[i] = dco2.s21c2[i] = dco2.s2c2[i] = dco2.s3c2[i] =
	dco2.wd1c2[i] = dco2.wd2c2[i] = dco2.wd3c2[i] =
	0.0f;
    }

    //--- Initialize production accumulators
    // For crops, annual accumulation starts at the month of planting.
    // For grasses and forest, annual accumulation starts at the beginning of
    // the growing season.
    if ( sched->DoingStartCropGrassGrowth() ||
	 sched->DoingPlanting() ||
	 sched->DoingStartTreeGrowth() ||
	 st->dayOfYear == 1 )
	InitAnnualProdAccum ();

    //--- Initialize weather and water
    if ( !SimMicrocosm() )
    {
	dwt.tave = weather->MeanDailyTemp (st->dayOfYear);	// Avg air temp at 2m
	dwt.precip = weather->DlyPrecip (st->dayOfYear);
	wt.rain += dwt.precip;
	dwt.pet = weather->DailyPET ( weather->DlyTempMin (st->dayOfYear),
				weather->DlyTempMax (st->dayOfYear),
				siteEnv.GetLatitude (), fixed.fwloss[3]);
	wt.pet += dwt.pet;
	// If irrigating, determine actual amount of irrigation, irract
	if ( sched->DoingIrrigation() &&
	     IsTimeForIrrigation(st->dayOfYear, st->year) )
	{
	    Assert (st->dayOfYear - 6 > 0);
	    // Assume irrigation period is the previous week
	    float pet = weather->DailyPETSum (st->dayOfYear-6, st->dayOfYear,
		siteEnv.GetLatitude(), fixed.fwloss[3]);
	    float tave = weather->DailyTempMeanAvg (
					st->dayOfYear-6, st->dayOfYear);
	    float precip = weather->DailyPrecipSum (
					st->dayOfYear-6, st->dayOfYear);

	    // dwt.irract is only an estimate of irrigation in the upcoming
	    // period since irrigation and production may not occur on strictly
	    // overlapping periods. At time when this was implemented, prodcution
	    // and irrigation occurred about every 7 days. -mdh 5/07/01
	    dwt.irract = Irrigate (tave, pet, precip);
	    wt.irract += dwt.irract;    // accumulate irrigation over month
	    wt.irrtot += dwt.irract;	// accumulate irrigation over simulation
	}
	else
	{
	    dwt.irract = 0.0f;
	}
    }
    else	// simulating a microcosm
    {
	//wt.pet = 15.0f; // constant temp and soil moisture, monthly value (cm)
	dwt.pet = 0.5f;   // constant temp and soil moisture, daily value (cm)
   }

    // Ratio of total available water to PET
    Assert (dwt.pet >= 0.0f);
    // Adjust ratioH2OtoPET for daily timestep by multiplying daily water fluxes
    // by the number of days in the month. -mdh 1/14/02
    float const ratioH2OtoPET =
	( wt.avh2o[2] + (dwt.precip + dwt.irract) * daysInMonth ) /
	( dwt.pet * daysInMonth );

    //--- If the system has a microcosm, skip the rest of the routine
    if ( SimMicrocosm() )
    {
	dwt.anerb = AnaerobicImpact (ratioH2OtoPET);
	if ( sched->DoingCultivation() &&
		IsTimeForCultivation(st->dayOfYear, st->year) )
	    for (short i = 0; i < 4; ++i)
		soilC.cltfac[i] = parcp.clteff[i];
	else
	    for (short i = 0; i < 4; ++i)
		soilC.cltfac[i] = 1.0f;
	return;
    }

    // If planting or growing month, calculate growing season precipitation
    if ( sched->DoingPlanting() || sched->DoingStartCropGrassGrowth() )
	parcp.grwprc = weather->GrowingSeasonPrecip (st->month);

    //--- Initialize DAILY mineralization accumulators for each element.
    for (short element = 0; element < site.nelem; ++element)
    {
	// to do: make these monthly variables again
	for ( short layer = SRFC; layer <= SOIL; ++layer )
	{
	    strmnr_ref (layer, element) = 0.0f;
	    metmnr_ref (layer, element) = 0.0f;
	    s1mnr_ref (layer, element) = 0.0f;
	}
	nps.s2mnr[element] =  nps.s3mnr[element] = 0.0f;
	//nps.gromin[element] = 0.0f;  // See ResetMonthlyValues()
	nps.w1mnr[element] =  nps.w2mnr[element] =  nps.w3mnr[element] = 0.0f;
    }

    //--- biomass
    if ( !calendarTools.IsStartOfMonth (st->dayOfYear, st->year) )
    {
	// This is calc'd on the 1st day each month,
	// so only do it here on subsequent days.
	GetBiomass();
    }

    //--- submodel: soil temperature
    //--- Calculate soil temperatures at and below the surface

    if ( !SimMicrocosm() )
    {
	float srfcTempAvg = dwt.stemp;
	soil->CalcSoilTemperatures (
	     st->dayOfYear,
	     dailyBiomass.biomass,
	     weather->DlyTempMin (st->dayOfYear),
	     weather->DlyTempMax (st->dayOfYear),
	     DayLength (st->dayOfYear, siteEnv.GetLatitude() ),
	     wt.snow,
	     fixed.pmntmp,
	     fixed.pmxtmp,
	     fixed.pmxbio,
	     srfcTempAvg);
//	if ( !::WithinNumericLimits<float> (srfcTempAvg) )
//	{
//	        Assert ( ::WithinNumericLimits<float> (srfcTempAvg) );
//		// To Do: handle this error
//	}
	dwt.stemp = srfcTempAvg;
    }

    if ( IsTimeForProduction(st->dayOfYear, st->year) )
    {
	//--- Potential Production
	// Determine potential production if it's during the growth season.
	float potentialProduction = 0.0f;	// potential production
	float canopyCover = 0.0f;		// canopy cover

	// Potential production calculations are based on the
	// next (not past) "ProductionPeriod" days, or until end of month,
	// whatever is shorter.  The current day is included in the
	// production period. -mdh 5/07/01
	int dayOfMonth = calendarTools.DayOfMonth (st->dayOfYear, st->year);
	int firstProdDay = st->dayOfYear;
	int lastProdDay;
	if ( dayOfMonth + ProductionPeriod - 1 <= daysInMonth )
	{
	    // a full production period
	    prodMonthFraction = (float)ProductionPeriod / (float)daysInMonth;
	    lastProdDay = st->dayOfYear + ProductionPeriod - 1;
	}
	else
	{
	    // a partial production period
	    prodMonthFraction =
		(float)(daysInMonth - dayOfMonth + 1) / (float)daysInMonth;
	    lastProdDay = calendarTools.EndOfMonth ( st->month, st->year );
	}

	float const prodPrecip =
		weather->DailyPrecipSum(firstProdDay, lastProdDay);
	float const prodTempMin =
		weather->DailyTempMinAvg(firstProdDay, lastProdDay);
	float const prodTempMax =
		weather->DailyTempMaxAvg(firstProdDay, lastProdDay);
	float const prodPET =
		weather->DailyPETSum (
			firstProdDay, lastProdDay,
			siteEnv.GetLatitude(), fixed.fwloss[3]);

	//  mean temperature during production period
	prodTempMean = weather->DailyTempMeanAvg (firstProdDay, lastProdDay);

	// Uses the current month's soil temperature (AKM).
	// Determine potential production if it's during the growth season.

	// 1. For a savana system...
	if (sysType.IsSavanna())	// Added below for savanna model (rm)
	{
	    // wood biomass = (forestC.fbrchc + forestC.rlwodc) * 2.0
	    param.trbasl =
		(forestC.fbrchc + forestC.rlwodc) * 2.0f / parfs.basfct;
	    if (param.trbasl == 0.0f)
		param.trbasl = 0.1f;
	    canopyCover = 1.0f - std::exp (param.trbasl * -0.064f);
	}
	// 2. For a Crop System...
	if ( parcp.IsGrowing() )
	{
	    potentialProduction = CropGrassProductionPotential (
		canopyCover, prodPrecip, prodTempMin, prodTempMax, prodPET,
		prodMonthFraction, dwt.stemp);
	}
	if ( sysType.IsCropGrass() )
	{
	    // dailyBiomass.agLiveBiomass += potentialProduction * 0.25f * 2.5f;
	    dailyBiomass.agLiveBiomass += potentialProduction * 0.625f;
	}
	// 3. For a Forest System...
	if ( parfs.IsGrowing() )
	{
	    ForestProductionPotential (prodPrecip, prodTempMin, prodTempMax,
		prodPET, prodMonthFraction, dwt.stemp);
	}
    }
    else
    {
	// Anything else to do if no production this day? -mdh 1/14/01
	prodMonthFraction = 0.0f;
    }

    //--- submodel: soil water
    if ( !SimMicrocosm() )
    {
	float soilEvap = 0.0f;
	float soilTransp = 0.0f;
	float outflow = 0.0f;
	float sublimation = 0.0f;

	// Compute soil water fluxes including soil water evaporation,
	// inflitration, soil water drainage, outflow, and transpiration.
	// Compute snow accumulation, melt, and sublimation. -mdh 5/12/01

	ComputeSoilWaterFluxes (st->dayOfYear, st->month, dwt.pet,
		dailyBiomass.agLiveBiomass,
		dailyBiomass.surfaceLitterBiomass,
		dailyBiomass.standDeadBiomass,
		dwt.irract,
		// the values of these arguments are updated
		wt.snow, wt.snlq, soilEvap, soilTransp, outflow,
		dwt.runoff, sublimation);

	// Set daily output values
	dwt.evap = soilEvap;
	dwt.tran = soilTransp;
	dwt.stream[0] = outflow;
	dwt.sublim = sublimation;

	// The following are monthly accumulators
	wt.evap += soilEvap;
	wt.tran += soilTransp;
	wt.stream[0] += outflow;
	wt.runoff += dwt.runoff;

	// This call was in h2olos.cpp -mdh 5/09/01
	UpdateWaterVariables ();
    }

    //--- Decomposition effects
    // water, temperature, impact of anerobic conditions on decomposition
    wfunc = WaterEffectOnDecomp (
			soil->GetSoilTextureIndex (),
			soil->WtdMeanWFPS(wt.simDepth),
			ratioH2OtoPET,
			fixed.idef );
    dwt.wfunc = wfunc;
    dwt.tfunc = TempEffectOnDecomp (dwt.stemp);
    dwt.anerb = AnaerobicImpact (ratioH2OtoPET);
    // Combined effects of temperature and moisture
    // Bound defac to >= 0.0   12/21/92
    if ( sysType.IsCropGrass() )
    {
	// debugging - daycent defac is 2 x monthly defac for c3grs, so reduce
	dwt.defac = std::max ( 0.4f * dwt.tfunc * dwt.wfunc, 0.0f );
	//dwt.defac = std::max ( dwt.tfunc * dwt.wfunc, 0.0f );
    }
    else // forest or savanna
    {
	// To do: examine defac values for trees
	// meanwhile, keep original equation.
	dwt.defac = std::max ( dwt.tfunc * dwt.wfunc, 0.0f );
    }
    comput.defacm[st->month - 1] += dwt.defac;

    // Effect of cultivation on decomposition (used in decomp routine)
    // vk 03-13-91
    // cltfac is this month's effect of cultivation on decomposition
    // of som1, som2, som3, and structural.  It is set to clteff
    // in months when cultivation occurs; otherwise it equals 1.
    // clteff is the effect of cultivation on decomposition read from
    // the cult.100 file
    if ( sched->DoingCultivation() &&
	 IsTimeForCultivation(st->dayOfYear, st->year) )
	for (short i = 0; i < 4; ++i)
	    soilC.cltfac[i] = parcp.clteff[i];
    else
	for (short i = 0; i < 4; ++i)
	    soilC.cltfac[i] = 1.0f;

    //--- Compute daylength for use in phenology of trees
    //siteEnv.GetDayLength (st->month);
    SetDayLengthParams ( st->dayOfYear, siteEnv.GetLatitude() );

    // Monthly Averages - sum now, and average at end of month
    wt.anerb += dwt.anerb;
    wt.defac += dwt.defac;
    wt.stemp += dwt.stemp;
    if ( calendarTools.IsEndOfMonth (st->dayOfYear, st->year) )
    {
	float const recipDaysInMonth = 1.0f / (float)daysInMonth;
	wt.anerb *= recipDaysInMonth;
	wt.defac *= recipDaysInMonth;
	wt.stemp *= recipDaysInMonth;
	comput.defacm[st->month - 1] *= recipDaysInMonth;
    }
    for (short element = 0; element < NUMELEM; element++)    // -mdh 8/31/02
       dnps.fertot[element] = 0.0f;
}

//--- end of file ---
