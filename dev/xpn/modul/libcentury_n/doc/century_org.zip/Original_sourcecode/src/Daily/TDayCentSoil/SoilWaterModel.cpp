// ----------------------------------------------------------------------------
//	Copyright 1999-2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model, daily version
//	File:     SoilWaterModel.cpp
//	Class:    SoilWaterModel
//
//	Description:
//	Class for a soil water model.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec99
//		Melannie Hartman, melannie@nrel.colostate.edu (DayCent updates)
//	History: See header file.
// ----------------------------------------------------------------------------
//	Notes:
//	Extracted from class SoilWaterModel. Tom Hilinski, Nov2004.
// ----------------------------------------------------------------------------

#include "SoilWaterModel.h"
#include <cmath>
#include "AssertEx.h"

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

float const SoilWaterModel::PARTDENS = 2.65f;	// Particle Density (g/cm-3)
float const SoilWaterModel::BAR2CM = 1024.0f;		// 1 bar = 1024 cm H2O
float const SoilWaterModel::CM2BAR = 1.0f / BAR2CM; 	// 1024 cm = 1 bar H2O
float const SoilWaterModel::minimumWaterPotentialBars = 80.0f;	// bars
float const SoilWaterModel::minimumTheta = 1.0e-6;		// cm soil H2O

// soil temperature at which a layer is considered frozen (deg C)
float const SoilWaterModel::frozenSoilTemp = -1.0f;

// max pore space to freeze
float const SoilWaterModel::maximumFrozenPoreSpace = 0.13f;

// min. hydraulic conductivity in frozen soil (cm/sec)
float const SoilWaterModel::MIN_FRZN_COND = 0.00005f;

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	------------------------------------------------------------------
//	HydraulicConductivity
//	Returns unsaturated hydraulic conductivity (cm/sec).
//
//    Reference: Campbell , G.S., 1974.  A simple method for determining
//    unsaturated hydraulic conductivity from soil moisture retention data.
//    Soil Sci., 117: 311-314.
//
//    Notes:
//    * This function returns Kw values way too small in magnitude.
//      Check reference for more detail on implementation.
//
//    Author: Melannie Hartman, melannie@NREL.colostate.edu 13Sep2001.
float SoilWaterModel::HydraulicConductivity (
	float  const Ksat, 	// saturated hydraulic cond. (cm/sec)
	double const theta,	// volumetric soilwater content (frac)
	double const thetaSat,	// saturated H2O content (vol. frac)
	float  const soilTavg)	// average soil temperature (deg C)
{
	float Kw = 0.0f;     // unsaturated hydraulic conductivity (cm/sec)
	if ( CheckForImpedence ( soilTavg, (thetaSat - theta) ) )
	{
		// water in the soil will freeze and
		// reduce hydraulic conductivity
		Kw = MIN_FRZN_COND;
	}
	else
	{
		// old:    S = (theta - 0.10)/(thetaSat - 0.10);
		float const S =
		  static_cast<float>(
		  	(theta - 0.03) / (thetaSat - 0.03) );

		if (S > 0.0f)
			Kw = Ksat * std::pow(S, 0.35f);
	}
	return Kw;
}

//	------------------------------------------------------------------
//	HydraulicConductivity
//	Returns unsaturated hydraulic conductivity (cm/sec).
//
//    Author: Melannie Hartman
float SoilWaterModel::HydraulicConductivity (
	float  const kSat,	// saturated hydraulic cond. (cm/sec)
	double const theta,	// volumetric H2O content (frac)
	double const thetaSat,	// saturated vol. H2O content (frac)
	float  const soilTavg,	// average soil temperature (deg C)
	float  const b)		// slope of retention curve (Clapp & Hornberger)
{
	float Kw;     // unsaturated hydraulic conductivity (cm/sec)
	if ( CheckForImpedence ( soilTavg, (thetaSat - theta) ) )
	{
		// water in the soil will freeze and
		// reduce hydraulic conductivity
		Kw = MIN_FRZN_COND;
	}
	else
	{
		Kw = kSat * static_cast<float>(
			std::pow( (theta / thetaSat), (2.0 * b + 3.0) ) );
	}
	return Kw;
}

//	------------------------------------------------------------------
//	SoilWaterPotential
//	Returns the soil water potential of a soil layer, given
//	its soilwater content (bars > 0).
//
//	(This is complementary to the function swfunc).
//
//	The equation and its coefficients are based on a
//	paper by Cosby, Hornberger, Clapp, Ginn, in WATER RESOURCES RESEARCH
//	June 1984.  Moisture retention data was fit to the power function.
//	  soil water potential = psiSat*(theta/thetaSat)**(-b)
//	See the routine "watreqn" for a description of how the variables
//	psiSat, b, and thetaSat are initialized.
//
//	Author: Susan Chaffee (original FORTRAN version of Soil Water Model)
//	        Melannie Hartman, Tom Hilinski
float SoilWaterModel::SoilWaterPotential (
	double const theta,	// soil water content (volumetric fraction)
	double const thetaSat,	// saturated water content (volumetric fraction)
	double const psiSat,	// "saturation" matric potential (cm H2O)
	double const b)		// see equation in comment header
{
	Assert (theta >= 0.0);
	Assert (theta <= 1.0);
	Assert (thetaSat > 0.0);
	Assert (thetaSat <= 1.0);

	float potential = minimumWaterPotentialBars;		// return value
	if ( theta > minimumTheta )
	{
		// minimum water potential = -80 bars
		double const base = theta / thetaSat;
		potential = static_cast<float>(
				psiSat / std::pow (base, b) * CM2BAR );
		potential = std::min (potential, minimumWaterPotentialBars);
	}
	return potential;
}

//	------------------------------------------------------------------
//	WaterEquation
//
//    Compute parameters to be used in equations to compute water content
//    or matric potential based on the regression equations by
//    Cosby, Hornberger, Clapp, Ginn (see WATER RESOURCES RESEARCH,
//    Vol.20,No.6, pp.682-690, June 1984). These are a set of regression
//    equations based on soil texture composition as a function of water
//    content and matric potential.
//
//    The regression equation can be used to compute either soilwater content:
//      soilwater content=(thetaSat*100*(psis/(bars*BAR2CM))**b) ????
//      (see swfunc.c)
//
//    or can be used to compute matric potential in bars:
//      matric potential = (psis/(theta/thetaSat)**b)/BAR2CM
//      (see swpotentl.cpp)
//
//      where:  BAR2CM = 1024 cm water per bar
//              bars   = matric potential at which to compute soilwater
//              theta = volumetric soilwater content.
//
//    Author: Susan Chaffee (original FORTRAN version of Soil Water Model),
//            Melannie Hartman
void SoilWaterModel::WaterEquation (
	TSoilProperty const & sand,	// sand fraction
	TSoilProperty const & clay,	// clay fraction
	T1DDoubleArray & thetaSat,	// saturated volumetric water content
	T1DDoubleArray & psiSat,	// saturation matric potential (cm H2O)
	T1DDoubleArray & b)		// slope of the retention curve
{
    double const tolerance = 1.0e-5;

    // Note: once sand and clay use the same containers as the others,
    // we may be able to use array syntax here.

    TSoilProperty::TFloatArray::const_iterator
	iSand     = sand.Values().begin (),
	iClay     = clay.Values().begin ();
    T1DDoubleArray::iterator
	iThetaSat = thetaSat.begin (),
    	iPsiSat   = psiSat.begin (),
    	iB        = b.begin ();

    for ( ;
	  iB != b.end();
	  ++iSand, ++iClay, ++iThetaSat, ++iPsiSat, ++iB )
    {
	double const theSand = *iSand;
    	double const theClay = *iClay;

	*iThetaSat = ThetaAtSaturation (theSand, theClay);
	Assert (*iThetaSat >= 0.0);
	Assert (*iThetaSat <= 1.0);
	//*iThetaSat = std::max (*iThetaSat, 0.0);
	//*iThetaSat = std::min (*iThetaSat, 1.0);

	*iPsiSat = std::pow (10.0, (-1.58 * theSand - 0.63 * theClay + 2.17) );

	*iB = -0.3 * theSand + 15.7 * theClay + 3.10;
	Assert (*iB > tolerance);
	//*iB = std::max (*iB, tolerance);
    }
}

//	------------------------------------------------------------------
//	DrainToFieldCapacity
//
//	Infilitrate water into soil layers under high water conditions
//	Resulting soilwater content of any layer will be <= its field capacity
//
//	Author - hwdrain.c: Melannie Hartman, Bill Parton 7/16/96
//
//	To do: add water table effect? from DayCent4.5
void SoilWaterModel::DrainToFieldCapacity (
	T1DDoubleArray const &
		swcFieldCapacity,	// swc at field capacity (cm H2O)
	T1DDoubleArray & swc,		// soilwater content (cm H2O)
	T1DFloatArray & amtTrans,	// Amount transfered between layers (cm)
	double & drainageOut)		// drainage from soil profile bottom
{
    double drainage = 0.0;		// drainage into next layer (cm)
    short const bottomLayer = swc.size() - 1;
    for(short layer = 0; layer < swc.size(); layer++)
    {
    	drainage = swc(layer) - swcFieldCapacity(layer);
	if ( drainage > 0.0 )				// excess water?
        {
	    // flow excess water into the next layer below
            if ( layer < bottomLayer )			// not at bottom layer?
		swc(layer + 1) += drainage;		// ...flow
	    swc(layer) = swcFieldCapacity(layer);	// new water content
	    amtTrans(layer) += drainage;		// accumulate flow
        }
	else
	    drainage = 0.0;
    }
    drainageOut = drainage;				// below soil
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------



// --- end of SoilWaterModel.cpp ---
