// ----------------------------------------------------------------------------
//	Copyright 2002, 2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  WriteMonthlyCentWthrFile.cpp
//	Class:	  WriteMonthlyCentWthrFile
//
//	Description:
//	Writes a Century monthly weather file from the data arrays specified.
//---------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May2005 (C++ driver)
//		Cindy Keough, 2002, file read, and statistical functions.
//	History: See header file.
// ----------------------------------------------------------------------------

#include "WriteMonthlyCentWthrFile.h"
using namespace nrel::util;
#include <fstream>

char const * const headerStr =
	"# var year    jan    feb    mar    apr    may    jun "
	"   jul    aug    sep    oct    nov    dec\n"
	"# --- ---- ------ ------ ------ ------ ------ ------ "
	"------ ------ ------ ------ ------ ------";


bool WriteMonthlyCentWthrFile::ErrorChecks (
	std::string const & fileName,		// output file name
	TInterval<long> const yearRange,	// year range of the data
	T2DFloatArray const & precip,		// precip mean monthly
	T2DFloatArray const & tempMin,		// temp. minimum mean monthly
	T2DFloatArray const & tempMax)		// temp. maximum mean monthly
{
	if ( fileName.empty() )
	{
		errorMsg += "Error: File name was not specified for the "
			    "monthly weather data.\n";
		return true;
	}
	if ( !yearRange.IsValid() )
	{
		errorMsg += "Error: Invalid range of years.\n";
		return true;
	}
	if ( precip.size().first == 0 )
	{
		errorMsg += "Error: Precipition data was not supplied.\n";
		return true;
	}
	if ( tempMin.size().first == 0 )
	{
		errorMsg += "Error: "
			    "Minimum temperature data was not supplied.\n";
		return true;
	}
	if ( tempMax.size().first == 0 )
	{
		errorMsg += "Error: "
			    "Maximum temperature data was not supplied.\n";
		return true;
	}
	return false;
}

void WriteMonthlyCentWthrFile::WriteData (
	std::string const & fileName,		// output file name
	TInterval<long> const yearRange,	// year range of the data
	T2DFloatArray const & precip,		// precip mean monthly
	T2DFloatArray const & tempMin,		// temp. minimum mean monthly
	T2DFloatArray const & tempMax,		// temp. maximum mean monthly
	std::string const & headerStr)
{
	if ( ErrorChecks ( fileName, yearRange, precip, tempMin, tempMax ) )
		return;

	std::ofstream fs (fileName.c_str(), std::ios::out | std::ios::trunc );
	if ( !fs.good() || !fs.is_open() )
	{
		errorMsg += "Error: "
			    "Unable to open the monthly data file.\n";
		return;
	}

	fs << headerStr << std::endl;
	WriteHeaders (fs);

	long year = yearRange.GetLower();
	T1DFloatArray::const_iterator iPrecip = precip.begin();
	T1DFloatArray::const_iterator iTempMin = tempMin.begin();
	T1DFloatArray::const_iterator iTempMax = tempMax.begin();
	while ( iPrecip != precip.end() )
	{
		WriteRecord (fs, year, iPrecip, iTempMin, iTempMax);
		++year;
		iPrecip = iPrecip + 12;
		iTempMin = iTempMin + 12;
		iTempMax = iTempMax + 12;
	}
	
}

void WriteMonthlyCentWthrFile::WriteHeaders (
	std::ofstream & fs)
{
	// to do: header info "about"
	fs << headerStr << '\n';
}

void WriteMonthlyCentWthrFile::WriteRecord (
	std::ofstream & fs,
	long const year,
	T2DFloatArray::const_iterator iPrecip,
	T2DFloatArray::const_iterator iTempMin,
	T2DFloatArray::const_iterator iTempMax)
{
	fs << "prec  " << std::setw(4) << year;
	for ( short i = 0; i < 12; ++i, ++iPrecip)
		fs << " "
		   << std::setw(6) << std::fixed
		   << std::setprecision(2) << std::showpoint
		   << *iPrecip;
	fs << std::endl;

	fs << "tmin  " << std::setw(4) << year;
	for ( short i = 0; i < 12; ++i, ++iTempMin)
		fs << " "
		   << std::setw(6) << std::fixed
		   << std::setprecision(2) << std::showpoint
		   << *iTempMin;
	fs << std::endl;

	fs << "tmax  " << std::setw(4) << year;
	for ( short i = 0; i < 12; ++i, ++iTempMax)
		fs << " "
		   << std::setw(6) << std::fixed
		   << std::setprecision(2) << std::showpoint
		   << *iTempMax;
	fs << std::endl;
}


//--- end of definitions for WriteMonthlyCentWthrFile ---

