#ifndef INC_nrel_dcirc_TDayCentIRCConfig_h
#define INC_nrel_dcirc_TDayCentIRCConfig_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  TDayCentIRCConfig.h
//	Class:	  TDayCentIRCConfig
//
//	Description:
//	Specifies the information needed to configure an DayCentIRC simulation.
//
//	Responsibilities:
//	* Provide additional configuration information specific to a DayCentIRC
//	  simulation.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, May 2003
//	History:
//	Oct03	Tom Hilinski
//	* Add elements to hold the list of file names
//	  for scheduled disturbance events.
//	Jul04	Tom Hilinski
//	* Moved CFOTSI members to base class.
// ----------------------------------------------------------------------------

#include "TGCFConfiguration.h"
#include "DayCentIRCTypes.h"

using ::nrel::gcf::TGeographyList;
using ::nrel::gcf::TLandElemListList;

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {


class TDayCentIRCConfig
	: public ::nrel::gcf::TGCFConfiguration
{
  public:
	//---- types

	//---- constructors and destructor
	TDayCentIRCConfig (
	  std::string const & useModelName = "",
	  std::string const & useLastVersionRun = "",
	  std::string const & useDateLastRun = "",
	  std::string const & useUserName = "",
	  std::string const & useUserEmail = "" )
	  : ::nrel::gcf::TGCFConfiguration (
	  	useModelName, useLastVersionRun, useDateLastRun,
	  	useUserName, useUserEmail ),
	    soilSource (nrel::gcf::SoilSrc_Unknown)
	  {
	  }
	TDayCentIRCConfig (
						//--- Grid configuration
	  TGridDimensions const & useDimensions,// grid (x,y) dimensions
	  TGeographyList const & useGeography,	// geography of each cell
	  TLandElemListList const &
			useLandscapeLists,	// lists of landscape lists
						//--- Biomes and cohorts
	  TBiomeConfigList const & useBiomeList, // list of biomes
	  TCohortConfigCellList const &
			useCohortConfigList,	// list of cohort config's.
						//--- Simulation time
	  TTime const useStartTimeStep,		// start time step
	  TTime const useEndTimeStep,		// end time step
	  TRunMode const useRunMode,		// run mode
						//--- User output
	  std::string const & useLogFileName,	// log file name + path
	  TOutputVarConfig const & useOutVarConfig, // output variables config.
						//--- Cohort aggregation
	  ::TimeRange const & useCATSI,		// cohort ag. interval
	  TTime const useMinCohortAgeToCombine,	// minimum cohort age to combine
	  float const useCohortVarFraction,	// variation range of cohorts
						//--- Cohort disturbance
	  TFileNameIDMap const &
	  		useDisturbFileNameMap,	// disturbance file name map
	  float const useMinAreaFracDisturb,	// min. area fraction to disturb
	  TTime const useMinCohortAgeToDisturb,	// min. cohort age to disturb
	  					//--- Locations of things
	  std::string const & useExePath,	// executable directory
	  std::string const & useInputPath,	// simulation input directory
	  std::string const & useOutputPath,	// simulation output directory
	  					//--- Datasets
	  std::string const & useWeatherINIFile, // weather INI file name
	  TSoilSource const useSoilSourceType,	 // soil source type
	  std::string const & useSoilSourceFile, // soil file name
	  					//--- Output timestep intervals
	  ::TimeRange const & useCFOTSI =	// cell output interval
		::TimeRange (),
	  ::TimeRange const & useGFOTSI =	// grid output interval
	  	::TimeRange (),
	  ::TimeRange const & useSFOTSI =	// simulation output interval
	  	::TimeRange (),
	  std::string const & useModelName = "",
	  std::string const & useLastVersionRun = "",
	  std::string const & useDateLastRun = "",
	  std::string const & useUserName = "",
	  std::string const & useUserEmail = "" )

	  : ::nrel::gcf::TGCFConfiguration (
		useDimensions,
		useGeography,
		useLandscapeLists,
		useBiomeList,
		useCohortConfigList,
		useStartTimeStep,
		useEndTimeStep,
		useRunMode,
		useMinCohortAgeToCombine,
		useMinAreaFracDisturb,
		useMinCohortAgeToDisturb,
		useExePath, useInputPath, useOutputPath,
		useCFOTSI, useGFOTSI, useSFOTSI,
		useModelName, useLastVersionRun, useDateLastRun,
		useUserName, useUserEmail ),
	    logFileName (useLogFileName),
	    outVarConfig (useOutVarConfig),
	    catsi (useCATSI),
	    cohortVariationFraction (useCohortVarFraction),
	    disturbFileNameMap (useDisturbFileNameMap),
	    weatherINIFile (useWeatherINIFile),
	    soilSource (useSoilSourceType),
	    soilSourceFile (useSoilSourceFile)
	  {
	  }
	TDayCentIRCConfig (
	  TDayCentIRCConfig const & object)
	  : ::nrel::gcf::TGCFConfiguration (object)
	  {
	    Copy (object);
	  }
	virtual ~TDayCentIRCConfig ()
	  {
	  }
	virtual TDayCentIRCConfig * const Clone () const	// Clone this
	  { return new TDayCentIRCConfig (*this); }

	//---- operator overloads
	TDayCentIRCConfig& operator= (
	  TDayCentIRCConfig const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
		::nrel::gcf::TGCFConfiguration::operator= (object);
		Copy (object);
	    }
	    return *this;
	  }
	bool operator== (
	  TDayCentIRCConfig const & object) const
	  {
	    if ( &object )
	    {
	      return
		::nrel::gcf::TGCFConfiguration::operator== (object) &&
		logFileName == object.logFileName &&
		outVarConfig == object.outVarConfig &&
		catsi == object.catsi &&
		cohortVariationFraction == object.cohortVariationFraction &&
		disturbFileNameMap == object.disturbFileNameMap &&
		weatherINIFile == object.weatherINIFile &&
		soilSource == object.soilSource &&
		soilSourceFile == object.soilSourceFile;
	    }
	    else
		return false;
	  }
	bool operator!= (
	  TDayCentIRCConfig const & object) const
	  {
	    return !(*this == object);
	  }

	//---- functions
	void SetLogFileName (
	  std::string const & useLogFileName)
	  { logFileName = useLogFileName; }
	void SetOutputVariablesConfig (
	  TOutputVarConfig const & useConfig)
	  { outVarConfig = useConfig; }
	void SetDisturbFileNameMap (
	  TFileNameIDMap const & useDisturbFileNameMap)
	  { disturbFileNameMap = useDisturbFileNameMap; }
	void SetCohortAgConfig (
	  TTime const useMinCohortAgeToCombine,	// minimum cohort age to combine
	  ::TimeRange const & useCATSI,	// cohort ag. interval
	  float const useCohortVarFraction)	// variation range of cohorts
	  {
	    ::nrel::gcf::TGCFConfiguration::SetCohortAgConfig (
	    	useMinCohortAgeToCombine);
	    catsi = useCATSI;
	    cohortVariationFraction = useCohortVarFraction;
	  }

	void SetWeatherINIFile (
	  std::string const & useWeatherINIFile)
	  { weatherINIFile = useWeatherINIFile; }

	// overloaded SetSoilSource in order to allow
	// precompiled headers (no data in header)
	void SetSoilSource (				// Soil Source
	  TSoilSource const useSource,			//   source type
	  std::string const & useFileName)		//   file name
	  {
	    soilSource = useSource;
	    soilSourceFile = useFileName;
	  }
	void SetSoilSource (				// Soil Source
	  TSoilSource const useSource)			//   source type
	  {
	    soilSource = useSource;
	    soilSourceFile.clear();
	  }

	void Clear ()					// "Clear" data members
	  {
	    ::nrel::gcf::TGCFConfiguration::Clear ();
	    logFileName.clear ();
	    outVarConfig.Reset ();
	    catsi.Clear ();
	    cohortVariationFraction = 0.0f;
	    disturbFileNameMap.clear ();
	    weatherINIFile.clear ();
	    soilSourceFile.clear ();
	  }

	//---- functions: Access
	std::string const & GetLogFileName () const	// log file name + path
	  { return logFileName; }
	TOutputVarConfig const & GetOutputVariablesConfig () const
	  { return outVarConfig; }
	// cohort aggregation timestep interval
	::TimeRange const & GetCATSI () const
	  { return catsi; }
	// variation range (+/-) of cohorts
	float GetCohortVariationFraction () const
	  { return cohortVariationFraction; }
	// disturbance file names indexed by cell ID
	TFileNameIDMap const & GetDisturbFileNameMap () const
	  { return disturbFileNameMap; }
	  						// Datasets
	std::string const & GetWeatherINIFileName () const
	  { return weatherINIFile; }
	TSoilSource GetSoilSource () const
	  { return soilSource; }
	std::string const & GetSoilSourceFileName () const
	  { return soilSourceFile; }

	//---- functions: Queries
	bool IsEmpty () const				// True if no data
	  {
	    return
		::nrel::gcf::TGCFConfiguration::IsEmpty() &&
		logFileName.empty() &&
		disturbFileNameMap.empty() &&
		catsi.IsEmpty() &&
		weatherINIFile.empty() &&
		soilSourceFile.empty();
	  }

  protected:
	//---- constants

	//---- configuration data
					//--- User output
	std::string logFileName;	// log file name + path
	TOutputVarConfig outVarConfig;	// output variables configuration
					//--- Cohort aggregation
	::TimeRange catsi;		// cohort aggregation timestep interval
	float cohortVariationFraction;	// variation range (+/-) of cohorts
					//--- Cohort disturbance
					// disturbance file names
					//   indexed by cell ID
	TFileNameIDMap disturbFileNameMap;
					//--- Datasets
	std::string weatherINIFile;	// weather INI file name
	TSoilSource soilSource;		// soil source type
	std::string soilSourceFile;	// soil file name

	//---- functions

  private:
	//---- constants

	//---- data

	//---- functions
	void Copy (TDayCentIRCConfig const & object)	// Copy to this
	  {
	    if ( &object )
	    {
		logFileName = object.logFileName;
		outVarConfig = object.outVarConfig;
		catsi = object.catsi;
		cohortVariationFraction = object.cohortVariationFraction;
		disturbFileNameMap = object.disturbFileNameMap;
		weatherINIFile = object.weatherINIFile;
		soilSource = object.soilSource;
		soilSourceFile = object.soilSourceFile;
	    }
	  }
};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_TDayCentIRCConfig_h
