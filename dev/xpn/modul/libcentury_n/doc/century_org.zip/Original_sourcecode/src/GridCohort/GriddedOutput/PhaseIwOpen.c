
/*              Copyright 1998 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "gridconst.h"
#include "netcdf.h"

/* Global Variables */
int PhaseINcid;
int P_precip_id, P_mintmp_id, P_maxtmp_id;

void handle_error(char *funcname, int status);

int
wopen(FILE *fp_init)
{
        int status;
	char line[MAXL+1];

	char phIname[FNAMEMAX];

	/* Get Names of VEMAP Phase I Climate File */
        fgets(line, MAXL, fp_init);
        fgets(line, MAXL, fp_init);
        sscanf(line, "%s", &phIname);

	/* Open files and get variable IDs */
	if ((status = nc_open(phIname, NC_NOWRITE, &PhaseINcid)) != NC_NOERR)
	{
	   printf("wopen: Unable to open file %s\n", phIname);
	   return 1;
	}

	status = nc_inq_varid(PhaseINcid, "ppt", &P_precip_id);
        if (status != NC_NOERR) handle_error("nc_inq_varid(ppt)", status);
	status = nc_inq_varid(PhaseINcid, "tn",  &P_mintmp_id);
        if (status != NC_NOERR) handle_error("nc_inq_varid(tn)", status);
	status = nc_inq_varid(PhaseINcid, "tx",  &P_maxtmp_id);
        if (status != NC_NOERR) handle_error("nc_inq_varid(tx)", status);

	return 0;
}
