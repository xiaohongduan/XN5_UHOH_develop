#ifndef INC_TFixed_h
#define INC_TFixed_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TFixed.h
//	Class:	  TFixed
//
//	Description:
//	Contains "fixed" model parameters.
//	Responsibilities:
//	* Initialize values.
//	* Check for bad values.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, July 2002
//	History:
//	May04	Tom Hilinski
//	* Add members LoadValues and CheckOptionSet. These replace
//	  TCenturyBase::fixin.cpp and TDayCent::fixin_dc.cpp.
//	  Also added a constructor that calls LoadValues.
// ----------------------------------------------------------------------------

#include "TSharedPtr.h"
#include "TEventOption.h"
#include "centconsts.h"

class TFixed
{
  public:
    TFixed ()
      {
      	Clear ();
      }
    TFixed (
      TSharedPtr<TEventOptionSet> optionSet)	// parameter fixed option set
      {
      	Clear ();
      	LoadValues (optionSet);
      }
    virtual ~TFixed ()
      {
      }
    virtual void Clear ();		// resets values to zero
    virtual bool Verify ();		// checks values for problems
    virtual bool LoadValues (		// load values from fixed option set
      TSharedPtr<TEventOptionSet> optionSet);
    bool CheckOptionSet (		// check the fixed option set
      TSharedPtr<TEventOptionSet> optionSet);

    //---- public data
    float
    	adep[MAXLYR], 	// default thicknesses of soil layers (cm)
    	agppa,  	//
    	agppb,  	//
    	aneref[3],  	// rain/PET anaerobic effect
			//   [0] max. impact, [1] min. impact, [2] min. impact
    	animpt,  	// anaerobic effect slope for for decomp.
    	awtl[MAXLYR],  	// root density factors for transpiration water loss
    	bgppa,  	//
    	bgppb, 		//
	co2ppm[2],  	//
	co2rmp,  	//
	damr[6],	// was [2][3]
	damrmn[3],  	//
	dec1[2],  	//
	dec2[2],  	//
	dec3[2],  	//
	dec4,  		//
	dec5,  		//
	deck5,  	//
	dligdf,  	//
	dresp,  	//
	edepth,  	// depth of surface layer which Century simulates (cm)
	elitst,  	//
	enrich,  	// Enrichment factor for SOM losses via erosion
	favail[6],  	//
	fleach[5],  	//
	fwloss[4],  	//
	fxmca,  	//
	fxmcb,  	//
	fxmxs,  	//
	fxnpb,  	//
	gremb;  	//
    short idef;		//
    float lhzf[3],  	// Fractions for initialization of lower layer.
    	minlch;  	//
    short nsnfix;	// Non-symbiotic N fixation flag:
    			//   1 = use N:P ratio
    			//   0 = use precip
    short ntspm;	// Number of time steps for decomp per sim. time step.
    float
    	omlech[3],  	//
    	p1co2a[2],   	//
    	p1co2b[2],   	//
    	p2co2,   	//
    	p3co2,   	//
    	pabres,   	//
    	pcemic[9],	// was [3][NUMELEM]; For elements N, P, S:
			//   pcemic(1,iel) = maximum C/E of new som1
			//   pcemic(2,iel) = minimum C/E of new som1
			//   pcemic(3,iel) = minimum E content of decomposing
			//     material that gives minimum C/E
	peftxa,   	//
	peftxb,   	//
	phesp[4],  	//
	pligst[2],  	// effect of lignin-to-structural-ratio on
			//   structural decomposition
	pmco2[2],  	//
	pmnsec[3],  	//
	pmntmp,  	//
	pmxbio,  	//
	pmxtmp,  	//
	pparmn[3],  	//
	pprpts[3],  	// [0] = minimum ratio available water:PET which
			//   would completely limit production assuming wc=0.
			// [1] = The effect of wc on the intercept, allows the
			//   user to increase the value of the intercept and
			//   thereby increase the slope of the line.
			// [2] = Lowest ratio available water:PET at which
			//   there is no restriction on production.
	ps1co2[2],  	//
	ps1s3[2],  	//
	ps2s3[2],  	//
	psecmn[3],  	//
	psecoc,  	//
	rad1p[9],	// was [3][NUMELEM]
	rcestr[3],  	//
	rictrl,  	//
	riint,  	//
	rsplig,  	//
	spl[2],  	//
	strmax[2],  	//
	texepp[5],  	//
	texesp[3],  	//
	teff[3],  	//
	tmelt[2],  	//
	varat1[9],	// was [3][NUMELEM]
	varat2[9],	// was [3][NUMELEM]
	varat3[9],	// was [3][NUMELEM]
	vlosse,   	// volatized N fraction lost per year
	vlossg;  	// volatized fraction of gross N mineralization flux
};

#endif // INC_TFixed_h
