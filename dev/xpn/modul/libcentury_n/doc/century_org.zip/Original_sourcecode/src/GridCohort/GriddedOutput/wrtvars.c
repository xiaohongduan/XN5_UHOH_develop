
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include "netcdf.h"
#include "wrtcdf.h"

void
wrtvars_(float fl_out[], int int_out[], int *no_of_flts, 
	 int *no_of_ints)
{
	static size_t	vstart[2]={0, 0};
	size_t 		vcount[2]={1, 1};
	int             status;


	vcount[1] = (size_t) *no_of_flts;
	status = nc_put_vara_float(site_ncid, fltvar_id, vstart, vcount, fl_out);

	vcount[1] = (size_t) *no_of_ints;
	status = nc_put_vara_int(site_ncid, intvar_id, vstart, vcount, int_out);

	vstart[0] = vstart[0] + 1;
	return;
}
