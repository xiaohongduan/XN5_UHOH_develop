// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model (Monthly)
//	File:	  TMCSoilFlows.cpp
//	Class:	  TMCSoilFlows
//
//	Description:
//	Class for managing flows to/from physical soil pools.
//	Members were extracted from class TCentury.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, April 2004
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TMCSoilFlows.h"
#include "TMCSoil.h"

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

float TMCSoilFlows::FlowNPSintoMineralSoil (
	TMineralElements element,	// N, P, S
	float * const source,		// source of mineral E
	float const eToAdd,		// amount of mineral E to add (gE/m^2)
	float const depth)		// soil depth to receive mineral E (cm)
{
	if ( eToAdd <= 0.0f )
		return 0.0f;

	Assert (source != NULL);

	TMCSoil & mcSoil = dynamic_cast<TMCSoil &>( soil );

	float amountAdded = 0.0f;
	switch (element)
	{
	  case N:
	  {
		amountAdded = FlowEIntoSoil (
			eToAdd, source, mcSoil.MineralN(), depth );
		break;
	  }
	  case P:
	  {
		amountAdded = FlowEIntoSoil (
			eToAdd, source, mcSoil.MineralP(), depth );
		break;
	  }
	  case S:
	  {
		amountAdded = FlowEIntoSoil (
			eToAdd, source, mcSoil.MineralS(), depth );
		break;
	  }
	}
	Assert ( std::fabs(amountAdded - eToAdd) <= 1.0E-05 );
	return amountAdded;
}

float TMCSoilFlows::FlowNPSfromMineralSoil (
	TMineralElements element,	// N=nitrogen, P=Phosphorus, S=Sulfur
	float * const destination,	// destination for mineral E
	float const eDemand,		// amount of mineral E wanted (gE/m^2)
	float const depth)		// soil depth to receive mineral E (cm)
{
	if ( eDemand == 0.0f )
		return 0.0f;

	Assert ( eDemand > 0.0f );
	Assert ( destination != NULL );

	TMCSoil & mcSoil = dynamic_cast<TMCSoil &>( soil );

	float amountRemoved = 0.0f;
	switch (element)
	{
	  case N:
	  {
		amountRemoved += FlowEFromSoil (
			eDemand, mcSoil.MineralN(), destination, depth );
		break;
	  }
	  case P:
	  {
		amountRemoved = FlowEFromSoil (
			eDemand, mcSoil.MineralP(), destination, depth );
		break;
	  }
	  case S:
	  {
		amountRemoved = FlowEFromSoil (
			eDemand, mcSoil.MineralS(), destination, depth );
		break;
	  }
	  default:
		break;
	}
	//Assert ( std::fabs(amountRemoved - eDemand) <= 1.0E-05 );
	return amountRemoved;
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//--- end of definitions for TMCSoilFlows ---
