// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TSoilFlowsBase.cpp
//	Class:	  TSoilFlowsBase
//
//	Description:
//	Class for managing flows to/from physical soil pools.
//	Members were extracted from class TCenturyBase.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, April 2004
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TSoilFlowsBase.h"

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	FlowEIntoSoil
//	Schedule a flow for a mineral element into the specified depth of soil.
//	The flow is evenly distributed throughout the soil depth.
//	Return the total amount of flow scheduled.
float TSoilFlowsBase::FlowEIntoSoil (
	float const eToAdd,	// amount of mineral E to add (gE/m^2)
	float * const source,	// source of mineral element
	TSoilPool & soilPool,	// soil sink of mineral element
	float const depth)	// depth of soil to receive mineral E (cm)
{
	if ( eToAdd == 0.0f )
		return 0.0f;

	// full layers or is bottom within a layer?
	TSoilBase::size_type const numberOfLayers =
		soil.GetLayerIndex (depth) + 1;
      	Assert (numberOfLayers <= soil.GetLayerCount());
      	TSoilBase::size_type numberFullLayers;		// loop limit
      	if ( !AmountIsSignificant (
      		depth - soil.Depth(numberOfLayers - 1),
		1.0e-5f ) )				// at layer boundary?
	{
      		numberFullLayers = numberOfLayers;	// ...yes, full layer
      	}
      	else
      		numberFullLayers = numberOfLayers - 1;	// ...fractional layer

	float amountFlow = 0.0f;
	if ( numberFullLayers > 0 ) 			// full layers?
	{
	    for ( TSoilBase::size_type layer = 0;
		  layer < numberFullLayers;
		  ++layer )
	    {
		float const amount = eToAdd * soil.Thickness(layer) / depth;
		Assert (amount <= (eToAdd + eToAdd * 1.0e-4f) );
		if ( amount > 0.0f )
			SCHEDULE_FLOW( &flows, source, &soilPool[layer],
					simTime.time, amount );
		amountFlow += amount;
	    }
	}
	if ( numberFullLayers < numberOfLayers )	// fractional layer?
	{
	    short const layer = numberFullLayers;	// layer index
	    float const amount = eToAdd *
		( layer == 0 ?
		  1.0f :
		  (depth - soil.Depth(layer - 1)) / depth );
	    Assert (amount <= (eToAdd + eToAdd * 1.0e-4f) );
	    if ( amount > 0.0f )
		SCHEDULE_FLOW( &flows, source, &soilPool[layer],
				simTime.time, amount );
	    amountFlow += amount;
	}
	return amountFlow;
}

//	FlowEFromSoil
//	Schedule a flow for a mineral element from the top simDepth of soil.
//	Demand is limited by availability in the total soil.
//	so no layer is completely depleted.
//	Return the total amount of flow scheduled.
float TSoilFlowsBase::FlowEFromSoil (
	float const eDemand,	// amount of mineral E demand (gE/m^2)
	TSoilPool & soilPool,	// soil source of mineral element
	float * const sink,	// sink of mineral element
	float const depth)	// depth of soil to receive mineral E (cm)
{
	if ( eDemand == 0.0f )
		return 0.0f;

	// full layers or is bottom within a layer?
	TSoilBase::size_type const numberOfLayers =
		soil.GetLayerIndex (depth) + 1;
      	Assert (numberOfLayers <= soil.GetLayerCount());
      	TSoilBase::size_type numberFullLayers;	// loop limit
      	if ( !AmountIsSignificant (
      		depth - soil.Depth(numberOfLayers - 1),
      		1.0e-5f ) )				// at layer boundary?
	{
      		numberFullLayers = numberOfLayers;	// ...yes, full layer
      	}
      	else
      		numberFullLayers = numberOfLayers - 1;	// ...fractional layer

	// remaining E demand
	float availableE = std::min (
	    eDemand,
	    soilPool.Quantity (0.0f, depth, soil.Depth(), soil.Thickness()) );
	if ( availableE <= 0.0f )
		return 0.0f;

	float totalEFlow = 0.0f;
	if ( numberFullLayers > 0 ) 			// full layers?
	{
	    for ( TSoilBase::size_type layer = 0;
		  layer < numberFullLayers;
		  ++layer )
	    {
		float const sourceQuantity = soilPool.Quantity (layer, layer);
		if ( sourceQuantity <= 0.0f )		// anything to extract?
			continue;			// ...no
		float const amount =
			std::min ( availableE * soil.Thickness(layer) / depth,
				   sourceQuantity );
		SCHEDULE_FLOW(&flows,
			&soilPool[layer], sink, simTime.time, amount);
		totalEFlow += amount;
		availableE -= amount;
	    }
	}
	if ( numberFullLayers < numberOfLayers )	// fractional layer?
	{
	    Assert (availableE > 0.0f);
	    short const layer = numberFullLayers;	// layer index
	    float const sourceQuantity = soilPool.Quantity (layer, layer) *
		( layer == 0 ?
		  depth / soil.Thickness(0) :
		  (depth - soil.Depth(layer - 1)) / soil.Thickness(layer) );
	    float const amount = std::min ( availableE, sourceQuantity );
	    if ( amount > 0.0f )
	    {
		SCHEDULE_FLOW(&flows,
			&soilPool[layer], sink, simTime.time, amount );
		totalEFlow += amount;
	    }
	}
	return totalEFlow;
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//--- end of definitions for TSoilFlowsBase ---
