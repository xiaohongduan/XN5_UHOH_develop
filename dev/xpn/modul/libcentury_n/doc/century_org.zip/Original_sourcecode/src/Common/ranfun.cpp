// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  ranfun.cpp
//	Functions:
//	anorm	- ? random value from a normal distribution
//	sknorm	- ? random value from a skewed normal distribution
//	gpdf	- ? random value generalized Poisson density distribution
//
//	Description:
//	Contains functions for generating random values and values from
//	distributions.
// ----------------------------------------------------------------------------
//	History:
//	See header file.
// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "zufall.h"
#include <cmath>

#ifndef __BCPLUSPLUS__
 #ifndef M_PI
   const double M_PI = 3.14159265358979323846;
 #endif
#endif

// ----------------------------------------------------------------------------
//	anorm
//
/*  ******************** flowlib ********************* */
/* 	(run-time sub-set of modaid, exclusive of modctl) */
/* 	release 1.0  (first formal release of modaid) */
/* 	james m. vevea */
/* 	natural resource ecology lab */
/* 	colorado state university */
/* 	fort collins, colorado	80523 */
// ----------------------------------------------------------------------------

float anorm (
	float const mean,
	float const stdev)
{
    float retVal;
    double randomValue[2];

    /* get two values from a uniform distribution */
    ::zufall (2, randomValue);	// assumes initialization externally
    /* convert to a skewed distribution */
    retVal = std::sqrt ( std::log(randomValue[0]) * -2.0) *
			std::cos(randomValue[1] * M_PI * 2.0 ) *
		stdev + mean;
    return retVal;
}

// ----------------------------------------------------------------------------
//	sknorm
//	Value from a skewed normal distribution.
/* by Alister Metherell, from EPIC Model */
// ----------------------------------------------------------------------------
float sknorm (
	float const mean, 	// mean
	float const stddev, 	// standard deviation
	float const skew)	// skewness
{
    float retVal;
    double randomValue;
    ::zufall (1, &randomValue);	// assumes initialization externally

    /* Determine skewed value */
    if (skew == 0.0f)
	retVal = mean + stddev * randomValue;
    else	/* Computing 3rd power */
    {
	const double recip6 = 1.0 / 6.0;
	float tmp =
		(float)(recip6 * skew * (randomValue - recip6 * skew) + 1.0);
	retVal = mean + stddev * 2.0 / skew * (tmp * tmp * tmp - 1.0);
   }
    return retVal;
}

// ----------------------------------------------------------------------------
//	gpdf
//
/* ******************** flowlib ********************* */
/* (run-time sub-set of modaid, exclusive of modctl) */
/* Release 1.0  (first formal release of modaid) */
/*   james m. vevea */
/*   natural resource ecology lab */
/*   colorado state university */
/*   fort collins, colorado  80523 */
/* This routine is functionally equivalent to the routine of the */
/* same name, described in the publication: */
/*   Some Graphs and their Functional Forms */
/*   Technical Report No. 153 */
/*   William Parton and George Innis (1972) */
/*   Natural Resource Ecology Lab. */
/*   Colorado State University */
/*   Fort collins, Colorado  80523 */
/* 12/90 Corrected by McKeown - exponent on frac changed from d to c */
// ----------------------------------------------------------------------------
float gpdf (
	float const x,	// probability that values are > x
	float const a, 	// value of x at which gpdf() == 1.0
	float const b, 	// value of x at which gpdf() == 0.0
	float const c, 	// controls shape of curve for x > a
	float const d )	// controls shape of curve for x < a
{
    float retVal = 0.0f;
    float const frac = (b - x) / (b - a);

    if (frac > 0.0f)
	retVal = std::exp (c / d * (1.0 - std::pow(frac, d))) *
			std::pow(frac, c);
    return retVal;
}
