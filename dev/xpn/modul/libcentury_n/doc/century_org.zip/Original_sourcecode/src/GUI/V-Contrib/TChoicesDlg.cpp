// ----------------------------------------------------------------------------
// Copyright (c) 1999 Thomas E. Hilinski. All rights reserved.
// Unauthorized distribution, duplication, sale, and use is prohibited by law.
//
//	This software is made available under the terms of the
//	GNU LIBRARY GENERAL PUBLIC LICENSE.
//	This copyright notice must remain intact and in place.
// ----------------------------------------------------------------------------
//	Project:  V GUI Enhancement
//	File:	  TChoicesDlg.cpp
//	Class:	  TChoicesDialog
//
//	Description:
//	Declaration of class for a V dialog displaying a variable number of
//	radio buttons.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, hilinski@lamar.colostate.edu, Jan98
//	History:
//	See the header file.
// ----------------------------------------------------------------------------

#include "TChoicesDlg.h"
#include <v/vapp.h>
#include <v/vutil.h>
#include <cstring>
using namespace std;

// check for minimum V version
#if (V_VersMajor < 1) || (V_VersMinor < 16)
  #error V version 1.16 or higher is required.
#endif

//--- static member data

char const * const TChoicesDialog::version = "1.41";	// class version string


//--- constructors and destructor

TChoicesDialog::TChoicesDialog (
	vBaseWindow * const bw,		// pointer to window
	char const * const msg,		// message at top of choices
	short const numChoices,		// number of choices
	char const * const title, 	// title of dialog
	bool const centerMe)		// flag to center the dialog
	: vModalDialog (bw, title),
	  listSize (numChoices > 0 ? numChoices : 0),
	  currentSelection (0),
	  centered (centerMe)
{
	Initialize (msg);
}

TChoicesDialog::TChoicesDialog (
	vApp * const app,		// pointer to application
	char const * const msg,		// message at top of choices
	short const numChoices,		// number of choices
	char const * const title, 	// title of dialog
	bool const centerMe)		// flag to center the dialog
	: vModalDialog (app, title),
	  listSize (numChoices > 0 ? numChoices : 0),
	  currentSelection (0),
	  centered (centerMe)
{
	Initialize (msg);
}

TChoicesDialog::~TChoicesDialog ()
{
	// delete memory for text items
	if ( strlen(coList[0].title) )		// default has no length
		delete [] coList[0].title;	// has length, so was new'd
	for (short i = 0; i < listSize; i++)
		if ( strlen(coList[2+i].title) )
			delete [] coList[2+i].title;
	// delete memory for list
	delete [] coList;
	coList = 0;
}

//	DialogDisplayed
//	Overrides the vModelDialog method.
void TChoicesDialog::DialogDisplayed ()
{
	if ( centered )
	{
		// center the dialog in the app window
		int xApp, yApp;				// app window location
		unsigned int widthApp, heightApp; 	// app window dimensions
		unsigned int widthDlg, heightDlg; 	// dialog dimensions

#if defined(V_VersionWindows) || defined(V_VersionWin95)
		// MS Windows-specific!
		RECT rectApp, rectDlg;			// app & dlg corners
		BOOL success = ::GetWindowRect ( theApp->winHwnd(), &rectApp );
		success &= ::GetWindowRect ( myHwnd(), &rectDlg );
		if ( !success )
			return;		// Get*Rect() failed - nothing to do!
		xApp = rectApp.left;
		yApp = rectApp.top;
		widthApp = rectApp.right - rectApp.left;
		heightApp = rectApp.bottom - rectApp.top;
		widthDlg = rectDlg.right - rectDlg.left;
		heightDlg = rectDlg.bottom - rectDlg.top;

		// Common to all platforms
		int left, top;				// dlg upper-left corner
		// don't add to left - SetDialogPosition does
		if ( widthApp > widthDlg )
			left = (widthApp - widthDlg) / 2;
		else
			left = xApp;
		if ( heightApp > heightDlg )
			top = (heightApp - heightDlg) / 2;
		else
			top = yApp;
		SetDialogPosition (left , top);	      // set position V coords
#else
		// X11R6-specific
		// See vDialog::ShowDialog
		vModalDialog::DialogDisplayed ();
#endif
	}
}

//	DialogCommand
//	Overrides the vModelDialog method.
void TChoicesDialog::DialogCommand (ItemVal id, ItemVal val, CmdType type)
{
	if ( id == M_OK )
		for (short i = 1; i <= listSize; i++)
			if ( GetValue(CID_Button1 + i) == isChk )
			{
				choice = i;
				break;
			}
	// Default event processing
	vModalDialog::DialogCommand (id, val, type);
}

//--- private functions

void TChoicesDialog::Initialize (
	char const * const msg)
{
	// error checks
	if ( listSize == 0 )
		lastError = ZeroChoices;	// non-fatal error

	// create the CommandObject list
	try
	{
		coList = new CommandObject [listSize + 5];
	}
	catch (...)
	{
		lastError = MemoryAlloc;
		return;				// fatal error
	}

	// add C_Text for user's message
	CommandObject c0 = {C_Text, CID_Msg, 0, "",
		NoList, CA_NoBorder, isSens, NoFrame, 0, 0};
	coList[0] = c0;
	// add C_Frame for radio buttons
	CommandObject c1 = {C_Frame, CID_Frame, 0, "",
		NoList, CA_None, isSens, NoFrame, 0, CID_Msg};
	coList[1] = c1;
	// add OK button
	CommandObject c2 = {C_Button, M_OK, M_OK, "&Select",
		NoList,	CA_DefaultButton, isSens, NoFrame, 0, CID_Frame,
		0, "Accepts the selection and closes this dialog."};
	coList[listSize + 2] = c2;
	// add Cancel button
	CommandObject c3 = {C_Button, M_Cancel, M_Cancel, "&Cancel",
		NoList,	CA_None, isSens, NoFrame, M_OK, CID_Frame,
		0, "Cancels this selection."};
	coList[listSize + 3] = c3;
	// add end of list
	CommandObject c4 = {C_EndOfList, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	coList[listSize + 4] = c4;
	// Add the message to the text item
	if ( msg && *msg )
	{
		try
		{
			char *msgText = new char [strlen(msg) + 1];
			strcpy (msgText, msg);
			coList[0].title = msgText;
		}
		catch (...)
		{
			lastError = MemoryAlloc;
		}
	}
	// point to first radio button
	currentItem = 1;
	widestBtnID = 1;
	widestWidth = 0;
	toRightOf = belowOf = 0;
	// initial choice is "Cancel"
	choice = 0;
	// misc
	lastError = NoError;
	itemsAdded = 0;
}

//--- public functions

void TChoicesDialog::AddChoice (
	char const * const buttonText)
{
	// error checks
	if ( currentItem > listSize )		// too many choices?
	{
		lastError = TooMany;
		return;				// fatal
	}
	if ( !buttonText )			// anything there?
	{
		lastError = NullText;
		return;				// fatal
	}

	// set up the CommandObject
	CommandObject &c = coList[1 + currentItem];	// get button to add
	// fill in the CommandObject items
	c.cmdType = C_RadioButton;
	c.cmdId = CID_Button1 + currentItem;
	if ( currentItem == 1 )
	{
		c.retVal = isChk;			// first is checked
		currentSelection = 1;			// remember which
	}
	else
		c.retVal = notChk;			// others not checked
	if ( buttonText && *buttonText )
	{
		try
		{
			char *text = new char [strlen(buttonText) + 1];
			strcpy (text, buttonText);
			c.title = text;
		}
		catch (...)
		{
			lastError = MemoryAlloc;	// non-fatal
			c.title = "";
		}
		++itemsAdded;				// count number added
	}
	else
	{
		c.title = "";
	}
	c.itemList = NoList;
	c.attrs = CA_NoNotify;
	c.Sensitive = isSens;
	c.cFrame = CID_Frame;
	c.cRightOf = toRightOf;
	c.cBelow = belowOf;
	c.size = 0;
	c.tip = "You can select this choice.";
	// get width of title, and see if it is the widest
	int numLines, lineWidth;
	lineWidth = ::vTextLen (c.title, numLines);
	if ( lineWidth > widestWidth )
	{
		widestWidth = lineWidth;		// save width
		widestBtnID = currentItem;		// save button ID
	}
	belowOf = CID_Button1 + currentItem;
	// point to next available button
	++currentItem;
}

void TChoicesDialog::NextColumn ()
{
	toRightOf = CID_Button1 + widestBtnID;
	belowOf = 0;
	widestBtnID = currentItem;		// reset to current
	widestWidth = 0;			// reset
}

//	InitialSelection
//	Return false if a valid item number, else true if not.
bool TChoicesDialog::InitialSelection (
	size_type const itemNumber)	// one-based number in the list
{
	bool failed = ( itemsAdded == 0 );
	if ( !failed )
	{
		if ( itemNumber > itemsAdded )	// valid value?
		{
			// no change in the current selection
			failed = true;
		}
		else
		{
			coList[1 + currentSelection].retVal = notChk;
			coList[1 + itemNumber].retVal = isChk;
			currentSelection = itemNumber;	// remember which
		}
	}
	return failed;
}

bool TChoicesDialog::InitialSelection (
	char const * const buttonText)	// this item's text
{
	bool failed = ( itemsAdded == 0 );
	if ( !failed )
	{
		// search for matching item title
		CommandObject* pList = &coList[2];
		CommandObject* pListEnd = coList + itemsAdded;
		while (pList < pListEnd)
		{
		    if ( !strcmp(pList->title, buttonText) )  // match?
		    {
			size_type const itemNumber =
				static_cast<size_type>(pList - &coList[1]);
			coList[1 + currentSelection].retVal = notChk;
			coList[1 + itemNumber].retVal = isChk;
			currentSelection = itemNumber;	// remember which
			break;				// stop search
		    }
		    // no match, check next
		    ++pList;
		}
		if ( pList == pListEnd )			// no match?
			failed = true;
	}
	return failed;
}

short TChoicesDialog::GetChoice ()
{
	if ( itemsAdded == 0 )
		lastError = NoChoices;
	// even if no choices, show it anyway
	AddDialogCmds ((CommandObject*)coList);	// add dialog controls
	ItemVal retVal;
	ShowModalDialog ("", retVal);		// display it now
	return choice;
}

//--- end of file ---

