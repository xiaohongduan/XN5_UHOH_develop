#ifndef INC_SiteEditorDataSrcMCFile_h
#define INC_SiteEditorDataSrcMCFile_h
// ----------------------------------------------------------------------------
//	Copyright 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  SiteEditorDataSrcMCFile.h
//	Class:	  SiteEditorDataSrcMCFile
//
//	Description:
//	Class for the data source for the Site Editor for monthly Century5
//	site parameters from a file.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Dec04
//	History:
// ----------------------------------------------------------------------------

#include "SiteEditorDataSrcBase.h"
#include "TMCSiteParameters.h"
#include "v/vapp.h"
#include <string>

template<class TMCSiteParameters, class TMCSiteParamInfo> class SiteEditorDlg;

class SiteEditorDataSrcMCFile
	: public SiteEditorDataSrcBase<TMCSiteParameters, TMCSiteParamInfo>
{
  public:
  	//---- types
  	typedef SiteEditorDataSrcBase<TMCSiteParameters, TMCSiteParamInfo>
  		MyBaseClass;

	//---- constructors and destructor
	SiteEditorDataSrcMCFile (
	  vApp * const useParent,			// pointer to app
	  std::string const & useFileName,		// parameters file name
	  std::string const & useTmpltPath,		// template files
	  std::string const & useWorkPath,		// working directory
	  TMCSiteParamInfo::TInfoPtr useInfo)		// parameter names
	  : SiteEditorDataSrcBase<TMCSiteParameters, TMCSiteParamInfo> (
	  	useInfo),
	    parent (useParent),
	    templatePath (useTmpltPath),
	    workPath (useWorkPath),
	    activePath (useWorkPath),
	    fileName (useFileName)
	  {
	    /* error = */ Read (dataPtr);
	  }
	SiteEditorDataSrcMCFile (
	  vApp * const useParent,			// pointer to app
	  TSiteParametersBase::TSitePtr useSiteParameters, // parameters
	  TMCSiteParamInfo::TInfoPtr useInfo)		// parameter names
	  : SiteEditorDataSrcBase<TMCSiteParameters, TMCSiteParamInfo> (
	  	useInfo),
	    parent (useParent),
	    templatePath ( useSiteParameters->GetTemplatePath() ),
	    workPath ( useSiteParameters->GetWorkPath() )
	  {
	    activePath = workPath;
	    fileName = useSiteParameters->GetNcFileName().GetFullName();
	    DoSave ( dynamic_cast<TMCSiteParameters &>(*useSiteParameters) );
	  }
	SiteEditorDataSrcMCFile (
	  SiteEditorDataSrcMCFile const & object)
	  : SiteEditorDataSrcBase<TMCSiteParameters, TMCSiteParamInfo> (object),
	    parent (object.parent),
	    templatePath (object.templatePath),
	    workPath (object.workPath),
	    activePath (object.activePath),
	    fileName (object.fileName)
	  {
	  }
	virtual ~SiteEditorDataSrcMCFile ()
	  {
	  }
	virtual SiteEditorDataSrcMCFile * const Clone () const	// Clone this
	  {
	    return new SiteEditorDataSrcMCFile (*this);
	  }

	//---- operator overloads
	SiteEditorDataSrcMCFile & operator= (
	  SiteEditorDataSrcMCFile const & object)
	  {
	    MyBaseClass::operator= (object);
	    return *this;
	  }
	bool operator== (
	  SiteEditorDataSrcMCFile const & object) const
	  {
	    if ( &object )
	    {
		return
		  MyBaseClass::operator== (object) &&
		  fileName == object.fileName;
	    }
	    else
		return false;
	  }
	bool operator!= (
	  SiteEditorDataSrcMCFile const & object) const
	  {
	    return !(*this == object);
	  }

	std::string const & GetFileName () const
	  { return fileName; }

  protected:
	vApp * const parent;		// parent dialog
	std::string const templatePath;		// path to template folder
	std::string const workPath;		// user's work path
	std::string activePath;			// user's current path
	std::string fileName;			// site param file name

	bool Read (				// Read the file
	  TSharedPtr<TMCSiteParameters> & siteParameters);
	bool Write ();				// Write the file
	void ReadWriteErrorNotice (
	  char const * const msgFirstPart);

  private:
	virtual TUserAction DoOpen (
	  DataTypePtr siteParameters);
	virtual TUserAction DoSave (
	  TMCSiteParameters const & siteParameters);
	virtual TUserAction DoSaveAs (
	  DataTypePtr siteParameters);
};

#endif // INC_SiteEditorDataSrcMCFile_h
