#ifndef INC_TUserPref_h
#define INC_TUserPref_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TUserPref.h
//	Class:	  TUserPref
//
//	Description:
//	Class for information about the user's preferences.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Feb98
//	History:
//	Jan00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Operator= : added check for assignment to self, and changed to return
//	  a reference to this rather than a copy of this.
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* A bit of cleaning up.
//	Oct01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added static member defaultIniFileName.
//	* Added constructor taking an INI file name.
//	* Added function HaveIniFile.
//	Dec02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Adds the extension "ini" to a user preferences file name,
//	  if no extension is provided.
// ----------------------------------------------------------------------------

#include "TFileName.h"

class TUserPref
{
  public:
	//--- constructors and destructor
	TUserPref ()					// default constructor
	  {
	    Initialize ();
	  }
	TUserPref (
	  char const * const newIniFile)		// .INI file name
	  {
	    Initialize ();
	    SetIniFile (newIniFile);
	    ReadIniFile ();
	  }
	~TUserPref ()
	  {
	    Clear ();
	  }
	TUserPref (TUserPref const & object)  	// copy constructor
	  {
	    Initialize ();
	    Copy (object);
	  }

	//--- operator overloads
	TUserPref& operator= (TUserPref const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	Clear ();
		Copy (object);
	    }
	    return *this;
	  }
	bool operator== (TUserPref const & object) const;
	bool operator!= (TUserPref const & object) const
	  { return !(*this == object); }

	//--- functions
	bool SetIniFile (			// Set the .INI file name
	  TEH::TFileName const & newIniFile);	//   to this name
	bool SetIniFile (			// Set the .INI file name
	  char const * const newIniFile);	//   to this name
	bool SetIniFile (			// Set the .INI file name
	  std::string const & newIniFile)	//   to this name
	  { return SetIniFile ( newIniFile.c_str() ); }
	TEH::TFileName const & GetIniFile () const
	  { return iniFileName; }
	bool HaveIniFile ()			// True if have .INI file name
	  { return !iniFileName.IsEmpty(); }
	static char const * const GetDefaultIniFileName ()
	  { return defaultIniFileName; }
	void SetName (				// Set the user's name
	  char const * const newName);
	void SetName (				// Set the user's name
	  std::string const & newName)
	  { SetName ( newName.c_str() ); }
	std::string const & GetName () const	// Get the user's name
	  { return userName; }
	bool SetSitesPath (			// Path to user's site libs
	  TEH::TFileName const & newPath);
	bool SetSitesPath (			// Path to user's site libs
	  char const * const newPath);
	TEH::TFileName const & GetSitesPath () const
	  { return siteLibPath; }
	bool SetMgmtPath (			// Path to user's mgmt. libs
	  TEH::TFileName const & newPath);
	bool SetMgmtPath (			// Path to user's mgmt. libs
	  char const * const newPath);
	bool SetMgmtPath (			// Path to user's mgmt. libs
	  std::string const & newPath)
	  { return SetMgmtPath ( newPath.c_str() ); }
	TEH::TFileName const & GetMgmtPath () const
	  { return mgmtLibPath; }
	bool AddProjectPath (			// Add path to work path list
	  TEH::TFileName const & newPath);
	bool AddProjectPath (			// Add path to work path list
	  char const * const newPath);
	bool AddProjectPath (			// Add path to work path list
	  std::string const & newPath)
	  { return AddProjectPath ( newPath.c_str() ); }
	TEH::TFileName const & GetProjectPath (	// Get path from work path list
	  short const which) const
	  {
	    if ( which >= 0 && which < numProjPaths )
		return projectPaths[which];
	    else
		return nullFileName;
	  }
	short DelProjectPath (			// Remove path from work paths
	  short which);
	short GetProjPathCount () const		// Get number of work paths
	  { return numProjPaths; }
	bool SetWorkPath (			// Set current work path
	  TEH::TFileName const & newPath);
	bool SetWorkPath (			// Set current work path
	  char const * const newPath);
	bool SetWorkPath (			// Set current work path
	  std::string const & newPath)
	  { return SetWorkPath ( newPath.c_str() ); }
	TEH::TFileName const & GetWorkPath () const
	  { return workPath; }
	bool ReadIniFile ();			// Read initialization file:
						// false if successful.
	bool WriteIniFile ();			// Write initialization file:
						// false if successful.
	void SetModified (bool flag)		// Set the modified flag
	  { modified = flag; }
	bool IsModified () const		// True if the data changed
	  { return modified; }
	char** GetParamNameList (		// Get params. for INI file:
	  short & count);				// returns list size in count;
						// caller owns pointer.
	bool IsEmpty () const;			// Returns true if no prefs.
	void Clear ();				// "Clear" data members

  protected:
	//--- contants
	static TEH::TFileName const nullFileName;	// empty file name
	static char const * const
		defaultIniFileName;	// default .INI file name
	static char const * const
		paramStdNames[];	// std. parameter names for INI file
	static short const
		paramStdNamesCount;	// number of std. parameter names

	//--- data
	TEH::TFileName iniFileName;	// last initialization file specified
	std::string userName;		// user's name
	TEH::TFileName* projectPaths;	// list of project paths (null-term'd)
	short numProjPaths;		// number of project paths
	TEH::TFileName
		siteLibPath,		// path to default site libraries
		mgmtLibPath,		// path to default mgmt. libraries
		workPath;		// current project path (work path)
	bool modified;			// true if data changed

  private:
	//--- functions
	void Initialize ();				// initialize members
	void Copy (TUserPref const & object);		// copy to this
	bool CheckDuplicate (				// is path in list?
	  TEH::TFileName const & newPath);
};

#endif // INC_TUserPref_h
