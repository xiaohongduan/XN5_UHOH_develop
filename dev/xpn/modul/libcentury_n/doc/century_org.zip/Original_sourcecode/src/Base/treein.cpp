// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  treein.cpp
//	Class:	  TCentury
//	Function: GetTree
//
//	Description:
//	Read the new tree parameter set.
//	Returns true if successful match in database, else false if not.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
// ----------------------------------------------------------------------------
//	History:
//	Jul01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to use new TEventDBList class.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "TEventDBList.h"
#include "util.h"
#include "constants.h"

MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::GetTree (
	char const * treeToMatch)
{
	// error checks
	if ( !treeToMatch || !(*treeToMatch) )		// anything there?
		return false;

	// get the option set
	TEventOptionSet const & optionSet =
		*paramDbList->Get (TEventDBList::DBI_Tree);
	if ( !&optionSet )				// database not there?
		ThrowCentException (TCentException::CE_NSPPDB,
			::eventName[ET_Tree]);
	if ( !optionSet.GetOptionCount () )		// empty database?
		ThrowCentException (TCentException::CE_EMPPDB,
			::eventName[ET_Tree]);

	// get the option matching the parameter string
    	TEventOption const * const option = optionSet.GetOption (treeToMatch);
	if ( !option )					// match found?
		return false;

	// retrieve values from option and save in Century's variables
	short const numParams = 111;			// total for an option
	short count = option->GetParamCount ();
	if ( count != numParams )			// counts match?
		ThrowCentException (TCentException::CE_OPCBAD,
			::eventName[ET_Tree]);

	register short k = 0;			// index to param values
	register short i, j, m;			// loop indices
	float del13c;
	float chkfrc;

	parfs.decid = static_cast<short>(
		option->GetParameter(k++)->GetValue() );
	for (i = 1; i < 3; ++i)
		param.prdx[i] = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 4; ++i)
		ppdf_ref (i, 1) = option->GetParameter(k++)->GetValue();
	for (i = 0; i < 3; ++i)
    	    for (j = 0; j < FPARTS; ++j)
    		for ( m = 0; m < NUMELEM; ++m )
		    cerfor_ref (i, j, m) = option->GetParameter(k++)->GetValue();
	parfs.decw1 = option->GetParameter(k++)->GetValue();
	parfs.decw2 = option->GetParameter(k++)->GetValue();
	parfs.decw3 = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 2; ++i)
    	{
    		chkfrc = 0.0f;	// check to make sure fractions add to 1
    		for (j = 0; j < 5; ++j)
    		{
			fcfrac_ref (j, i) = option->GetParameter(k++)->GetValue();
			chkfrc += fcfrac_ref (j, i);
		}
		if ( std::fabs (1.0f - chkfrc) > 1e-6f)
			ThrowCentException (TCentException::CE_FCFRAC, 0);
	}
	for (i = 0; i < 12; ++i)
		parfs.leafdr[i] = option->GetParameter(k++)->GetValue();
	// leaf area index parameters
	float btolai = option->GetParameter(k++)->GetValue();
	float klai = option->GetParameter(k++)->GetValue();
	parfs.laitop = option->GetParameter(k++)->GetValue();
	float maxlai = option->GetParameter(k++)->GetValue();
	canopy.SetLAIParameters (maxlai, klai, btolai);

	parfs.maxldr = option->GetParameter(k++)->GetValue();
	for (i = 0; i < 3; ++i)
		parfs.forrtf[i] = option->GetParameter(k++)->GetValue();
	parfs.sapk = option->GetParameter(k++)->GetValue();
	parfs.swold = option->GetParameter(k++)->GetValue();
	for (i = 0; i < FPARTS; ++i)
		parfs.wdlig[i] = option->GetParameter(k++)->GetValue();
	for (i = 0; i < FPARTS; ++i)
		parfs.wooddr[i] = option->GetParameter(k++)->GetValue();
	param.snfxmx[1] = option->GetParameter(k++)->GetValue();
	del13c = option->GetParameter(k++)->GetValue();
	param.co2ipr[1] = option->GetParameter(k++)->GetValue();
	param.co2itr[1] = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 2; ++i)
    		for (j = 0; j < 3; ++j)
		    co2ice_ref (1, i, j) = option->GetParameter(k++)->GetValue();
	param.co2irs[1] = option->GetParameter(k++)->GetValue();
	parcp.basfc2 = option->GetParameter(k++)->GetValue();
	parfs.basfct = option->GetParameter(k++)->GetValue();
	site.sitpot = option->GetParameter(k)->GetValue();

	// save option name in Century class variable
	strcpy (sched->curTree, treeToMatch);

	// Calculate cisotf as 13C if 13C labeling
	if (param.labtyp == Lbl_13C)
	{
		param.cisotf = del13c * PEEDEE * 0.001f + PEEDEE;
		param.cisotf = 1.0f / (1.0f / param.cisotf + 1.0f);
	}
	return true;
}
