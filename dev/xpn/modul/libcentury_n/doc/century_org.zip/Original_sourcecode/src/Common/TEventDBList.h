#ifndef INC_TEventDBList_h
#define INC_TEventDBList_h
// ----------------------------------------------------------------------------
// Copyright (c)  2001 Thomas E. Hilinski. All rights reserved.
// Unauthorized distribution, duplication, sale, and use is prohibited by law.
// This software is provided "as is" with no warranty as to function, purpose,
// use, or results.
// This software may be used and distributed freely, with the following
// conditions:
// * No charge is made for software upon distribution.
// * This copyright notice is distributed unaltered with this software.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TEventDBList.h
//	Class:	  TEventDBList
//
//	Description:
//	Class managing a list of event option databases (e.g., crops, trees).
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, tom.hilinski@colostate.edu, July 2001
//	History:
//	Oct01	Tom Hilinski
//	* Added more const-correctness.
//	Feb04	Tom Hilinski
//	* Version 1.1.0
//	* Modified to accept user-specified database files.
//	* Added public member UseDatabaseFile.
//	* Removed path from LoadCent4Files.
//	* Constructor requires the path to the default parameter files
//	  (e.g., $CENTURY_HOME/bin/parameters/Monthly)
//	Aug05	Tom Hilinski
//	* Version 1.2.0
//	* Added detailed error messages.
//	* Added GetErrorMessage.
//	* Parameter files now searched for in a list of paths.
// ----------------------------------------------------------------------------
//	Notes:
//	Each entry in the list is of a type TEventOptionSet, associated with
//	an event of type TEventType. The databases are stored as pointers
//	contained in a TSharedPtr template class.
//	Currently all databases are stored in memory as they are specified.
//	This should be changed to an "on-demand" model, wherein the memory
//	is not allocated until the "Get" function is called for that event
//	type for the first time.
//
//	To Do:
//	Refactor into (1) base class for param db entry, (2) child class
//	for Century4 parameter files, (3) sibling class for daycent5 parameter
//	files, (4) sibling for century4.5 parameter files, (5) sibling base
//	class for database sources.
// ----------------------------------------------------------------------------

#include "TEventOption.h"
#include "TSharedPtr.h"
#include <string>
#include <vector>
#include <map>
#include <utility>

class TEventDBList
{
  public:
	//---- types
	typedef std::vector< std::string >		TStringArray;

	// Indices to the database list.
	// These correspond to the entries in TEventDBList::cent4FileName[]
	enum DBIndex
	{
		DBI_Crop = 0, DBI_Cult, DBI_Fert, DBI_Fire, DBI_Graz,
		DBI_Harv, DBI_Irri, DBI_Omad, DBI_Tree, DBI_Trem, DBI_Fix,
		DBI_Unknown,
		DBI_EndOfList
	};

	//---- constructors and destructor
	TEventDBList (
	  TStringArray const & usePathList)
	  : searchPaths (usePathList),
	    modified (false)
	  {
	    CreateDefaultFileNames ();
	  }
	TEventDBList (
	  std::string const & useDefaultPath)	// path to default param. files
	  : modified (false)
	  {
	    searchPaths.push_back (useDefaultPath);
	    CreateDefaultFileNames ();
	  }
	~TEventDBList ()
	  {
	  }
	TEventDBList (				// copy constructor
	  TEventDBList const & object)
	  {
	    Copy (object);
	  }

	//---- operator overloads
	TEventDBList& operator= (TEventDBList const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	Clear ();
		Copy (object);
	    }
	    return *this;
	  }

	//---- functions
	bool UseDatabaseFile (				// Use database file
	  DBIndex useEventType,				//   this type
	  std::string const & dbFileName);		//   this file name
	TStringArray const & GetDBFileNameList () const	// Get list of files
	  { return fileNameList; }
	TSharedPtr<TEventOptionSet> Get (		// Get the database
	  DBIndex eventType) const;			//   of this type
	bool LoadCent4Files ();				// Load Century4 files
	bool Add (					// Add a new database
	  DBIndex const useEventType,			//   event type for set
	  TEH::TFileName const & newFileName);		//   db file path/name
	bool Add (					// Add a new database
	  DBIndex const useEventType,			//   event type for set
	  char const * const newFileName);		//   db file path/name
	bool Add (					// Add a new database
	  DBIndex useEventType,				//   event type for set
	  std::string const & newFileName);		//   db file path/name
	bool Replace (					// Replace database
	  DBIndex const useEventType,			//   event type for set
	  TEH::TFileName const & newFileName);		//   db file path/name
	bool Replace (					// Replace database
	  DBIndex const useEventType,			//   event type for set
	  char const * const newFileName);		//   db file path/name
	bool Replace (					// Replace database
	  DBIndex useEventType,				//   event type for set
	  std::string const & newFileName);		//   db file path/name
	void Clear ()					// "Clear" data members
	  {
	    dbList.clear ();
	    modified = true;
	    errMsg.clear ();
	  }

	//---- functions: Queries
	char const * const GetVersion () const		// Return version
	  { return version; }
	short Size () const				// Return size of list
	  { return static_cast<short>(dbList.size()); }
	bool IsEmpty () const				// True if no data
	  { return dbList.empty(); }
	bool IsModified () const			// True if modified
	  { return modified; }
	char const * const GetDBName (			// Get database name str
	  DBIndex eventType) const			//   for this type
	  { return cent4FileName[eventType]; }
	std::string const & GetErrorMessage () const	// Get error message
	  { return errMsg; }

  private:
	//---- types
	typedef std::pair<DBIndex, TSharedPtr<TEventOptionSet> >
		TDBEntry;				// db key/ptr pair
	typedef std::map<DBIndex, TSharedPtr<TEventOptionSet> >
		TDBList;				// db list

	//---- constants
	static char const * const version;		// class version number
	static char const * const cent4FileName[];	// Century 4 files

	//---- data
	TStringArray searchPaths;		// paths to look for files
	TDBList dbList;				// database ptr. list
	TStringArray fileNameList;		// database file names [DBIndex]
	bool modified;				// true if data changed
	std::string errMsg;			// error message

	//---- functions
	void Copy (TEventDBList const & object);	// Copy to this
	bool LoadDatabase (				// Load the option set
	  DBIndex eventType,				//   event type for set
	  TEH::TFileName const & fileName);		//   db file path/name
	void CreateDefaultFileNames ();			// fill "fileNameList"
};

#endif // INC_TEventDBList_h
