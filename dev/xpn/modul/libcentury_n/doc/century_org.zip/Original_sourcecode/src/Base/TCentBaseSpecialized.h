#ifndef	INC_TCentBaseSpecialized_h
#define	INC_TCentBaseSpecialized_h
// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCentBaseSpecialized.h
//	Class:	  TCenturyBase
//
//	Description:
//	Specialized instances of TCenturyBase.
//	Perhaps this can go away when "export template" is implemented!
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, November 2002
//	History:
// ----------------------------------------------------------------------------

#ifndef INC_TCenturyBase_h
#error TCentBaseSpecialized.h: TCenturyBase should be included before this file!
#endif

#if defined ( MONTHLY_CENTURY ) || defined ( ALL_CENTURY )
// ----------------------------------------------------------------------------
#include "TMCSiteParameters.h"
#include "TMCSoil.h"
#include "TWeather.h"
#include "TMCDecomposition.h"

template class TCenturyBase	//--- Specialization for monthly Century
	<
	  TMCSiteParameters,	// site parameters class
	  TManagementScheme,	// site management class
	  TMCSoil,		// physical soil submodel
	  TWeather,		// weather source
	  TFixed,		// fixed parameters
	  Tparam,		// site/mgmt parameters
	  Tparcp,		// crop parameters
	  Tparfs,		// forest/savanna parameters
	  TSimTime,		// simulation timing
	  TMCSoilFlows,		// flows to/from soil
	  TMCMicrobial,		// microbial submodel
	  TMCDecomposition	// decomposition submodel
	>;
// ----------------------------------------------------------------------------

#elif defined ( DAILY_CENTURY ) || defined ( ALL_CENTURY )
// ----------------------------------------------------------------------------
#include "TDCSiteParameters.h"
#include "TDayCentSoil.h"
#include "TDayCentWth.h"
#include "daycenttypes.h"
#include "TDCDecomposition.h"

template class TCenturyBase	//--- Specialization for daily Century
	<
	  TDCSiteParameters,	// site parameters class
	  TManagementScheme,	// site management class
	  TDayCentSoil,		// physical soil submodel
	  TDayCentWth,		// weather source
	  TDCFixed,		// fixed parameters
	  TDCparam,		// site/mgmt parameters
	  TDCparcp,		// crop parameters
	  TDCparfs,		// forest/savanna parameters
	  TDCSimTime,		// simulation timing
	  TDCSoilFlows,		// flows to/from soil
	  TDCMicrobial,		// microbial submodel
	  TDCDecomposition	// decomposition submodel
	>;
// ----------------------------------------------------------------------------

#else
#error No TCenturyBase template specialization macro is defined!
#endif

#endif // INC_TCentBaseSpecialized_h
