// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  potcrp.cpp
//	Class:	  TDayCent
//	Function: CropGrassProductionPotential
//
//	Description:
// 	Compute monthly production potential based upon montly precipitation,
// 	and restrict potential production based upon the method specified
// 	by grzeff.
// ----------------------------------------------------------------------------
//      History:
//      See Century/potcrp.cpp
//      May01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Changed function name from ProductionPotential to CropGrassPotProd
//      * Made this function a TDayCent function, formerly a TCentury function
//      * Added new function arguments
//      * Modified pptprd (now soilWaterEffectFraction) calculation
//      * Modified agprod calculation
//      * Rearranged code
//      * New fracrc/rootShootRatio calculation using FractionRootAllocation() function
//      * Added additional Assert() calls
//      Jun01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Added stemp as a parameter, used in place of wt.stemp.
//      Nov01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Updated pptprd (now moistureRatioForGrowth) calculation to be
//        timestep independent (see below)
//      Jan02   Melannie Hartman, melannie@nrel.colostate.edu
//      * Changed function name from CropGrassPotProd to
//        CropGrassProductionPotential
//      10Jan02 Melannie Hartman, melannie@nrel.colostate.edu
//      * Updated to keep consistent with TCentury::CropGrassProductionPotential()
//	May03	Tom Hilinski
//	* Moved restriction on grazing code into RestrictCropProdGrazing().
//	Sep03	Tom Hilinski
//	* Moved RestrictCropProdGrazing into TCenturyBase.
// ----------------------------------------------------------------------------
//      Notes:
//      * Fire and Grazing conditions persist for the entire month.
//      * stemp may be current day's soil surface temperature
// ----------------------------------------------------------------------------

#include "TDayCent.h"
#include "ranfun.h"
#include <cmath>

float TDayCent::CropGrassProductionPotential (
        float const canopyCover,        // canopy cover
        float const prodPrecip,         // precip amount over prod period (cm H2O)
        float const prodTempMin,        // avg min temp over prod period (deg C)
        float const prodTempMax,        // avg max temp over prod period (deg C)
        float const prodPET,            // PET amount over prod period (cm H2O)
        float const prodMonthFrac,      // fraction of current month comprised
                                        //   by the current production period (0-1)
        float const stemp)              // soil surface temperature (deg C)
{
    Assert (canopyCover >= 0.0f);
    Assert (prodPrecip >= 0.0f);
    Assert (prodTempMin <= prodTempMax);
    Assert (prodPET >= 0.0f);
    Assert (prodMonthFrac > 0.0f);
    Assert (prodMonthFrac <= 1.0f);
    Assert (stemp > -99.0f);
    Assert (stemp < 100.0f);

    float r1, r2;	// for min and max temp values

    // ------------------------------------------------------------------------
    // Shading modifier for savanna
    float shadeEffectFraction;	// shading effect upon savanna production
    if (sysType.IsSavanna())
    {
    	float aisc = 0.0f;
	if ( AmountIsSignificant(canopyCover) )		// anything there?
	{
	    //aisc =
	    //  std::exp (forestC.rleavc * 2.5 * -0.0035 / canopyCover) * 5.0;
	    aisc = std::exp (-8.75e-3f * forestC.rleavc / canopyCover) * 5.0f;
	}
	Assert ((aisc + 1.0f) != 0.0f);
	float const subcan = aisc / (aisc + 1.0f);
	shadeEffectFraction = 1.0f - canopyCover + canopyCover * subcan;
    }
    else
    {
	shadeEffectFraction = 1.0f;
    }
    Assert (shadeEffectFraction >= 0.0);
    Assert (shadeEffectFraction <= 1.0);

    // ------------------------------------------------------------------------
    // Soil water content effect upon production.
    // Value for potential plant production is now calculated from the
    // equation of a line whose intercept changes depending on water
    // content based on soil type.  The function PPRDWC contains the
    // equation for the line.

    float const soilWaterEffectFraction = PotPlantProdFromSoilH2O (
	water.extrSoilH2OCrop,
	MoistureRatioForGrowth (
		water.extrSoilH2OCrop, prodPrecip, prodPET, prodMonthFrac) );

    parcp.pptprd = soilWaterEffectFraction;

    // ------------------------------------------------------------------------
    // Estimate fraction of carbon allocated to fine roots (fracrc)
    // and the root/shoot ratio (rootShootRatio)
    float rootShootRatio;
    float fracrc = FractionRootAllocation(SysType_CropGrass, parcp.a2drat,
            soilWaterEffectFraction);
    if (fracrc < 0.99f)
        rootShootRatio = fracrc / (1.0f - fracrc);
    else
    {
        rootShootRatio = 100.0;   // Maximum root/shoot value
        // fracrc = 1.0f; --- not used ---
    }

    if (stemp <= 0.0f)
    {
	// No production this month
	potentProd.total =
		potentProd.aboveGround =
		potentProd.cropC = 0.0f;
	return potentProd.cropC;
    }

    // modify the root:shoot ratio for fire
    // This in effect for 1 month.
    if ( sched->DoingCropGrassFire() || sched->DoingSavannaFire() )
    {
	rootShootRatio += parcp.frtsh;
    }
    rootShootRatio *= co2.co2crs[CRPSYS];		// effect of CO2

    // ------------------------------------------------------------------------
    // Estimate plant production: stemp > 0.0f
    /*----- change taken from VEMAP - TEH 28Oct98
    // Calculate temperature effect on growth
    // Removal of litter effects on soil temperature as it
    // drives plant productin (keith paustian)
    float bio = std::min (cropC.aglivc * 2.5, fixed.pmxbio);
    // Maximum temperature
    float tmxs = weather->TempMax(month) + 25.4f /
    	(exp (-0.2 * weather->TempMax(month)) * 18.0f + 1.0f) *
    	(exp (fixed.pmxtmp * bio) - 0.13f);
    // Minimum temperature
    float tmns = weather->TempMin(month) + fixed.pmntmp * bio - 1.78f;
    // Average surface temperature
    float ctemp = (tmxs + tmns) * 0.5f;
    soilTempEffectFraction =
    	::gpdf (ctemp, ppdf_ref (0, 0), ppdf_ref (1, 0),
    		 ppdf_ref (2, 0), ppdf_ref (3, 0));
    -----*/
    float const soilTempEffectFraction =
    	::gpdf (stemp, ppdf_ref (0, 0), ppdf_ref (1, 0),
    		 ppdf_ref (2, 0), ppdf_ref (3, 0));

    // Calculate the effect of the ratio of live biomass to
    // dead biomass on the reduction of potential growth rate.
    float biomassRatioEffectFraction = 1.0f;
    if (parcp.bioflg == 1)
    {
	// Calculate maximum potential effect of standing dead on plant growth
	// (the effect of physical obstruction of litter and standing dead)
	float bioc = cropC.stdedc + soilC.strucc[SRFC] * 0.1f;
	if (bioc <= 0.0f)
    		bioc = 0.01f;
	if (bioc > fixed.pmxbio)
    		bioc = fixed.pmxbio;
	float const bioprd = 1.0f - bioc / (parcp.biok5 + bioc);

	// Calculate the effect of the ratio of live biomass to
	// dead biomass on the reduction of potential growth rate.
	// Intercept (highest negative effect of dead plant biomass)
	// = bioprd when the ratio = zero.
	float temp1 = 1.0f - bioprd;
	float temp2 = temp1 * 0.75f;
	float temp3 = temp1 * 0.25f;
	Assert (bioc != 0.0f);
	float const ratlc = cropC.aglivc / bioc;
	if (ratlc <= 1.0f)
    		biomassRatioEffectFraction = bioprd + temp2 * ratlc;
	else if (ratlc > 1.0f && ratlc <= 2.0f)
    		biomassRatioEffectFraction =
    			bioprd + temp2 + temp3 * (ratlc - 1.0f);
	else if (ratlc > 2.0f)
    		biomassRatioEffectFraction = 1.0f;
    }

    // ------------------------------------------------------------------------
    // Restriction on seedling growth
    if (cropC.aglivc > parcp.fulcan)
	parcp.seedl = 0;
    float seedlingEffectFraction;	// fraction that prdx is reduced
    if (parcp.seedl == 1)
    {
    	Assert (parcp.fulcan != 0.0f);
	r1 = 1.0f;
	r2 = parcp.pltmrf + cropC.aglivc *
    			(1.0f - parcp.pltmrf) / parcp.fulcan;
	seedlingEffectFraction = std::min (r1, r2);
    }
    else
    {
	seedlingEffectFraction = 1.0f;
    }

    // ------------------------------------------------------------------------
    // Potential production (biomass)
    // pdrx = biomass
    // 1. aboveground
    potentProd.aboveGround = 
	co2.co2cpr[CRPSYS] * 
	param.prdx[0] * 
	shadeEffectFraction * 
	soilWaterEffectFraction * 
	soilTempEffectFraction *
	biomassRatioEffectFraction *
	seedlingEffectFraction *
	prodMonthFrac;
    // 2. belowground
    float belowgroundPotentialProduction =
    	potentProd.aboveGround * rootShootRatio;
    potentProd.total =
    	potentProd.aboveGround + belowgroundPotentialProduction; // total

    // ------------------------------------------------------------------------
    // Restrict production due to grazing
    if ( sched->DoingGrazing() )
    {
	RestrictCropProdGrazing ( rootShootRatio,
		potentProd.aboveGround, belowgroundPotentialProduction);
	potentProd.total =
		potentProd.aboveGround + belowgroundPotentialProduction;
    }

    // ------------------------------------------------------------------------
    // Minimum and maximum C/N, C/P, and C/S ratios allowed in plants.
    // Changed grwprc to 2.5*aglivc in calculation of cercrp
    for (short e = 0; e < site.nelem; ++e)
    {
	// C:E min and max for aboveground
	Assert (parcp.biomax != 0.0f);
	r1 = pramn_ref (e, 0) + 
		(pramn_ref (e, 1) - pramn_ref (e, 0)) * 2.5f *
		cropC.aglivc / parcp.biomax;
	r2 = pramn_ref (e, 1);
	cercrp_ref (MINIMUM, ABOVE, e) = std::min (r1, r2);
	r1 = pramx_ref (e, 0) + 
		(pramx_ref (e, 1) - pramx_ref (e, 0)) * 2.5f *
		cropC.aglivc / parcp.biomax;
	r2 = pramx_ref (e, 1);
	cercrp_ref (MAXIMUM, ABOVE, e) = std::min (r1, r2);
	// C:E min and max for belowground
	cercrp_ref (MINIMUM, BELOW, e) =
		prbmn_ref (e, 0) + prbmn_ref (e, 1) * parcp.grwprc;
	cercrp_ref (MAXIMUM, BELOW, e) =
		prbmx_ref (e, 0) + prbmx_ref (e, 1) * parcp.grwprc;
    }

    // ------------------------------------------------------------------------
    // If burning occurs, modify maximum C/N ratio of shoots & roots.
    // minimum values do not change.
    // This in effect for 1 month.
    if ( sched->DoingCropGrassFire() || sched->DoingSavannaFire() )
    {
	cercrp_ref (MAXIMUM, ABOVE, N) += parcp.fnue[0];
	cercrp_ref (MAXIMUM, BELOW, N) += parcp.fnue[1];
    }

    // ------------------------------------------------------------------------
    // Add effect of co2 to above ground
    for (short e = 0; e < site.nelem; ++e)
    {
	cercrp_ref(MINIMUM, ABOVE, e) *= co2cce_ref(CRPSYS, 0, e);
	cercrp_ref(MAXIMUM, ABOVE, e) *= co2cce_ref(CRPSYS, 1, e);
    }

    // ------------------------------------------------------------------------
    // Update accumulators & compute potential C production
    // note: 0.4 = 1/2.5 = factor used in calc of potential effects above
    cropC.ptagc += potentProd.aboveGround * 0.4f;
    cropC.ptbgc += belowgroundPotentialProduction * 0.4f;
    potentProd.cropC = potentProd.total * 0.4f;
    return potentProd.cropC;
}

//--- end of potcrp.cpp ---

