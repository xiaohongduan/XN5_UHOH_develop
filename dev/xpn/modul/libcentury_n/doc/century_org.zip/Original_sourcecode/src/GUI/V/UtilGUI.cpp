// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  UtilGUI.cpp
//
//	Description:
//	Misc. utility functions for use with CMI.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Oct2003
//	History:
// ----------------------------------------------------------------------------

#include "UtilGUI.h"
#include <sstream>
//using namespace UtilGUI;

// #include "TCmdLineBase.h"
// #include "TTextCmdWindow.h"

UtilGUI::DlgCmdsArray::size_type UtilGUI::Size (
  CommandObject const * const cmdList)
{
	DlgCmdsArray::size_type size = 0;
	CommandObject const * iCmdList = cmdList;
	while ( iCmdList && iCmdList->cmdType != C_EndOfList )
	{
		++size;
		++iCmdList;
	}
	return size;
}

void UtilGUI::Copy (
  CommandObject const * const cmdList,	// from dialog elements struct array
  DlgCmdsArray & cmdArray)		// to vector of elements
{
	CommandObject const * iCmdList = cmdList;
	while ( iCmdList && iCmdList->cmdType != C_EndOfList )
	{
		// rely on the compiler-generated CommandObject::operator=
		cmdArray.push_back (*iCmdList);
		++iCmdList;
	}
}

void UtilGUI::Copy (
  DlgCmdsArray & cmdArray,		// from vector of dialog elements
  CommandObject * const cmdList)	// to dialog elements struct array
{
	// !!! No checks on allocated size of cmdList !!!
	DlgCmdsArray::const_iterator iCmdArray = cmdArray.begin();
	CommandObject * iCmdList = cmdList;
	while ( iCmdArray != cmdArray.end() )
	{
		// rely on the compiler-generated CommandObject::operator=
		*iCmdList = *iCmdArray;
		++iCmdArray;
		++iCmdList;
	}
	iCmdList->cmdType = C_EndOfList;
}

/*
//	DisplayCmdLineArgs
//	Displays the command-line arguments in the message window.
void DisplayCmdLineArgs (
	::TTextCmdWindow & window,
	::TCmdLineBase const & cmdLine)
{
	std::ostringstream os;
	os << "Command-line options:";
	if ( cmdLine.GetOptionCount() > 0 )
	{
	    for ( short i = 0; i < cmdLine.GetOptionCount(); ++i )
		os << "\n  " << cmdLine.GetOptionString(i);
	    os << std::endl;
	}
	else
		os << " None." << std::endl;
	window.Text ( os.str().c_str() );
}
*/

//--- end of file ---