// ----------------------------------------------------------------------------
//	Copyright 2000-2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCanopy.cpp
//	Class:	  TCanopy
//
//	Description:
//	Encapsulates tree canopy information and calculations.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec00
//	History: See header file.
// ----------------------------------------------------------------------------
//	Notes:
//
//	LAI Calculation:
//	Calculate true LAI using leaf biomass and a biomass-to-LAI
//	conversion parameter which is the slope of a regression
//	line derived from LAI vs Foliar Mass for Slash Pine.
//	Calculate theoretical LAI as a function of large wood mass.
//	There is no strong consensus on the true nature of the relationship
//	between LAI and stemwood mass. Version 3.0 used a negative exponential
//	relationship between leaf mass and large wood mass, which tended to
//	break down in very large forests. Many sutdies have cited as "general"
//	an increase of LAI up to a maximum, then a decrease to a plateau value
//	(e.g. Switzer et al. 1968, Gholz and Fisher 1982).  However, this
//	response is not general, and seems to mostly be a feature of young
//	pine plantations.  Northern hardwoods have shown a monotonic increase
//	to a plateau  (e.g. Switzer et al. 1968).  Pacific Northwest conifers
//	have shown a steady increase in LAI with no plateau evident (e.g.
//	Gholz 1982).  In this version, we use a simple saturation fucntion in
//	which LAI increases linearly against large wood mass initially, then
//	approaches a plateau value.  The plateau value can be set very large
//	to give a response of steadily increasing LAI with stemwood.
//
//	References:
//	    1)  Switzer, G.L., L.E. Nelson and W.H. Smith 1968.
//	        The mineral cycle in forest stands.  'Forest
//	        Fertilization:  Theory and Practice'.  pp 1-9
//	        Tenn. Valley Auth., Muscle Shoals, AL.
//	    2)  Gholz, H.L., and F.R. Fisher 1982.  Organic matter
//	        production and distribution in slash pine (Pinus
//	        elliotii) plantations.  Ecology 63(6):  1827-1839.
//	    3)  Gholz, H.L.  1982.  Environmental limits on aboveground
//	        net primary production and biomass in vegetation zones of
//	        the Pacific Northwest.  Ecology 63:469-481.
// ----------------------------------------------------------------------------

#include "TCanopy.h"
#include "AssertEx.h"

float const TCanopy::biomassConversionFactor = 2.5f;

//	SetLAIParameters
//	Set the LAI parameters.
void TCanopy::SetLAIParameters (
	  float const useMaxLAI,	// new maxLAI
	  float const useKLAI,		// new kLAI
	  float const useBiomassToLAI)	// new biomassToLAI
{
	Assert (useBiomassToLAI > 0.0f);

	maxLAI = useMaxLAI;
	kLAI = useKLAI;
	biomassToLAI = useBiomassToLAI;
}

//	LAI
//	Leaf area index calculation.
float TCanopy::LAI (
	float const leafC,	// C in forest leaf component (g/m2)
	float const largeWoodC	// C in forest large wood component (g/m2)
	) const
{
	float lai;	// return value: leaf area index

	const float laiFromLWBiomass =
		maxLAI * largeWoodC / (kLAI + largeWoodC);

	// Choose the LAI reducer on production.
	const float laiFromLeafBiomass =
		leafC * biomassConversionFactor * biomassToLAI;
	if (laiFromLeafBiomass < laiFromLWBiomass)
		lai = (laiFromLeafBiomass + laiFromLWBiomass) * 0.5f;
	else
		lai = laiFromLWBiomass;
	return lai;
}

//--- end of file ---

