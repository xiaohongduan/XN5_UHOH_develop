

/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Rewrite the nmnr.nc netCDF file using COARDS standards */
/* The original file was organized variable(cell, time) */
/* The new file is organized variable(time, lat, lon) */

#include <stdio.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf_ll.h"

    int write_nmnr_ll_(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  gromin_vals[MAXCELLS], strmnr1_vals[MAXCELLS], strmnr2_vals[MAXCELLS],
             metmnr1_vals[MAXCELLS], metmnr2_vals[MAXCELLS], s1mnr1_vals[MAXCELLS],
             s1mnr2_vals[MAXCELLS], s2mnr_vals[MAXCELLS], s3mnr_vals[MAXCELLS],
             wd1mnr_vals[MAXCELLS], wd2mnr_vals[MAXCELLS], wd3mnr_vals[MAXCELLS];
      int status;
      int oldnmnrid;
      int oldgrominid, oldstrmnr1id, oldstrmnr2id, oldmetmnr1id, oldmetmnr2id,
          olds1mnr1id, olds1mnr2id, olds2mnrid, olds3mnrid, oldwd1mnrid,
          oldwd2mnrid, oldwd3mnrid;
      int ii, jj, ngrids;

      /* Open old version of nmnr.nc file */
      status = nc_open("nmnr.nc", NC_NOWRITE, &oldnmnrid);
      if (status != NC_NOERR) handle_error("nc_open(nmnr.nc)", status);

      /* Get the indices for the nmnr output variables */
      status = nc_inq_varid(oldnmnrid, "gromin", &oldgrominid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for gromin",status);
      status = nc_inq_varid(oldnmnrid, "strmnr1", &oldstrmnr1id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for strmnr1",status);
      status = nc_inq_varid(oldnmnrid, "strmnr2", &oldstrmnr2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for strmnr2",status);
      status = nc_inq_varid(oldnmnrid, "metmnr1", &oldmetmnr1id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for metmnr1",status);
      status = nc_inq_varid(oldnmnrid, "metmnr2", &oldmetmnr2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for metmnr2",status);
      status = nc_inq_varid(oldnmnrid, "s1mnr1", &olds1mnr1id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for s1mnr1",status);
      status = nc_inq_varid(oldnmnrid, "s1mnr2", &olds1mnr2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for s1mnr2",status);
      status = nc_inq_varid(oldnmnrid, "s2mnr", &olds2mnrid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for s2mnr",status);
      status = nc_inq_varid(oldnmnrid, "s3mnr", &olds3mnrid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for s3mnr",status);
      status = nc_inq_varid(oldnmnrid, "wd1mnr", &oldwd1mnrid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wd1mnr",status);
      status = nc_inq_varid(oldnmnrid, "wd2mnr", &oldwd2mnrid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wd2mnr",status);
      status = nc_inq_varid(oldnmnrid, "wd3mnr", &oldwd3mnrid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wd3mnr",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        gromin_vals[ii] = fill;
        strmnr1_vals[ii] = fill;
        strmnr2_vals[ii] = fill;
        metmnr1_vals[ii] = fill;
        metmnr2_vals[ii] = fill;
        s1mnr1_vals[ii] = fill;
        s1mnr2_vals[ii] = fill;
        s2mnr_vals[ii] = fill;
        s3mnr_vals[ii] = fill;
        wd1mnr_vals[ii] = fill;
        wd2mnr_vals[ii] = fill;
        wd3mnr_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the nmnr output file */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldnmnrid, oldgrominid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for gromin",status);
            }
            gromin_vals[jj] = val;
            status = nc_get_var1_float(oldnmnrid, oldstrmnr1id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for strmnr1",status);
            }
            strmnr1_vals[jj] = val;
            status = nc_get_var1_float(oldnmnrid, oldstrmnr2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for strmnr2",status);
            }
            strmnr2_vals[jj] = val;
            status = nc_get_var1_float(oldnmnrid, oldmetmnr1id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for metmnr1",status);
            }
            metmnr1_vals[jj] = val;
            status = nc_get_var1_float(oldnmnrid, oldmetmnr2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for metmnr2",status);
            }
            metmnr2_vals[jj] = val;
            status = nc_get_var1_float(oldnmnrid, olds1mnr1id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for s1mnr1",status);
            }
            s1mnr1_vals[jj] = val;
            status = nc_get_var1_float(oldnmnrid, olds1mnr2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for s1mnr2",status);
            }
            s1mnr2_vals[jj] = val;
            status = nc_get_var1_float(oldnmnrid, olds2mnrid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for s2mnr",status);
            }
            s2mnr_vals[jj] = val;
            status = nc_get_var1_float(oldnmnrid, olds3mnrid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for s3mnr",status);
            }
            s3mnr_vals[jj] = val;
            status = nc_get_var1_float(oldnmnrid, oldwd1mnrid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wd1mnr",status);
            }
            wd1mnr_vals[jj] = val;
            status = nc_get_var1_float(oldnmnrid, oldwd2mnrid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wd2mnr",status);
            }
            wd2mnr_vals[jj] = val;
            status = nc_get_var1_float(oldnmnrid, oldwd3mnrid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wd3mnr",status);
            }
            wd3mnr_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(nmnrll_ncid, grominll_id, start, count, gromin_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for gromin",status);
        status = nc_put_vara_float(nmnrll_ncid, strmnr1ll_id, start, count, strmnr1_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for strmnr1",status);
        status = nc_put_vara_float(nmnrll_ncid, strmnr2ll_id, start, count, strmnr2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for strmnr2",status);
        status = nc_put_vara_float(nmnrll_ncid, metmnr1ll_id, start, count, metmnr1_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for metmnr1",status);
        status = nc_put_vara_float(nmnrll_ncid, metmnr2ll_id, start, count, metmnr2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for metmnr2",status);
        status = nc_put_vara_float(nmnrll_ncid, s1mnr1ll_id, start, count, s1mnr1_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for s1mnr1",status);
        status = nc_put_vara_float(nmnrll_ncid, s1mnr2ll_id, start, count, s1mnr2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for s1mnr2",status);
        status = nc_put_vara_float(nmnrll_ncid, s2mnrll_id, start, count, s2mnr_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for s2mnr",status);
        status = nc_put_vara_float(nmnrll_ncid, s3mnrll_id, start, count, s3mnr_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for s3mnr",status);
        status = nc_put_vara_float(nmnrll_ncid, wd1mnrll_id, start, count, wd1mnr_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wd1mnr",status);
        status = nc_put_vara_float(nmnrll_ncid, wd2mnrll_id, start, count, wd2mnr_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wd2mnr",status);
        status = nc_put_vara_float(nmnrll_ncid, wd3mnrll_id, start, count, wd3mnr_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wd3mnr",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldnmnrid);

      return 0;
    }
