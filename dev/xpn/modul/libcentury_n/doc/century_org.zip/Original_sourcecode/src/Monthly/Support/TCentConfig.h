#ifndef INC_TCentConfig_h
#define INC_TCentConfig_h
// ----------------------------------------------------------------------------
//	Copyright (c) 2001-2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCentConfig.h
//	Class:	  TCenturyConfig
//
//	Description:
//	Class which initializes a configuration set for class TCentury.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, July 2001
//	History:
//	Oct01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Changed class name from TCentDefaultSetup to TCenturyConfig.
//	Jul02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added flag indicating if output files should be created.
//	Apr2003	Tom Hilinski
//	* Added constructor argument for "textdata".
//	Sep03	Tom Hilinski
//	* Refactored to inherit TCenturyConfigBase.
//	Feb04	Tom Hilinski
//	* InitializeParamDBList modified to use fix.100 file name, if provided.
//	Feb05	Tom Hilinski
//	* Added fixFile initialization to the constructor.
//	Mar05	Tom Hilinski
//	* Moved error flags and associated functions to the base class.
//	* Moved "use" mgmt to the base class.
//	* Moved InitializeParamDBList to base class.
//	Aug05	Tom Hilinski
//	* Replaced constructor args accepting char* by std::string &
//	* param path is now a list of paths to be used by class TEventDBList.
//	* Moved BuildOutputFileName to parent class.
// ----------------------------------------------------------------------------
//	Notes:
//	1. If any of the input arguments are empty, default values are
//	   provided.
// ----------------------------------------------------------------------------
//	To Do:
//	- Further refactoring of TCenturyConfig and TDailyCenturyConfig
//	  to add common data/functions into the common base class.
// ----------------------------------------------------------------------------

#include "TCenturyConfigBase.h"
#include "TMCSiteParameters.h"
#include "TMCSiteParamInfo.h"

class TCenturyConfig
	: public TCenturyConfigBase<TMCSiteParameters, TMCSiteParamInfo>
{
  public:
	//---- types
	typedef TCenturyConfigBase<TMCSiteParameters, TMCSiteParamInfo>
		TMyBase;

	//---- constructors and destructor
	explicit TCenturyConfig (
	  std::string const & useSiteFile,		// site file name
	  std::string const & useMgmtFile,		// management file name
	  std::string const & useOutputFile,		// output file
	  TOutputBase::TOutputType useOutputType,	// file format type
	  TOutputBase::TAccessMode useAccess,		// file access mode
	  bool const useDoOutput,			// false if no output
	  std::string const & useCentHomePath,		// home or "exe" path
	  std::string const & useWorkPath,	 	// path to work files
	  std::string const & useParamPath,		// path to parameters
	  TStringArray const & useParamPathList,	// parameter file search
	  std::string const & useTemplatePath,		// path to templates
	  std::string const & useTextDataPath,		// path to text data
	  std::string const & useFixFile,		// path/name to fix.100
	  std::string const & useUserName,		// user name
	  TAsynchCommunication const * const useAsynchCom);	// asynch. com.
	TCenturyConfig (			// copy constr.
	  TCenturyConfig const & object)
	  : TMyBase (object)
	  {
	    Copy (object);
	  }
	~TCenturyConfig ()
	  {
	  }
	virtual TCenturyConfig * const Clone () const	// Clone this
	  { return new TCenturyConfig (*this); }

	//---- operator overloads
	TCenturyConfig& operator= (
	  TCenturyConfig const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	TMyBase::operator= (object);
	    	Clear ();
		Copy (object);
	    }
	    return *this;
	  }

	//---- functions: Modify data
	using TMyBase::UseSite;
	TCentException::TCEIndex UseOutputFile (	// Use output file
	  std::string const & useOutputFile,		//   output file name
	  TOutputBase::TOutputType useOutputType,	//   file format type
	  TOutputBase::TAccessMode useAccess);		//   file access mode

	//---- functions: Access

	//---- functions: Queries

  protected:
	//---- constants

	//---- data

	//---- functions
	void Copy (				// Copy to this
	  TCenturyConfig const & object);
	void SetWorkPath ();			// Initialize work path

  private:
	//---- constants
	// subdirectory for monthly century
	static char const * const mcSubdirectory;

	//---- data

	//---- functions
	void ConstructMe (				// Common constructor
	  std::string const & useSiteFile,		// site file name
	  std::string const & useMgmtFile,		// management file name
	  std::string const & useOutputFile,		// output file
	  TOutputBase::TOutputType useOutputType,	// file format type
	  TOutputBase::TAccessMode useAccess,		// file access mode
	  TAsynchCommunication const * const useAsynchCom);	// asynch. com.

};

#endif // INC_TCentConfig_h
