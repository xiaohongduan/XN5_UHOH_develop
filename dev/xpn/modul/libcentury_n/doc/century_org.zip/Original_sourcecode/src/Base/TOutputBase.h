#ifndef INC_TOutputBase_h
#define INC_TOutputBase_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TOutputBase.h
//	Class:	  TOutputBase
//
//	Description:
//	Base class for model output.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Sep 2001
//	History:
//	Sep03	Tom Hilinski
//	* Added Reset function to allow re-initialization of the output
//	  from the model configuration or controller.
//	Aug05	Tom Hilinski
//	* Minor refactoring.
// ----------------------------------------------------------------------------

class TOutputBase
{
  public:
	//---- types
	enum TState			// Output engine state:
	{
		State_Unknown,		// unknown state
		State_NotInitialized,	// not initialized
		State_Initialized,	// is initialized
		State_Open,		// is open for output
		State_Closed,		// has been closed
		State_EndOfList		// last item always!
	};
	enum TOutputType		// output type
	{
		Type_Unknown,		// unknown output type
		Type_Text,		// Text file
		Type_CSV,		// ASCII comma-separated values
		Type_NetCDF,		// netCDF
		Type_HDF,		// HDF
		Type_XML,		// XML
		Type_Native,		// Native binary format
		Type_EndOfList		// last item always!
	};
	enum TAccessMode		// File access modes
	{
		Mode_Unknown,	// unknown access mode
		Mode_New,	// new file; fails if already exists
		Mode_Replace,	// replace existing file, or creates new file
		Mode_Append,	// append to file; creates if doesn't exist
		Mode_EndOfList	// last item always!
	};
	enum TFileFormat		// File format types
	{
		Format_Unknown,		// unknown format
		Format_Binary,		// binary
		Format_CommaDelim,	// comma-delimited ("CSV" files)
		Format_SpaceDelim,	// space-delimited ("PRN" files)
		Format_TabDelim,	// tab-delimited
		Format_Native,		// format is native to type
		Format_EndOfList	// last item always!
	};
	enum TError			// Error flags
	{
		Error_NoError, 		// no error - FIRST ITEM ALWAYS
		Error_InvalidType,	// invalid type
		Error_InvalidAccess,	// invalid access mode
		Error_InvalidFormat,	// invalid file format type
		Error_InvalidFile, 	// invalid file or file name
		Error_OpenFailed, 	// could not open the file
		Error_CloseFailed,	// could not close the file
		Error_ReadFailed,	// last read failed
		Error_WriteFailed,	// last write failed
		Error_MemoryAlloc,	// memory allocation error
		Error_NoOutVarInfo,	// unable to access output var info
		Error_UnknownError	// unknown error - LAST ITEM ALWAYS
	};

	//---- constructors and destructor
  protected:
	TOutputBase (
	  TOutputType const useOutputType,
	  TAccessMode const useAccessMode,
	  TFileFormat const useFileFormat = Format_Unknown)
	  : state (State_NotInitialized),
	    outputType (useOutputType),
	    accessMode (useAccessMode),
	    fileFormat (useFileFormat),
	    errorState (Error_NoError)
	  {
	    Initialize ();
	  }
	TOutputBase (
	  TOutputBase const & object)
	  : outputType (object.outputType)
	  {
	    Initialize ();
	    Copy (object);
	  }
  public:
	virtual ~TOutputBase () = 0;

	//---- operator overloads
	TOutputBase& operator= (TOutputBase const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
		Copy (object);
	    }
	    return *this;
	  }
	bool operator== (TOutputBase const & object) const
	  {
	    return outputType == object.outputType &&
	    	   accessMode == object.accessMode;
	  }
	bool operator!= (TOutputBase const & object) const
	  { return !(*this == object); }

	//---- functions
	TState Open ()				// Open the output engine
	  {					//   State_Open if successful
	    return DoOpen (); // virtual
	  }
	TState Close ()				// Close the output engine
	  {					//   State_Closed if successful
	    return DoClose (); // virtual
	  }
	TState Reset ()				// Re-init. the output engine
	  {					//   State_Open if successful
	    return DoReset (); // virtual
	  }
	virtual TOutputBase * const Clone () const = 0;	// Clone this

	//---- functions: Queries
	TState GetState () const		// Get output engine state
	  { return state; }
	TOutputType GetOutputType () const	// Get output type
	  { return outputType; }
	TAccessMode GetAccessMode () const	// Get file access mode
	  { return accessMode; }
	TFileFormat GetFormat () const		// Get file format
	  { return fileFormat; }
	TError GetErrorState () const		// Get the error state
	  { return errorState; }
	bool IsEmpty () const			// True if not initialized
	  {
	    return state == State_Unknown ||
		state == State_NotInitialized ||
		outputType == Type_Unknown;
	  }

  protected:
	//---- constants

	//---- data
	TState state;				// output engine state
	TOutputType const outputType;		// output type
	TAccessMode accessMode;			// output access mode
	TFileFormat fileFormat;			// file format
	TError errorState;			// error state

	//---- functions
	void Copy (TOutputBase const & object)	// Copy to this
	  {
	    if ( &object )
	    {
	    	state = State_NotInitialized;
		accessMode = object.accessMode;
		fileFormat = object.fileFormat;
		errorState = Error_NoError;
	    }
	  }

  private:
	//---- constants

	//---- data

	//---- functions
	void Initialize ()				// Initialize members
	  {
	    // set required file format
	    switch (outputType)
	    {
	      case Type_NetCDF:
	      case Type_HDF:
	      case Type_Native:
		fileFormat = Format_Binary;
	      	break;
	      case Type_CSV:
		fileFormat = Format_CommaDelim;
	      	break;
	      case Type_XML:
	      case Type_Text:
		fileFormat = Format_Native;
	      	break;
	      default:
	      	break;
	    }
	  }

	//---- functions: Virtual
	virtual TState DoOpen () = 0;		// Open the output engine
	virtual TState DoClose () = 0;		// Close the output engine
	virtual TState DoReset () = 0;		// Reset the output engine
};

inline TOutputBase::~TOutputBase ()
{
}


#endif // INC_TOutputBase_h
