#ifndef INC_TCenturyFiles_h
#define INC_TCenturyFiles_h

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TCentFiles.h
//	Class:	  TCenturyFiles
//
//	Description:
//	Files used by class TCentury.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jan01
// ----------------------------------------------------------------------------
//	History:
//	Jan01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Made into a real class (was a simple struct).
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added copy constructor, operator=
// ----------------------------------------------------------------------------
//	Copyright 2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include <string>

class TCenturyFiles
{
  public:
	//--- constructor and destructor
	TCenturyFiles ();
	~TCenturyFiles ()
	  { Clear (); }
	TCenturyFiles (TCenturyFiles const & object)	// copy constructor
	  {
	    Copy (object);
	  }

	//---- operator overloads
	TCenturyFiles& operator= (TCenturyFiles const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
		Copy (object);
	    }
	    return *this;
	  }

	//--- functions
	void Clear ();				// Clear member functions
	bool SetWorkPath (			// Set the work folder path
	  char const * useName);		//   use this name
	bool SetWorkPath (			// Set the work folder path
	  std::string const & useName);		//   use this name
	bool SetParamPath (			// Set parameter folder path
	  char const * useName);		//   use this name
	bool SetParamPath (			// Set the work folder path
	  std::string const & useName);		//   use this name
	bool SetTemplatePath (			// Set template folder path
	  char const * useName);		//   use this name
	bool SetTemplatePath (			// Set the work folder path
	  std::string const & useName);		//   use this name
	bool SetOutputName (			// Set output file name
	  char const * useName);		//   use this name
	bool SetOutputName (			// Set the work folder path
	  std::string const & useName);		//   use this name
	bool SetC14Name (			// Set the C14 data file name
	  char const * useName);		//   use this name
	bool SetC14Name (			// Set the work folder path
	  std::string const & useName);		//   use this name

	//--- functions - queries
	std::string const & GetWorkPath () const	// Get the work folder
	  { return (std::string &)workPath; }
	bool HaveWorkPath () const		// True if have work folder
	  { return !workPath.empty(); }
	std::string const & GetParamPath () const // Get the parameter path
	  { return (std::string &)paramPath; }
	bool HaveParamPath () const		// True if have parameter path
	  { return !paramPath.empty(); }
	std::string const & GetTemplatePath () const // Get the template path
	  { return (std::string &)templatePath; }
	bool HaveTemplatePath () const		// True if have template path
	  { return !templatePath.empty(); }
	std::string const & GetOutputName () const // Get the output file name
	  { return (std::string &)outputName; }
	bool HaveOutputName () const		// True if have output name
	  { return !outputName.empty(); }
	char const * const GetC14Name () const	// Get the C14 data file name
	  { return c14Name.c_str(); }
	bool HaveC14FileName () const		// True if have c14 file name
	  { return !c14Name.empty(); }

	//--- data - constants - default values
	static char const* const defaultWorkPath;
	static char const* const defaultParamPath;
	static char const* const defaultTemplatePath;
	static char const* const defaultOutputFileName;
	static char const* const defaultC14FileName;

  private:
	//--- data - paths
	std::string workPath;		// path to current working directory
	std::string paramPath;		// path to parameter files
	std::string templatePath;	// path to template files

	//--- data - file names
	std::string outputName;
	std::string c14Name;

	//--- functions
	void Initialize ();
	void Copy (TCenturyFiles const & object);	// Copy to this
};

#endif // INC_TCenturyFiles_h

