
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include <stdio.h>
/* #include "netcdf.h" */

/* Prototypes */
int	write_crop(float crop[][12]);
int	write_h2o(float h2o[][12]);
int	write_livc(float livc[][12]);
int	write_livn(float livn[][12]);
int	write_nflux(float nflux[][12]);
int	write_nmnr(float nmnr[][12]);
int	write_nupt(float nupt[][12]);
int	write_prod(float prod[][12]);
int	write_resp(float respr[][12]);
int	write_soilc(float soilc[][12]);
int	write_soiln(float soiln[][12]);
int	write_cremv(float C_remv[][12]);
int	write_nremv(float N_remv[][12]);

/* Global Variables */
/* START and COUNT are dimensioned {CELL#, TIME} */
size_t	start[2] = {0, 0}; 
size_t	count[2] = {1, 12}; 
/*
 * START_LAYER and COUNT_LAYER are dimensioned {CELL#, LAYER, TIME} 
 * Layers represent individual variables - so this ordering should 
 * work.
 */
size_t	start_layer[3] = {0, 0, 0};
size_t	count_layer[3] = {1, 1, 12};

/* Write values into NetCDF file */

int
wrtcdf_(int *cellno, float crop[][12], float h2o[][12], float livc[][12],
	float livn[][12], float nflux[][12], float nmnr[][12], 
	float nupt[][12], float prod[][12], float respr[][12], 
        float soilc[][12], float soiln[][12],
        float C_remv[][12], float N_remv[][12])
{
	/* Local Variables */
	int write_err;
	static int prev_cell = 0;

	/* Set NetCDF vectors for beginning location and distance
	 * of write
	 */

        start[0] = *cellno;
	start_layer[0] = *cellno;
	count_layer[1] = 10L;

	if (*cellno > prev_cell)
	{
		start[1] = 0;
		start_layer[2] = 0;
		prev_cell = *cellno;
	}

	write_err = write_crop(crop);
	write_err = write_h2o(h2o);
	write_err = write_livc(livc);
	write_err = write_livn(livn);
	write_err = write_nflux(nflux);
	write_err = write_nmnr(nmnr);
	write_err = write_nupt(nupt);
	write_err = write_prod(prod);
	write_err = write_resp(respr);
	write_err = write_soilc(soilc);
	write_err = write_soiln(soiln);
	write_err = write_cremv(C_remv);
	write_err = write_nremv(N_remv);

	start[1] += 12;
	start_layer[2] += 12;

	return(write_err);
}
