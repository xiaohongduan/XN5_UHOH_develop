// ----------------------------------------------------------------------------
//	Copyright 2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  SiteFileFormat.cpp
//
//	Description:
//	Writes a site parameter file in the format specified.
//---------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, July 2005
//	History:
//	
//---------------------------------------------------------------------------

#include <iostream>
#include <sstream>
#include <exception>
#include <cstring>
#include "fnutil.h"
#include "timeutil.h"

//---------------------------------------------------------------------------
//	About this application
//---------------------------------------------------------------------------
char const * const version = "1.0.0 ";
char const * const versionDate = __DATE__;
char const * const appName =
	"SiteFileFormat";
char const * const copyright =
	"Copyright 2005 Colorado State University. All rights reserved.";
char const * const author =
	"Thomas E. Hilinski";
char const * const department =
	"Natural Resource Ecology Laboratory";
char const * const organization =
	"Colorado State University";
char const * const purpose[] =
{
  "Writes a site parameter file in a specified format",
  "from another site parameter file.",
  0 // last item in list always!
};

//---------------------------------------------------------------------------
//	Display functions
//---------------------------------------------------------------------------

void DisplayAbout (
	std::ostream & os)
{
	os << "\nAbout this application:\n"
	   << "\nName: " << appName
	   << "\nVersion: " << version << ' ' << versionDate
	   << "\nDescription:";

	char const * const * pPurpose = purpose;
	while ( *pPurpose )
		os << "\n  " << *(pPurpose++);

	os << "\nAuthor(s): " << author
	   << "\nOrganization:"
	   << "\n  " << department
	   << "\n  " << organization
	   << "\n  " << copyright
	   << std::endl;
}

void DisplayUsage (
	std::ostream & os,
	char const * const exeName)
{
	os << "\nName: " << appName << " " << version << '\n';

	char const * const * pPurpose = purpose;
	while ( *pPurpose )
		os << '\n' << *(pPurpose++);

	os << "\n\nUsage:\n  "
	   << TEH::basename (exeName)
	   << " [-a -n ] source_file new_file"
	   << "\n\nOptions:"
	   << "\n  -a   new_file is to be in ASCII format"
	   << "\n  -n   new_file is to be in NetCDF format"
	   << "\n\nOptions used alone:"
	   << "\n  -?   Display help"
	   << "\n  -V   Display application information"
	   << std::endl;
}

//---------------------------------------------------------------------------

#pragma argsused
int main (int argc, char* argv[])
{
    //--- handle command-line arguments ---
    // simply done; we'll implement the cmdline class later
    
    // usage
    if ( argc < 4 /* minimum arg count required */ ||
	 strcmp (argv[1], "-?") == 0 )
    {
	::DisplayUsage (std::cout, argv[0] );
	return 1;
    }

    // about
    if ( strcmp (argv[1], "-V") == 0 )		// -V
    {
    	DisplayAbout (std::cout);
	return 0;
    }

    // retrieve args
    short argIndex = 1;
    std::string const formatFlag =
	( argc > argIndex ? argv[ argIndex++ ] : "");
    std::string const inFileName =
	( argc > argIndex ? argv[ argIndex++ ] : "");
    std::string const outFileName =
	( argc > argIndex ? argv[ argIndex++ ] : "");

    try
    {
	// display action information
	std::cout << "\nSource site parameter file:\n  \""
		  << inFileName << '\"'
		  << "\nNew site parameter file:\n  \""
		  << outFileName << '\"'
		  << std::endl;
	if ( formatFlag == "-a" )
	{
		std::cout << "New format is ASCII" << std::endl;
	}
	else if ( formatFlag == "-n" )
	{
		std::cout << "New format is NetCDF" << std::endl;
	}
	else
	{
		std::cout << "\nError: Invalid format flag: "
			  << formatFlag
			  << std::endl;
		return 1;
	}

	// read source file

	// write new file
    }
    catch (std::exception const & e)
    {
	std::cout << "Error: " << e.what() << std::endl;
    }
    catch (...)
    {
	std::cout << "Error: unknown error." << std::endl;
    }

    std::cout << "\n\n   all done!" << std::endl;
    return 0;
}
//---------------------------------------------------------------------------
 