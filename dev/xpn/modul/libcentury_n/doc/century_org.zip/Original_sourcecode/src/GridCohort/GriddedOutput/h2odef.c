
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  h2o_ncid;			/* netCDF id */

/* variable ids */
int  avh2o1_id, avh2o2_id, avh2o3_id, asmos_id, evap_id, 
     pet_id, rwcf_id, snlq_id, snow_id, stemp_id, stream1_id, 
     stream2_id, stream5_id, stream6_id, tran_id, runo_id;

int
h2odef(int *ntimes, char *history) {			/* create h2o.nc */

   int status;

   /* dimension ids */
   int  layer_dim = 0;
   int  time_dim = 0;
   int  cell_dim = 0;

   /* variable shapes */
   int dims[3];

   /* enter define mode */
   status = nc_create("h2o.nc", NC_CLOBBER, &h2o_ncid);
   if (status != NC_NOERR) handle_error("nc_create(h2o.nc)", status);

   /* define dimensions */
   status = nc_def_dim(h2o_ncid, "layer", 10L, &layer_dim);
   status = nc_def_dim(h2o_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(h2o_ncid, "cell", NC_UNLIMITED, &cell_dim);

   /* define variables */

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "avh2o1", NC_FLOAT, 2, dims, &avh2o1_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "avh2o2", NC_FLOAT, 2, dims, &avh2o2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "avh2o3", NC_FLOAT, 2, dims, &avh2o3_id);

   dims[0] = cell_dim;
   dims[1] = layer_dim;
   dims[2] = time_dim;
   status = nc_def_var (h2o_ncid, "asmos", NC_FLOAT, 3, dims, &asmos_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "evap", NC_FLOAT, 2, dims, &evap_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "pet", NC_FLOAT, 2, dims, &pet_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "rwcf", NC_FLOAT, 2, dims, &rwcf_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "snlq", NC_FLOAT, 2, dims, &snlq_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "snow", NC_FLOAT, 2, dims, &snow_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "stemp", NC_FLOAT, 2, dims, &stemp_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "stream1", NC_FLOAT, 2, dims, &stream1_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "stream2", NC_FLOAT, 2, dims, &stream2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "stream5", NC_FLOAT, 2, dims, &stream5_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "stream6", NC_FLOAT, 2, dims, &stream6_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "tran", NC_FLOAT, 2, dims, &tran_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (h2o_ncid, "runoff", NC_FLOAT, 2, dims, &runo_id);

   /* assign attributes */
   status = nc_put_att_text (h2o_ncid, NC_GLOBAL, "history", strlen(history), history);
   status = nc_put_att_text (h2o_ncid, avh2o1_id, "long_name", 
	strlen("growth_h2o"), "growth_h2o");
   status = nc_put_att_text (h2o_ncid, avh2o1_id, "units", 
	strlen("cm"), "cm");
   status = nc_put_att_text (h2o_ncid, avh2o2_id, "long_name", 
	strlen("survival_h2o"), "survival_h2o");
   status = nc_put_att_text (h2o_ncid, avh2o2_id, "units", strlen("cm"), "cm");
   status = nc_put_att_text (h2o_ncid, avh2o3_id, "long_name", 
	strlen("2_layer_h2o"), "2_layer_h2o");
   status = nc_put_att_text (h2o_ncid, avh2o3_id, "units", strlen("cm"), "cm");
   status = nc_put_att_text (h2o_ncid, asmos_id, "long_name", 
	strlen("soil_h2o"), "soil_h2o");
   status = nc_put_att_text (h2o_ncid, asmos_id, "units", strlen("cm"), "cm");
   status = nc_put_att_text (h2o_ncid, evap_id, "long_name", 
	strlen("evaporation"), "evaporation");
   status = nc_put_att_text (h2o_ncid, evap_id, "units", strlen("cm/mo"), "cm/mo");
   status = nc_put_att_text (h2o_ncid, pet_id, "long_name", 
	strlen("pot_evapotranspiration"), "pot_evapotranspiration");
   status = nc_put_att_text (h2o_ncid, pet_id, "units", strlen("cm/mo"), "cm/mo");
   status = nc_put_att_text (h2o_ncid, rwcf_id, "long_name", 
	strlen("relative_water_content"), "relative_water_content");
   status = nc_put_att_text (h2o_ncid, rwcf_id, "units", strlen("unitless"), "unitless");
   status = nc_put_att_text (h2o_ncid, snlq_id, "long_name", 
	strlen("liquid_h2o_snow"), "liquid_h2o_snow");
   status = nc_put_att_text (h2o_ncid, snlq_id, "units", strlen("cm"), "cm");
   status = nc_put_att_text (h2o_ncid, snow_id, "long_name", 
	strlen("snow"), "snow");
   status = nc_put_att_text (h2o_ncid, snow_id, "units", strlen("cm"), "cm");
   status = nc_put_att_text (h2o_ncid, stemp_id, "long_name", 
	strlen("soil_temperature"), "soil_temperature");
   status = nc_put_att_text (h2o_ncid, stemp_id, "units", strlen("cm"), "cm");
   status = nc_put_att_text (h2o_ncid, stream1_id, "long_name", 
	strlen("stream_flow"), "stream_flow");
   status = nc_put_att_text (h2o_ncid, stream1_id, "units", strlen("cm/mo"), "cm/mo");
   status = nc_put_att_text (h2o_ncid, stream2_id, "long_name", 
	strlen("N_inorganic_leaching_flow"), "N_inorganic_leaching_flow");
   status = nc_put_att_text (h2o_ncid, stream2_id, "units", 
	strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (h2o_ncid, stream5_id, "long_name", 
	strlen("C_organic_leaching_flow"), "C_organic_leaching_flow");
   status = nc_put_att_text (h2o_ncid, stream5_id, "units", 
	strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (h2o_ncid, stream6_id, "long_name", 
	strlen("N_organic_leaching_flow"), "N_organic_leaching_flow");
   status = nc_put_att_text (h2o_ncid, stream6_id, "units", 
	strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (h2o_ncid, tran_id, "long_name", 
	strlen("transpiration"), "transpiration");
   status = nc_put_att_text (h2o_ncid, tran_id, "units", strlen("cm/mo"), "cm/mo");
   status = nc_put_att_text (h2o_ncid, runo_id, "long_name", 
	strlen("runoff"), "runoff");
   status = nc_put_att_text (h2o_ncid, runo_id, "units", strlen("cm/mo"), "cm/mo");

   /* leave define mode */
   status = nc_enddef (h2o_ncid);
   return 0;
}
