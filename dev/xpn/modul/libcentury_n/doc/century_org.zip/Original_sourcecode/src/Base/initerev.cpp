// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  initerev.cpp
//	Class:	  TCenturyBase
//	Function: InitErosionEvent, InitDepositionEvent
//
//	Description:
//	Initialize for an erosion or deposition event.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec98
//	History:
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "util.h"
#include <sstream>

//	InitErosionEvent
//	Initialize for an erosion event. Make sure lower layer and erosion
//	class instances are available.
//	Returns false if event is initialized, else true.
MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::InitErosionEvent (
	char const* eventInfo)	// "additional information" field of event
{
	bool retVal = false;

	//--- initialize lower sim. layer and erosion instances
	if ( !lowerSoil.get() )			// lower soil instance?
		InitializeLowerLayer ();	// ...make one
	if ( !erosion.get() )			// erosion instance?
	{
	    erosion.reset ( new TErosion (site, *soil, *lowerSoil,
					soilC, nps, water,
					wt, *flows.get(),
					ISOS, site.nelem,
					GetManagement()->GetSimDescription(),
					GetManagement()->GetBaseName(),
					GetSite()->GetDescription().c_str(),
					GetSite()->GetBaseName().c_str(),
					userName.c_str() ) );
	    // TO DO: need error checks- is erosion instance OK?

	    // retrieve the erosion file, if specified
	    if ( GetManagement()->GetSimInfo().erosionFileName ) // file name?
	    {
		std::string const fileName =
		  GetManagement()->GetSimInfo().erosionFileName->GetFullName();
		if ( !fileName.empty() )		// have a name?
		{
			// give name to erosion instance, and check for error
			if ( erosion->UseErosionFile (fileName) )
			{
				ThrowCentException ( TCentException::CE_IEROFN,
						     fileName.c_str() );
			}
		}
	    }
	}

	//--- extract values from the eventInfo string
	// 1. check if a valid rate and enrichment factor is specified
	// Borland C++ 5.02 doesn't accept const chars in strstreams! boo hiss
	float rate = 0.0f;			// erosion rate  kg m-2
	float ef = 1.0f;			// enrichment factor
	float const minFloat = 1.0e-30f;	// minimum positive float value
	std::istringstream is (eventInfo);
	if ( !is )
		goto error_rate;
	if ( is >> rate )			// extract rate OK?
	{
		if ( rate >= minFloat )			// valid rate?
		{
			Assert (rate <= 20.0f);		// kg m-2; not too much!
			erosion->SetRate (rate);	// save it
		}
		else					// invalid rate
			goto error_rate;
		if ( is >> ef )				// extract ef OK?
		{
			if ( ef >= MINEF && ef <= MAXEF )	// valid?
				erosion->SetEnrichFactor (ef);	// save it
		}
	}
	// 2. otherwise an error
	else
		goto error_rate;

	return retVal;

error_rate:
	std::ostringstream os;
	os << "year " << st->year
	   << ", month " << (short)st->month
	   << '\n'
	   << ", additional info " << eventInfo;
	ThrowCentException (TCentException::CE_IREROD,
				os.str().c_str() );
}

//	InitDepositionEvent
//	Initialize for an deposition event. Make sure lower layer and
//	deposition class instances are available.
//	Returns false if event is initialized, else true.
MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::InitDepositionEvent ()
{
	bool retVal = false;

	//--- initialize lower sim. layer and deposition instances
	if ( !lowerSoil.get() )			// lower soil instance?
		InitializeLowerLayer ();	// ...make one
	if ( !deposition.get() )		// deposition instance?
	{
	    deposition.reset ( new TDeposition (site, *soil, *lowerSoil,
					soilC, nps, water,
					wt, *flows.get(),
					ISOS, site.nelem ));

	    // retrieve the deposition file, if specified
	    if ( GetManagement()->GetSimInfo().depoFileName )	// file name?
	    {
		std::string const fileName =
		  GetManagement()->GetSimInfo().depoFileName->GetFullName ();
		if ( !fileName.empty() )		// have a name?
		{
			// give name to deposition instance and check for error
			if ( deposition->UseDepositionFile (fileName) ||
			     !deposition->HaveDepositFile () )
				ThrowCentException (
					TCentException::CE_IDEPFN,
					fileName.c_str() );
		}
	    }
	    else
		ThrowCentException (TCentException::CE_DEPNEF, 0);
	}
	return retVal;
}

//--- end of file initerev.cpp ---

