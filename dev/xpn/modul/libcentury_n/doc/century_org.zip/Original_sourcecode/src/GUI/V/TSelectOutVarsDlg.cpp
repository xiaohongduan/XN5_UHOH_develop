// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TSelectOutVarsDlg.h
//	Class:	  TSelectOutVarsDlg
//
//	Description:
//	Class for dialog to select output variables for view/plot/export.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Sep98
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TSelectOutVarsDlg.h"
#include "TMCOutVarInfo.h"
#include "charutil.h"
#include <v/vicon.h>
#include <v/vapp.h>
#include <v/vutil.h>
#include <v/vnotice.h>
// netCDF C++ interface
#include "netcdf.hh"
// STL
#include <algorithm>

// ----------------------------------------------------------------------------
//	icons
// ----------------------------------------------------------------------------
#include "left.vbm"
static vIcon leftArrowIcon ( &left_bits[0], left_height, left_width, 1 );
#include "right.vbm"
static vIcon rightArrowIcon ( &right_bits[0], right_height, right_width, 1 );

// ----------------------------------------------------------------------------
//	local variables
// ----------------------------------------------------------------------------

static char* dummyList[] = { NULL };	// empty list for list boxes
static char *toolTips[] =		// tool tips text
{
	// 0 = Combobox: categories
	"Select the output variable category from this list.",
	// 1 = List: source of results
	"Select the source of the output variables from this list.",
	// 2 = Button: Browse for source
	"Browse for and add results files to the source list.",
	// 3 = List: available variables
	"Select the output variables to extract.",
	// 4 = Description of the highlighted variable in the available list
	"Description of the highlighted output variable.",
	// 5 = Button: right arrow to "selected" list
	"Copy the highlighted variable name into the Selected list.",
	// 6 = Button: left arrow from "selected" list
	"Remove the highlighted variable name from the Selected list.",
	// 7 = OK button
	"Press when you have completed your selection of variables.",
	// 8 = Cancel button
	"Cancel this selection.",
	// 9 = Help button
	"Help on making selections.",
	// 10 = List: selected variables
	"List of variables you have selected.",
	// 11 = Clear the selected variables list
	"Removes all items from the list of selected variables.",
	// 12 = move up button
	"Moves the highlighted item up one position.",
	// 13 = move down button
	"Moves the highlighted item down one position.",
	// 14 = simulation description
	"Simulation description stored in the selected output file.",
	// last item always
	NULL
};

// ----------------------------------------------------------------------------
//	static member variables
// ----------------------------------------------------------------------------

CommandObject TSelectOutVarsDlg::cmdList[] =
{
	//--- Available sources for output variables
	{C_Frame, 105, 0, "", NoList, CA_NoBorder, isSens, NoFrame, 0, 101},
	{C_Label, 301, 0, "Available Century Output Files:",
		NoList, CA_None, isSens, 105, 0, 0},
	{C_Button, D_AddOutFile, D_AddOutFile, "Add Output File...",
		NoList,	CA_None, notSens, 105, 0, 301, 0, toolTips[2]},
	{C_List, D_ResultsSource, 280, "", NoList,
		CA_Size | CA_ListWidth, isSens, 105, 301, 0, 5, toolTips[1]},
	{C_Label, 505, 0, "Simulation Description:",
		NoList, CA_None, isSens, 105, 301, D_ResultsSource},
	{C_Text, D_SimDescrip, 0, "", NoList, CA_NoBorder, isSens,
		105, 301, 505, 280, toolTips[14]},

	//--- Categories and list of output variables
	{C_Frame, 101, 0, "", NoList, CA_NoBorder, isSens, NoFrame, 0, 105},
	{C_Label, 201, 0, "Category and Variable:",
		NoList, CA_None, isSens, 101, 0, 0},
	{C_ComboBox, D_Categories, 0, "", dummyList,
		CA_None, isSens, 101, 0, 201, 90, toolTips[0]},
	{C_Blank, 901, 0, " ", NoList, CA_None, notSens,
		101, 0, D_Categories, 18},
	{C_List, D_AvailableVars, 70, "", NoList, CA_ListWidth | CA_Size,
		isSens, 101, 901, D_Categories, 12, toolTips[3]},

	//--- Buttons to transfer between lists
	{C_Frame, 110, 0, "", NoList, CA_NoBorder, isSens, NoFrame,
		101, D_Categories},
	{C_IconButton, D_ToSelected, D_ToSelected, "",
		(void*)&rightArrowIcon, CA_None, isSens, 110, 0, 0,
		0, toolTips[6]},
	{C_IconButton, D_FromSelected, D_FromSelected, "",
		(void*)&leftArrowIcon, CA_None, notSens, 110, 0, D_ToSelected,
		0, toolTips[5]},

	//--- Selected output variables
	{C_Frame, 115, 0, "", NoList, CA_NoBorder, isSens, NoFrame, 110, 105},
	{C_Label, 401, 0, "Selected Variables:",
		NoList, CA_None, isSens, 115, 0, 0},
	{C_List, D_SelectedVars, 270, "", NoList,
		CA_Size | CA_ListWidth, isSens, 115, 0, 401, 12, toolTips[10]},
	{C_Button, D_ClearSelected, D_ClearSelected, "Clear List",
		NoList,	CA_None, notSens, 115, 0, D_SelectedVars,
		0, toolTips[11]},
	{C_Button, D_MoveItemUp, D_MoveItemUp, " Move Up  ",
		NoList,	CA_None, notSens, 115, D_ClearSelected, D_SelectedVars,
		0, toolTips[12]},
	{C_Button, D_MoveItemDown, D_MoveItemDown, "Move Down ",
		NoList,	CA_None, notSens, 115, D_MoveItemUp, D_SelectedVars,
		0, toolTips[13]},

	//--- Description of the highlighted variable
	{C_Frame, 120, 0, "", NoList, CA_NoBorder, isSens, NoFrame, 0, 115},
	{C_Label, 501, 0, "Variable Description:",
		NoList, CA_None, isSens, 120, 0, 0},
	{C_Text, D_VarDescrip, 0, "\n",
		NoList, CA_NoBorder, isSens, 120, 0, 501, 340, toolTips[4]},

	//--- Common Buttons
	{C_Button, M_OK, M_OK, "  &OK   ",
		NoList,	CA_DefaultButton, isSens, NoFrame, 0, 120,
		0, toolTips[7]},
	{C_Button, M_Cancel, M_Cancel, " &Cancel",
		NoList,	CA_None, isSens, NoFrame, M_OK, 120,
		0, toolTips[8]},
	{C_Button, M_Help, M_Help, "  &Help ",
		NoList,	CA_None, isSens, NoFrame, M_Cancel, 120,
		0, toolTips[9]},

	//--- Last one always!
	{C_EndOfList, 0, 0, 0, 0, CA_None, 0, 0}
};

// ----------------------------------------------------------------------------
//	methods
// ----------------------------------------------------------------------------

//--- constructors and destructor

TSelectOutVarsDlg::TSelectOutVarsDlg (vApp* const parent,
	TEH::TFileName const & useVarDefFilePath,   // variable definitions file
	TEH::TFileName const ** const useWorkPaths, // working directory paths
						    // (null-term. list of ptrs.)
	char const* const title)		// dialog title
	: TModalDlg ( parent, title ),
	  workPaths (useWorkPaths)		// save ptr to paths
{
	char const* errDlgTitle = "Error: Output Variables Selection Dialog";
	char const* errorText;

	//--- member initialize variables
	Initialize ();

	//--- retrieve the variable definitions
	if ( !useVarDefFilePath.IsEmpty() )
	{
		info = new TMCOutputVariableInfo ( useVarDefFilePath );
		if ( info->IsEmpty() )
		{
			errorText =
				"Unable to retrieve the variable definitions.";
			goto error_handling;
		}
	}
	else	// no file name supplied
	{
		errorText = "A file name for the variable definitions\n"
			    "was not specified";
		goto error_handling;
	}

	//--- get the output file list from the work directory paths
	if ( workPaths && *workPaths && !(*workPaths)->IsEmpty() )
	{
		// count the number of paths
		short count = 0;
		const TEH::TFileName** p = workPaths;
		while ( *(p++) )
			++count;

		// convert paths to string list
		char const** pathList = new char const* [count + 1];
		pathList[count] = 0;			// null-term the list
		for ( short i = 0; i < count; i++ )
		{
			std::string fullPath = workPaths[i]->GetFullPath();
			char * const fullPathCStr =
				new char [ fullPath.size() + 1 ];
			strcpy ( fullPathCStr, fullPath.c_str() );
			pathList[i] = fullPathCStr;
		}

		// create instance of TNcFileList
		srcList = new TNcFileList (pathList, NCFT_CenturyOutput);
		if ( srcList->IsEmpty() )
		{
			errorText = "Unable to find any Century output files\n"
				    "in the locations specified.";
			goto error_handling;
		}
		BuildSimDescList ();	// list of simulation descriptions

		// all done!
		::DeleteNTCStringList ( const_cast<char**>(pathList) );
	}
	else
	{
		errorText = "A list of directories in which to search for\n"
			    "Century output files was not specified";
		goto error_handling;
	}

	// set initial sizes of vectors
	indexSelected.reserve ( srcList->GetCount() * 5 );
	selectedList.reserve (50);

	//--- display dialog
	AddDialogCmds ((CommandObject*)cmdList);	// add dialog controls
	ItemVal retVal;
	ShowModalDialog (const_cast<char*>(title), retVal);  // display it now

	//--- return data
	return;

	//--- error handling
error_handling:
	vNoticeDialog dlg ( const_cast<vApp*>(parent),
			    const_cast<char*>(errDlgTitle) );
	dlg.Notice ( const_cast<char*>(errorText) );
	return;
}

TSelectOutVarsDlg::~TSelectOutVarsDlg ()
{
	// first, make sure all lists are pointing to NULL
	cmdList[idxCategoryList].itemList = (void *)dummyList;
	SetValue (D_Categories, 0, ChangeListPtr);
	cmdList[idxSourceList].itemList = (void *)dummyList;
	SetValue (D_ResultsSource, 0, ChangeListPtr);
	cmdList[idxAvailList].itemList = (void *)dummyList;
	SetValue (D_AvailableVars, 0, ChangeListPtr);
	cmdList[idxSelectList].itemList = (void *)dummyList;
	SetValue (D_SelectedVars, 0, ChangeListPtr);

	// delete class members' memory
	Clear ();
}


//--- functions overridden

void TSelectOutVarsDlg::DialogDisplayed ()
{
	TModalDlg::DialogDisplayed ();
	LoadDlg ();				// load data into dialog
}

void TSelectOutVarsDlg::DialogCommand (ItemVal id, ItemVal val, CmdType type)
{
	switch (id)
	{
	  case D_Categories:	// combo list: categories
		Evt_Category ();
		break;
	  case D_AvailableVars:	// list: available variables for category
		Evt_AvailableVars ();
		break;
	  case D_ResultsSource:	// list: available sources of output
	  	Evt_Source ();
	  	break;
	  case D_ToSelected:	// button: right arrow to "selected" list
		Evt_ToSelected ();
		break;
	  case D_FromSelected:	// button: left arrow from "selected" list
		Evt_FromSelected ();
		break;
	  case D_AddOutFile:	// button: browse for files to add to list
		Evt_AddOutFile ();
		break;
	  case D_SelectedVars:	// list: selected variables
	  	Evt_SelectedVars ();
	  	break;
	  case D_ClearSelected:	// button: clear the "selected" list
	  	Evt_ClearSelected ();
		break;
	  case D_MoveItemUp:	// move highlighted item up in sekected list
		Evt_MoveItemUp ();
		break;
	  case D_MoveItemDown:	// move highlighted item down in selected list
	  	Evt_MoveItemDown ();
		break;
	  case M_OK:		// button: OK
		break;
	  case M_Help:			// "help" button
		//::HelpDisplay (::myApp.winHwnd(), ::helpPath,
		//	   HELP_CONTEXT, IDH_SelOutVars_Dlg);
		break;
	  default:
	  	break;
	};
	// Default event processing
	TModalDlg::DialogCommand (id, val, type);
}


//--- public functions

//	GetOutputFileNames
//	Return the output file list
/*inline*/
const TNcFileList* TSelectOutVarsDlg::GetOutputFileNames ()
{
	return srcList;
}

//	GetIndicesList
//	Return the selection indices
/*inline*/
const TSelectOutVarsDlg::TSelIndexList& TSelectOutVarsDlg::GetIndicesList ()
{
	return indexSelected;
}

//	GetOutputVarInfo
//	Return the output variables names and descriptions.
/*inline*/
const TMCOutputVariableInfo* TSelectOutVarsDlg::GetOutputVarInfo ()
{
	return info;
}


//--- private functions

//	Initialize
// 	initialize members
void TSelectOutVarsDlg::Initialize ()
{
	// member variables
	info = 0;
	srcList = 0;
	selectedStrList = 0;
	simDescList = 0;
	// indicies to lists in CommandObject array
	idxCategoryList = (short) vGetcmdIdIndex (D_Categories, cmdList);
	idxSourceList = (short) vGetcmdIdIndex (D_ResultsSource, cmdList);
	idxAvailList = (short) vGetcmdIdIndex (D_AvailableVars, cmdList);
	idxSelectList = (short) vGetcmdIdIndex (D_SelectedVars, cmdList);
}

//	Clear
// 	clear member data, except varDefFilePath and workPaths
void TSelectOutVarsDlg::Clear ()
{
	// output variables source files list
	cmdList[idxSourceList].itemList = (void*) dummyList;
	SetValue (D_ResultsSource, 0, ChangeListPtr);
	delete srcList;
	srcList = 0;

	// output variable names and descriptions
	cmdList[idxCategoryList].itemList = (void*) dummyList;
	SetValue (D_Categories, 0, ChangeListPtr);
	cmdList[idxAvailList].itemList = (void*) dummyList;
	SetValue (D_AvailableVars, 0, ChangeListPtr);
	delete info;
	info = 0;

	// STL vectors
	indexSelected.erase (indexSelected.begin(), indexSelected.end());
	selectedList.erase (selectedList.begin(), selectedList.end());

	// selected list
	cmdList[idxSelectList].itemList = (void*) dummyList;
	SetValue (D_SelectedVars, 0, ChangeListPtr);
	delete [] selectedStrList;
	selectedStrList = 0;

	// simulation descriptions
	::DeleteNTCStringList (simDescList);
}

//	LoadDlg
// 	load the dialog
void TSelectOutVarsDlg::LoadDlg ()
{
	// load sources
	LoadSources ();
	Evt_Source ();

	// load categories
	cmdList[idxCategoryList].itemList = (void*) (info->GetCategories());
	SetValue (D_Categories, 0, ChangeListPtr);
	Evt_Category ();	// load available variables in category
}

//	LoadSources
// 	load the sources list
void TSelectOutVarsDlg::LoadSources ()
{
	// get C string form of list
	char const** pList = srcList->GetList();
	if ( !pList || !(*pList) )			// anything there?
	{
		// need error handling here
		return;
	}
	// change the list display
	cmdList[idxSourceList].itemList = (void*) pList;
	SetValue (D_ResultsSource, 0, ChangeListPtr);
}

//	Evt_Source
// 	selected an output source
void TSelectOutVarsDlg::Evt_Source ()
{
	// check that the selected source file still exists on disk
	TEH::TFileName fileName ( GetSourceName() );
	if ( !fileName.Exists() )
	{
		vNoticeDialog dlg (this, "Error Accessing File");
		dlg.Notice ("The selected Century output file\n"
			    "is no longer accessable or has been deleted.");
	}
	CheckRightArrowSens ();

	// display description of simulation
	if ( simDescList )
	{
		// get index to currently selected item in source file list
		short i = (short)GetValue (D_ResultsSource);
		// display description
		SetString ( D_SimDescrip, simDescList[i] );
	}
}

//	GetSourceName
//	get name of selected source file
char const* TSelectOutVarsDlg::GetSourceName ()
{
	// get index to the currently selected items
	short i = (short)GetValue (D_ResultsSource);	// source file list
	// get text from list
	return (*srcList)[i];
}

//	Evt_AddOutFile
// 	browse for source button
void TSelectOutVarsDlg::Evt_AddOutFile ()
{
	// To do
}

//	AddToSourcesList
// 	add to output sources list
void TSelectOutVarsDlg::AddToSourcesList (char* item)
{
	// To do
	// 1. add item to the sources list
	// 2. update the list display
}

//	Evt_Category
// 	selected a category
void TSelectOutVarsDlg::Evt_Category ()
{
	// get index to the currently selected item in the category list
	short i = (short)GetValue (D_Categories);
	// load available variables into the variable list
	cmdList[idxAvailList].itemList =
			(void*) ( info->GetNameList ( (TOVICategory)i) );
	SetValue (D_AvailableVars, 0, ChangeListPtr);
	Evt_AvailableVars ();
}

//	Evt_AvailableVars
//	list of available variables
inline void TSelectOutVarsDlg::Evt_AvailableVars ()
{
	DisplayDescription (D_AvailableVars);
	CheckRightArrowSens ();
}

//	Evt_ToSelected
// 	right-arrow button
void TSelectOutVarsDlg::Evt_ToSelected ()
{
	// get index to the currently selected items
	short i = (short)GetValue (D_AvailableVars);	// variable list
	short j = (short)GetValue (D_Categories);	// category list
	short k = (short)GetValue (D_SelectedVars);	// selected list
	short n = (short)GetValue (D_ResultsSource);	// file name

	// create a concatenated string for the list of the form:
	// "name - category - source"
	string itemStr = info->GetNameList((TOVICategory)j)[i];	// item
	itemStr += " - ";
	itemStr += info->GetCategories()[j];			// category
	itemStr += " - ";
	itemStr += GetSourceName();

	// is string already in the set?
	TIndexGroup ig  = { n, j, i };		// setup the list's index data
	TSelIndexList::iterator found =
		find (indexSelected.begin(), indexSelected.end(), ig);
	if ( found != indexSelected.end() )		// found it?
		return;					// ...yes

	// insert the new string after the selected string
	if ( selectedList.size() )
	{
		TSelectedVector::iterator is = selectedList.begin() + k + 1;
		selectedList.insert ( is, itemStr );	// insert string
		TSelIndexList::iterator ii = indexSelected.begin() + k + 1;
		indexSelected.insert ( ii, ig );	// insert indices
	}
	else
	{
		selectedList.push_back (itemStr);		// add string
		indexSelected.push_back ( ig );		// add indices
	}

	// display the new list
	DisplaySelected ();

	// set the selections
	SetValue (D_SelectedVars, k + 1, Value);	// select inserted
	SetValue (D_AvailableVars, i + 1, Value);	// select next avail.
	DisplayDescription (D_AvailableVars);		// update description

	// button displays
	CheckSelListSens ();
}

//	Evt_FromSelected
// 	left arrow button
void TSelectOutVarsDlg::Evt_FromSelected ()
{
	if ( !selectedList.size() )			// anything there?
		return;

	// get index to the currently selected items
	short i = (short)GetValue (D_SelectedVars);	// selected list

	// remove the selected item from the list
	TSelectedVector::iterator is = selectedList.begin() + i;
	selectedList.erase (is);

	// remove indices from the index list
	TSelIndexList::iterator ii = indexSelected.begin() + i;
	indexSelected.erase (ii);

	// display the new list
	DisplaySelected ();

	// set the selection
	if ( i >= selectedList.size() )			// check range
		i = (short) selectedList.size() - 1;
	SetValue (D_SelectedVars,i, Value);		// select same position

	// button displays
	CheckSelListSens ();
}

//	Evt_SelectedVars
// 	list of selected variables
void TSelectOutVarsDlg::Evt_SelectedVars ()
{
	if ( !selectedList.size() )			// anything there?
		return;

	// display the highlighted variable's description
}

//	Evt_ClearSelected
// 	"clear selected" button
void TSelectOutVarsDlg::Evt_ClearSelected ()
{
	if ( !selectedList.size() )			// anything there?
		return;

	// clear the display
	cmdList[idxSelectList].itemList = (void *)dummyList;
	SetValue (D_SelectedVars, 0, ChangeListPtr);

	// clear the member variables
	indexSelected.erase (indexSelected.begin(), indexSelected.end());
	selectedList.erase (selectedList.begin(), selectedList.end());
	delete [] selectedStrList;
	selectedStrList = 0;

	// button displays
	CheckSelListSens ();
}

//	Evt_MoveItemUp
//	move highlighted item up in selected list
void TSelectOutVarsDlg::Evt_MoveItemUp ()
{
	if ( !selectedList.size() )		// anything there?
		return;

	// get index to the currently selected items
	short i = (short)GetValue (D_SelectedVars);
	if ( i == 0 )					// at top already?
		return;

	swap (selectedList[i - 1], selectedList[i]);	// swap strings
	swap (indexSelected[i - 1], indexSelected[i]);	// swap index groups
	DisplaySelected ();				// redisplay the list
	SetValue (D_SelectedVars, i - 1, Value);	// set the selection
}

//	Evt_MoveItemDown
//	move highlighted item down in selected list
void TSelectOutVarsDlg::Evt_MoveItemDown ()
{
	if ( !selectedList.size() )		// anything there?
		return;

	// get index to the currently selected items
	short i = (short)GetValue (D_SelectedVars);
	if ( i == selectedList.size() - 1 )		// at bottom already?
		return;

	swap (selectedList[i + 1], selectedList[i]);	// swap strings
	swap (indexSelected[i + 1], indexSelected[i]);	// swap index groups
	DisplaySelected ();				// redisplay the list
	SetValue (D_SelectedVars, i + 1, Value);	// set the selection
}

//	DisplaySelected
// 	displays the selected items list
void TSelectOutVarsDlg::DisplaySelected ()
{
	delete [] selectedStrList;
	selectedStrList = new char const* [selectedList.size() + 1];
	selectedStrList[selectedList.size()] = 0;	// null-term the list
							// retrieve pointers
	TSelectedVector::iterator s = selectedList.begin();
	char const** p = selectedStrList;
	while ( s != selectedList.end() )
	{
		*(p++) = (*s).c_str();
		++s;
	}
	cmdList[idxSelectList].itemList = (void*) selectedStrList;
	SetValue (D_SelectedVars, 0, ChangeListPtr);
}

//	DisplayDescription
// 	displays a highlighted variable's description
inline void TSelectOutVarsDlg::DisplayDescription (ItemVal list)
{
	// 1. get index to the currently selected items
	short i = (short)GetValue (list);		// variable list
	short j = (short)GetValue (D_Categories);	// category list
	// display the highlighted variable's description
	SetString ( D_VarDescrip, info->GetDescList((TOVICategory)j)[i] );
}

//	CheckRightArrowSens
//	changes sensitivity of right arrow
void TSelectOutVarsDlg::CheckRightArrowSens ()
{
	// get index to the currently selected items
	short i = (short)GetValue (D_AvailableVars);	// variable list
	short j = (short)GetValue (D_Categories);	// category list
	short n = (short)GetValue (D_ResultsSource);	// file name
	TIndexGroup ig  = { n, j, i };		// setup the list's index data

	// is string already in the set?
	TSelIndexList::iterator found =
		find (indexSelected.begin(), indexSelected.end(), ig);
	if ( found != indexSelected.end() )			// found it?
		SetValue (D_ToSelected, notSens, Sensitive);	// ...yes
	else
		SetValue (D_ToSelected, isSens, Sensitive);	// ...no
}

//	CheckSelListSens
//	changes sensitivity of left arrow
void TSelectOutVarsDlg::CheckSelListSens ()
{
	if ( !selectedList.size() )			// anything there?
	{
		SetValue (D_FromSelected, notSens, Sensitive);	// ...yes
		SetValue (D_ClearSelected, notSens, Sensitive);
		SetValue (D_MoveItemUp, notSens, Sensitive);
		SetValue (D_MoveItemDown, notSens, Sensitive);
	}
	else
	{
		SetValue (D_FromSelected, isSens, Sensitive);	// ...no
		SetValue (D_ClearSelected, isSens, Sensitive);
		SetValue (D_MoveItemUp, isSens, Sensitive);
		SetValue (D_MoveItemDown, isSens, Sensitive);
	}
}

//	BuildSimDescList
//	Builds a list of simulation descriptions associated with the files in
//	the output file list, srcList.
void TSelectOutVarsDlg::BuildSimDescList ()
{
	// allocate memory for simDescList
	short const length = srcList->GetCount();	// length of list
	simDescList = new char* [length + 1];		// memory for pointers
	char** p = simDescList;				// set all to null
	for ( short i = 0; i <= length; i++ )
		*(p++) = 0;

	// for each file in srcList
	for ( short i = 0; i < length; i++ )
	{
		// open file
		NcError* ncErr = new NcError (NcError::silent_nonfatal);
		char const* name = (*srcList)[i];
		NcFile* ncFile = new NcFile (name, NcFile::ReadOnly);
		if ( !ncFile->is_valid() || ncErr->get_err() )
			continue;		// error accessing the file

		// extract description to simDescList
		NcAtt *pAttrib = ncFile->get_att ("SimDescription");
		if ( pAttrib )
		{
			char* desc = pAttrib->as_string (0);
			simDescList[i] = new char [strlen(desc) + 1];
			strcpy (simDescList[i], desc);
			delete pAttrib;
		}

		// close file
		delete ncFile;
		delete ncErr;
	}
	// all done!
}


