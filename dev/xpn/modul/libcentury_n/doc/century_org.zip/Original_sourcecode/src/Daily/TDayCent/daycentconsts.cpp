// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  daycentconsts.cpp
//	Class:	  TDayCent
//
//	Description:
//	Constants for class TDayCent and related utilities.
//
//	Author: Melannie Hartman, melannie@nrel.colostate.edu, Aug01
// ----------------------------------------------------------------------------
//	History:
//      See Century/centconsts.cpp
//      Aug01   Melannie Hartman, melannie@nrel.colostate.edu
//      * These constansts were once in centconsts.cpp, now in this separate file.
// ----------------------------------------------------------------------------
//	Copyright 2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TDayCent.h"

//--- public constants

//--- default names

//--- protected constants

// TDayCent constants
// These are used in "IsTimeFor___() functions, among other places -mdh 5/02/01
int const TDayCent::IrrigationEventsPerMonth = 4;
int const TDayCent::FertilizationEventsPerMonth = 1;
int const TDayCent::GrazingEventsPerMonth = 1;
int const TDayCent::OMAdditionEventsPerMonth = 1;
int const TDayCent::ProductionPeriod = 7;     // max # of days between growth events


//--- end of daycentconsts.cpp ---
