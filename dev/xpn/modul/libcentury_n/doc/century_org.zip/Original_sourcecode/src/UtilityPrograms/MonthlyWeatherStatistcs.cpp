// ----------------------------------------------------------------------------
//	Copyright 2002, 2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  MonthlyWeatherStatistcs.h
//	Class:	  MonthlyWeatherStatistcs
//
//	Description:
//	Class to calculate monthly statistics and
//	generate a site parameter set.
//---------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May2005 (C++ driver)
//		Cindy Keough, 2002, file read, and statistical functions.
//	History: See header file.
// ----------------------------------------------------------------------------

#include "MonthlyWeatherStatistcs.h"
#include <cmath>
#include <vector>
#include <algorithm>
using namespace nrel::util;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

std::string const MonthlyWeatherStatistcs::precipMeanName	= "\t\tPRECIP";
std::string const MonthlyWeatherStatistcs::precipStdDevName	= "\t\tPRCSTD";
std::string const MonthlyWeatherStatistcs::precipSkewName	= "\t\tPRCSKW";
std::string const MonthlyWeatherStatistcs::tempMinMeanName	= "\t\tTMN2M";
std::string const MonthlyWeatherStatistcs::tempMaxMeanName	= "\t\tTMX2M";

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

struct AppendString
	: public std::binary_function
		 <std::string &, std::string const &, std::string &>
{
	std::string & operator() (
	  std::string & prefix,
	  std::string const & suffix) const
	  {
		prefix += suffix;
		return prefix;
	  }
};


void MonthlyWeatherStatistcs::WriteSiteParameters (
	std::ostream & os)
{
	// create an array of "(N)", where N = [1..12]
	std::vector<std::string> indexStrArray (12, std::string("(") );
	for ( short i = 1; i <= 12; ++i )
	{
		std::string & s = indexStrArray[i - 1];
		if ( i < 10 )
			s += (char) ( '0' + i );
		else
		{
			s += '1';
			s += (char) ( '0' + (i % 10) );
		}
		s += ')';
	}

	// append indices strings to name strings 
	std::vector<std::string> precipMeanArray (12, precipMeanName);
	std::transform ( precipMeanArray.begin(), precipMeanArray.end(),
			 indexStrArray.begin(),
			 precipMeanArray.begin(),
			 AppendString() );

	std::vector<std::string> precipStdDevArray (12, precipStdDevName);
	std::transform ( precipStdDevArray.begin(), precipStdDevArray.end(),
			 indexStrArray.begin(),
			 precipStdDevArray.begin(),
			 AppendString() );

	std::vector<std::string> precipSkewArray (12, precipSkewName);
	std::transform ( precipSkewArray.begin(), precipSkewArray.end(),
			 indexStrArray.begin(),
			 precipSkewArray.begin(),
			 AppendString() );

	std::vector<std::string> tempMinMeanArray (12, tempMinMeanName);
	std::transform ( tempMinMeanArray.begin(), tempMinMeanArray.end(),
			 indexStrArray.begin(),
			 tempMinMeanArray.begin(),
			 AppendString() );

	std::vector<std::string> tempMaxMeanArray (12, tempMaxMeanName);
	std::transform ( tempMaxMeanArray.begin(), tempMaxMeanArray.end(),
			 indexStrArray.begin(),
			 tempMaxMeanArray.begin(),
			 AppendString() );

	// write values and names to strings
	for ( short i = 0; i < 12; ++i )
		os << std::setw(7) << std::fixed
		   << std::setprecision(3) << std::showpoint
		   << precipMean(i) << precipMeanArray[i]
		   << '\n';
	for ( short i = 0; i < 12; ++i )
		os << std::setw(7) << std::fixed
		   << std::setprecision(3) << std::showpoint
		   << precipStdDev(i) << precipStdDevArray[i]
		   << '\n';
	for ( short i = 0; i < 12; ++i )
		os << std::setw(7) << std::fixed
		   << std::setprecision(3) << std::showpoint
		   << precipSkew(i) << precipSkewArray[i]
		   << '\n';
	for ( short i = 0; i < 12; ++i )
		os << std::setw(7) << std::fixed
		   << std::setprecision(3) << std::showpoint
		   << tempMinMean(i) << tempMinMeanArray[i]
		   << '\n';
	for ( short i = 0; i < 12; ++i )
		os << std::setw(7) << std::fixed
		   << std::setprecision(3) << std::showpoint
		   << tempMaxMean(i) << tempMaxMeanArray[i]
		   << '\n';
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

void stats (
	int const numyears,		// size of 1 dim. of "value"
	float const missingValue,	// data missing value
	T2DFloatArray const & value,	// input array [year][month]
	T1DFloatArray & mean)		// mean [month]
{
    using namespace std;

    int goodyears, month, year;
    float sum;
    float const MONTHS = 12;

    for ( month = 0; month < MONTHS; month++ )
    {
        sum = 0.0f;
	goodyears = 0;

	for ( year = 0; year < numyears; year++ )
	{
	    if ( value(year, month) != missingValue )
	    {
		++goodyears;
		sum += value(year, month);
	    }
	}
	mean(month) = sum / ( float ) goodyears;
    }
}

void stats (
	int const numyears,		// size of 1 dim. of "value"
	float const missingValue,	// data missing value
	T2DFloatArray const & value,	// input array [year][month]
	T1DFloatArray & mean,		// mean [month]
	T1DFloatArray & sd,		// std. deviation [month]
	T1DFloatArray & skew )		// skewness [month]
{
    using namespace std;

    int goodyears, month, year;
    float sum, ssum, csum, var, testskew;
    float const MONTHS = 12;

    for ( month = 0; month < MONTHS; month++ )
    {
        sum = 0.0f;
        ssum = 0.0f;
        csum = 0.0f;
        goodyears = 0;

        for ( year = 0; year < numyears; year++ )
        {
            if ( value(year, month) != missingValue )
            {
		++goodyears;
                sum += value(year, month);
		ssum += ( float ) pow( value(year, month), 2.0f );
		csum += ( float ) pow( value(year, month), 3.0f );
            }
        }
        mean(month) = sum / ( float ) goodyears;
        var = ssum / ( float ) goodyears - ( float ) pow( mean(month), 2.0f );

        if ( var < 0.0f )
        {
            var = 0.0f;
        }

        sd(month) = ( float ) sqrt( var );
        testskew = ( float ) pow( var, 1.5f );

        if ( testskew == 0 )
        {
            printf( "Unable to calculate SKEW value; replacing with 0.00\n" );
            skew(month) = 0.0f;
        }

        else
        {
            skew(month) = ( csum / ( float ) goodyears - 3.0f * mean(month) *
			      var - ( float ) pow( mean(month), 3.0f ) ) /
                            testskew;
        }
    }
}

void MonthlyWeatherStatistcs::Initialize (
	float const missingValue)
{
	precipMean.resize (12);		precipMean = missingValue;
	precipStdDev.resize (12);	precipStdDev = missingValue;
	precipSkew.resize (12);		precipSkew = missingValue;
	tempMinMean.resize (12);	tempMinMean = missingValue;
	tempMaxMean.resize (12);	tempMaxMean = missingValue;
}

void MonthlyWeatherStatistcs::DoStatistics (
	T2DFloatArray const & precip,	// precipitation [year][month]
	T2DFloatArray const & tempMin,	// minimum temperature [year][month]
	T2DFloatArray const & tempMax,	// maximum temperature [year][month]
	float const missingValue)
{
    ::stats ( precip.size().first, missingValue, precip,
	      precipMean, precipStdDev, precipSkew );
    ::stats ( tempMin.size().first, missingValue, tempMin, tempMinMean );
    ::stats ( tempMax.size().first, missingValue, tempMax, tempMaxMean );
}

//--- end of definitions for MonthlyWeatherStatistcs ---

 