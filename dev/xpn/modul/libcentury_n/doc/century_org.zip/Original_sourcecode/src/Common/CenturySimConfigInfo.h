#ifndef INC_nrel_century_CenturySimConfigInfo_h
#define INC_nrel_century_CenturySimConfigInfo_h
// ----------------------------------------------------------------------------
//	Copyright 2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  CenturySimConfigInfo.h
//	Class:	  CenturySimConfigInfo
//
//	Description:
//	Contains text and flags data describing a configuration for a
//	single Century5 simulation.
//	To do: This needs to be a child of class TINIData, and all data
//	stored in INI keys.
//
//	Responsibilities:
//	* Knows its data.
//	* Provides public access functions.
//	* Knows if data has been modified.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Aug2005
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TOutputBase.h"
#include <vector>
#include <string>

namespace nrel
{
//  namespace eco
//  {
    namespace century
    {

class CenturySimConfigInfo
{
  public:
	//--- types
	typedef std::vector<std::string>		TStringArray;

	//--- constructors and destructor
	CenturySimConfigInfo ()
	  : outputType (TOutputBase::Type_Unknown),
	    outputAccess (TOutputBase::Mode_Unknown),
	    doOutput (true),
	    modified (false)
	  {
	  }
	CenturySimConfigInfo (
	  std::string const & useSiteFileName,
	  std::string const & useManagementFileName,
	  std::string const & useOutputFileName,
	  TOutputBase::TOutputType const useOutputType,
	  TOutputBase::TAccessMode const useOutputAccess,
	  bool const useProduceOutput,
	  TStringArray const & useParametersSearchPaths,
	  std::string const & useFixParametersFileName,
	  std::string const & useUserName,
	  std::string const & useConfigurationDescription)
	  {
	    SetSiteFileName ( useSiteFileName );
	    SetManagementFileName ( useManagementFileName );
	    SetOutputFileName ( useOutputFileName );
	    SetOutputType ( useOutputType );
	    SetOutputAccess ( useOutputAccess );
	    SetProduceOutput ( useProduceOutput );
	    SetParameterSearchPaths ( useParametersSearchPaths );
	    SetFixFileName ( useFixParametersFileName );
	    SetUserName ( useUserName );
	    SetDescription ( useConfigurationDescription );
	    modified = false;
	  }
	CenturySimConfigInfo (CenturySimConfigInfo const & object)
	  {
	    Copy (object);
	  }
	~CenturySimConfigInfo ()
	  {
	  }

	//---- operator overloads
	CenturySimConfigInfo & operator= (CenturySimConfigInfo const & object)
	  {
	    Copy (object);
	    return *this;
	  }
	bool operator== (CenturySimConfigInfo const & object) const
	  {
	    if ( &object )
		return DoCompare(object);
	    else
	    	return false;
	  }
	bool operator!= (CenturySimConfigInfo const & object) const
	  { return !(*this == object); }

	//--- functions
	void SetSiteFileName (
	  std::string const & useSiteFileName)
	  {
	    siteFileName = useSiteFileName;
	    modified = true;
	  }
	void SetManagementFileName (
	  std::string const & useManagementFileName)
	  {
	    mgmtFileName = useManagementFileName;
	    modified = true;
	  }
	void SetOutputFileName (
	  std::string const & useOutputFileName)
	  {
	    outputFileName = useOutputFileName;
	    modified = true;
	  }
	void SetOutputType (
	  TOutputBase::TOutputType const useOutputType)
	  {
	    outputType = useOutputType;
	    modified = true;
	  }
	void SetOutputAccess (
	  TOutputBase::TAccessMode const useOutputAccess)
	  {
	    outputAccess = useOutputAccess;
	    modified = true;
	  }
	void SetProduceOutput (
	  bool const useDoOutput)
	  {
	    doOutput = useDoOutput;
	    modified = true;
	  }
	void SetParameterSearchPaths (
	  TStringArray const & useSearchPaths)
	  {
	    paramPathList = useSearchPaths;
	    modified = true;
	  }
	void SetFixFileName (
	  std::string const & useFixFileName)
	  {
	    fixFileName = useFixFileName;
	    modified = true;
	  }
	void SetUserName (
	  std::string const & useUserName)
	  {
	    userName = useUserName;
	    modified = true;
	  }
	void SetDescription (
	  std::string const & useDescription)
	  {
	    description = useDescription;
	    modified = true;
	  }
	void SetModified (
	  bool const flag)
	  {
	    modified = flag;
	  }

	std::string const & GetSiteFileName () const
	  { return siteFileName; }
	std::string const & GetManagementFileName () const
	  { return mgmtFileName; }
	std::string const & GetOutputFileName () const
	  { return outputFileName; }
	TOutputBase::TOutputType GetOutputType () const
	  { return outputType; }
	TOutputBase::TAccessMode GetOutputAccess () const
	  { return outputAccess; }
	bool ProduceOutput () const
	  { return doOutput; }
	TStringArray const & GetParameterSearchPaths () const
	  { return paramPathList; }
	std::string const & GetFixFileName () const
	  { return fixFileName; }
	std::string const & GetUserName () const
	  { return userName; }
	std::string const & GetDescription () const
	  { return description; }
	bool IsModified () const		// True if data is modified
	  { return modified; }

  private:
	std::string siteFileName;
	std::string mgmtFileName;
	std::string outputFileName;
	TOutputBase::TOutputType outputType;	// file format type
	TOutputBase::TAccessMode outputAccess;	// file access mode
	bool doOutput;				// false if no output
	TStringArray paramPathList;		// parameter file search
	std::string fixFileName;		// path/name to fix.100
	std::string userName;
	std::string description;
	bool modified;				// true if data changed

	void Copy (					// Copy to this
	  CenturySimConfigInfo const & object)
	  {
	    if ( &object )
	    {
	    	siteFileName = object.siteFileName;
	    	mgmtFileName = object.mgmtFileName;
	    	outputFileName = object.outputFileName;
	    	outputType = object.outputType;
	    	outputAccess = object.outputAccess;
		doOutput = object.doOutput;
	    	paramPathList = object.paramPathList;
	    	fixFileName = object.fixFileName;
	    	userName = object.userName;
	    	description = object.description;
	    	modified = object.modified;
	    }
	  }

	bool DoCompare (CenturySimConfigInfo const & object) const
	  {
	    return
	    	siteFileName == object.siteFileName &&
	    	mgmtFileName == object.mgmtFileName &&
	    	outputFileName == object.outputFileName &&
	    	outputType == object.outputType &&
	    	outputAccess == object.outputAccess &&
	    	doOutput == object.doOutput &&
	    	paramPathList == object.paramPathList &&
	    	fixFileName == object.fixFileName;
	    	// userName,  description, modified
	    	// are not essential to a sim. config.
	    	// so do not include them in operator=
	  }
};

    } // namespace century
//  } // namespace eco
} // namespace nrel

#endif // INC_CenturySimConfigInfo_h
