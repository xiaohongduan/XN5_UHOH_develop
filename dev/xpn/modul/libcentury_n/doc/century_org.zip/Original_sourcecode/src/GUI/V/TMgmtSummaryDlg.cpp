// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	Class:	  TMgmtSummaryDlg
//	File:	  TMgmtSummaryDlg.cpp
//
//	Description:
//	Class for displaying "Management Summary" window.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Jan98, tom.hilinski@colostate.edu
//	History: See header file.
// ----------------------------------------------------------------------------
//	Note: This is a quick-and-dirty kluge. Could be done much more
//	elegantly and usefully. Particularly:
//	* sorting by date
//	* event list box when clicking on an instance
//	* simulation info details
// ----------------------------------------------------------------------------

#include "TCMIApp.h"
#include "TMgmtSummaryDlg.h"
#include "TManagement.h"
#include "TInstList.h"
#include <sstream>

// Note: dummy list uses one wide entry to force a wide list control
char const * const TMgmtSummaryDlg::dummyList[] =
	{
	  "                                        ",
	  NULL
	};

CommandObject TMgmtSummaryDlg::cmdList[] =
{
	{C_Label, 101, 0, "Block Instances",
	 NoList, CA_None, isSens, NoFrame, 0, 0},
	{C_List, 102, 0, "", (void*)dummyList,
	 //CA_None, isSens, NoFrame, 0, 101, 70},
	 CA_Large, isSens, NoFrame, 0, 101}, // V1.17 uses size for #rows
	{C_Button, M_Cancel, M_Cancel, "&Close",
		NoList,	CA_DefaultButton, isSens, NoFrame, 0, 102},
	{C_EndOfList, 0, 0, 0, 0, CA_None, 0, 0}
};

TMgmtSummaryDlg::TMgmtSummaryDlg (
	TCMIApp * const app,
	TManagementScheme & useMgmt,
	char const * const title)
	: vDialog ( dynamic_cast<vApp * const>(app), 0, title ),
	  mgmt (useMgmt)
{
	//--- display dialog
	AddDialogCmds ((CommandObject*)cmdList);	// add dialog controls
	if ( !IsDisplayed() )				// show only once
		ShowDialog ("");			// display it now
}

TMgmtSummaryDlg::~TMgmtSummaryDlg()
{
	// change to empty list in display
	cmdList[1].itemList = (void *)dummyList;
	SetValue ( cmdList[1].cmdId, 0, ChangeListPtr);
}

void TMgmtSummaryDlg::DialogCommand (
	ItemVal id,
	ItemVal val,
	CmdType type)
{
	switch (id)
	{
		case M_Cancel:
			break;
		default:
			break;
	}
	// Default event processing
	vDialog::DialogCommand (id, val, type);
}

//	UpdateList
//	Update the displayed list.
void TMgmtSummaryDlg::UpdateList ()
{
	// change to empty list in display
	cmdList[1].itemList = (void *)dummyList;
	SetValue ( cmdList[1].cmdId, 0, ChangeListPtr);

	BuildList ();

	// display the list
	cmdList[1].itemList = (void *)list.list;	// set pointer to list
	SetValue ( cmdList[1].cmdId, 0, ChangeListPtr);
}

//	BuildList
//	Build the list to display.
void TMgmtSummaryDlg::BuildList ()
{
	// sorted list of instances...
	TInstanceList instList (mgmt);

	// build  a new list
	list.erase();
	for ( short i = 0; i < instList.GetCount(); i++ )
	{
		// build string
		TInstanceListItem const & item = instList.GetInstance(i);
		char const * const desc =		// block description
			mgmt.GetBlock(item.blockNum)->GetDescription();
		std::ostringstream listItem;
		listItem << item.yearFirst
			 << " - "
			 << item.yearLast
			 << "   ";
		if ( desc && *desc )
			listItem << desc;
		else
			listItem << "(no description)";

		// Add string to list
		list.insert (-1, listItem.str().c_str() );
	}
}

//--- end of file ---

