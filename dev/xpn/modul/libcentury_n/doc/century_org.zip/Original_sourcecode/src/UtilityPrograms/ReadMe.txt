File:	Century/version5/src/cmd-line-utils/ReadMe.txt

Century Command-Line Utilities

File Name	Description
--------------	------------------------------------------------------
ncfilelist	Lists Century netCDF file type descriptions for files
		in the current directory.

ef2csv   	Translates a Century erosion output file (in netCDF
		format) into a comma-separated values text format for
		import into spreadsheets.


--- end of file ---