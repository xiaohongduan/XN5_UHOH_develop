#ifndef INC_NSUnitsConsts_h_
#define INC_NSUnitsConsts_h_

// ----------------------------------------------------------------------------
//	Project:  	CENTURY soil organic model
//	File:	  	NSUnits.h
//	Namespace:	NSUnits
//
//	Description:
//	Constants for various units and conversions between units.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Aug00
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
//	Copyright 2000 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#ifdef __BCPLUSPLUS__
	// Borland C++ Compiler
	// Precompiled headers hate constants in the headers, and
	// BCC and BCB will not precompile these headers. This increases
	// compilation time tremendously.
	// So, here I trade type safety for compilation speed.
#define NSUnits_cm2m2		1.0e4f		// cm2 per m2
#define NSUnits_m2cm2		1.0e-4f		// m2 per cm2
#define NSUnits_cmm		100.0f		// m per cm
#define NSUnits_mcm		0.01f		// cm per m
#define NSUnits_gkg		1000.0f		// g per kg
#define NSUnits_kgg		1.0e-3f		// kg per g

#else

namespace NSUnits
{
	// conversion constants
	static float const cm2m2 = 1.0e4f;		// cm2 per m2
	static float const m2cm2 = 1.0e-4f;		// m2 per cm2
	static float const cmm = 100.0f;		// m per cm
	static float const mcm = 0.01f;			// cm per m
	static float const gkg = 1000.0f;		// g per kg
	static float const kgg = 1.0e-3f;		// kg per g

}   // namespace NSUnits

#define NSUnits_cm2m2		NSUnits::cm2m2
#define NSUnits_m2cm2		NSUnits::m2cm2
#define NSUnits_cmm		NSUnits::cmm
#define NSUnits_mcm		NSUnits::mcm
#define NSUnits_gkg		NSUnits::gkg
#define NSUnits_kgg		NSUnits::kgg

#endif // __BORLANDCPP__

#endif // INC_NSUnitsConsts_h_
