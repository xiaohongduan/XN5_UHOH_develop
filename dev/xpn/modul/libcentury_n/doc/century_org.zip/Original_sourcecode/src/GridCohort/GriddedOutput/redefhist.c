
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <stdlib.h>
#include <string.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf.h"

void
redefhist_(int *savall, float *final_co2conc)
{
	/* Append final co2 concentration to history strings
           in all NetCDF files */

        char history[HISTL+1];
        char new_history[HISTL+1];

        int ifile;
        int nfiles = 1;
	int status;
        int ncid[14];

	ncid[0] = site_ncid;
        memset(history, '\0', (HISTL)*sizeof(char));
        memset(new_history, '\0', (HISTL)*sizeof(char));


	if (*savall == 1)
	{
		ncid[1]  = crop_ncid;
		ncid[2]  = h2o_ncid;
		ncid[3]  = livc_ncid;
		ncid[4]  = livn_ncid;
		ncid[5]  = nflux_ncid;
		ncid[6]  = nmnr_ncid;
		ncid[7]  = nupt_ncid;
		ncid[8]  = prod_ncid;
		ncid[9]  = resp_ncid;
		ncid[10] = soilc_ncid;
		ncid[11] = soiln_ncid;
		ncid[12] = cremv_ncid;
		ncid[13] = nremv_ncid;
                nfiles = 14;
	}

    for(ifile=0; ifile < nfiles; ifile ++) {
       status = nc_get_att_text(ncid[ifile], NC_GLOBAL, "history", history);
       if (status != NC_NOERR) handle_error("nc_get_att_text", status);
    
       sprintf(new_history, "%s: final CO2 = %6.3f", history, *final_co2conc);
    
       status = nc_redef(ncid[ifile]);
       if (status != NC_NOERR) handle_error("nc_redef", status);
    
       status = nc_put_att_text(ncid[ifile], NC_GLOBAL, "history", strlen(new_history), new_history);
       if (status != NC_NOERR) handle_error("nc_put_att_text", status);
    
       status = nc_enddef(ncid[ifile]);
       if (status != NC_NOERR) handle_error("nc_enddef", status);

    }
    return;
}
