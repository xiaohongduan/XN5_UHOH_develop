// ----------------------------------------------------------------------------
//	Copyright 1999-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TMgmtEditorDlg.cpp
//	Class:	  TMgmtEditorDlg
//
//	Description:
//	Dialog box for editing the site managment.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec97
//	History: See the class header file, TMgmtEditorDlg.h.
// ----------------------------------------------------------------------------
//	Notes:
//	This class is divided among the following files:
//	TMgmtEditorDlg.h		declarations header file
//	TMgmtEditorDlg.cpp		main class definitions
//	TMgmtEditorDlgLoad.cpp		methods to load data into dialog
//	TMgmtEditorDlgEvents.cpp	methods to handle dialog events
//	TMgmtEditorDlgGet.cpp		methods to retrieve data from dialog
// ----------------------------------------------------------------------------

#define _TMgtDlg_ClassDefined_
#include "TMgmtEditorDlg.h"
#ifndef TESTING_EDITOR
#include "externals.h"
#endif
#include "utilmgmt.h"
#include "TChoicesDlg.h"
#include "util.h"
#include "HelpDisplay.h"
#include <v/vcolor.h>
#include <v/vynreply.h>
#include <v/vnotice.h>
using namespace std;

#ifdef TESTING_EDITOR
#define HistText(a)
#define MsgText(a)
#endif

// ----------------------------------------------------------------------------
//	local variables
// ----------------------------------------------------------------------------

char const * const TMgmtEditorDlg::version =	// version of editor
	"2.0.0";

static char const * const NULLStr =		// global NULL string
	 "";
static char const * const dummyList[] =		// for lists and combo-lists
	{ NULL };
static char const * const description[] =	// dialog labels
{
	"Specify Simulation Information",
	"Define Management Blocks",
	"Specify Blocks in Simulation Time",
	0
};
static char const* notVerifiedStr =
	"Not Verified";
static char const* modifiedStr =
	"Modified";

char const * TMgmtEditorDlg::toolTips[] =		// tool tips text
{
	//---	Common Buttons
	// 0 = button Done
	"Finished editing the management scheme.",
	// 1 = button Help
	"View Help on editing the management scheme.",
	// 2 = button New
	"Create a new (empty) management scheme.",
	// 3 = button Open
	"Open an existing management scheme.",
	// 4 = button Import
	"Import a Century 4 schedule file.",
	// 5 = button From Library
	"Create a new management scheme from a library scheme.",
	// 6 = button Save
	"Save the management scheme to a file.",
	//---	Tab buttons
	// 7 = simulation info
	"Edit the simulation parameters.",
	// 8 = block definitions
	"Create and edit block definitions.",
	// 9 = block instances
	"Specify and edit instances of blocks.",
	//---	Toggle Frame 1- default frame = Simulation info dialog
	// 10 = text edit and button: base name for management files
	"Change the base name for the management files.",
	// 11 = mgmt description
	"Description for the management scheme.",
	// 12 = edit boxes: simulation time
	"Start and End years for the simulation.",
	// 13 = text edit and button:
	"Enter or select a site file name.",
	// 14 = CO2 labeling start year
	"Simulation year for start of CO2 labeling.",
	// 15 = CO2 effect years
	"Start and End simulation years for CO2 effect.",
	//---	Toggle Frame 2 = Block definition dialog
	// 16 = block list
	"Select a block to view or edit events.",
	// 17 = add block
	"Add a new block definition to the simulation.",
	// 18 = copy to new
	"Copy the selected block to a new block definition.",
	// 19 = from library
	"Insert a block definition from a block library.",
	// 20 = delete a block
	"Delete the selected block definition.",
	// 21 = event list
	"Select an event to view or edit.",
	// 22 = add event
	"Add an event to the block definition.",
	// 23 = delete event
	"Delete the selected event.",
	// 24 = save event
	"Save the data for the selected event.",
	// 25 = block description text box
	"Enter or edit the block description.",
	// 26 = block description change button
	"Save the block description.",
	// 27 = std. event: event year
	"Year of event relative to start of block.",
	// 28 = std. event: event month
	"Month of event in the event year.",
	// 29 = text edit: Additional data
	"Additional data specific to this event.",
	// 30 = std. event: button: choose additional
	"Choose additional data from a list.",
	// 31 = range event: start and end years
	"Start and End years relative to start of block..",
	// 32 = range event: start and end values
	"Start and End values corresponding to the years.",
	// 33 = range event: monthly fraction
	"Fraction of each year\'s amount to be applied to this month.",
	//---	Toggle Frame 3 = Block instance dialog
	// 34 = block list
	"Select a block to view or edit instances.",
	// 35 =  instance list
	"Select a block instance to view or edit.",
	// 36 = button: add instance
	"Add a new instance of the selected block to the simulation.",
	// 37 = button: copy instance to new
	"Copy the selected instance to a new instance.",
	// 38 = button: delete instance
	"Delete the selected instance.",
	// 39 = button: save instance
	"Save the data for the current instance.",
	// 40 = text edit: years in simulation
	"Start and End simulation years in which the block will be used.",
	// 41 = text edit: output: start year
	"Simulation year at which output will start.",
	// 42 = text edit: output: start month
	"Month at which output will start in each output year.",
	// 43 = text edit: output: frequency
	"Number of months between output / 12.",
	// 44 = button: output: frequency choice list
	"Choose output frequency from a list of values.",
	// 45 = text edit and button: weather file
	"Enter or select a weather file name.",
	// 46 = text edit and button: 14C data file
	"Enter or select a 14C data file name.",
	// 47 = text edit and button: erosion output file
	"Enter or select an erosion output file name.",
	// 48 = text edit and button: deposition input file
	"Enter or select a deposition input file name.",
	// 49 = verify management button
	"Verify the logical order in the management scheme.",
	// 50 = microcosm simulation
	"Microcosm simulation uses constant temperature and moisture.",
	// last item always
	0
};

static vColor labelColor(128, 0, 0);	// define color for main labels

CommandObject TMgmtEditorDlg::cmdList[] =
{
	//---	Tab buttons
	{C_ToggleButton, Tab_Simulation, 1, "Simulation Information",
		NoList, CA_None, isSens, NoFrame, 0, 0,
		0, toolTips[7]},
	{C_ToggleButton, Tab_BlockDef, 0, "Define Blocks",
		NoList, CA_None, isSens, NoFrame, Tab_Simulation, 0,
		0, toolTips[8]},
	{C_ToggleButton, Tab_BlockInst, 0, "Use Blocks",
		NoList, CA_None, isSens, NoFrame, Tab_BlockDef, 0,
		0, toolTips[9]},
	{C_Blank, 9991, 0, NULLStr,
		NoList, CA_None, isSens, NoFrame, Tab_BlockInst, 0, 10},
	{C_ColorLabel, D_MgmtModified, 0, modifiedStr, (void *)&labelColor,
		CA_None, isSens, NoFrame, 9991, 0, 15},
	{C_ColorLabel, D_MgmtVerified, 0, notVerifiedStr, (void *)&labelColor,
		CA_None, isSens, NoFrame, D_MgmtModified, 0, 15},

	//---	Master Frame provides a border for toggle frames
	{C_Frame, D_MasterFrame, 0, NULLStr,
		NoList, CA_None, isSens, NoFrame, 0, Tab_Simulation},

	//---	Toggle Frame 1- default frame = Simulation info dialog
	{C_ToggleFrame, D_ToggleFrame1, 1, NULLStr,
		NoList, CA_NoBorder, isSens, D_MasterFrame, 0, 0},
	//	ID numbers begins with 101
	{C_ColorLabel, 101, 0, description[0], (void *)&labelColor,
		CA_None, isSens, D_ToggleFrame1, 0, 0},
	// management base file name
	{C_Label, 115, 0, "File Name for Management:", NoList,
		CA_None, isSens, D_ToggleFrame1, 0, 101, 25},
	{C_TextIn, D_MgtBaseName, 0, NULLStr, NoList,
		CA_None, isSens, D_ToggleFrame1, 115, 101, 50, toolTips[10]},
	{C_Button, D_MgtBaseNameChg, D_MgtBaseNameChg, "&Browse...",
		NoList,	CA_None, isSens, D_ToggleFrame1, D_MgtBaseName, 101,
		0, toolTips[10]},
	//	management scheme description
	{C_Label, 102, 0, "Description:", NoList,
		CA_None, isSens, D_ToggleFrame1, 0, D_MgtBaseName, 25},
	{C_TextIn, D_MgtDescrip, 0, "", NoList, CA_None, isSens,
		D_ToggleFrame1, 102, D_MgtBaseName, 50, toolTips[11]},
	//	years
	{C_Label, 103, 0, "Year Start:", NoList,
		CA_None, isSens, D_ToggleFrame1, 0, D_MgtDescrip, 25},
	{C_TextIn, D_YearStart, 0, NULLStr, NoList,
		CA_Small, isSens, D_ToggleFrame1, 103, D_MgtDescrip, 5,
		toolTips[12]},
	{C_Blank, 190, 0, "    ", NoList,
		CA_None, isSens, D_ToggleFrame1, D_YearStart, D_MgtDescrip},
	{C_Label, 104, 0, "Year End:", NoList,
		CA_None, isSens, D_ToggleFrame1, 190, D_MgtDescrip,},
	{C_TextIn, D_YearEnd, 0, NULLStr, NoList,
		CA_Small, isSens, D_ToggleFrame1, 104, D_MgtDescrip, 5,
		toolTips[12]},

	//	Frame w/border for options
	{C_Frame, 140, 0, NULLStr, NoList,
		CA_None | CA_NoBorder, isSens, D_ToggleFrame1,
		0, D_YearStart},
	//	labeling
	{C_Frame, 105, 0, NULLStr, NoList,
		CA_None, isSens, 140, 0, 0},
	{C_Label, 106, 0, "CO2 Labeling", NoList,
		CA_None, isSens, 105, 0, 0},
	{C_Frame, 113, 0, NULLStr, NoList,
		CA_None | CA_NoBorder, isSens, 105, 0, 106},
	{C_RadioButton, D_LabelTypeNone, 1, "None", NoList,
		CA_None, isSens, 113, 0, 0},
	{C_RadioButton, D_LabelType14C, 0, "14C", NoList,
		CA_None, isSens, 113, 0, D_LabelTypeNone},
	{C_RadioButton, D_LabelType13C, 0, "13C", NoList,
		CA_None, isSens, 113, 0, D_LabelType14C},
	{C_Label, 112, 0, "Year Start:", NoList,
		CA_None, isSens, 105, 0, 113 },
	{C_TextIn, D_LabelYear, 0, NULLStr, NoList,
		CA_None, notSens, 105, 112, 113, 5, toolTips[14]},
	//	initial system
	{C_Frame, 107, 0, NULLStr, NoList, CA_None, isSens, 140, 105, 0},
	{C_Label, 108, 0, "Initial System", NoList,
		CA_None, isSens, 107, 0, 0},
	{C_RadioButton, D_InitSysCrop, 1, "Crop", NoList,
		CA_None, isSens, 107, 0, 108},
	{C_Label, D_InitSysCropStr, 0, "None", NoList,
		CA_None, isSens,
		107, D_InitSysCrop, 108,
		6},
	{C_Button, D_InitSysCropSel, D_InitSysCropSel, "Select...",
		NoList,	CA_Small, isSens,
		107, D_InitSysCropStr, 108},
	{C_RadioButton, D_InitSysTree, 0, "Tree", NoList,
		CA_None, isSens, 107, 0, D_InitSysCrop},
	{C_Label, D_InitSysTreeStr, 0, "None", NoList,
		CA_None, isSens,
		107, D_InitSysTree, D_InitSysCropSel,
		6},
	{C_Button, D_InitSysTreeSel, D_InitSysTreeSel, "Select...",
		NoList,	CA_Small, notSens, 107,
		D_InitSysTreeStr, D_InitSysCropSel},
	{C_RadioButton, D_InitSysBoth, 0, "Both", NoList,
		CA_None, isSens, 107, 0, D_InitSysTree},

	//	microcosm
	{C_Frame, 109, 0, NULLStr, NoList, CA_None, isSens, 140, 107, 0},
	{C_Label, 110, 0, "Microcosm/Soil Incubation", NoList,
		CA_None, isSens, 109, 0, 0 },
	{C_CheckBox, D_Microcosm, 0, "Simulate this?", NoList,
		CA_None, isSens, 109, 0, 110, 0, toolTips[50]},
	{C_TextIn, D_MicrocosmTemp, 0, NULLStr, NoList,
		CA_None, notSens, 109, 0, D_Microcosm, 5, toolTips[50]},
	{C_Label, 112, 0, "deg C", NoList,
		CA_None, isSens, 109, D_MicrocosmTemp, D_Microcosm},

	//	CO2 effects
	{C_Frame, 150, 0, NULLStr, NoList, CA_None, isSens, 140, 109, 0},
	{C_Label, 152, 0, "CO2 Effect", NoList,
		CA_None, isSens, 150, 0, 0},
	{C_CheckBox, D_CO2Effect, 0, "Simulate this?", NoList,
		CA_None, isSens, 150, 0, 152},
	{C_Label, 154, 0, "Year Start:", NoList,
		CA_None, isSens, 150, 0, D_CO2Effect, 8},
	{C_TextIn, D_CO2EffectYrSt, 0, NULLStr, NoList,
		CA_None, notSens, 150, 154, D_CO2Effect, 5, toolTips[15]},
	{C_Label, 156, 0, "Year End:", NoList,
		CA_None, isSens, 150, 0, D_CO2EffectYrSt, 8},
	{C_TextIn, D_CO2EffectYrEnd, 0, NULLStr, NoList,
		CA_None, notSens, 150, 156, D_CO2EffectYrSt, 5, toolTips[15]},

	// 14C data file name
	{C_Label, 160, 0, "File Name for 14C Data:", NoList,
		CA_None, isSens, D_ToggleFrame1, 0, 140, 31 },
	{C_TextIn, D_14CFileName, 0, NULLStr, NoList,
		CA_None, notSens, D_ToggleFrame1, 160, 140, 50, toolTips[46]},
	{C_Button, D_14CFileBrowse, D_14CFileBrowse, "Browse...",
		NoList,	CA_None, notSens, D_ToggleFrame1, D_14CFileName, 140,
		0, toolTips[46]},
	// erosion data file name
	{C_Label, 161, 0, "File Name for Erosion Output:", NoList,
		CA_None, isSens, D_ToggleFrame1, 0, D_14CFileBrowse, 31 },
	{C_TextIn, D_EroFileName, 0, NULLStr, NoList,
		CA_None, isSens,
		D_ToggleFrame1, 161, D_14CFileBrowse,
		50, toolTips[47]},
	{C_Button, D_EroFileBrowse, D_EroFileBrowse, "Browse...",
		NoList,	CA_None, isSens,
		D_ToggleFrame1, D_EroFileName, D_14CFileBrowse,
		0, toolTips[47]},
	// deposition data file name
	{C_Label, 162, 0, "File Name for Deposition Input:", NoList,
		CA_None, isSens, D_ToggleFrame1, 0, D_EroFileBrowse, 31 },
	{C_TextIn, D_DepFileName, 0, NULLStr, NoList,
		CA_None, isSens,
		D_ToggleFrame1, 162, D_EroFileBrowse,
		50, toolTips[48]},
	{C_Button, D_DepFileBrowse, D_DepFileBrowse, "Browse...",
		NoList,	CA_None, isSens,
		D_ToggleFrame1, D_DepFileName, D_EroFileBrowse,
		0, toolTips[48]},
	// block count
	{C_Label, 130, 0, "Simulation contains", NoList,
		CA_None, isSens,
		D_ToggleFrame1, 0, D_DepFileBrowse},
	{C_Label, D_SimBlkCnt, 0, "0", NoList,
		CA_None | CA_NoBorder, isSens,
		D_ToggleFrame1, 130, D_DepFileBrowse},
	{C_Label, 131, 0, "blocks.", NoList,
		CA_None, isSens,
		D_ToggleFrame1, D_SimBlkCnt, D_DepFileBrowse},

	//---	Toggle Frame 2 = Block definition dialog
	{C_ToggleFrame, D_ToggleFrame2, 0, NULLStr, NoList,
		CA_NoBorder | CA_Hidden, isSens, D_MasterFrame, 0, 0},
	//	ID numbers begins with 201
	{C_ColorLabel, 201, 0, description[1], (void *)&labelColor,
		CA_Hidden, isSens, D_ToggleFrame2, 0, 0},
	//	block list
	{C_Label, 202, 0, "1. Select Block:",
		NoList, CA_Hidden, isSens, D_ToggleFrame2, 0, 201},
	{C_List, D_BlkList, 80, NULLStr, (void*)dummyList,
		CA_Hidden | CA_ListWidth, isSens, D_ToggleFrame2, 0, 202,
		0, toolTips[16]},
	//	block list action buttons
	{C_Button, D_BlkNew, D_BlkNew,         "  Add Block  ",
		NoList,	CA_Hidden, isSens, D_ToggleFrame2, 0, D_BlkList,
		80, toolTips[17]},
	{C_Button, D_BlkNewCopy, D_BlkNewCopy, " Copy to New ",
		NoList,	CA_Hidden, isSens, D_ToggleFrame2, 0, D_BlkNew,
		80, toolTips[18]},
	{C_Button, D_BlkLibAdd, D_BlkLibAdd,   "From Library ",
		NoList,	CA_Hidden, notSens, D_ToggleFrame2, 0, D_BlkNewCopy,
		80, toolTips[19]},
	{C_Button, D_BlkDel, D_BlkDel,         "Delete Block ",
		NoList,	CA_Hidden, isSens, D_ToggleFrame2, 0, D_BlkLibAdd,
		80, toolTips[20]},
	//	event list
	{C_Label, 203, 0, "2. Select Event:",
		NoList, CA_Hidden, isSens, D_ToggleFrame2, D_BlkList, 201},
	{C_List, D_EvtList, 80, NULLStr, (void*)dummyList,
		CA_Hidden | CA_ListWidth, isSens,
		D_ToggleFrame2, D_BlkList, 203, 0, toolTips[21]},
	//	event list action buttons
	{C_Button, D_EvtNew, D_EvtNew,   " Add Event  ",
		NoList,	CA_Hidden, isSens, D_ToggleFrame2,
		D_BlkList, D_EvtList, 80, toolTips[22]},
	{C_Button, D_EvtDel, D_EvtDel,   "Delete Event", NoList,
		CA_Hidden, isSens, D_ToggleFrame2, D_BlkList, D_EvtNew,
		80, toolTips[23]},
	{C_Button, D_EvtSave, D_EvtSave, " Save Event ",
		NoList,	CA_Hidden, isSens, D_ToggleFrame2,
		D_BlkList, D_EvtDel, 80, toolTips[24]},
	//	Block description
	{C_Label, 295, 0, "Block Number:", NoList,
		CA_Hidden, isSens, D_ToggleFrame2, 0, D_BlkDel},
	{C_Label, D_BlkNumber, 0, "", NoList,
		CA_Hidden, isSens, D_ToggleFrame2, 295, D_BlkDel},
	{C_Label, 290, 0, "Block Description:", NoList,
		CA_Hidden, isSens, D_ToggleFrame2, 0, 295},
	{C_TextIn, D_BlkDesc, 0, NULLStr, NoList,
		CA_Hidden, isSens, D_ToggleFrame2, 290, 295, 40,
		toolTips[25]},
	{C_Button, D_BlkDescChange, D_BlkDescChange, "Change",
		NoList,	CA_Hidden, isSens, D_ToggleFrame2,
		D_BlkDesc, 295, 0, toolTips[26]},
	{C_Label, 230, 0, "Block contains", NoList,
		CA_Hidden, isSens, D_ToggleFrame2, 0, D_BlkDesc},
	{C_Label, D_BlkEvtCnt, 0, "0", NoList,
		CA_Hidden | CA_NoBorder | CA_Small, isSens,
		D_ToggleFrame2, 230, D_BlkDesc},
	{C_Label, 231, 0, "events.", NoList,
		CA_Hidden, isSens, D_ToggleFrame2, D_BlkEvtCnt, D_BlkDesc},
	{C_Label, 232, 0, " Events describe", NoList,
		CA_Hidden, isSens, D_ToggleFrame2, 231, D_BlkDesc},
	{C_Label, D_BlkLenYrs, 0, "0", NoList,
		CA_Hidden | CA_NoBorder | CA_Small, isSens,
		D_ToggleFrame2, 232, D_BlkDesc},
	{C_Label, 233, 0, "years.", NoList,
		CA_Hidden, isSens, D_ToggleFrame2, D_BlkLenYrs, D_BlkDesc},
	//	event type
	{C_Label, 204, 0, " Event Mnemonic:", NoList,
		CA_Hidden, isSens, D_ToggleFrame2, D_EvtList, 201},
	{C_Label, D_EvtType, 1, "None", NoList,
		CA_Hidden, isSens, D_ToggleFrame2, 204, 201},
	//	Event data: use toggle frames to select the proper data display
	{C_Frame, 205, 0, NULLStr, NoList,
		CA_Hidden | CA_NoSpace | CA_NoBorder, isSens, D_ToggleFrame2,
		D_EvtList, 204},
	//	1. No event selected
	{C_ToggleFrame, D_EvtTab_None, 0, NULLStr, NoList,
		CA_NoBorder | CA_Hidden, isSens, 205, 0, 0},
	{C_Text, 206, 0, "No event is selected, or\nno events are available.",
		NoList, CA_NoBorder | CA_Hidden, isSens, D_EvtTab_None, 0, 0},
	//	2. Standard event data
	{C_ToggleFrame, D_EvtTab_Std, 0, NULLStr, NoList,
		CA_Hidden, isSens, 205, 0, 0},
	{C_Label, 207, 0, "Year in Block:", NoList,
		CA_Hidden, isSens, D_EvtTab_Std, 0, 0, 15},
	{C_TextIn, D_EvtYear, 0, "1", NoList,
		CA_Hidden, isSens, D_EvtTab_Std, 207, 0, 5, toolTips[27]},
	{C_Label, 208, 0, "Month in Block:", NoList,
		CA_Hidden, isSens, D_EvtTab_Std, 0, D_EvtYear, 15},
	{C_TextIn, D_EvtMonth, 0, "1", NoList, CA_Hidden, isSens,
		D_EvtTab_Std, 208, D_EvtYear, 5, toolTips[28]},
	{C_Label, 209, 0, "Additional:", NoList,
		CA_Hidden, isSens, D_EvtTab_Std, 0, D_EvtMonth, 15},
	{C_TextIn, D_EvtAdd, 0, NULLStr, NoList, CA_Hidden, isSens,
		D_EvtTab_Std, 209, D_EvtMonth, 30, toolTips[29]},
	{C_Button, D_EvtAddChoose, D_EvtAddChoose, "Choose...",
		NoList,	CA_Hidden, isSens, D_EvtTab_Std, 209, D_EvtAdd,
		0, toolTips[30]},
	//	3. Range event data
	{C_ToggleFrame, D_EvtTab_Range, 0, NULLStr, NoList,
		CA_NoSpace | CA_Hidden, isSens, 205, 0, 0},
	//	...make a table for year/value @ start/end pairs
	{C_Blank, 291, 0, " ", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 0, 0, 10},
	//	...(i) column headers
	{C_Label, 210, 0, "Year:", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 291, 0},
	{C_Label, 211, 0, "Value:", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 210, 0},
	//	...(ii) row headers
	{C_Label, 212, 0, "Start:", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 0, 210, 10},
	{C_Label, 213, 0, "End:", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 0, 212, 10},
	//	...(iii) data cells
	{C_TextIn, D_RngYrStart, 0, "1", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 212, 210, 5, toolTips[31]},
	{C_TextIn, D_RngValStart, 0, "0.0", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, D_RngYrStart, 210,
		5, toolTips[32]},
	{C_TextIn, D_RngYrEnd, 0, "1", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 213, D_RngYrStart,
		5, toolTips[31]},
	{C_TextIn, D_RngValEnd, 0, "0.0", NoList,
		CA_Hidden, isSens, D_EvtTab_Range,
		D_RngYrEnd, D_RngValStart, 5, toolTips[32]},
	//	...fractions for each month
	{C_Blank, 292, 0, " ", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 0, D_RngYrEnd},
	{C_Label, 214, 0, "Monthly Fractions:", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 0, 292},
	//	...(i) row 1
	{C_Label, 215, 0, " 1", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 0, 214, 8},
	{C_TextIn, D_FracMo1, 0, "0.0", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 215, 214, 3, toolTips[33]},
	{C_Label, 216, 0, " 2", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, D_FracMo1, 214, 8},
	{C_TextIn, D_FracMo2, 0, "0.0", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 216, 214, 3, toolTips[33]},
	{C_Label, 217, 0, " 3", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, D_FracMo2, 214, 8},
	{C_TextIn, D_FracMo3, 0, "0.0", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 217, 214, 3, toolTips[33]},
	{C_Label, 218, 0, " 4", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, D_FracMo3, 214, 8},
	{C_TextIn, D_FracMo4, 0, "0.0", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 218, 214, 3, toolTips[33]},
	//	...(ii) row 2
	{C_Label, 219, 0, " 5", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 0, D_FracMo1, 8},
	{C_TextIn, D_FracMo5, 0, "0.0", NoList, CA_Hidden, isSens,
		D_EvtTab_Range, 219, D_FracMo1, 3, toolTips[33]},
	{C_Label, 220, 0, " 6", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, D_FracMo5, D_FracMo1, 8},
	{C_TextIn, D_FracMo6, 0, "0.0", NoList, CA_Hidden, isSens,
		D_EvtTab_Range, 220, D_FracMo1, 3, toolTips[33]},
	{C_Label, 221, 0, " 7", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, D_FracMo6, D_FracMo1, 8},
	{C_TextIn, D_FracMo7, 0, "0.0", NoList, CA_Hidden, isSens,
		D_EvtTab_Range, 221, D_FracMo1, 3, toolTips[33]},
	{C_Label, 222, 0, " 8", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, D_FracMo7, D_FracMo1, 8},
	{C_TextIn, D_FracMo8, 0, "0.0", NoList, CA_Hidden, isSens,
		D_EvtTab_Range, 222, D_FracMo1, 3, toolTips[33]},
	//	...(iii) row 3
	{C_Label, 223, 0, " 9", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, 0, D_FracMo5, 8},
	{C_TextIn, D_FracMo9, 0, "0.0", NoList, CA_Hidden, isSens,
		D_EvtTab_Range, 223, D_FracMo5, 3, toolTips[33]},
	{C_Label, 224, 0, "10", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, D_FracMo9, D_FracMo5, 8},
	{C_TextIn, D_FracMo10, 0, "0.0", NoList, CA_Hidden, isSens,
		D_EvtTab_Range, 224, D_FracMo5, 3, toolTips[33]},
	{C_Label, 225, 0, "11", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, D_FracMo10, D_FracMo5, 8},
	{C_TextIn, D_FracMo11, 0, "0.0", NoList, CA_Hidden, isSens,
		D_EvtTab_Range, 225, D_FracMo5, 3, toolTips[33]},
	{C_Label, 226, 0, "12", NoList,
		CA_Hidden, isSens, D_EvtTab_Range, D_FracMo11, D_FracMo5, 8},
	{C_TextIn, D_FracMo12, 0, "0.0", NoList, CA_Hidden, isSens,
		D_EvtTab_Range, 226, D_FracMo5, 3, toolTips[33]},

	//---	Toggle Frame 3 = Block instance dialog
	{C_ToggleFrame, D_ToggleFrame3, 0, NULLStr,
		NoList, CA_NoBorder | CA_Hidden, isSens, D_MasterFrame, 0, 0},
	//	ID numbers begins with 301
	{C_ColorLabel, 301, 0, description[2], (void *)&labelColor,
		CA_Hidden, isSens, D_ToggleFrame3, 0, 0},
	//	block list
	{C_Label, 302, 0, "1. Select Blocks:",
		NoList, CA_Hidden, isSens, D_ToggleFrame3, 0, 301},
	{C_List, D_BlkListInst, 80, NULLStr, (void*)dummyList,
		CA_Hidden | CA_ListWidth, isSens, D_ToggleFrame3, 0, 302,
		0, toolTips[34]},
	//	instance list
	{C_Label, 303, 0, "2. Select Instance:",
		NoList, CA_Hidden, isSens, D_ToggleFrame3, D_BlkListInst, 301},
	{C_List, D_InstList, 0, NULLStr, (void*)dummyList,
		CA_Hidden | CA_Large, isSens, D_ToggleFrame3,
		D_BlkListInst, 303, 0, toolTips[35]},
	//	instance list action buttons
	{C_Button, D_InstNew, D_InstNew, " Add Instance  ",
		NoList,	CA_Hidden, isSens, D_ToggleFrame3,
		D_BlkListInst, D_InstList, 0, toolTips[36]},
	{C_Button, D_InstNewCopy, D_InstNewCopy, "  Copy To New  ", NoList,
		CA_Hidden, isSens, D_ToggleFrame3, D_BlkListInst, D_InstNew,
		0, toolTips[37]},
	{C_Button, D_InstDel, D_InstDel,   "Delete Instance", NoList,
		CA_Hidden, isSens, D_ToggleFrame3,
		D_BlkListInst, D_InstNewCopy, 0, toolTips[38]},
	{C_Button, D_InstSave, D_InstSave, " Save Instance ", NoList,
		CA_Hidden, isSens, D_ToggleFrame3, D_BlkListInst, D_InstDel,
		0, toolTips[39]},
	//	Instance data: use toggle frames to select the data display
	{C_Frame, 320, 0, NULLStr, NoList,
		CA_Hidden | CA_NoSpace | CA_NoBorder, isSens, D_ToggleFrame3,
		D_InstList, 301},
	//	1. No instance selected
	{C_ToggleFrame, D_InstTab_None, 0, NULLStr, NoList,
		CA_NoBorder | CA_Hidden, isSens, 320, 0, 0},
	{C_Text, 321, 0, "No instance is selected, or\n"
			 "no instances are available.",
		NoList, CA_NoBorder | CA_Hidden, isSens, D_InstTab_None, 0, 0},
	//	2. Instance data
	{C_ToggleFrame, D_InstTab_Data, 0, NULLStr, NoList,
		CA_None | CA_Hidden, isSens, 320, 0, 0},
	//	years
	{C_Label, 305, 0, "Years in simulation:", NoList,
		CA_Hidden, isSens, D_InstTab_Data, 0, 0},
	{C_Label, 335, 0, "First:", NoList,
		CA_Hidden, isSens, D_InstTab_Data, 305, 0},
	{C_TextIn, D_FirstYear, 0, NULLStr, NoList,
		CA_Hidden, isSens, D_InstTab_Data, 335, 0, 5, toolTips[40]},
	{C_Label, 306, 0, " Last:", NoList,
		CA_Hidden, isSens, D_InstTab_Data, D_FirstYear, 0},
	{C_TextIn, D_LastYear, 0, NULLStr, NoList,
		CA_Hidden, isSens, D_InstTab_Data, 306, 0, 5, toolTips[40]},
	//	weather source
	{C_Frame, 307, 0, NULLStr, NoList,
		CA_Hidden, isSens, D_InstTab_Data,
		0, D_LastYear},
	{C_Label, 308, 0, "Weather source:", NoList,
		CA_Hidden, isSens, 307, 0, 0},
	{C_RadioButton, D_WthrMeans, 0,
		"Use mean weather values from the site file", NoList,
		CA_Hidden, isSens, 307, 0, 308},
	{C_RadioButton, D_WthrStoch, 1,
		"Generate values stochastically", NoList,
		CA_Hidden, isSens, 307, 0, D_WthrMeans},
	{C_RadioButton, D_WthrFileRew, 0,
		"Use weather file: Rewind file for more years", NoList,
		CA_Hidden, isSens, 307, 0, D_WthrStoch},
	{C_RadioButton, D_WthrFileCont, 0,
		"Use weather file: Continue in file as needed", NoList,
		CA_Hidden, isSens, 307, 0, D_WthrFileRew},
	//	output
	{C_Frame, 310, 0, NULLStr, NoList,
		CA_Hidden, isSens, D_InstTab_Data,
		307, D_LastYear},
	{C_Label, 311, 0, "Simulation Output:", NoList,
		CA_Hidden, isSens, 310, 0, 0},
	{C_Label, 312, 0, "Start Year:", NoList,
		CA_Hidden, isSens, 310, 0, 311, 12},
	{C_TextIn, D_OutputYr, 0, "1", NoList,
		CA_Hidden, isSens, 310, 312, 311, 5, toolTips[41]},
	{C_Label, 313, 0, "Start Month:", NoList,
		CA_Hidden, isSens, 310, 0, D_OutputYr, 12},
	{C_TextIn, D_OutputMo, 0, "1", NoList,
		CA_Hidden, isSens, 310, 313, D_OutputYr, 5, toolTips[42]},
	{C_Label, 314, 0, "Frequency:", NoList,
		CA_Hidden, isSens, 310, 0, D_OutputMo, 12},
	{C_TextIn, D_OutputFreq, 0, "1", NoList,
		CA_Hidden, isSens, 310, 314, D_OutputMo, 5, toolTips[43]},
	{C_Button, D_OutputFreqSel, D_OutputFreqSel, "Choose...",
		NoList,	CA_Small | CA_Hidden, isSens, 310, 314, D_OutputFreq,
		0, toolTips[44]},
	//	weather file
	{C_Label, 309, 0, "Weather File:", NoList,
		CA_Hidden, isSens, D_InstTab_Data, 0, 310},
	{C_TextIn, D_WthrFileName, 0, NULLStr, NoList,
		CA_Hidden | CA_Large, isSens, D_InstTab_Data, 309, 310,
		40, toolTips[45]},
	{C_Button, D_WthrFileBrowse, D_WthrFileBrowse, "&Browse...",
		NoList,	CA_Small | CA_Hidden, isSens, D_InstTab_Data, 309,
		D_WthrFileName, 0, toolTips[45]},
	{C_ColorLabel, D_WthrFileMsg, 0, NULLStr, (void *)&labelColor,
		CA_Hidden, isSens, D_InstTab_Data,
		D_WthrFileBrowse, D_WthrFileName, 40},
	//	Block description
	{C_Label, 304, 0, "Block Description:", NoList,
		CA_Hidden, isSens, D_ToggleFrame3, 0, D_InstSave},
	{C_Label, D_BlkDescInst, 0, NULLStr, NoList,
		CA_Hidden, isSens, D_ToggleFrame3, 304, D_InstSave, 60},
	{C_Label, 330, 0, "Block contains", NoList,
		CA_Hidden, isSens, D_ToggleFrame3, 0, 304},
	{C_Label, D_BlkInstCnt, 0, "0", NoList,
		CA_Hidden | CA_NoBorder, isSens, D_ToggleFrame3, 330, 304},
	{C_Label, 331, 0, "instances.", NoList,
		CA_Hidden, isSens, D_ToggleFrame3, D_BlkInstCnt, 304},

	//---	Common Buttons
	{C_Frame, 901, 0, NULLStr, NoList,
		CA_NoBorder, isSens,
		NoFrame, 0, D_MasterFrame},
	{C_Button, M_OK, M_OK, " &Done ",
		NoList,	CA_DefaultButton, isSens,
		901, 0, 0,
		0, toolTips[0]},
	{C_Button, D_NewMgt, D_NewMgt, "&New...",
		NoList,	CA_None, isSens,
		901, M_OK, 0,
		0, toolTips[2]},
	{C_Button, D_OpenMgt, D_OpenMgt, "&Open...",
		NoList,	CA_None, isSens,
		901, D_NewMgt, 0,
		0, toolTips[3]},
	{C_Button, D_ImpMgt, D_ImpMgt, "&Import...",
		NoList,	CA_None, isSens,
		901, D_OpenMgt, 0,
		0, toolTips[4]},
	{C_Button, D_MgtFromLib, D_MgtFromLib, "&From Library",
		NoList,	CA_None, isSens,
		901, D_ImpMgt, 0,
		0, toolTips[5]},
	{C_Button, D_SaveMgt, D_SaveMgt, "&Save...",
		NoList,	CA_None, notSens,
		901, D_MgtFromLib, 0,
		0, toolTips[6]},
	{C_Button, D_VerifyMgmt, D_VerifyMgmt, "&Verify",
		NoList,	CA_None, notSens,
		901, D_SaveMgt, 0,
		0, toolTips[49]},
	{C_Button, M_Help, M_Help, " &Help ",
		NoList, CA_None, isSens,
		901, D_VerifyMgmt, 0,
		0, toolTips[1]},

	{C_EndOfList, 0, 0, 0, 0, CA_None, 0, 0}
};

// ----------------------------------------------------------------------------
//	methods
// ----------------------------------------------------------------------------

TMgmtEditorDlg::TMgmtEditorDlg (
	// TCMIApp * const useParent,		// application parent
	vApp * const useParent,			// pointer to application
	TSharedPtr<TManagementScheme> newMgmt,	// original/final mgmt scheme
	std::string const & useHelpPath,	// path to help file
	std::string const & useMgmtLibPath,	// path to mgmt libraries
	std::string const & useUserLibPath,	// user's mgmt library path
	std::string const & useTemplatePath,	// path to template folder
	std::string const & useWorkPath,	// user's work path
	TEventDBList const & useDbList,		// parameter database list
	char const *  const title)		// dialog title
	: TModalDlg (useParent, title),
	  parent (useParent),
	  helpFilePath (useHelpPath),
	  mgmtLibPath (useMgmtLibPath),
	  userMgmtLibPath (useUserLibPath),
	  templatePath (useTemplatePath),
	  workPath (useWorkPath),
	  origMgmt (newMgmt),
	  dbList (useDbList)
{
	Initialize ();
	InitializeManagement ();
	vrfy = new TVerifyMgmt ( *mgmtDisp );

	// Get the indicies to cmdList items for lists.
	// Done only once for speed.
					// block list in definition dialog
	idxBlkListDef = GetItemIndexInCmdObj (cmdList, D_BlkList);
					// block list in instance dialog
	idxBlkListInst = GetItemIndexInCmdObj (cmdList, D_BlkListInst);
					// event list
	idxEvtList = GetItemIndexInCmdObj (cmdList, D_EvtList);
					// instance list
	idxInstList = GetItemIndexInCmdObj (cmdList, D_InstList);

	//--- create arrays to hold toggle button & frame IDs
	toggleCount = NUMBER_OF_TABS;
	// TO DO: add exception handling
	toggleButtonId = new ItemVal [toggleCount];
	Assert (toggleButtonId != NULL);
	toggleFrameId = new ItemVal [toggleCount];
	Assert (toggleFrameId != NULL);
	for (int i = 0; i < toggleCount; i++)
	{
		toggleButtonId[i] = Tab_Simulation + i;
		toggleFrameId[i] = D_ToggleFrame1 + i;
	}
	curButtonId = Tab_Simulation;
	curFrameId = D_ToggleFrame1;

	//--- display dialog
	AddDialogCmds ((CommandObject*)cmdList);	// add dialog controls
	ItemVal retVal;
	ShowModalDialog (title, retVal);
}

TMgmtEditorDlg::~TMgmtEditorDlg ()
{
	ClearDialogs ();
	ClearLists ();
	ClearManagement ();
	delete mgmtDisp;
	delete vrfy;

	// delete tab button memory
	delete [] toggleFrameId;
	delete [] toggleButtonId;
}

//	InitializeManagement
//	Copies the specified management scheme into the displayed
// 	management scheme.
//	Does NOT display the copied scheme.
void TMgmtEditorDlg::InitializeManagement ()
{
	// anything in the new mgmt?
	origMgmt = ::centuryConfig->GetManagement();
	bool isEmpty = ( origMgmt.get() ? origMgmt->IsEmpty() : true );

	// copy new mgmt to internal mgmt instance
	bool justAllocMgmt = false;	// true if we alloc mgmtDisp now
	if ( !mgmtDisp )		// make sure we have a mgmt instance
	{
		mgmtDisp = new TManagementScheme;
		justAllocMgmt = true;
	}
	if ( !isEmpty )			// have a mgmt scheme to copy?
	{
		if ( !justAllocMgmt )  	// Clear current mgmt
		{
			ClearDialogs ();
			ClearLists ();
			ClearManagement ();
		}
		*mgmtDisp = *origMgmt;		// copy the supplied mgmt.
		mgmtDisp->modified = false;	// no editing actions yet
		mgmtDisp->verified = false;	// don't know about this yet!
	}
}

void TMgmtEditorDlg::ToggleTheButton (ItemVal theButton)
{
	// show the selected frame
	if (theButton != curButtonId)
	{
		int i = theButton - Tab_Simulation;	// position in array
		Assert (i >= 0);

		SetValue (theButton, 1, Value);		// new button on
		SetValue (curButtonId, 0, Value);	// previous button off
		SetValue (curFrameId, 0, Value);	// previous frame off
		SetValue (toggleFrameId[i], 1, Value);	// new frame on
						// save new as current
		curButtonId = theButton;
		curFrameId = toggleFrameId[i];
		if ( curFrameId == D_ToggleFrame2 )
		{
			// Note: this is here due to a problem in v 1.16
			// in displaying nested toggle dialogs.
			// These frames are for a set of toggle dialogs nested
			// inside the main toggle dialog.
			// Putting these in "DialogDisplayed" does not have
			// any effect.
			// hide them all
			SetValue (D_EvtTab_None, 0, Value);
			SetValue (D_EvtTab_Std, 0, Value);
			SetValue (D_EvtTab_Range, 0, Value);
			// show the current frame
			ItemVal newId = D_EvtTab_None + (ItemVal) curEvtDlg;
			SetValue (newId, 1, Value);	// frame on
			// check button enabling/disabling
			ButtonDisplayBlkLst ();
			ButtonDisplayEvtLst ();
		}
		else if ( curFrameId == D_ToggleFrame3 )	// block inst.
		{
			// Note: this is here due to a problem in v 1.16
			// in displaying nested toggle dialogs.
			// These frames are for a set of toggle dialogs nested
			// inside the main toggle dialog.
			SetValue (D_InstTab_None, 0, Value);
			SetValue (D_InstTab_Data, 0, Value);
			if ( instDisp )
				SetValue (D_InstTab_Data, 1, Value);
			else
				SetValue (D_InstTab_None, 1, Value);
			// check button enabling/disabling
			ButtonDisplayInstLst ();
			// check for weather file display
			if ( instDisp )
			{
				if ( instDisp->weatherSource == WS_Means ||
				     instDisp->weatherSource == WS_Stochastic )
					DisableWeatherFileControls ();
				else
					EnableWeatherFileControls ();
			}
		}
	}
}

//	ShowEventDataDialog
//	Shows the specified event data toggle dialog.
void TMgmtEditorDlg::ShowEventDataDialog (TEvtDlgSelect which)
{
	if ( curFrameId == D_ToggleFrame2 )
	{
		// calc dialog IDs
		ItemVal prevId = D_EvtTab_None + (ItemVal) curEvtDlg;
		ItemVal newId = D_EvtTab_None + (ItemVal) which;
		if ( newId != prevId )
		{
			// display requested toggle dialog
			SetValue (prevId, 0, Value);	// previous frame off
			SetValue (newId, 1, Value);	// new frame on
		}
	}
	curEvtDlg = which;		// save new current
}

//	ShowInstDataDialog
//	Shows the specified instance toggle dialog.
void TMgmtEditorDlg::ShowInstDataDialog (ItemVal which)
{
	if ( curFrameId == D_ToggleFrame3 )
	{
		if (which == D_InstTab_None)
		{
			SetValue (D_InstTab_Data, 0, Value);
			SetValue (D_InstTab_None, 1, Value);
		}
		else	// D_InstTab_Data
		{
			SetValue (D_InstTab_None, 0, Value);
			SetValue (D_InstTab_Data, 1, Value);
		}
	}
}

void TMgmtEditorDlg::DialogCommand (ItemVal id, ItemVal val, CmdType type)
{
	// process events
	if (type == C_ToggleButton)
	{
		// tab button selected
		// First, save what needs to be saved before changing dialogs
		if ( curFrameId == D_ToggleFrame1 )		// sim. info
			GetDispSimInfo ();
		else if ( curFrameId == D_ToggleFrame2 )	// block def.
		{
			GetBlockDescrip ();
			if ( id == Tab_BlockInst )	// going to instances
			{
				// get index to item highlighted in list
				short i = (short)GetValue (D_BlkList);
				// block list in instances to match this one
				SetValue (D_BlkListInst, i, Value);
				UpdateDlg_InstList ();
			}
		}
		else if ( curFrameId == D_ToggleFrame3 )	// block inst.
		{
			if ( id == Tab_BlockDef )	// going to definition
			{
				// get index to item highlighted in list
				short i = (short)GetValue (D_BlkListInst);
				// block list in instances to match this one
				SetValue (D_BlkList, i, Value);
				UpdateDlg_EventList ();
			}
		}
		// Second, change dialog frame
		ToggleTheButton (id);
	}
	else if (type == C_Button)
	{
		switch (id)
		{
		  case M_OK:		// "done" button
		  	ConfirmSaveMgmt ();
			break;
		  case M_Help:			// "help" button
			if ( curFrameId == D_ToggleFrame1 )
			{
#ifdef MSWindowsHelp
				::HelpDisplay (parent->winHwnd(),
					helpFilePath,
					HELP_CONTEXT, IDH_SIMULATION_INFO);
#elif defined(X11Help)
				::HelpDisplay (winHwnd(),
					helpFilePath,
					HELP_CONTEXT, IDH_SIMULATION_INFO);
#endif
			}
			else if ( curFrameId == D_ToggleFrame2 )
			{
#ifdef MSWindowsHelp
				::HelpDisplay (parent->winHwnd(),
					helpFilePath,
					HELP_CONTEXT, IDH_DEFINE_BLOCKS);
#elif defined(X11Help)
				::HelpDisplay (winHwnd(),
					helpFilePath,
					HELP_CONTEXT, IDH_DEFINE_BLOCKS);
#endif
			}
			else
			{
#ifdef MSWindowsHelp
				::HelpDisplay (parent->winHwnd(),
					helpFilePath,
					HELP_CONTEXT, IDH_USE_BLOCKS);
#elif defined(X11Help)
				::HelpDisplay (winHwnd(),
					helpFilePath,
					HELP_CONTEXT, IDH_USE_BLOCKS);
#endif
			}
			break;
		  case D_NewMgt:		// new/clear mgmt scheme
			Evt_NewMgmtScheme ();
			break;
		  case D_OpenMgt:		// open a mgmt scheme
			Evt_OpenMgmtScheme ();
			break;
		  case D_ImpMgt:		// import Century4 schedule
			Evt_ImportMgmtScheme ();
			break;
		  case D_MgtFromLib:		// copy from the library
		  	Evt_CopyFromLibrary ();
			break;
		  case D_SaveMgt:		// save the current scheme
			Evt_SaveMgmtScheme ();
			break;
		  case D_VerifyMgmt:
			ConfirmVerifyMgmt ();
		  	break;
		  case D_MgtBaseNameChg:	// browse for netCDF file
			Evt_FileNameBaseChange ();
			break;
		  case D_14CFileBrowse:		// browse for  file name
			Evt_Browse14CFile ();
			break;
		  case D_EroFileBrowse:		// browse for  file name
			Evt_BrowseEroFile ();
			break;
		  case D_DepFileBrowse:		// browse for  file name
			Evt_BrowseDepFile ();
			break;
		  case D_BlkNew:		// add new block (clears first)
			Evt_AddNewBlock ();
			break;
		  case D_BlkDel:		// delete block highlighted
			Evt_DeleteBlock ();
			break;
		  case D_EvtNew:		// add new event (clears first)
			Evt_AddNewEvent ();
			break;
		  case D_EvtDel:		// delete event highlighted
			Evt_DeleteEvent ();
			break;
		  case D_EvtSave:		// save event data displayed
			Evt_SaveEventData ();
			break;
		  case D_EvtAddChoose:		// additional info for event
			Evt_EvtAddChoose ();
			break;
		  case D_InstNew:		// add new instance (clears)
			Evt_AddNewInstance ();
			break;
		  case D_InstDel:		// delete instance highlighted
			Evt_DeleteInstance ();
			break;
		  case D_InstSave:		// save instance data displayed
			Evt_SaveInstanceData ();
			break;
		  case D_WthrFileBrowse:	// browse for a weather file
			Evt_BrowseWthrFile ();
			break;
		  case D_BlkDescChange:		// change block description
			Evt_BlkDescChange ();
			break;
		  case D_InstNewCopy:		// copy instance to new
			Evt_CopyInstToNew ();
			break;
		  case D_BlkNewCopy:		// copy block to new
			Evt_CopyBlkToNew ();
			break;
		  case D_OutputFreqSel:		// select output interval
			Evt_OutputFreqSel ();
			break;
		  case D_InitSysCropSel:	// init. crop select
			Evt_InitSysCropSel ();
			break;
		  case D_InitSysTreeSel:	// init. tree select
			Evt_InitSysTreeSel ();
			break;
		  default:
			break;
		}
	}
	else if (type == C_RadioButton)
	{
		switch (id)
		{
		  case D_LabelTypeNone:	// C labeling type - none
			Evt_LabelTypeNone ();
			break;
		  case D_LabelType14C:	// C labeling type - 14C
			Evt_LabelType14C ();
			break;
		  case D_LabelType13C:	// C labeling type - 13C
			Evt_LabelType13C ();
			break;
		  case D_InitSysCrop:	// init. system = crop
			Evt_InitSysCrop ();
			break;
		  case D_InitSysTree:	// init. system = tree
			Evt_InitSysTree ();
			break;
		  case D_InitSysBoth:	// init. system = both
			Evt_InitSysBoth ();
		  	break;
		  case D_WthrMeans:
		  case D_WthrStoch:
		  case D_WthrFileCont:
			DisableWeatherFileControls ();
			break;
		  case D_WthrFileRew:
			EnableWeatherFileControls ();
			break;
		  default:
			break;
		}
	}
	else if (type == C_CheckBox)
	{
		switch (id)
		{
		  case D_Microcosm:	// simulate a microcosm
		  	Evt_Microcosm ();
		  case D_CO2Effect:	// use CO2 effect
			Evt_CO2Effect ();
			break;
		  default:
			break;
		}
	}
	else if (type == C_List)
	{
		switch (id)
		{
		  case D_BlkList:	// list selection: blocks in def. dlg.
			ConfirmSaveEventData ();
			GetBlockDescrip ();
			UpdateDlg_EventList ();
			break;
		  case D_EvtList:	// list selection: events
		  	ConfirmSaveEventData ();
			UpdateDlg_EventData ();
			break;
		  case D_BlkListInst:	// list selection: blocks in inst. dlg.
		  	ConfirmSaveInstData ();
			UpdateDlg_InstList ();
			break;
		  case D_InstList:	// list selection: instances
		  	ConfirmSaveInstData ();
			UpdateDlg_InstData ();
			break;
		  default:
			break;
		}
	}
	// things to check always
	ShowHideNotVerified ();
	ShowHideModified ();
	// Default event processing
	TModalDlg::DialogCommand (id, val, type);
}

//	DialogDisplayed
//	Overrides the vModelDialog method.
void TMgmtEditorDlg::DialogDisplayed ()
{
	TModalDlg::DialogDisplayed ();
	// Load the dialogs here
	LoadDlg_Simulation ();
	LoadDlg_BlockDef ();
	LoadDlg_BlockInst ();
	// things to check always
	ShowHideNotVerified ();
	ShowHideModified ();
}

//	Initialize
// 	initialize member variables
void TMgmtEditorDlg::Initialize ()
{
	// lists
	blkList = 0;
	evtList = 0;
	instList = 0;
	curEvtDlg = EvtDlg_NoEvt;
	// displayed management
	mgmtDisp = 0;
	blockDisp = 0;
	evtDisp = 0;
	instDisp = 0;
	vrfy = 0;
}

//	ClearDialogs
//	Clears the dialogs' controls; i.e., resets to default values.
//	Note: This does NOT clear the memory for the pointers used in these
//	lists! Use member function "ClearLists" AFTER this function
//	to release the memory for the member variable lists.
void TMgmtEditorDlg::ClearDialogs ()
{
	//--- Simulation data
	SetString (D_MgtBaseName, NULLStr);
	short const i =
		GetItemIndexInCmdObj (cmdList, D_MgtDescrip); // index to item
	SetString (D_MgtDescrip, cmdList[i].title);	  // use def. string
	SetString (D_YearStart, NULLStr);
	SetString (D_YearEnd, NULLStr);
	SetString (D_LabelYear, NULLStr);
	//SetString (D_SiteFileName, NULLStr);
	SetString (D_SimBlkCnt, "0");
	SetValue (D_LabelTypeNone, isChk, Value);
	SetValue (D_Microcosm, notChk, Value);
	SetValue (D_CO2Effect, notChk, Value);
	SetValue (D_InitSysCrop, isChk, Value);
	char const* noneStr = "None";
	SetString ( D_InitSysCropStr, noneStr );
	SetString ( D_InitSysTreeStr, noneStr );
	Evt_InitSysCrop ();

	ClearDlgBlkDefList ();	// block list in block definition dialog
	ClearDlgEvtList ();	// event list
	ClearDlgEvtData ();	// event data
	ClearDlgBlkInstList ();	// block list in block instance dialog
	ClearDlgInstList ();	// instance list
	ClearDlgInstData ();	// Instance data

	//--- Show the starting toggle dialogs
	ShowEventDataDialog (EvtDlg_NoEvt);	// select "no event"
	ShowInstDataDialog (D_InstTab_None);	// select "no instance"
	ToggleTheButton (Tab_Simulation);	// select "Simulation" tab
}

//	ClearDlgBlkDefList
// 	Clear block list display in the block definition dialog.
void TMgmtEditorDlg::ClearDlgBlkDefList ()
{
	// block list
	short const i = idxBlkListDef;			// index to list item
	cmdList[i].itemList = (void *)dummyList;	// set pointer to list
	SetValue (cmdList[i].cmdId, 0, ChangeListPtr);	// display list
	// descriptive fields
	SetString (D_BlkNumber, NULLStr);
	SetString (D_BlkDesc, NULLStr);
	SetString (D_BlkEvtCnt, NULLStr);
	SetString (D_BlkLenYrs, NULLStr);
	blockDisp = NULL;
}

//	ClearDlgEvtList
// 	Clear event list display
void TMgmtEditorDlg::ClearDlgEvtList ()
{
	short i = idxEvtList;				// index to list item
	cmdList[i].itemList = (void *)dummyList;	// set pointer to list
	SetValue (cmdList[i].cmdId, 0, ChangeListPtr);	// display list
	SetString (D_BlkEvtCnt, "0");
	evtDisp = NULL;
}

//	ClearDlgEvtData
// 	Clear event data display
void TMgmtEditorDlg::ClearDlgEvtData ()
{
	SetString (D_EvtType, "None");
	SetString (D_EvtYear, "1");
	SetString (D_EvtMonth, "1");
	SetString (D_EvtAdd, NULLStr);
	// range values and monthly fractions
	for (short i = 0; i < 16; i++)
		SetString (D_RngYrStart + i, "0");
}

//	ClearDlgBlkInstList
//	Clear the block list in inst. dialog
void TMgmtEditorDlg::ClearDlgBlkInstList ()
{
	// block list
	short i = idxBlkListInst;			// index to list item
	cmdList[i].itemList = (void *)dummyList;	// set pointer to list
	SetValue (cmdList[i].cmdId, 0, ChangeListPtr);	// display list
	// descriptive fields
}

//	ClearDlgInstList
// 	Clear instance list display
void TMgmtEditorDlg::ClearDlgInstList ()
{
	short i = idxInstList;				// index to list item
	cmdList[i].itemList = (void *)dummyList;	// set pointer to list
	SetValue (cmdList[i].cmdId, 0, ChangeListPtr);	// display list
	instDisp = NULL;
}

//	ClearDlgInstData
// 	Clear instance data display
void TMgmtEditorDlg::ClearDlgInstData ()
{
	SetString (D_BlkDescInst, NULLStr);
	SetString (D_BlkInstCnt, "0");
	SetString (D_FirstYear, "0");
	SetString (D_LastYear, "0");
	SetString (D_OutputYr, "1");
	SetString (D_OutputMo, "1");
	SetString (D_OutputFreq, "1");
	SetValue (D_WthrStoch, isChk, Value);
	SetString (D_WthrFileName, NULLStr);
}

//	ClearLists
//	Clears the block and event list member variables.
//	Note: This does NOT change the display of these lists in the dialogs.
//	Use member function "ClearDialogs" to clear the display of the lists.
void TMgmtEditorDlg::ClearLists ()
{
	ClearBlockList ();
	ClearEventList ();
	ClearInstList ();
}

//	ClearBlockList
// 	Clear blkList member variable
void TMgmtEditorDlg::ClearBlockList ()
{
	::DeleteNTCStringList (blkList);
}

//	ClearEventList
// 	Clear evtList member variable
void TMgmtEditorDlg::ClearEventList ()
{
	::DeleteNTCStringList (evtList);
}

//	ClearInstList
// 	Clear instList member variable
void TMgmtEditorDlg::ClearInstList ()
{
	::DeleteNTCStringList (instList);
}

//	ClearManagement
//	Clear the management variables
void TMgmtEditorDlg::ClearManagement ()
{
	blockDisp = 0;
	evtDisp = 0;
	instDisp = 0;
	mgmtDisp->Clear ();
}

//	ConfirmDelMgmt
//	Asks the user to confirm deletion of the current management scheme.
//	Returns true if "yes, delete" or false if "do not delete".
//	If "yes", the dialog is cleared and the current management scheme is
//	deleted from memory.
bool TMgmtEditorDlg::ConfirmDelMgmt ()
{
	if ( !mgmtDisp || mgmtDisp->IsEmpty() )	// if empty, don't ask
		return true;			// ...return "can replace"

	bool retVal = false;		// default response
	char msg[161];
	const char *msg1 = "Display of current management scheme\n"
			   "will be replaced ";
	const char *msg2 = "The current management scheme\n"
			   "has been modified but not saved.\n\n"
			   "Modifications will be lost ";
	const char *msg3 = "if you continue.\n\nDo you want to continue?";
	vYNReplyDialog ynDlg (this);

	// build the message
	if ( mgmtDisp && mgmtDisp->modified )
		strcpy (msg, msg2);
	else
		strcpy (msg, msg1);
	strcat (msg, msg3);

	// display and get response
	if ( ynDlg.AskYN ((char*)msg) == 1 )
	{
		retVal = true;		// delete is confirmed
		// delete the global variables!
		mgmtDisp->Clear ();	// yes, delete the contents
		// reset the paths in the management instance
		mgmtDisp->SetPaths (templatePath, workPath);
		// reset everything in the dialog
		ClearDialogs ();
		ClearLists ();
		ClearManagement ();
	}
	return retVal;
}

//	ConfirmSaveMgmt
//	If the mgmt. scheme has been changed but not saved, ask user
//	if want to save it.
void TMgmtEditorDlg::ConfirmSaveMgmt ()
{
	Assert (mgmtDisp != NULL);

	// make sure all the info is gotten from the dialogs
	if ( curFrameId == D_ToggleFrame1 )
		GetDispSimInfo ();
	if ( curFrameId == D_ToggleFrame2 )
		ConfirmSaveEventData ();
	else if ( curFrameId == D_ToggleFrame3 )
		ConfirmSaveInstData ();

	if ( mgmtDisp->IsEmpty() )		// if empty, don't ask
		return;

	// check with user
	ConfirmVerifyMgmt ();			// ask for verification action
	bool doConfirm =
		mgmtDisp->modified || !origMgmt.get() || origMgmt->IsEmpty();
	if ( !doConfirm )
		doConfirm = (*mgmtDisp != *origMgmt);
	if ( doConfirm )
	{
		// ask user if want to save
		vYNReplyDialog ynDlg (this, "Confirm");
		int answer = ynDlg.AskYN (
			"The management scheme displayed has been modified "
			"but not saved to disk.\n\n"
			"Do you want to save these changes?" );
		if ( answer == 1 )			// yes?
			Evt_SaveMgmtScheme ();
		else // "no" or "cancel"
			HistText ("Management was not saved.\n");
	}
}

//	ConfirmSaveEventData
//	If event data displayed differs from that saved, ask user if want
//	to save the changes.
void TMgmtEditorDlg::ConfirmSaveEventData ()
{
	if ( !evtDisp )			// anything to check?
		return;
	TManagementEvent newEvtDisp;	// stores event data from display
	GetEventData ( &newEvtDisp );	// retrieve data
	if ( newEvtDisp != *evtDisp &&
	     curEvtDlg != EvtDlg_NoEvt )  // data changed since last "save"?
	{
		// ask user if want to save
		vYNReplyDialog ynDlg (this, "Confirm");
		int answer = ynDlg.AskYN (
			"The event data has been changed but not saved.\n\n"
			"Do you want to save these changes?" );
		if ( answer == 1 )			// yes?
		{
			*evtDisp = newEvtDisp;		// copy
			mgmtDisp->modified = true;
		}
	}
}

//	ConfirmSaveInstData
//	If instance data displayed differs from that saved, ask user if want
//	to save the changes.
void TMgmtEditorDlg::ConfirmSaveInstData ()
{
	if ( !instDisp )		// anything to check?
		return;
	TManagementInst newInstDisp;	// stores instance data from display
	GetInstanceData ( &newInstDisp );	// retrieve data
	if ( newInstDisp != *instDisp )	// data changed since last "save"?
	{
		// ask user if want to save
		vYNReplyDialog ynDlg (this, "Confirm");
		int answer = ynDlg.AskYN (
			"The block instance data has been changed "
			"but not saved.\n\n"
			"Do you want to save these changes?" );
		if ( answer == 1 )			// yes?
		{
			*instDisp = newInstDisp;		// copy
			mgmtDisp->modified = true;
		}
	}
}

//	ConfirmVerifyMgmt
//	If management has not verified, ask user if want to verify.
void TMgmtEditorDlg::ConfirmVerifyMgmt ()
{
	if ( !mgmtDisp || mgmtDisp->IsEmpty() )		// if empty, don't ask
		return;
	if ( mgmtDisp->verified )			// already verified?
		return;

	// ask for verification action
	vYNReplyDialog ynDlg ( this, "Verify Management?" );
	int answer = ynDlg.AskYN ("Do you want to verify the\n"
				  "management information now?");
	if ( answer == 1 )
	{
		std::string errMsg = ::VerifyManagement( *mgmtDisp );
		if ( !errMsg.empty() )	// verify failed?
			MsgText ( errMsg.c_str() );
		if ( origMgmt.get() )
			origMgmt->verified = mgmtDisp->verified;
		ShowHideNotVerified ();
		vNoticeDialog noticeDlg ( this,
					  "Management Verification Results" );
		noticeDlg.Notice (
			mgmtDisp->verified ?
                          "Failed: See the message window for details." :
			  "No errors found." );
	}
}

//	ButtonDisplayBlkLst
//	Enable or disable buttons as needed - block list
void TMgmtEditorDlg::ButtonDisplayBlkLst ()
{
	if ( curFrameId == D_ToggleFrame2 )		// block definitions
	{
		if ( !mgmtDisp || mgmtDisp->GetBlockCount() == 0 )
		{
			// no blocks, so disable buttons & desc. except "add"
			SetValue ( D_BlkNewCopy, notSens, Sensitive );
			SetValue ( D_BlkDel, notSens, Sensitive );
			SetValue ( D_BlkDesc, notSens, Sensitive );
			SetValue ( D_BlkDescChange, notSens, Sensitive );
		}
		else
		{
			SetValue ( D_BlkNewCopy, isSens, Sensitive );
			SetValue ( D_BlkDel, isSens, Sensitive );
			SetValue ( D_BlkDesc, isSens, Sensitive );
			SetValue ( D_BlkDescChange, isSens, Sensitive );
		}
		ButtonDisplayEvtLst ();	// check the event list next
	}
}

//	ButtonDisplayEvtLst
//	Enable or disable buttons as needed - event list
void TMgmtEditorDlg::ButtonDisplayEvtLst ()
{
	if ( curFrameId == D_ToggleFrame2 )		// block definitions
	{
		// if no blocks, then can't add
		if ( !blockDisp || mgmtDisp->GetBlockCount() == 0 )
			SetValue ( D_EvtNew, notSens, Sensitive );
		else
			SetValue ( D_EvtNew, isSens, Sensitive );

		// if no events, then can't delete or save
		if ( !blockDisp || blockDisp->GetEventCount() == 0 )
		{
			// no events, so disable except "add"
			SetValue ( D_EvtDel, notSens, Sensitive );
			SetValue ( D_EvtSave, notSens, Sensitive );
			SetValue ( D_EvtList, notSens, Sensitive );
		}
		else
		{
			SetValue ( D_EvtDel, isSens, Sensitive );
			SetValue ( D_EvtSave, isSens, Sensitive );
			SetValue ( D_EvtList, isSens, Sensitive );
		}
	}
}

//	ButtonDisplayInstLst
//	Enable or disable buttons as needed - instance list
void TMgmtEditorDlg::ButtonDisplayInstLst ()
{
	if ( curFrameId == D_ToggleFrame3 )	// block instances
	{
		// if no blocks, then can't add or save
		if ( !blockDisp || mgmtDisp->GetBlockCount() == 0 )
		{
			SetValue ( D_InstNew, notSens, Sensitive );
			SetValue ( D_InstSave, notSens, Sensitive );
		}
		else
		{
			SetValue ( D_InstNew, isSens, Sensitive );
			SetValue ( D_InstSave, isSens, Sensitive );
		}

		// if no instances, then can't delete or copy
		if ( !blockDisp || blockDisp->GetInstanceCount() == 0 )
		{
			SetValue ( D_InstNewCopy, notSens, Sensitive );
			SetValue ( D_InstDel, notSens, Sensitive );
			SetValue ( D_InstList, notSens, Sensitive );
		}
		else
		{
			SetValue ( D_InstNewCopy, isSens, Sensitive );
			SetValue ( D_InstDel, isSens, Sensitive );
			SetValue ( D_InstList, isSens, Sensitive );
		}
	}
}

//	SelectListOfEvents
//	select an event from a list
//	Returns the event type assoicated with the selection.
//
//	NOTE: 	Until range events are implemented in Century,
//		DO NOT DISPLAY RANGE EVENTS in the list.
//	To use range events, changed initialization of numChoices.
//
TEventType TMgmtEditorDlg::SelectListOfEvents ()
{
	// build dialog
	//	Since Century does not yet understand all the new event types,
	//	stop at the end of the implemented events.
	//short const numChoices = (short) ET_EndOfList - 1;
	static short const numChoices = (short) ET_External;
	TChoicesDialog dlg (this,
			"Select the event to add\nto the current block:",
			numChoices, "Add Event to Block", true);
	short const half = numChoices / 2 - 1;	// half the list (zero-based)
	for (short i = 0; i < numChoices; i++)
	{
		dlg.AddChoice (eventDescrip[i + 1]);
		if ( i == half )
			dlg.NextColumn ();
	}
	// display choice to user
	short choice = dlg.GetChoice ();
	return static_cast<TEventType>(choice);
}

//	SelectEventOption
//	Select an event option from a list of options.
//	Returns the selected character string describing the option
//	or NULL if none.
//	Returns true if selected an option, else false if no selection made.
bool TMgmtEditorDlg::SelectEventOption (
	TEventType eventType,			// event
	char const * & optionText,		// event option string
	char const * const initialOptionText)	//   initial value
{
	Assert (eventType > ET_Unknown);
	Assert (eventType < ET_EndOfList);

	// buid dialog
	TEventOptionSet const & optionSet = *dbList.Get (
		static_cast<TEventDBList::DBIndex>(eventType - 1) );
	if ( !&optionSet )			// not in database list?
	{
		vNoticeDialog dlg (this, "No Event Options");
		std::string msg =
		    "No event options are available\n"
		    "for the event specified:\n";
		msg += ::eventName[eventType];
		dlg.Notice ( msg.c_str() );
		return 0;
	}
	short const numChoices = (short) optionSet.GetOptionCount();
	string caption = "Select the option for this event:\n";
	caption += eventName[eventType];
	TChoicesDialog dlg (this, caption.c_str(), numChoices,
				"Select Management Event Option", true);
	// column breaks at every 20 or so entries, evenly divided
	short breakEvery =
	    numChoices > 20 ?
	    (numChoices / ((short)((float)numChoices * 0.05f + 0.5f) + 1) ) :
	    numChoices;
	while ( numChoices % breakEvery < numChoices / 2 &&
		numChoices % breakEvery != 0 &&
		breakEvery <= numChoices )
		++breakEvery;
	// add strings to display
	short breakAt = breakEvery;
	short initialOptionNumber = 0;
	for (short i = 0; i < numChoices; i++)
	{
		std::string displayStr = optionSet.GetOption(i)->GetName();
		if ( initialOptionText && initialOptionNumber == 0 )
		{
			if ( displayStr == initialOptionText )
				initialOptionNumber = i + 1;
		}
		// add the description
		displayStr += ": ";
		displayStr += optionSet.GetOption(i)->GetDescription();
		dlg.AddChoice ( displayStr.c_str() );
		if ( i > 0 && i == breakAt - 1 )
		{
			dlg.NextColumn ();
			breakAt += breakEvery;
		}
	}
	// Set initial option
	dlg.InitialSelection (initialOptionNumber);
	// display choice to user
	short const choice = dlg.GetChoice ();
	if ( choice > 0 )				// selection made?
	{
		optionText = optionSet.GetOption(choice - 1)->GetName();
		return true;
	}
	else						// no selection
		return false;
}

//	ShowHideNotVerified
//	Toggles the display of the "not verified" message at the top
//	of the dialog.
inline
void TMgmtEditorDlg::ShowHideNotVerified ()
{
	Assert (mgmtDisp != NULL);
	if ( mgmtDisp->verified )
	{
		SetValue (D_MgmtVerified, 1, Hidden); 		// hide label
		SetValue ( D_VerifyMgmt, notSens, Sensitive );	// show button
	}
	else
	{
		SetValue (D_MgmtVerified, 0, Hidden); 		// show label
		SetValue ( D_VerifyMgmt, isSens, Sensitive );	// hide button
	}
}

//	ShowHideModified
//	Toggles the display of the "modified" message at the top
//	of the dialog.
inline
void TMgmtEditorDlg::ShowHideModified ()
{
	Assert (mgmtDisp != NULL);
	if ( mgmtDisp->modified )
	{
		SetValue (D_MgmtModified, 0, Hidden); 		// show label
		SetValue ( D_SaveMgt, isSens, Sensitive );	// show button
	}
	else
	{
		SetValue (D_MgmtModified, 1, Hidden); 		// hide label
		SetValue ( D_SaveMgt, notSens, Sensitive );	// hide button
	}
}

//	Enable14CFileName
//	Toggles the activation of the 14C data file name selection controls.
void TMgmtEditorDlg::Enable14CFileName (
	bool enable)	// if true, enable controls, else disable
{
	if ( enable )
	{
		SetValue ( D_14CFileName, isSens, Sensitive );
		SetValue ( D_14CFileBrowse, isSens, Sensitive );
	}
	else
	{
		SetValue ( D_14CFileName, notSens, Sensitive );
		SetValue ( D_14CFileBrowse, notSens, Sensitive );
	}
}

//	DisableWeatherFileControls
//	Deactivates the dialog controls for selecting/entering a weather file.
void TMgmtEditorDlg::DisableWeatherFileControls ()
{
	SetValue ( D_WthrFileName, notSens, Sensitive );
	SetValue ( D_WthrFileBrowse, notSens, Sensitive );
	SetValue ( D_WthrFileMsg, notSens, Sensitive );
}

//	EnableWeatherFileControls
//	Activates the dialog controls for selecting/entering a weather file.
void TMgmtEditorDlg::EnableWeatherFileControls ()
{
	SetValue ( D_WthrFileName, isSens, Sensitive );
	SetValue ( D_WthrFileBrowse, isSens, Sensitive );
	SetValue ( D_WthrFileMsg, isSens, Sensitive );
}

//	MakeBlkDescItemStr
//	Creates a string from the block description to go into the
//	the block selection lists.
//	Returns string pointer in "item".
//	Memory for string is allocated here if the "item" is null.
//	Pointer will be deallocated upon destruction.
void TMgmtEditorDlg::MakeBlkDescItemStr (
		char*& item, 		// string (can be null)
		char const* blkDesc)	// block's description
{
	if ( !item )				// need memory for string?
		item = new char [24];
	*item = '\0';
	register short len = strlen (blkDesc);	// description length
	if ( len > 20 )				// too long?
	{
		strncpy (item, blkDesc, 20);	// copy string
		item[20] = '\0';		// null-terminate
		strcat (item, "...");		// append "..."
	}
	else					// not too long:
		strcpy (item, blkDesc);		// get entire description
}

//	FileExists
//	Check that specified file exists.
//	Return true if it does, else false if not.
//	If it doesn't exist, give the user a warning.
bool TMgmtEditorDlg::FileExists (
	const TEH::TFileName* fileName,	//   name of the file
	char const* desc)		//   description of file for user
{
	bool retVal = true;
	if ( !fileName )
		retVal = false;
	else if ( !fileName->Exists() )
	{
		vNoticeDialog dlg (this, "File Not Found");
		std::string msg;
		msg += "The ";
		if ( desc )
			msg += desc;
		msg += " file you specified:\n\n";
		msg += fileName->GetFullName();
		msg += "\n\n";
		msg += "was not found.";
		dlg.Notice ( msg.c_str() );
		retVal = false;
	}
	return retVal;
}

//	FileIsValid
//	Check that specified file is a valid file name.
//	Return true if it is valid, else false if not.
//	If not valid, give the user a warning.
bool TMgmtEditorDlg::FileIsValid (
	const TEH::TFileName* fileName,	//   name of the file
	char const* desc)		//   description of file for user
{
	bool retVal = true;
	if ( !fileName )
		retVal = false;
	else if ( !fileName->IsValid() )
	{
		vNoticeDialog dlg (this, "File Name is Not Valid");
		std::string msg;
		msg += "The ";
		if ( desc )
			msg += desc;
		msg += " file you specified:\n\n";
		msg += fileName->GetFullName();
		msg += "\n\n";
		msg += "is not a valid file name.";
		dlg.Notice ( msg.c_str() );
		retVal = false;
	}
	return retVal;
}

//	AddWorkPath
//	Prepends work path to file name.
void TMgmtEditorDlg::AddWorkPath (
	TEH::TFileName* fileName)
{
	if ( fileName )
	{
		if ( !fileName->GetFullPath().empty() )
		{
			TEH::TFileName tmpName (
				workPath, TEH::TFileName::FT_Directory);
			tmpName.SetName ( fileName->GetName() );
			tmpName.SetExtension ( fileName->GetExtension() );
			*fileName = tmpName;
		}
	}
}
