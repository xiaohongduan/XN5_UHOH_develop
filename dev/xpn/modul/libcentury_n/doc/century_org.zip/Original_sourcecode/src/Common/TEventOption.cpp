// ----------------------------------------------------------------------------
//	Copyright 1997-2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TEventOption.cpp
//	Classes:
//	  TParamInfo
//	  TParameter
//	  TEventOption
//	  TEventOptionSet
//
//	Description:
//	Classes for Century parameters (formerly "*.100" files).
// ----------------------------------------------------------------------------
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TEventOption.h"
#include <algorithm>
#include <cctype>
#include <fstream>
#include <sstream>
using namespace std;

// ----------------------------------------------------------------------------
//	class TParamInfo
//---------------------------------------------------------------------------

//	Copy
// 	copy to this
void TParamInfo::Copy (TParamInfo const & object)
{
	if ( &object )
	{
		strcpy (name, object.name);
		min = object.min;
		max = object.max;
		if (object.description)
		{
		    char* tmpStr = new char [strlen(object.description) + 1];
		    strcpy (tmpStr, object.description);
		    description = tmpStr;
		}
	}
}

// ----------------------------------------------------------------------------
//	class TParameter
//---------------------------------------------------------------------------

TParameter& TParameter::operator = (const TParameter &obj)
{
	if (this != &obj)	// check for assignment to self
	{
		Initialize ();
		Copy (obj);
	}
	return *this;
}

// 	Equality based upon value and parameter name
bool TParameter::operator == (const TParameter &obj) const
{
	return ( value == obj.value &&
		 !strcmp(info->name, obj.info->name) );
}

//	Ordering based upon parameter value
bool TParameter::operator < (const TParameter& obj) const
{
	return (value < obj.value);
}

//--- private functions

inline void TParameter::Initialize ()			// initialize members
{
	value = 0.0f;
	info = 0;
	valid = false;
	modified = false;
}

inline void TParameter::Copy (const TParameter &fromObj)	// copy to this
{
	if ( &fromObj )
	{
		value = fromObj.value;
		info = fromObj.info;
		valid = fromObj.valid;
		modified = fromObj.modified;
	}
}

//--- public functions

//	CheckValue
//	Returns true if a valid value or not known, else false if invalid.
inline bool TParameter::CheckValue ()
{
	if ( info )
	{
		if ( value >= info->min && value <= info->max )
			return true;
		else
			return false;
	}
	return false;
}

//	Clear
//	clear member data
void TParameter::Clear ()
{
	Initialize ();
}


// ----------------------------------------------------------------------------
// Functions for TEventOption

//--- constructors and destructor

// The number of parameters for each event in the current parameter file
// is passed in.

//	Assignment
TEventOption& TEventOption::operator = (const TEventOption &obj)
{
	if (this != &obj)	// check for assignment to self
	{
		Initialize ();
		Copy (obj);
	}
	return *this;
}

//	Is equal to
bool TEventOption::operator == (const TEventOption &obj) const
{
	return !strcmp (name, obj.name) &&
		!strcmp (description, obj.description) &&
		param == obj.param;
}

//	Less than
//	Ordering based on option name (case-insensitive).
bool TEventOption::operator < (const TEventOption &obj) const
{
	bool retVal = false;
	if ( &obj )
	{
		char name1[_maxEventNameLen+1], name2[_maxEventNameLen+1];
		strcpy (name1, name);
		::strtolower ((char*)name1);
		strcpy (name2, obj.name);
		::strtolower ((char*)name2);
		if ( strcmp(name1, name2) < 0 )
			retVal = true;
	}
	return retVal;
}


//--- public functions

//	Clear
//	Erase member data.
void TEventOption::Clear ()
{
	param.erase (param.begin(), param.end());	// erase param vector
	Initialize ();
}

//--- private functions

void TEventOption::Initialize ()			// initialize members
{
	memset (name, '\0', _maxEventNameLen+1);
	memset (description, '\0', _maxEventDescLen+1);
}

void TEventOption::Copy (const TEventOption &fromObj)	// copy to this
{
	if ( &fromObj )
	{
		strcpy (name, fromObj.name);
		strcpy (description, fromObj.description);
		if ( fromObj.param.size() > 0 )
			param = fromObj.param;
	}
}

// ----------------------------------------------------------------------------
//	class TEventOptionSet
// ----------------------------------------------------------------------------

//--- constructors and destructor

TEventOptionSet::TEventOptionSet (
	int const useKey,		// event type for set
	TEH::TFileName const & newFileName)	// source file name
	: key (useKey)
{
	if ( ConstructMe (newFileName) )
	{
		// error msg stored in errMsg
	}
}

TEventOptionSet::TEventOptionSet (
	int const useKey,		// event type for set
	char const * const newFileName)		// source file name
	: key (useKey)
{
	TEH::TFileName theName (newFileName);
	if ( ConstructMe (theName) )
	{
		// error msg stored in errMsg
	}
}

TEventOptionSet::TEventOptionSet (
	int const useKey,		// event type for set
	std::string const newFileName)		// source file name
	: key (useKey)
{
	TEH::TFileName theName ( newFileName.c_str() );
	if ( ConstructMe (theName) )
	{
		// error msg stored in errMsg
	}
}

//--- operator overloads

//	Assignment
TEventOptionSet& TEventOptionSet::operator = (const TEventOptionSet &obj)
{
	if (this != &obj)	// check for assignment to self
	{
		Initialize ();
		Copy (obj);
	}
	return *this;
}

//	Is Equal To
bool TEventOptionSet::operator == (const TEventOptionSet &object) const
{
	bool retVal = false;
	if ( &object )
	{
		retVal = (key == object.key);
		if ( retVal )
			retVal = (name == object.name);
		if ( retVal )
			retVal = (description == object.description);
		if ( retVal )
			retVal = ( filePath == object.filePath &&
				   fileType == object.fileType &&
				   optionCount == object.optionCount &&
				   options == object.options &&
				   info == object.info &&
				   numParams == object.numParams );
	}
	return retVal;
}


//--- protected functions

//	ClearSets
// 	Erases all options set data.
void TEventOptionSet::ClearSets ()
{
	// erase contents of options set
	TSetOptions::iterator i = options.begin ();
	while ( i != options.end() )	// erase sets
	{
		const_cast<TEventOption&>(*i).Clear();
		++i;
	}

	info.erase (info.begin(), info.end());		// erase info vector
	options.erase (options.begin(), options.end());	// erase options set
	optionCount = 0;
	modified = true;
}

//--- public functions

//	Clear
//	Erases member variables.
void TEventOptionSet::Clear ()
{
	name.clear();
	description.clear();
	filePath.clear();
	ClearSets ();
	Initialize ();
	errMsg.clear ();
}

//	GetFileType
//	Returns the type of the specified file.
TParamFileType TEventOptionSet::GetFileType (
	TEH::TFileName const & fileName) const
{
	TParamFileType retVal = PFT_Unknown;

	// check for file type
	if ( fileName.IsValid() )
	{
		std::string const & ext = fileName.GetExtension();
		if ( !ext.empty() )			// anything there?
		{
			if ( ext == "100" )		// Century 4 file?
				retVal = PFT_Century4;
			else				// netCDF file?
			{
				if ( tolower(ext[0]) == 'n' &&
				     tolower(ext[1]) == 'c' &&
				     ext.size() == 2 )
				{
					retVal = PFT_netCDF;
				}
			}
		}
	}
	return retVal;
}

//	ImportCent4File
//	Import a Century 4.0 parameter (".100") file.
//	Returns false upon success, else true if not.
//	Stores error msg in errMsg.
bool TEventOptionSet::ImportCent4File ()
{
	bool retVal = false;		// default = success

	// error checks
	if ( fileType != PFT_Century4 )
		return true;

 	char const * const fileName = filePath.c_str();	// text name of file

	// Import the options and their parameters
	// Assumptions:
	// For each file, internal consistancy is required!
	// >   format of lines is not checked, so no format errors
	// >   1st line of parameter set = 2 strings, set name and description
	// >   1st set of parameters contain a complete list of parameters
	// >   parameter names are not duplicated within each option
	// >   input line lengths do not exceed 100 characters
	// >   1st char of line always != alpha for param. value + name lines
	// >   1st char of line always == alpha for option name + desc. lines
	// >   same number of parameters for each option
	// >   parameters are in the same order for each option

	// open the file as read only
	ifstream ifs;					// input file stream
	ifs.open (fileName, ios::in);			// open stream
	if ( !ifs.is_open() || !ifs.good() )
	{
		// why failed?
		int failedOpen = 0;
		if ( ifs.eof() )		// end of file
			failedOpen = 1;
		else if ( !ifs.good() )		// fatal
			failedOpen = 2;
		if ( failedOpen != 0 )
		{
			if ( !errMsg.empty() )
				errMsg += NL_CHAR;
			errMsg += "Error opening parameter database file: ";
			errMsg += fileName;
			errMsg += NL_CHAR;
			if ( failedOpen == 1 )
				errMsg += "Prematured end-of-file condition.";
			else if ( failedOpen == 2 )
				errMsg += "Unable to access the file.";
		}
		return failedOpen != 0;			// open failedOpen
	}

	// temporary variables
	char line[101];					// receives input line
	*line = '\0';
	short const nameLen = _maxEventNameLen + 1;
	char optName[nameLen];				// option name
	short const descLen = _maxEventDescLen + 1;
	char optDesc[descLen];				// option description
	float value;					// parameter value
	short const parNameLen = _maxParamNameLen + 1;
	char paramName[parNameLen];			// parameter name
	TEventOption opt;				// one option
	TParameter param;				// one parameter
	TParamInfo pInfo;				// one param. info.
	bool haveNames = false;				// flag - param. names
	char c;						// one character
	short count = 0;				// number of parameters

	// first, count the parameters in the first set
	ifs.getline (line, 101);			// get past opt. name
	ifs >> ws;
	while ( ifs && !ifs.eof() )
	{
		// read in a line
		ifs.getline (line, 101);		// next line
		ifs >> ws;
		if ( line && !(*line) )			// blank line?
			continue;
		if ( !line || isalpha(*line) )		// done with set?
			break;
		// check for obsolete names
		if ( FindObsoleteParameter(line) )
			continue;
		++count;				// count parameter
	}
	if ( !count )					// anything there?
		return true;				// ...no
	numParams = count;				// keep count
	ifs.clear ();					// clear any errors
	ifs.seekg (0, ios::beg);			// rewind

	// set vector capacity
	(opt.param).resize (numParams);
	info.resize (numParams);

	// read all the event option sets in the file
	while ( ifs && !ifs.eof() )			// until EOF...
	{
		// read in a line
		ifs.getline (line, 101);		// next line
		ifs >> ws;
		if ( line && !(*line) )			// blank line?
			continue;
		if ( !line || !ifs )			// done with set?
			break;

		// begin a new event option set
		opt.Clear ();
		std::istringstream ilss (line);		// stream for line

		// get set name and description
		ilss.width (nameLen);			// no overflow
		if ( !(ilss >> optName) )		// name
			break;
		ilss >> ws;
		if ( !(ilss.getline(optDesc,descLen)) )	// description
			break;
		opt.SetName (optName);
		opt.SetDescription (optDesc);

		// read parameters
		count = 0;
		while ( ifs && count <= numParams )
		{
			// check the next line
			ifs >> ws;
			c = (char) ifs.peek();		// peek at next char
			if ( !c )			// blank line?
				continue;		// ...skip it
			if ( !ifs || isalpha(c) ) 	// done with set?
				break;			// ...on to next set

			// get the value/parameter pair
			param.Clear ();
			if ( !(ifs >> value) )			// get value
			{
				if ( !errMsg.empty() )
					errMsg += NL_CHAR;
				errMsg += "Parameter set: ";
				errMsg += optName;
				errMsg += NL_CHAR;
				errMsg += "Error reading parameter value at: ";
				errMsg += line;
				retVal = true;
				break;				// error!
			}
			param.value = value;			// save
			if ( !(ifs.getline (line, 101)) )	// rest of line
			{
				if ( !errMsg.empty() )
					errMsg += NL_CHAR;
				errMsg += "Parameter set: ";
				errMsg += optName;
				errMsg += NL_CHAR;
				errMsg += "Error reading parameter name at: ";
				errMsg += line;
				retVal = true;
				break;				// error!
			}
			ifs >> ws;
			// check for obsolete names
			if ( FindObsoleteParameter(line) )
				continue;
			// save name
			::strtrim (line);
			if ( !haveNames )			// read name?
			{
				// copy and remove quotes around string
				short const len =
				    std::min ( (short)strlen(line) - 2,
					       parNameLen - 1 );
				strncpy (paramName, line + 1, len);
				paramName[len] = '\0';
				// save name
				strcpy (pInfo.name, paramName);
				pInfo.min = pInfo.max = 0.0;
				info.push_back (pInfo);	// save in vector
			}
			param.info = &(info[count]);	// point to info struct
			opt.param.push_back (param);	// save in set
			++count;
		}
		// Option set is finished.
		// check that parameters were read
		if ( count > 0 )
		{
			if ( !haveNames )		// get names only once
				haveNames = true;
			if ( AddOption (opt) )		// add to options set
			{
				if ( !errMsg.empty() )
					errMsg += NL_CHAR;
				errMsg += "Error adding parameter set: ";
				errMsg += optName;
				retVal = true;
				break;				// error!
			}
		}
	}

	// all done!
	ifs.close ();
	return retVal;
}

//	FindObsoleteParameter
//	Check for obsolete parameters that do not have replacements.
//	Returns true if found, else false.
bool TEventOptionSet::FindObsoleteParameter (
	char const* paramName)	//   parameter name to check
{
	// Assume paramName always has a value!
	static char const * const obsoleteNames[] = // list of obsolete names
	{
		"FFCRET", "SEED",
		0
	};
	const char * const *p = obsoleteNames;
	while ( *p )	// compare - assume uppercase input str
		if ( strstr (paramName, *(p++)) )	// found?
			return true;			// ...yes
	return false;					// ...no
}

//	AddOption
//	Adds an event option to the option set.
//	Returns false if successful, else true if not.
bool TEventOptionSet::AddOption (TEventOption& newOption)
{
	bool retVal = false;				// return value
	// create iterator and insert item
	pair<TSetOptions::iterator, bool> p = options.insert (newOption);
	if ( p.second )
	{
		modified = true;
		optionCount = (short) options.size ();	// update class member
	}
	else
		retVal = true;
	return retVal;				// return sequence number
}

//	GetOption
//	Returns a pointer to the option specified at the zero-based position.
//	Returns NULL if error or out-of-range option number.
TEventOption const * const TEventOptionSet::GetOption (
	unsigned short const optNum) const
{
	if ( optNum >= options.size () )		// anything there?
		return NULL;				// ...no

	TSetOptions::const_iterator i = options.begin ();	// start of set
	TSetOptions::difference_type dist = optNum;		// distance to
	advance (i, dist);					// go to
	return (TEventOption*) &(*i);				// return ptr
}

//	GetOption
//	Returns a pointer to the option with matching name..
//	Returns NULL if error or out-of-range option number.
TEventOption const * const TEventOptionSet::GetOption (
	char const * const name) const
{
	if ( !name || !(*name) )			// anything there?
		return NULL;				// ...no

	TSetOptions::const_iterator i = options.begin ();	// start of set
	while ( i != options.end() )			// search set...
	{
		const char * const optName = (*i).GetName ();
		if ( strcmp( optName, name ) == 0 )	// matching name?
			return (TEventOption*) &(*i);	// ...yes
		else
			++i;				// ...no, go to next
	}
	return NULL;					// no match
}

//	DeleteOption
//	Deletes the specified option specified by the zero-based option number.
//	Returns false if successfully deleted, else true.
bool TEventOptionSet::DeleteOption (
	unsigned short const optNum)
{
	if ( optNum >= options.size () )		// anything there?
		return true;				// ...no

	// delete the requested option
	TSetOptions::iterator i = options.begin ();	// start of set
	TSetOptions::difference_type dist = optNum;	// distance to
	advance (i, dist);				// go to
	options.erase (i);				// delete item
	optionCount = (short)options.size ();		// update class member
	// all done!
	modified = true;
	return false;
}

//	ReplaceOption
//	Replaces an option object specified by the zero-based option number
//	with the new option supplied.
//	Returns false if successfully replaced, else true.
//	If not successful, attempts to restore the original value.
bool TEventOptionSet::ReplaceOption (
	unsigned short const optNum,
	TEventOption& newOpt)
{
	if ( optNum >= options.size () )		// anything there?
		return true;				// ...no

	// go to the option number requested
	TSetOptions::iterator i = options.begin ();	// start of set
	TSetOptions::difference_type dist = optNum;	// distance to
	advance (i, dist);				// go to
	TEventOption prevOpt = *i;	// save the option prior to erasing
	options.erase (i);				// erase block
	if (!AddOption (newOpt))			// add replacement ok?
	{
		modified = true;			// ...yes
		return false;
	}
	else				// could not add the new one
		AddOption (prevOpt);	// try to replace the previous

	optionCount = (short)options.size ();		// update class member
	return true;					// return failed
}

//	OptionNameList
//	Build an list of strings containing options' names
//	in the order in which they appear in the option set.
//	Returns a NULL-terminated list of strings, or NULL if no options.
//	List pointer is owned by caller. Use DeleteCharList to delete memory.
char const ** TEventOptionSet::OptionNameList ()
{
	if ( !optionCount )				// anything there?
		return NULL;				// ...no

	// memory for list
	char** list = new char* [optionCount + 1];	// memory
	list[optionCount] = NULL;			// null-terminate list

	// add names to list
	TEventOption const * option;			// one option
	for ( short i = 0; i < optionCount; i++ )	// /for each option...
	{
		option = GetOption (i);			// next option
		list[i] = new char [strlen( option->GetName() ) + 1];
		strcpy ( list[i], option->GetName() );
	}
	return const_cast<char const **>(list);
}

//	OptionDescriptionList
//	Builds a list of strings containing options' descriptions
//	in the order in which they appear in the option set.
//	Returns a NULL-terminated list of strings, or NULL if no options.
//	List pointer is owned by caller.
char const ** TEventOptionSet::OptionDescriptionList ()
{
	if ( !optionCount )				// anything there?
		return NULL;				// ...no

	// allocate memory for list
	char **list = new char* [optionCount + 1];	// memory
	list[optionCount] = NULL;			// null-terminated list

	// retrieve option descriptions
	TEventOption const * option;			// one option
	for (short i = 0; i < optionCount; i++)
	{
		// next option set
		option = GetOption (i);
		if ( !option )				// anything there?
			break;
		// copy the description into the list
		if ( !option->GetDescription() )	// anything there?
			break;
		list[i] = new char [strlen( option->GetDescription() ) + 1];
		strcpy (list[i], option->GetDescription());
	}
	return const_cast<char const **>(list);
}

//	Initialize
//	initialize members
void TEventOptionSet::Initialize ()
{
	name.clear();
	description.clear();
	fileType = PFT_Unknown;
	optionCount = numParams = 0;
}

//	Copy
//	copy to this
void TEventOptionSet::Copy (const TEventOptionSet &fromObj)
{
	if ( &fromObj )
	{
		name = fromObj.name;
		description = fromObj.description;
		filePath = fromObj.filePath;
		fileType = fromObj.fileType;
		optionCount = fromObj.optionCount;
		numParams = fromObj.numParams;
		if ( numParams > 0 )
		{
			options = fromObj.options;
			info = fromObj.info;
		}
		modified = fromObj.modified;
	}
}

//	ConstructMe
//	Common construction.
//	Returns false if successful, else true if not.
bool TEventOptionSet::ConstructMe (
	TEH::TFileName const & newFileName)		// source file name
{
	Initialize ();
	bool retVal = false;			// return value
	if ( !newFileName.IsEmpty() && newFileName.IsValid() )
	{
		// get file type and validity
		fileType = GetFileType (newFileName);
		if ( fileType != PFT_Unknown )
		{
			filePath = newFileName.GetFullName (); // save file path
		}
		if ( fileType == PFT_Century4 )		// import Cent. 4 file
		{
			retVal = ImportCent4File ();
		}
	}
	else
	{
		retVal = true;
	}
	return retVal;
}

//--- end of file TEventOption.cpp ---

