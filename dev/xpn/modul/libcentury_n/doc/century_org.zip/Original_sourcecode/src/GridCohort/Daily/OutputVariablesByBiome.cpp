// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  OutputVariablesByBiome.cpp
//	Class:	  OutputVariablesByBiome
//
//	Description:
//	Management of output variables by biome for DayCentIRC.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, April 2005
//	History: See header file.
// ----------------------------------------------------------------------------

#include "OutputVariablesByBiome.h"
using namespace nrel::dcirc;

//	CollectOutputByBiome
//	Output for biomes separately.
void OutputVariablesByBiome::CollectOutputByBiome ()
{
	// to do: CollectOutputByBiome
	TOutVarValueArray::iterator iValues = values.begin();
	while ( iValues != values.end() )
	{
	    ++iValues;
	}
}

void OutputVariablesByBiome::DoUpdateValues ()
{
	CollectOutputByBiome ();
	AdjustForCumulativeValues ();
}


//--- end of file ---
