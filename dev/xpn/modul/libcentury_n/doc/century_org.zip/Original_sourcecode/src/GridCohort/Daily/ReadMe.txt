File:		Ecosystem/Century5/src/GridCohort/Daily/ReadMe.txt
Project:	IRC

This directory contains C++ source code for the IRC interface classes and
associated classes for the Daily Century model.

To configure a simulation, modify the following functions and files:

* TDayCentModel::ConfigureCentury
* DayCentIRC.cpp




--- end of file ---