// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  crop.cpp
//	Class:	  TDayCent
//	Function: SimulateCrop
//
//	Description:
//	Calculate the production for a crop.
// ----------------------------------------------------------------------------
//	History:
//      May01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Added IsTimeForOMAddtion() function call
//      * Added function arguments day, curYear
//      * Made this function a TDayCent function, formerly a TCentury function
//      4Sep01 Melannie Hartman, melannie@nrel.colostate.edu
//      * Added prodMonthFraction and prodTempMean function arguments
//      08Jan02 Melannie Hartman, melannie@nrel.colostate.edu
//      * Updated to keep consistent with TCentury::SimulateCrop()
// ----------------------------------------------------------------------------

#include "TDayCent.h"

void TDayCent::SimulateCrop (
	float const wfunc,	// water function (?)
	float const prodMonthFraction, // fraction of month over which
				       //   current production event occurs (0-1)
	float const prodTempMean)      // mean air temp over production period (deg C)
{
    // Option to add organic matter.
    if ( sched->DoingOMAddition() &&
	 IsTimeForOMAddition(st->dayOfYear, st->year) )
    {
	PartitionResidue (parcp.astgc, parcp.astrec, SRFC, soilC.csrsnk,
			  nps.esrsnk, parcp.astlig, parcp.astlbl);
    }

    // If microcosm selected, skip the rest of the crop code
    if ( SimMicrocosm() )
	return;

    // Do dead stuff
    SimulateFallStandingDead ();		// Fall of standing dead
    DeathOfRoots (prodTempMean);		// Death of roots
    DeathOfShoots (wfunc);			// Death of shoots
    // Update so direct absorption will be accounted for  before plant uptake.
    Update ();					// Update the flows and sums

    // Cultivation
    if ( sched->DoingCultivation() &&
	 IsTimeForCultivation(st->dayOfYear, st->year) )
    {
	SimulateCultivation ();
	Update ();				// Update the flows and sums

	// Check status of carbon values to make sure that everything
	// has been reset correctly; if carbon = 0, reset elements to 0 as well
	if (!AmountIsSignificant (cropC.aglcis[UNLABL] + cropC.aglcis[LABELD]))
		cropC.aglcis[UNLABL] = cropC.aglcis[LABELD] = 0.0f;
	if (cropC.aglcis[UNLABL] + cropC.aglcis[LABELD] == 0.0f)
	{
		for (short element = 0; element < site.nelem; ++element)
			nps.aglive[element] = 0.0f;
	}
	if (!AmountIsSignificant (cropC.bglcis[UNLABL] + cropC.bglcis[LABELD]))
		cropC.bglcis[UNLABL] = cropC.bglcis[LABELD] = 0.0f;
	if (cropC.bglcis[UNLABL] + cropC.bglcis[LABELD] == 0.0f)
	{
		for (short element = 0; element < site.nelem; ++element)
			nps.bglive[element] = 0.0f;
	}
	if (!AmountIsSignificant (cropC.stdcis[UNLABL] + cropC.stdcis[LABELD]))
		cropC.stdcis[UNLABL] = cropC.stdcis[LABELD] = 0.0f;
	if (cropC.stdcis[UNLABL] + cropC.stdcis[LABELD] == 0.0f)
	{
		for (short element = 0; element < site.nelem; ++element)
			nps.stdede[element] = 0.0f;
	}
	for (short element = 0; element < site.nelem; ++element)
	{
		if ( !AmountIsSignificant (nps.aglive[element]) )
			nps.aglive[element] = 0.0f;
		if ( !AmountIsSignificant (nps.bglive[element]) )
			nps.bglive[element] = 0.0f;
		if ( !AmountIsSignificant (nps.stdede[element]) )
			nps.stdede[element] = 0.0f;
	}
	SumCarbon ();
    }
    CropGrassGrowth (prodMonthFraction, prodTempMean);
}

//--- end of file ---

