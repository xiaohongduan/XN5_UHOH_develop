#ifndef INC_MgmtEditorDataSrcBase_h
#define INC_MgmtEditorDataSrcBase_h
// ----------------------------------------------------------------------------
//	Copyright 2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  MgmtEditorDataSrcBase.h
//	Class:	  MgmtEditorDataSrcBase
//
//	Description:
//	Base class for the data source for the Management Editor for
//	Century5 site management.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Nov03, tom.hilinski@colostate.edu
//	History:
// ----------------------------------------------------------------------------

#include "EditedDataBase.h"

template
<
	class ManagementType		// management object type
>
class MgmtEditorDataSrcBase
	: public EditedDataBase<ManagementType>
{
  public:
	virtual ~MgmtEditorDataSrcBase ()
	  {
	  }

  protected:
  	MgmtEditorDataSrcBase ()
	  : EditedDataBase<ManagementType> ()
  	  {
  	  }

  private:
	virtual bool DoIsEmpty () const
	  {
	    ManagementType const * const mgmt =
		dynamic_cast<ManagementType const * const>(
			dataPtr.get() );
	    return ( mgmt != 0 ?
	    		mgmt->IsEmpty() :
	    		true );
	  }
};

#endif // INC_MgmtEditorDataSrcBase_h
