// ----------------------------------------------------------------------------
//	Copyright 1997-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  T_ModalDlg.cpp
//	Class:	  TModalDlg
//
//	Description:
//	Base class for dialogs that are centered in the application window.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Oct97
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TModalDlg.h"

//--- constructors and destructor

//--- private methods

//--- public methods

//	GetItemIndexInCmdObj
//	Return the index to the CommandObject array for the CommandObject
//	item which has the matching cmdId.
short
TModalDlg::GetItemIndexInCmdObj (CommandObject *cmdObj, ItemVal cmdId)
{
	register short	i = 0;
	while (cmdObj[i].cmdType != C_EndOfList)
	{
		if (cmdObj[i].cmdId == cmdId)
			break;
		i++;
	}
	return i;
}

//	DialogDisplayed
//	This overrides the vDialog method.
void TModalDlg::DialogDisplayed ()
{
	// center the dialog in the app window
#if defined(V_VersionWindows) || defined(V_VersionWin95)
	// NOTE: The following is Windows-specific!
    RECT rectApp, rectDialog;			// app and dialog corners
    ::GetWindowRect(theApp->winClientHwnd(), &rectApp);
    ::GetWindowRect(_wDialog, &rectDialog);
    int const widthApp = rectApp.right - rectApp.left + 1;
    int const heightApp = rectApp.bottom - rectApp.top + 1;
    int const widthDialog = rectDialog.right - rectDialog.left + 1;
    int const heightDialog = rectDialog.bottom - rectDialog.top + 1;
    int newLeft, newTop;			// new dialog upper-left corner
    // SetDialogPosition wants dialog coords relative to the app.
    if ( widthApp > widthDialog )
	newLeft = (widthApp - widthDialog) / 2;
    else
	newLeft = 0;
    if ( heightApp > heightDialog )
	newTop = (heightApp - heightDialog) / 2;
    else
	newTop = 0;
    SetDialogPosition (newLeft, newTop);	// set the position, in V coords
#endif
}

//	DialogCommand
//	This overrides the vDialog method.
void TModalDlg::DialogCommand (ItemVal id, ItemVal val, CmdType type)
{
	vModalDialog::DialogCommand (id, val, type);	// call first
}

//	ShowModalDialog
//	This overrides the vDialog ShowModalDialog method.
ItemVal TModalDlg::ShowModalDialog (const char *message, ItemVal &retVal)
{
	ItemVal id;
	id = vModalDialog::ShowModalDialog (message, retVal);
	return id;
}


