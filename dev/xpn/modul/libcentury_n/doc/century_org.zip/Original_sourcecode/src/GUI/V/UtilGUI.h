#ifndef INC_UtilGUI_h
#define INC_UtilGUI_h
// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  UtilGUI.h
//
//	Description:
//	Misc. utility functions for use with CMI.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Oct2003
//	History:
// ----------------------------------------------------------------------------

#include "v/v_defs.h"
#include <vector>

namespace UtilGUI
{

typedef std::vector<CommandObject>		DlgCmdsArray;

DlgCmdsArray::size_type Size (		// Size of a CommandObject list
  CommandObject const * const cmdList);

void Copy (				// Copy a CommandObject list
  CommandObject const * const cmdList,	// from dialog elements struct array
  DlgCmdsArray & cmdArray);		// to vector of elements

void Copy (				// Copy to a CommandObject list
  DlgCmdsArray & cmdArray,		// from vector of dialog elements
  CommandObject * const cmdList);	// to dialog elements struct array

/*
class ::TTextCmdWindow;
class ::TCmdLineBase;

void DisplayCmdLineArgs (
	::TTextCmdWindow & window,
	::TCmdLineBase const & cmdLine);
*/

} // namespace UtilGUI

#endif 	// INC_UtilGUI_h
