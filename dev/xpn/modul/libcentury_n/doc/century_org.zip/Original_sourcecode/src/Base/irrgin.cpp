// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  irrgin.cpp
//	Class:	  TCentury
//	Function: GetIrrigation
//
//	Description:
//	Read the new irrigation parameter set.
//	Returns true if successful match in database, else false if not.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
// ----------------------------------------------------------------------------
//	History:
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Parameter set is now read in once only during a simulation,
//	  and stored in a TCentury member variable.
//	Jul01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to use new TEventDBList class.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "TEventDBList.h"
#include "util.h"
#include "constants.h"

MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::GetIrrigation (char const* irrigateToMatch)
{
	// error checks
	if ( !irrigateToMatch || !(*irrigateToMatch) )	// anything there?
		return false;

	// get the option set
	TEventOptionSet const & optionSet =
		*paramDbList->Get (TEventDBList::DBI_Irri);
	if ( !&optionSet )				// database not there?
		ThrowCentException (TCentException::CE_NSPPDB,
			::eventName[ET_Irrigate]);
	if ( !optionSet.GetOptionCount () )		// empty database?
		ThrowCentException (TCentException::CE_EMPPDB,
			::eventName[ET_Irrigate]);

	// get the option matching the parameter string
    	TEventOption const * const option =
    		optionSet.GetOption (irrigateToMatch);
	if ( !option )					// match found?
		return false;

	// retrieve values from option and save in Century's variables
	short const numParams = 4;			// total for an option
	short count = option->GetParamCount ();
	if ( count != numParams )			// counts match?
		ThrowCentException (TCentException::CE_OPCBAD,
			::eventName[ET_Irrigate]);

	register short k = 0;			// index to param values

	parcp.auirri = (int) option->GetParameter(k++)->GetValue();
	parcp.fawhc = option->GetParameter(k++)->GetValue();
	parcp.irraut = option->GetParameter(k++)->GetValue();
	parcp.irramt = option->GetParameter(k)->GetValue();

	// save option name in Century class variable
	strcpy (sched->curIrri, irrigateToMatch);		// save it

	return true;
}	/* GetIrrigation */
