// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  TCenturyConfigBase.cpp
//	Class:	  TCenturyConfigBase
//
//	Description: See header file.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@attbi.com, May03
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TCenturyConfigBase.h"
#include "SiteFillDefaultValues.h"
#include "VerifySiteParameters.h"
#include "stringutil.h"
#include <algorithm>

#define MY_TEMPLATE_DECLARATION \
	template <class TSite, class TSiteInfo>
#define TCENTURYCONFIGBASE \
	TCenturyConfigBase <TSite, TSiteInfo>

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

MY_TEMPLATE_DECLARATION
char const* const TCENTURYCONFIGBASE::defaultSiteName =	// default site name
	"site";
MY_TEMPLATE_DECLARATION
char const* const TCENTURYCONFIGBASE::defaultMgmtName =	// default mgmt name
	"management";
MY_TEMPLATE_DECLARATION
char const* const TCENTURYCONFIGBASE::defaultOutputName = // default output name
	"output";
MY_TEMPLATE_DECLARATION
char const* const TCENTURYCONFIGBASE::defaultUserName =	// default user name
	"unknown";

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

MY_TEMPLATE_DECLARATION
bool TCENTURYCONFIGBASE::operator== (
	TCenturyConfigBase const & object) const
{
	if ( &object )
	{
		return true; // To Do: TCENTURYCONFIGBASE::operator==
	}
	else
		return false;
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	Clear
// 	"clear" data members
MY_TEMPLATE_DECLARATION
void TCENTURYCONFIGBASE::Clear ()
{
	paths.reset ();
	site.reset ();
	mgmt.reset ();
	dbList.reset ();
	output.reset ();
	asynchCom.reset ();
	fixFile.clear ();
	userName.clear ();
	modified = true;
	ClearErrors ();
}

//	UseSite
//	Use the site parameter file name supplied.
//	This should be called AFTER the "paths" member is initialized via
//	InitializeDefaultPaths().
//	Returns the error state flag.
MY_TEMPLATE_DECLARATION
TCentException::TCEIndex TCENTURYCONFIGBASE::UseSite (
	std::string const & newSiteFile)	// site file name
{
	if ( newSiteFile.empty() )		// anything there?
	{
		siteError = TCentException::CE_NOSITE;
	}
	else
	{
		// site parameters' names and definitions
		typename TSiteInfo::TInfoPtr infoPtr (
			new TSiteInfo (
				paths->GetPath (CenturyPaths::TextData) ) );
		if ( infoPtr->IsEmpty() || !infoPtr->IsValid() )
		{
			siteError = TCentException::CE_NOSTPD;
			if ( !errorMsg.empty() )
				errorMsg += '\n';
			errorMsg += infoPtr->GetErrorMsg();
			goto allDone;
		}
		// next get site file
		TEH::TFileName siteFile (
			newSiteFile, TEH::TFileName::FT_Normal);
		if ( siteFile.IsEmpty() || !siteFile.Exists() )
			siteError = TCentException::CE_NOSITE;
		else if ( !siteFile.IsValid() )
			siteError = TCentException::CE_SITERR;
		else	// read site
		{
			siteError = TCentException::CE_NOERR;
			site.reset (
			    new TSite (
			      siteFile,
			      paths->GetPath (CenturyPaths::Templates).c_str(),
			      paths->GetPath (CenturyPaths::Work).c_str(),
			      infoPtr ) );
			if ( site->IsError() )
				siteError = TCentException::CE_SITERR;
		}
	}

	allDone:
	if ( siteError != TCentException::CE_NOERR)	// error?
	{
		if ( !newSiteFile.empty() && errorMsg.empty() )
		{
			errorMsg = "Site file: ";
			errorMsg += newSiteFile;
		}
		if ( site.get() )
		{
			if ( site->IsError() )
			{
				errorMsg += '\n';
				errorMsg += site->GetErrorMsg();
			}
		}
		site.reset ();				// ...clear site
	}
	return siteError;
}

MY_TEMPLATE_DECLARATION
TCentException::TCEIndex TCENTURYCONFIGBASE::UseSite (
	TSitePtr newSiteFile)
{
	if ( newSiteFile.get() == 0 )		// anything there?
	{
		siteError = TCentException::CE_NOSITE;
	}
	else
	{
		site = newSiteFile;
		if ( site->IsError() )
			siteError = TCentException::CE_SITERR;
		else
			siteError = TCentException::CE_NOERR;
	}
	if ( siteError != TCentException::CE_NOERR)	// error?
	{
		if ( site.get() )
		{
			if ( site->IsError() )
			{
				errorMsg += '\n';
				errorMsg += site->GetErrorMsg();
			}
		}
		site.reset ();				// ...clear site
	}
	return siteError;
}

//	UseManagement
//	Use the management scheme file name supplied.
//	This should be called AFTER the "paths" member is initialized via
//	InitializeDefaultPaths().
//	Returns the error state flag.
MY_TEMPLATE_DECLARATION
TCentException::TCEIndex TCENTURYCONFIGBASE::UseManagement (
	std::string const & newMgmtFile)
{
	if ( newMgmtFile.empty() )		// anything there?
	{
		mgmtError = TCentException::CE_NOMGMT;
	}
	else
	{
		TEH::TFileName fileName (
			newMgmtFile, TEH::TFileName::FT_Normal);
		if ( !fileName.IsValid() )
		{
			mgmtError = TCentException::CE_MGTFNV;
		}
		else if ( !fileName.Exists() )
		{
			mgmtError = TCentException::CE_NOMGMT;
		}
		else
		{
			mgmtError = TCentException::CE_NOERR;
			mgmt.reset ( new TManagementScheme (fileName) );
			if ( mgmt->IsError() )
			{
				mgmtError = TCentException::CE_MGTERR;
			}
			else if ( mgmt->IsEmpty() )
			{
				mgmtError = TCentException::CE_NOMGMT;
			}
			else
			{
				mgmt->SetPaths (
				    paths->GetPath (CenturyPaths::Templates),
				    paths->GetPath (CenturyPaths::Work) );
				if ( mgmt->IsError() )
					mgmtError = TCentException::CE_MGTERR;
			}
		}
	}
	if ( mgmtError != TCentException::CE_NOERR)	// error?
	{
		if ( !newMgmtFile.empty() && errorMsg.empty() )
		{
			errorMsg += "Management file: ";
			errorMsg += newMgmtFile;
			errorMsg += NL_CHAR;
		}
		if ( mgmt.get() )
		{
			if ( mgmt->IsError() )
			{
				errorMsg += NL_CHAR;
				errorMsg += mgmt->GetErrorMsg();
			}
		}
		mgmt.reset ();				// ...clear site
	}
	return mgmtError;
}

//	UseManagement
//	Use the management scheme supplied.
//	Transfer ownership of the pointer to this.
//	Returns the error state flag.
MY_TEMPLATE_DECLARATION
TCentException::TCEIndex TCENTURYCONFIGBASE::UseManagement (
	TMgmtPtr newMgmt)	// this management
{
	if ( newMgmt )			// anything to do?
	{
		mgmtError = TCentException::CE_NOERR;
		mgmt = newMgmt;
		if ( mgmt->IsError() )
		{
			mgmtError = TCentException::CE_MGTERR;
		}
		else if ( mgmt->IsEmpty() )
		{
			mgmtError = TCentException::CE_NOMGMT;
		}
		else
		{
			mgmt->SetPaths (
				paths->GetPath (CenturyPaths::Templates),
				paths->GetPath (CenturyPaths::Work) );
			if ( mgmt->IsError() )
				mgmtError = TCentException::CE_MGTERR;
		}
	}
	else	// no mgmt specified
	{
		mgmtError = TCentException::CE_NOMGMT;
	}
	if ( mgmtError != TCentException::CE_NOERR)	// error?
	{
		if ( mgmt.get() )
		{
			if ( mgmt->IsError() )
			{
				errorMsg += NL_CHAR;
				errorMsg += mgmt->GetErrorMsg();
			}
		}
		mgmt.reset ();				// ...clear site
	}
	return mgmtError;
}

MY_TEMPLATE_DECLARATION
bool TCENTURYCONFIGBASE::VerifySite ()
{
	bool haveError = false;
	if ( HaveSite() && siteError == TCentException::CE_NOERR )
	{
	    // fill in missing values
	    ::nrel::site::SiteFillDefaultValues
		<TSite, typename TSite::indices_type, TSiteInfo>
	      siteFill (
		*site,
		dynamic_cast<TSiteInfo const &>(
			*( site->GetSiteParamInfo() ) ),
		*dbList->Get(TEventDBList::DBI_Fix) );
	    haveError = siteFill.Process ();
	    if ( siteFill.HaveMessage() )
	    {
	    	warningMsg += siteFill.GetMessage();
	    }

	    // verify values are ok
	    ::nrel::site::VerifySiteParameters
		<TSite, typename TSite::indices_type, TSiteInfo>
	      siteVerify (
		*site,
		dynamic_cast<TSiteInfo const &>(
			*( site->GetSiteParamInfo() ) ) );
	    haveError = siteVerify.Verify();
	    if ( haveError )
	    {
	    	errorMsg += "Verification of site parameters failed:\n";
	    	errorMsg += siteVerify.GetMessage();
	    }
	    else if ( siteVerify.HaveMessage() )		// warnings?
	    {
	    	warningMsg += siteVerify.GetMessage();
	    }
	}
	return haveError;
}

MY_TEMPLATE_DECLARATION
bool TCENTURYCONFIGBASE::VerifyManagement ()
{
	bool haveError = false;
	if ( HaveManagement() && mgmtError == TCentException::CE_NOERR )
	{
	    // to do: VerifyManagement
	}
	return haveError;
}

//	FindAndThrowError
//	If error flag is set, throw an exception.
MY_TEMPLATE_DECLARATION
void TCENTURYCONFIGBASE::FindAndThrowError ()
{
	if (pathsError != TCentException::CE_NOERR)
		ThrowCentException ( pathsError, errorMsg.c_str() );
	if (siteError != TCentException::CE_NOERR)
		ThrowCentException ( siteError, errorMsg.c_str() );
	if (spiError != TCentException::CE_NOERR)
		ThrowCentException ( spiError, errorMsg.c_str() );
	if (mgmtError != TCentException::CE_NOERR)
		ThrowCentException ( mgmtError, errorMsg.c_str() );
	if (dbListError != TCentException::CE_NOERR)
		ThrowCentException ( dbListError, errorMsg.c_str() );
	if (outputError != TCentException::CE_NOERR)
		ThrowCentException ( outputError, errorMsg.c_str() );
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	InitializeDefaultPaths
MY_TEMPLATE_DECLARATION
void TCENTURYCONFIGBASE::InitializeDefaultPaths (
	std::string const & useCentHomePath,		// home or "exe" path
	std::string const & useWorkPath,	 	// path to work files
	std::string const & useParamPath,		// path to parameters
	std::string const & useTemplatePath,		// path to templates
	std::string const & useTextDataPath,		// path to text data
	std::string const & useSubdirectory)		// subdirectory name
{
	paths.reset ( new CenturyPaths (
				useCentHomePath,	// exe path
				useParamPath,		// parameters paths
				useTemplatePath,	// templates path
				useTextDataPath,	// text data path
				EMPTY_STRING,		// site lib
				EMPTY_STRING,		// block lib
				EMPTY_STRING,		// mgmt lib
				useWorkPath,		// working dir
				useSubdirectory ) );
	// if path list doesn't have the default parameter path, add it
	bool addParamPathToList = !paramPathList.empty();
	if ( !addParamPathToList )
	{
	    TStringArray::const_iterator i =
		std::find ( paramPathList.begin(), paramPathList.end(),
			    paths->GetPath (CenturyPaths::Parameters) );
	    addParamPathToList = (i == paramPathList.end() );
	}
	if ( addParamPathToList )
	{
		paramPathList.push_back (
			paths->GetPath (CenturyPaths::Parameters) );
	}
}

//	FindFix100File
//	Search for a valid fix.100 file name.
//	Prepend the path, if needed, to the existing file name.
//	If user-specified file is not found, use the default file fix.100
//	Assumes the "actual paths" in paths have been set.
MY_TEMPLATE_DECLARATION
void TCENTURYCONFIGBASE::FindFix100File (
	std::string & fileName,
	std::string const & outputPath,
	CenturyPaths const & paths)
{
	bool found = false;
	if ( !fileName.empty() )
	{
	    TEH::TFileName newFileName ( fileName, TEH::TFileName::FT_Normal);
	    if ( newFileName.GetFullPath().empty() )
	    {
		// 1. try work path
		if ( !paths.GetPath (CenturyPaths::Work).empty() )
		{
		    newFileName.SetPath (
		    	paths.GetPath (CenturyPaths::Work) );
		    found = newFileName.Exists();		// found it?
		}
		// 2. try output path
		if ( !found && !outputPath.empty() )
		{
		    newFileName.SetPath ( outputPath );
		    found = newFileName.Exists();		// found it?
		}
		// 3. try Parameters path
		if ( !found )
		{
		    newFileName.SetPath (
		    	paths.GetPath (CenturyPaths::Parameters) );
		    found = newFileName.Exists();		// found it?
		}
	    }
	    if ( found )
		fileName = newFileName.GetFullName();
	}
	if ( !found  || fileName.empty() )	// use default fix.100
	{
	    //  prefix with path to Parameters installation directory
	    TEH::TFileName newFileName (
	    	"fix.100",
	    	paths.GetPath (CenturyPaths::Parameters) );
	    fileName = newFileName.GetFullName();
	}
}

//	InitializeParamDBList
//	Setup the parameters database list.
MY_TEMPLATE_DECLARATION
void TCENTURYCONFIGBASE::InitializeParamDBList ()
{
	dbList.reset ( new TEventDBList ( paramPathList ) );

	// fix.100 file
	FindFix100File (fixFile, EMPTY_STRING, *paths);
	dbList->UseDatabaseFile (TEventDBList::DBI_Fix, fixFile);

	// load all parameter databases
	if ( dbList->LoadCent4Files() )				// failed?
	{
		dbListError = TCentException::CE_RDPDBF;
		errorMsg = dbList->GetErrorMessage();
	}
}

//	BuildOutputFileName
//	Builds the output file name.
//	If no name yet exists, builds the initial name for the user from
//	the management scheme file name.
//	If no site file name exists, builds the initial name from the
//	the site parameter file name.
//	If no path is present, adds the work path.
//	Guarantees that an output file name will be built.
//	Returns the newly built name.
MY_TEMPLATE_DECLARATION
std::string TCENTURYCONFIGBASE::BuildOutputFileName (
	std::string const & fileName)	// starting name
{
	std::string newFileName;		// return value

	// is there an output file name already specified?
	if ( fileName.empty() )		// nothing there?
	{
		// get root name
		if ( mgmt.get() && mgmt->GetBaseName() )	// use mgmt?
			newFileName = mgmt->GetBaseName();
		else if ( site.get() &&
			  !site->GetBaseName().empty() )	// use site?
			newFileName = site->GetBaseName();
		else						// default name
			newFileName = defaultOutputName;
	}
	else
		newFileName = fileName;

	// name has a path?
	TEH::TFileName tempFileName ( newFileName, TEH::TFileName::FT_Normal );
	std::string const path = tempFileName.GetFullPath (); // existing path?
	// if not, concatinate name part from fileName to work path
	if ( path.empty() )
	{
		// build fully-qualified name
		TEH::TFileName fullName (paths->GetPath(CenturyPaths::Work),
				    TEH::TFileName::FT_Directory );
		fullName.SetName ( tempFileName.GetName() );
		fullName.SetExtension ( tempFileName.GetExtension() );
		newFileName = fullName.GetFullName ();	// save to return
	}
	// all done!
	return newFileName;
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Copy
// 	copy to this
MY_TEMPLATE_DECLARATION
void TCENTURYCONFIGBASE::Copy (
	TCenturyConfigBase const & object)
{
	if ( &object )
	{
		//---- data: config info
		paths.reset ( object.paths->Clone() );
		site.reset ( new TSite (*object.site) );
		mgmt.reset ( new TManagementScheme (*object.mgmt) );
		dbList.reset ( new TEventDBList (*object.dbList) );
		doOutput = object.doOutput;
		if ( doOutput )
			output.reset ( object.output->Clone() );
		asynchCom.reset (
			new TAsynchCommunication (*object.asynchCom) );
		fixFile = object.fixFile;
		userName = object.userName;
		paramPathList = object.paramPathList;

		//---- data: other than config info
		modified = object.modified;

		//---- data: Error conditions
		warningMsg = object.warningMsg;
		errorMsg = object.errorMsg;
		pathsError = object.pathsError;
		siteError = object.siteError;
		spiError = object.spiError;
		mgmtError = object.mgmtError;
		dbListError = object.dbListError;
		outputError = object.outputError;
	}
}

//--- end of definitions for TCenturyConfigBase ---
