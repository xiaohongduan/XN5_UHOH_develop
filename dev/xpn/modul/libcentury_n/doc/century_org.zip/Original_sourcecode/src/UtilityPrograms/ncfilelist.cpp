// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  ncfilelist.cpp
//
//	Description:
//	Lists all the netCDF files in the current directory along with
//	a description of the CMI/Century file type.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Feb99
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------
//	Copyright (c) 1999, T.E. Hilinski. All rights reserved.
//	This software is made freely available for non-commercial use.
//	This copyright notice must remain intact and in place.
//	Modification of this software without permission of the author
//	is prohibited and a violation of this copyright.
// ----------------------------------------------------------------------------

#include "TNcFileFTDesc.h"
#include "TFileList.h"
#include <iostream>
#include <strstream>

char const* versionDate = "Version date: " __DATE__;
char const* description =
	"Displays descriptions of Century netCDF files\n"
	"located in the current directory.";
char const* copyright =
	"Copyright (c) 1999 Thomas E. Hilinski. All rights reserved.";

void Pause ()
{
	std::cerr << "\nPress Enter to continue:";
	std::cin.get ();
}

TNcFileType GetFileType (char const* name)
{
	TNcFileType type = NCFT_Unknown;

	// open the netCDF file
	NcFile ncFile (name, NcFile::ReadOnly);
	if ( ncFile.is_valid() )
	{
		// retrieve the attribute "FileType"
		NcAtt* attr = ncFile.get_att ("FileType");
		if ( attr && attr->is_valid() )
		{
			TNcFileType newType = (TNcFileType) attr->as_short (0);
			if ( newType >= NCFT_Unknown &&
			     newType < NCFT_EndOfList )
				type = newType;
		}
		delete attr;
	}

	// all done!
	ncFile.close ();
	return type;
}

void DisplayHelp ()
{
	std::cout << '\n' << ::description
	     << "\n\n" << "ncfilelist [options]\n"
	     << "  -v    Display software version.\n"
	     << "  -?    Display this help information.\n"
	     << "  -n    Do not pause for keypress when finished.\n"
	     << '\n' << ::copyright
	     << std::endl;
}

int main (int argc, char** argv)
{
	bool					// flags
		noPause = false,		// Do not pause when finished
		quitNow = false;		// exit program now

	// process command line arguments
	if ( argc > 1 )
	{
		short numArgs = argc - 1;
		char** args = &argv[1];
		while (numArgs > 0 && *args)
		{
			if ( !strcmp(*args, "-v") )
			{
				std::cout << ::versionDate << '\n'
				     << ::copyright << std::endl;
				quitNow = true;
			}
			else if ( **args == '?' ||
				  !strcmp(*args, "-?") ||
				  !strcmp(*args, "-help") ||
				  !strcmp(*args, "--help") )
			{
				::DisplayHelp ();
				quitNow = true;
			}
			else if ( !strcmp(*args, "-n") )
				noPause = true;
			--numArgs;
			++args;
		}
	}
	if ( quitNow )
		return 0;

	// retrieve description list from netCDF file
	TEH::TFileName descFile (argv[0]);		// executable path
	descFile.SetName ("NCFTypes");
	descFile.SetExtension ("nc");
	descFile.AppendToPath ("template");
	TNcFileFTDesc ftd (descFile);			// get descriptions
	char const* errStr = ftd.GetNcErrStr ();	// error string
	if ( errStr )					// error?
	{
		std::cout << "Unable to retrieve file descriptions." << std::endl;
		std::cout << "Error message: " << errStr << std::endl;
		::Pause ();
		return -1;
	}

	// get a list of netCDF files in the current directory
	char const* mask = "*.nc";			// file name mask
	TEH::TFileNameList fileList (			// get lists
		mask, TEH::TFileNameList::FLT_Normal);
	if ( fileList.IsError() )
	{
		std::cout << "Unable to obtain a list of files." << std::endl;
		::Pause ();
		return -1;
	}
	short const numFiles = fileList.GetCount ();	// number of files
	if ( numFiles == 0 )
	{
		std::cout << "No netCDF files found." << std::endl;
		::Pause ();
		return 0;
	}

	// get longest name in name list
	short maxLen = 0;				// maximum length
	short len;					// current length
	char const * const * names = fileList.GetList ();
	for ( short i = 0; i < numFiles; ++i )
	{
		len = strlen ( *(names++) );
		if ( len > maxLen )
			maxLen = len;
	}

	// create a string and stream to hold output information
	len = maxLen + 81;				// output string length
	char* os = new char [len];			// output string
	std::ostrstream oss (os, len);

	// list files and corresponding descriptions
	names = fileList.GetList ();			// get list of names
	TNcFileType type;				// "FileType" attribute
	std::cout << "\nCentury NetCDF files in the current directory:\n";
	for ( short i = 0; i < numFiles; ++i )
	{
		oss << *names << ":\t";
		type = ::GetFileType (*names);
		oss << ftd.GetDesc (type) << std::ends;
		std::cout << os << std::endl;
		++names;				// next name
		oss.seekp (0, std::ios::beg);		// reset streams
	}
	std::cout.flush ();

	// all done!
	delete [] os;
	if ( !noPause )
		::Pause ();
	return 0;
}