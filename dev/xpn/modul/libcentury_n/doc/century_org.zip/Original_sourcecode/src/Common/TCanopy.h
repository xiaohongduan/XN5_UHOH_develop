#ifndef INC_TCanopy_h
#define INC_TCanopy_h

// ----------------------------------------------------------------------------
//	Copyright 2000-2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCanopy.h
//	Class:	  TCanopy
//
//	Description:
//	Encapsulates tree canopy information and calculations.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec00
//	History:
//	Dec00	Tom Hilinski
//	* Extracted canopy info/calcs from class TCentury and put it here.
//	  This is just a starting skeleton - only LAI initially.
//	Jun01	Tom Hilinski
//	* Added member Clear().
//	Jul02	Tom Hilinski
//	* Added copy constructor.
//	Jun05	Tom Hilinski
//	* Added functions BiomassFromLAI, GetMaximumLAI.
// ----------------------------------------------------------------------------

class TCanopy
{
  public:
  	TCanopy ()
  	  {
  	    Initialize();
  	  }
	virtual ~TCanopy ()
	  {
	  }
	TCanopy (TCanopy const & object)  // copy constructor
	  {
	    Copy (object);
	  }

	//---- operator overloads

	//---- functions

  	//--- functions - leaf area index
	void SetLAIParameters (		// Set the LAI parameters
	  float const useMaxLAI,		//   new maxLAI
	  float const useKLAI,			//   new kLAI
	  float const useBiomassToLAI);		//   new biomassToLAI
	float LAI (				// Leaf area index calculation
	  float const leafC,			//   C in leaf (g/m2)
	  float const largeWoodC		//   C in large wood (g/m2)
	  ) const;
	float GetBiomassToLAI () const
	  { return biomassToLAI; }
	float BiomassFromLAI (
	  float const lai) const
	  {
	    return lai / (biomassConversionFactor * biomassToLAI);
	  }
	float GetMaximumLAI () const
	  { return maxLAI; }
	void Clear ()				// "Clear" data members
	  { Initialize (); }

  protected:
  	//--- constants
	static float const biomassConversionFactor;

  	//--- data
  	float maxLAI;			// Theoretical maximum LAI
  					//   in mature forest.
	float kLAI;			// Large wood mass at which half of the
					//   theoretical max. LAI is achieved
	float biomassToLAI;		// Biomass to LAI conversion factor

  	//--- functions

  private:
  	//--- data

  	//--- functions
  	void Initialize ()			// Initialize data members
  	  {
  	    maxLAI = kLAI = biomassToLAI = 0.0f;
  	  }
	void Copy (TCanopy const & object)	// Copy to this
	  {
	    if ( &object )
	    {
	    	maxLAI = object.maxLAI;
	    	kLAI = object.kLAI;
	    	biomassToLAI = object.biomassToLAI;
	    }
	  }
};

#endif // INC_TCanopy_h
