// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  fertincpp
//	Class:	  TCentury
//	Function: GetFertilization
//
//	Description:
//	Read the new fertilization parameter set.
//	Returns true if successful match in database, else false if not.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
// ----------------------------------------------------------------------------
//	History:
//	Jul01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to use new TEventDBList class.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "TEventDBList.h"
#include "util.h"
#include "constants.h"

MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::GetFertilization (
	char const* fertToMatch)
{
	// error checks
	if ( !fertToMatch || !(*fertToMatch) )		// anything there?
		return false;

	// get the option set
	TEventOptionSet const & optionSet =
		*paramDbList->Get (TEventDBList::DBI_Fert);
	if ( !&optionSet )				// database not there?
		ThrowCentException (TCentException::CE_NSPPDB,
			::eventName[ET_Fertilize]);
	if ( !optionSet.GetOptionCount () )		// empty database?
		ThrowCentException (TCentException::CE_EMPPDB,
			::eventName[ET_Fertilize]);

	// get the option matching the parameter string
    	TEventOption const * const option = optionSet.GetOption (fertToMatch);
	if ( !option )					// match found?
		return false;

	// retrieve values from option and save in Century's variables
	short const numParams = 4;			// total for an option
	short count = option->GetParamCount ();
	if ( count != numParams )			// counts match?
		ThrowCentException (TCentException::CE_OPCBAD,
			::eventName[ET_Fertilize]);

	register short k = 0;			// index to param values
	register short i;			// loop indices

    	for (i = 0; i < 3; ++i)
		param.feramt[i] = option->GetParameter(k++)->GetValue();
	param.aufert = option->GetParameter(k)->GetValue();

	// save option name in Century class variable
	strcpy (sched->curFert, fertToMatch);
	return true;
}

//--- end of fertin.cpp ---/

