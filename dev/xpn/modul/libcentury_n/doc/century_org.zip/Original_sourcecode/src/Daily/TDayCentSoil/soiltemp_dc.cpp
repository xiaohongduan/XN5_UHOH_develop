// ----------------------------------------------------------------------------
//    Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//    Project:  Century Soil Organic Matter Model, daily version
//    File:	soiltemp_dc.cpp
//    Class:	TDayCentSoil
//    Function: Soil temperature submodel
//
//    Description:
//    Calculates soil temperature distribution thru soil profile.
//    The model is described in the following papers,
//    Parton, W.J. and J.A. Logan. 1981. A model for diurnal variation in
//      soil and air temperature. Agric. Meteorol. 23:205-216.
//    Parton, W.J. 1984. Predicting soil temperature in a shortgrass steppe.
//      Soil Science 138:2:93-101.
//    Eitzinger, J., W.J. Parton, and M. Hartman. 2000. Improvement and
//      validation of a daily soil temperature submodel for freezing/thawing
//      periods. Soil Science 165:525-534.
//
//	Functions:
//	InitializeSoilTempModel
//	InitTemperatureLayers
//	AllocSoilTemperatureLayers
//	CopySoilTempModel
//	CheckSoilTempValues
//	CalcSoilTemperatures		(To Do: break into pieces)
// ----------------------------------------------------------------------------
//    Author: Melannie Hartman, Bill Parton, Josef Eitzinger
//    History:
//    Sep1994  Melannie Hartman, melannie@NREL.colostate.edu
//    * Created soiltemp.c from soiltemp.f and linked it to the
//      daily soil water model
//    Apr1997  Melannie Hartman, melannie@NREL.colostate.edu
//    * Linked soiltemp.c to FORTRAN/C version of DayCent
//    Jan1999 Josef Eitzinger + Melannie Hartman
//    * Modified and adapted for frost/thaw periods during winter
//    Apr2001	 Melannie Hartman, melannie@NREL.colostate.edu
//    * Translated soiltemp.c to soiltemp.cpp
//	Jul02	Tom Hilinski
// 	* Lots of misc. cleanup
//	  (1) fix double vs. float complaints by g++ 3.04
//	  (2) fix FP error found by BCB5
//	  (3) Use float constants where needed to prevent promotion to double.
//	  (4) Remove all cerr and cout statements.
//	  (5) Make all dynamically allocated arrays to be class members
//	      so they are allocated only once unless need to be made larger!
//	  (6) Correct calc of nd so it rounds as expected.
//	Dec02-Feb03	Tom Hilinski
//	* Misc. cleanup and consolidation of temperature functions.
// ----------------------------------------------------------------------------
//	To Do:
//      * What components make up "biomass".  Live standing?  Dead standing?
//	  Litter?
//      * What to do about min soil surface temp > max soil surface temp?
//	  -mdh 9/28/01
// ----------------------------------------------------------------------------

#include "TDayCentSoil.h"
#include "TDayCentException.h"
#include "precision.h"
#include "TCenturyMath.h"
using namespace std;
#ifdef __BCPLUSPLUS__
#include "fastmath.h"
#endif

// the following should be a member of the soil thermal class:
namespace
{

  static float meanAirTempPreviousDay = -999.0f;

} // namespace



//	InitializeSoilTempModel
//	Initialize variables used in the soil temperature submodel.
void TDayCentSoil::InitializeSoilTempModel ()
{
	avgThermalDiffusivUnFrzn = 0.00215f;		// default value
	avgThermalDiffusivFrzn = 0.00215f;		// default value
	soilTemperatureInterval = 2.0f;			// default value
	soilTemperatureDmpFactor = 0.00450f;		// default value
	soilBottomTempMin = -999.0f;			// undefined value
	soilBottomTempMax = -999.0f;			// undefined value
	soilBottomTimeLag = -1.0f;			// undefined value
	numSoilTemperatureLayers = 0;
}

//	InitTemperatureLayers
//      Initialzie soil temperature layers
void TDayCentSoil::InitTemperatureLayers (
    int const numberSoilLayers,			// # of soil layers in profile
    TSoilBase::TFloatArray const & soilTemp)	// temperature of layers (deg C)
{
    Assert ( soilTemperatureInterval > 0.0f );
    Assert ( numberSoilLayers > 0 && numberSoilLayers <= MAXLYR );
    Assert ( soilTempLyrAvg.size() > 0 );
    Assert ( soilTempLyrMin.size() > 0 );
    Assert ( soilTempLyrMax.size() > 0 );
    Assert ( freezeEnergyPool.size() > 0 );
    Assert ( numSoilTemperatureLayers > 0 );

    short layer = 0;				// soil layer
    // depth to midpoint of soil temp layer (cm)
    float soilTempLayerMidpoint = 0.0f;		// temp at midpt of layer
    for ( short soilTempLayer = 0;
	  soilTempLayer < numSoilTemperatureLayers &&
		soilTempLayerMidpoint < depth[numberSoilLayers - 1];
	  soilTempLayer++ )
    {
	soilTempLayerMidpoint =
		soilTemperatureInterval * (soilTempLayer + 0.5f);
	for ( ; layer < numberSoilLayers; layer++ )
	{
	    if ( soilTempLayerMidpoint > (depth[layer] - thickness[layer]) &&
		 soilTempLayerMidpoint <= depth[layer] )
	    {
		soilTempLyrAvg(soilTempLayer) =
			soilTempLyrMin(soilTempLayer) =
			soilTempLyrMax(soilTempLayer) = soilTemp[layer];
		break;
	    }
	}
    }
}

//	AllocSoilTemperatureLayers
//      Allocate memory for soil temperature layer variables
void TDayCentSoil::AllocSoilTemperatureLayers ()
{
    // if soil temp. array depth is not near the actual soil depth,
    // then recalculate
    float const soilTempDepth =
    	numSoilTemperatureLayers * soilTemperatureInterval;
    if ( soilTempDepth < SoilDepth() ||
	 soilTempDepth > SoilDepth() + soilTemperatureInterval )
    {
	// number of layers (rounded to nearest int, and constrained)
	numSoilTemperatureLayers =
		(short)( SoilDepth() / soilTemperatureInterval + 0.5f );
	if ( numSoilTemperatureLayers * soilTemperatureInterval < SoilDepth() )
		++numSoilTemperatureLayers;
	// need at least 4 layers for CalcSoilTemperatures()
	numSoilTemperatureLayers =
		std::max ( (int)numSoilTemperatureLayers, 4 );
	// cannot be less than the number of soil layers + 1
	numSoilTemperatureLayers =
		std::max ( (int)numSoilTemperatureLayers,
			   (int)GetLayerCount() + 1 );
    }

    // resize the arrays
    if ( soilTempLyrAvg.size() != numSoilTemperatureLayers )
    {
	soilTempLyrAvg.resize (numSoilTemperatureLayers);
	soilTempLyrMin.resize (numSoilTemperatureLayers);
	soilTempLyrMax.resize (numSoilTemperatureLayers);
	freezeEnergyPool.resize (numSoilTemperatureLayers);
    }
    soilTempLyrAvg = 0.0f;
    soilTempLyrMin = 0.0f;
    soilTempLyrMax = 0.0f;
    freezeEnergyPool = 0.0f;
}

//	CopySoilTempModel
//	Copy the soil temperature model data into this.
void TDayCentSoil::CopySoilTempModel (
	TDayCentSoil const & fromObj)
{
	if ( &fromObj && fromObj.GetLayerCount() > 0 )
	{
		// soil temperature parameters
		numSoilTemperatureLayers = fromObj.numSoilTemperatureLayers;
		soilTemperatureInterval = fromObj.soilTemperatureInterval;
		avgThermalDiffusivUnFrzn = fromObj.avgThermalDiffusivUnFrzn;
		avgThermalDiffusivFrzn = fromObj.avgThermalDiffusivFrzn;
		soilTemperatureDmpFactor = fromObj.soilTemperatureDmpFactor;
		soilBottomTempMin = fromObj.soilBottomTempMin;
		soilBottomTempMax = fromObj.soilBottomTempMax;
		soilBottomTimeLag = fromObj.soilBottomTimeLag;
		// depthToMidPt is recalc'd

		// soil temperature layers
		soilTempLyrAvg = fromObj.soilTempLyrAvg;
		soilTempLyrMin = fromObj.soilTempLyrMin;
		soilTempLyrMax = fromObj.soilTempLyrMax;
		freezeEnergyPool = fromObj.freezeEnergyPool;
	}
}

//	CheckSoilTempValues
//	Check the soil temperature data for validity
//	Return true if failed check.
bool TDayCentSoil::CheckSoilTempValues ()
{
	bool failed = false;				// return value

	// To Do: add if checks for these for when assertions are off.

	Assert (numSoilTemperatureLayers > 0);
	Assert ( SoilDepth() > soilTemperatureInterval );
	Assert ( soilTemperatureInterval >= 1.0f );
	Assert ( soilTemperatureInterval <= 5.0f );
	Assert ( avgThermalDiffusivUnFrzn > 0.0f );
	Assert ( avgThermalDiffusivUnFrzn <= 1.0f );
	Assert ( avgThermalDiffusivFrzn > 0.0f );
	Assert ( avgThermalDiffusivFrzn <= 1.0f );
	Assert ( soilTemperatureDmpFactor > 0.0f );
	Assert ( soilTemperatureDmpFactor <= 1.0f );
	Assert ( soilBottomTempMin > -50.0f );
	Assert ( soilBottomTempMin < 75.0f );
	Assert ( soilBottomTempMax > -50.0f );
	Assert ( soilBottomTempMax < 75.0f );
	Assert ( soilBottomTimeLag >= 0 );
	Assert ( soilBottomTimeLag < 366 );

	return failed;
}

//	CalcSoilTemperatures
//	Calculates the daily average, maximum, and minimum
//	soil temperature for a specified number of soil layers.
//	Data requirements include the max and min air temperature
//	(airTempMax, airTempMin), latitude of the site (degLatitude),
//	standing plant biomass (biomass), surface snowpack amount (snowPack),
//	soil temperature at the bottom of the soil profile, and thermal
//	diffusivity of the soil.
void TDayCentSoil::CalcSoilTemperatures (
    int const jday,           // day of the year (1..366)
    float const biomass,      // above ground biomass (gm/m**2)
    float const airTempMin,   // minimum air temperature for jday (deg C)
    float const airTempMax,   // maximum air temperature for jday (deg C)
    float const dayLength,    // day length (hours)
    float const snowPack,     // current snow pack amount (cm SWE)
    float const pmntmp,       // effect of biomass on min soil surface temp
    float const pmxtmp,       // effect of biomass on max soil surface temp
    float const pmxbio,       // max biomass value used for surface temp calcs
    float & surfTempAvg)      // avg soil surface temperature for jday (deg C)
{
    Assert ( jday > 0 && jday <= 366 );
    Assert ( biomass >= 0.0f );
    Assert ( airTempMin <= airTempMax );
    Assert ( dayLength > 0.0f && dayLength < 24.0f );
    Assert ( snowPack >= 0.0f );
    Assert (pmxbio > 0.0f);

    // optimization:
    // if there is not enough difference in the air temps, then don't do this
    // This is a coarse calc - should account for biomass and snow, at least
    float const meanAirTemp = ( airTempMax - airTempMin ) * 0.5f;
//    if ( fabs( meanAirTempPreviousDay - meanAirTemp ) < 2.0f )
//	return;
//    else
//    	meanAirTempPreviousDay = meanAirTemp;	// save for next time


    float const h2ofus = 80.0f;	// energy release of fusion (cal/g)
				//   and minimum (j=2) soil temp for
				//   i'th soil layer (deg C)

    // number of soil temperature layers
    AllocSoilTemperatureLayers ();
    CheckSoilTempValues ();

    // shortcuts
    float const dx = 		// actual soil temperature interval size (cm)
    	SoilDepth() / numSoilTemperatureLayers;
    short const nd = numSoilTemperatureLayers;		// shorthand

    // Only resize() if number of layers increases.
    if ( dtemp.size() < nd )
    {
	dtemp.resize (nd);	// daily delta temp for temp lyrs (deg C/day)
	thermDif.resize (nd);	// thermal diffusivity of temp lyrs (units?)
	vh2oc.resize (nd);	// volum soil water content of temp lyrs (frac)
	hcst.resize (nd);	// heat capacity per temperature layer (cal/K)
	freezeEnergy.resize (nd);	// freeze energy (deg C)
    }

    Assert (dtemp.size() > 0);
    Assert (thermDif.size() > 0);
    Assert (vh2oc.size() > 0);
    Assert (hcst.size() > 0);
    Assert (freezeEnergy.size() > 0);

    dtemp = 0.0f;
    thermDif = 0.0f;
    vh2oc = 0.0f;
    hcst = 0.0f;
    freezeEnergy = 0.0f;

    // Midpoints of layers
    MidPointsOfLayers ();

    // Calculate maximum soil surface temperature (srfcTempMax, deg C)
    // Equations are from Parton (1984).
    Assert ( AmountIsSignificant(biomass) );
    float const bio = std::min(biomass, pmxbio);
    // srfcTempMax = soil surface maximum temperature for jday (deg C)
    //srfcTempMax = ( 25.4 / (1.0 + 18.0 * exp(-0.20*airTempMax)) )
    //       * ( exp(-0.0048*biomass) - 0.13 ) + airTempMax;
#ifdef __BCPLUSPLUS__
    // avoid BCB6 FPU error producing a NAN in a the 1st exp()
    _fpreset ();	// reset the FPU package
#endif
    float srfcTempMax = airTempMax +
	(25.4f / (1.0f + 18.0f * exp(-0.20f * airTempMax)) ) *
	( exp(pmxtmp * bio) - 0.13f);

    //  Calculate minimum soil surface temperature (sfrcTempMin, deg C)
    // srfcTempMin = soil surface minimum temperature for jday (deg C)
    //srfcTempMin = airTempMin + 0.006*biomass - 1.82;
    float const srfcTempMin = airTempMin + pmntmp * bio - 1.78f;

    srfcTempMax = std::max ( srfcTempMin, srfcTempMax );
    /*
    if (srfcTempMin > srfcTempMax)
    {
	ostringstream os;
	os << "The minimum surface temperature ("
	   << srfcTempMin
	   << ") is greater than the maximum surface temperature ("
	   << srfcTempMax
	   << ") in CalcSoilTemperatures."
	   << ends;
	ThrowDayCentException ( TDayCentException::DCE_STMERR,
				os.str().c_str() );
    }
    */

    //  Calculate thermal diffusivity, and other soil temperature layer properties
    //  soilTempLyrAvg[] used in this function is equal to previous day's values

    CalcThermalDiffusivity (airTempMin, airTempMax, thermDif, vh2oc, hcst);

    //  Specify the soil temperature at bottom of soil profile + dx
    //  soilTempLyrAvg[nd+1] is set to sin function, using soilBottomTempMax
    //  and soilBottomTempMin at the specified layer, and lag time
    //  in julian days from the beginning of the year to the coldest
    //  time period (soilBottomTimeLag). These parameters are based
    //  on avg. monthly soil temps at 183 cm.
    //    for Pawnee/Colorado 1971-79 : 16.4/5.5/60
    //    for Grossenzersdorf/Austria 1990-1994 : 15.2/4.7
    {
	// tbotmx=16.4;
	// tbotmn=5.5;
	// timlag=74.0;
	// timlag = 60;

	float const a = 0.5f * (soilBottomTempMax - soilBottomTempMin);
	float const b = (2.0f * M_PI) / 365.0f;
	// float const c = ( (365.0f * 0.75f) - soilBottomTimeLag) * b;
	float const c = ( 273.75f - soilBottomTimeLag) * b;
	float const d = 0.5f * (soilBottomTempMax + soilBottomTempMin);
	soilTempLyrAvg(nd - 2) = a * sin (b * jday + c) + d;
	soilTempLyrAvg(nd - 1) = a * sin (b * jday + c) + d;
    }

    // Calculate change of temperature for each depth(temp[i])
    // the soil depth between layers is dx-cm and the time step=86400 sec.
    // 86400 is the number of seconds in a day and is equal to the period
    // oscillation or time step.

    //  Except for soil temperature layers nd and nd+1,
    //  soilTempLyrAvg(k) are previous day's values at this point

    float const diffusivityFactor =
    	soilTemperatureDmpFactor * SEC_PER_DAY / (dx*dx);

    float tempChange =
	soilTempLyrAvg(0) - 2.0f  * soilTempLyrAvg(1) + soilTempLyrAvg(2);
    if (tempChange > -0.3e-12f && tempChange < 0.3e-12f)
	tempChange = 0.0f;
    dtemp(0) = diffusivityFactor * thermDif(0) * tempChange;

    //  added freezeEnergy(0) calculation, it was missing -mdh 4/4/01
    Assert ( AmountIsSignificant ( hcst(0) ) );
    freezeEnergy(0) = -h2ofus * dx * vh2oc(0) / hcst(0) * 0.020f;
    // At the minimum of 4 layers (nd == 4), this loop will execute twice.
    for (short layer = 1; layer < nd - 2; layer++)
    {
	short const layerAbove = layer - 1;
	short const layerBelow = layer + 1;

	// 0.020 = time step correction factor found for pawnee
	if (soilTempLyrAvg(layer) > -1.0f && hcst(layer) > 1.0f)
		freezeEnergy(layer) = -h2ofus * dx * vh2oc(layer) /
					hcst(layer) * 0.020f;
	else
		freezeEnergy(layer) = 0.0f;

	float kdtemp;
	if ( freezeEnergy(layerAbove) < freezeEnergyPool(layerAbove) &&
	     freezeEnergyPool(layerAbove) < 0.0f )
	{
		kdtemp = 0.0f;
	}
	else
		kdtemp = dtemp(layerAbove);
	float thermDifIce;
	if ( freezeEnergyPool(layerAbove) > -2.0f &&
	     freezeEnergyPool(layerAbove) < 0.0f )
		thermDifIce = 0.001f;
	else
		thermDifIce = thermDif(layer);

	// dummy2 = stemp(layer)+dtemp(layerAbove)-2.0*stemp(layerBelow)+
	//		stemp(layer+2);
	float tempChange = soilTempLyrAvg(layer) + kdtemp -
			2.0f * soilTempLyrAvg(layerBelow) +
			soilTempLyrAvg(layer+2);
	if (tempChange > -0.3e-12f && tempChange < 0.3e-12f)
		tempChange = 0.0f;
	dtemp(layer) =
		diffusivityFactor * thermDif(0) * thermDifIce * tempChange;

	// Simulated freezing/thawing impact on soil temperature
	// change by creating a fusion energy pool
	float const adjustedTempLyrAvg = soilTempLyrAvg(layer) + dtemp(layer);
	if ( adjustedTempLyrAvg <= -1.0f &&
	     soilTempLyrAvg(layer) > -1.0f )
	      freezeEnergyPool(layer) = adjustedTempLyrAvg;

	if ( adjustedTempLyrAvg <= -1.0f &&
	     freezeEnergyPool(layer) < 0.0f )
		freezeEnergyPool(layer) += dtemp(layer);

	if ( adjustedTempLyrAvg > -1.0f &&
	     freezeEnergyPool(layer) < 0.0f )
		freezeEnergyPool(layer) += dtemp(layer) + soilTempLyrAvg(layer);

	if ( freezeEnergyPool(layer) > 0.0f )
		freezeEnergyPool(layer) = 0.0f;

	if ( freezeEnergy(layer) < freezeEnergyPool(layer) &&
	     freezeEnergyPool(layer) < 0.0f )
		dtemp(layer) = 0.0f;
    } // for layer

    // Weigh surface temperature more towards sfrcTempMin in the winter between
    // the fall and spring equinox when nights are longer than days.
    // 12/5/95 - Bill Parton.
    float tmnsMult;     // wieght factor on minimum surface temperature (0-1)
    float tmxsMult;     // weight factor on maximum surface temperature (0-1)
    if (dayLength < 12.0f)
    {
	tmnsMult = ((12.0f - dayLength) * 3.0f + 12.0f) / (float)HOURS_PER_DAY;
    }
    else
    {
	// Summer time, between spring and fall equinox
	tmnsMult = ((12.0f - dayLength) * 1.2f + 12.0f) / (float)HOURS_PER_DAY;
    }
    tmnsMult = std::min (0.95f, tmnsMult);
    tmnsMult = std::max (0.05f, tmnsMult);
    Assert  (tmnsMult > 0.0f && tmnsMult < 1.0f);
    tmxsMult = 1.0f - tmnsMult;

    // Compute insulation effects of snow on surface soil temperature
    // 11/30/95 (Bill Parton).
    float diurnalRange; // the difference between the max and min
			//   surface soil temperatures with the day (deg C)
    if (snowPack <= 1.0e-8f)	// no snow?
    {
	soilTempLyrAvg(0) = tmxsMult * srfcTempMax + tmnsMult * srfcTempMin;
	soilTempLyrMax(0) = srfcTempMax;
	soilTempLyrMin(0) = srfcTempMin;
	diurnalRange = srfcTempMax - srfcTempMin;
    }
    else if (meanAirTemp >= 0.0f)		// snow + warm air
    {
	//  if there is snow, and average air temperature gets above
	//  freezing, average soil surface temperature stays at freezing
	soilTempLyrAvg(0) = -2.0f;
	diurnalRange = 0.3f * meanAirTemp;
	if (diurnalRange * 0.5f + soilTempLyrAvg(0) > 0.0f)
	    diurnalRange = -2.0f * soilTempLyrAvg(0);
	soilTempLyrMax(0) = soilTempLyrAvg(0) + diurnalRange * 0.5f;
	soilTempLyrMin(0) = soilTempLyrAvg(0) - diurnalRange * 0.5f;
    }
    else			//  average air temperature is below freezing
    {
	// Effect of snow depth on surface temperature (frac).
	// It is smallest with deep snow and multiples average air
	// temperature.  The more snow, the closer soil surface
	// temperature is to freezing.
	float const snowMult = std::max (0.0f, -0.15f * snowPack + 1.0f);
	soilTempLyrAvg(0) = -2.0f + (0.3f * meanAirTemp) * snowMult;
	diurnalRange = 0.3f * (airTempMax - airTempMin) * snowMult;
	if (diurnalRange * 0.5f + soilTempLyrAvg(0) > 0.0f)
	    diurnalRange = -2.0f * soilTempLyrAvg(0);
	soilTempLyrMax(0) = soilTempLyrAvg(0) + diurnalRange * 0.5f;
	soilTempLyrMin(0) = soilTempLyrAvg(0) - diurnalRange * 0.5f;
    }
    surfTempAvg =  soilTempLyrAvg(0);

    //  Calculate the updated value for the average soil temperature
    for (short layer = 1; layer < nd; layer++)
    {
	soilTempLyrAvg(layer) += dtemp(layer-1);
	// if (freezeEnergy(layer) < freezeEnergyPool(layer) &&
	//	freezeEnergyPool(layer) < 0)
	//     stemp(layer) = -1;
	Assert (soilTempLyrAvg(layer) >= -50.0f);
	Assert (soilTempLyrAvg(layer) <= 60.0f);
    }

    //  Calculate the maximum and minimum soil temperature at depth depth[i].use
    //  eqn presented by parton(1983),which is a function of the average thermal
    //  diffusivity in the top 15cm,and the soil depth(depth[i]),and the diurnal
    //  variation at the soil surface.
    for (int layer = 1; layer < nd; layer++)
    {
	float const avgThermalDif = (soilTempLyrAvg(layer) <= -1.0f) ?
			avgThermalDiffusivFrzn : avgThermalDiffusivUnFrzn;
	Assert (avgThermalDif > 0.0f);
	float const kdepth = dx * layer + dx * 0.5f;
	//diff1=-depth[i]* pow((0.00005/avgThermalDif),0.5);
	float const diff1 =
	    std::max ( -60.0f,
		       -kdepth * (float) pow((5.0e-5f / avgThermalDif), 0.5f) );
	float const differ = diurnalRange;
	//if ((freezeEnergy(layer) < freezeEnergyPool(layer)) &&
	//    (freezeEnergyPool(layer) < 0.0))
	//    differ = differ*1.0;
	//else if (stemp_min(layer-1)=stemp_max(layer-1))
	//    differ = differ*1.0;

	soilTempLyrMax(layer) =
		soilTempLyrAvg(layer) + differ * exp(diff1) * 0.5f;
	if ( soilTempLyrMax(layer) > -1.0f &&
	     freezeEnergyPool(layer) < 0.0f )
	{
		soilTempLyrMax(layer) = soilTempLyrAvg(layer);
	}
	soilTempLyrMin(layer) =
		soilTempLyrAvg(layer) - differ * exp(diff1) * 0.5f;
	if ( soilTempLyrMin(layer) < -1.0f &&
	     freezeEnergy(layer) < freezeEnergyPool(layer) &&
	     freezeEnergyPool(layer) < 0.0f )
	{
		 soilTempLyrMin(layer) = soilTempLyrAvg(layer);
	}
	if ( soilTempLyrAvg(layer) > -1.0f &&
	     soilTempLyrMin(layer) < -1.0f )
		soilTempLyrMin(layer) = soilTempLyrAvg(layer);
    }  // for layer

    //  Calculate average, maximum, and minimum soil temperature (t[i,j]) for
    //  each soil layer. The average soil temperature is calculated by linearly
    //  interpolating between soil temperatures calculated at dx intervals.
    //  Based on the fourier heat transfer equation.
    // t[i][j] is the average (j=0), maximum (j=1),
    for (short layer = 0; layer < GetLayerCount(); layer++)
    {
	Assert (depthToMidPt(layer) > 0.0f);
	if (depthToMidPt(layer) == 0.0f)
	{
	    SoilTempMax(layer) = srfcTempMax;
	    SoilTempMin(layer) = srfcTempMin;
	    SoilTempAvg(layer) = (srfcTempMax + srfcTempMin) * 0.5f;
	}
	else
	{
	    // Get indices of soil temp laters surrounding the
	    // soil layer midpoint depth.
	    short const indexTempLayer =
	      std::max (
	        1,
		std::min (
		  numSoilTemperatureLayers - 2,
		  static_cast<int>(depthToMidPt(layer) / dx)
		  ) );
	    short const k1 = indexTempLayer - 1;
	    short const k2 = indexTempLayer + 1;
	    Assert (k1 >= 0);
	    Assert (k1 < k2);
	    Assert (k2 < numSoilTemperatureLayers);

	    // New version - needs to be tweaked still.
	    // Assume the the temperature in each soil temperature layers
	    // represent the temperature at the depth of the bottom of the
	    // layer. I.e., temp(k) at depth(k).
	    // A linear interpolation:
	    // T(depthToMidPt) = (T2-T1) / dx * (depthToMidPt - depth1)
	/*
	    float const depth1 = k1 * dx;
	    float const c = (depthToMidPt(layer) - depth1) / dx;
	    SoilTempAvg(layer) = (soilTempLyrAvg(k2) - soilTempLyrAvg(k1)) * c;
	    SoilTempMax(layer) = (soilTempLyrMax(k2) - soilTempLyrMax(k1)) * c;
	    SoilTempMin(layer) = (soilTempLyrMin(k2) - soilTempLyrMin(k1)) * c;
	*/

	  /*	original version
		Appears to do some kind of weighted mean of the thickness
		at the temps above and below the midpoint depth.
		If so, then assumes the temperature of each soil temp layer
		represents a mean temp of the layer.
	  */

	    // Linear equation constants
	    float const m1 =	// unitless weight factor
	      ( 2.0f * k2 - (depthToMidPt(layer) - dx * 0.5f) ) / dx;
	    float const m2 =	// unitless weight factor
	      ( depthToMidPt(layer) + dx * 0.5f - 2.0f * k2 ) / dx;
	    SoilTempAvg(layer) =
		m1 * soilTempLyrAvg(k1) + m2 * soilTempLyrAvg(k2);
	    SoilTempMax(layer) =
		m1 * soilTempLyrMax(k1) + m2 * soilTempLyrMax(k2);
	    SoilTempMin(layer) =
		m1 * soilTempLyrMin(k1) + m2 * soilTempLyrMin(k2);
	}
    }  // for layer

    // volume heat of soil (cal/cm3/deg)*(cm3*deg)=cal
    // Never used!
    /*------------------------------------------------------------------
    int const TAVG = 0, TMAX = 1, TMIN = 2;	// indices to temperature arrays
    float t[MAXLYR][3];		// t[i][j] is the average (j=0), maximum (j=1),
    float volheat[MAXLYR];
    float siltFrac[MAXLYR];
    // total energy absorbed/released from the soil (cal)
    float soilenrgy = 0.0f;
    for (short layer = 0; layer < GetLayerCount(); layer++)
    {
	//  New volume heat calculation by Bill Parton 9/94
	//  The volume of soil over 1 square meter is 100cm*100cm*thickness[i]

	//  If the temperature drops in the soil, energy is  given of back
	//  to the atmosphere, and is therefore positive.
	//  deltat is the change in soil temp between today and yesterday (deg C)
	//  At this point, SoilTempAvg(), SoilTempMax(), and SoilTempMin() are their
	//  previous day's values.

	siltFrac[layer] = 1.0f - SandFraction(layer) - ClayFraction(layer) -
				OMPC(layer) * 0.01f;
	Assert (siltFrac[layer] > 0.0f && siltFrac[layer] < 1.0f);
	float const vsilt = BulkDensity(layer) * siltFrac[layer] / PARTDENS;
	float const vsand = BulkDensity(layer) * SandFraction(layer) / PARTDENS;
	float const vclay = BulkDensity(layer) * ClayFraction(layer) / PARTDENS;
	float const vmuck = BulkDensity(layer) * OMPC(layer) / 100.0f / 1.30f;
	float const vh2o  = WaterContent(layer) / thickness[layer];
	float const deltaTemp = SoilTempAvg(layer) - t[layer][TAVG] ;
	volheat[layer] =
		( 0.20f * (vsand + vclay + vsilt) * PARTDENS +
		0.30f * vmuck * 1.30f + vh2o ) * deltaTemp *
		( thickness[layer] * 10000.0f );

	//  Negative soilenergy represents heat going into the soil
	//  Positive soilenergy represents heat going to warm the atmosphere
	soilenrgy += volheat[layer];
    } // for layer
   ------------------------------------------------------------------*/
}

//--- end of file ---
