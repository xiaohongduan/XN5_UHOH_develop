// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  ef2csv.cpp
//
//	Description:
//	Translates a Century erosion output file in netCDF format
//	to a comma-separated values format for spreadsheet import.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Jun99
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------
//	Copyright (c) 1999, T.E. Hilinski. All rights reserved.
//	This software is made freely available for non-commercial use.
//	This copyright notice must remain intact and in place.
//	Modification of this software without permission of the author
//	is prohibited and a violation of this copyright.
// ----------------------------------------------------------------------------

#include "TNcFileErosion.h"
#include "TDepEroBase.h"
#include <iostream>
#include <fstream>

char const* versionDate = "Version date: " __DATE__;
char const* description =
	"Translates a Century erosion output file (in netCDF format) into\n"
	"a comma-separated values text format for import into spreadsheets.";
char const* copyright =
	"Copyright (c) 1999 Thomas E. Hilinski. All rights reserved.";


char const quote = '"';			// quote character
char const sepChar = ',';		// separator character
char const * const blankCell = "\"\"";	// blank cell
char const nlChar = '\n';

//-----------------------------------------------------------------------------
//	HeaderInfo
//	Struct to hold data for the file header information.
//	Character arrays are allocated externally.
struct HeaderInfo
{
	char	*title, *simDesc, *mgmtFile, *siteFile, *siteDesc,
		*whoMod, *whenMod;

	HeaderInfo ()
	{
		title = simDesc = mgmtFile = siteFile = siteDesc =
		whoMod = whenMod = 0;
	}
	~HeaderInfo ()
	{
		Clear ();
	}
	void Clear ()
	{
		delete [] title;	delete [] simDesc;
		delete [] mgmtFile;	delete [] siteFile;
		delete [] siteDesc;	delete [] whoMod;
		delete [] whenMod;
	}
};


//-----------------------------------------------------------------------------
//	TimeStepRecord
//	Struct to hold data for one time-step record.
struct TimeStepRecord
{
	float simTime, thickness, bulkDen, sand, silt, clay;
	float* data;	// ptr to static array

	TimeStepRecord (float a, float b, float c, float d, float e, float f,
			float* g)
		: simTime (a), thickness (b), bulkDen (c),
		  sand (d), silt (e), clay (f), data (g)
	{
	}
	void Clear ()
	{
		simTime = thickness = bulkDen = sand = silt = clay = 0;
		register short loopLimit = EE_NumElements * EPT_NumPools;
		float* p = data;
		for ( short i = 0; i < loopLimit; ++i )
			*(p++) = 0.0f;
	}
};


//-----------------------------------------------------------------------------
//	SpreadSheetFile
//	Class to create and write the spreadsheet output file.
class SpreadSheetFile
{
  public:
	SpreadSheetFile (
		TEH::TFileName const & efName);	// erosion file name
	~SpreadSheetFile ();
	void WriteHeader (			// write CSV file header
		const HeaderInfo& info);
	void WriteRecord (			// write one CSV record
		const TimeStepRecord& record);
	bool IsOpen () const			// true if open file
		{ return isOpen; }
	bool IsError () const			// true if error
		{ return isWriteError; }
	TEH::TFileName const & GetFileName () const	// get CSV file name
		{ return fileName; }

  private:
	TEH::TFileName fileName;	// spreadsheet file name
	std::ofstream os;		// output file stream
	bool isOpen;			// true if the file is open
	bool isWriteError;		// true if a write error occurred
};

SpreadSheetFile::SpreadSheetFile (TEH::TFileName const & efName)
{
	// initialize member variables
	isWriteError = false;

	// create the output file name
	isOpen = false;
	fileName = efName;
	fileName.SetExtension ("csv");
	// open the file
	std::string fileNameStr = fileName.GetFullName ();
	if ( !fileNameStr.empty() )
	{
		os.open (fileNameStr.c_str(), std::ios::out);
		if ( !os || !os.good() )	// failed?
			fileName.Clear();	// ...yes
		else
			isOpen = true;		// ...no, is open
	}
}

SpreadSheetFile::~SpreadSheetFile ()
{
	// close the file
	if ( isOpen )
		os.close ();
}

void SpreadSheetFile::WriteHeader (
	HeaderInfo const & info)
{
	char const * const poolName[5] =
	  { "active", "slow", "passive", "metabolic", "structural" };
	char const * const elemName[5] =
	  { "Unlabeled C", "Labeled C", "N", "P", "S" };

	// "About" info
	os << quote << info.title << quote << nlChar
	   << nlChar
	   << quote << "Simulation description: "
	   << info.simDesc << quote << nlChar
	   << quote << "Management scheme file: "
	   << info.mgmtFile << quote << nlChar
	   << quote << "Site parameters file: "
	   << info.siteFile << quote << nlChar
	   << quote << "Site description: "
	   << info.siteDesc << quote << nlChar
	   << quote << "Last modified by: "
	   << info.whoMod << quote << nlChar
	   << quote << "Last modified date: "
	   << info.whenMod << quote << nlChar
	   << nlChar;

	// column headers - first row
	os << quote << "Simulation" << quote << sepChar
	   << quote << "Erosion" << quote << sepChar
	   << quote << "Bulk" << quote << sepChar
	   << quote << "Sand" << quote << sepChar
	   << quote << "Silt" << quote << sepChar
	   << quote << "Clay" << quote << sepChar;
	for ( short i = 0; i < 5; ++i )
	{
		os << quote << elemName[i] << quote << sepChar;
		for ( short j = 0; j < 4; ++j )
			os << blankCell << sepChar;
	}
	os << nlChar;

	// column headers - second row
	os << quote << "Time" << quote << sepChar
	   << quote << "Thickness" << quote << sepChar
	   << quote << "Density" << quote << sepChar
	   << quote << "Fraction" << quote << sepChar
	   << quote << "Fraction" << quote << sepChar
	   << quote << "Fraction" << quote << sepChar;
	for ( short i = 0; i < 5; ++i )
	    for ( short j = 0; j < 5; ++j )
		os << quote << poolName[j] << quote << sepChar;
	os << std::endl;
}

void SpreadSheetFile::WriteRecord (
	TimeStepRecord const & record)
{
	// float simTime, thickness, bulkDen, sand, silt, clay;
	// float* data;	// ptr to static array

	os << record.simTime << sepChar
	   << record.thickness << sepChar
	   << record.bulkDen << sepChar
	   << record.sand << sepChar
	   << record.silt << sepChar
	   << record.clay << sepChar;
	float const * p = record.data;
	for ( short i = 0; i < EE_NumElements * EPT_NumPools; ++i )
		os << *(p++) << sepChar;
	os << std::endl;
}


//-----------------------------------------------------------------------------
//	Global functions

void Pause ()
{
	std::cerr << "\nPress Enter to continue:";
	std::cin.get ();
}

void DisplayHelp ()
{
	std::cout << '\n' << ::description
	     << "\n\n" << "ef2csv [options] [erosion file name]\n"
	     << "  -v    Display software version.\n"
	     << "  -?    Display this help information.\n"
	     << "  -n    Do not pause for keypress when finished.\n"
	     << '\n' << ::copyright
	     << std::endl;
}

int main (int argc, char** argv)
{
	bool noPause = false;			// Do not pause when finished
	bool quitNow = false;			// true if exit program now
	TEH::TFileName inputFileName;		// input file name

	//--- process command line arguments
	if ( argc > 1 )
	{
		short numArgs = argc - 1;
		char** args = &argv[1];
		while (numArgs > 0 && *args)
		{
			if ( !strcmp(*args, "-v") )
			{
				std::cout << ::versionDate << nlChar
				     << ::copyright << nlChar;
				quitNow = true;
			}
			else if ( **args == '?' ||
				  !strcmp(*args, "-?") ||
				  !strcmp(*args, "-help") ||
				  !strcmp(*args, "--help") )
			{
				::DisplayHelp ();
				quitNow = true;
			}
			else if ( !strcmp(*args, "-n") )
				noPause = true;
			else	// file name
			{
				if ( inputFileName.IsEmpty() )
					inputFileName = *args;
				if ( !inputFileName.IsValid() )
				{
				    std::cout << "Invalid file name specified."
					      << std::endl;
				    quitNow = true;
				}
			}
			--numArgs;
			++args;
		}
	}
	if ( quitNow )
		return 0;

	//--- check the input file extension
	char const * const reqExt = "nc";		// required extension
	std::string ext = inputFileName.GetExtension();
	if ( !ext.empty() )			// anything there?
	{
		inputFileName.SetExtension (reqExt);
		ext = reqExt;
	}

	//--- find the erosion file
	if ( inputFileName.IsEmpty() || ::strcmplc(ext.c_str(), reqExt) )
	{
		std::cout << "You did not specify an erosion file name!"
			  << std::endl;
		return 0;
	}
	if ( !inputFileName.Exists() )
	{
		std::cout << "Could not find the erosion file you specified!"
			  << std::endl;
		return 0;
	}

	//--- open the erosion file
	TNcErosionFile *ef = 0;
	try
	{
		ef = new TNcErosionFile (inputFileName);
	}
	catch (char const* msgStr)
	{
		std::cout << "Error accessing the file.\nMessage is:"
		     << msgStr
		     << std::endl;
		delete ef;
		return -1;

	}
	catch (...)
	{
		std::cout << "Unknown error accessing the erosion file."
			  << std::endl;
		delete ef;
		return -1;
	}

	//--- read the erosion file and write a spreadsheet file
	// first, let the user know what is happening
	SpreadSheetFile ssf (inputFileName);
	std::string const outName = ssf.GetFileName().GetFullName();
	std::cout << "Output file name is:\n" << outName << std::endl;
	short const numRecords = (short) ef->GetRecordCount ();
	std::cout << "Translating "
		<< numRecords
		<< " time-step records..."
		<< std::endl;
	float simTime, thickness, bulkDen, sand, silt, clay;
	float data[EE_NumElements][EPT_NumPools];

	// read and write the header information
	HeaderInfo info;
	ef->ReadAbout (info.title, info.simDesc, info.mgmtFile,
		info.siteFile, info.siteDesc, info.whoMod, info.whenMod);
	ssf.WriteHeader (info);

	// for each record...
	for ( short numRec = 0; numRec < numRecords; ++numRec )
	{
		ef->SetRecordRead (numRec);	// read record numRec
		if ( ef->ReadRecord (simTime,
				     thickness, bulkDen, sand, silt, clay,
				     (float*)data) )
		{
			std::cout << "\nError reading record "
				<< numRec
				<< std::endl;
			return -1;
		}
		TimeStepRecord rec (simTime, thickness, bulkDen,
					sand, silt, clay, (float*)data );
		ssf.WriteRecord (rec);
	}

	//--- all done!
	delete ef;
	if ( !noPause )
		::Pause ();
	return 0;
}
