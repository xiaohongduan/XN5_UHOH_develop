#ifndef INC_TMCOutputFileBase_h
#define INC_TMCOutputFileBase_h
// ----------------------------------------------------------------------------
//	Copyright 2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TMCOutputFileBase.h
//	Class:	  TMCOutputFileBase
//
//	Description:
//	Base class for monthly Century output files.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, June 2002
//	History:
//	Jun02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Created this to move the output variable names from the base class
//	  to here, in order to accomodate different output variable sets.
// ----------------------------------------------------------------------------

#include "TCentOFBase.h"
#include "TMCOutVarInfo.h"
#include "TMCSiteParameters.h"

class TMCOutputFileBase
	: public TCentOutFileBase
{
  protected:
	TMCOutputFileBase (
	  std::string const & useFileName, 		// file name instance
	  TOutputType const useOutputType,		// output type
	  TAccessMode const useAccess,			// file access mode
	  TOutputBase::TFileFormat const useFormat,	// file format type
	  TManagementScheme & useMgmt,		// mgmt. scheme
	  TMCSiteParameters & useSite,		// site parameter set
	  std::string const & useUserName,	// user name for output file
	  TEH::TFileName const & useOVDefFile)	// path to the netCDF file with
						//   the names and definitions
						//   of the output variables.
	  : TCentOutFileBase (
	  	useFileName, useOutputType, useAccess, useFormat,
	  	useMgmt, useSite, useUserName,
	  	TSharedPtr<TOutVarInfoBase> (
	  		new TMCOutputVariableInfo (useOVDefFile) ) )
	  {
	  	outputSetName = myOutputSetName;
	  }
	TMCOutputFileBase (				// copy constructor
	  TMCOutputFileBase const & object)
	  : TCentOutFileBase (object)
  	  {
  	  }
	virtual ~TMCOutputFileBase () = 0;

  public:

  protected:
	static char const * const myOutputSetName[];	// output set names
};

inline TMCOutputFileBase::~TMCOutputFileBase ()
{
}

#endif // INC_TMCOutputFileBase_h
