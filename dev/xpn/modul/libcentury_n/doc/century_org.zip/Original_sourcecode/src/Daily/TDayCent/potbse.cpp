// ----------------------------------------------------------------------------
//    Project:  Century Soil Organic Matter Model, daily version
//    File:	potbse.cpp
//    Class:	TDayCent
//    Function: float PotentialEvapRate()
//
//    Description:
//    Return the potential bare soil evaporation rate (cm/day)
//    See 2.11 in ELM doc.
//
//    Author: Susan Chaffee, Melannie Hartman, Bill Parton
// ----------------------------------------------------------------------------
//    History:
//    Apr1992  Susan L. Chaffee
//    * Created potbse.f
//    Sep1993  Melannie Hartman  melannie@NREL.colostate.edu
//    * Translated potbse.f to potbse.c
//    MMMYYYY  Melannie Hartman  melannie@NREL.colostate.edu
//    * Updated for FORTRAN/C version of DayCent model
//    Apr2001  Melannie Hartman  melannie@NREL.colostate.edu
//    * Translated potbse.c to potbse.cpp
//	Nov02   Tom Hilinski, tom.hilinski@colostate.edu
//	* Misc. clean up, const-correctness, optimization.
// ----------------------------------------------------------------------------
//    Copyright 1998-2000 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//    Calls:
//      none
// ----------------------------------------------------------------------------
#include "TDayCent.h"
#include "AssertEx.h"
using namespace std;

float TDayCent::PotentialEvapRate (
    float const totAGBiomass,  // aboveground live + dead biomass plus
                               //   surface litter (g biomass/m^2)
    float const fbse,          // fraction of water loss from bare soil evap (0-1)
                               //   1 - fbse = fraction of transpiration water loss
    float const PET)           // potential evapotranspiration rate (cm H2O/day)
{
    // check function parameters
    Assert ( totAGBiomass >= 0.0 );
    Assert ( (fbse >= 0.0) && (fbse <= 1.0) );
    Assert ( PET >= 0.0 );

    // constants
    float const AGB_LIMIT = 300.0f;
    // The maximum PET fraction that can be alllocated to bare soil evaporation
    float const maxPETfrac = 0.70f;
    // minium bare soil evaporation rate (cm H2O/day)
    // Don't allow min potential evaporation rate to exceed PET. -mdh 5/14/01
    float const minPotentialEvap = std::min (0.05f, PET);

    // local variables
    float potentialEvap = 0.0f;		// return value

    // Potential evaporation:
    //  if totAGBiomass > AGB_LIMIT, assume soil surface is
    //  completely covered with litter and that bare soil
    //  evaporation is inhibited. 8/27/92 (SLC)
    if (totAGBiomass >= AGB_LIMIT)
    {
        potentialEvap = minPotentialEvap;
    }
    else
    {
        potentialEvap =
           std::max ( minPotentialEvap,
                      PET * (1.0f - totAGBiomass / AGB_LIMIT) * fbse );
        if (potentialEvap > maxPETfrac * PET)
            potentialEvap = maxPETfrac * PET;
    }
    Assert ( potentialEvap >= 0.0f );
    Assert ( potentialEvap <= PET );
    return potentialEvap;
}

//--- end of file ---
