// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  cmplig.cpp
//	Class:	  TCenturyBase
//	Function: PlantLigninFraction
//
//	Description:
//	Compute plant lignin;
//	Returns the fraction of residue which will lignin in comput.pltlig?
// ----------------------------------------------------------------------------
//	History:
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::PlantLigninFraction ()
{
    // crop or savanna system: lignin contend depends on annual rainfall
    float const meanAnnualPrecip = 			// annual precipitation
	sysType.IsForest() ? 0.0f : weather->MeanAnnualPrecip ();

    if ( sysType.IsCropGrass() )
    {
	comput.pltlig[ABOVE] = fligni_ref (INTCPT, ABOVE) +
			fligni_ref (SLOPE, ABOVE) * meanAnnualPrecip;
	comput.pltlig[BELOW] = fligni_ref (INTCPT, BELOW) +
			fligni_ref (SLOPE, BELOW) * meanAnnualPrecip;
    }
    else if ( sysType.IsForest() )
    {
	comput.pltlig[ABOVE] = parfs.wdlig[LEAF];
	comput.pltlig[BELOW] = parfs.wdlig[FROOT];
    }
    else if ( sysType.IsSavanna() )
    {
	comput.pltlig[ABOVE] =
		( parfs.wdlig[LEAF] + fligni_ref (INTCPT, ABOVE) +
		  fligni_ref (SLOPE, ABOVE) * meanAnnualPrecip) * 0.5f;
	comput.pltlig[BELOW] =
		(parfs.wdlig[FROOT] + fligni_ref (INTCPT, BELOW) +
		fligni_ref (SLOPE,BELOW) * meanAnnualPrecip) * 0.5;
    }

    // Check range for comput.pltlig; the hard-coded values should be
    // replaced with parameter values someday
    comput.pltlig[ABOVE] = std::max (0.02f, comput.pltlig[ABOVE]);
    comput.pltlig[ABOVE] = std::min (0.5f, comput.pltlig[ABOVE]);
    comput.pltlig[BELOW] = std::max (0.02f, comput.pltlig[BELOW]);
    comput.pltlig[BELOW] = std::min (0.5f, comput.pltlig[BELOW]);
}

//--- end of file ---
