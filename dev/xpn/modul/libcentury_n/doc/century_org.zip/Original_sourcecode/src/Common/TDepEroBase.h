#ifndef INC_TDepEroBase_h
#define INC_TDepEroBase_h

// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TDepEroBase.h
//	Class:	  TDepEroBase
//
//	Description:
//	Base class to deposition and erosion within a Century simulation.
//	This only deals with the Century pools, NOT the physical soil.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Mar99
// ----------------------------------------------------------------------------
//	History:
//	Jan01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Made the reference to the physical soil class a const.
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added copy constructor, operator=
// ----------------------------------------------------------------------------
//	Copyright 1999-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#ifndef INC_TCentury_h
#include "outputvars.h"
#include "TFlow.h"
#include "TCenturySoil.h"
#include "TLowerSoil.h"
#include "centtypes.h"
#include "centconsts.h"
#include "arraydefs.h"
#endif // INC_TCentury_h
#include "TIOSourceSinkBase.h"
#include <memory>

//--- Indices to arrays for erosion file
// 1. unlabeled and labeled C; N; P; S
enum TErosionElements
{
	EE_CU, EE_CL, EE_N, EE_P, EE_S, EE_NumElements
};
// 2. pools: active, slow, passive, metabolic, structural
enum TErosionPoolTypes
{
	EPT_Active, EPT_Slow, EPT_Passive, EPT_Structural, EPT_Metabolic,
	EPT_NumPools
};
// 3. elemental fractions lost from eroded material: dissolution, gaseous
enum TErosionELF
{
	ELF_Dis, ELF_Gas, ELF_NumFractions
};

#ifdef __BCPLUSPLUS__

// Borland C++ Compiler
// Precompiled headers hate constants in the headers, and
// BCC and BCB will not precompile these headers. This increases
// compilation time tremendously.
// So, here I trade type safety for compilation speed.

// minimum amount in a pool (g/m2)
#define	NSDepEro_poolMinThreshold	1.0e-6f
// min. thickness (cm) = 1/1000
#define	NSDepEro_thicknessMin		1.0e-3f

#else

namespace NSDepEro			//--- common values
{
    static float const
	poolMinThreshold = 1.0e-6f,	// minimum amount in a pool (g/m2)
	thicknessMin = 1.0e-3f;		// min. thickness (cm)
}

#define	NSDepEro_poolMinThreshold	NSDepEro::poolMinThreshold
#define	NSDepEro_thicknessMin		NSDepEro::thicknessMin

#endif // __BORLANDCPP__


class TDepEroBase
{
  public:
	//--- types
	typedef std::auto_ptr<nrel::io::TIOSourceSinkBase>	TDepEroFilePtr;

	//--- constants
	// These should match those in src/century/centconsts.h
	enum { ACTIVE, SLOW, PASSIVE, NUMPOOLS }; // Indices to C pools
	enum { N, P, S, NUMELEM };		  // Indices to elements
	enum { UNLABELED, LABELED, NUMISO };	  // Indices to C isotopes

	//--- constructors and destructor
	TDepEroBase (
	  TSite& useSite,		// use this site class instance
	  TCenturySoil& useSoil,	// use this soil class instance
	  TLowerSoil& useLwrSoil,	// use this lower soil pool instance
	  TSoilC& useSoilC, 		// soil C output variable instance
	  TNPS& useNPS,			// N,P,S output variable instance
	  TWater& useWater,		// water parameters class
	  TWaterTemp& useWT,		// water & temperature output class
	  TFlow& useFlows,		// flow manager class instance
	  short const useNumIso,	// number of isotopes
	  short const useNumElem)	// number of elements
	  : site (useSite),
	    soil (useSoil),
	    lowerSoil (useLwrSoil),
	    soilC (useSoilC),
	    nps (useNPS),
	    water (useWater),
	    wt (useWT),
	    flows (useFlows),
	    numIso (useNumIso),
	    numElem (useNumElem)
	  {
	    Initialize ();
	  }
	virtual ~TDepEroBase ()
	  {
	    Initialize ();
	  }
	TDepEroBase (TDepEroBase const & object)	// copy constructor
	  : site (object.site),
	    soil (object.soil),
	    lowerSoil (object.lowerSoil),
	    soilC (object.soilC),
	    nps (object.nps),
	    water (object.water),
	    wt (object.wt),
	    flows (object.flows),
	    numIso (object.numIso),
	    numElem (object.numElem)
	  {
	    Initialize ();
	    Copy (object);
	  }

	//---- operator overloads
	TDepEroBase& operator= (TDepEroBase const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
		Initialize ();
		Copy (object);
	    }
	    return *this;
	  }

	//--- functions
	void Clear ()			// "Clear" data members
	  {
	    Initialize ();
	  }

  protected:
	//--- external data references and constants
	TSite& site;			// site information class instance
	TCenturySoil& soil;		// soil physical class instance
	TLowerSoil& lowerSoil;		// lower soil pools class instance
	TSoilC& soilC; 			// soil C output variable class
	TNPS& nps;			// N,P,S output variable class
	TWater& water;			// water parameters class instance
	TWaterTemp& wt;			// water & temp. output class instance
	TFlow& flows;			// flow manager class instance
	short const numIso;		// number of isotopes
	short const numElem;		// number of elements

	//--- data
	TDepEroFilePtr eoFile;		// erosion file object smart pointer

	//--- functions

  private:
	//--- functions
	void Initialize ()				// initialize members
	  { eoFile.reset (); }
	void Copy (TDepEroBase const & object)		// Copy to this
	  {
	    if ( &object )
	    {
	    	*eoFile = *object.eoFile;
	    }
	  }
};

// Defines for common 2-D arrays
#define amtC_ref(pool_, isotope_)    amtC[(pool_) * NUMISO + isotope_]
#define amtE_ref(pool_,_element)     amtE[(pool_) * NUMELEM + _element]
#define data_ref(element_, pool_)    (data + element_ * EPT_NumPools + pool_)

#endif // INC_TDepEroBase_h
