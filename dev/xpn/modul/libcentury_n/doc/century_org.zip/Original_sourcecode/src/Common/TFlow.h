#ifndef INC_TFlow_h
#define INC_TFlow_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TFlow.h
//	Class:	  TFlow
//
//	Description:
//	Class to perform the flows between the Century compartments.
//	This simulates a Euler's solution to difference equations.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jun98
//	History:
//	Jan00	Tom Hilinski
//	* Added limits on the size of flow amounts to 10e6 and 10e-6.
//	Jun01	Tom Hilinski
//	* Added copy constructor, operator=
//	* Changed file names: T_Flow.* to TFlow.*
//	* Changed stack to be a std library container, and modified everything
//	  to use the container.
//	* Changed initial stack size 500 to 200.
//	* Inlined some functions.
//	Jun02	Tom Hilinski
//	* Commented out TStackElement::operator=
//	* Made all data members of TStackElement constant.
//	May03	Tom Hilinski
//	* Added exception handling to TFlow::FlowUp
//	* Added optional C string argument to TFlow::FlowError
//	* Debug checks for null pointers (NDEBUG)
//	* Removed unused TFlow::flowErrorMsg.
//	* Removed empty TFlow::Initialize.
//	* Inlined TFlow::Copy.
//	* Added debugging features triggered by macro FLOWSTACK_DEBUG.
//	Apr04	Tom Hilinski
//	* Added operator+ and operator+= to TFlow so as to combine flow stacks.
//	* Added copy constructor to TStackElement.
//	* Promoted GetStack to be a regular public member.
// ----------------------------------------------------------------------------
//	Note: The macro FLOWSTACK_DEBUG turns on additional information from
//	each stack entry: __FILE__, __LINE__, simTimeAdded
// ----------------------------------------------------------------------------

#include <vector>
#include <string>

// -------------- COMMENT OUT THIS MACRO FOR PRODUCTION RUNS! -----------------
// #define FLOWSTACK_DEBUG
#undef FLOWSTACK_DEBUG
// ----------------------------------------------------------------------------

#ifdef FLOWSTACK_DEBUG
  #define SCHEDULE_FLOW(flows, from, to, when, amount) \
	  (flows)->Schedule ((from), (to), (when), (amount), \
			  __FILE__, __LINE__)
#else
  #define SCHEDULE_FLOW(flows, from, to, when, amount) \
  	  (flows)->Schedule ((from), (to), (when), (amount))
#endif


//	TStackElement
//	Class to hold one stack entry (one flow).
class TStackElement
{
  public:
	float * from;			// Source
	float * to;			// Destination
	float when;			// Time to flow
	float amount;			// Amount
#ifdef FLOWSTACK_DEBUG
	std::string fileName;		// __FILE__
	unsigned short lineNumber;	// __LINE__
#endif

	//--- constructor and destructor
	TStackElement (
	  float * const useFrom = 0,
	  float * const useTo = 0,
	  float const useWhen = 0.0f,
	  float const useAmount = 0.0f
#ifdef FLOWSTACK_DEBUG
	  ,
	  char const * const useFileName = "",
	  unsigned short useLineNumber = 0
#endif
	  )
	  : from (useFrom),
	    to (useTo),
	    when (useWhen),
	    amount (useAmount)
#ifdef FLOWSTACK_DEBUG
	    ,
	    fileName (useFileName),
	    lineNumber (useLineNumber)
#endif
	  {
	  }
	TStackElement (TStackElement const & object)
	  : from (object.from),
	    to (object.to),
	    when (object.when),
	    amount (object.amount)
#ifdef FLOWSTACK_DEBUG
	    ,
	    fileName (object.fileName),
	    lineNumber (object.lineNumber)
#endif
	  {
	  }
	~TStackElement ()
	  {
	  }

	//---- operator overloads
	bool operator< (			// Sort by time
	  TStackElement const & object ) const
	  {
	    return when < object.when;
	  }
	TStackElement& operator= (TStackElement const & object)
	  {
	    from = object.from;
	    to = object.to;
	    when = object.when;
	    amount = object.amount;
#ifdef FLOWSTACK_DEBUG
	    fileName = object.fileName;
	    lineNumber = object.lineNumber;
#endif
	    return *this;
	  }
};

class TFlow
{
  public:
	//--- types
	typedef std::vector<TStackElement>	TStack;

	//--- constructor and destructor
	TFlow ()
	  {
	    //stack.reserve (1000);
	  }
	~TFlow ()
	  {
	    Clear ();
	  }
	TFlow (TFlow const & object)	// copy constructor
	  {
	    Copy (object);
	  }

	//---- operator overloads
	TFlow& operator= (TFlow const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	Clear ();
		Copy (object);
	    }
	    return *this;
	  }
	TFlow operator+ (TFlow const & object) const
	  {
	    // definition: Combines (adds) stacks.
	    TFlow tempObject;
	    tempObject.stack = stack;	// insert left operand
	    tempObject.stack.insert (	// insert right operand
		tempObject.stack.end(),
	    	object.stack.begin(), object.stack.end() );
	    return tempObject;
	  }
	TFlow& operator+= (TFlow const & object)
	  {
	    // definition: Adds rhs stack to this stack
	    stack.insert ( stack.end(),
	    	object.stack.begin(), object.stack.end() );
	    return *this;
	  }

	//--- functions
	void  Schedule (			// Schedule a flow
	  float * const fromPool,		//   from pool
	  float * const toPool,			//   to pool
	  float const whenToFlow,		//   time for flow to occur
	  float const amountToFlow		//   amount of flow
#ifdef FLOWSTACK_DEBUG
	  ,
	  char const * const useFileName = "",	// __FILE__
	  unsigned short useLineNumber = 0	// __LINE__
#endif
	  );
	void  FlowUp (				// Do the flows
	  float const time);			//   at simulation time
	void Clear ()				//   Reset to initial state
	  {
	    stack.clear ();
	  }

	//--- functions
	bool IsEmpty () const			// True if empty
	  { return stack.empty(); }
	short GetStackLength () const		// Get number of entries
	  { return (short) stack.size(); }
	TStack const & GetStack () const	// Get the stack
	  { return stack; }

  private:
	//--- constants
	static short const initialSizeStack;	// size of flow stack
	static float const smallestAmount;	// smallest flow allowed
	static float const largestAmount;	// largest flow allowed

	//--- data
	TStack stack;			// The flow stack

	//--- functions
	void Copy (TFlow const & object)	// Copy to this
	  {
	    if ( &object )
	    {
		stack = object.stack;
	    }
	  }

	void  FlowError (
	  short const error_num, 		// error number
	  float const when,			// simulation time of error
	  char const * const msg = 0		// optional message
#ifdef FLOWSTACK_DEBUG
	  ,
	  char const * const useFileName = "",	// __FILE__
	  unsigned short useLineNumber = 0	// __LINE__
#endif
	  );
};

#endif // INC_TFlow_h
