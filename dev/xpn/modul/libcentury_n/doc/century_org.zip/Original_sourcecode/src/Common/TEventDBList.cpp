// ----------------------------------------------------------------------------
// Copyright (c)  2001 Thomas E. Hilinski. All rights reserved.
// Unauthorized distribution, duplication, sale, and use is prohibited by law.
// This software is provided "as is" with no warranty as to function, purpose,
// use, or results.
// This software may be used and distributed freely, with the following
// conditions:
// * No charge is made for software upon distribution.
// * This copyright notice is distributed unaltered with this software.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TEventDBList.cpp
//	Class:	  TEventDBList
//
//	Description:
//	Class managing a list of event option databases (e.g., crops, trees).
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, July 2001
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TEventDBList.h"
#include "fnutil.h"

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

char const * const TEventDBList::version =		// class version number
	"1.2.1";

//	Valid Century 4 parameter (".100") file names:
//	These correspond in order to the 1st 10 values in enum DBIndex.
char const * const TEventDBList::cent4FileName[] =
{
	"crop", "cult", "fert", "fire",
	"graz", "harv", "irri", "omad",
	"tree", "trem", "fix", 0
};

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	UseDatabaseFile
//	Specify a database file to use for a given type of database.
//	Return false if name is added, else true if not or error.
bool TEventDBList::UseDatabaseFile (
	DBIndex useEventType,		// this type
	std::string const & dbFileName)	// this file name
{
	if ( useEventType >= DBI_Crop &&
	     useEventType < DBI_Unknown )
	{
		if ( static_cast<std::size_t>(useEventType) <
		     fileNameList.size() )
		{
			fileNameList[useEventType] = dbFileName;
			return false;
		}
		else
			return true;
	}
	else
	{
		if ( !errMsg.empty() )
			errMsg += NL_CHAR;
		errMsg = "Invalid parameter database type.";
		return true;
	}
}

//	Get
//	Get the database.
//	Returns a pointer to the event option set matching the event type,
//	or a null pointer if the event type was not found.
TSharedPtr<TEventOptionSet> TEventDBList::Get (
	DBIndex eventType) const	// event type
{
	TSharedPtr<TEventOptionSet> dbPtr;
	if ( dbList.size() > 0 )
	{
		TDBList::const_iterator p = dbList.find (eventType);
		if ( p != dbList.end() )
			dbPtr = p->second;		// found it!
	}
	return dbPtr;
}

//	LoadCent4Files
//	Returns false if successful, else true if failed.
bool TEventDBList::LoadCent4Files ()
{
	DBIndex e = DBI_Crop;
	TStringArray::const_iterator i = fileNameList.begin();
	while ( i != fileNameList.end() )
	{
		if ( Add ( e, *i) )	// failed?
		{
			// error handling in LoadDatabase
			return true;
		}
		++i;
		e = (DBIndex)((int)e + 1);
	}
	return false;
}

//	Add
//	Add a new database to the list.
//	Returns false if successful, else true if failed.
bool TEventDBList::Add (
	DBIndex const useEventType,		// event type for set
	TEH::TFileName const & newFileName)	// db file path/name
{
	return LoadDatabase (useEventType, newFileName);
}

bool TEventDBList::Add (
	DBIndex const useEventType,		// event type for set
	char const * const newFileName)		// db file path/name
{
	TEH::TFileName theName (newFileName);
	return LoadDatabase (useEventType, theName);
}

bool TEventDBList::Add (
	DBIndex useEventType,			// event type for set
	std::string const & newFileName)	// db file path/name
{
	TEH::TFileName theName (newFileName, TEH::TFileName::FT_Normal);
	return LoadDatabase (useEventType, theName);
}

//	Replace
//	Replace a database in the list.
//	Returns false if successful, else true if failed.
bool TEventDBList::Replace (
	DBIndex const useEventType,		// event type for set
	TEH::TFileName const & newFileName)	// db file path/name
{
	bool failed = true;
	if ( dbList.end() != dbList.find (useEventType) )
		failed = LoadDatabase (useEventType, newFileName);
	return failed;
}

bool TEventDBList::Replace (
	DBIndex const useEventType,		// event type for set
	char const * const newFileName)		// db file path/name
{
	TEH::TFileName theName (newFileName, TEH::TFileName::FT_Normal);
	return Replace (useEventType, theName);
}

bool TEventDBList::Replace (
	DBIndex useEventType,			// event type for set
	std::string const & newFileName)	// db file path/name
{
	TEH::TFileName theName (newFileName, TEH::TFileName::FT_Normal);
	return Replace (useEventType, theName);
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Copy
// 	copy to this
void TEventDBList::Copy (TEventDBList const & object)
{
	if ( &object )
	{
		searchPaths = object.searchPaths;
		dbList = object.dbList;
		fileNameList = object.fileNameList;
		modified = true;
	}
}

//	LoadDatabase
//	Load the option set into memory.
//	Returns false if successful, else true if failed.
bool TEventDBList::LoadDatabase (
	DBIndex const eventType,		// event type for set
	TEH::TFileName const & fileName)	// db file path/name
{
	TSharedPtr<TEventOptionSet> db (
		new TEventOptionSet (eventType, fileName) );
	bool failed = !db->GetErrorMessage().empty();		// return value
	if ( !failed && db->GetOptionCount() > 0 )		// have it?
	{
		failed = !dbList.insert (
				TDBEntry ( eventType, db ) ).second;
		if ( !failed )
			fileNameList[eventType] = fileName.GetFullName();
	}
	if ( failed )
	{
		if ( !errMsg.empty() )
			errMsg += NL_CHAR;
		errMsg += "Error reading parameter database: ";
		errMsg += fileName.GetFullName();
		if ( !db->GetErrorMessage().empty() )
		{
			errMsg += NL_CHAR;
			errMsg += db->GetErrorMessage();
		}
	}
	return failed;
}

//	CreateDefaultFileNames
// 	Fill "fileNameList" with the default file names.
void TEventDBList::CreateDefaultFileNames ()
{
	fileNameList.reserve (DBI_Unknown);
	DBIndex e = DBI_Crop;
	char const ** i = const_cast<char const **>(cent4FileName);
	while ( e != DBI_Unknown )	// for each file name
	{
	    // create the file name w/suffix
	    std::string fileName = *i;
	    fileName += ".100";
	    // search paths
	    TStringArray::const_iterator iFoundAt =
		TEH::FindInPaths (
			fileName, searchPaths.begin(), searchPaths.end() );
	    if ( iFoundAt != searchPaths.end() )	// found file?
	    {
		TEH::PrependPathToFileIf ( fileName, *iFoundAt );
		std::size_t const oldSize = fileNameList.size();
		fileNameList.push_back (fileName);
		if ( oldSize != fileNameList.size() - 1 )	// failed?
			throw ( "TEventDBList::CreateDefaultFileNames: "
				"push_back failed" );
	    }
	    // kluge
	    // fix.100 may not exist, but add placeholder
	    else if ( fileName == "fix.100" )
	    {
		TEH::PrependPathToFileIf ( fileName, *(searchPaths.end() - 1) );
		fileNameList.push_back (fileName);
	    }
	    else
	    {
		std::string msg =
			"TEventDBList::CreateDefaultFileNames: "
			"parameter database file not found: ";
		msg += fileName;
		throw (msg);
	    }
	    // to next name
	    ++i;
	    e = (DBIndex)((int)e + 1);
	}
}

//--- end of definitions for TEventDBList ---
