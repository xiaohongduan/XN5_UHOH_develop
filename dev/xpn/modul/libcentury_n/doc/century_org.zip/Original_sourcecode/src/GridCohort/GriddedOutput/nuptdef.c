
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  nupt_ncid;			/* netCDF id */

/* variable ids */
int  agcnup_id, bgcnup_id, rlvnup_id, frtnup_id, fbrnup_id, 
     rlwnup_id, crtnup_id;

void handle_error(char *funcname, int status);

int
nuptdef(int *ntimes, char *history) {		/* create nupt.nc */

   int status;

   /* dimension ids */
   int  time_dim = 0;
   int  cell_dim = 0;

   /* variable shapes */
   int dims[2];

   /* enter define mode */
   status = nc_create("nupt.nc", NC_CLOBBER, &nupt_ncid);
   if (status != NC_NOERR) handle_error("nc_create(nupt.nc)", status);

   /* define dimensions */
   status = nc_def_dim(nupt_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(nupt_ncid, "cell", NC_UNLIMITED, &cell_dim);

   /* define variables */

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nupt_ncid, "agcnup", NC_FLOAT, 2, dims, &agcnup_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nupt_ncid, "bgcnup", NC_FLOAT, 2, dims, &bgcnup_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nupt_ncid, "rlvnup", NC_FLOAT, 2, dims, &rlvnup_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nupt_ncid, "frtnup", NC_FLOAT, 2, dims, &frtnup_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nupt_ncid, "fbrnup", NC_FLOAT, 2, dims, &fbrnup_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nupt_ncid, "rlwnup", NC_FLOAT, 2, dims, &rlwnup_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (nupt_ncid, "crtnup", NC_FLOAT, 2, dims, &crtnup_id);

   /* assign attributes */
   status = nc_put_att_text (nupt_ncid, NC_GLOBAL, "history", strlen(history), history);
   status = nc_put_att_text (nupt_ncid, agcnup_id, "long_name", 
	strlen("above_ground_crop_N_uptake"), "above_ground_crop_N_uptake");
   status = nc_put_att_text (nupt_ncid, agcnup_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nupt_ncid, bgcnup_id, "long_name", 
	strlen("below_ground_crop_N_uptake"), "below_ground_crop_N_uptake");
   status = nc_put_att_text (nupt_ncid, bgcnup_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nupt_ncid, rlvnup_id, "long_name", 
	strlen("leaf_N_uptake"), "leaf_N_uptake");
   status = nc_put_att_text (nupt_ncid, rlvnup_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nupt_ncid, frtnup_id, "long_name", 
	strlen("fine_root_N_uptake"), "fine_root_N_uptake");
   status = nc_put_att_text (nupt_ncid, frtnup_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nupt_ncid, fbrnup_id, "long_name", 
	strlen("fine_branch_N_uptake"), "fine_branch_N_uptake");
   status = nc_put_att_text (nupt_ncid, fbrnup_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nupt_ncid, rlwnup_id, "long_name", 
	strlen("large_wood_N_uptake"), "large_wood_N_uptake");
   status = nc_put_att_text (nupt_ncid, rlwnup_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_text (nupt_ncid, crtnup_id, "long_name", 
	strlen("coarse_root_N_uptake"), "coarse_root_N_uptake");
   status = nc_put_att_text (nupt_ncid, crtnup_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   /* leave define mode */
   status = nc_enddef (nupt_ncid);
   return 0;
}
