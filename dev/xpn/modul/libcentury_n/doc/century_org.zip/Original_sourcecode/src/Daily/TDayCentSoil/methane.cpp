// ----------------------------------------------------------------------------
//	Copyright 1998-2000 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model, daily version
//	File:	  methane.cpp
//	Class:	  TDayCentSoil
//	Function: MethaneOxidation
//
//	Description:
//	Calculate methane oxidation.  Methane oxidation is a function of
//	soil water content, temperature, porosity, and field capacity.
//
//	Reference:
//	General CH4 Oxidation Model and Comparison of CH4 Oxidation in Natural
//	and Managed Systems.  S.J. Del Grosso, W.J. Parton, A.R. Mosier, D.S.
//	Ojima, C.S. Potter, W. Borken, R. Brumme, K. Butterbach-Bahi, P.M.
//	Crill, K. Dobbie, and K.A. Smith.  In press.
// ----------------------------------------------------------------------------
//	Author: Cindy Keough
//	History:
//	Mar2001  Cindy Keough, cindyk@NREL.colostate.edu
//	* Created original methane.c for FORTRAN/C version of DayCent
//	Apr2001	 Melannie Hartman, melannie@NREL.colostate.edu
//	* Translated methane.c to methane.cpp
//	May03	Tom Hilinski
//	* Additional assertions and some minor cleanup.
// ----------------------------------------------------------------------------
//	Notes:
//	* Eventually remove type "double" declarations in favor of
//	   casting when necessary -mdh 4/25/01
//	* Specify "CH4DEPTH" as function argument instead? -mdh 4/25/0
// ----------------------------------------------------------------------------

#include "TDayCentSoil.h"
#include "AssertEx.h"
#include <cmath>
using namespace std;

#define CH4DEPTH 15.0f  // maximum depth at which CH4 oxidation occurs (cm)

float TDayCentSoil::MethaneOxidation (
    bool const isDeciduous,     // flag, 1 for deciduous forest, 0 otherwise
    bool const isAgriculture)   // flag, 1 for agricultural system or grassland
				//   that has been fertilized or cultivated,
				//   0 otherwise
{
    double const Ha_to_SqM = 0.0001;	// factor to convert ha to m^2
    double CH4;         		// methane oxidation (g/ha/day)

    // Compute a weighted average for soil temperature, field capacity,
    // bulk density, water filled pore space, and volumetric soil water
    // content in top CH4DEPTH cm of soil profile
    float const fieldcapacity =
	FieldCapacity().WtdMean (0.0f, CH4DEPTH, depth, thickness);
    float const bulkdensity =
	BulkDensity().WtdMean (0.0f, CH4DEPTH, depth, thickness);
    double const soiltemp =	// (deg C)
	SoilTempAvg().WtdMean (0.0f, CH4DEPTH, depth, thickness);
    double const soilwater =	// (volumetric %, cm^3 H2O / cm^3 soil * 100)
	100.0 * WaterContent().Quantity(0.0f, CH4DEPTH, depth, thickness) /
	CH4DEPTH;
    double const wfps = WtdMeanWFPS (CH4DEPTH);		// (fraction 0.0-1.0)

    if (isDeciduous)
    {
	//  CH4 oxidation for a deciduous system
	// maximum CH4 oxidation rate (g/ha/day)
	double const CH4max = 40.0 - 18.3 * bulkdensity;
	Assert (CH4max >= 0.0);

	// adjustment factor for soil temperature
	double const temp_adjust = 0.0209 * soiltemp + 0.845;
	Assert ( (10.0 * wfps - 0.5) / (1.84 - 0.5) > 0.0 );
	// adjustment factor for water filled pore space
	double wfps_adjust =
		std::pow ( (10.0 * wfps - 0.5) / (1.84 - 0.5), 0.13 );
	Assert ( (10.0 * wfps - 55) / (1.84 - 55) > 0.0 );
	wfps_adjust *= std::pow ( (10.0 * wfps - 55) / (1.84 - 55),
				  (0.13 * (55 - 1.84)) / (1.84 - 0.5) );
	wfps_adjust = std::max (0.1, wfps_adjust);

	Assert (temp_adjust >= 0.0);
	Assert (wfps_adjust >= 0.0);

	CH4 = CH4max * wfps_adjust * temp_adjust;
    }
    else
    {
	//  CH4 oxidation for a grassland/coniferous/tropical system
	// optimum/min/max water content (volumetric fraction * 10)
	float const Wopt = 6.3f * fieldcapacity - 0.58f;
	float const Wmin = 3.0 * fieldcapacity - 0.28;
	float const Wmax = 10.6 * fieldcapacity + 1.9;
	Assert (Wmin > 0.0);
	Assert (Wmax > 0.0);
	Assert (Wopt > 0.0);
	// float const wfps =			// water-filled pore space
	// 	Wopt * 0.1f / (1.0f - (bulkdensity / (float)PARTDENS));
	// ratio of gas diffusivity through soil at Wopt to gas
	//   diffusivity through air
	float const porosity = 1.0f - bulkdensity / PARTDENS;
	float const Dopt =
		Diffusivity (fieldcapacity, bulkdensity, porosity, wfps);
	// maximum CH4 oxidation rate (g/ha/day)
	double const CH4max = 53.8 * Dopt + 0.58;
	Assert (CH4max >= 0.0);
	double watr_adjust;     // adjustment factor for water limitation
	if ( 0.1 * soilwater < Wmin ||
	     0.1 * soilwater > Wmax )
	{
	    watr_adjust = 0.1;
	}
	else
	{
	    Assert ( ((0.1 * soilwater - Wmin) / (Wopt - Wmin)) > 0.0 );
	    Assert ( ((0.1 * soilwater - Wmax) / (Wopt - Wmax)) > 0.0 );
	    watr_adjust =
		std::pow( (0.1 * soilwater - Wmin) / (Wopt - Wmin), 0.4) *
		std::pow( (0.1 * soilwater - Wmax) / (Wopt - Wmax),
			  (0.4 * (Wmax - Wopt)) / (Wopt - Wmin) );
	    watr_adjust = std::max (0.1, watr_adjust);
	}
	double agri_adjust;     // adjustment factor for agricultural soils
	if (isAgriculture)
	{
	    if (Dopt < 0.1)
		agri_adjust = 0.9;
	    else if (Dopt > 0.28)
		agri_adjust = 0.28;
	    else
		agri_adjust = -4.6 * Dopt + 1.6;
	}
	else
	{
	    agri_adjust = 1.0;
	}
	// adjustment factor for soil temperature
	double const temp_adjust =
		(soiltemp * std::max(0.11f, Dopt) * 0.095) + 0.9;

	Assert (watr_adjust >= 0.0);
	Assert (temp_adjust >= 0.0);
	Assert (agri_adjust >= 0.0);

	CH4 = CH4max * watr_adjust * temp_adjust * agri_adjust;
    }

    //  Convert gC/ha/day to gC/m^2/day
    float const methaneFlux = CH4 * Ha_to_SqM;
    Assert (methaneFlux >= 0.0);
    return methaneFlux;
}

//--- end of file ---
