
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  soilcll_ncid;			/* netCDF id */

/* variable ids */
int  defacll_id, som1c1ll_id, som1c2ll_id, som2cll_id, som3cll_id, 
     strucc1ll_id, strucc2ll_id, metabc1ll_id, metabc2ll_id;
int  timell_id, lat_id, lon_id;

/* create soilc.nc */
int
soilcdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
            float *opltim, float *qtime) {

   int   status, istart_year, iend_year, ii;
   float fill, fstart_year, fend_year;
   char  timeunits[25], temp[5];

   /* dimension ids */
   int  time_dim = 0;
   int  lat_dim = 0;
   int  lon_dim = 0;

   /* variable shapes */
   int dims[3];

   /* Set fill, start_year, and end_year values */
   fill = NC_FILL_FLOAT;
   fstart_year = *opltim;
   fend_year = *qtime - 1;
   istart_year = fstart_year;
   iend_year = fend_year;

   for (ii = 0; ii < 25; ii++) {
     timeunits[ii] = '\0';
   }
   /* Get the start time for the time definition */
   sprintf(temp, "%d", istart_year); 
   strcat(timeunits, "days since ");
   strcat(timeunits, temp);
   strcat(timeunits, "-01-01");

   /* enter define mode */
   status = nc_create("soilcll.nc", NC_CLOBBER, &soilcll_ncid);
   if (status != NC_NOERR) handle_error("nc_create(soilc.nc)", status);

   /* define dimensions */
   status = nc_def_dim(soilcll_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(soilcll_ncid, "lat", (size_t) *nlat, &lat_dim);
   status = nc_def_dim(soilcll_ncid, "lon", (size_t) *nlon, &lon_dim);

   /* define variables */

   dims[0] = time_dim;
   status = nc_def_var (soilcll_ncid, "time", NC_INT, 1, dims, &timell_id);

   dims[0] = lat_dim;
   status = nc_def_var (soilcll_ncid, "lat", NC_FLOAT, 1, dims, &lat_id);

   dims[0] = lon_dim;
   status = nc_def_var (soilcll_ncid, "lon", NC_FLOAT, 1, dims, &lon_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilcll_ncid, "defac", NC_FLOAT, 3, dims, &defacll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilcll_ncid, "som1c1", NC_FLOAT, 3, dims, &som1c1ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilcll_ncid, "som1c2", NC_FLOAT, 3, dims, &som1c2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilcll_ncid, "som2c", NC_FLOAT, 3, dims, &som2cll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilcll_ncid, "som3c", NC_FLOAT, 3, dims, &som3cll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilcll_ncid, "strucc1", NC_FLOAT, 3, dims, &strucc1ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilcll_ncid, "strucc2", NC_FLOAT, 3, dims, &strucc2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilcll_ncid, "metabc1", NC_FLOAT, 3, dims, &metabc1ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilcll_ncid, "metabc2", NC_FLOAT, 3, dims, &metabc2ll_id);

   /* assign attributes */
   status = nc_put_att_text (soilcll_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (soilcll_ncid, timell_id, "long_name", strlen("Time"), "Time");
   status = nc_put_att_text (soilcll_ncid, timell_id, "units", strlen(timeunits), timeunits);
   status = nc_put_att_text (soilcll_ncid, timell_id, "time_step", strlen("monthly"), "monthly");
   status = nc_put_att_text (soilcll_ncid, timell_id, "calendar", strlen("gregorian"), "gregorian");
   status = nc_put_att_int (soilcll_ncid, timell_id, "start_year", NC_INT, 1, &istart_year);
   status = nc_put_att_int (soilcll_ncid, timell_id, "end_year", NC_INT, 1, &iend_year);

   status = nc_put_att_text (soilcll_ncid, lat_id, "long_name", strlen("Latitude"), "Latitude");
   status = nc_put_att_text (soilcll_ncid, lat_id, "units", strlen("degrees_north"), "degrees_north");
   status = nc_put_att_text (soilcll_ncid, lat_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (soilcll_ncid, lat_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (soilcll_ncid, lon_id, "long_name", strlen("Longitude"), "Longitude");
   status = nc_put_att_text (soilcll_ncid, lon_id, "units", strlen("degrees_east"), "degrees_east");
   status = nc_put_att_text (soilcll_ncid, lon_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (soilcll_ncid, lon_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (soilcll_ncid, defacll_id, "long_name", 
	strlen("decomposition factor"), "decomposition factor");
   status = nc_put_att_text (soilcll_ncid, defacll_id, "units", strlen("unitless"), "unitless");
   status = nc_put_att_float(soilcll_ncid, defacll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilcll_ncid, som1c1ll_id, "long_name", 
	strlen("surface_microbial_carbon"), "surface_microbial_carbon");
   status = nc_put_att_text (soilcll_ncid, som1c1ll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilcll_ncid, som1c1ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilcll_ncid, som1c2ll_id, "long_name", 
	strlen("soil_microbial_carbon"), "soil_microbial_carbon");
   status = nc_put_att_text (soilcll_ncid, som1c2ll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilcll_ncid, som1c2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilcll_ncid, som2cll_id, "long_name", 
	strlen("som2_carbon"), "som2_carbon");
   status = nc_put_att_text (soilcll_ncid, som2cll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilcll_ncid, som2cll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilcll_ncid, som3cll_id, "long_name", 
	strlen("som3_carbon"), "som3_carbon");
   status = nc_put_att_text (soilcll_ncid, som3cll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilcll_ncid, som3cll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilcll_ncid, strucc1ll_id, "long_name", 
	strlen("surface_structural_carbon"), "surface_structural_carbon");
   status = nc_put_att_text (soilcll_ncid, strucc1ll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilcll_ncid, strucc1ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilcll_ncid, strucc2ll_id, "long_name", 
	strlen("soil_structural_carbon"), "soil_structural_carbon");
   status = nc_put_att_text (soilcll_ncid, strucc2ll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilcll_ncid, strucc2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilcll_ncid, metabc1ll_id, "long_name", 
	strlen("surface_metabolic_carbon"), "surface_metabolic_carbon");
   status = nc_put_att_text (soilcll_ncid, metabc1ll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilcll_ncid, metabc1ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilcll_ncid, metabc2ll_id, "long_name", 
	strlen("soil_metabolic_carbon"), "soil_metabolic_carbon");
   status = nc_put_att_text (soilcll_ncid, metabc2ll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilcll_ncid, metabc2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   /* leave define mode */
   status = nc_enddef (soilcll_ncid);
   return 0;
}
