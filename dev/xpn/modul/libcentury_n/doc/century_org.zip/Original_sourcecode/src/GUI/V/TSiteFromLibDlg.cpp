// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TSiteFromLibDlg.cpp
//	Class:	  TSiteFromLibDlg
//
//	Description:
//	Class for copying a site parameter set from the library.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Apr98
//	History: See the header file.
// ----------------------------------------------------------------------------

#define _TSiteFromLibDlg_ClassDefined_
#include "TSiteFromLibDlg.h"
#include "TMCSiteParIndices.h"
#include "TFileList.h"
#include "AssertEx.h"
#include "HelpDisplay.h"
#include "netcdfcpp.h"
#include <v/vnotice.h>
#include <v/vutil.h>
#include <algorithm>

namespace {

static char displayStr[21];		// for converting values <--> dlg text
static char const * const NULLStr = "";	// global NULL string

} // anon namespace

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

std::string const TSiteFromLibDlg::maskSiteFileNetCDFSuffix = "*-ST.nc";

char const * const TSiteFromLibDlg::toolTips[] =
{
	// 0 = app default library folder
	"Select from sites in the default site parameter library.",
	// 1 = user's personal library folder
	"Select from sites in the your personal site library.",
	// 2 = radiobutton: crop
	"View a list of crop sites.",
	// 3 = radiobutton: grass
	"View a list of grass sites.",
	// 4 = radiobutton: tree
	"View a list of tree sites.",
	// 5 = radiobutton: savanna
	"View a list of savanna sites.",
	// 6 = list: descriptions
	"Select a site from these descriptions.",
	// 7 = r/o text: Mnemonic
	"Name for the site.",
	// 8 = r/o text: latitude/longitude
	"Location in degrees.",
	// 9 = r/o text: sand, silt, and clay %
	"Percent sand, silt, and clay content of soil.",
	// 10 = Accept
	"Use the selected site parameter set for the simulation.",
	// 11 = Cancel
	"Cancel this operation.",
	// 12 = Help
	"View Help on selecting a site parameter set.",
	// 13 = editor name
	"Name of last editor of this site.",
	// 14 = edit date
	"Date and time of last edit of this site.",
	// last item always
	NULL
};


CommandObject TSiteFromLibDlg::cmdList[] =
{
	//--- Master Frame provides a border for data
	{C_Frame, 101, 0, NULLStr, NoList, CA_NoBorder, isSens, NoFrame, 0, 0},

	//--- site library
	{C_Label, 201, 0, "1. Select Library",
		NoList, CA_None, isSens, 101, 0, 0},
	{C_Frame, 105, 0, NULLStr, NoList, CA_None, isSens, 101, 0, 201},
	{C_RadioButton, D_DefaultLib, 1, "Default",
		NoList, CA_None, isSens, 105, 0, 201, 0, toolTips[0]},
	{C_RadioButton, D_PersonalLib, 0, "Personal",
		NoList, CA_None, isSens, 105, 0, D_DefaultLib, 0, toolTips[1]},

	//--- site category
	{C_Label, 210, 0, "2. Select Category",
		NoList, CA_None, isSens, 101, 201, 0},
	{C_Frame, 110, 0, NULLStr, NoList, CA_None, isSens, 101, 201, 210},
	{C_RadioButton, D_CatCrop, 1, "Crop",
		NoList, CA_None, isSens, 110, 0, 210, 0, toolTips[2]},
	{C_RadioButton, D_CatGrass, 0, "Grass",
		NoList, CA_None, isSens, 110, 0, D_CatCrop, 0, toolTips[3]},
	{C_RadioButton, D_CatTree, 0, "Tree",
		NoList, CA_None, isSens, 110, 0, D_CatGrass, 0, toolTips[4]},
	{C_RadioButton, D_CatSavanna, 0, "Savanna",
		NoList, CA_None, isSens, 110, 0, D_CatTree, 0, toolTips[5]},

	//--- site list
	{C_Label, 220, 0, "3. Select Site",
		NoList, CA_None, isSens, 101, 210, 0},
	{C_List, D_DescripList, 150, NULLStr, NoList,
		CA_ListWidth, isSens, 101, 210, 220, 0, toolTips[6]},

	//--- site summary
	{C_Label, 230, 0, "Site Summary",
		NoList, CA_None, isSens, 101, 0, D_DescripList},
	{C_Frame, 115, 0, NULLStr, NoList, CA_NoSpace, isSens, 101, 0, 230},

	{C_Label, 260, 0, "Site File Name:",
		NoList, CA_None, isSens, 115, 0, 0, 55},
	{C_Label, D_SiteFile, 0, "",
		NoList, CA_None, isSens, 115, 260, 0, 230},

	{C_Label, 232, 0, "Mnemonic:",
		NoList, CA_None, isSens, 115, 0, 260, 40},
	{C_Label, D_Mnemonic, 0, "",
		NoList, CA_NoBorder, isSens, 115, 232, 260, 100},
	{C_Label, 236, 0, "Latitude:",
		NoList, CA_None, isSens, 115, 0, 232, 40},
	{C_Label, D_Lat, 0, "",
		NoList, CA_NoBorder, isSens, 115, 236, 232, 40, toolTips[8]},
	{C_Label, 238, 0, "Longitude:",
		NoList, CA_None, isSens, 115, 0, 236, 40},
	{C_Label, D_Long, 0, "",
		NoList, CA_NoBorder, isSens, 115, 238, 236, 40, toolTips[8]},
	{C_Label, 270, 0, "Editor:",
		NoList, CA_None, isSens, 115, 0, 238, 40},
	{C_Label, D_EditorName, 0, "",
		NoList, CA_NoBorder, isSens, 115, 270, 238, 200, toolTips[13]},
	{C_Label, 272, 0, "Edit Date:",
		NoList, CA_None, isSens, 115, 0, 270, 40},
	{C_Label, D_EditDate, 0, "",
		NoList, CA_NoBorder, isSens, 115, 272, 270, 100, toolTips[14]},

	{C_Label, 242, 0, "Sand(1) (%) =",
		NoList, CA_None, isSens, 115, D_Mnemonic, 260, 50},
	{C_Label, D_Sand, 0, "",
		NoList, CA_NoBorder, isSens, 115, 242, 260, 30, toolTips[9]},
	{C_Label, 244, 0, "Silt(1) (%) =",
		NoList, CA_None, isSens, 115, D_Mnemonic, 242, 50},
	{C_Label, D_Silt, 0, "",
		NoList, CA_NoBorder, isSens, 115, 244, 242, 30, toolTips[9]},
	{C_Label, 246, 0, "Clay(1) (%) =",
		NoList, CA_None, isSens, 115, D_Mnemonic, 244, 50},
	{C_Label, D_Clay, 0, "",
		NoList, CA_NoBorder, isSens, 115, 246, 244, 30, toolTips[9]},

	//--- library search paths
	{C_Frame, 120, 0, NULLStr,
		NoList, CA_NoSpace | CA_NoBorder, isSens, 101, 0, 115},
	{C_Label, 250, 0, "Default library path:",
		NoList, CA_None, isSens, 120, 0, 0},
	{C_Label, D_LibPath1, 0, "",
		NoList, CA_NoBorder, isSens, 120, 250, 0, 200},
	{C_Label, 252, 0, "Personal library path:",
		NoList, CA_None, isSens, 120, 0, 250},
	{C_Label, D_LibPath2, 0, "",
		NoList, CA_NoBorder, isSens, 120, 252, 250, 200},

	//--- Common Buttons
	{C_Button, M_OK, M_OK,		"  &Open",
		NoList,	CA_DefaultButton, isSens, NoFrame, 0, 101,
		0, toolTips[10]},
	{C_Button, M_Cancel, M_Cancel,	" &Cancel",
		NoList,	CA_None, isSens, NoFrame, M_OK, 101, 0, toolTips[11]},
	{C_Button, M_Help, M_Help, 	"  &Help ",
		NoList,	CA_None, isSens, NoFrame, M_Cancel, 101,
		0, toolTips[12]},

	//--- Last one always!
	{C_EndOfList, 0, 0, 0, 0, CA_None, 0, 0}
};

// ----------------------------------------------------------------------------
//	methods
// ----------------------------------------------------------------------------

//--- constructors and destructor

//	newDefPath = default path to search for library subdirectories,
//	newUserPath = user's library path (no subdirectories).
TSiteFromLibDlg::TSiteFromLibDlg (
	vApp * const useParent,			// pointer to application parent
	std::string const & useHelpPath,	// path to help file
	std::string const & newDefPath,		// path to search for site files
	std::string const & newUserPath,	// user's library path
	std::string & siteFile,			// returns selected site file
	char const * const title )		// title of dialog
	: TModalDlg (useParent, title),
	  parent (useParent),
	  helpFilePath (useHelpPath)
{
	ConstructMe (newDefPath, newUserPath, siteFile, title);
}

TSiteFromLibDlg::TSiteFromLibDlg (
	vBaseWindow * const useParent,		// pointer to window parent
	vApp * const useApp,			// pointer to application parent
	std::string const & useHelpPath,	// path to help file
	std::string const & newDefPath,		// path to search for site files
	std::string const & newUserPath,	// user's library path
	std::string & siteFile,			// returns selected site file
	char const * const title )		// title of dialog
	: parent (useApp),
	  helpFilePath (useHelpPath),
	  TModalDlg (useParent, title)
{
	ConstructMe (newDefPath, newUserPath, siteFile, title);
}

TSiteFromLibDlg::~TSiteFromLibDlg ()
{
	ClearDlgSiteList ();
	for (short i = 0; i < 2; i++)
	{
		// delete string lists
		::DeleteNTCStringList (descListCrop[i]);
		::DeleteNTCStringList (descListGrass[i]);
		::DeleteNTCStringList (descListTree[i]);
		::DeleteNTCStringList (descListSav[i]);
		// delete strings
		libPath[i].clear();
		// erase vectors
		sumCrop[i].erase ( sumCrop[i].begin(), sumCrop[i].end() );
		sumGrass[i].erase ( sumGrass[i].begin(), sumGrass[i].end() );
		sumTree[i].erase ( sumTree[i].begin(), sumTree[i].end() );
		sumSav[i].erase ( sumSav[i].begin(), sumSav[i].end() );
		sumCrop[i].resize (0);
		sumGrass[i].resize (0);
		sumTree[i].resize (0);
		sumSav[i].resize (0);
	}
}

//	ConstructMe
//	common constructor
void TSiteFromLibDlg::ConstructMe (
	std::string const & newDefPath,		// path to site libraries
	std::string const & newUserPath,	// user's site library path
	std::string & siteFile,			// returns selected site file
	char const * const title)		// dialog title
{
	//--- initialize variables
	Initialize ();
	libPath[0] = newDefPath;
	Assert ( !libPath[0].empty() );		// always have a default lib
	libPath[1] = newUserPath;
	ReadDescriptions ();

	// Get the indicies to cmdList items for lists.
	// Done only once for speed.
	idxParamList = ::vGetcmdIdIndex (D_DescripList, cmdList);

	//--- display dialog
	AddDialogCmds ((CommandObject*)cmdList);	// add dialog controls
	ItemVal retVal;
	ShowModalDialog (title, retVal);		// display it now

	//--- return data
	if ( !libPath[usingPath].empty() && usingSiteSum )
	{
		siteFile = libPath[usingPath];
		siteFile += usingSiteSum->fileName;
	}
}

//--- functions overridden

void TSiteFromLibDlg::DialogDisplayed ()
{
	TModalDlg::DialogDisplayed ();
	if ( libPath[1].empty() )		// personal lib available?
		SetValue (D_PersonalLib, notSens, Sensitive);	// de-activate

	// display the search paths
	SetString ( D_LibPath1, libPath[0] );
	SetString ( D_LibPath2, libPath[1] );

	LoadDlg ();				// load data into dialog
}

void TSiteFromLibDlg::DialogCommand (ItemVal id, ItemVal val, CmdType type)
{
	switch (id)
	{
						// which library path?
	  case D_DefaultLib:
		if ( usingPath != 0 )
		{
			usingPath = 0;
			UpdateDlg_SiteList ();
		}
		break;
	  case D_PersonalLib:
		if ( usingPath != 1 )
		{
			usingPath = 1;
			UpdateDlg_SiteList ();
		}
		break;
						// which category?
	  case D_CatCrop:
		if ( usingCat != TSiteParametersBase::ST_Crop )
		{
			usingCat = TSiteParametersBase::ST_Crop;
			UpdateDlg_SiteList ();
		}
		break;
	  case D_CatGrass:
		if ( usingCat != TSiteParametersBase::ST_Grass )
		{
			usingCat = TSiteParametersBase::ST_Grass;
			UpdateDlg_SiteList ();
		}
		break;
	  case D_CatTree:
		if ( usingCat != TSiteParametersBase::ST_Tree )
		{
			usingCat = TSiteParametersBase::ST_Tree;
			UpdateDlg_SiteList ();
		}
		break;
	  case D_CatSavanna:
		if ( usingCat != TSiteParametersBase::ST_Savanna )
		{
			usingCat = TSiteParametersBase::ST_Savanna;
			UpdateDlg_SiteList ();
		}
		break;
						// list selection
	  case D_DescripList:
	  	UpdateDlg_SiteData ();
	  	break;
						// buttons
	  case M_OK:
		break;
	  case M_Cancel:
	  	usingSiteSum = 0;
		break;
	  case M_Help:			// "help" button
#ifdef MSWindowsHelp
		::HelpDisplay (parent->winHwnd(), helpFilePath,
			HELP_CONTEXT, IDH_SITE_FROMLIB_DLG);
#elif defined(X11Help)
		::HelpDisplay (winHwnd(), helpFilePath,
			HELP_CONTEXT, IDH_SITE_FROMLIB_DLG);
#endif
		break;
	  default:
	  	break;
	};
	// Default event processing
	TModalDlg::DialogCommand (id, val, type);
}


//--- private functions

//	Initialize
// 	initialize members
void TSiteFromLibDlg::Initialize ()
{
	for (short i = 0; i < 2; i++)
	{
		descListCrop[i] = descListGrass[i] =
		descListTree[i] = descListSav[i] = NULL;
		libPath[i].clear();
	}
	usingPath = 0;					// default library
	usingCat = TSiteParametersBase::ST_Unknown;	// unknown category
	usingSiteSum = 0;
}

//	ReadDescriptions
// 	gets site descriptions from files
void TSiteFromLibDlg::ReadDescriptions ()
{
	vector<TSiteDesc> tmpList;		// temporary list of descrips.
	std::string mask;			// file list mask
	TSiteSummary sum;			// temporary site summary
	short cntCrop, cntGrass,		// counts of each type
	      cntTree, cntSav;
	long strLen;				// string length

	for ( short i = 0; i < 2; i++ )		// for each library
	{
		if ( libPath[i].empty() )		// path to folder?
			continue;			// ...no

		// get a list of files
		Assert (libPath[i].size() < 250);
		mask = libPath[i];
		mask += maskSiteFileNetCDFSuffix;
		Assert (mask.size() < 257);
		TEH::TFileNameList fileList (
			mask, TEH::TFileNameList::FLT_Normal);
		if ( fileList.IsError() ||
		     fileList.GetCount() == 0 )			// list ok?
			continue;				// ...no

		// reserve some memory for the STL vectors
		// to prevent excessive reallocation and copying
		tmpList.reserve (fileList.GetCount());
		if ( fileList.GetCount() >= 8 )
		{
			short const reserveSize =
				(fileList.GetCount() + 3) / 4 + 1;
			sumCrop[i].reserve (reserveSize);
			sumGrass[i].reserve (reserveSize);
			sumTree[i].reserve (reserveSize);
			sumSav[i].reserve (reserveSize);
		}

		// read the files in the current library path
		char const * const * const fileNames = fileList.GetList ();
		cntCrop = cntGrass = cntTree = cntSav = 0;
		for ( short f = 0; f < fileList.GetCount(); ++f )
		{
			char const * const curName = fileNames[f];
			// create a full path name
			Assert ((libPath[i].size() + strlen(curName)) < 257);
			std::string ncName;	// current file to read
			ncName = libPath[i];
			ncName += curName;
			Assert (!ncName.empty());

			// open the file
			NcFile ncFile (ncName.c_str(), NcFile::ReadOnly);
			if ( !ncFile.is_valid() )
				continue;	// error accessing the file

			// get pointers to netCDF variables (by position)
			NcVar* siteType = ncFile.get_var ("siteType");
			NcVar* siteName = ncFile.get_var ("name");
			NcVar* siteDesc = ncFile.get_var ("description");
			NcVar* siteVals = ncFile.get_var ("value");
			Assert (siteType != 0);
			Assert (siteName != 0);
			Assert (siteDesc != 0);
			Assert (siteVals != 0);

			// keep above the goto
			NcAtt* edNameAtt = 0;		// editor name
			NcAtt* edDateAtt = 0;		// edit date
			char tmpStr[81];		// temporary string
			TSiteDesc tmpSiteDesc;		// temp description

			// read the description
			// Save in an STL array to build lists after all
			// the descriptions are collected.
			ncbyte type;				// read type
			siteType->get (&type, 1);
			if ( (TSiteType)type == TSiteParametersBase::ST_Unknown )
				goto close_file;
			tmpSiteDesc.type = (TSiteType)type;	// save
			siteDesc->get (tmpSiteDesc.desc, 80);	// read desc
			tmpSiteDesc.desc[80] = '\0';
			::strtrim (tmpSiteDesc.desc);
			tmpList.push_back (tmpSiteDesc);	// save

			// read in the summary data
			Assert (strlen(curName) < 101);		// file name
			sum.fileName = curName;
			siteName->get (tmpStr, 20);		// site name
			tmpStr[20] = '\0';
			::strtrim (tmpStr);
			sum.name = tmpStr;

			// summary values
			siteVals->set_cur (TMCSiteParIndices::SPI_sitlat);
			siteVals->get (&sum.latitude, 1);
			siteVals->set_cur (TMCSiteParIndices::SPI_sitlng);
			siteVals->get (&sum.longitude, 1);
			siteVals->set_cur (TMCSiteParIndices::SPI_sand);
			siteVals->get (&sum.sand, 1);
			siteVals->set_cur (TMCSiteParIndices::SPI_silt);
			siteVals->get (&sum.silt, 1);
			siteVals->set_cur (TMCSiteParIndices::SPI_clay);
			siteVals->get (&sum.clay, 1);

			// attribute - editor name
			edNameAtt = ncFile.get_att ("LastModifiedWho");
			strLen = edNameAtt->num_vals ();
			if ( strLen <= 40 )
			    sum.editorName = edNameAtt->as_string(0);
			else
			{
			    sum.editorName.assign (
			    	edNameAtt->as_string(0), 40);
			}
			delete edNameAtt;

			// attribute - last edit date
			edDateAtt = ncFile.get_att ("LastModifiedWhen");
			strLen = edDateAtt->num_vals ();
			if ( strLen <= 18 )
			    sum.editDate = edDateAtt->as_string(0);
			else
			{
			    sum.editDate.assign (
			    	edDateAtt->as_string(0), 18);
			}
			delete edDateAtt;

			// store summary data
			switch ( (TSiteType)type )
			{
			  case TSiteParametersBase::ST_Crop:
				++cntCrop;
				sumCrop[i].push_back (sum);
				break;
			  case TSiteParametersBase::ST_Grass:
 				++cntGrass;
				sumGrass[i].push_back (sum);
				break;
			  case TSiteParametersBase::ST_Tree:
				++cntTree;
				sumTree[i].push_back (sum);
				break;
			  case TSiteParametersBase::ST_Savanna:
				++cntSav;
				sumSav[i].push_back (sum);
				break;
			};
		  close_file:
			ncFile.close ();		// close the file
		}

		// build display lists of descriptions
		// 1. alloc memory for lists, and null-term. the list
		Assert ( (unsigned int)cntCrop == sumCrop[i].size() );
		Assert ( (unsigned int)cntGrass == sumGrass[i].size() );
		Assert ( (unsigned int)cntTree == sumTree[i].size() );
		Assert ( (unsigned int)cntSav == sumSav[i].size() );
		Assert ( (unsigned int)(cntCrop+cntGrass+cntTree+cntSav) ==
			 tmpList.size());
		if ( cntCrop > 0 )				// crop
		{
			descListCrop[i] = new char* [cntCrop + 1];
			descListCrop[i][cntCrop] = NULL;
		}
		if ( cntGrass > 0 )				// grass
		{
			descListGrass[i] = new char* [cntGrass + 1];
			descListGrass[i][cntGrass] = NULL;
		}
		if ( cntTree > 0 )				// tree
		{
			descListTree[i] = new char* [cntTree + 1];
			descListTree[i][cntTree] = NULL;
		}
		if ( cntSav > 0 )				// savanna
		{
			descListSav[i] = new char* [cntSav + 1];
			descListSav[i][cntSav] = NULL;
		}
		// 2. extract description strings from vector
		vector<TSiteDesc>::iterator loc = tmpList.begin ();
		cntCrop = cntGrass = cntTree = cntSav = 0; 	// index lists
		while ( loc != tmpList.end() )	// for each description...
		{
			// alloc memory for string
			char * const str = new char [strlen(loc->desc) + 1];
			strcpy (str, loc->desc);
			// save string in list, and increment counter
			switch ( (TSiteType)loc->type )
			{
			  case TSiteParametersBase::ST_Crop:
				descListCrop[i][cntCrop++] = str;
				break;
			  case TSiteParametersBase::ST_Grass:
				descListGrass[i][cntGrass++] = str;
				break;
			  case TSiteParametersBase::ST_Tree:
				descListTree[i][cntTree++] = str;
				break;
			  case TSiteParametersBase::ST_Savanna:
				descListSav[i][cntSav++] = str;
				break;
			};
			++loc;				// next description
		}

		// erase the temporary description list
		tmpList.erase ( tmpList.begin(), tmpList.end() );
	}
}


// Load data into dialogs:

//	LoadDlg
// 	load the dialog
void TSiteFromLibDlg::LoadDlg ()
{
	usingPath = 0;			// default library folder
	usingCat = TSiteParametersBase::ST_Crop;		// crop
	UpdateDlg_SiteList ();
}

//	UpdateDlg_SiteList
// 	site list
void TSiteFromLibDlg::UpdateDlg_SiteList ()
{
	// usingPath and usingCat are set in DialogCommand()
	// select list to display
	char **p = 0;				// pointer to the list
	switch ( usingCat )
	{
	  case TSiteParametersBase::ST_Crop:
		p = descListCrop[usingPath];
		break;
	  case TSiteParametersBase::ST_Grass:
		p = descListGrass[usingPath];
		break;
	  case TSiteParametersBase::ST_Tree:
		p = descListTree[usingPath];
		break;
	  case TSiteParametersBase::ST_Savanna:
		p = descListSav[usingPath];
		break;
	};
	// display the list
	cmdList[idxParamList].itemList = (void *)p; 	// set ptr to list
	SetValue (cmdList[idxParamList].cmdId, 0, ChangeListPtr); // display

	// update the parameter data
	UpdateDlg_SiteData ();
}

//	UpdateDlg_SiteData
// 	site data
void TSiteFromLibDlg::UpdateDlg_SiteData ()
{
	// get index to the currently selected item in the event list
	short i = (short)GetValue (D_DescripList);
	// get the summary data of the selected item
	TSiteSummary *sum = NULL;
	switch ( usingCat )
	{
	  case TSiteParametersBase::ST_Crop:
		if ( !sumCrop[usingPath].empty() )
			sum = &(sumCrop[usingPath][i]);
		break;
	  case TSiteParametersBase::ST_Grass:
		if ( !sumGrass[usingPath].empty() )
			sum = &(sumGrass[usingPath][i]);
		break;
	  case TSiteParametersBase::ST_Tree:
		if ( !sumTree[usingPath].empty() )
			sum = &(sumTree[usingPath][i]);
		break;
	  case TSiteParametersBase::ST_Savanna:
		if ( !sumSav[usingPath].empty() )
			sum = &(sumSav[usingPath][i]);
		break;
	};
	if ( sum )
	{
		SetValue ( M_OK, isSens, Sensitive);
		usingSiteSum = sum;				// save
		SetString ( D_SiteFile, sum->fileName.c_str() );
		SetString ( D_Mnemonic, sum->name.c_str() );
		sprintf (displayStr, "%-.2f", sum->latitude);
		SetString ( D_Lat, displayStr );
		sprintf (displayStr, "%-.2f", sum->longitude);
		SetString ( D_Long, displayStr );
		sprintf (displayStr, "%-.3f", sum->sand);
		SetString ( D_Sand, displayStr );
		sprintf (displayStr, "%-.3f", sum->silt);
		SetString ( D_Silt, displayStr );
		sprintf (displayStr, "%-.3f", sum->clay);
		SetString ( D_Clay, displayStr );
		SetString ( D_EditorName, sum->editorName.c_str() );
		SetString ( D_EditDate, sum->editDate.c_str() );
	}
	else
	{
		SetValue ( M_OK, notSens, Sensitive);
		ClearDlgSiteSum ();
	}
}


// Clear dialog controls:

//	ClearDlgSiteList
// 	Clear site list display
void TSiteFromLibDlg::ClearDlgSiteList ()
{
	// display the list
	cmdList[idxParamList].itemList = (void *)NULL; 	// set ptr to list
	SetValue (cmdList[idxParamList].cmdId, 0, ChangeListPtr); // display
}

//	ClearDlgSiteSum
//	Clear the site summary data
void TSiteFromLibDlg::ClearDlgSiteSum ()
{
	short i = (short)D_SiteFile;
	while ( i <= (short)D_Clay )
	{
		SetString ( i, NULLStr );
		++i;
	}
}








