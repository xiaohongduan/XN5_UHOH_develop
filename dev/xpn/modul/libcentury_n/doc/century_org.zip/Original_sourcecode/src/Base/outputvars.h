#ifndef INC_outputvars_h
#define INC_outputvars_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	Project:  Century Soil Organic Matter Model
//	File:	  outputvars.h
//	Classes:
//	  TWaterTemp
//	  TSoilC
//	  TCropGrassC
//	  TForestC
//	  TCO2
//	  TNPS
//
//	Description:
//	Classes for Century output variables.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jun98
//	History:
//	May99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added "simDepth" to TWaterTemp =
//	  simulation layer depth (thickness) in cm.
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added "lhsomtc" and "somtpc" to TSoilC.
//	* Added "soilDepth" to TWaterTemp
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Changed all "0.0" to "0.0f"
//	* Made TCenturyOutput::memCheckValue a static const instead of #define.
//	* Added copy constructor
//	Oct01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Changed base class name to TCenturyOutputSet.
//	* Moved class TCenturyOutputSet to its own file.
// ----------------------------------------------------------------------------
//	Notes:
//
//	(1) Each output class has a set of floating point values with unique
//	names. A list of pointers to the variables is built upon construction
//	of the class to allow the set of variables to be accessed as an array
//	of floats for speed upon output.
//
//	(2) The order in which the pointers to the variables is assigned must
//	match the list of output variable names! The order is alphabetical (as
//	of the original ordering). Any changes to variable names, or addition
//	of new variables, will have to accommodate ordering, and consider past
//	vs. new ordering.
//
//	(3) With any additions/removals of variables, adjust the number of
//	variables in the total specified in the call to the constructor for
//	TCenturyOutputSet. Also, add/remove the variables from the member
//	functions for the class: Clear, AssignPointers.
//
//	(4) The values for "numFloats" member variable for each class should
//	match the dimemsion for the number of variables in the netCDF file,
//	"OutVarsDef.cdl".
// ----------------------------------------------------------------------------

#include "TCenturyOutputSet.h"
#include "centconsts.h"

//	------------------------------------------------------------
//	TWaterTemp
//	Output variables - Water and temperature
class TWaterTemp : public TCenturyOutputSet
{
  public:
    float
    	firstOne,			// dummy - always first variable!
	adefac,		// Average annual value of the variable DEFAC.
	anerb,		// Effect of soil anaerobic conditions on decomp.
 	asmos[MAXLYR],	// Soil water content of the nth soil layer(cm H2O)
 			//    Last layer = drainage pool
	avh2o[3],	// Available water:
			//   [0] = to plants for growth (nlaypg),
			//   [1] = to plants for survival (nlayer),
			//   [2] = in the simulation depth (wt.simDepth)
	defac,		// Decomposition factor based on temp. and moisture.
	evap,		// water evaporated from soil & vegetation (cm/month)
	irract,		// Actual amount of irrigation (cm H2O/month).
	irrtot,		// Cumulative irrigation (cm H2O).
	pet,		// Monthly potential evapotranspiration (cm).
	petann,		// Annual potential eva3potranspiration (cm).
	prcann,		// Annual precipitation (cm).
	prcfal,		// Fallow period precipitation (cm).
	pttr,		// Monthly potential transpiration water loss.
	rain,		// Monthly precipitation (cm).
	runoff,		// Monthly runoff (cm/month)
	rwcf[MAXLYR],	// Plant-extractable water content fractions
	snlq,		// Liquid water in snowpack (cm).
	snow,		// Snowpack water content (cm H2O).
	stemp,		// Average soil temperature (deg C).
	stream[8],	// Stream flow and leached amounts of C, N, P, S:
			//   [0] = flow (base flow + storm flow) (cm H2O).
			//   [1-3] = mineral leaching N, P, S (g/m2).
			//   [4-7] = organic leaching C, N, P, S (g/m2).
	tave,		// Average air temperature (deg C).
	tran,		// Monthly transpiration (cm).
	simDepth,	// Simulation layer depth (thickness) (cm).
	soilDepth,	// Soil profile depth
   	lastOne;			// dummy - always last variable!
    // constuctor
    TWaterTemp () : TCenturyOutputSet (51)
	{ Clear ();
	  firstOne = lastOne = memCheckValue;	// for memory overwrite checks:
    	  AssignPointers ();
	};
    // functions
    void Clear ();
    bool IsMemoryOK ()
    	{ return (firstOne == memCheckValue && lastOne ==  memCheckValue); }

  private:
    void AssignPointers ();	// initialize pointers to variablse
};

//	------------------------------------------------------------
//	TSoilC
//	Output variables - C in soil
class TSoilC : public TCenturyOutputSet
{
  public:
    float
    	firstOne,			// dummy - always first variable!
	clittr[4],	// Soil and Surface C residue (g/m2). was [2][2].
			//   [0,0] = Surface unlabeled
			//   [0,1] = Surface labeled
 			//   [1,0] = Soil unlabeled
 			//   [1,1] = Soil labeled
	cltfac[4],	// Effect of cultivation on decomposition for
			//   SOM1, 2, 3, and structural C;
			//   is a factor normalized to 1.0
	csrsnk[2],	// C source/sink (g/m2), Unlabeled and Labeled
	dblit,		// Delta 13C value for belowground litter.
	dmetc[2],	// Delta 13C value for metabolic C in
			//   [0] = surface, [1] = belowground.
	dslit,		// Delta 13C value for surface litter.
	dsom1c[2],	// Delta 13C value for SOM1C.
	dsom2c,		// Delta 13C value for SOM2C.
	dsom3c,		// Delta 13C value for SOM3C.
	dsomsc,		// Delta 13C value for SOM.
	dsomtc,		// Delta 13C value for total soil C.
	dstruc[2],	// Delta 13C value for structural C;
			//   [0] = surface, [1] = belowground.
	lhzcac,		// Cumulative C transferred to 0-20 cm layer from
			//   lower horizon pools due to soil erosion (g/m2).
	lhsomtc,	// Lower horizon total soil organic C
	metabc[2],	// Metabolic C in litter (g/m2).
			//   [0] = surface, [1] = belowground.
	metcis[4],	// Metabolic litter C (g/m2); was [2][2]
			//   [0,0], [0,1] = surface labeled and unlabeled;
			//   [1,0], [1,1] = belowground labeled and unlabeled.
	eroCcum,	// Cumulative C lost from SOM by erosion (g/m2)
	eroC,		// Monthly C loss from SOM by erosion (g/m2)
	depCcum,	// Cumulative C gain from deposition (g/m2)
	depC,		// Monthly C gain from deposition (g/m2)
	som1c[2],	// C in surface microbe pool and active SOM (g/m2).
	som1ci[4],	// C in surface microbe pool and active SOM (g/m2);
			//   was [NUMLAYERS][ISOS];
			//   [0,0], [0,1] = unlabeled, labeled C, surface pool;
			//   [1,0], [1,1] = unlabeled, labeled C, active SOM.
	som2c,		// C in slow pool SOM (g/m2).
	som2ci[2],	// Unlabeled, labeled C in slow pool SOM (g/m2).
	som3c,		// C in passive pool SOM (g/m2).
	som3ci[2],	// Unlabeled, labeled C in passive pool SOM (g/m2).
	somsc,		// Sum: unlabeled & labeled C from SOM1C, 2C, 3C (g/m2).
	somsci[2],	// Sum: unlabeled & labeled C from SOM1C, 2C, 3C (g/m2).
			//   [0] = unlabeled, [1] = labeled.
	somtc,		// Total soil C (g/m2).
	somtci[2],	// Total soil C (g/m2) by isotope.
			//   [0] = unlabeled, [1] = labeled.
	somtpc,		// Total soil organic C in profile = somsc + lhsomtc
	strcis[4],	// Litter structural C (g/m2); was [2][2];
			//   [0,0], [0,1] = unlabeled, labeled surface C;
			//   [1,0], [1,1] = unlabeled, labeled belowground C
	strlig[2],	// Lignin content of surface, soil structural residue.
	strucc[2],	// Surface, belowground litter structural C (g/m2).
	tomres[2],	// Total C in soil, belowground, & aboveground litter.
			//   [0], [1] = unlabeled, labeled surface C.
	totalc,		// Total C including source/sink (g/m2).
	totc,		// Minimum annual non-living C (g/m2).
    	lastOne;			// dummy - always last variable!
    // constuctor
    TSoilC () : TCenturyOutputSet (65)
	{ Clear ();
	  firstOne = lastOne = memCheckValue;	// for memory overwrite checks:
    	  AssignPointers ();
	};
    // functions
    void Clear ();
    bool IsMemoryOK ()
    	{ return (firstOne == memCheckValue && lastOne ==  memCheckValue); }

  private:
    void AssignPointers ();	// initialize pointers to variablse
};

//	------------------------------------------------------------
//	TCropGrassC
//	Output variables - C in Crop and grass systems
class TCropGrassC : public TCenturyOutputSet
{
  public:
    float
    	firstOne,			// dummy - always first variable!
    	accrst,		// Cumulative C in straw removed (g/m2).
    	agcacc,		// Growing season aboveground C production (g/m2/y).
	agcisa[2],	// Growing season aboveground C production (g/m2/y);
			//   [0] = unlabeled, [1] = labeled.
    	aglcis[2],	// Aboveground C (g/m2);
			//   [0] = unlabeled, [1] = labeled.
	aglcn,		// Aboveground live C/N.
    	aglivc,		// C in aboveground live biomass (g/m2).
	bgcacc,		// Growing season belowground C production (g/m2).
	bgcisa[2],	// Growing season belowground C production (g/m2);
			//   [0] = unlabeled, [1] = labeled.
	bglcis[2],	// Belowground live C (g/m2);
			//   [0] = unlabeled, [1] = labeled.
	bglcn,		// Belowground live C/N.
	bglivc,		// C in belowground live biomass (g/m2).
	cgracc,		// Cum. economic yield of grain & tuber prod. (g/m2).
	cgrain,		// Economic yield of C in grain & tubers (g/m2).
	cinput,		// Annual C inputs.
    	cisgra[2],	// C in grain (g/m2).
			//   [0] = unlabeled, [1] = labeled.
 	cprodc,		// Monthly total C production (g/m2/month).
	creta,		// Annual C returned due to grazing/fire (g/m2/year).
	crmvst,		// Monthly C removed in straw upon harvest (g/m2/month).
	crpval,		// Numerical representation of the current crop.
	harmth,		// Harvest flag: 0 = no harvest, 1 = harvest month.
	hi,		// Harvest index (CGRAIN/ AGLIVC)
	ptagc,		// Grow. season potential aboveground C prod. (g/m2/y).
	ptbgc,		// Grow. season potential belowground C prod. (g/m2/y).
	sdrema,		// Ann. C rem. from stand. dead upon graz./fire (g/m2).
	sdrmai[2],	// Ann. C rem. from stand. dead upon graz./fire (g/m2);
			//   [0] = unlabeled, [1] = labeled.
	shrema,		// Annual C removed from shoots upon graz./fire (g/m2).
	shrmai[2],	// Annual C removed from shoots upon graz./fire (g/m2);
			//   [0] = unlabeled, [1] = labeled.
	stdcis[2],	// C in standing dead material (g/m2);
			//   [0] = unlabeled, [1] = labeled.
	stdedc,		// C in standing dead material (g/m2).
   	lastOne;			// dummy - always last variable!
    // constuctor
    TCropGrassC () : TCenturyOutputSet (37)
	{ Clear ();
	  firstOne = lastOne = memCheckValue;	// for memory overwrite checks:
    	  AssignPointers ();
	};
    // functions
    void Clear ();
    bool IsMemoryOK ()
    	{ return (firstOne == memCheckValue && lastOne ==  memCheckValue); }

  private:
    void AssignPointers ();	// initialize pointers to variablse
};

//	------------------------------------------------------------
//	TForestC
//	Output variables - C in forest systems
class TForestC : public TCenturyOutputSet
{
  public:
    float
    	firstOne,			// dummy - always first variable!
	acrcis[2],	// Growing season C production in coarse root (g/m2/y).
			//   [0] = unlabeled, [1] = labeled.
	afbcis[2],	// Growing season C production in fine branch (g/m2/y).
			//   [0] = unlabeled, [1] = labeled.
	afrcis[2],	// Growing season C production in fine root (g/m2/y).
			//   [0] = unlabeled, [1] = labeled.
	alvcis[2],	// Growing season C production in leaf (g/m2/y).
			//   [0] = unlabeled, [1] = labeled.
	alwcis[2],	// Growing season C production in large wood (g/m2/y).
			//   [0] = unlabeled, [1] = labeled.
	cproda,		// Annual NPP in crop/grassland + forest C (g/m2/year).
	cprodf,		// Monthly forest C production (g/m2/month).
	crootc,		// C in coarse root (g/m2).
	crtacc,		// Growing season C production in coarse root (g/m2/y).
	crtcis[2],	// C in coarse root component (g/m2).
			//   [0] = unlabeled, [1] = labeled.
	fbracc,		// Growing season C production in fine branch (g/m2/y).
	fbrchc,		// C in fine branch component (g/m2).
	fbrcis[2],	// C in fine branch component (g/m2);
			//   [0] = unlabeled, [1] = labeled.
	fcacc,		// Growing season C production (g/m2/y).
	frootc,		// C in fine root (g/m2).
	frstc,		// Sum of C in live components (g/m2).
	frtacc,		// Growing season C production in fine root (g/m2).
	frtcis[2],	// C in fine root component (g/m2).
			//   [0] = unlabeled, [1] = labeled.
	fsysc,		// Total C (g/m2).
	rleavc,		// C in leaf component (g/m2).
	rlvacc,		// Growing season C production in leaf (g/m2/y).
	rlvcis[2],	// C in leaf component (g/m2);
			//   [0] = unlabeled, [1] = labeled.
	rlwacc,		// Growing season C production in large wood (g/m2/y).
	rlwcis[2],	// C in large wood component (g/m2);
			//   [0] = unlabeled, [1] = labeled.
	rlwodc,		// C in large wood component (g/m2).
	sumrsp,		//
	tcrem,		//
	// Note: w1/2/3lib are not used anywhere in Century, but were read
	//       from site file variables of the same name.
	//w1lig,	// Lignin fraction of dead fine wood.
	//w2lig,	// Lignin fraction of dead large wood.
	//w3lig,	// Lignin fraction of dead coarse roots.
	wd1cis[2],	// C in dead fine branch (g/m2);
			//   [0] = unlabeled, [1] = labeled.
	wd2cis[2],	// C in dead large wood (g/m2);
			//   [0] = unlabeled, [1] = labeled.
	wd3cis[2],	// C in dead coarse root (g/m2);
			//   [0] = unlabeled, [1] = labeled.
	wood1c,		// C in dead fine branch component (g/m2).
	wood2c,		// C in dead large wood) component (g/m2).
	wood3c,		// C in dead coarse roots) component (g/m2).
	woodc,		// Sum of C in dead wood components (g/m2).
    	lastOne;			// dummy - always last variable!
    // constuctor
    TForestC () : TCenturyOutputSet (47)
	{ Clear ();
	  firstOne = lastOne = memCheckValue;	// for memory overwrite checks:
    	  AssignPointers ();
	};
    // functions
    void Clear ();
    bool IsMemoryOK ()
    	{ return (firstOne == memCheckValue && lastOne ==  memCheckValue); }

  private:
    void AssignPointers ();	// initialize pointers to variablse
};

//	------------------------------------------------------------
//	TCO2
//	Output variables - CO2
class TCO2 : public TCenturyOutputSet
{
  public:
    float
    	firstOne,			// dummy - always first variable!
    	// Begin: CO2 loss due to microbial respiration
    	amt1c2,		// Annual surface loss from litter decomposition.
    	amt2c2,		// Annual soil loss from litter decomposition.
	as11c2,		// Cum. loss, decomposition of surface SOM1 to SOM2.
	as21c2,		// Cum. loss, decomposition of soil SOM1 to SOM2, SOM3.
	as2c2,		// Cum. loss, decomposition of SOM2 to soil SOM1, SOM3.
	as3c2,		// Cum. loss, decomposition of SOM3 to soil SOM1.
	ast1c2,		// Cum. loss, decomposition of surface struct. litter
			//   into SOM1 and SOM2.
	ast2c2,		// Cum. loss, decomposition of soil structural litter
			//   into SOM1 and SOM2.
    	// End: CO2 loss due to microbial respiration
    	// Begin: CO2 effect due to doubling from 350 to 750 ppm:
	co2cce[12],	// was [2][2][NUMELEM]- C:E ratios
			//   Crop/Grass effects:
			//   [0,0,0] = minimum C/N
			//   [0,0,1] = minimum C/P
			//   [0,0,2] = minimum C/S
			//   [0,1,0] = maximum C/N
			//   [0,1,1] = maximum C/P
			//   [0,1,2] = maximum C/S
			//   Forest effects:
			//   [1,0,0] = minimum C/N
			//   [1,0,1] = minimum C/P
			//   [1,0,2] = minimum C/S
			//   [1,1,0] = maximum C/N
			//   [1,1,1] = maximum C/P
			//   [1,1,2] = maximum C/S
	co2cpr[2],	// production; [0] = crop/grass, [1] = forest.
	co2crs[2],	// root-shoot ratio; [0] = crop/grass, [1] = forest.
	co2ctr[2],	// PET rate; [0] = crop/grass, [1] = forest.
    	// End: effect of atm. CO2 doubling from 350 to 750 ppm
	mt1c2[2],	// Cum. microbial CO2 respiration, surface litter;
			//   [0] = unlabeled, [1] = labeled.
	mt2c2[2],	// Cum. microbial CO2 respiration, soil;
			//   [0] = unlabeled, [1] = labeled.
	resp[2],	// Annual CO2 respiration from decomposition (g/m2);
			//   [0] = unlabeled, [1] = labeled.
	s11c2[2],	// Cum. microbial CO2 respiration, surf. SOM1 to SOM2;
			//   [0] = unlabeled, [1] = labeled.
	s21c2[2],	// Cum. microbial CO2 respiration, soil SOM1 to 2 & 3;
			//   [0] = unlabeled, [1] = labeled.
	s2c2[2],	// Cum. microbial CO2 respiration, SOM2 to soil 1 & 3;
			//   [0] = unlabeled, [1] = labeled.
	s3c2[2],	// Cum. microbial CO2 respiration, SOM3 to soil SOM1;
			//   [0] = unlabeled, [1] = labeled.
	st1c2[2],	// Cum. microbial CO2 respiration,
			//   surface structural litter into SOM1 and SOM2;
			//   [0] = unlabeled, [1] = labeled.
	st2c2[2],	// Cum. microbial CO2 respiration,
			//   soil structural litter into SOM1 and SOM2;
			//   [0] = unlabeled, [1] = labeled.
    	lastOne;			// dummy - always last variable!
    // constuctor
    TCO2 () : TCenturyOutputSet (44)
	{ Clear ();
	  firstOne = lastOne = memCheckValue;	// for memory overwrite checks:
    	  AssignPointers ();
	};
    // functions
    void Clear ();
    bool IsMemoryOK ()
    	{ return (firstOne == memCheckValue && lastOne ==  memCheckValue); }

  private:
    void AssignPointers ();	// initialize pointers to variablse
};

//	------------------------------------------------------------
//	TNPS
//	Output variables - arrays for Nitrogen, Phosphorus, and Sulphur
//	For all 1-D arrays, [0] = N, [1] = P, [2] = S.
//	For 2-D arrays, the 2nd dim. is described with the variable.
class TNPS : public TCenturyOutputSet
{
  public:
    float
    	firstOne,			// dummy - always first variable!
	elimit,		// The limiting element; 1 if N, 2 if P, 3 if S.
    			//--- Nitrogen
	nfix,		// Monthly symbiotic N fixation (g/m2/month).
	nfixac,		// Cumulative symbiotic N fixation (g/m2/year).
			//   DayCent: monthly cumulative
	rnpml1,		// Mineral N/P used to control soil N fixation.
	snfxac[2],	// Annual symbiotic N fixation.
			//   [0] = Crop/Grass, [1] = Forest.
	tcnpro,		// Total C/N for production.
	volex,		// Volatilization loss after uptake by plants (g/m2).
	volexa,		// Cum. volatilization after uptake by plants (g/m2).
	volgm,		// Volatil. loss due to gross mineralization (g/m2).
	volgma,		// Cum. volatil. due to gross mineralization (g/m2).
	volpl,		// Volatilization from plants during harvest (g/m2).
	volpla,		// Cum. volatil. from plants during harvest (g/m2).
	wdfx,		// Annual atm. + symbio. N fixation (g/m2/y).
	wdfxa,		// Annual N fixation in atmosphere (g/m2/y).
	wdfxaa,		// Annual atmospheric N input (g/m2/y).
	wdfxas,		// Annual non-symbiotic soil N fixation input (g/m2/y).
	wdfxma,		// Monthly N fixation in atmosphere (g/m2).
	wdfxms,		// Monthly non-symbiotic soil N fixation (g/m2).
	wdfxs,		// Annual non-symbiotic soil N fixation (g/m2).
    			//--- Phosphorus
	occlud,		// Occluded P (g/m2).
	plabil,		// Cumulative labile phosphate in all layers.
    			//--- Sulphur
	satmac,		// Cumulative atmospheric S deposition (g/m2).
	sirrac,		// Cumulative irrigation S inputs (g S / m2).
    			//--- NPS arrays
    	aglive[3],	// Amt. in aboveground live biomass (g/m2).
    	aminrl[3],	// Sum of mineral in layer 1 before uptake by plants.
	bglive[3],	// Amt. in belowground live biomass (g/m2).
	croote[3],	// Forest: amount in coarse root component (g/m2).
	crpstg[3],	// Crop/Grass: Retranslocation storage pool amt. (g/m2).
	egracc[3],	// Cumulative amt. in grain + tuber production (g/m2).
	egrain[3],	// Economic yield in grain + tubers (g/m2).
	eprodc[3],	// Crop/Grass: Actual monthly uptake (g/m2/month).
	eprodf[3],	// Forest: Actual monthly uptake (g/m2/month).
	ereta[3],	// Annual amt. returned to system during grazing and
			//   fire (g/m2/year).
	ermvst[3],	// Amount removed as straw during harvest (g/m2/month).
	esrsnk[3],	// Amount in source/sink (g/m2).
	eupacc[3],	// Growing season uptake by plants (g/m2).
	eupaga[3],	// Aboveground growing season uptake by plants (g/m2).
	eupbga[3],	// Belowground growing season uptake by plants (g/m2).
	eupprt[15],	// Forest: Growing season uptake (g/m2); was [5][3];
			//   [0][] = leaf, [1][] = fine roots,
			//   [2][] = fine branches, [3][] = large wood,
			//   [4][] = coarse roots.
	fbrche[3],	// Forest: Amount in fine branch component (g/m2).
	fertot[3],	// Cumulative amount in fertilizer.
	forstg[3],	// Forest: Retranslocation storage pool.
	froote[3],	// Forest: Amount in fine root component (g/m2).
	frste[3],	// Forest: Sum in live components  (g/m2).
	fsyse[3],	// Forest: Total in SOM, trees, dead wood, litter.
	gromin[3],	// Gross mineralization.
	lhzeac[3],	// Cumulative input to 0-20 cm layer from the
			//   lower horizon pools due to soil erosion (g/m2).
	metabe[6],	// Metabolic E in litter (g/m2);
			//   was [NUMLAYERS][NUMELEM];
			//   [0][] = aboveground, [1][] = belowground litter.
	metmnr[6],	// Net mineralization for metabolic litter;
			//   was [NUMLAYERS][NUMELEM];
			//   [0][] = aboveground, [1][] = belowground litter.
	minerl[30],	// Mineralized content for each soil layer (g/m2).;
			//   was [MAXLYR][3]; [][I] where I = N, P, S
 			//    Last layer = drainage pools
	parent[3],	// Parent material amount (g/m2).
	rleave[3],	// Forest: Amount in leaf component (g/m2).
	rlwode[3],	// Forest: Amount in large wood component (g/m2).
	s1mnr[6],	// Net mineralization for pools;
			//   was [NUMLAYERS][NUMELEM]:
			//   [0][] = surface microbe pool (g/m2),
			//   [1][] = active SOM pool (g/m2).
	s2mnr[3],	// Net mineralization for slow pool (g/m2).
	s3mnr[3],	// Net mineralization for passive pool (g/m2).
	sdrmae[3],	// Annual amt. removed from standing dead due to
			//   grazing and fire (g/m2).
	secndy[3],	// Secondary amount (g/m2).
	shrmae[3],	// Annual amt. removed from shoots due to
			//   grazing and fire (g/m2).
	soilnm[3],	// Annual net mineralization in soil (g/m2).
	som1e[6],	// Amount in surface microbe & active SOM; was [2][3];
			//   [0][] = surface microbe pool (g/m2),
			//   [1][] = active SOM pool (g/m2).
	som2e[3],	// Amount in slow pool soil organic matter (g/m2).
	som3e[3],	// Amount in passive pool soil organic matter (g/m2).
	somse[3],	// Sum of SOM1E, SOM2E, and SOM3E (g/m2).
	somte[3],	// Sum of NPS in SOM including belowground structural
			//   and metabolic (g/m2/mo).
	stdede[3],	// Amount in standing dead (g/m2).
	strmnr[6],	// Net mineralization for structural litter;
			//   was [NUMLAYERS][NUMELEM]
			//   [0][] = aboveground, [1][] = belowground.
	struce[6],	// Amount in litter structural pool (g/m2); was [2][3];
			//   [0][] = aboveground, [1][] = belowground.
	sumnrs[3],	// Annual net mineralization from all compartments
			//   except structural and wood (g/m2/y).
	tcerat[3],	// Total C/E in SOM including belowground structural
			//   and metabolic.
	terem[3],	// Forest: Total lost in tree removal events (g/m2).
	tminrl[3],	// Total mineralized amount in soil (g/m2).
	tnetmn[3],	// Annual net mineral. from all compartments (g/m2/y).
	totale[3],	// Total amount including source/sink.
	w1mnr[3],	// Forest: Amount mineral. from dead fine branch (g/m2).
	w2mnr[3],	// Forest: Amount mineral. from dead large wood (g/m2).
	w3mnr[3],	// Forest: Amount mineral. from dead coarse root (g/m2).
	wood1e[3],	// Forest: Amount in dead fine branch (g/m2).
	wood2e[3],	// Forest: Amount in dead large wood (g/m2).
	wood3e[3],	// Forest: Amount in dead coarse roots (g/m2).
	woode[3],	// Forest: Sum in wood components (g/m2).
    	lastOne;			// dummy - always last variable!
    // constuctor
    TNPS () : TCenturyOutputSet (255)
	{ Clear ();
	  firstOne = lastOne = memCheckValue;	// for memory overwrite checks:
    	  AssignPointers ();
	};
    // functions
    void Clear ();
    bool IsMemoryOK ()
    	{ return (firstOne == memCheckValue && lastOne ==  memCheckValue); }

  private:
    void AssignPointers ();	// initialize pointers to variablse
};

#endif // INC_outputvars_h
