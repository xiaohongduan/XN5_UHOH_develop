// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TSiteEnv.cpp
//	Class:	  TSiteEnvironment
//
//	Description:
//	Site geographic and environmental data and functions.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec00
// ----------------------------------------------------------------------------
//	History:
//	See header file.
// ----------------------------------------------------------------------------
//	Copyright 2000 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TSiteEnv.h"
#include "TCenturyMath.h"
#include "AssertEx.h"
#include <algorithm>

//	SetLatLong
//	Save the latitude and longitude.
void TSiteEnvironment::SetLatLong (
	float const useLatitude,
	float const useLongitude)
{
	// save the latitude
	if ( useLatitude >= 0.0f )		// northern hemisphere
		latitude = std::min (90.0f, useLatitude);
	else					// southern hemisphere
		latitude = std::max (-90.0f, useLatitude);

	// save the longitude
	if ( useLongitude >= -180.0f && useLongitude <= 180.0f )
		longitude = useLongitude;
	else
	{
		longitude = std::fmod (useLongitude, 360.0f);
		if ( longitude > 180.0f )
			longitude = longitude - 360.0f;
		else if ( longitude < -180.0f )
			longitude += 360.0f;
	}

    //--- day length initialization (from Cindy Keough, Aug00)
    // The change made above, to how hrsinc is set, had the potential to leave
    // hrsinc uninitialized if the site we are simulating is in the southern
    // hemisphere.  To fix this I changed the initialization in prelim.f for
    // dayhrs to consider the latitude of the site and added the
    // initialization for hrsinc.

	// initialize the daylight hours
	if ( latitude >= 0.0f )			// northern hemisphere
	{
    		dayHours = 0.0f;
    		dayIncreasing = true;
	}
	else					// southern hemisphere
	{
    		dayHours = 24.0f;
    		dayIncreasing = false;
	}
}

//	GetDayLength
//	Calculate the day length based upon time of year and latitude.
float TSiteEnvironment::GetDayLength (
	short const month)	// month of year (range: 1-12)
{
	if ( month >= (short)1 && month <= (short)12 )
	{
		float newDayHours = CalcDayLength (month);
		if ( newDayHours < dayHours )		// decreasing?
			dayIncreasing = false;
		else if ( newDayHours > dayHours )	// increasing?
			dayIncreasing = true;
		dayHours = newDayHours;			// save hours
	}
	return dayHours;
}

//	CalcDayLength
//	Returns the number of fractional hours in the day given the
//	month and the latitude.
//	Author: Melannie Hartman did the original.
//	Tom Hilinski optimized constants, and pow and tan usage.
float TSiteEnvironment::CalcDayLength (
	short const month)	// month of year (range: 1-12)
{
	Assert (month >= 1);
	Assert (month <= 12);

	double adelt, ahou;
	double tanRadLat;		// tan of latitude in radians
	double temp1, temp2, temp3;
	// Julian day numbers for the 1st of each month:
	const double julianDay[12] =
	  {
		1.0, 32.0, 61.0, 92.0, 122.0, 153.0,
		183.0, 214.0, 245.0, 275.0, 306.0, 337.0
	  };
	const double recip365 = 1.0 / 365.0;
	const double recip180 = 1.0 / 180.0;
	const double recipPI = 1.0 / M_PI;

	float theLatitude = std::fabs (latitude);

	// NOTE: JDAY isn't exact, but should be close enough.
	// Convert from degrees to radians
	tanRadLat = std::tan ( (theLatitude * M_PI * recip180) );
	temp1 = 2.0 * M_PI * (julianDay[month - 1] - 77.0) * recip365;
	adelt = 0.4014 * std::sin (temp1);
	// temp1 = 1.0 - std::pow ((-tan (rlat) * (adelt)), 2.0);
	// replaced by the following two lines:
	temp3 = -tanRadLat * adelt;
	temp1 = std::sqrt ( std::max ( 1.0 - temp3 * temp3, 0.0 ) );
	temp2 = -tanRadLat * std::tan (adelt);
	ahou = std::atan2 (temp1, temp2);
	return static_cast<float>(ahou * recipPI * 24.0);
}

//--- end of file ---
