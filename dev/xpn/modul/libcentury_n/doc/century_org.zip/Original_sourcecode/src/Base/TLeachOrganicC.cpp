// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TLeachOrganicC.cpp
//	Class:	  TLeachOrganicC
//
//	Description:
//	Class for submodel of leaching of organic C from the simulation layer.
//	Members were extracted from class TCenturyBase.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, April 2004
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TLeachOrganicC.h"
#include "TSimTime.h"
#include "centtypes.h"
#include "outputvars.h"
#include "arraydefs.h"

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	Leach
//	Leaching of organic C from the simulation layer.
//	Returns the amount of C leached.
//	Notes:
//	Considers only effects within the simulation layer.
//	This only occurs when the water flow out of the simulation layer > 0.
//	Use the same C/N, C/P, and C/S ratios as for the flow to SOM3.
//	Removed organic leaching sink and replaced it with the
//	stream flows. -rm 2/92
//	Author: 2/92 -rm
float TLeachOrganicC::Leach (
	float const microbeC,		// C from microbial pool
	float const h2oFromLayer)	// water flow from sim. layer
{
    if (h2oFromLayer > 1.0e-4f && microbeC > 1.0e-6f)	// anything to leach?
    {
	amtLeachedC = microbeC * textureFactor *
	    std::min (
		1.0f - (maxLeachWater - h2oFromLayer) / maxLeachWater,
		1.0f );
	if ( amtLeachedC < 1.0e-6f )
	{
		amtLeachedC = 0.0f;
		return 0.0f;
	}

	dataCleared = false;

	// Partition and schedule C flows by isotope
	ScheduleCFlow ( simTime.time, amtLeachedC,
			som1ci_ref (SOIL, LABELD) / soilC.som1c[SOIL], 1.0f,
			&som1ci_ref (SOIL, UNLABL), &amtLeachedCI[0],
			&som1ci_ref (SOIL, LABELD), &amtLeachedCI[1] );

	// Leach N, P, and S associated with organic C.
	float const ratioC = amtLeachedC / soilC.som1c[SOIL];
	float* pStream = &wt.stream[5];
	float* pLeachedAmt = amtLeachedE;
	for ( short element = 0;
	      element < numE;
	      ++element, ++pLeachedAmt, ++pStream )
	{
	    // use the C:N ratio for som1 for organic leaching -rm 3/92
	    *pLeachedAmt = som1e_ref (SOIL, element) * ratioC;
	    SCHEDULE_FLOW ( flows, &som1e_ref(SOIL, element), pStream,
				simTime.time, *pLeachedAmt );
	}
    }
    else
    {
	ClearAmtLeached ();
    }
    return amtLeachedC;
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

void TLeachOrganicC::Copy (				// Copy to this
	TLeachOrganicC const & object)
{
	textureFactor = object.textureFactor;
	amtLeachedC = object.amtLeachedC;
	amtLeachedCI[0] = object.amtLeachedCI[0];
	amtLeachedCI[1] = object.amtLeachedCI[1];
	float* pTo = amtLeachedE;
	float const * pFrom = object.amtLeachedE;
	for ( short element = 0;
	      element < numE;
	      ++element, ++pTo, ++pFrom )
	{
		*pTo = *pFrom;
	}
	dataCleared = object.dataCleared;
}

void TLeachOrganicC::ClearAmtLeached ()
{
	if ( !dataCleared )
	{
		textureFactor = 1.0f;
		amtLeachedC = 0.0f;
		amtLeachedCI[0] = 0.0f;
		amtLeachedCI[1] = 0.0f;
		float* pLeachedAmt = amtLeachedE;
		for ( short element = 0;
		      element < numE;
		      ++element, ++pLeachedAmt )
		{
			*pLeachedAmt = 0.0f;
		}
		dataCleared = true;
	}
}

//--- end of definitions for TLeachOrganicC ---
