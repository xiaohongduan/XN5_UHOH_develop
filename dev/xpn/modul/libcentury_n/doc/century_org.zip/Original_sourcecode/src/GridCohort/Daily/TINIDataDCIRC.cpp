// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  TINIDataDCIRC.cpp
//	Class:	  TINIDataDCIRC
//
//	Description:
//	Class for managing INI data for the DayCentIRC model.
//
//	Responsibilities:
//	* Provides public interface to access to the INI data.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Oct03
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TINIDataDCIRC.h"
#include "GCFINIUtil.h"
#include "DayCentIRCTypes.h"
#include "stringutil.h"
#include "fnutil.h"
using namespace nrel::dcirc;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

void TINIDataDCIRC::SetLogFile (		// Set the log file name
	std::string const & fileName)		//   file name + path
{
	std::string fileNameNative ( fileName );
	::TEH::ToNativePath (fileNameNative);
	Record record;						// make record
	record.first = simulationKeys[indexLogFileName];	// key
	record.second.values.Add ( fileNameNative );
	record.second.comment = "# Log file name";
	SectionData & sectionData =	// find section
		data[ sectionNames[Simulation] ];
	sectionData.records[ record.first ] = record.second;	// add
}

void TINIDataDCIRC::SetOutputVariablesConfig (
	  TOutputVarConfig const & useConfig)
{
	Record record;						// make record
	record.first = simulationKeys[indexOutputVarsConfig];	// key
	if ( FromOutputVariablesConfig (useConfig, record.second.values) )
	{
		// error: set to default values
		TOutputVarConfig defaultConfig;
		FromOutputVariablesConfig (defaultConfig, record.second.values);
	}
	record.second.comment =
		"# Output variables configuration (scope, group by)\n"
		"# scope    = cohort, cell, grid\n"
		"# group by = none, biome, landscape";
	SectionData & sectionData =	// find section
		data[ sectionNames[Simulation] ];
	sectionData.records[ record.first ] = record.second;	// add
}

void TINIDataDCIRC::SetCohortAgConfig (		// Set aggreg. algorithm
	::TimeRange const & catsi,		//   cohort ag. time interval
	TTime const minCohortAgeToCombine,	//   min. cohort age to combine
	float const cohortVarFraction)		//   variation range of cohorts
{
	::nrel::gcf::TINIDataGCF::SetCohortAgConfig (minCohortAgeToCombine);

	SectionData & sectionData =				// find section
		data[ sectionNames[CohortAggregation] ];
	Record record;						// make record
	record.first = cohortAggregationKeys[indexCohortVarFraction];	// key
	::nrel::ini::AddValueToRecord (record, cohortVarFraction);
	record.second.comment =
		"# Fraction variation allowed in comparison of cohorts (+/-)";
	sectionData.records[ record.first ] = record.second;	// add

	record.first = cohortAggregationKeys[indexCATSI];	// key
	record.second.values.Clear();
	::nrel::ini::AddValuesToRecord (record,
		catsi.start, catsi.end, catsi.interval);
	record.second.comment =
		"# Cohort Aggregation timestep interval "
		"(start, end, interval) "
		"(unit: simulation months)";
	sectionData.records[ record.first ] = record.second;	// add
}

void TINIDataDCIRC::SetDisturbanceConfig (	// Set disturbance algorithm
	TFileNameIDMap const & disturbFiles)	//  disturbance file names
{
	SectionData & sectionData =				// find section
	    data[ sectionNames[ CohortDisturbance ] ];
	// loop through vector, building a key name, a record,
	// then adding to the TSectionMap.records
	TFileNameIDMap::const_iterator pDisturbFiles =
		disturbFiles.begin();
	while ( pDisturbFiles != disturbFiles.end() )
	{
	    // form of key:
	    // DisturbFileNameCell0=~/sim/disturbances_cell0.txt
	    Record record;					// make record
	    record.first =
	      cohortDisturbanceKeys[indexDisturbFileNameCell];	  // key
	    record.first += ::ToString ( pDisturbFiles->first );  // ID
	    std::string fileNameNative ( pDisturbFiles->second );
	    ::TEH::ToNativePath (fileNameNative);
	    record.second.values.Add ( fileNameNative );	  // file name
	    sectionData.records[ record.first ] = record.second;  // add
	    ++pDisturbFiles;
	}
}

void TINIDataDCIRC::SetDisturbanceConfig (	// Set disturbance algorithm
	TFileNameIDMap const & disturbFiles, //  disturbance file names
	float const minAreaFracDisturb,		//   min. area fraction disturb.
	TTime const minCohortAgeToDisturb)	//   min. cohort age to disturb
{
	::nrel::gcf::TINIDataGCF::SetDisturbanceConfig (
		minAreaFracDisturb, minCohortAgeToDisturb );
	SetDisturbanceConfig (disturbFiles);
}

void TINIDataDCIRC::SetWeatherINIFile (			// Weather INI file
	std::string const & weatherINIFile) 		//   file name
{
	std::string fileNameNative ( weatherINIFile );
	::TEH::ToNativePath (fileNameNative);
	Record record;						// make records
	record.first = simulationKeys[indexWeather];		// key 0
	record.second.values.Add ( fileNameNative );
	record.second.comment = "# Weather INI file name and path";
	SectionData & sectionData =				// find section
		data[ sectionNames[Simulation] ];
	sectionData.records[ record.first ] = record.second;	// add
}

void TINIDataDCIRC::SetSoilSource (			// Soil Source
	TSoilSource const source,			//   source type
	std::string const & fileName)			//   file name
{
	Record record;						// make records
	record.first = simulationKeys[indexSoil];		// key 0
	record.second.values.Add ( GetSoilSourceStr(source) );
	if ( source == ::nrel::gcf::SoilSrc_File )
	{
		std::string fileNameNative ( fileName );
		::TEH::ToNativePath (fileNameNative);
		record.second.values.Add (fileNameNative);
	}

	SectionData & sectionData =				// find section
		data[ sectionNames[Simulation] ];
	record.second.comment =
		"# Soil source: type = site or file\n"
		"# If site, uses soil in site parameters.\n"
		"# If file, format is followed by a file name.";
	sectionData.records[ record.first ] = record.second;	// add
}

//inline
::TimeRange const TINIDataDCIRC::GetCATSI () const
{
	Values const & values =
		::nrel::ini::GetValues (
		  data, sectionNames[CohortAggregation],
		  cohortAggregationKeys[indexCATSI] );
	if ( values.Size() >= 3 )
		return ::nrel::gcf::ToTiming (values);
	else
		return ::TimeRange ();
}

TFileNameIDMap const TINIDataDCIRC::GetDisturbFileNameMap () const
{
	TFileNameIDMap fnMap;		// return value

	SectionMap const & records = ::nrel::ini::GetRecords (
		data, sectionNames[CohortDisturbance]);
	SectionMapConstIter i = records.begin();
	std::string const & findStr =
		cohortDisturbanceKeys[indexDisturbFileNameCell];
	while ( i != records.end() )
	{
	    i = std::find_if ( i, records.end(),
	    		       ::nrel::ini::KeyStartsWith(findStr) );
	    if ( i != records.end() )
	    {
		TIDNumber const id =
		  ::StrToNLast<TIDNumber> (
			i->first.data(),
			i->first.data() + i->first.size() );
		fnMap[id] = i->second.values[0];
		++i;
	    }
	}
	return fnMap;
}

// inline
TSoilSource TINIDataDCIRC::GetSoilSource () const
{
	Values const & values =
		::nrel::ini::GetValues (
			data, sectionNames[Simulation],
			simulationKeys[indexSoil] );
	if ( values.IsEmpty() )
		return ::nrel::gcf::SoilSrc_Unknown;
	else
		return ::nrel::gcf::ToSoilSource (values);
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

bool TINIDataDCIRC::AddKeyNoValue (	// Add empty key to section
	SectionName & sectionName,	//   section to add to
	Key & key)			//   key to add to section
{
	bool failed = false;				// return value
	Record record;
	record.first = key;
	if ( AddRecord ( sectionName, record ) )
	{
		error = Error_AddRecFailed;
		failed = true;
	}
	return failed;
}

void TINIDataDCIRC::StoreSectionAndKeyNames ()	// Add section names to array
{
	indexLogFileName = simulationKeys.size();
	simulationKeys.push_back ("LogFileName");	// data: string
	indexOutputVarsConfig = simulationKeys.size();
	simulationKeys.push_back ("OutputVariables");	// data: string
	indexWeather = simulationKeys.size();
	simulationKeys.push_back ("WeatherINI");	// string: weather INI file name
	indexSoil = simulationKeys.size();
	simulationKeys.push_back ("SoilSource");	// string: "site", or "file" w/name

	// cohort aggregation timestep interval
	//   data: class TimeRange
	cohortAggregationKeys.push_back ("CATSI");
	indexCATSI = cohortAggregationKeys.size() - 1;
	// variation range (+/-) of cohorts
	// data: floating point
	cohortAggregationKeys.push_back ("CohortVariationFraction");
	indexCohortVarFraction = cohortAggregationKeys.size() - 1;

	// disturbance file: data: string
	// prefix; suffix = cell ID
	cohortDisturbanceKeys.push_back ("DisturbFileNameCell");
	indexDisturbFileNameCell = cohortDisturbanceKeys.size() - 1;
}

void TINIDataDCIRC::BuildINIData ()			// Fill in iniData
{
	AddKeyNoValue (
		sectionNames[Simulation],
		*(simulationKeys.end() - 1) );
	AddKeyNoValue (
		sectionNames[CohortAggregation],
		*(cohortAggregationKeys.end() - 2) );
	AddKeyNoValue (
		sectionNames[CohortAggregation],
		*(cohortAggregationKeys.end() - 1) );
//	std::string keyDisturbance = *(cohortDisturbanceKeys.end() - 1);
//	AppendCellNumber ( keyDisturbance, 0 );
//	AddKeyNoValue (
//		sectionNames[CohortDisturbance],
//		keyDisturbance );
}


//--- end of file ---

