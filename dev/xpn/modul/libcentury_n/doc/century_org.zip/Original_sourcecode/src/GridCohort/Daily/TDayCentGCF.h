#ifndef INC_nrel_dcirc_TDayCentGCF_h
#define INC_nrel_dcirc_TDayCentGCF_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TDayCentGCF.h
//	Class:	  TDayCentGCF
//
//	Description:
//	DayCent model derived class for thr IRC grid-cohort framework.
//	Responsibilities:
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, Sept 2002
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TDayCent.h"
#include "TFireInfo.h"

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class TDayCentModel;

class TDayCentGCF
	: public TDayCent
{
  public:
	//--- constructors and destructor
	TDayCentGCF (
	  TDailyCenturyConfig const & config,	// configuration
	  TDebugInfo const & useDebugInfo,	// debug flags
	  TDayCentModel & useOwner)		// owner : TDayCentModel
	  : TDayCent (config, useDebugInfo),
	    owner (useOwner)
	  {
	    Assert (&owner != 0);
	  }
	virtual	~TDayCentGCF ()
	  {
	  }
	TDayCentGCF (				// copy	constructor
	  TDayCentGCF const & object,		//   source object
	  TDayCentModel & useOwner,		//   owner = TDayCentModel
	  TMgmtPtr useMgmt)			// use new mgmt in clone
	  : TDayCent ( object, useMgmt ),
	    owner (useOwner)
	  {
	  }
	virtual	TDayCentGCF * const Clone (	// Clone this
	  TDayCentModel & useOwner,		// owner = TDayCentModel
	  TMgmtPtr useMgmt			// use new mgmt in clone
	  ) const
	  { return new TDayCentGCF (*this, useOwner, useMgmt); }

	//--- functions
	TDayCentModel & GetOwner ()
	  { return owner; }

  protected:

	//--- DayCent functions replaced
	virtual	void InitMonthlyCycle ();

  private:
	//--- data
	TDayCentModel & owner;			// owner

	//--- functions
};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_TDayCentGCF_h



