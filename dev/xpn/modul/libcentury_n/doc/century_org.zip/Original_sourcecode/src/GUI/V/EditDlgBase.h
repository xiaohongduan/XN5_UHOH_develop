#ifndef INC__EditDlgBase_h
#define INC__EditDlgBase_h

// ----------------------------------------------------------------------------
//	Developed with funding from the National Science Foundation
//	grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  EditDlgBase.h
//	Class:	  EditDlgBase
//
//	Description:
//	Base class for GUI editing dialogs.
//
//	Responsibilities:
//	* Defines the minimum interface for the editor.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Aug04
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TModalDlg.h"

class EditDlgBase
	 : public TModalDlg
{
  public:
	//---- types

	//---- constructors and destructor
	virtual ~EditDlgBase ()
	  {
	  }

	//---- operator overloads

	//---- functions
	bool ReadOnly () const			// True if data is read-only
	  { return readOnly; }

	//---- functions: Queries

  protected:
	//---- constants

	//---- data
	bool readOnly;				// true if no changes allowed

	//---- constructors and destructor
	EditDlgBase (				// default constructor
	  vApp * const useParent,		// pointer to application
	  char const * const title)		// dialog title
	  : TModalDlg (useParent, title),
	    readOnly (false)
	  {
	  }

	//---- functions
	virtual void LoadDlg () = 0;		// Load the dialog
	virtual void ClearDialog () = 0;	// Clears the entire dialog
	virtual bool ConfirmReplaceData () = 0;	// User to confirm clear dialog
	virtual int  Event_OK () = 0;		// Close dialog; returns cmdID
	virtual void Event_Cancel () = 0;	// Cancel: restore to start
	virtual void Event_Open () = 0;		// Open a new edit object
	virtual void Event_New () = 0;		// Create a new edit object
	virtual void Event_Save () = 0;		// Save the edit object
	virtual void Event_SaveAs () = 0;	// Save to a different file
	virtual void Event_ReadOnly () = 0;	// Read-only change status
	virtual void Event_Help () = 0;		// Display Help information
	virtual void Event_About () = 0;	// Display About information

  private:
	//---- constants

	//---- data

	//---- functions

	//---- functions: should never be called!
	EditDlgBase (
	  EditDlgBase const & object)  // copy constructor
	  : TModalDlg (object),
	    readOnly (object.readOnly)
	  {
	  }
};


#endif // INC_EditDlgBase_h
