File:		ReadMe.txt
Directory:	Ecosystem/Century5/src/Common

This directory contains source code files that are common to all
versions of the Century model, and are not a part of any model-specific
class.

--- end of file ---