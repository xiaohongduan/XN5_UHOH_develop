// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  pschem.cpp
//	Class:	  TCentury
//	Function: PSDecompChemistry
//
//	Description:
//	Calculates the P and S chemistry for  decomposition flows.
// ----------------------------------------------------------------------------
//	History:
//	6/91	McKeown
//	These calculations were removed from
//	the DECOMP subroutine, and slightly modified to include the
//	calculation for the fraction of mineral P in solution.  Also
//	removed the flow from secondary to parent material.
//	Dec01	Tom Hilinski
//	* Clarified the roles of parent and secondary pools. These represent
//	  the entire soil layer, so transfers to/from mineral E pools must
//	  be proportional to layer thickness. For now, assume the distribution
//	  of the parent and secondary pools is uniform over soil depth.
//	* Mineral E pools are now part of the layer soil structure.
// ----------------------------------------------------------------------------
//	WARNING!
//	Do not alter the "soil" variable layered structure
//	until the flows have been resolved! The addresses
//	of the mineralE's may become invalid.
// ----------------------------------------------------------------------------

#include "TCentury.h"

void TCentury::PSDecompChemistry (
	float const dtm)	// time step (years)
{
    Assert (site.nelem > 1);
    for (short element = P; element < site.nelem; ++element)
    {
	//--- Determine the fraction of mineral P in solution
	float const fractionInSolution =
		( element == P ?  FractionMinPInSolution(): 1.0f );

	//--- decomposition factor effect scaled for the time step
	float const decompFactor = wt.defac * dtm;

	//--- array of layer thickness fractions
	std::vector<float> thicknessFraction (0.0f, soil->Thickness().size() );
	TSoilPool::TFloatArray::const_iterator thickness =
		soil->Thickness().begin();
	float const soilDepthRecip = 1.0 / soil->SoilDepth();
	for ( std::vector<float>::iterator fraction = thicknessFraction.begin();
	      thickness != soil->Thickness().end();
	      ++fraction, ++thickness )
	{
		*fraction = *thickness * soilDepthRecip;
	}

	//--- Flow from parent material to mineral compartment.
	/*
	float amount =
		fixed.pparmn[element] * nps.parent[element] * decompFactor;
	flows->Schedule (&nps.parent[element], &minerl_ref (SRFC, element),
			st->time, amount);
	*/
	// Transfer from parent an amount proportional to the layer thickness.
	TSoilPool::TFloatArray::iterator mineralE;
	switch (element)
	{
	  case N: mineralE = soil->MineralN().Values().begin();	break;
	  case P: mineralE = soil->MineralP().Values().begin();	break;
	  case S: mineralE = soil->MineralS().Values().begin();	break;
	}
	for ( std::vector<float>::iterator fraction = thicknessFraction.begin();
	      fraction != thicknessFraction.end();
	      ++fraction, ++mineralE )
	{
	    float const amountFromSource =
		nps.parent[element] * (*fraction);
	    float const amountToFlow =
		fixed.pparmn[element] * amountFromSource * decompFactor;
	    flows->Schedule ( &nps.parent[element], &(*mineralE),
				st->time, amountToFlow );
	}

	//--- Flow from secondary to mineral compartment.
	// Sorbed P is in dynamic equilibrium with strongly sorbed P.
	/*
	amount = fixed.psecmn[element] * nps.secndy[element] * decompFactor;
	flows->Schedule (&nps.secndy[element], &minerl_ref (SRFC, element),
			st->time, amount);
	*/
	switch (element)
	{
	  case N: mineralE = soil->MineralN().Values().begin();	break;
	  case P: mineralE = soil->MineralP().Values().begin();	break;
	  case S: mineralE = soil->MineralS().Values().begin();	break;
	}
	for ( std::vector<float>::iterator fraction = thicknessFraction.begin();
	      fraction != thicknessFraction.end();
	      ++fraction, ++mineralE )
	{
	    float const amountFromSource = nps.secndy[element] * (*fraction);
	    float const amountToFlow =
		fixed.psecmn[element] * amountFromSource * decompFactor;
	    flows->Schedule (&nps.secndy[element], &(*mineralE),
				st->time, amountToFlow);
	}

	//--- Flow from mineral to secondary
	switch (element)
	{
	  case N: mineralE = soil->MineralN().Values().begin();	break;
	  case P: mineralE = soil->MineralP().Values().begin();	break;
	  case S: mineralE = soil->MineralS().Values().begin();	break;
	}
	for ( std::vector<float>::iterator fraction = thicknessFraction.begin();
	      fraction != thicknessFraction.end();
	      ++fraction, ++mineralE )
	{
	    float const amountToFlow = fixed.pmnsec[element] * (*mineralE) *
		(1.0f - fractionInSolution) * decompFactor;
	    flows->Schedule ( &(*mineralE), &nps.secndy[element],
				st->time, amountToFlow);
	}
    }
    //--- Flow from secondary Phosophorus to occluded Phosophorus.
    float const amountToFlow = fixed.psecoc * nps.secndy[P] * wt.defac * dtm;
    flows->Schedule (&nps.secndy[P], &nps.occlud, st->time, amountToFlow);
}

//--- end of file ---
