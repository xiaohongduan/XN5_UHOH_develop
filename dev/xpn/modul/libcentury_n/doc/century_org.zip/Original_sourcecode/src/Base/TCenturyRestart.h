#ifndef INC_TCenturyRestart_h
#define INC_TCenturyRestart_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCenturyRestart.h
//	Class:	  TCenturyRestart
//
//	Description:
//	Class for managing restart information.
//	Responsibilities:
//	* Know restart mode (doing restart or not)
//	* Know file names for input and output restart files.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, July 02
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------
//	To Do:
//	* function to make a date-time stamp
//	* function to append date-times stamp to output file name
//	* variable to rememeber when output restart last written
//	* Imp[ement the read/write functions.
//	* Implement derived classes, one for monthly and one for daily Century.
// ----------------------------------------------------------------------------

#include <string>

class TCenturyRestart
{
  public:
	//---- constructors and destructor
	explicit TCenturyRestart ()
	  : doingRestart (false)
	  {
	  }
	virtual ~TCenturyRestart ()
	  {
	  }
	TCenturyRestart (TCenturyRestart const & object)
	  {
	    Copy (object);
	  }

	//---- functions
	void SetRestartFlag (			// Set the restart flag
	  bool newRestartFlag)
	  {
	    doingRestart = newRestartFlag;
	  }
	bool InRestartMode () const		// True if in restart mode
	  { return doingRestart; }
	bool ReadRestartFile (			// Read the restart file
	  std::string const & fileName)		//   with this file name
	  {
	    // To Do: ReadRestartFile
	    restartInputFileName = fileName;
      	    return true;	// failed
	  }
	bool WriteRestartFile (			// Write a restart file
	  std::string const & fileName)		//   with this file name
	  {
	    // To Do: WriteRestartFile
	    restartOutputFileName = fileName;
      	    return true;	// failed
	  }
	void Clear ()
	  {
      	    doingRestart = false;
      	    restartInputFileName.clear();
      	    restartOutputFileName.clear();
	  }

       	//---- functions: Queries
       	std::string const & GetInputRestartFile () const
       	  { return restartInputFileName; }
       	std::string const & GetOutputRestartFile () const
       	  { return restartOutputFileName; }

  protected:
	//---- constants

	//---- data
	bool doingRestart;			// true if in restart mode
	std::string restartInputFileName;	// restart file when read
	std::string restartOutputFileName;	// restart file when written

	//---- functions

  private:
	//---- constants

	//---- data

	//---- functions
	void Copy (TCenturyRestart const & object)	// Copy to this
	  {
	    if ( &object )
	    {
	      doingRestart = object.doingRestart;
	      restartInputFileName = object.restartInputFileName;
	      restartOutputFileName = object.restartOutputFileName;
	    }
	  }
};

#endif // INC_TCenturyRestart_h
