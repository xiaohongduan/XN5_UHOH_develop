// ----------------------------------------------------------------------------
//	Copyright 1999-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TMgmtEditorDlgEvents.cpp
//	Class:	  TMgmtEditorDlg
//
//	Description:
//	Dialog box for editing the site managment.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec97
//	History: See the class header file, TMgmtEditorDlg.h.
// ----------------------------------------------------------------------------
//	Notes:
//	This class is divided among the following files:
//	TMgmtEditorDlg.h		declarations header file
//	TMgmtEditorDlg.cpp		main class definitions
//	TMgmtEditorDlgLoad.cpp		methods to load data into dialog
//	TMgmtEditorDlgEvents.cpp	methods to handle dialog events
//	TMgmtEditorDlgGet.cpp		methods to retrieve data from dialog
// ----------------------------------------------------------------------------

#define _TMgtDlg_ClassDefined_
#include "TMgmtEditorDlg.h"
#include "TCMIApp.h"
#include "TNcFileMgt.h"
#include "TEventOption.h"
#include "TMgtFromLibDlg.h"
#include "utilmgmt.h"
#include "TChoicesDlg.h"
#include "TFileSelDlg.h"
#include "TCentConfig.h"
#include "TUserPref.h"
#include "constants.h"
#include "AssertEx.h"
#include <v/vynreply.h>
#include <v/vreply.h>
#include <v/vnotice.h>
using namespace std;

// These are defined in "externals.h"; need to be passed as ptrs into class.
#define HistText(a)
#define MsgText(a)

extern std::auto_ptr<TCenturyConfig> centuryConfig;	// Century model config.
extern	TUserPref userPref;				// user preferences

// ----------------------------------------------------------------------------
//	local variables
// ----------------------------------------------------------------------------

// static char displayStrLen = 21;	// length of display string
static char displayStr[21];	// for converting between values and text
// static char const* canceledStr = "Request canceled.\n";

// ----------------------------------------------------------------------------
//	member functions
// ----------------------------------------------------------------------------

//	Evt_NewMgmtScheme
//	Event Handler for button: New Management Scheme
void TMgmtEditorDlg::Evt_NewMgmtScheme ()
{
	HistText ("Requested a new management scheme.\n");
	Assert (mgmtDisp != NULL);

	if ( !ConfirmDelMgmt() )	// delete current management contents?
	{
		HistText (::canceledStr);
		return;			// no, cancel operation
	}
	// Clear current management object
	ClearLists ();
	ClearManagement ();
	if ( origMgmt )
		origMgmt->modified = true;
	// If summary is displayed, update it
	dynamic_cast<TCMIApp * const>(parent)->Display_MgmtSummary ();
}

//	Evt_OpenMgmtScheme
//	Event Handler for button: Open Management Scheme
void TMgmtEditorDlg::Evt_OpenMgmtScheme ()
{
	HistText ("Opening an existing management scheme.\n");

	if ( !ConfirmDelMgmt() )	// delete the current management?
	{
		HistText (::canceledStr);
		return;			// no, cancel operation
	}

	// ask for the file
	char *fileName;
	char const* filter[] =
	{
		"Management Schemes|*-S.nc|"
		"Century 4 Schedules|*.sch|"
		"All (*.*)|*.*|",
		NULL
	};
	fileName = UserSelectFile ( "Select a Management Scheme File",
				    filter, true );
	if ( !fileName )
		return;				// operation canceled
						// display file name
	if ( !dynamic_cast<TCMIApp * const>(parent)->ReadMgmt (fileName) )
	{
		InitializeManagement ();	// copy into member variables
		// Reload the dialogs now
		LoadDlg_Simulation ();
		LoadDlg_BlockDef ();
		LoadDlg_BlockInst ();
		// If summary is displayed, update it
		dynamic_cast<TCMIApp * const>(parent)->Display_MgmtSummary ();
	}
}

//	Evt_ImportMgmtScheme
//	Event Handler for button: Import Century 4.0 schedule file
void TMgmtEditorDlg::Evt_ImportMgmtScheme ()
{
	HistText ("Importing a Century 4.0 schedule file.\n");

	if ( !ConfirmDelMgmt() )	// delete the current management?
	{
		HistText (::canceledStr);
		return;			// no, cancel operation
	}

	// ask for the file
	char *fileName;
	char const* filter[] =
	{
		"Century Schedules|*.sch|"
		"All (*.*)|*.*|",
		NULL
	};
	fileName = UserSelectFile ( "Select a Century 4.0 Schedule File",
				    filter, true );
	if ( !fileName )			// successful?
	{
		//HistText (::canceledStr);
		return;				// no
	}
	if ( dynamic_cast<TCMIApp * const>(parent)->ReadMgmt (fileName) )
		return;				// error importing schedule
	InitializeManagement ();		// copy into member variables
	// turn on modified flag since imported data not save to netCDF file
	mgmtDisp->modified = true;
	// display in dialogs
	LoadDlg_Simulation ();
	LoadDlg_BlockDef ();
	LoadDlg_BlockInst ();
	// If summary is displayed, update it
	dynamic_cast<TCMIApp * const>(parent)->Display_MgmtSummary ();
}

//	Evt_CopyFromLibrary
//	Event Handler for button: From Library
void TMgmtEditorDlg::Evt_CopyFromLibrary ()
{
	HistText ("Obtaining management scheme from a management library.");

	if ( !ConfirmDelMgmt() )	// delete the current management?
	{
		HistText (::canceledStr);
		return;			// no, cancel operation
	}

	// ask for the file
	char* newMgmtFileBase = NULL;
	TMgtFromLibDlg *dlg = new TMgtFromLibDlg (
					parent,
					mgmtLibPath,
					userMgmtLibPath,
					newMgmtFileBase,
					helpFilePath.c_str() );
	delete dlg;	// delete afer dlg returns
	if ( !newMgmtFileBase )
	{
		HistText (::canceledStr);
		return;			// no, cancel operation
	}

	// read in the selected mgmt. scheme
	if ( dynamic_cast<TCMIApp * const>(parent)->ReadMgmt (newMgmtFileBase) )
		return;
	InitializeManagement ();		// copy into member variables
	// Reload the dialogs now
	LoadDlg_Simulation ();
	LoadDlg_BlockDef ();
	LoadDlg_BlockInst ();
	// If summary is displayed, update it
	dynamic_cast<TCMIApp * const>(parent)->Display_MgmtSummary ();

	// all done!
	delete [] newMgmtFileBase;
}

//	Evt_SaveMgmtScheme
//	Event Handler for button: Save Management Scheme
void TMgmtEditorDlg::Evt_SaveMgmtScheme ()
{
	Assert (mgmtDisp != NULL);
	HistText ("Saving the current management scheme.");

	// make sure all the info is gotten from the dialogs
	if ( curFrameId == D_ToggleFrame1 )
		GetDispSimInfo ();
	if ( curFrameId == D_ToggleFrame2 )
		ConfirmSaveEventData ();
	else if ( curFrameId == D_ToggleFrame3 )
		ConfirmSaveInstData ();

	// check the base name
	char newName[257];
	GetTextIn ( D_MgtBaseName, newName, 257 );	// text box contents
	if ( strlen(newName) == 0 )			// nothing entered
	{
		*newName = '\0';
		vReplyDialog rd (this, "Specify Management File Name");
		int reply = rd.Reply (
				 "Enter a name for the management files:\n"
				"(e.g., \"c3grass\")\n"
				"Name can include the path.",
				newName, 257 );
		if ( reply == M_Cancel || !(*newName) )
		{
			HistText (::canceledStr);
			return;
		}
		char msg[512];
		strcpy (msg, "New management files base name is \"");
		strcat (msg, newName);
		strcat (msg, "\"\n");
		HistText (msg);
	}
	// add the work path if no path given
	TEH::TFileName tmpName (newName);
	AddWorkPath (&tmpName);
	// save base name
	mgmtDisp->SetFileName ( tmpName.GetFullName() );

	// retrieve into the global mgmt. variable
	if ( !origMgmt.get() )
	{
		origMgmt.reset (new TManagementScheme (*mgmtDisp) );
		::centuryConfig->UseManagement (origMgmt);
	}
	else
		*origMgmt = *mgmtDisp;

	// write to disk
	if ( !dynamic_cast<TCMIApp * const>(parent)->WriteMgmt() )
		mgmtDisp->modified = false;	// write failed
        //  update
	dynamic_cast<TCMIApp * const>(parent)->Display_MgmtSummary ();
}

//	Evt_BrowseWthrFile
//	Event Handler for button: "browse" for weather file.
//	The file must already exist.
void TMgmtEditorDlg::Evt_BrowseWthrFile ()
{
	char const* filter[] =
	{
		"Weather (*.wth)|*.wth|"
		"Century 4 Weather (*.prn)|*.prn|"
		"Data (*.dat)|*.dat|"
		"Text (*.txt)|*.txt|"
		"All (*.*)|*.*|",
		NULL
	};
	std::string fileName =
		UserSelectFile ( "Select Weather File", filter, true );
	// Do explicit check so we can add messages later if we want to.
	if ( !fileName.empty() )
	{
		// message in session window
		HistText ("Selected a weather file:\n\"");
		HistText (fileName);
		HistText ("\"\n");
		// remove leading "./" if there
		/*
		if ( fileName[0] == '.' &&
		     (fileName[1] == '/' || fileName[1] == '\\') )
		{
			fileName.erase (0, 2);
		}
		*/
		// save name in current management scheme display
		SetString (D_WthrFileName, fileName.c_str() );
		// since we just found the file, assume it is ok.
		SetString ( D_WthrFileMsg, "" );	// no message
	}
}

//	Evt_AddNewBlock
// 	add new block
void TMgmtEditorDlg::Evt_AddNewBlock ()
{
	if ( !mgmtDisp )
		return;
	short countPrev = mgmtDisp->GetBlockCount();	// num. blocks before
	// add to new block to management scheme
	{	// isolate newBlk so BC++ 5.02 doesn't screw up
		TManagementBlock newBlk;
		newBlk.SetDescription ( "New Block" );
		mgmtDisp->AddBlock ( newBlk );
	}
	// update the display
	LoadDlg_BlockDef ();
	LoadDlg_BlockInst ();
	// make sure the corrent item is highlighted
	short count = mgmtDisp->GetBlockCount();	// new num. blocks
	if ( countPrev == 0 && count > 0 )
		ButtonDisplayBlkLst ();			// activate buttons
	SetValue (D_BlkList, count - 1, Value);
	SetValue (D_BlkListInst, count - 1, Value);
	// synchronize both lists
	UpdateDlg_EventList ();
	UpdateDlg_InstList ();
	// update the displayed block count
	sprintf ( displayStr, "%d", count );	// num. blocks
	SetString ( D_SimBlkCnt, displayStr );
	// flags
	mgmtDisp->modified = true;	// modified
	mgmtDisp->verified = false;	// modified so needs to be verified
}

//	Evt_CopyBlkToNew
//	copy highlighted block to new
void TMgmtEditorDlg::Evt_CopyBlkToNew ()
{
	if ( !blockDisp )		// anything to copy?
		return;
	// copy the highlighted block
	TManagementBlock newBlk;
	newBlk = *blockDisp;
	// change some of the block data
	char description[81];
	strcpy (description, "Copy of ");
	strncat (description, blockDisp->GetDescription(), 72);
	newBlk.SetDescription ( description );
	// add to new block to management scheme
	mgmtDisp->AddBlock ( newBlk );
	// update the display
	LoadDlg_BlockDef ();
	LoadDlg_BlockInst ();
	// make sure the corrent item is highlighted
	short count = mgmtDisp->GetBlockCount();
	SetValue (D_BlkList, count - 1, Value);
	SetValue (D_BlkListInst, count - 1, Value);
	// synchronize both lists
	UpdateDlg_EventList ();
	UpdateDlg_InstList ();
	// update the displayed block count
	sprintf (displayStr, "%d", count );	// num. blocks
	SetString ( D_SimBlkCnt, displayStr );
	// flags
	mgmtDisp->modified = true;	// modified
	mgmtDisp->verified = false;	// modified so needs to be verified
}

//	Evt_DeleteBlock
// 	delete block highlighted
void TMgmtEditorDlg::Evt_DeleteBlock ()
{
	if ( !mgmtDisp || !blockDisp )		// anything to delete?
		return;
	short indexList;				// index of list
	indexList = (short)GetValue (D_BlkList);	// get index to item
	mgmtDisp->DeleteBlock (indexList);
	// update the display
						// lists
	LoadDlg_BlockDef ();
	LoadDlg_BlockInst ();
						// display block count
	short count = mgmtDisp->GetBlockCount();
	sprintf (displayStr, "%hd", count );	// num. blocks
	SetString ( D_SimBlkCnt, displayStr );
	if ( count == 0 )
		ButtonDisplayBlkLst ();		// deactivate buttons
	// flags
	mgmtDisp->modified = true;	// modified
	mgmtDisp->verified = false;	// modified so needs to be verified
}

//	Evt_AddNewEvent
// 	add new event (clears first)
void TMgmtEditorDlg::Evt_AddNewEvent ()
{
	if ( blockDisp->GetEventCount() > 0 )
		ConfirmSaveEventData ();	// need to save current event?
	else
		ButtonDisplayEvtLst ();		// activate buttons

	// display a list of events to choose from
	TEventType type = SelectListOfEvents ();	// select an event
	if ( type == ET_Unknown )			// canceled?
		return;

	// add the event to the currently selected management block
	TManagementEvent newEvt;
	newEvt.type = type;
	newEvt.SetRangeEventFlag ();

	// figure out the initial year and month
	if ( blockDisp->GetEventCount() == 0 )
	{
		newEvt.year = 1;
		newEvt.month = 1;
	}
	else
	{
		// get event highlighted in the list; use its year & month
		newEvt.year = evtDisp->year;
		newEvt.month = evtDisp->month;
	}

	// now add it to the block
add_paired_event:			// kluge for "if...then...do again"
	short which = blockDisp->AddEvent (newEvt);
	if ( which >= 0 )				// added?
	{
		// update the display
		ButtonDisplayEvtLst ();
							// lists
		UpdateDlg_EventList ();
		SetValue (D_EvtList, which, Value);
							// data
		UpdateDlg_EventData ();
							// display event count
		sprintf (displayStr, "%hd", 	// num. events
			blockDisp->GetEventCount() );
		SetString ( D_BlkEvtCnt, displayStr );
		// flags
		mgmtDisp->modified = true;	// modified
		mgmtDisp->verified = false;	// needs to be verified
	}
	else				// not added
	{
		vNoticeDialog dlg (this, "Failed Adding Event");
		std::string msg;
		msg = "Unable to add the event: ";
		msg += ::eventDescrip[newEvt.type];
		dlg.Notice ( msg.c_str() );
		return;
	}

	// check for paired events
	//	1. harvest with crop last month growth
	//	2. fire with tree removal if trees are present
	//	   and tree removal event is a type for fire
	//	3. tree with tree first month growth
	TManagementEvent prevEvt = newEvt;	// save previous event
	newEvt.Clear ();			// clear for new event
	switch (prevEvt.type)
	{
	  case ET_Harvest:
	  case ET_Fire:
	  case ET_Tree:
		switch (prevEvt.type)
		{
	  	  case ET_Harvest:
	  	  	newEvt.type = ET_EndCrop;
			MsgText ("Added Crop Growth End event for the "
	  	  		 "Harvest event.\n");
	  	  	break;
	  	  case ET_Fire:
	  	  {
	  	  	short startIndex = 0;
			if ( FindEvent ( blockDisp, ET_Tree, startIndex ) )
			{
				newEvt.type = ET_TreeRemoval;
				MsgText ("Added Tree Removal event for the "
					 "Burn event.\n");
			}
	  	  }
	  		break;
	  	  case ET_Tree:
	  		newEvt.type = ET_StartTree;
	  	  	MsgText ("Added Tree Start Growth event for the "
	  	  		 "Tree specification.\n");
	  		break;
		}
		newEvt.month = prevEvt.month;
		newEvt.year = prevEvt.year;
		if ( newEvt.type != ET_Unknown )
			goto add_paired_event;
		break;
	  default:
	  	break;
	}
}

//	Evt_DeleteEvent
// 	delete event highlighted
void TMgmtEditorDlg::Evt_DeleteEvent ()
{
	if ( !blockDisp || !evtDisp )		// anything to delete?
		return;
	short indexList;				// index of list
	indexList = (short)GetValue (D_EvtList);	// get index to item
	blockDisp->DeleteEvent (indexList);
	// update the display
						// lists
	UpdateDlg_EventList ();
						// display event count
	short count = blockDisp->GetEventCount();
	sprintf (displayStr, "%hd", count );	// num. events
	SetString ( D_BlkEvtCnt, displayStr );
	if ( count == 0 )
		ButtonDisplayEvtLst ();		// deactivate buttons
	// flags
	mgmtDisp->modified = true;	// modified
	mgmtDisp->verified = false;	// modified so needs to be verified
}

//	Evt_SaveEventData
// 	Button "save event": save event data displayed
void TMgmtEditorDlg::Evt_SaveEventData ()
{
	if ( !evtDisp )
		return;				// nothing to save!
	TManagementEvent prevEvt = *evtDisp;	// previous event
	TManagementEvent newEvt;
	GetEventData ( &newEvt );		// retrieve data
	if ( vrfy->VerifyEvent ( blockDisp, &newEvt ) )	// failed?
	{
		// TO DO: Need user msg here
	}
	short which = (short)GetValue (D_EvtList);	// get index to item
	blockDisp->ReplaceEvent ( which, newEvt );
	blockDisp->ReplaceEvent ( which, newEvt );
	// update the display
							// lists
	if ( prevEvt < newEvt || prevEvt > newEvt )
		UpdateDlg_EventList ();
							// data
	UpdateDlg_EventData ();
	// flags
	mgmtDisp->modified = true;	// modified
}

//	Evt_EvtAddChoose
//	button: additional info for event
void TMgmtEditorDlg::Evt_EvtAddChoose ()
{
	char const* erodDepoStr = "Enter a value whose units are\n\n"
				  "kilograms/square meter/month\n\n"
				  "into the additional data field.";

	if ( !evtDisp )				// anything there?
		return;
	TManagementEvent & evt = *evtDisp;
	//GetEventData (evt);			// get displayed event data
	switch (evt.type)
	{
	  case ET_Crop:			// select from crop.100
	  case ET_Cultivate:		// select from cult.100
	  case ET_Fertilize:		// select from fert.100
	  case ET_Fire:			// select from fire.100
	  case ET_Graze:		// select from graz.100
	  case ET_Harvest:		// select from harv.100
	  case ET_Irrigate:		// select from irri.100
	  case ET_AddOM:		// select from omad.100
	  case ET_Tree:			// select from tree.100
	  case ET_TreeRemoval:		// select from trem.100
	  {
	  	char const * const currentOption = evt.additional;
	  	char const * newOption = 0;
	  	if ( SelectEventOption (evt.type, newOption, currentOption) )
			SetString ( D_EvtAdd, newOption );
	  	break;
	  }
	  case ET_Erosion:		// enter: kg/m^2/month
	  {
		vNoticeDialog dlg (this, "Erosion Event");
		dlg.Notice (erodDepoStr);
		break;
	  }
	  case ET_Deposition:		// enter: kg/m^2/month
	  {
		vNoticeDialog dlg (this, "Deposition Event");
		dlg.Notice (erodDepoStr);
		break;
	  }
	  case ET_Plant:
	  case ET_StartCrop:
	  case ET_EndCrop:
	  case ET_Senesce:
	  case ET_StartTree:
	  case ET_EndTree:
	  {
		vNoticeDialog dlg (this, "Event Additional Information");
		dlg.Notice ("No additional information is required "
			    "for this event.");
		break;
	  }
	  case ET_External:
	  {
		vNoticeDialog dlg (this, "External Event Information");
		dlg.Notice (
			"Additional information entered here will be\n"
			"passed to the external function."
			"\nUse this event only if this version of the model\n"
			"is configured for handling this event.");
		break;
	  }
	  default:
	  	break;
	}
}

//	Evt_AddNewInstance
// 	add new instance (clears)
void TMgmtEditorDlg::Evt_AddNewInstance ()
{
	if ( !blockDisp )		// anything there?
		return;
	ConfirmSaveInstData ();		// need to save current instance?
	// add to new instance to current block
	TManagementInst newInst;
	blockDisp->AddInstance (newInst);
	// update the display
					// lists
	UpdateDlg_InstList ();
					// displayed event count
	sprintf (displayStr, "%hd", blockDisp->GetInstanceCount() );
	SetString ( D_BlkInstCnt, displayStr );
	ShowInstDataDialog (D_InstTab_Data);
	ButtonDisplayInstLst ();
	// flags
	mgmtDisp->modified = true;	// modified
	mgmtDisp->verified = false;	// modified so needs to be verified
}

//	Evt_CopyInstToNew
//	copy highlighted instance to new
void TMgmtEditorDlg::Evt_CopyInstToNew ()
{
	if ( !instDisp )				// anything to copy?
		return;
	ConfirmSaveInstData ();		// need to save current instance?
	// get the currently highlighted instance
	TManagementInst newInst;
	newInst = *instDisp;
	// change the year variables so instance is unique
	newInst.yearFirst = newInst.yearLast + 1;
	newInst.yearLast = newInst.yearFirst;
	newInst.outputStartYr = newInst.yearFirst;
	// add to new instance to current block
	blockDisp->AddInstance (newInst);
	// update the display
					// lists
	UpdateDlg_InstList ();
					// displayed event count
	sprintf (displayStr, "%hd", blockDisp->GetInstanceCount() );
	SetString ( D_BlkInstCnt, displayStr );
	// flags
	mgmtDisp->modified = true;	// modified
	mgmtDisp->verified = false;	// modified so needs to be verified
}

//	Evt_DeleteInstance
// 	delete instance highlighted
void TMgmtEditorDlg::Evt_DeleteInstance ()
{
	if ( !blockDisp || !instDisp )		// anything to delete?
		return;
	short indexList;				// index of list
	indexList = (short)GetValue (D_InstList);	// get index to item
	blockDisp->DeleteInstance (indexList);
	// update the display
					// lists
	UpdateDlg_InstList ();
					// displayed event count
	short count = blockDisp->GetInstanceCount();
	sprintf (displayStr, "%hd", count );
	SetString ( D_BlkInstCnt, displayStr );
	if ( count == 0 )
	{
		ButtonDisplayInstLst ();		// deactivate buttons
		ShowInstDataDialog (D_InstTab_None);	// "none" text
	}
	// flags
	mgmtDisp->modified = true;	// modified
	mgmtDisp->verified = false;	// modified so needs to be verified
}

//	Evt_SaveInstanceData
// 	save instance data displayed
void TMgmtEditorDlg::Evt_SaveInstanceData ()
{
	if ( !instDisp )
		return;				// nothing to save!
	TManagementInst prevInst = *instDisp;	// previous event
	TManagementInst newInst;
	GetInstanceData ( &newInst );		// retrieve data
	if ( vrfy->VerifyInstance ( blockDisp, &newInst ) )	// failed?
	{
		// TO DO: user message needed here
	}
	short which = (short)GetValue (D_InstList);	// get index to item
	blockDisp->ReplaceInstance ( which, newInst );
	blockDisp->ReplaceInstance ( which, newInst );
	// update the display
							// lists
	if ( prevInst < newInst || prevInst > newInst )
		UpdateDlg_InstList ();
							// data
	UpdateDlg_InstData ();
	ButtonDisplayInstLst ();
	// flags
	mgmtDisp->modified = true;	// modified
}

//	Evt_OutputFreqSel
//	button: select output interval from list
void TMgmtEditorDlg::Evt_OutputFreqSel ()
{
	static short const numChoices = 11;	// number of radio buttons
	// radio button labels
	const char *str[] = { "None",
			"Monthly", "Bimonthly", "Every 3 months",
			"Every 4 months", "Every 6 months",
			"Annually", "Biannually",
			"Every 5 years", "Every 10 years",
			"Every 100 years", "Every 1000 years",
			NULL };
	// associated values
	float const freq[] = { 0.0,
			0.0833, 0.1667, 0.250, 0.3333, 0.50,
			1.0, 2.0, 5.0, 10.0, 100.0 };
	// build dialog
	TChoicesDialog dlg (this,
		"Select the output frequency\nfor this instance:",
		numChoices, "Output Frequency");
	for (short i = 1; i <= numChoices; i++)
		dlg.AddChoice (str[i]);
	// display choice to user
	short choice = dlg.GetChoice ();
	if ( choice )
	{
		sprintf (displayStr, "%f", freq[choice]);
		SetString (D_OutputFreq, displayStr);
	}
}

//	Evt_BlkDescChange
//	Change and update lists for new block description.
void TMgmtEditorDlg::Evt_BlkDescChange ()
{
	if ( !blockDisp )
		return;					// nothing to do
	TManagementBlock prevBlk = *blockDisp;		// save previous
	GetBlockDescrip ();				// get description
	if ( !strcmp( prevBlk.GetDescription(),
		      blockDisp->GetDescription() ) )
		return;					// nothing changed

	// Update the item text in the block display list
	short i = (short)GetValue (D_BlkList);	// index to list item
	short c = idxBlkListDef;	// index to list in CommandObject
	char *p = ( (char**)(cmdList[c].itemList) )[i];	// pointer to item
	char desc[81];					// block description
	strcpy ( desc, blockDisp->GetDescription() );	// get block descrip.
	// KLUGE!
	// For some reason, block description is retrieved with
	// blanks padded after string, though sent to STL trimmed.
	// So here we trim again (errgghhh!)
	::strtrim (desc);
	MakeBlkDescItemStr (p, desc);

	// update display of block definition list
	SetValue (cmdList[c].cmdId, 0, ChangeListPtr);
	if ( curFrameId == D_ToggleFrame2 )		// make sure is visible
		SetValue (cmdList[c].cmdId, 0, Hidden);
	LoadDlg_BlockInst ();
	// make sure the corrent item is highlighted
	SetValue (D_BlkList, i, Value);
	SetValue (D_BlkListInst, i, Value);

	// synchronize event and instance lists
	UpdateDlg_EventList ();
	UpdateDlg_InstList ();

	// flags
	mgmtDisp->modified = true;	// modified
	mgmtDisp->verified = false;	// modified so needs to be verified
}

//	Evt_FileNameBaseChange
//	Change and update the netCDF file name base for the mgmt. scheme.
void TMgmtEditorDlg::Evt_FileNameBaseChange ()
{
	HistText ("Changing the management file name.");
	const char *prevName = mgmtDisp->GetBaseName ();  // retrieve previous
	std::string initPath;			// starting folder
	static short const pathLength = 257;
	static char fileName[pathLength];	// file name
	char const* filter[] =			// file filter
	{
		"Management Schemes|*-S.nc|",
	  	NULL
	};
	int filterIdx = 0;			// filter index
	*fileName = 0;

	// retrieve name from dialog
	char newName[pathLength];
	GetTextIn ( D_MgtBaseName, newName, pathLength );
	::strtrim (newName);

	// if entered a new path and name, use it as base for browse
	if ( *newName )				// anything entered?
	{
		// extract name parts
		TEH::TFileName name (newName);
		initPath = name.GetFullPath ();
		if ( name.HaveName() )
		{
			strcpy (fileName, name.GetName().c_str() );
			strcat (fileName, "-S.nc");
		}
	}
	else	// use working directory
	{
		// extract name parts
		initPath = workPath;
	}
	if ( !(*fileName) && prevName )		// anything yet?
	{
		strcpy (fileName, prevName);	// use base name
		strcat (fileName, "-S.nc");
	}

	// browse
	char const* title = "Select Management File Name";
	TFileSelectDlg fileBrowserDlg (this);	// instance of browser
	int result = fileBrowserDlg.FileSelectSave ( title,
				fileName, pathLength,
				filter, filterIdx, initPath.c_str() );

	// check results
	if ( !(result && *fileName) )	// no name entered or selected?
	{
		HistText ("No management file name was entered.");
		return;
	}

	// check if different from the previously saved name
	if ( prevName && !strcmp ( fileName, prevName ) )	// same name?
		return;

	// save the new name base
	if ( mgmtDisp->SetFileName (fileName) )
	{
		HistText ("Error saving the new file name.\n");
	}
	else	// base name changed
	{
		SetString ( D_MgtBaseName, mgmtDisp->GetBaseName() );
		char msg[512];
		strcpy (msg, "Management file name has been changed to\n\"");
		strcat (msg, fileName);
		strcat (msg, "\"\n");
		HistText (msg);
		// flags
		mgmtDisp->modified = true;	// modified
		mgmtDisp->verified = false;	// needs to be verified
	}
}

//	Evt_LabelTypeNone
//	radiobutton: C labeling type - none
void TMgmtEditorDlg::Evt_LabelTypeNone ()
{
	SetValue ( D_LabelYear, notSens, Sensitive );	// disable year entry
	Enable14CFileName (false);
}

//	Evt_LabelType14C
//	radiobutton: C labeling type - 14C
void TMgmtEditorDlg::Evt_LabelType14C ()
{
	SetValue ( D_LabelYear, isSens, Sensitive );	// enable year entry
	Enable14CFileName (true);
}

//	Evt_LabelType13C
//	radiobutton: C labeling type - 13C
void TMgmtEditorDlg::Evt_LabelType13C ()
{
	SetValue ( D_LabelYear, isSens, Sensitive );	// enable year entry
	Enable14CFileName (false);
}

static char const* noneStr = "None";

//	Evt_InitSysCrop
//	radiobutton: init. system = crop
void TMgmtEditorDlg::Evt_InitSysCrop ()
{
	SetValue ( D_InitSysTreeSel, notSens, Sensitive );	// disable
	SetValue ( D_InitSysCropSel, isSens, Sensitive );	// enable
	TSimInfo& si = mgmtDisp->GetSimInfo ();		// simulation info
	si.initManagement = SysType_CropGrass;
	if ( *si.initCrop )		// anything there?
		SetString ( D_InitSysCropStr, si.initCrop );
	else
		SetString ( D_InitSysCropStr, noneStr );
	SetString ( D_InitSysTreeStr, noneStr );
}

//	Evt_InitSysTree
//	radiobutton: init. system = tree
void TMgmtEditorDlg::Evt_InitSysTree ()
{
	SetValue ( D_InitSysCropSel, notSens, Sensitive );	// disable
	SetValue ( D_InitSysTreeSel, isSens, Sensitive );	// enable
	TSimInfo& si = mgmtDisp->GetSimInfo ();		// simulation info
	si.initManagement = SysType_Forest;
	if ( *si.initTree )		// anything there?
		SetString ( D_InitSysTreeStr, si.initTree );
	else
		SetString ( D_InitSysTreeStr, noneStr );
	SetString ( D_InitSysCropStr, noneStr );
}

//	Evt_InitSysBoth
//	radiobutton: init. system = both
void TMgmtEditorDlg::Evt_InitSysBoth ()
{
	SetValue ( D_InitSysCropSel, isSens, Sensitive );	// enable
	SetValue ( D_InitSysTreeSel, isSens, Sensitive );	// enable
	TSimInfo& si = mgmtDisp->GetSimInfo ();		// simulation info
	si.initManagement = SysType_Savanna;
	if ( *si.initCrop )		// anything there?
		SetString ( D_InitSysCropStr, si.initCrop );
	else
		SetString ( D_InitSysCropStr, noneStr );
	if ( *si.initTree )		// anything there?
		SetString ( D_InitSysTreeStr, si.initTree );
	else
		SetString ( D_InitSysTreeStr, noneStr );
}

//	Evt_InitSysCropSel
//	button: choose init. crop
void TMgmtEditorDlg::Evt_InitSysCropSel ()
{
	TSimInfo & si = mgmtDisp->GetSimInfo ();	// simulation info
	char const * const currentOption = si.initCrop;
	char const * newOption = 0;
	if ( SelectEventOption (ET_Crop, newOption, currentOption) )
	{
		strcpy ( si.initCrop, newOption );
		if ( si.initManagement == SysType_Unknown )
			si.initManagement = SysType_CropGrass;
		UpdateInitSystem ();
	}
}

//	Evt_InitSysTreeSel
//	button: choose init. tree
void TMgmtEditorDlg::Evt_InitSysTreeSel ()
{
	TSimInfo & si = mgmtDisp->GetSimInfo ();	// simulation info
	char const * const currentOption = si.initTree;
	char const * newOption = 0;
	if ( SelectEventOption (ET_Tree, newOption, currentOption) )
	{
		strcpy ( si.initTree, newOption );
		if ( si.initManagement == SysType_Unknown )
			si.initManagement = SysType_Forest;
		UpdateInitSystem ();
	}
}

//	Evt_Microcosm
//	Checkbox: Simulate a microcosm.
void TMgmtEditorDlg::Evt_Microcosm ()
{
	if ( isChk == GetValue (D_Microcosm) )		// enable temp entry
		SetValue ( D_MicrocosmTemp, isSens, Sensitive );
	else						// disable temp entry
		SetValue ( D_MicrocosmTemp, notSens, Sensitive );
}

//	Evt_CO2Effect
//	Checkbox: use CO2 effect
void TMgmtEditorDlg::Evt_CO2Effect ()
{
	if ( isChk == GetValue (D_CO2Effect) )		// enable year entry
	{
		SetValue ( D_CO2EffectYrSt, isSens, Sensitive );
		SetValue ( D_CO2EffectYrEnd, isSens, Sensitive );
	}
	else						// disable year entry
	{
		SetValue ( D_CO2EffectYrSt, notSens, Sensitive );
		SetValue ( D_CO2EffectYrEnd, notSens, Sensitive );
	}
}

//	Evt_Browse14CFile
//	button: "browse" for 14C data file.
//	The file must already exist.
void TMgmtEditorDlg::Evt_Browse14CFile ()
{
	char const* filter[] =
	{
		"Data (*.dat)|*.dat|"
		"Text (*.txt)|*.txt|"
		"All (*.*)|*.*|",
		NULL
	};
	char* fileName =
		UserSelectFile ( "Select 14C Input Data File", filter, true );
	// Do explicit check so we can add messages later if we want to.
	if ( fileName )
	{
		// TO DO: After the 14C data editor is developed, and
		//	  14C data is in netCDF files, then
		//	  check netCDF file attribute "FileType" to see
		//	  if this is an erosion/deposition file.

		// message in session window
		HistText ("Selected a 14C input data file:\n\"");
		HistText (fileName);
		HistText ("\"\n");
		// save name in current management editor display
		SetString (D_14CFileName, fileName);
	}
}

//	Evt_BrowseEroFile
//	button: "browse" for erosion file
//	This is a new or existing file.
void TMgmtEditorDlg::Evt_BrowseEroFile ()
{
	char const* filter[] =
	{
		"netCDF (*.nc)|*.nc|"
		"All (*.*)|*.*|",
		NULL
	};
	char* fileName = UserSelectFile ( "Select New Erosion Data File",
					  filter, false );
	// Do explicit check so we can add messages later if we want to.
	if ( fileName )
	{
		// TO DO: Check netCDF file attribute "FileType" to see
		//        if this is an erosion/deposition file.

		// TO DO: Check the extension to be sure is "nc"

		// message in session window
		HistText ("Selected an erosion output data file:\n\"");
		HistText (fileName);
		HistText ("\"\n");
		// save name in current management editor display
		SetString (D_EroFileName, fileName);
	}
}

//	Evt_BrowseDepFile
//	button: "browse" for deposition file.
//	The file must already exist.
void TMgmtEditorDlg::Evt_BrowseDepFile ()
{
	char const* filter[] =
	{
		"netCDF (*.nc)|*.nc|"
		"All (*.*)|*.*|",
		NULL
	};
	char* fileName = UserSelectFile (
		"Select Deposition Input Data File", filter, true );
	// Do explicit check so we can add messages later if we want to.
	if ( fileName )
	{
		// TO DO: Check netCDF file attribute "FileType" to see
		//        if this is an erosion/deposition file.

		// TO DO: Check the extension to be sure is "nc"

		// message in session window
		HistText ("Selected a deposition input data file:\n\"");
		HistText (fileName);
		HistText ("\"\n");
		// save name in current management editor display
		SetString (D_DepFileName, fileName);
	}
}

//	UserSelectFile
//	User interactively selects a file using the file browser.
//	Returns a pointer to the file name if selected, else NULL if not.
char* TMgmtEditorDlg::UserSelectFile (
	char const* title,	// dialog title
	char const** filter,	// file filter
	const bool mustExist)	// true if file must already exist
{
	static short const pathLength = 257;
	static char fileName[pathLength];	// selected file name
	*fileName = 0;				// ...initialize
	int filterIdx = 0;			// filter index
	std::string initPath;			// starting folder
	if ( ::centuryConfig->GetManagement() )		// have mgmt?
		initPath = workPath;
	else						// no site
		initPath = ::userPref.GetMgmtPath().GetFullPath();

	TFileSelectDlg fileBrowserDlg ((vApp*)parent);	// instance of
	// browse
	int result;
	if ( mustExist )
		result = fileBrowserDlg.FileSelect ( title,
				fileName, pathLength,
				filter, filterIdx, initPath.c_str() );
	else
		result = fileBrowserDlg.FileSelectSave ( title,
				fileName, pathLength,
				filter, filterIdx, initPath.c_str() );
	if (result && *fileName)	// get a file name?
		return fileName;	// ...yes
	else
		return 0;		// ...no
}

//--- end of TMgmtEditorDlgEvents.cpp

