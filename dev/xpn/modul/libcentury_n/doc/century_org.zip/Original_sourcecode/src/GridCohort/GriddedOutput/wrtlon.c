
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include "netcdf.h"
#include "wrtcdf_ll.h"

    void wrtlon_(float *curr_lon)
    {
      int           status;
      static size_t lonstart={0};
      size_t        tcount={1};

      status = nc_put_vara_float(cropll_ncid, lon_id, &lonstart, &tcount,
                                 curr_lon);
      status = nc_put_vara_float(h2oll_ncid, lon_id, &lonstart, &tcount,
                                 curr_lon);
      status = nc_put_vara_float(livcll_ncid, lon_id, &lonstart, &tcount,
                                 curr_lon);
      status = nc_put_vara_float(livnll_ncid, lon_id, &lonstart, &tcount,
                                 curr_lon);
      status = nc_put_vara_float(nfluxll_ncid, lon_id, &lonstart, &tcount,
                                 curr_lon);
      status = nc_put_vara_float(nmnrll_ncid, lon_id, &lonstart, &tcount,
                                 curr_lon);
      status = nc_put_vara_float(nuptll_ncid, lon_id, &lonstart, &tcount,
                                 curr_lon);
      status = nc_put_vara_float(prodll_ncid, lon_id, &lonstart, &tcount,
                                 curr_lon);
      status = nc_put_vara_float(respll_ncid, lon_id, &lonstart, &tcount,
                                 curr_lon);
      status = nc_put_vara_float(soilcll_ncid, lon_id, &lonstart, &tcount,
                                 curr_lon);
      status = nc_put_vara_float(soilnll_ncid, lon_id, &lonstart, &tcount,
                                 curr_lon);
      lonstart += 1;

      return;
    }
