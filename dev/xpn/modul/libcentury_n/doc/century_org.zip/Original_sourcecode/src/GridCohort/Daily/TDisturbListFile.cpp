// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  TDisturbListFile.cpp
//	Class:	  TDisturbListFile
//
//	Description: See header file.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, July 2003
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TDisturbListFile.h"
#include "DayCentIRCTypes.h"
#include <sstream>
using namespace nrel::dcirc;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	Read
//	Read the disturbance file.
//	Return number of disturbance records read.
TDisturbListFile::size_type TDisturbListFile::Read ()
{
	size_type recordsRead = 0;
	if ( IsOpen() && AllowsInput() )
	{
	    while ( !fs.eof() && fs.good() && errorState == Error_NoError )
	    {
		// read a distrurbance record
		std::string line;
		std::getline ( fs, line );
		if ( !line.empty() )
		{
		    ScheduledDisturbanceEvent disturbEvent;
		    if ( IsComment( line.c_str() ) )
		    {
		    	// extract the comment and save in description field
			disturbEvent.SetComment (true, line);
			// To do: add next event's date, id's to this one
		    }
		    else
		    {
		    	if ( Extract (line, disturbEvent) )
		    	{
				errorState = Error_ReadFailed;
		    	}
		    }
		    // add to the list
		    int const previousSize = disturbanceList.size();
		    disturbanceList.push_back (disturbEvent);
		    if ( disturbanceList.size() == previousSize + 1 )
		    {
		    	if ( !disturbEvent.IsComment() )
			    ++recordsRead;  // count disturbance records
		    }
		    else	// add failed
		    {
		    	errorState = Error_UnknownError;
		    }
		}
	    }
	}
	return recordsRead;
}

//	Write
//	Write the disturbance file
//	Return number of disturbance records written.
TDisturbListFile::size_type TDisturbListFile::Write ()
{
	size_type recordsWritten = 0;
	char const separator = '\t';
	if ( IsOpen() && AllowsOutput() )
	{
		TDisturbanceList::iterator iList = disturbanceList.begin();
		while ( iList != disturbanceList.end() )
		{
		    if ( iList->IsComment() )
		    {
			fs << iList->GetDescription()
			   << std::endl;
		    }
		    else
		    {
			// write a record
			fs << iList->GetYear() << separator
			   << iList->GetMonth() << separator
			   << iList->GetDay() << separator
			   << iList->GetID() << separator
			   << iList->GetSourceCohortID() << separator
			   << iList->GetCellAreaFraction() << separator
			   << iList->GetManagementFileName() << separator
			   << iList->GetDescription()
			   << std::endl;
			++recordsWritten;
		    }
		    ++iList;
		}
	}
	return recordsWritten;
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

bool TDisturbListFile::Extract (			// Get event
	std::string const & record,			//   from text line
	ScheduledDisturbanceEvent & disturbEvent)	//   store in struct
{
	TCohortID idSource;		// ID number of source cohort
	TCohortID id;			// my ID number
	TYear year;			// simulation year
	TMonth month;			// simulation month
	TDay day;			// simulation day of month
	float cellAreaFraction;		// area fraction of cell
	std::string mgmtFile;		// management file name
	std::string description;	// description of disturbance

	// extract fields from line
	// to do: make more efficient - friend of ScheduledDisturbanceEvent?
	std::istringstream iss (record);	// makes copy of line
	short monthNum;
	iss >> year
	    >> monthNum
	    >> day
	    >> id
	    >> idSource
	    >> cellAreaFraction
	    >> /* std::ws >> */ mgmtFile
	    >> std::ws;
	std::getline ( iss, description );
	monthNum = std::max ( (short)::Jan, monthNum );
	monthNum = std::min ( (short)::Dec, monthNum );
	month = static_cast<TMonth>(monthNum);

	ScheduledDisturbanceEvent newEvent (
		idSource, id,
		year, month, day,
		cellAreaFraction,
		mgmtFile,
		description );
	disturbEvent = newEvent;
	return false; 			// successful
}


//--- end of definitions for TDisturbListFile ---
