// ----------------------------------------------------------------------------
//    Project:  Century Soil Organic Matter Model, daily version
//    File:	getsoilprop.cpp
//    Class:	TDayCentSoil
//    Function: GetSoilProperites
//
//    Description:
//
//    Determine soil texture class based on percent of sand, silt, clay.
//
//          U.S. Department of Agriculture soil textural classes
//
//         1 -- sand            2 -- loamy sand     3 -- sandy loam
//         4 -- silt loam       5 -- loam           6 -- sandy clay loam
//         7 -- silty clay loam 8 -- clay loam      9 -- sandy clay
//        10 -- silty clay     11 -- clay          12 -- peat or silt
//        13 -- volcanic
//
//     saturation soil hydraulic `conductivity' (m/s)
//     DATA SSCONS/0.000176, 0.0001563, 0.00003467, 0.0000072
//                ,0.00000695, 0.0000063, 0.0000017, 0.00000245
//                ,0.000002167, 0.000001033, 0.000001283, 0.0000080/
//
//    Author: Melannie Hartman
// ----------------------------------------------------------------------------
//    History:
//    ??????  Melannie Hartman, melannie@NREL.colostate.edu
//    * Created original getsoilprop.c for FORTRAN/C version of DayCent
//    Apr2001	 Melannie Hartman, melannie@NREL.colostate.edu
//    * Translated getsoilprop.c to getsoilprop.cpp
// ----------------------------------------------------------------------------
//    Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//    Notes:
// ----------------------------------------------------------------------------

#include "TDayCentException.h"
#include "TDayCentSoil.h"
#include "AssertEx.h"
#include <sstream>
using namespace std;

#define NCLASS 14

void TDayCentSoil::GetSoilProperties (
    TSoilTextureIndex textureIndex, // constant to designate coarseness/fineness of soil
                            //   (i.e. COARSE, MEDIUM, FINE, VERYFINE
    float const sandFrac,   // soil sand fraction (0-1)
    float const siltFrac,   // soil silt fraction (0-1)
    float const clayFrac,   // soil clay fraction (0-1)
    float & BulkDen,        // bulk density based on sand/silt/clay fracs (g/cm^3)
    float & FieldCap)       // field capacity based on sand/silt/clay fracs (0-1)
{
    static float const satcond[NCLASS] = {0.0, 0.000176, 0.0001563, 0.00003467,
        0.0000072, 0.00000695, 0.0000063, 0.0000017, 0.00000245,
        0.000002167, 0.000001033, 0.000001283, 0.0000080, 0.0000080};
    static float const bulk_density[NCLASS] = {0.0, 1.55, 1.50, 1.43, 1.36, 1.39,
        1.35, 1.24, 1.30, 1.28, 1.19, 1.15, 1.40, 0.75};
    static float const field_capacity[NCLASS] = {0.0, 0.14, 0.18, 0.22, 0.32, 0.29,
        0.28, 0.40, 0.36, 0.36, 0.46, 0.45, 0.33, 0.70};

  //  Initial assertions

    //! Debug Error (No exception handling necessary)
    // Check for out of range values should occur at source of input
    Assert (sandFrac > 0.0f);
    Assert (sandFrac < 1.0f);
    Assert (clayFrac > 0.0f);
    Assert (clayFrac < 1.0f);
    Assert (siltFrac > 0.0f);
    Assert (siltFrac < 1.0f);
    Assert ( std::fabs(sandFrac + clayFrac + siltFrac - 1.0) <= 1.0E-05 );

    int soil_indx;

    float sand = sandFrac * 100.0f;
    float silt = siltFrac * 100.0f;
    float clay = clayFrac * 100.0f;

    if (textureIndex == VERYFINE)
    {
      // volcanic
        soil_indx = 13;
    }
    else if ((sand >= 85) && ((-2.0/3.0)*silt - clay + 10 >= 0))
    {
      // sand
        soil_indx = 1;
    }
    else if (((-2.0/3.0)*silt - clay + 10 <= 0) && (-0.5*silt - clay + 15 >= 0))
    {
      // loamy sand
        soil_indx = 2;
    }
    else if (((-0.5*silt - clay + 15 <= 0) && (clay <= 20) && (sand >= 52))
      || ((sand <= 52) && (silt <= 50) && (clay <= 7)))
    {
      // sandy loam
        soil_indx = 3;
    }
    else if ((sand <= 50) && (silt >= 50) && (clay <= 27))
    {
        if ((sand <= 20) && (clay <= 10))
        {
          // silt
            soil_indx = 12;
        }
        else
        {
          // silt loam
            soil_indx = 4;
        }
    }
    else if ((sand >= 23 && sand <= 52) && (silt >= 28 && silt <= 50)
      && (clay >= 7 && clay <= 27))
    {
      // loam
        soil_indx = 5;
    }
    else if ((sand >= 45 && sand <= 80) && (silt <= 28)
      && (clay >= 20 && clay <= 35))
    {
      // sandy clay loam
        soil_indx = 6;
    }
    else if ((sand <= 20) && (clay >= 27 && clay <= 40))
    {
      // silty clay loam
        soil_indx = 7;
    }
    else if ((sand >= 20 && sand <= 45) && (clay >= 27 && clay <= 40))
    {
      // clay loam
        soil_indx = 8;
    }
    else if ((sand >= 45 && sand <= 65) && (silt <= 20)
      && (clay >= 35 && clay <= 55)) {
      // sandy clay
        soil_indx = 9;
    }
    else if ((sand <= 20) && (silt >= 40 && silt <= 60)
      && (clay >= 40 && clay <= 60))
    {
      // silty clay
        soil_indx = 10;
    }
    else if ((sand <= 45) && (silt <= 40) && (clay >= 40))
    {
      // clay
        soil_indx = 11;
    }
    else
    {
        ostringstream os;
        os << "Unknown texture type in GetSoilProperties:"
           << endl
           << "sand = " << sand
           << "silt = " << silt
           << "clay = " << clay
           << endl;
        ThrowDayCentException (TDayCentException::DCE_TGMERR,
        			os.str().c_str() );
    }

    BulkDen = bulk_density[soil_indx];
    FieldCap = field_capacity[soil_indx];
    /* not used here
    float ksat;
    ksat = satcond[soil_indx]*100.0;	       // Convert m/sec to cm/sec
    */
}

//--- end of file ---

