
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include "netcdf.h"
#include "wrtcdf_ll.h"

    void wrtlat_(float *curr_lat)
    {
      int           status;
      static size_t latstart={0};
      size_t        tcount={1};

      status = nc_put_vara_float(cropll_ncid, lat_id, &latstart, &tcount,
                                 curr_lat);
      status = nc_put_vara_float(h2oll_ncid, lat_id, &latstart, &tcount,
                                 curr_lat);
      status = nc_put_vara_float(livcll_ncid, lat_id, &latstart, &tcount,
                                 curr_lat);
      status = nc_put_vara_float(livnll_ncid, lat_id, &latstart, &tcount,
                                 curr_lat);
      status = nc_put_vara_float(nfluxll_ncid, lat_id, &latstart, &tcount,
                                 curr_lat);
      status = nc_put_vara_float(nmnrll_ncid, lat_id, &latstart, &tcount,
                                 curr_lat);
      status = nc_put_vara_float(nuptll_ncid, lat_id, &latstart, &tcount,
                                 curr_lat);
      status = nc_put_vara_float(prodll_ncid, lat_id, &latstart, &tcount,
                                 curr_lat);
      status = nc_put_vara_float(respll_ncid, lat_id, &latstart, &tcount,
                                 curr_lat);
      status = nc_put_vara_float(soilcll_ncid, lat_id, &latstart, &tcount,
                                 curr_lat);
      status = nc_put_vara_float(soilnll_ncid, lat_id, &latstart, &tcount,
                                 curr_lat);
      latstart += 1;

      return;
    }
