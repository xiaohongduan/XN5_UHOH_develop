// ----------------------------------------------------------------------------
//	Copyright 1999-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TMgmtEditorDlgGet.cpp
//	Class:	  TMgmtEditorDlg
//
//	Description:
//	Dialog box for editing the site managment.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec97
//	History: See the class header file, TMgmtEditorDlg.h.
// ----------------------------------------------------------------------------
//	Notes:
//	This class is divided among the following files:
//	TMgmtEditorDlg.h		declarations header file
//	TMgmtEditorDlg.cpp		main class definitions
//	TMgmtEditorDlgLoad.cpp		methods to load data into dialog
//	TMgmtEditorDlgEvents.cpp	methods to handle dialog events
//	TMgmtEditorDlgGet.cpp		methods to retrieve data from dialog
// ----------------------------------------------------------------------------

#define _TMgtDlg_ClassDefined_
#include "TMgmtEditorDlg.h"
#include "util.h"
#include <stdio.h>

//	GetDispSimInfo
//	Get info from simulation info toggle dialog.
void TMgmtEditorDlg::GetDispSimInfo ()
{
	if ( !mgmtDisp )
		return;

	char str[257];					// for input string
	TSimInfo& si = mgmtDisp->GetSimInfo ();		// simulation info

	GetTextIn (D_MgtDescrip, str, 81);		// mgmt. description
	::strtrim (str);
	mgmtDisp->SetDescription (str);
	GetTextIn (D_YearStart, str, 8);		// sim. start year
	::strtrim (str);
	sscanf (str, "%hd", &si.yearStart);
	GetTextIn (D_YearEnd, str, 8);			// simulation end year
	::strtrim (str);
	sscanf (str, "%hd", &si.yearEnd);
	if ( GetValue (D_LabelType14C) == isChk )	// 14C labeling
	{
		si.labelType = Lbl_14C;
		// get the 14C data file name; check that it exists
		GetTextIn (D_14CFileName, str, 257);
		::strtrim (str);
		if ( *str )
		{
			delete si.c14FileName;
			si.c14FileName = new TEH::TFileName (str);
			if ( !FileExists ( si.c14FileName, "14C data") )
			{
				delete si.c14FileName;
				si.c14FileName = 0;
			}
			else
				AddWorkPath (si.c14FileName);
		}
	}
	else if ( GetValue (D_LabelType13C) == isChk )	// 13C labeling
		si.labelType = Lbl_13C;
	else 						// no C labeling
		si.labelType = Lbl_None;
	if ( si.labelType != Lbl_None )			// have labeling?
	{
		GetTextIn (D_LabelYear, str, 8);	// ...label year start
		sscanf (str, "%hd", &si.labelYear);
	}
							// initial system
	if ( GetValue (D_InitSysCrop) == isChk )
		si.initManagement = SysType_CropGrass;
	if ( GetValue (D_InitSysTree) == isChk )
		si.initManagement = SysType_Forest;
	else // if ( GetValue (D_InitSysBoth) == isChk )
		si.initManagement = SysType_Savanna;
							// options:
	// simulate microcosm
	si.microcosm = GetValue (D_Microcosm) == isChk;
	if ( si.microcosm )
	{
		GetTextIn (D_MicrocosmTemp, str, 6);	// effect year start
		sscanf (str, "%f", &si.microcosmTemp);
	}

	// simulate CO2 effect
	si.co2Effect = GetValue (D_CO2Effect) == isChk;
	if ( si.co2Effect )
	{
		GetTextIn (D_CO2EffectYrSt, str, 8);	// effect year start
		sscanf (str, "%hd", &si.co2YearStart);
		GetTextIn (D_CO2EffectYrEnd, str, 8);	// effect year start
		sscanf (str, "%hd", &si.co2YearEnd);
	}
	// get the erosion output data file name
	GetTextIn (D_EroFileName, str, 257);
	::strtrim (str);
	if ( *str )
	{
		delete si.erosionFileName;
		si.erosionFileName = new TEH::TFileName (str);
		if ( !FileIsValid (si.erosionFileName, "erosion output data"))
		{
			delete si.erosionFileName;
			si.erosionFileName = 0;
		}
		else
			AddWorkPath (si.erosionFileName);
	}
	// get the deposition input file name; check that it exists
	GetTextIn (D_DepFileName, str, 257);
	::strtrim (str);
	if ( *str )
	{
		delete si.depoFileName;
		si.depoFileName = new TEH::TFileName (str);
		if ( !FileExists ( si.depoFileName, "deposition input data") )
		{
			delete si.depoFileName;
			si.depoFileName = 0;
		}
		else
			AddWorkPath (si.depoFileName);
	}
}

//	GetBlockDescrip
//	Get block description from block definition toggle dialog.
//	Call this whenever (1) change which block is displayed,
//	(2) change management scheme, (3) save the scheme.
//	Does NOT update the display in the block lists.
void TMgmtEditorDlg::GetBlockDescrip ()
{
	if ( blockDisp )
	{
		char desc[81];
		GetTextIn (D_BlkDesc, desc, 80);
		::strtrim (desc);
		if ( strcmp(desc, blockDisp->GetDescription() ) ) // changed?
		{
			blockDisp->SetDescription (desc);
			mgmtDisp->modified = true;
		}
	}
}

//	GetEventData
//	Get event data from block definition toggle dialog.
void TMgmtEditorDlg::GetEventData (TManagementEvent * const evt)
{
	if ( evt == 0 )
		return;			// nothing to save!

	evt->Clear ();
	if ( evtDisp != 0 )
		evt->type = evtDisp->type;	// constant for life of event
	else
		evt->type = ET_Unknown;
	if ( evt->haveRangeEvent )
	{
		char str[13];
		GetTextIn (D_RngYrStart, str, 7);	// range start year
		::strtrim (str);
		sscanf (str, "%hd", &evt->yearStart);
		GetTextIn (D_RngYrEnd, str, 7);		// range end year
		::strtrim (str);
		sscanf (str, "%hd", &evt->yearEnd);
							// values
		GetTextIn (D_RngValStart, str, 12);
		sscanf (str, "%f", &evt->valueStart);
		GetTextIn (D_RngValEnd, str, 12);
		sscanf (str, "%f", &evt->valueEnd);
		for (short i = 0; i < 12; i++)
		{
			GetTextIn (D_FracMo1 + i, str, 12);
			sscanf (str, "%f", &evt->fraction[i]);
		}
	}
	else
	{
		char str[81];
		GetTextIn (D_EvtYear, str, 7);		// year in block
		::strtrim (str);
		sscanf (str, "%hd", &evt->year);
		GetTextIn (D_EvtMonth, str, 7);		// month of event
		::strtrim (str);
		sscanf (str, "%hd", &evt->month);
		GetTextIn (D_EvtAdd, str, 80);		// additional data
		::strtrim (str);
		strcpy (evt->additional, str);
	}
}

//	GetInstanceData
//	Get instance data from the block instance dialog.
void TMgmtEditorDlg::GetInstanceData (
	TManagementInst * const inst)
{
	if ( inst == 0 )
		return;			// nothing to save!

	char displayStr[257];	// for converting between values and text

	inst->Clear ();
	GetTextIn (D_FirstYear, displayStr, 7);		// first sim. year
	sscanf (displayStr, "%hd", &inst->yearFirst);
	GetTextIn (D_LastYear, displayStr, 7);		// last sim. year
	sscanf (displayStr, "%hd", &inst->yearLast);
	GetTextIn (D_OutputYr, displayStr, 7);		// output year in block
	sscanf (displayStr, "%hd", &inst->outputStartYr);
	GetTextIn (D_OutputMo, displayStr, 7);		// output month start
	sscanf (displayStr, "%hd", &inst->outputStartMo);
	GetTextIn (D_OutputFreq, displayStr, 12);	// freq. of output
	register float freq;
	sscanf (displayStr, "%f", &freq);
	// round to 4 decimal places
	freq = (float)( (long)(10000.0 * freq + 0.5) ) * 0.0001;
	inst->outputInterval = freq;

						// file containing weather data
	GetTextIn (D_WthrFileName, displayStr, 257);
	inst->weatherFile = displayStr;
						// radiobuttons for weather src
	if ( GetValue (D_WthrMeans) == isChk )
		inst->weatherSource = WS_Means;
	else if ( GetValue (D_WthrFileRew) == isChk )
		inst->weatherSource = WS_FileRewind;
	else if ( GetValue (D_WthrFileCont) == isChk )
		inst->weatherSource = WS_FileContinue;
	else // D_WthrStoch = default
		inst->weatherSource = WS_Stochastic;
}

