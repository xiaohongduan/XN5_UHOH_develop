// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  ConfigToINIDataDCIRC.cpp
//	Class:	  ConfigToINIDataDCIRC
//
//	Description:
//	Class for transferring INI data to Configuration objects for the
//	Grid-Cohort Framework.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski (tom.hilinski@colostate.edu) June 2004
//	History: See header file.
// ----------------------------------------------------------------------------

#include "ConfigToINIDataDCIRC.h"
using namespace nrel::dcirc;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	DoToINI
//	Transfer Config data to INI data.
//	Return false if successful, else true if error.
bool ConfigToINIDataDCIRC::DoToINI ()
{
	bool error = false;

	TDayCentIRCConfig const & myConfig =
		dynamic_cast<TDayCentIRCConfig const &>(config);
	TINIDataDCIRC & myINI =
		dynamic_cast<TINIDataDCIRC &>(iniData);

	myINI.SetLogFile ( myConfig.GetLogFileName () );
	myINI.SetOutputVariablesConfig (
		myConfig.GetOutputVariablesConfig() );
	myINI.SetCohortAgConfig (
		myConfig.GetCATSI (),
		myConfig.GetMinCohortAgeToCombine (),
		myConfig.GetCohortVariationFraction () );
	myINI.SetDisturbanceConfig ( myConfig.GetDisturbFileNameMap () );
	myINI.SetWeatherINIFile ( myConfig.GetWeatherINIFileName() );
	myINI.SetSoilSource (
		myConfig.GetSoilSource(),
		myConfig.GetSoilSourceFileName() );

	return error;
}

//--- end of definitions for ConfigToINIDataDCIRC ---

