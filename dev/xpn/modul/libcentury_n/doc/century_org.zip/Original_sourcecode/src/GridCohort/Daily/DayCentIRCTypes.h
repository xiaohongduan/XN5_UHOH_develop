#ifndef INC_nrel_gcf_DayCentIRCTypes_h
#define INC_nrel_gcf_DayCentIRCTypes_h

// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  DayCentIRCTypes.h
//
//	Description:
//	Specifies global types common to the DayCentIRC model.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, June 2005
//	History:
// ----------------------------------------------------------------------------

#include "GCFTypes.h"
#include "GCFfwd.h"
#include "TSharedPtr.h"

namespace nrel
{
  namespace dcirc
  {

// ----------------------------------------------------------------------------
//	Shortcuts to types in the Grid-Cohort Framework
// ----------------------------------------------------------------------------

using ::nrel::gcf::TStringCArray;
using ::nrel::gcf::TStringArray;
using ::nrel::gcf::TCStringArray;
using ::nrel::gcf::TIDNumber;
using ::nrel::gcf::TGridCellID;
using ::nrel::gcf::TLandElemID;
using ::nrel::gcf::TCohortID;
using ::nrel::gcf::TModelID;
using ::nrel::gcf::TGridSize;
using ::nrel::gcf::TGridDimensions;
using ::nrel::gcf::TCohortConfig;
using ::nrel::gcf::TCohortConfigList;
using ::nrel::gcf::TCohortConfigCellList;
using ::nrel::gcf::TBiomeConfig;
using ::nrel::gcf::TBiomeConfigList;
using ::nrel::gcf::TRunMode;
using ::nrel::gcf::TSoilSource;
using ::nrel::gcf::TFileNameStr;
using ::nrel::gcf::TFileNameIDPair;
using ::nrel::gcf::TFileNameIDMap;
using ::nrel::gcf::TOutVarType;
using ::nrel::gcf::TOutVarValueArray;

// ----------------------------------------------------------------------------
//	Pointers
// ----------------------------------------------------------------------------
typedef TSharedPtr< ::nrel::gcf::TDecision >	TDecisionPtr;
typedef TSharedPtr< ::nrel::gcf::TFactories >	TFactoriesPtr;

// ----------------------------------------------------------------------------
//	Output variables
//
// Matrix
// scope:	group by:			note:
// cohort	none				individual cohorts
// cell		none, biome, landscape		none = aggregate entire cell
// grid		none, biome, landscape		none = aggregate entire grid
// ----------------------------------------------------------------------------

enum TOVScope				// output variables scope
{					// i.e., where values are aggregated
	OVS_Cohort,			// per cohort
	OVS_Cell,			// cell
	OVS_Grid,			// entire grid
	OVS_LastItem			// last item always!
};

enum TOVScopeGroup			// group within output variables scope
{
	OVSG_None,			// no grouping
	OVSG_Biome,			// group by biome
	OVSG_Landscape,			// group by landscape
	OVSG_LastItem			// last item always!
};

struct TOutputVarConfig			// Output variables configuration
{
	TOVScope scope;
	TOVScopeGroup groupBy;

	TOutputVarConfig ()
	  : scope (OVS_Cell),
	    groupBy (OVSG_None)
	  {
	  }

	void Reset ()	// set to "safe" values
	  {
	    scope = OVS_Cell;
	    groupBy = OVSG_None;
	  }

	bool operator== (
	  TOutputVarConfig const & object) const
	  {
	    if ( &object )
	    {
		return scope == object.scope &&
			groupBy == object.groupBy;
	    }
	    else
		return false;
	  }
	bool operator!= (
	  TOutputVarConfig const & object) const
	  {
	    return !(*this == object);
	  }

};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_gcf_DayCentIRCTypes_h
