
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* netCDF id */
int  site_ncid;

/* variable ids */
int  mask_id, fltvar_id, intvar_id, time_id;

int
sitedef(int *ntimes, char *history, int *nrow, int *ncol, int rows[2], int cols[2],
	int calendar_year[2])
{			/* create site.nc */

   /*  Added rows[], cols[] 8/18/98  -mdh */
   /* rows[0], rows[1] - starting and ending rows */
   /* cols[0], cols[1] - starting and ending columns */

   /*  Added calendar_year[] 10/6/98  -mdh */
   /* calendar_year[] is written to site file for post processing purposes only */
   /* calendar_year[0] - calendar year corresponding to initial simulation year */
   /* calendar_year[1] - calendar year corresponding to final simulation year */

   int status;
   int rows_id, cols_id, calyr_id;
   int arows[2], acols[2];
   size_t rcstart[1];
   size_t rccount[1];

   /* dimension ids */
   int  ncells_dim = 0;
   int  nouts_dim = 0;
   int  iouts_dim = 0;
   int  nrows_dim = 0;
   int  ncols_dim = 0;
   int  time_dim = 0;
   int  rcvals_dim = 0;

   /* variable shapes */
   int dims[2];

   /* enter define mode */
   status = nc_create("site.nc", NC_CLOBBER, &site_ncid);
   if (status != NC_NOERR) handle_error("nc_create(site.nc)", status);

   /* define dimensions */
   status = nc_def_dim(site_ncid, "ntime", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(site_ncid, "ncells", NC_UNLIMITED, &ncells_dim);
   status = nc_def_dim(site_ncid, "nouts", 235L, &nouts_dim);
   status = nc_def_dim(site_ncid, "iouts", 3L, &iouts_dim);
   status = nc_def_dim(site_ncid, "nrows", (size_t) *nrow, &nrows_dim);
   status = nc_def_dim(site_ncid, "ncols", (size_t) *ncol, &ncols_dim);
   status = nc_def_dim(site_ncid, "rcvals", 2L, &rcvals_dim);

   /* define variables */

   dims[0] = time_dim;
   status = nc_def_var (site_ncid, "time", NC_FLOAT, 1, dims, &time_id);
   status = nc_put_att_text (site_ncid, time_id, "units", strlen("months"), "months");

   dims[0] = nrows_dim;
   dims[1] = ncols_dim;
   status = nc_def_var (site_ncid, "mask", NC_LONG, 2, dims, &mask_id);

   dims[0] = ncells_dim;
   dims[1] = nouts_dim;
   status = nc_def_var (site_ncid, "fltvar", NC_FLOAT, 2, dims, &fltvar_id);

   dims[0] = ncells_dim;
   dims[1] = iouts_dim;
   status = nc_def_var (site_ncid, "intvar", NC_LONG, 2, dims, &intvar_id);

   dims[0] = rcvals_dim;
   status = nc_def_var (site_ncid, "rows", NC_INT, 1, dims, &rows_id);

   dims[0] = rcvals_dim;
   status = nc_def_var (site_ncid, "cols", NC_INT, 1, dims, &cols_id);

   dims[0] = rcvals_dim;
   status = nc_def_var (site_ncid, "calendar_year", NC_INT, 1, dims, &calyr_id);

   /* assign attributes */
   status = nc_put_att_text (site_ncid, NC_GLOBAL, "history", strlen(history), history);
   status = nc_put_att_text (site_ncid, time_id, "long_name", 
	strlen("output_time"), "output_time");
   status = nc_put_att_text (site_ncid, mask_id, "long_name", 
	strlen("simulated_cell_mask"), "simulated_cell_mask");
   status = nc_put_att_text (site_ncid, fltvar_id, "long_name", 
	strlen("float_variable_array"), "float_variable_array");
   status = nc_put_att_text (site_ncid, intvar_id, "long_name", 
	strlen( "integer_variable_array"), "integer_variable_array");
   status = nc_put_att_text (site_ncid, rows_id, "long_name", 
	strlen( "first_and_last_row"), "first_and_last_row");
   status = nc_put_att_text (site_ncid, cols_id, "long_name", 
	strlen( "first_and_last_col"), "first_and_last_col");
   status = nc_put_att_text (site_ncid, calyr_id, "long_name", 
	strlen( "first and final calendar years"), "first and final calendar years");

   /* leave define mode */
   status = nc_enddef (site_ncid);

   /* write starting and ending rows and cols information. -mdh 8/18/98 */
   rcstart[0] = 0;
   rccount[0] = 2;
   /* Must decrement the 2nd value of rows and cols to get ending indices */
   arows[0] = rows[0];
   arows[1] = rows[1] - 1;
   acols[0] = cols[0];
   acols[1] = cols[1] - 1;

   status = nc_put_vara_int(site_ncid, rows_id, rcstart, rccount, arows);
   status = nc_put_vara_int(site_ncid, cols_id, rcstart, rccount, acols);
   status = nc_put_vara_int(site_ncid, calyr_id, rcstart, rccount, calendar_year);

   status = nc_sync (site_ncid);

   return 0;
}
