// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TNcFile.cpp
//	Class:	  TNcFile
//
//	Description:
//	Polymorphic Base Class for managing netCDF files.
//	Always derive a class from this and implement the member functions
//	Read and Write for your specific data.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Dec97
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TNcFile.h"

// ----------------------------------------------------------------------------
//	member constants - protected
// ----------------------------------------------------------------------------

char const * const TNcFile::mwhoAttrName =	// modified by who
	"LastModifiedWho";
char const * const TNcFile::mwhenAttrName =	// modified when
	"LastModifiedWhen";
char const * const TNcFile::ftAttrName = 	// file type attribute name
	"FileType";
char const * const TNcFile::fvAttrName = 	// file version attribute name
	"Version";

// ----------------------------------------------------------------------------
//	member constants - private
// ----------------------------------------------------------------------------

char const * const TNcFile::badFVMsg = 		// bad file version message
	"File version greater than software version";
char const * const TNcFile::ivCFFileName =	// invalid "create from" name
	"Invalid file name in CreateFrom()";
char const * const TNcFile::badFTMsg = 		// bad file type message
	"Incorrect file type";
char const * const TNcFile::fileNFMsg	 =	// "file not found" message
	"File was not found";
char const * const TNcFile::fileInvMsg =	// "file invalid" message
	"Invalid file name";

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

TNcFile::TNcFile (
	TEH::TFileName const & file,	// netCDF file name
	TNcFileType const reqFileType,	// requested Century netCDF file type
	short const fileVersion)	// version number (highest)
	: ncFileType (reqFileType), version (fileVersion)
{
	Initialize ();
	// check file name
	if ( !file.IsValid() || file.IsEmpty() )
		ncErrStr = fileInvMsg;
	else
	{
		ncFileName = file;
		CheckExtension ();
		// check file type
		if ( reqFileType != NCFT_Unknown &&
		     !FileTypeMatches (reqFileType) )
			ncErrStr = badFTMsg;
		// check file version
		else if ( !FileVersionValid (fileVersion) )
			ncErrStr = badFVMsg;
		// Instance of the netCDF error handler
		if ( !ncErrStr )
			ncErr = new NcError (NcError::silent_nonfatal);
	}
}

TNcFile::~TNcFile ()
{
	ncFileName.Clear();
	Clear ();
}

//	Copy constructor
TNcFile::TNcFile (
	TNcFile const & object)
	: ncFileType (object.ncFileType),
	  version (object.version)
{
	Clear ();
	Copy (object);
}

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

TNcFile& TNcFile::operator= (
	TNcFile const & object)
{
	if (this != &object)	// check for assignment to self
	{
		// Note: Does not copy the const members!
		Clear ();
		Copy (object);
	}
	return *this;
}

bool TNcFile::operator== (
	TNcFile const & object) const
{
	return ( &object ? ( ncFileName == object.ncFileName &&
				ncFileType == object.ncFileType &&
				version == object.version )
		      : false );
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	OpenNcFile
//	Opens the netCDF file associated with ncFileName member variable,
//	with the access mode specified.
//	Returns false if successful, else true if open failed.
bool TNcFile::OpenNcFile (
	NcFile::FileMode const mode)
{
	if ( !ncFileName.IsValid() || ncFileName.IsEmpty() )
	{
		ncErrStr = fileInvMsg;
		return true;	// skip SetNcErrStr
	}
	//if ( mode != NcFile::New && mode != NcFile::Replace &&
	if ( (mode == NcFile::Replace || mode == NcFile::ReadOnly) &&
	     !ncFileName.Exists() )
	{
		ncErrStr = fileNFMsg;
		return true;
	}
	if ( isOpen )
		Clear ();
	std::string const toName = ncFileName.GetFullName ();
	if ( !toName.empty() )
	{
		::ncerr = NC_NOERR;	// netCDF lib global error code
		// open/create/replace the file
		ncFile = new NcFile (toName.c_str(), mode);
		isOpen = ncFile->is_valid();
	}
	SetNcErrStr();
	return !isOpen;
}

//	CloseNcFile
//	Closes the netCDF file associated with ncFile member variable.
void TNcFile::CloseNcFile ()
{
	if ( ncFile && isOpen )		// delete the file object
	{
		//ncFile->sync ();	==> can throw exception in version 3.50
		delete ncFile;
		ncFile = 0;
		isOpen = false;
	}
	if ( ncErr )			// delete the error object
	{
		delete ncErr;
	ncErr = 0;
	}
}

//	CreateFrom
//	Creates a new netCDF file, replacing the current one, if any.
//	The new file is created from template netCDF files, named in the
//	parameter variable "file".
//	Returns false if successful, else true if not.
bool TNcFile::CreateFrom (
	TEH::TFileName const & file)
{
	bool retVal = false;	// return error value
	Clear ();		// make sure previous v, d, a are deleted

	// check input file name
	if ( !file.IsValid () || file.IsEmpty() )
	{
		ncErrStr = ivCFFileName;
		return true;
	}
	CheckExtension ();

	// Read existing file structure
	NcFile fromNcFile ( file.GetFullName().c_str(), NcFile::ReadOnly );
	if ( fromNcFile.is_valid() )		// retrieve file structure
	{
		GetDims (&fromNcFile);
		if ( IsNcErr() )
			goto from_error_done;
		GetVars (&fromNcFile);
		if ( IsNcErr() )
			goto from_error_done;
		GetAtts (&fromNcFile);
		if ( IsNcErr() )
			goto from_error_done;
	}
	else
		goto from_error_done;

	// Write structure to new netCDF file
	NcFile::FileMode mode;
	if ( ncFileName.Exists() )
		mode = NcFile::Replace;
	else
		mode = NcFile::New;
	if ( !OpenNcFile (mode) )	// create file structure
	{
		if ( AddDims () )
			goto to_error_done;
		if ( AddVars () )
			goto to_error_done;
		if ( AddAtts () )
			goto to_error_done;
		goto all_done;
	}

from_error_done:
	// Error string saved in the "Get..." functions.
	retVal = true;
	goto all_done;

to_error_done:
	SetNcErrStr ();				// save error string
	retVal = true;

all_done:
	fromNcFile.close();
	CloseNcFile ();
	return retVal;
}

bool TNcFile::CreateFrom (
	char const * const file)
{
	TEH::TFileName fromFile (file);
	return CreateFrom (fromFile);
}

//	Clear
// 	"clear" data members
void TNcFile::Clear ()
{
	// close the netCDF file
	CloseNcFile ();
	// delete global attribute pointers since we own them
	if ( a )
	{
		for (short i = 0; i < numAtt; i++)
		{
			//Assert (a[i] != 0);
			delete a[i];
		}
		delete [] a;
	}
	// delete variable attribute pointers since we own them
	if ( v )
	{
		for (short i = 0; i < numVar; i++)
		{
			if ( v[i].a )
				for (short j = 0; j < v[i].numAtt; j++)
				{
					//Assert (v[i].a[j] != 0);
					delete v[i].a[j];
				}
		}
		// delete member arrays
		for (short i = 0; i < numVar; i++)
		{
			delete [] v[i].d;
			delete [] v[i].a;
		}
		delete [] v;
	}
	delete [] d;
	// initialize member variables
	Initialize ();
}

//	IsValid
// 	Returns true if a valid file, else false;
bool TNcFile::IsValid ()
{
	bool retVal = false;

	// Check if netCDF file name is valid
	if ( ncFileName.IsEmpty() ||
	     !ncFileName.IsValid () || !ncFileName.Exists() )
		goto all_done;
	// Check if netCDF file is valid
	if ( isOpen )
		retVal = ncFile->is_valid ();
	else
	{
		bool openedHere = false;
		if ( !isOpen )
		{
			if ( OpenNcFile (NcFile::ReadOnly) )
				goto all_done;		// error opening
			openedHere = true;
		}
		retVal = ncFile->is_valid ();
		if ( openedHere )
			CloseNcFile ();
	}
all_done:
	return retVal;
}

//	FileTypeMatches
//	Check file for matching type.
//	Returns true if type matches, else false if not.
//	Does NOT modify the member variable "ncFileType".
bool TNcFile::FileTypeMatches (
	TNcFileType const newType)
{
	// first check that file exists
	if ( !ncFileName.Exists() )
		return true;		// doesn't exist, so must match!

	// make sure file is open
	if ( !isOpen )					// file not open?
	{
		if ( OpenNcFile (NcFile::ReadOnly) )	// open failed?
			return false;			// ...yes
	}
	// check if the file type attribute exists
	bool retVal = false;				// return value
	NcAtt* attr = ncFile->get_att (ftAttrName);	// attribute pointer
	if ( attr && attr->is_valid() &&
	     ( attr->type() == ncShort || attr->type() == ncLong ) )
	{
		short value = attr->as_short(0);	// get the value
		if ( newType == (TNcFileType) value )	// matching file type?
			retVal = true;			// ...yes
	}
	// all done!
	delete attr;	// delete because owned by this
	return retVal;
}

//	FileVersionValid
//	Returns true if requested version >= file version,
//	or if could not check the file version number.
bool TNcFile::FileVersionValid (
	short const wantFileVersion)
{
	// first check that file exists
	if ( !ncFileName.Exists() )
		return true;		// doesn't exist, so must match!

	// make sure file is open
	if ( !isOpen )					// file not open?
	{
		if ( OpenNcFile (NcFile::ReadOnly) )	// open failed?
			return true;			// ...yes
	}
	// check if the file type attribute exists
	bool retVal = false;					// return value
	const NcAtt* attr = ncFile->get_att (fvAttrName);	// attribute
	if ( attr && attr->is_valid() &&
	     ( attr->type() == ncShort || attr->type() == ncLong ) )
	{
		versionFromFile = attr->as_short(0);		// get value
		if ( wantFileVersion >= versionFromFile )	// match?
			retVal = true;				// ...yes
	}
	// all done!
	delete attr;	// delete because owned by this
	return retVal;
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	AddOneAtt
//	Add one global attribute to the netCDF file.
//	Used to deal with the need to check for type of values.
//	Returns zero (false) if successful, else non-zero (true) if not.
template<class T>
int AddOneAtt (
	T ptr,  			// netCDF data type with member add_att
	NcAtt const * const att)	// attribute
{
	int err_val = 1;			// return success flag
	int numVals = att->num_vals ();		// number of values
	switch ( att->type() )
	{
	  case ncByte:
	  {
		ncbyte *p = new ncbyte [numVals];
		for (short i = 0; i < numVals; i++)
			p[i] = att->as_ncbyte (i);
		err_val = ptr->add_att ( att->name(), numVals, p );
		delete [] p;
		break;
	  }
	  case ncChar:	// assume C string with terminating NULL
		err_val = ptr->add_att ( att->name(), att->as_string(0) );
		break;
	  case ncShort:
	  {
		short *p = new short [numVals];
		for (short i = 0; i < numVals; i++)
			p[i] = att->as_short (i);
		err_val = ptr->add_att ( att->name(), numVals, p );
		delete [] p;
		break;
	  }
	  case ncLong:
	  {
		nclong *p = new nclong [numVals];
		for (short i = 0; i < numVals; i++)
			p[i] = att->as_nclong (i);
		err_val = ptr->add_att ( att->name(), numVals, p );
		delete [] p;
		break;
	  }
	  case ncFloat:
	  {
		float *p = new float [numVals];
		for (short i = 0; i < numVals; i++)
			p[i] = att->as_float (i);
		err_val = ptr->add_att ( att->name(), numVals, p );
		delete [] p;
		break;
	  }
	  case ncDouble:
	  {
		double *p = new double [numVals];
		for (short i = 0; i < numVals; i++)
			p[i] = att->as_double (i);
		err_val = ptr->add_att ( att->name(), numVals, p );
		delete [] p;
		break;
	  }
	  default:
		break;
	}
	return !err_val;
}

//	GetDims
//	Retrieves pointers to the dimensions of the netCDF file.
//	Returns the number of dimensions retrieved.
//	Assumes that the netCDF file already exists and that the member
//	variables v, d, and a have not been allocated memory.
short TNcFile::GetDims (
	NcFile const * const fromFile)
{
	if ( !fromFile )				// file initialized?
		return 0;
	short count = 0;				// count dims. read
	NcError myErr (NcError::silent_nonfatal);	// error handler
	numDim = (short)fromFile->num_dims ();		// number of dimensions
	if (numDim > 0)
	{
		d = new NcDim* [numDim];		// memory for array
		memset (d, '\0', sizeof(NcDim*)*numDim);
		for (short i = 0; i < numDim; i++)	// for each dim. name
		{
			d[i] = fromFile->get_dim ( i );
			if ( d[i] && !myErr.get_err() )
				count++;
			else
			{
				ncErrStr = ::nc_strerror ( myErr.get_err() );
				break;			// error!
			}
		}
	}
	return count;
}

//	GetVars
//	Retrieves pointers to the variables of the netCDF file.
//	Returns the number of variables  retrieved.
//	Assumes that the netCDF file already exists and that the member
//	variables v, d, and a have not been allocated memory.
short TNcFile::GetVars (
	NcFile const * const fromFile)
{
	if ( !fromFile )				// file initialized?
		return 0;
	short count = 0;				// count vars. read
	NcVar *tmpV;				// temp. pointer to variable
	TNcVar *vs;				// temp.  variable struct
	NcError myErr (NcError::silent_nonfatal);	// error handler
	numVar = (short)fromFile->num_vars (); 		// number of variables
	if (numVar > 0)
	{
		v = new TNcVar [numVar];		// allocate memory
		memset (v, '\0', sizeof(TNcVar)*numVar);
		for (short i = 0; i < numVar; i++)	// for each variable
		{
			vs = &v[i];				// struct ptr.
			vs->v = fromFile->get_var ( i );       	// var. ptr.
			tmpV = vs->v;				// local ptr.
			if ( !tmpV || myErr.get_err() )
				goto all_done;			// error!
			count++;
			vs->numDim = (short)tmpV->num_dims();	// no. of dims
			vs->d = new NcDim* [vs->numDim];    	// alloc memory
			memset (vs->d, '\0', sizeof(NcDim*)*vs->numDim);
			vs->numAtt = (short)tmpV->num_atts();	// no. of atts
			vs->a = new NcAtt* [vs->numAtt];    	// alloc memory
			memset (vs->a, '\0', sizeof(NcAtt*)*vs->numAtt);
			// get pointers to dimensions and attributes
			for (short j = 0; j < vs->numDim; j++)
			{
				vs->d[j] = tmpV->get_dim (j);
				if ( !(vs->d[j]) || myErr.get_err() )
					goto all_done;		// error!
			}
			for (short j = 0; j < vs->numAtt; j++)
			{
				vs->a[j] = tmpV->get_att (j);
				if ( !(vs->a[j]) || myErr.get_err() )
					goto all_done;		// error!
			}
			++count;
		}
	}
all_done:
	if ( myErr.get_err() )
		ncErrStr = ::nc_strerror ( myErr.get_err() );
	return count;
}

//	GetAtts
//	Retrieves pointers to the global attributes of the netCDF file.
//	Returns the number of attributes retrieved.
//	Assumes that the netCDF file already exists and that the member
//	variables v, d, and a have not been allocated memory.
short TNcFile::GetAtts (
	NcFile const * const fromFile)
{
	if ( !fromFile )				// file initialized?
		return 0;
	short count = 0;				// count atts. read
	NcError myErr (NcError::silent_nonfatal);	// error handler
	numAtt = (short)fromFile->num_atts ();		// number of attributes
	if (numAtt > 0)
	{
		a = new NcAtt* [numAtt];		// allocate memory
		memset (a, '\0', sizeof(NcAtt*) * numAtt);
		for (int i = 0; i < numAtt; i++)
		{
			a[i] = fromFile->get_att ( i );	// att. pointer
			if ( a[i] && !myErr.get_err() )
				count++;
			else
			{
				ncErrStr = ::nc_strerror ( myErr.get_err() );
				break;			// error!
			}
		}
	}
	return count;
}

//	AddDims
//	Adds dimensions to the netCDF file in member variable "ncFile".
//	Returns false if successful, else true if not.
bool TNcFile::AddDims ()
{
	bool ret_val = false;				// return value
	if ( !ncFile || numDim <= 0 )			// file initialized?
		return true;
	NcDim *newDim, *thisDim;			// temp. variables
	for (short i = 0; i < numDim; i++)		// for each dimension
	{
		thisDim = d[i];
		if ( thisDim->is_unlimited() )
			newDim = ncFile->add_dim ( thisDim->name() );
		else
			newDim = ncFile->add_dim ( thisDim->name(),
						   thisDim->size() );
		if ( !newDim || ncErr->get_err() )	// added ok?
		{
			ret_val = true;			// error!
			break;				// quit now
		}
	}
	return ret_val;
}

//	AddVars
//	Adds variables to the netCDF file in member variable "ncFile".
//	Returns false if successful, else true if not.
bool TNcFile::AddVars ()
{
	bool ret_val = false;				// return value
	if ( !ncFile || numVar <= 0 )			// file initialized?
		return true;
	NcVar *newVar, *thisVar;			// temp. variables
	for (short i = 0; i < numVar; i++)		// for each variable
	{
		// add variable
		thisVar = v[i].v;
		newVar = ncFile->add_var ( thisVar->name(),
					   thisVar->type(),
					   (int)v[i].numDim,
					   (const NcDim**)v[i].d );
		if ( !newVar || ncErr->get_err() )
		{
			ret_val = true;			// error!
			break;				// quit now
		}
		// add attributes
		for (short j = 0; j < v[i].numAtt; j++)
		{
			if ( AddOneAtt ( newVar, v[i].a[j] ) )
			{
				ret_val = true;		// error!
				break;			// quit now
			}
		}
	}
	return ret_val;
}

//	AddAtts
//	Adds global attributes to the netCDF file in member variable "ncFile".
//	Returns false if successful, else true if not.
bool TNcFile::AddAtts ()
{
	bool ret_val = false;				// return value
	if ( !ncFile || numAtt <= 0 )			// file initialized?
		return true;
	NcAtt* thisAtt;					// temp. variables
	for (short i = 0; i < numAtt; i++)		// for each attribute
	{
		thisAtt = a[i];
		if ( AddOneAtt ( ncFile, thisAtt ) )
		{
			ret_val = true;			// error!
			break;				// quit now
		}
	}
	return ret_val;
}

//	SetNcErrStr
//	Retrieve the netCDF error string corresponding to the value
// 	returned by the NcError member function get_err.
//	Returns true if a netCDF error was detected, else false if no error.
//	Sets the member variables ncErrStr and ncErrFlag.
bool TNcFile::SetNcErrStr ()
{
	ncErrFlag = false;
	ncErrStr = 0;
	if ( ncErr )
	{
		ncErrFlag = ( ncErr->get_err() != NC_NOERR );
		if ( ncErrFlag )
			ncErrStr = ::nc_strerror ( ncErr->get_err() );
	}
	return ncErrFlag;
}

//	CheckExtension
//	Sets extension to "nc" if not already.
//	Assumes the member variable ncFileName is already set.
void TNcFile::CheckExtension ()
{
	static char const * const extStr = "nc";	// extension value
	if ( ncFileName.GetExtension() != extStr )	// not == "nc"?
		ncFileName.SetExtension (extStr);
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Initialize
//	Initialize member variables.
void TNcFile::Initialize ()
{
	ncFile = 0;
	ncErr = 0;
	ncErrStr = 0;
	ncErrFlag = false;
	v = 0;
	a = 0;
	d = 0;
	numVar = numAtt = numDim = 0;
	isOpen = modified = false;
	versionFromFile = 0;
}

//	Copy
// 	Copy the TNcFile object to this.
void TNcFile::Copy (
	const TNcFile &fromObj)
{
	if ( &fromObj )
	{
		ncFileName = fromObj.ncFileName;
	}
	// Note:
	// The remaining member variables assume the netCDF file is
	// opened, and the variable and dimension pointers are owned
	// by the instance in "fromObj".
	// So, here we'll use the simplest case and not attempt to copy
	// the open object's variables. The file will have to be opened
	// and read again from this copy in order to access the structure.
	// Also, the "CreateFrom" function should be used to duplicate
	// the fromObj file.
}

//--- end of T_NcFile.cpp ---
