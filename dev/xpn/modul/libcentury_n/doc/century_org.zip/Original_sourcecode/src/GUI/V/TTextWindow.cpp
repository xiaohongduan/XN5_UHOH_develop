// ----------------------------------------------------------------------------
//	Project:  Century Model Interface - V GUI
//	File:	TTextWindow.cpp
//
//	Class Type for GUI Window: TTextWindow
//	Overrides vTextEditor
//
//	Author:	Tom Hilinski, Feb98, tom.hilinski@colostate.edu
// ----------------------------------------------------------------------------

#include "TTextWindow.h"
#include <v/vapp.h>
#include <v/vcmdwin.h>
#include <cstring>

// ----------------------------------------------------------------------------
//	Popup Menu
// ----------------------------------------------------------------------------

vMenu TTextWindow::popupMenuDef[] =
{
  {"Copy", M_Copy, notSens, notChk, noKeyLbl, noKey, noSub},
  {"-", M_Line, notSens, notChk, noKeyLbl, noKey, noSub},
  {"Change Font", M_Font, isSens, notChk, noKeyLbl, noKey, noSub},
  {"-", M_Line, notSens, notChk, noKeyLbl, noKey, noSub},
  {"Exit", M_Exit, isSens, notChk, noKeyLbl, noKey, noSub},
  {NULL}
};



//--- constructors and destructor

TTextWindow::TTextWindow (
	vCmdWindow * const parent,	// modified by vCanvasPane
	const bool readOnlyFlag, 	// true if file is read-only
	const bool userCloseFlag)	// true if user can close win.
	: vTextEditor (parent)
{
	// save member flags
	readOnly = readOnlyFlag;
	userClose = userCloseFlag;

	// set local editor flags
	edState localState = GetEdState ();	// retrieve editor state
	localState.readOnly = (int)readOnly;	// read-only window?
	SetEdState ( localState );		// set editor state

	// set global  editor flags
	globalState state = GetGlobalState ();	// retrieve editor state
	state.tabspc = 4;			// tab spacing
	SetGlobalState ( state );		// set editor state

	// initialize buffer
	buf = 0;
	bufLen = 0;

	// create the popup menu
	popupMenu.reset (
		new vPopupMenu ( popupMenuDef,
				 dynamic_cast<vWindow* const>(parent) ) );
}

TTextWindow::~TTextWindow ()
{
	delete [] buf;
}


//--- overridden methods

void TTextWindow::TextMouseDown (int row, int col, int button)
{
	if (button == 3)		// check for right button press
	{
		// setup the menu items
		if ( SelectionLen() > 0 )
			popupMenu->SetValue (M_Copy, isSens, Sensitive);
		else
			popupMenu->SetValue (M_Copy, notSens, Sensitive);

		// display the popup menu
		if ( popupMenu->isImplemented() )
			//popupMenu->ShowMenu ( col, row );
			popupMenu->ShowMenu ( ColToX(col), RowToY(row) );
	}
	else				// default action otherwise
		vTextEditor::TextMouseDown (row, col, button);
}


//--- public functions

// Note: This should be rewritten so it doesn't redisplay the entire
// buffer each time.
void TTextWindow::AppendText (
	char const * const text)
{
	// initialize local output buffer
	short const len = static_cast<short>( strlen (text) );
	if ( bufLen < len )
	{
		delete [] buf;
		buf = new char [len + 1];
		bufLen = len;
	}

	// Add text line-by-line, since vTextEditor stops writing when
	// a newline is encountered.
	register char *cp = buf,
		      *cpBeg = buf,
		      *cpEnd = buf + len;
	strcpy (buf, text);
	while ( cp <= cpEnd )
	{
		if ( *cp == '\n' || *cp == '\r' || !(*cp) )
		{
			*cp = '\0';		// terminate line
			vTextEditor::addLine (cpBeg);
			++cp;			// advance
			cpBeg = cp;
		}
		else
			++cp;			// advance
	}
	// display new lines
	if ( buf )
	{
		displayBuff ();
		EditCommand (edBufferBottom, 0);
	}
}

void TTextWindow::CloseWin ()
{
	// Only close window if exiting the application or
	// if the userClose flag is true.
	if ( theApp->InExit() || userClose )
		_parentWin->CloseWin ();
}

