#ifndef INC_TSimTime_h
#define INC_TSimTime_h
// ----------------------------------------------------------------------------
//	Copyright 1999-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TSimTime.h
//	Class:	  TSimTime
//
//	Description:
//	Variables and functions dealing with simulation time.
//	This class is entirely inline. There is no .cpp file.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Feb99
// ----------------------------------------------------------------------------
//	History:
//	May99	Tom Hilinski
//	* Fixed bug in calculation of writeMonth and writeYear in
//	  member function IncrementOutput.
//	* Added member function SetOutputFreq.
//	Dec00	Tom Hilinski
//	* Added member function IsEndOfYear
//	Jun01	Tom Hilinski
//	* Added copy constructor, operator=
//	Jun02	Tom Hilinski
//	* Added virtual destructor for inheritance.
//	* Made lots of functions virtual for derived replacement.
//	* Changed month enum names to TMonth.
//	* Added typedefs to year, day.
//	Nov02   Tom Hilinski
//	* minor comments and cleanup
//	Apr03	Tom Hilinski
//	* UpdateFloatTime returns floating point time.
//	Sep04	Tom Hilinski
//	* Moved typedefs for time into timetypes.h
// ----------------------------------------------------------------------------

#include "timetypes.h"

class TSimTime
{
  public:
    //--- types

    //--- data
    				//--- simulation timing
    TYear year;			// current simulation year
    TMonth month;		// current simulation month
    TYear startYear,		// simulation start year
	  endYear;		// simulation end year
    				//--- Simulation time steps
    float dt;			// monthly time step
    				//    units = year / month
    float dtDecomp;		// time step used for the decomposition model
				//    units = year / day
    float time;			// simulation time in years + fraction of year
    				// This is a kluge since flow routines are all
    				// in float units (historical thing).
				//--- management timing
    TYear blockStartYear,	// simulation time for block to start
	  blockEndYear;		// simulation time for block to end
				//--- output timing
    TYear writeYear;		// year variables should be written to output
    short writeMonth;		// month variables should be written to output
    short dtWriteMonth,		// output time step - months
	  dtWriteYear;		// output time step - years

	//--- constructor
	TSimTime ()
	  {
	    Initialize ();
	  }
	virtual ~TSimTime ()
	  {
	  }
	TSimTime (TSimTime const & object)	// copy constructor
	  {
	    Copy (object);
	  }

	//---- operator overloads
	TSimTime& operator= (TSimTime const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
		Copy (object);
	    }
	    return *this;
	  }

    //--- functions
    void Initialize ()
      {
    	year = startYear = endYear = blockStartYear = blockEndYear =
		writeYear = 0;
	month = Jan;
	writeMonth = dtWriteMonth = dtWriteYear = (short)0;
    	time = 0.0f;
    	// simulation time step is fixed at 1 month
    	dt = 1.0f / (float)monthsPerYear;	// calc for machine precision.
	// There are 4 time steps per simulation time step for decomp.
	// dtDecomp is the time step used in decomp.
	// This multiple is actually specified in the fix.100 parameter NTSPM
	dtDecomp = dt / 4.0f;	// default = 4 times per month
      }
    virtual void SetOutputFreq (
      float const outputFreq)		// output frequency
      {
	dtWriteYear = (short)outputFreq;	// integer and fraction parts
	dtWriteMonth =
	    (short)((outputFreq - dtWriteYear) * (float)monthsPerYear + 0.5f);
      }
    virtual void Increment ()		// increments the simulation time
      {
	if ( month == Dec )		// end of year?
	{
		++year;			// ...next simulation year
		month = Jan;		// ...1st month
	}
	else			// ...no, increment month
		month = (TMonth)((int)month + 1);
	UpdateFloatTime ();		// calc floating point time
      }
    virtual void IncrementOutput ()	// increments the output time
      {
	writeYear += dtWriteYear;
	writeMonth += dtWriteMonth;
	if (writeMonth > (short)Dec)
	{
		++writeYear;
		writeMonth %= (short)monthsPerYear;
		if ( writeMonth == (short)0 )
			writeMonth = (short)monthsPerYear;
	}
      }
    virtual float UpdateFloatTime ()	// FP time uses zero-based year
      {
    	time = (float)year + (float)(month - 1) / (float)monthsPerYear;
    	return time;
      }
    virtual bool AtSimulationEnd ()	// true if at simulation end time
      {
	return ( year == endYear && month == Dec );
      }
    virtual bool AtSimulationStart ()	// true if at start of simulation
      {
	return ( year == startYear && month == Jan );
      }
    virtual bool IsBlockStart ()	// true if at start year/month of block
      {
	return ( year == blockStartYear && month == Jan );
      }
    virtual bool AtBlockEnd ()	// true if time to retrieve info for mgmt block
      {
	return ( blockEndYear == year && month == Dec );
      }
    virtual bool TimeForOutput ()	// true if time to write output
      {
	return ( writeYear == year && month == writeMonth );
      }
    virtual bool IsStartOfYear ()	// true if month is January
      {
	return ( month == Jan );
      }
    virtual bool IsEndOfYear ()		// true if month is December
      {
	return ( month == Dec );
      }
    long SimYears ()		// returns number of years requested
      {
    	return endYear - startYear + 1L;
      }

  private:
	//--- functions
	void Copy (TSimTime const & object)	// Copy to this
	  {
	    if ( &object )
	    {
		year = object.year;
		month = object.month;
		startYear = object.startYear;
		endYear = object.endYear;
		dt = object.dt;
		dtDecomp = object.dtDecomp;
		time = object.time;
		blockStartYear = object.blockStartYear;
		blockEndYear = object.blockEndYear;
		writeYear = object.writeYear;
		writeMonth = object.writeMonth;
		dtWriteMonth = object.dtWriteMonth;
		dtWriteYear = object.dtWriteYear;
	    }
	  }
};

#endif // INC_TSimTime_h
