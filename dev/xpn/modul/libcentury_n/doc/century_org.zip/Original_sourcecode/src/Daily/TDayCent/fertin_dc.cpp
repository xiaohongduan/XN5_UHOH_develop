// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  fertin.cpp
//	Class:	  TDayCent
//	Function: GetFertilization
//
//	Description:
//	Read the new fertilization parameter set.
//	Returns true if successful match in database, else false if not.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
// ----------------------------------------------------------------------------
//	History:
//      See Century/fertin.cpp
//      Aug01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Changed this function from TCentury to TDayCent member
//      12Sep01 Melannie Hartman, melannie@nrel.colostate.edu
//      * Read new parameter param.nitrateFertFrac
// ----------------------------------------------------------------------------
//      Notes:
// ----------------------------------------------------------------------------

#include "TDayCent.h"
#include "TEventDBList.h"
#include "util.h"
#include "constants.h"

bool TDayCent::GetFertilization (char const* fertToMatch)
{
	// error checks
	if ( !fertToMatch || !(*fertToMatch) )		// anything there?
		return false;

	char const * const strInvVal = "Invalid Value: ";
	float const minFloat = 1.0e-10f;  // minimum acceptable float value
        std::string msg;

	// get the option set
	TEventOptionSet const & optionSet =
		*paramDbList->Get (TEventDBList::DBI_Fert);
	if ( !&optionSet )				// database not there?
		ThrowCentException (TCentException::CE_NSPPDB,
			::eventName[ET_Fertilize]);
	if ( !optionSet.GetOptionCount () )		// empty database?
		ThrowCentException (TCentException::CE_EMPPDB,
			::eventName[ET_Fertilize]);

	// get the option matching the parameter string
    	TEventOption const * const option = optionSet.GetOption (fertToMatch);
	if ( !option )					// match found?
		return false;

	// retrieve values from option and save in Century's variables
        //short const numParams = 4;			// total for an option
	short const numParams = 5;			// total for an option
	short count = option->GetParamCount ();
	if ( count != numParams )			// counts match?
		ThrowCentException (TCentException::CE_OPCBAD,
			::eventName[ET_Fertilize]);

	register short k = 0;			// index to param values
    	for (short i = 0; i < 3; ++i)
		param.feramt[i] = option->GetParameter(k++)->value;
	param.aufert = option->GetParameter(k++)->value;
        // Added nitrateFertFrac -mdh 9/12/01
        param.nitrateFertFrac = option->GetParameter(k)->value;
        if ( param.nitrateFertFrac < minFloat ||
             param.nitrateFertFrac > 1.0f )
        {
            msg = strInvVal;
            msg += "NO3FRAC < 0.0 or NO3FRAC > 1.0 for fertilization ";
            msg += fertToMatch;
            ThrowDayCentException ( TDayCentException::DCE_VORFER,
            				msg.c_str() );
        }

	// save option name in Century class variable
	strcpy (sched->curFert, fertToMatch);
	return true;
}

//--- end of fertin.cpp ---/

