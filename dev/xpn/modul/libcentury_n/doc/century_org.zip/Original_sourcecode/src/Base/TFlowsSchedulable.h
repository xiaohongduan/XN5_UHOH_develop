#ifndef INC_TFlowsSchedulable_h
#define INC_TFlowsSchedulable_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  TFlowsSchedulable.h
//	Class:	  TFlowsSchedulable
//
//	Description:
//	Base class for a model object that can schedule and perform flows
//	via the class TFlow.
//	Responsibilities:
//	* Owns an instance of TFlow.
//	* Provides a protected interface to its data and functions.
//	* Cannot be directly instantiated.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include <memory>
#include "TFlow.h"
#include "centconsts.h"
#include "precision.h"

class TFlowsSchedulable
{
  public:
	//---- operator overloads

	//---- functions
	void  DoFlows (			// Do the flows
	  float const time)		//   at simulation time
	  {
	    flows->FlowUp (time);
	  }
	void ScheduleCFlow (		// Flow between C pools
	  float const simTime,		//   simulation time
	  float const totalCFlow,	//   total C flow from Box A to Box B
	  float const labeledFraction,	//   labeled fraction of total flow
	  float const fractionation,	//   amount of fractionation
	  float* const srcUnlabeledC,	//   source: unlabeled C in Box A
	  float* const destUnlabeledC,	//   destination: unlabeled C in Box B
	  float* const srcLabeledC,	//   source: labeled C in Box A
	  float* const destLabeledC,	//   destination: labeled C in Box B
	  float* const accum)		//   cum. C, [0]=unlabeled, [1]=labeled
	  {
	    if ( AmountIsSignificant (totalCFlow) )
	    {
		// amounts of C to flow for each isotope
		float const labeledCFlow =
			totalCFlow * labeledFraction * fractionation;
		float const unlabeledCFlow = totalCFlow - labeledCFlow;

		// Flow the amounts
		SCHEDULE_FLOW( flows,
			srcUnlabeledC, destUnlabeledC,
			simTime, unlabeledCFlow );
		accum[UNLABL] += unlabeledCFlow;	// return accumulation
		if ( labeledCFlow != 0.0f )
		{
		    SCHEDULE_FLOW( flows,
			srcLabeledC, destLabeledC,
			simTime, labeledCFlow );
		    accum[LABELD] += labeledCFlow;	// return accumulation
		}
	    }
	  }
	void ScheduleCFlow (		// Flow between C pools
	  float const simTime,		//   simulation time
	  float const totalCFlow,	//   total C flow from Box A to Box B
	  float const labeledFraction,	//   labeled fraction of total flow
	  float const fractionation,	//   amount of fractionation
	  float* const srcUnlabeledC,	//   source: unlabeled C in Box A
	  float* const destUnlabeledC,	//   destination: unlabeled C in Box B
	  float* const srcLabeledC,	//   source: labeled C in Box A
	  float* const destLabeledC)	//   destination: labeled C in Box B
	  {
	    if ( AmountIsSignificant (totalCFlow) )
	    {
		// amounts of C to flow for each isotope
		float const labeledCFlow =
			totalCFlow * labeledFraction * fractionation;
		float const unlabeledCFlow = totalCFlow - labeledCFlow;

		// Flow the amounts
		SCHEDULE_FLOW(flows,
			srcUnlabeledC, destUnlabeledC,
			simTime, unlabeledCFlow );
		if ( labeledCFlow != 0.0f )
		    SCHEDULE_FLOW(flows,
			srcLabeledC, destLabeledC,
			simTime, labeledCFlow );
	    }
	  }
	void Clear ()					// "Clear" data members
	  {
	    flows->Clear ();
	  }

	//---- functions: Queries

  protected:
	//---- constants

	//---- data
	std::auto_ptr<TFlow> flows;		// flows

	//---- functions

	//---- constructors and destructor
	TFlowsSchedulable ()
	  {
	    Initialize ();
	  }
	virtual ~TFlowsSchedulable ()
	  {
	    Clear ();
	  }
	TFlowsSchedulable (
	  TFlowsSchedulable const & object)
	  {
	    Initialize ();
	    Copy (object);
	  }

  private:
	//---- constants

	//---- data

	//---- functions
	void Initialize ()				// Initialize members
	  {
	    flows.reset ( new TFlow () );
	  }
	void Copy (TFlowsSchedulable const & object)	// Copy to this
	  {
	    if ( &object )
	    {
		flows.reset ( new TFlow (*object.flows) );
	    }
	  }
};

#endif // INC_TFlowsSchedulable_h
