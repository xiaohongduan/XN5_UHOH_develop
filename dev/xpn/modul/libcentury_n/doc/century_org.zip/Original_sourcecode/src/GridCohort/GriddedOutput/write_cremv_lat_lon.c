
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Rewrite the cremv.nc netCDF file using COARDS standards */
/* The original file was organized variable(cell, time) */
/* The new file is organized variable(time, lat, lon) */

#include <stdio.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf_ll.h"

    int write_cremv_ll_(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  shremc_vals[MAXCELLS], sdremc_vals[MAXCELLS], rlvremc_vals[MAXCELLS],
             fbrremc_vals[MAXCELLS], rlwremc_vals[MAXCELLS], wd1remc_vals[MAXCELLS],
             wd2remc_vals[MAXCELLS], stremc_vals[MAXCELLS], metrmc_vals[MAXCELLS];
      int status;
      int oldcremvid;
      int oldshremcid, oldsdremcid, oldrlvremcid, oldfbrremcid, oldrlwremcid,
          oldwd1remcid, oldwd2remcid, oldstremcid, oldmetrmcid;
      int ii, jj, ngrids;

      /* Open old version of cremv.nc file */
      status = nc_open("cremv.nc", NC_NOWRITE, &oldcremvid);
      if (status != NC_NOERR) handle_error("nc_open(cremv.nc)", status);

      /* Get the indices for the cremv output variables */
      status = nc_inq_varid(oldcremvid, "shremc", &oldshremcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for shremc",status);
      status = nc_inq_varid(oldcremvid, "sdremc", &oldsdremcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for sdremc",status);
      status = nc_inq_varid(oldcremvid, "rlvremc", &oldrlvremcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for rlvremc",status);
      status = nc_inq_varid(oldcremvid, "fbrremc", &oldfbrremcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for fbrremc",status);
      status = nc_inq_varid(oldcremvid, "rlwremc", &oldrlwremcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for rlwremc",status);
      status = nc_inq_varid(oldcremvid, "wd1remc", &oldwd1remcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wd1remc",status);
      status = nc_inq_varid(oldcremvid, "wd2remc", &oldwd2remcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wd2remc",status);
      status = nc_inq_varid(oldcremvid, "stremc", &oldstremcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for stremc",status);
      status = nc_inq_varid(oldcremvid, "metrmc", &oldmetrmcid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for metrmc",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        shremc_vals[ii] = fill;
        sdremc_vals[ii] = fill;
        rlvremc_vals[ii] = fill;
        fbrremc_vals[ii] = fill;
        rlwremc_vals[ii] = fill;
        wd1remc_vals[ii] = fill;
        wd2remc_vals[ii] = fill;
        stremc_vals[ii] = fill;
        metrmc_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the cremv output file */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldcremvid, oldshremcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for shremc",status);
            }
            shremc_vals[jj] = val;
            status = nc_get_var1_float(oldcremvid, oldsdremcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for sdremc",status);
            }
            sdremc_vals[jj] = val;
            status = nc_get_var1_float(oldcremvid, oldrlvremcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for rlvremc",status);
            }
            rlvremc_vals[jj] = val;
            status = nc_get_var1_float(oldcremvid, oldfbrremcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for fbrremc",status);
            }
            fbrremc_vals[jj] = val;
            status = nc_get_var1_float(oldcremvid, oldrlwremcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for rlwremc",status);
            }
            rlwremc_vals[jj] = val;
            status = nc_get_var1_float(oldcremvid, oldwd1remcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wd1remc",status);
            }
            wd1remc_vals[jj] = val;
            status = nc_get_var1_float(oldcremvid, oldwd2remcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wd2remc",status);
            }
            wd2remc_vals[jj] = val;
            status = nc_get_var1_float(oldcremvid, oldstremcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for stremc",status);
            }
            stremc_vals[jj] = val;
            status = nc_get_var1_float(oldcremvid, oldmetrmcid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for metrmc",status);
            }
            metrmc_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(cremvll_ncid, shremcll_id, start, count, shremc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for shremc",status);
        status = nc_put_vara_float(cremvll_ncid, sdremcll_id, start, count, sdremc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for sdremc",status);
        status = nc_put_vara_float(cremvll_ncid, rlvremcll_id, start, count, rlvremc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for rlvremc",status);
        status = nc_put_vara_float(cremvll_ncid, fbrremcll_id, start, count, fbrremc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for fbrremc",status);
        status = nc_put_vara_float(cremvll_ncid, rlwremcll_id, start, count, rlwremc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for rlwremc",status);
        status = nc_put_vara_float(cremvll_ncid, wd1remcll_id, start, count, wd1remc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wd1remc",status);
        status = nc_put_vara_float(cremvll_ncid, wd2remcll_id, start, count, wd2remc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wd2remc",status);
        status = nc_put_vara_float(cremvll_ncid, stremcll_id, start, count, stremc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for stremc",status);
        status = nc_put_vara_float(cremvll_ncid, metrmcll_id, start, count, metrmc_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for metrmc",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldcremvid);

      return 0;
    }
