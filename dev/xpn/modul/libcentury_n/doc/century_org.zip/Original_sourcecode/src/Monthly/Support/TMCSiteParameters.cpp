// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TSiteParam.cpp
//	Class:	  TSiteParameter, TSiteParamSet, TMCSiteParameters
//
//	Description:
//	Classes for Century site file parameters (formerly "<site>.100" files).
//	An associated class is TMCSiteParamInfo which holds the site parameter
//	names and definition text.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Feb98, tom.hilinski@colostate.edu
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TMCSiteParameters.h"
#include "TNcFileSitePar.h"		// always after T_SiteParam.h
#include "AssertEx.h"
#include "SiteException.h"
using ::nrel::site::SiteException;
#include <vector>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <cstring>
#include <cctype>
using namespace std;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

//	default values for site parameters

float const EFLCU_DEFAULTS[5][2] = 	// unlabeled C loss
		{ { 0.9, 0.1 },		// respired & dissolved active pool
		  { 0.0, 0.0 },		// respired & dissolved slow pool pool
		  { 0.0, 0.0 },		// respired & dissolved passive pool
		  { 0.0, 0.0 },		// respired & dissolved structural pool
		  { 0.9, 0.1 } };	// respired & dissolved metabolic pool
float const EFLCL_DEFAULTS[5][2] = 	// labeled C loss
		{ { 0.9, 0.1 },		// respired & dissolved active pool
		  { 0.0, 0.0 },		// respired & dissolved slow pool pool
		  { 0.0, 0.0 },		// respired & dissolved passive pool
		  { 0.0, 0.0 },		// respired & dissolved structural pool
		  { 0.9, 0.1 } };	// respired & dissolved metabolic pool
float const EFLN_DEFAULTS[5][2] = 	// N loss
		{ { 0.9, 0.1 },		// respired & dissolved active pool
		  { 0.0, 0.0 },		// respired & dissolved slow pool pool
		  { 0.0, 0.0 },		// respired & dissolved passive pool
		  { 0.0, 0.0 },		// respired & dissolved structural pool
		  { 0.9, 0.1 } };	// respired & dissolved metabolic pool

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

TMCSiteParameters::TMCSiteParameters (
	std::string const & useTmpltPath,	// template files
	std::string const & useWorkPath,	// working directory
	TMCSiteParamInfo::TInfoPtr useInfo)	// parameter descriptions
	: TSiteParamUnknown (useInfo)
{
	Initialize ();
	SetPaths (useTmpltPath, useWorkPath);
	if ( !CheckInfo<TMCSiteParamInfo> (info) ) // param info read failed?
	{
		Clear ();
		SiteParamDefException ("TMCSiteParameters");
	}
	CreateZeroedSets ();
}

TMCSiteParameters::TMCSiteParameters (
	char const * const useTmpltPath,	// template files
	char const * const useWorkPath,		// working directory
	TMCSiteParamInfo::TInfoPtr useInfo)	// parameter descriptions
	: TSiteParamUnknown (useInfo)
{
	Initialize ();
	SetPaths (useTmpltPath, useWorkPath);
	if ( !CheckInfo<TMCSiteParamInfo> (info) ) // param info read failed?
	{
		Clear ();
		SiteParamDefException ("TMCSiteParameters");
	}
	CreateZeroedSets ();
}

TMCSiteParameters::TMCSiteParameters (
	TEH::TFileName const & useFileName,	// site file name
	char const * const useTmpltPath,	// template files
	char const * const useWorkPath,		// working directory
	TMCSiteParamInfo::TInfoPtr useInfo)	// parameter descriptions
	: TSiteParamUnknown (useInfo)
{
	Initialize ();
	SetPaths (useTmpltPath, useWorkPath);
	if ( !CheckInfo<TMCSiteParamInfo> (info) ) // param info read failed?
	{
		Clear ();
		SiteParamDefException ("TMCSiteParameters");
	}
	else if ( Read (useFileName) )		   // read parameters failed?
	{
		Clear ();
		SiteParamReadException (
			"TMCSiteParameters",
			useFileName.GetFullName().c_str() );
	}
}

TMCSiteParameters::TMCSiteParameters (
	char const * const useFileName, 	// site file name
	char const * const useTmpltPath,	// template files
	char const * const useWorkPath,		// working directory
	TMCSiteParamInfo::TInfoPtr useInfo)	// parameter descriptions
	: TSiteParamUnknown (useInfo)
{
	Initialize ();
	SetPaths (useTmpltPath, useWorkPath);
	if ( !CheckInfo<TMCSiteParamInfo> (info) ) // param info read failed?
	{
		Clear ();
		SiteParamDefException ("TMCSiteParameters");
	}
	else if ( Read (useFileName) )		   // read parameters failed?
	{
		Clear ();
		SiteParamReadException ( "TMCSiteParameters", useFileName );
	}
}

TMCSiteParameters::TMCSiteParameters (
	std::string const & useFileName, 	// site file name
	std::string const & useTmpltPath,	// template files
	std::string const & useWorkPath,	// working directory
	TMCSiteParamInfo::TInfoPtr useInfo)	// parameter descriptions
	: TSiteParamUnknown (useInfo)
{
	Initialize ();
	SetPaths (useTmpltPath, useWorkPath);
	if ( !CheckInfo<TMCSiteParamInfo> (info) ) // param info read failed?
	{
		Clear ();
		SiteParamDefException ("TMCSiteParameters");
	}
	else if ( Read (useFileName) )		   // read parameters failed?
	{
		Clear ();
		SiteParamReadException (
			"TMCSiteParameters",
			useFileName.c_str() );
	}
}

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

//	Assignment
TMCSiteParameters& TMCSiteParameters::operator= (
	TMCSiteParameters const & object)
{
	if (this != &object)	// check for assignment to self
	{
		TBaseClass::operator= (object);
		Copy (object);
	}
	return *this;
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	Clear
//	Erases member variables.
void TMCSiteParameters::Clear ()
{
	TBaseClass::Clear ();
	filePath.Clear();
	Initialize ();
}

//	GetFileType
//	Returns the type of the specified file.
TSiteParamFileType TMCSiteParameters::GetFileType (
	TEH::TFileName const & fileName)
{
	TSiteParamFileType retVal = SPFT_Unknown;

	// check for file type
	if ( fileName.IsValid() )
	{
		std::string const & ext = fileName.GetExtension();
		if ( !ext.empty() )			// anything there?
		{
			if ( ext == "100" )		// Century 4 file?
				retVal = SPFT_Century4;
			else				// netCDF file?
			{
				if ( tolower(ext[0]) == 'n' &&
				     tolower(ext[1]) == 'c' &&
				     ext.size() == 2 )
				{
					retVal = SPFT_netCDF;
				}
			}
		}
	}
	return retVal;
}

//	ImportCent4File
//	Import a Century 4.0 parameter (".100") file.
//	Returns false upon success, else true if not.
bool TMCSiteParameters::ImportCent4File ()
{
	char const * const myName = "TMCSiteParameters::ImportCent4File";

	// error checks
	if ( GetFileType(filePath) != SPFT_Century4 )	// valid for import?
		return true;				// ...no

	// local variables and constants
	bool retVal = false;				// default = success

	//--- define a set to hold one set of parameters
	TSiteParamSet set;				// one set
	TSiteParameter param;				// one parameter
	// find maximum set size
	short maxNumParams = 0;		// maximum number of parameters
	for ( short i = 0; i < indices.GetSetCount(); i++ )
		maxNumParams = std::max (maxNumParams, indices.siteSetCount[i]);
	// set vector capacity to the maximum needed
	set.ParameterList().reserve (maxNumParams);

	// Create an array of bools to flag
	// which parameters have been imported successfully:
	// The order is the same as the parameter names stored in
	// the class TMCSiteParamInfo.
	std::vector<bool> haveParam (maxNumParams, false);

	// save file name
	fileType = SPFT_Century4;
	std::string const fileName = filePath.GetFullName();
	retVal = SetBaseName ( fileName );		// set default base
	if ( retVal )
	{
		if ( !errStr.empty() )
			errStr += NL_CHAR;
		errStr += "Error setting the name of the site parameters file.";
		return true;
	}

	// Import the sets and their parameters
	// Assumptions:
	// For each file, internal consistancy is required!
	//  > format of lines is not checked, so no format errors
	//  > 1st line of file = 2 strings, site name and description
	//  > 1st line of set set starts with "***"
	//  > parameter names are not duplicated within each set
	//  > input line lengths do not exceed 100 characters
	//  > 1st char of line always != alpha for param. value + name lines
	//  > 1st char of line always == alpha for set name + desc. lines
	//  > same number of parameters for each set
	//  > parameters names are always in upper case

	// open the file as read only
	ifstream ifs;					// input file stream
	ifs.open (fileName.c_str(), ios::in);		// open stream
	if ( !ifs.good() )
	{
		if ( !errStr.empty() )
			errStr += NL_CHAR;
		errStr += "Failed opening the site parameters file.";
		return true;
	}

	// temporary variables
	short const maxLengthLine = 1023;
	char line[maxLengthLine + 1];			// receives input line
	*line = NULL_CHAR;
	short const nameLen = 29 + 1;
	short const descLen = maxDescLen + 1;

	// 0. read comment header
	std::string header;
	while (true)
	{
	    ifs.getline (line, maxLengthLine);
	    if ( ifs.good() )
	    {
	    	if ( IsComment(line) )		// save it
	    	{
			header += line;
			header += NL_CHAR;
	    	}
		else
		{
			break;			// no more comments
		}
	    }
	    else if ( !ifs.eof() )		// not good!
	    {
		// should not get here
		errStr += "The file stream has an error.";
		goto error_done;
	    }
	    else // eof
	    	goto all_done;
	}
	// to do: save header in site object

	// 1. get the name and description of the site
	// ifs.getline (line, maxLengthLine); // read in step 0
	if ( ifs.good() )
	{
		::strtrim (line);
		istrstream ils (line, strlen(line));	// stream for line
		char tmpStr[maxLengthLine + 1];
		tmpStr[0] = NULL_CHAR;
							// get name
		ils.width (nameLen);
		ils >> ws >> tmpStr;
		if ( tmpStr )
			name = tmpStr;
							// get description
		ils.width (descLen);
		ils >> ws;
		tmpStr[0] = NULL_CHAR;
		ils.getline (tmpStr, maxLengthLine);
		if ( tmpStr )
			description = tmpStr;
	}
	else						// failed!
	{
		retVal = true;
		goto all_done;				// ...stop processing
	}

	// 2. Get each set of parameters
	while ( ifs.good() &&
		sets.GetSetCount() <= indices.SPGI_Water ) // for each set...
	{
		// read in first line of next parameter set
		ifs >> ws;				// whitespace
		ifs.getline (line, maxLengthLine);	// next line
		if ( IsComment(line) )			// comment?
			continue;			// ...ignore it
		if ( !(*line) )				// blank line?
			continue;			// ...yes; next line
		if ( !ifs.good() )			// done with set?
			break;				// ...yes; quit
		if ( *line != '*' )			// start of set?
			continue;			// ...no; next line

		// prepare for a new set
		set.Clear ();
		param.Clear ();
		haveParam.assign (maxNumParams, false);
		short const setSize = indices.siteSetCount[sets.GetSetCount()];
		Assert (setSize > 0);
		Assert (setSize <= maxNumParams);

		// save name of set
		set.SetName ((char*)indices.siteSetName[sets.GetSetCount()]);

		// insert the needed number of blank parameters into the set
		set.ParameterList().insert (
			set.ParameterList().begin(), setSize, param);

		// read parameters in the current set
		short count = 0;			// number of parameters
		TParamImportStatus status;
		while ( ifs.good() && count < setSize )	// for each parameter
		{
		    Assert (count < maxNumParams);
		    status = ImportParameter (ifs, param);
		    Assert (param.GetIndex() < maxNumParams);
		    if ( status == PIS_Success )	// successful?
		    {
			// save parameter data in set
			//set.ParameterList().at (param.GetIndex()) = param;  // save
			set.GetParameter (param.GetIndex()) = param;  // save
			haveParam[ param.GetIndex() ] = true;

		    }
		    else if ( status == PIS_NextParameter )
			continue;			// next parameter
		    else if ( status == PIS_NextSet )
			break;				// next set
		    else if ( status == PIS_NonFatalError )
		    {
		    	// TO DO: need error reporting here
			continue;			// next parameter
		    }
		    else if ( status == PIS_FatalError )
		    {
		    	// ImportParameter sets the error message
			retVal = true;
			goto error_done;		// stop processing
		    }
		    ++count;
		}

		// Import of current parameter set is finished.
		if ( !retVal && count > 0 )	// some parameters read?
		{
		    // add parameters created after Century 4 release
		    param.Clear ();
		    Assert (setSize <= maxNumParams);
		    for ( short i = 0; i < setSize; ++i ) // for each parameter
		    {
			if ( !haveParam[i] )	//  parameter not imported?
		    	{
				param.SetIndex (i);
				set.GetParameter (i) = param;  // save in set
			}
		    }
		    // add current parameter set to the set of sets
		    if ( sets.AddSet (set) )		// add to sets set
		    {
			retVal = true;
			break;			// failed!
		    }
		}
	}

	// check the stream state
	if ( !retVal )
	{
		int state = ifs.rdstate();
		if (state == ios::failbit || state == ios::badbit)
			retVal = true;
	}

	if ( retVal ||
	     sets.GetSetCount() != indices.SPGI_Water + 1 )	// problem?
	{
		sets.Clear ();
		errStr += "Could not read in site parameters.\n"
			  "Check site file format.";
		goto error_done;
	}

	 param.Clear ();
	 for ( short i = indices.SPGI_Water + 1;
	       i < indices.SPGI_EndOfList;
	       ++i )
	 {
	    	// begin new set
	    	set.Clear ();
		set.SetName ((char*)indices.siteSetName[i]);
		short setSize = indices.siteSetCount[i];	// size of set
		set.ParameterList().insert (
			set.ParameterList().begin(), setSize, param);
		for ( short j = 0; j < setSize; ++j )	// each parameter...
		{
			// values for the parameter
			param.SetIndex(j);
			set.GetParameter (param.GetIndex()) = param;	// save in set
			param.Clear ();				// erase
		}
		// add to sets set
		if ( sets.AddSet (set) )
		{
			errStr += "Error adding parameter to set\n";
			errStr += "Set name: ";
			errStr += set.GetName();
			retVal = true;
			goto error_done;		// failed!
		}
	}
	goto all_done;	// normal completion

    error_done:						// error handler
    {
	// cleanup
	if ( ifs.is_open() )
		ifs.close ();
	// outa here!
	if ( !errStr.empty() )
		errStr += NL_CHAR;
	errStr += fileName;
	SiteException e ( myName, errStr );
	throw (e);
    }

    all_done:						// normal completion
 	// cleanup
	if ( ifs.is_open() )
		ifs.close ();
	if ( !errStr.empty() )	// previously uncaught problem?
	{
		errStr += NL_CHAR;
		errStr += fileName;
		SiteException e ( myName, errStr );
		throw (e);
	}
	return retVal;
}

//	ReadNcFile
// 	Read parameter values from the netCDF files
//	Returns false if successful, else throws SiteException if not.
bool TMCSiteParameters::ReadNcFile ()
{
	char const * const myName = "TMCSiteParameters::ReadNcFile";

	TNcSiteParameters nc (ncFile);	// class instance to read file
	if ( nc.Read (*this) )
	{
		// failed
	    	std::string msg = "Could not read site parameters:\n";
		msg += nc.GetFileName().GetFullName();
		if ( nc.IsNcErr() )
		{
			if ( !errStr.empty() )
				errStr += NL_CHAR;
			errStr += nc.GetNcErrStr ();
		}
		if ( !errStr.empty() )
		{
			msg += NL_CHAR;
			msg += errStr;
		}
		Clear ();
		SiteException e ( myName, msg );
		throw (e);
	}
	else
	{
		modified = false;
		return false;				// successful
	}
}

//	WriteNcFile
// 	Write parameter values from the netCDF files.
//	Returns false if successful, else throws SiteException if not.
bool TMCSiteParameters::WriteNcFile ()
{
	char const * const myName = "TMCSiteParameters::WriteNcFile";

	TEH::TFileName fromFile (templateFileName);	// "create from" file
	if ( !templatePath.IsEmpty() )
		fromFile.SetPath (templatePath);
	bool const exists = fromFile.Exists();
	if ( !exists )
	{
	    std::string msg = "Template file does not exist:\n";
	    msg += fromFile.GetFullName();
	    SiteException e ( myName, msg );
	    throw (e);
	}
	TNcSiteParameters nc (ncFile);		// class instance to write file
	if ( !ncFile.Exists() ||		// need to create the file?
	     ( nc.GetVersion() != nc.GetFileVersion() ) )
	{
		if ( nc.CreateFrom (fromFile) )	// create file from template
		{
		    // failed
		    std::string msg =
			"Could not create site parameters file:\n";
		    msg += nc.GetFileName().GetFullName();
		    char const * const ncErrStr = nc.GetNcErrStr ();
		    if ( ncErrStr )
		    {
			if ( !errStr.empty() )
				errStr += NL_CHAR;
			errStr += ncErrStr;
		    }
		    if ( !errStr.empty() )
		    {
			msg += NL_CHAR;
			msg += errStr;
		    }
		    SiteException e ( myName, msg );
		    throw (e);
		}
	}
	return nc.Write (*this);		// Write the data
}

//	VerifyValues
//	Check the parameter values for within a valid range.
//	Returns false if verified OK, else true if failed verification.
//	To Do: move this into the new site parameters verification class.
bool TMCSiteParameters::VerifyValues ()
{
	bool retVal = false;				// return value
	/*
	TSiteParamSet& set = sets[SPGI_Climate];//--- climate set
	set = sets[SPGI_Soil];			//--- soil & physical set
	set = sets[SPGI_ExtNut];		//--- ext. nutrients set
	set = sets[SPGI_InitOrg];		//--- initial OM set
	set = sets[SPGI_ForOrg];		//--- init. forest OM set
	set = sets[SPGI_MinNPS];		//--- mineral N, P, S set
	set = sets[SPGI_Water];			//--- water content set
	set = sets[SPGI_LowerHor];		//--- lower horizon set
	*/

	TSiteParamSet const & set =		//--- erosion set
		sets[indices.SPGI_ErosDep];
	register short offset = 0;			// offset in set
	register float value;				// one value
	float sum[5][3];				// sum of fractions
	float *p0, *p1, *p2;				// ptrs to sum array
	for ( short i = 0; i < 5; ++i )			// each pool...
	{
	    p0 = &sum[i][0];			// unlabeled C sum of fractions
	    p1 = &sum[i][1]; 			// labeled C sum of fractions
	    p2 = &sum[i][2];			// N sum of fractions
	    *p0 = *p1 = *p2 = 0.0;		// ...initialize to zero
	    // fraction values between 0.0 and 1.0?
	    for ( short j = 0; j < 2; ++j )		// each fraction...
	    {
	    	//--- labeled C loss fractions
		value = set.GetParameter(indices.SPI_eflcu + offset).GetValue();
		if ( value < 0.0f || value > 1.0f )		// valid?
	    		goto out_of_range_error;
	    	*(p0++) += value;				// sum values
	    	//--- unlabeled C loss fractions
		value = set.GetParameter(indices.SPI_eflcl + offset).GetValue();
		if ( value < 0.0f || value > 1.0f )		// valid?
	    		goto out_of_range_error;
	    	*(p1++) += value;				// sum values
	    	//--- N loss fractions
	    	value = set.GetParameter(indices.SPI_efln + offset).GetValue();
		if ( value < 0.0f || value > 1.0f )		// valid?
	    		goto out_of_range_error;
	    	*(p2++) += value;				// sum values
	    	++offset;
	    }
	    // sum of fractions <= 1.0?
	    for ( short e = 0; e < 3; ++e )		// each element...
	    	if ( sum[i][e] > 1.0f )			// too large?
	    		goto too_large_error;
	}
	goto all_done;					// no errors

out_of_range_error:		// To Do: value out of range - handle error
	retVal = true;
	goto all_done;

too_large_error:		// To Do: fraction sum >= 1.0 - handle error
	retVal = true;

all_done:
	return retVal;
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	AssignDefaultValues
// 	Assign default parameter values.
void TMCSiteParameters::AssignDefaultValues ()
{
	/*
	//--- climate set
	{
	TSiteParamSet& set = sets[SPGI_Climate];
	}
	*/
	//--- soil & physical controls set
	{
		// runoff coefficients
		TSiteParamSet & set = sets[indices.SPGI_Soil];
		short offset = indices.SPI_runoff - indices.SPI_ivauto;
		float A = set.GetParameter(offset).GetValue(),
		      B = set.GetParameter(offset + 1).GetValue(),
		      C = set.GetParameter(offset + 2).GetValue();
		if (A == 0.0f && B == 0.0f && C == 0.0f)
		{
			set.GetParameter(offset + 1).SetValue( 0.55f );
			set.GetParameter(offset + 2).SetValue( 2.75f );
		}
	}
	// numParamsRead += 3;	// runoff coefficients
	// numParamsRead += 10;	// thicknesses
	//--- external nutrients set
	{
		// TSiteParamSet& set = sets[indices.SPGI_ExtNut];
	}

	//--- initial OM set
	{
		// TSiteParamSet& set = sets[indices.SPGI_InitOrg];
	}

	//--- initial forest OM set
	{
		// TSiteParamSet& set = sets[indices.SPGI_ForOrg];
	}

	//--- mineral N, P, S set
	{
		// TSiteParamSet& set = sets[indices.SPGI_MinNPS];
	}

	//--- water content set
	{
		// TSiteParamSet& set = sets[indices.SPGI_Water];
	}

	//--- lower horizon set
	{
		// TSiteParamSet& set = sets[indices.SPGI_LowerHor];
	}
	// numParamsRead += (indices.SPI_eflcu - indices.SPI_lhicu);

	//--- erosion set
	{
	TSiteParamSet & set = sets[indices.SPGI_ErosDep];
	// erosion loss factors
	short offset = 0;	// offset from beginning of the parameter index
	for ( short i = 0; i < 5; ++i )			// each pool
	    for ( short j = 0; j < 2; ++j )		// each fraction
	    {
		set.GetParameter(offset).SetValue ( 	// unlabeled C
			EFLCU_DEFAULTS[i][j] );
		set.GetParameter(offset).SetValue ( 	// labeled C
			EFLCL_DEFAULTS[i][j] );
		set.GetParameter(offset).SetValue ( 	// N
			EFLN_DEFAULTS[i][j] );
		++offset;
	    }
	}
	// numParamsRead += (SPI_ksat - SPI_eflcu);
}

//	ImportParameter
//	Imports one parameter from the Century 4 site parameter file.
//	Return value indicates result of import; see enum TParamImportStatus.
TMCSiteParameters::TParamImportStatus TMCSiteParameters::ImportParameter (
	ifstream & ifs, 	// file stream of Century 4 file
	TSiteParameter & param)	// imported parameter
{
	TParamImportStatus retVal = 		// return value
		PIS_Success;
	register char c;			// one character
	float value = 0.0f;			// parameter value
	char line[101];				// receives input line
	*line = NULL_CHAR;
	short const parNameLen = maxNameLen + 1; // parameter name length
	char paramName[21];			// parameter name [parNameLen]
	register short nameLen;			// name length
	char const * const errMsgBase = "Error importing site parameter: ";
	std::string errMsgMore;

#define ChkStreamState(s)	\
	if ( !ifs.good() )	\
	{			\
	  if (s)		\
	  	errMsgMore = s;	\
	  goto fatal_error;	\
	}

	// check the next line
	ifs >> ws;			// remove whitespace
	c = (char) ifs.peek();		// peek at next char
	if ( !c )			// blank line?
		goto skip_parameter;	// ...skip it
	if ( !ifs.good() || c == '*' ) 	// done with set?
		goto skip_set;		// ...on to next set
	ChkStreamState("Stream error after checking next line.");

	// get parameter value
	param.Clear ();
	ifs >> value;
	if ( !ifs.good() )				// get value
		goto skip_set;
	ChkStreamState("Error after reading parameter value.");
	param.SetValue (value);				// save value

	// get parameter name
	//ifs.seekg (0, ios::cur);			// kluge: BC++5.02 bug
	ifs >> ws;					// skip whitespace
	if ( !(ifs.getline (line, 101)) )		// get rest of line
		goto skip_set;				// ...stream error
	ChkStreamState("Error after reading parameter name.");
	if ( !(*line) )					// blank line?
		goto skip_parameter;			// ...yes; on to next

	// check for obsolete names that do not have replacements
	if ( FindObsoleteParameter (line) )
		goto skip_parameter;		// found match - skip parameter

	// get parameter name and remove quotes around string, if there
	#define APOSTROPHE '\''
	if ( *line == APOSTROPHE )			// skip leading quote?
		strncpy (paramName, line + 1, parNameLen - 1);
	else
		strncpy (paramName, line, parNameLen - 1);
	paramName[parNameLen - 1] = NULL_CHAR;		// null-terminate
	::strtrim (paramName);				// lose trailing blanks
	nameLen = strlen(paramName) - 1;		// get name length
	if ( *(paramName + nameLen) == APOSTROPHE )	// end quote?
		*(paramName + nameLen) = NULL_CHAR;	// ...remove it

	// check for obsolete names that have replacements
	{
	  char const* newName = FindReplacedParameter (paramName);
	  if ( newName )				// found replacement
		strcpy (paramName, newName);		// ...retrieve it
	}

	// search for name in parameter description set
	param.SetIndex ( info->FindNameIndex (sets.GetSetCount(), paramName) );
	Assert (param.GetIndex() < indices.siteSetCount[sets.GetSetCount()]);
	if ( param.GetIndex() < 0 )			// found name?
	{
		errMsgMore += "Parameter name is not recognized.";
		goto fatal_error;			// ...no
	}
	else
		goto all_done;				// ...sucessful!

	// the following target labels set the return value
	fatal_error:
	{
		retVal = PIS_FatalError;
		errStr += errMsgBase;
		errStr += paramName;
		if ( !errMsgMore.empty() )
		{
			errStr += NL_CHAR;
			errStr += errMsgMore;
		}
		goto all_done;
	}

	skip_parameter:
    		retVal = PIS_NextParameter;
		goto all_done;

	skip_set:
		retVal = PIS_NextSet;

	all_done:
		return retVal;
}

//	FindObsoleteParameter
//	Check for obsolete parameters that do not have replacements.
//	Returns true if found, else false.
bool TMCSiteParameters::FindObsoleteParameter (
	char const* paramName)	//   parameter name to check
{
	// Assume paramName always has a value!
	static char const * const obsoleteNames[] = // list of obsolete names
	{
		"W1LIG", "W2LIG", "W3LIG",
		0
	};
	const char * const *p = obsoleteNames;
	while ( *p )	// compare - assume uppercase input str
		if ( !strcmp (paramName, *(p++)) )	// found?
			return true;			// ...yes
	return false;					// ...no
}

//	FindReplacedParameter
//	Check for obsolete parameters that do not have replacements.
//	Returns new name if replacement found, else NULL if not found.
char const* TMCSiteParameters::FindReplacedParameter (
	char const* paramName)	// parameter name to check
{
	// Assume paramName always has a value!
	static char const * const oldNames[] =		// previous names
	{
	    "SAND", "SILT", "CLAY", "BULKD",
	    0
	};
	static char const * const newNames[] =		// replacement names
	{
	    "SAND(1)", "SILT(1)", "CLAY(1)", "BULKD(1)",
	    0
	};

	// compare - assume uppercase input str
	char const * const * p = oldNames;
	while ( *p )
		if ( !strcmp (paramName, *p) )			// found?
	    		return newNames[(int)(p - oldNames)];	// ...yes
	    	else
	    		++p;				// ...no; check next
	return 0;					// no match found
}

//	Read
//	Read the site parameters from the specified file name.
//	Returns false if successful, else true if error.
bool TMCSiteParameters::Read (
	TEH::TFileName const & newFileName)	// site file name
{
	bool failed = true;

	// parameter values
	if ( !newFileName.IsEmpty() && newFileName.IsValid() )
	{
		// get file type and validity
		fileType = GetFileType (newFileName);
		if ( fileType != SPFT_Unknown )
			filePath = newFileName;		// save file path
		if ( fileType == SPFT_Century4 )	// import Cent. 4 file
		{
			failed =  ImportCent4File ();
		}
		else if ( fileType == SPFT_netCDF )	// read netCDF file
		{
			std::string const tmpFileName =
				newFileName.GetFullName ();
			Assert ( !tmpFileName.empty() );
			Assert ( tmpFileName[0] != NULL_CHAR);
			// to do: refactor duplicate code below
			if ( SetBaseName (tmpFileName) )
			{
			  if ( !errStr.empty() )
				errStr += NL_CHAR;
			  errStr +=
				"Error setting the name of the "
				"site parameters file.";
			  return true;
			}
			ncFile = filePath;
			failed = ReadNcFile ();		// read it now
			if ( failed )			// read failed?
				ncFile.Clear ();	// ...yes
		}
		if ( !failed )
			AssignDefaultValues ();
	}
	return failed;
}

//	CreateZeroedSets
//	Adds sets with only zero values to the set of parameters sets.
void TMCSiteParameters::CreateZeroedSets ()
{
	for ( short i = 0; i < indices.GetSetCount(); ++i )
	{
		TSiteParamSet set;
		set.SetName ( (char*)indices.siteSetName[i] );
		short const numParams = (short)(
		    indices.setIndexList[i+1] - indices.setIndexList[i] );
		set.ParameterList().reserve (numParams);	// set capacity
		for ( short j = 0; j < numParams; ++j )
		{
			TSiteParameter param;
			set.ParameterList().push_back (param);
		}
		if ( sets.AddSet (set) )
		{
			// To Do: CreateZeroedSets: throw exception here
			Assert (false);
		}
	}
	Assert (GetSetCount() > 0);
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Initialize
//	initialize members
void TMCSiteParameters::Initialize ()
{
	fileType = SPFT_Unknown;
}

//	Copy
//	copy to this
void TMCSiteParameters::Copy (
	TMCSiteParameters const & object)
{
	if ( &object )
	{
		filePath = object.filePath;
		fileType = object.fileType;
	}
}

//--- end of definitions for TMCSiteParameters.cpp ---
