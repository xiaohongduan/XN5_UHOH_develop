// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TNcFileSitePar.cpp
//	Class:	  TNcSiteParameters, TNcSiteParamDef
//
//	Description:
//	Classes for I/O of netCDF files for the TMCSiteParameters class.
//	Derived from the class TNcFile.
//	These are friends of class TMCSiteParameters.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Mar98
// ----------------------------------------------------------------------------
//	History: See header file.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TMCSiteParamInfo.h"
#include "TMCSiteParameters.h"
#include "TNcFileSitePar.h"
#include "AssertEx.h"
#include "timeutil.h"

//	-----------------------------------------------------------------------
//	Class TNcSiteParameters

short const TNcSiteParameters::version = 4;	// netCDf file version number

//	Read
//	Read the site parameter data from the netCDF file.
// 	Reads the entire contents of the netCDF file
//	derived from the default netCDF file "SiteParam.nc".
//	Returns false upon successful read, else true if not successful.
bool TNcSiteParameters::Read (
	TMCSiteParameters & sp)
{
	if ( ncErrStr )			// already have error message?
		return true;		// ...yes

	bool retVal = true;
	if ( OpenNcFile (NcFile::ReadOnly) )	// open the netCDF file
	{
		// TO DO: need more error handling here
		return retVal;			// ...failed
	}

	GetVars (ncFile);		// get pointers to variables
	GetDims (ncFile);		// get dimensions
					// Read variable values
	// 1. site type

	v[0].v->get ( (ncbyte*)&(sp.siteType), 1 );
	if ( SetNcErrStr () )
	{
		CloseNcFile ();			// close the netCDF file
		return retVal;
	}

	// 2. site name
	short len = (short)d[0]->size ();	// length of name
	char * newName = new char [len + 1];
	v[1].v->get ( newName, len );
	newName[len] = '\0';
	::strtrim (newName);
	sp.name = newName;
	if ( SetNcErrStr () )
	{
		CloseNcFile ();			// close the netCDF file
		return retVal;
	}

	// 3. site description
	len = (short)d[1]->size ();		// length of description
	char * newDescription = new char [len + 1];
	Assert (newDescription != NULL);
	v[2].v->get ( newDescription, len );
	newDescription[len] = '\0';
	::strtrim (newDescription);
	sp.description = newDescription;
	if ( SetNcErrStr () )
	{
		CloseNcFile ();			// close the netCDF file
		return retVal;
	}

	// 4. values
	short const numValues = (short)d[2]->size ();	// num. params.
        // numParamsRead = numValues;
	float *values = new float [numValues];
	Assert (values != NULL);
	v[3].v->get ( values, numValues );		// values
	if ( SetNcErrStr () )
	{
		CloseNcFile ();			// close the netCDF file
		return retVal;
	}

	// find space needed for the largest set
	short maxNumParams = 0;			// maximum
	for ( short i = 0;
	      i < TMCSiteParIndices::GetSetCount();
	      i++ )					// for each set
	{
		short const numParams = (short)(
		    sp.indices.setIndexList[i+1] - sp.indices.setIndexList[i] );
		if ( numParams > maxNumParams )
			maxNumParams = numParams;
	}

	// assign values to sets and save
	TSiteParamSet set;				// one set
	set.ParameterList().reserve (maxNumParams);	// set capacity
	TSiteParameter param;				// one parameter
	short count = 0;				// index to value
							// file version info
	const NcAtt* verAtt = ncFile->get_att ("Version");
	const int fileVersion = verAtt->as_int (0);
	for ( short i = 0;
	      i < TMCSiteParIndices::GetSetCount();
	      i++ )					// for each set
	{
		// read set descriptive info
		set.SetName ((char*)sp.indices.siteSetName[i]);
		short const numParams = (short)(
		    sp.indices.setIndexList[i+1] - sp.indices.setIndexList[i] );
		// read parameter values
		if ( fileVersion == 1 && i == TMCSiteParIndices::SPGI_Soil )
		{
			register short j = 0;
			short const infminIndex =
				TMCSiteParIndices::SPI_stormf -
				TMCSiteParIndices::SPI_ivauto + 1;
			short const swflagIndex =
				TMCSiteParIndices::SPI_ivauto -
				TMCSiteParIndices::SPI_swflag;
			while ( j < numParams )			// each set
			{
			    // runoff params were different
			    if ( j == infminIndex )		// infmin?
			    {
			    	float infmin = values[count++];
			    	float runfrac = values[count++];
				set.ParameterList().push_back (param);	// runoff(1)
				++j;
				param.Clear ();
			    	param.SetValue (runfrac);		// runoff(2)
				set.ParameterList().push_back (param);
				++j;
				param.Clear ();
			    	param.SetValue (infmin * runfrac);	// runoff(3)
				set.ParameterList().push_back (param);
			    }
			    else if ( j >= swflagIndex )	// swflag?
			    {
				param.SetValue (values[count++]);	// get
				set.ParameterList().push_back (param);	// save in set
			    }
			    param.Clear ();			// ready next
			    ++j;
			}
			if ( sp.sets.AddSet (set) )	// add to sets set
				break;			// failed!
			set.Clear();
		}
		else
		{
			for ( short j = 0; j < numParams; j++ )	// each param.
			{
				param.SetValue (values[count++]);	// get
				set.ParameterList().push_back (param);	// save in set
				param.Clear ();			// ready next
			}
			if ( sp.sets.AddSet (set) )	// add to sets set
				break;			// failed!
			set.Clear();
		}
	}
	delete [] values;
	values = 0;

	//--- read attributes
	// attribute - editor name
	NcAtt* edNameAtt = ncFile->get_att ("LastModifiedWho");
	// attribute - last edit date
	NcAtt* edDateAtt = ncFile->get_att ("LastModifiedWhen");
	EditorsInfo editInfo (
		edNameAtt->as_string(0), edDateAtt->as_string(0) );
	// Save editing info to the site parameter set
	sp.SetEditInfo (editInfo);
	delete edNameAtt;
	delete edDateAtt;

	SetNcErrStr ();

	//--- all done!
	CloseNcFile ();			// close the netCDF file
	if ( !ncErrFlag )		// error?
		retVal = false;		// ...no
	return retVal;
}

//	Write
//	Write the site parameter data to the netCDF file.
//	Writes (replaces) the entire contents of the netCDF file
//	derived from the default netCDF file "SiteParam.nc".
//	Returns false upon successful write, else true if not successful.
bool TNcSiteParameters::Write (
	TMCSiteParameters & sp)
{
	bool retVal = true;
	short const numParams = 			// dimensions
		(short)TMCSiteParIndices::SPI_EndOfList;
	float values[numParams];			// list of values
	short valCount = 0;				// where in values[]
	short setParamCount;				// num. params. in set

	// build list of values
	for (short i = 0; i < (short)sp.sets.GetSetCount(); ++i) // each set...
	{
		TSiteParamSet const & set = sp.GetSet (i);	// next set
		setParamCount = (short) set.GetParamCount ();	// num. params.
		TSiteParamSet::TParameterList::const_iterator i =
			set.ParameterList().begin ();
		for ( short j = 0; j < setParamCount; ++j )	// each param.
		{
			values[valCount] = (*i).GetValue();
			++i;
			++valCount;
		}
	}

	// save the values to the netCDF file
	if ( !OpenNcFile (NcFile::Write) )	// open the netCDF file
	{
		GetVars (ncFile);		// get pointers to variables
		GetDims (ncFile);		// get dimensions
		// Write variable values
		v[0].v->put ((ncbyte*)&(sp.siteType), 1);	// site type
		v[1].v->put (sp.name.c_str(), 			// name
			sp.name.length() < (size_t) d[0]->size() ?
			sp.name.length() : d[0]->size() );
		v[2].v->put (sp.description.c_str(),		// description
			sp.description.length() < (size_t) d[1]->size() ?
			sp.description.length() : d[1]->size() );
		v[3].v->put (values, valCount);			// values

		// Write attributes
		// 1. check for empty fields
		EditorsInfo editInfo ( sp.GetEditInfo() );
		if ( editInfo.GetEditorName().empty() )
			editInfo.SetEditorName ("");
		if ( editInfo.GetEditDate().empty() )		// empty?
			editInfo.SetEditDate( ::DateTimeStr() );
		if ( editInfo != sp.GetEditInfo() )
			sp.SetEditInfo ( editInfo );
		// 2. add the fields
		ncFile->add_att ( "LastModifiedWho",
				  editInfo.GetEditorName().c_str() );
		ncFile->add_att ( "LastModifiedWhen",
				  editInfo.GetEditDate().c_str() );
		ncFile->add_att ( "LastModifiedHow", "" );

		// all done!
		// check for errors
		SetNcErrStr ();
		CloseNcFile ();			// close the netCDF file
		if ( !ncErrFlag )		// error?
		{
			retVal = false;		// ...no
			sp.modified = false;
		}
	}
	return retVal;
}

//	-----------------------------------------------------------------------
//	Class TNcSiteParamDef

short const TNcSiteParamDef::version = 3;	// version number (highest)

//	Read
//	Read the site parameter name and definition data from the netCDF file.
// 	Reads the entire contents of the netCDF file
//	derived from the default netCDF file "SiteParamDef.nc".
//	Returns false upon successful read, else true if not successful.
bool TNcSiteParamDef::Read (
	TMCSiteParamInfo & pi)	// parameter info object
{
	if ( ncErrStr )			// already have error message?
		return true;		// ...yes

	bool retVal = true;
	if ( !OpenNcFile (NcFile::ReadOnly) )	// open the netCDF file
	{
		GetVars (ncFile);		// get pointers to variables
						// Read variable values
		register short k = 0;		// index to variable array
						// 1. names
		v[k].v->set_cur ( 0, 0 );		// 1st record
		short const numParams = (short)v[k].d[0]->size (); // dims.
		short const nameLen = (short)v[k].d[1]->size ();
		pi.names.resize (numParams);		// memory for list
		TMCSiteParamInfo::TStringArray::iterator p = pi.names.begin();
		char* curName = new char [nameLen + 1];	// temp name
		curName[nameLen] = '\0';
		for ( short i = 0; i < numParams; i++ )
		{
			v[k].v->set_cur (i, 0);			// next string
			v[k].v->get (curName, 1, nameLen);	// get string
			::strtrim (curName);
			*p = curName;
			++p;
		}
		delete [] curName;
		curName = 0;
		Assert (pi.names.size() ==
			static_cast<std::string::size_type>(numParams));
						// 2. descriptions
		v[++k].v->set_cur ( 0, 0 );
		Assert (v[k].d[0]->size() == numParams);	// same count?
		short const descLen = (short)v[k].d[1]->size ();
		pi.descs.resize (numParams);		// memory for list
		p = pi.descs.begin();			// ptr to desc. list
		char* curDesc = new char [descLen + 1];	// a description
		curDesc[descLen] = '\0';
		for ( short i = 0; i < numParams; i++ )
		{
			v[k].v->set_cur (i, 0);		// to next string
			v[k].v->get (curDesc, 1, descLen);	// get string
			::strtrim (curDesc);
			*p = curDesc;
			++p;
		}
		delete [] curDesc;
		curDesc = 0;
		Assert (pi.descs.size() ==
			static_cast<std::string::size_type>(numParams));

		// check for errors
		SetNcErrStr ();
		CloseNcFile ();			// close the netCDF file
		if ( !ncErrFlag )		// error?
			retVal = false;		// ...no
	}
	return retVal;
}

//---	end of T_NcFileSitePar.cpp ---//
