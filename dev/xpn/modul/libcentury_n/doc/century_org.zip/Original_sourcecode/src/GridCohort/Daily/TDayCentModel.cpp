// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TDayCentModel.cpp
//	Class:	  TDayCentModel
//
//	Description: See header file.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, June 2002
//	History: See header file.
// ----------------------------------------------------------------------------
//	Notes:
//	This version has hardwired configuration information.
//	See the function TDayCentModel::ConfigureCentury to change
//	the initial site and management files.
// ----------------------------------------------------------------------------

#include "TDayCentModel.h"
#include "stringutil.h"
#include "DayCentIRCTypes.h"
#include <exception>
using namespace nrel::dcirc;

// ----------------------------------------------------------------------------
//	helper functions for DayCent
// ----------------------------------------------------------------------------

// Pointer to current model
// updated each model (not thread safe)
// Never delete or modify this pointer!
static TDayCentModel * currentModel;

// Function to receive messages from the model.
static void DisplayMsg (char const * const modelMsg)
{
	std::string msg = currentModel->GetIDString ();
	msg += ": ";
	msg += modelMsg;
	currentModel->WriteToSim (msg);
}

static void DisplayMsg (std::string const & modelMsg)
{
	std::string msg = currentModel->GetIDString ();
	msg += ": ";
	msg += modelMsg;
	currentModel->WriteToSim (msg);
}

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

TDayCentModel::TDayCentModel (
	::nrel::gcf::TCohort * const useOwner,		// owner = cohort
	::nrel::gcf::TDecision * const useDecision,	// decision object
	::nrel::gcf::TFactories * const factories,	// class factories
	bool const timeThisRun)			// True if timing the model run
	: ::nrel::gcf::TModelBase (useOwner, useDecision, factories, timeThisRun),
	  // mySimController ( dynamic_cast<TDayCentSimController * const>(
	  //	owner->GetOwner()->GetOwner()->GetOwner() ) ),
	  mySimController (
		(TDayCentSimController * const)
	  	owner->GetOwner()->GetOwner()->GetOwner() ),
	  myCloneSource (0)
{
	// dynamic_cast issue:
	// the following works thru "sim" below; remaining dynamic_casts fail.
	/*
	::nrel::gcf::TCohort * const cohort = owner;
	::nrel::gcf::TGridCell * const cell = cohort->GetOwner();
	::nrel::gcf::TGrid * const grid = cell->GetOwner();
	::nrel::gcf::TGriddedSimulationBase * const sim = grid->GetOwner();
	TDayCentSimController * const mySimControllerLocal1 =
		dynamic_cast<TDayCentSimController * const>(sim);
	TDayCentSimController * const mySimControllerLocal2 =
		(TDayCentSimController * const)sim;	// this works
	*/

	Assert (mySimController != 0);
	MakeIDString ();
}

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

void TDayCentModel::WriteEventToSim (
	std::string const & eventStr,
	TCohortID const cohortID)
{
	std::ostringstream os;
	os << "Sim time step "
	   << mySimController->GetTimer().GetTimeStep()
	   << " : Model time step " << GetTimer().GetTimeStep()
	   << " : cell " << owner->GetOwner()->GetID()
	   << " cohort " << cohortID
	   << " : " << eventStr;
	WriteToSim ( os.str() );
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

void TDayCentModel::Copy (				// Copy to this
	TDayCentModel const & object,
	::nrel::gcf::TEvent const * const data)
{
    ::currentModel = this;
    if ( &object )
    {
	// create a new configuration
	// To do: store mgmt in separate var so can share unmodified config
	// object. Then only have to allocate a mgmt object; less mem & faster.
	centuryConfig.reset ( new TDailyCenturyConfig (*object.centuryConfig) );

	// if new mgmt is specified in the event, use it
	::nrel::gcf::TEventDataArray const & eventDataArray = data->second;
	if ( eventDataArray.size() >= 3 )	// mgmt = item # 3
	{
		std::string newMgmtFileName = eventDataArray[2];
		centuryConfig->UseManagement ( newMgmtFileName.c_str() );
	}

	// create an output object
	TCentOutFileBase const * const yourOutput =
			dynamic_cast<TCentOutFileBase const * const>(
				object.centuryConfig->GetOutput().get() );
	bool doingOutput = object.GetModel().DoingOutput();
	if ( doingOutput )
    	{
		// modify the output file name
		TEH::TFileName newOFName ( yourOutput->GetFileName().c_str(),
						TEH::TFileName::FT_Normal );
		std::string nameStr = newOFName.GetFullPath();
		MakeOutputFileName (nameStr);
		newOFName.SetName ( nameStr );
		// let the config. object setup the output object
		centuryConfig->UseOutputFile (
			newOFName.GetFullName().c_str(),
			yourOutput->GetOutputType(),
			yourOutput->GetAccessMode() );
	}
	if ( centuryConfig->HaveWarningMsg() )
	{
		std::string msg = ": Configuration messages:\n";
		msg += centuryConfig->GetWarningMsg();
		::DisplayMsg ( msg );
	}
	centuryConfig->FindAndThrowError ();	// check for errors

	// save the list of output set pointers
	if ( doingOutput )
    	{
		TCentOutFileBase * const myOutput =
			dynamic_cast<TCentOutFileBase * const>(
				centuryConfig->GetOutput().get() );
		myOutput->SetOutputSetList ( yourOutput->GetOutputSetList() );
	}

	// clone Century
	century.reset (
		object.century->Clone (
			*this,
			centuryConfig->GetManagement() ) );

	// set the timer so the start time step is now
	GetTimer().SetTimeStepRange (
		GetTimer().GetTimeStep(), 	// start = current time step
		GetTimer().GetEndTimeStep() );	// same ending time step

	// use the new parts in the cloned century model
    	if ( doingOutput )
		century->UseOutput (
			centuryConfig->GetOutput() );
    }
    ::currentModel = 0;
}

std::string & TDayCentModel::MakeExceptionMsg (
	std::string & msg)
{
	char const * const exceptionMsg =
		" : Exception caught. Ending simulation.";
	msg = idString;
	msg += exceptionMsg;
	std::ostringstream os;
	os << "\nSim time step "
	   << mySimController->GetTimer().GetTimeStep()
	   << " : Model time step "
	   << GetTimer().GetTimeStep()
	   << "\nClock time = " << ::DateTimeStr();
	msg += os.str();
	return msg;
}

//	Simulation start and end messages
void TDayCentModel::SimStartMsg ()
{
	std::ostringstream oss;
	oss << idString << ": Begin simulation\n"
	    << "Sim time step "
	    << mySimController->GetTimer().GetTimeStep()
	    << " : Model time steps "
	    << GetTimer().GetStartTimeStep()
	    << " - "
	    << GetTimer().GetEndTimeStep()
	    << " : Simulation start, end years = "
	    << century->GetSimTime()->startYear
	    << " - "
	    << century->GetSimTime()->endYear;
	WriteToSim ( oss.str() );
}

void TDayCentModel::SimEndMsg ()
{
	std::ostringstream oss;
	oss << idString << ": End simulation\n"
	    << "Sim time step "
	    << mySimController->GetTimer().GetTimeStep()
	    << " : Model time step "
	    << GetTimer().GetTimeStep()
	    << " : elapsed time steps = "
	    << (GetTimer().GetElapsedTimeSteps() + 1)
	    << " : simulation time = " << century->GetSimTime()->time;
	WriteToSim ( oss.str() );
}

//	DoInitializeModel
//	Initialize the model
//	Return false if successful, else true if failed.
bool TDayCentModel::DoInitializeModel ()
{
	msg = idString;
	msg += ": Initializing";
	WriteToSim (msg);
	::currentModel = this;
	centuryConfig.reset ( ConfigureCentury().release() );
	Assert (centuryConfig.get() != 0);
	century.reset ( InstantiateCentury().release() );
	Assert (century.get() != 0);
	// Timer should have been set in ::nrel::gcf::TCohort::DoInitializeGridElement
	// prior to this function, to the sim. controller timer.
	Assert (!(GetTimer().GetStartTimeStep() == 0 &&
		  GetTimer().GetEndTimeStep() == 0));
	century->SetTimer (
		GetTimer().GetStartTimeStep(),
		GetTimer().GetEndTimeStep(),
		true /* want clock time for run */ );
	century->InitializeModel ();
	::currentModel = 0;
	return false;
}

//	DoRunToCompletion
//	Run model to completion.
//	Return false if successful, else true if failed.
bool TDayCentModel::DoRunToCompletion ()
{
	::currentModel = this;
	state.SetState (TModelState::State_Running);
	bool doMore = true;
	SimStartMsg ();
	while ( !GetTimer().IsFinished() && doMore )
	{
		doMore = OneIterationTasks ();
		++GetTimer ();		// increment iteration counter
	}
	state.SetState (TModelState::State_Completed);
	SimEndMsg ();
	::currentModel = 0;
	return false;				// Return true if failed
}

//	DoRunIteration
//	Run model one iteration of DayCent (one month's simulation).
//	Return true if can continue.
bool TDayCentModel::DoRunIteration ()
{
	::currentModel = this;
	if ( GetTimer().AtStartTimeStep() )
	{
		SimStartMsg ();
		state.SetState (TModelState::State_Running);
	}
	bool continueFlag = false;
	try
	{
		// debug start

	long const modelTimeStep = GetTimer().GetTimeStep();
	float const centurySimTime = century->GetSimTime()->time;

	std::ostringstream oss;
	oss << idString << " : "
	    << "Sim time step " << mySimController->GetTimer().GetTimeStep()
	    << " : Model time step " << modelTimeStep
	    << " : Century sim time " << centurySimTime;
	WriteToSim ( oss.str() );

		// debug end

		continueFlag = OneIterationTasks (); // one month's tasks
	}
	catch (TDayCentException const& ce)	// exceptions thrown by DayCent
	{
		WriteToSim ( MakeExceptionMsg (msg) );
		WriteToSim ( ce.GetMsg() );
		continueFlag = false;
		state.SetState (TModelState::State_Terminated);
	}
	catch (TCentException const & ce)	// exceptions thrown by Century
	{
		WriteToSim ( MakeExceptionMsg (msg) );
		WriteToSim ( ce.GetMsg() );
		continueFlag = false;
		state.SetState (TModelState::State_Terminated);
	}
	catch (std::exception const & e)	// other exceptions (elaborate!)
	{
		WriteToSim ( MakeExceptionMsg (msg) );
		WriteToSim ( e.what() );
		continueFlag = false;
		state.SetState (TModelState::State_Terminated);
	}
	catch (char const * const aMsg)
	{
		WriteToSim ( MakeExceptionMsg (msg) );
		WriteToSim (aMsg);
		continueFlag = false;
		state.SetState (TModelState::State_Terminated);
	}
	catch (std::string const & aMsg)
	{
		WriteToSim ( MakeExceptionMsg (msg) );
		WriteToSim ( aMsg );
		continueFlag = false;
		state.SetState (TModelState::State_Terminated);
	}
	catch (...)
	{
		MakeExceptionMsg (msg);
		msg += "\nUnknown exception.";
		WriteToSim ( msg );
		continueFlag = false;
		state.SetState (TModelState::State_Terminated);
	}

	if ( GetTimer().AtEndTimeStep() )
	{
		state.SetState (TModelState::State_Completed);
		if ( continueFlag )		// should not happen
		{
		 // To Do: DoRunIteration error (continueFlag && AtEndTimeStep)
			continueFlag = false;
		}
	}
	if ( !continueFlag )
		SimEndMsg ();
	::currentModel = 0;
	return continueFlag;  // Return true if can continue
}

//	DoCombineModelPools
//	Add the pools of the other model into this one,
//	weighting by area fraction.
void TDayCentModel::DoCombineModelPools (
	::nrel::gcf::TModelBase const & otherModel)
{
	// first, a message
	TDayCentModel const & otherDayCentModel =
		dynamic_cast<TDayCentModel const &>(otherModel);
	msg = "Aggregate cohort ";
	msg += ::ToString ( otherDayCentModel.GetOwner()->GetID() );
	msg += " - combined cell fraction = ";
	msg += ::ToString ( owner->GetAreaFraction() +
			    otherDayCentModel.GetOwner()->GetAreaFraction() );
	WriteEventToSim ( msg, owner->GetID() );

	// aggregation parameters
	TDayCentGCF const & otherCentury = otherDayCentModel.GetModel();
	// calc normalized fractions
	float const totalFraction = owner->GetAreaFraction() +
		otherDayCentModel.GetOwner()->GetAreaFraction();
	float const myFraction = owner->GetAreaFraction() / totalFraction;
	float const yourFraction =
		otherDayCentModel.GetOwner()->GetAreaFraction() / totalFraction;

	// combine pools
	CombineSoilCPools (otherCentury, myFraction, yourFraction);
	CombineCropGrassBiomassCPools (otherCentury, myFraction, yourFraction);
	CombineForestBiomassCPools (otherCentury, myFraction, yourFraction);
	CombineNPools (otherCentury, myFraction, yourFraction);
	CombineH2OPools (otherCentury, myFraction, yourFraction);
	CombineCO2Pools (otherCentury, myFraction, yourFraction);
}

//	CombineCO2Pools
void TDayCentModel::CombineCO2Pools (
	TDayCentGCF const & otherCentury,
	float const myFraction,
	float const yourFraction)
{
	// CO2 accumulators
	century->CO2().amt1c2 =
		century->CO2().amt1c2 * myFraction +
		otherCentury.CO2().amt1c2 * yourFraction;
	century->CO2().amt2c2 =
		century->CO2().amt2c2 * myFraction +
		otherCentury.CO2().amt2c2 * yourFraction;
	for ( short i = 0; i < 2; ++i )
	{
		century->CO2().resp[i] =
			century->CO2().resp[i] * myFraction +
			otherCentury.CO2().resp[i] * yourFraction;
	}
}

//	CombineH2OPools
void TDayCentModel::CombineH2OPools (
	TDayCentGCF const & otherCentury,
	float const myFraction,
	float const yourFraction)
{
	short const numLayers = 7;	// To Do: change to soil layer count
	for (short layer = 0; layer < numLayers; ++layer)
	{
	    century->WaterTemp().asmos[layer] =
		century->WaterTemp().asmos[layer] * myFraction +
		otherCentury.WaterTemp().asmos[layer] * yourFraction;
	}
}

//	CombineSoilCPools
void TDayCentModel::CombineSoilCPools (
	TDayCentGCF const & otherCentury,
	float const myFraction,
	float const yourFraction)
{
	for ( short i = 0; i < 2; ++i )
	{
		century->SoilC().som1c[i] =
			century->SoilC().som1c[i] * myFraction +
			otherCentury.SoilC().som1c[i] * yourFraction;
		century->SoilC().som2ci[i] =
			century->SoilC().som2ci[i] * myFraction +
			otherCentury.SoilC().som2ci[i] * yourFraction;
		century->SoilC().som3ci[i] =
			century->SoilC().som3ci[i] * myFraction +
			otherCentury.SoilC().som3ci[i] * yourFraction;
		century->SoilC().strlig[i] =
			century->SoilC().strlig[i] * myFraction +
			otherCentury.SoilC().strlig[i] * yourFraction;
		century->SoilC().strucc[i] =
			century->SoilC().strucc[i] * myFraction +
			otherCentury.SoilC().strucc[i] * yourFraction;
		century->SoilC().metabc[i] =
			century->SoilC().metabc[i] * myFraction +
			otherCentury.SoilC().metabc[i] * yourFraction;
		century->SoilC().csrsnk[i] =
			century->SoilC().csrsnk[i] * myFraction +
			otherCentury.SoilC().csrsnk[i] * yourFraction;
	}
	for ( short i = 0; i < 4; ++i )
	{
		century->SoilC().metcis[i] =
			century->SoilC().metcis[i] * myFraction +
			otherCentury.SoilC().metcis[i] * yourFraction;
		century->SoilC().strcis[i] =
			century->SoilC().strcis[i] * myFraction +
			otherCentury.SoilC().strcis[i] * yourFraction;
		century->SoilC().som1ci[i] =
			century->SoilC().som1ci[i] * myFraction +
			otherCentury.SoilC().som1ci[i] * yourFraction;
	}
	century->SoilC().som2c =
		century->SoilC().som2c * myFraction +
		otherCentury.SoilC().som2c * yourFraction;
	century->SoilC().som3c =
		century->SoilC().som3c * myFraction +
		otherCentury.SoilC().som3c * yourFraction;
}

//	CombineCropGrassBiomassCPools
void TDayCentModel::CombineCropGrassBiomassCPools (
	TDayCentGCF const & otherCentury,
	float const myFraction,
	float const yourFraction)
{
	// crop/grass
	century->CropGrassC().aglivc =
		century->CropGrassC().aglivc * myFraction +
		otherCentury.CropGrassC().aglivc * yourFraction;
	century->CropGrassC().bglivc =
		century->CropGrassC().bglivc * myFraction +
		otherCentury.CropGrassC().bglivc * yourFraction;
	century->CropGrassC().creta =
		century->CropGrassC().creta * myFraction +
		otherCentury.CropGrassC().creta * yourFraction;
	century->CropGrassC().cinput =
		century->CropGrassC().cinput * myFraction +
		otherCentury.CropGrassC().cinput * yourFraction;
	for ( short i = 0; i < 2; ++i )
	{
		century->CropGrassC().agcisa[i] =
			century->CropGrassC().agcisa[i] * myFraction +
			otherCentury.CropGrassC().agcisa[i] * yourFraction;
		century->CropGrassC().aglcis[i] =
			century->CropGrassC().aglcis[i] * myFraction +
			otherCentury.CropGrassC().aglcis[i] * yourFraction;
		century->CropGrassC().bgcisa[i] =
			century->CropGrassC().bgcisa[i] * myFraction +
			otherCentury.CropGrassC().bgcisa[i] * yourFraction;
		century->CropGrassC().bglcis[i] =
			century->CropGrassC().bglcis[i] * myFraction +
			otherCentury.CropGrassC().bglcis[i] * yourFraction;
		century->CropGrassC().sdrmai[i] =
			century->CropGrassC().sdrmai[i] * myFraction +
			otherCentury.CropGrassC().sdrmai[i] * yourFraction;
		century->CropGrassC().shrmai[i] =
			century->CropGrassC().shrmai[i] * myFraction +
			otherCentury.CropGrassC().shrmai[i] * yourFraction;
	}
}

//	CombineForestBiomassCPools
void TDayCentModel::CombineForestBiomassCPools (
	TDayCentGCF const & otherCentury,
	float const myFraction,
	float const yourFraction)
{
	century->ForestC().cproda =
		century->ForestC().cproda * myFraction +
		otherCentury.ForestC().cproda * yourFraction;
	century->ForestC().crootc =
		century->ForestC().crootc * myFraction +
		otherCentury.ForestC().crootc * yourFraction;
	century->ForestC().fbrchc =
		century->ForestC().fbrchc * myFraction +
		otherCentury.ForestC().fbrchc * yourFraction;
	century->ForestC().frootc =
		century->ForestC().frootc * myFraction +
		otherCentury.ForestC().frootc * yourFraction;
	century->ForestC().rleavc =
		century->ForestC().rleavc * myFraction +
		otherCentury.ForestC().rleavc * yourFraction;
	century->ForestC().rlwodc =
		century->ForestC().rlwodc * myFraction +
		otherCentury.ForestC().rlwodc * yourFraction;
	century->ForestC().wood1c =
		century->ForestC().wood1c * myFraction +
		otherCentury.ForestC().wood1c * yourFraction;
	century->ForestC().wood2c =
		century->ForestC().wood2c * myFraction +
		otherCentury.ForestC().wood2c * yourFraction;
	century->ForestC().wood3c =
		century->ForestC().wood3c * myFraction +
		otherCentury.ForestC().wood3c * yourFraction;
	century->ForestC().tcrem =
		century->ForestC().tcrem * myFraction +
		otherCentury.ForestC().tcrem * yourFraction;
	for ( short i = 0; i < 2; ++i )
	{
		century->ForestC().crtcis[i] =
			century->ForestC().crtcis[i] * myFraction +
			otherCentury.ForestC().crtcis[i] * yourFraction;
		century->ForestC().fbrcis[i] =
			century->ForestC().fbrcis[i] * myFraction +
			otherCentury.ForestC().fbrcis[i] * yourFraction;
		century->ForestC().frtcis[i] =
			century->ForestC().frtcis[i] * myFraction +
			otherCentury.ForestC().frtcis[i] * yourFraction;
		century->ForestC().rlvcis[i] =
			century->ForestC().rlvcis[i] * myFraction +
			otherCentury.ForestC().rlvcis[i] * yourFraction;
		century->ForestC().rlwcis[i] =
			century->ForestC().rlwcis[i] * myFraction +
			otherCentury.ForestC().rlwcis[i] * yourFraction;
		century->ForestC().wd1cis[i] =
			century->ForestC().wd1cis[i] * myFraction +
			otherCentury.ForestC().wd1cis[i] * yourFraction;
		century->ForestC().wd2cis[i] =
			century->ForestC().wd2cis[i] * myFraction +
			otherCentury.ForestC().wd2cis[i] * yourFraction;
		century->ForestC().wd3cis[i] =
			century->ForestC().wd3cis[i] * myFraction +
			otherCentury.ForestC().wd3cis[i] * yourFraction;
	}
}

//	CombineNPools
void TDayCentModel::CombineNPools (
	TDayCentGCF const & otherCentury,
	float const myFraction,
	float const yourFraction)
{
	century->NPS().aglive[0] =
		century->NPS().aglive[0] * myFraction +
		otherCentury.NPS().aglive[0] * yourFraction;
	century->NPS().bglive[0] =
		century->NPS().bglive[0] * myFraction +
		otherCentury.NPS().bglive[0] * yourFraction;
	century->NPS().croote[0] =
		century->NPS().croote[0] * myFraction +
		otherCentury.NPS().croote[0] * yourFraction;
	century->NPS().ereta[0] =
		century->NPS().ereta[0] * myFraction +
		otherCentury.NPS().ereta[0] * yourFraction;
	century->NPS().esrsnk[0] =
		century->NPS().esrsnk[0] * myFraction +
		otherCentury.NPS().esrsnk[0] * yourFraction;
	century->NPS().eupacc[0] =
		century->NPS().eupacc[0] * myFraction +
		otherCentury.NPS().eupacc[0] * yourFraction;
	century->NPS().eupaga[0] =
		century->NPS().eupaga[0] * myFraction +
		otherCentury.NPS().eupaga[0] * yourFraction;
	century->NPS().eupbga[0] =
		century->NPS().eupbga[0] * myFraction +
		otherCentury.NPS().eupbga[0] * yourFraction;
	century->NPS().fbrche[0] =
		century->NPS().fbrche[0] * myFraction +
		otherCentury.NPS().fbrche[0] * yourFraction;
	century->NPS().forstg[0] =
		century->NPS().forstg[0] * myFraction +
		otherCentury.NPS().forstg[0] * yourFraction;
	century->NPS().froote[0] =
		century->NPS().froote[0] * myFraction +
		otherCentury.NPS().froote[0] * yourFraction;
	century->NPS().gromin[0] =
		century->NPS().gromin[0] * myFraction +
		otherCentury.NPS().gromin[0] * yourFraction;
	century->NPS().parent[0] =
		century->NPS().parent[0] * myFraction +
		otherCentury.NPS().parent[0] * yourFraction;
	century->NPS().rleave[0] =
		century->NPS().rleave[0] * myFraction +
		otherCentury.NPS().rleave[0] * yourFraction;
	century->NPS().rlwode[0] =
		century->NPS().rlwode[0] * myFraction +
		otherCentury.NPS().rlwode[0] * yourFraction;
	century->NPS().sdrmae[0] =
		century->NPS().sdrmae[0] * myFraction +
		otherCentury.NPS().sdrmae[0] * yourFraction;
	century->NPS().secndy[0] =
		century->NPS().secndy[0] * myFraction +
		otherCentury.NPS().secndy[0] * yourFraction;
	century->NPS().shrmae[0] =
		century->NPS().shrmae[0] * myFraction +
		otherCentury.NPS().shrmae[0] * yourFraction;
	century->NPS().soilnm[0] =
		century->NPS().soilnm[0] * myFraction +
		otherCentury.NPS().soilnm[0] * yourFraction;
	century->NPS().som2e[0] =
		century->NPS().som2e[0] * myFraction +
		otherCentury.NPS().som2e[0] * yourFraction;
	century->NPS().som3e[0] =
		century->NPS().som3e[0] * myFraction +
		otherCentury.NPS().som3e[0] * yourFraction;
	century->NPS().stdede[0] =
		century->NPS().stdede[0] * myFraction +
		otherCentury.NPS().stdede[0] * yourFraction;
	century->NPS().struce[0] =
		century->NPS().struce[0] * myFraction +
		otherCentury.NPS().struce[0] * yourFraction;
	century->NPS().terem[0] =
		century->NPS().terem[0] * myFraction +
		otherCentury.NPS().terem[0] * yourFraction;
	century->NPS().tminrl[0] =
		century->NPS().tminrl[0] * myFraction +
		otherCentury.NPS().tminrl[0] * yourFraction;
	century->NPS().tnetmn[0] =
		century->NPS().tnetmn[0] * myFraction +
		otherCentury.NPS().tnetmn[0] * yourFraction;
	century->NPS().totale[0] =
		century->NPS().totale[0] * myFraction +
		otherCentury.NPS().totale[0] * yourFraction;
	century->NPS().w1mnr[0] =
		century->NPS().w1mnr[0] * myFraction +
		otherCentury.NPS().w1mnr[0] * yourFraction;
	century->NPS().w2mnr[0] =
		century->NPS().w2mnr[0] * myFraction +
		otherCentury.NPS().w2mnr[0] * yourFraction;
	century->NPS().w3mnr[0] =
		century->NPS().w3mnr[0] * myFraction +
		otherCentury.NPS().w3mnr[0] * yourFraction;
	century->NPS().wood1e[0] =
		century->NPS().wood1e[0] * myFraction +
		otherCentury.NPS().wood1e[0] * yourFraction;
	century->NPS().wood2e[0] =
		century->NPS().wood2e[0] * myFraction +
		otherCentury.NPS().wood2e[0] * yourFraction;
	century->NPS().wood3e[0] =
		century->NPS().wood3e[0] * myFraction +
		otherCentury.NPS().wood3e[0] * yourFraction;
	century->NPS().woode[0] =
		century->NPS().woode[0] * myFraction +
		otherCentury.NPS().woode[0] * yourFraction;
#define EUPPRT(a_,b_)		eupprt[(b_)*FPARTS + (a_)]
	for ( short i = 0; i < FPARTS; ++i )
	{
		century->NPS().EUPPRT(i, N) =
			century->NPS().EUPPRT(i, N) * myFraction +
			otherCentury.NPS().EUPPRT(i, N) * yourFraction;
	}
#define METABE(a_,b_)		metabe[(b_)*NUMLAYERS + (a_)]
#define STRUCE(a_,b_)		struce[(b_)*NUMLAYERS + (a_)]
	for (short layer = SRFC; layer <= SOIL; ++layer)
	{
	}
	for (short layer = SRFC; layer <= SOIL; ++layer)
	{
	    century->NPS().STRUCE (layer, N) =
		century->NPS().STRUCE (layer, N) * myFraction +
		otherCentury.NPS().STRUCE (layer, N) * yourFraction;
	    century->NPS().METABE (layer, N) =
		century->NPS().METABE (layer, N) * myFraction +
		otherCentury.NPS().METABE (layer, N) * yourFraction;
	}
#define MINERL(a_,b_)		minerl[(b_)*MAXLYR + (a_)]
	short const numLayers = 7;	// To Do: change to soil layer count
	for (short layer = 0; layer < numLayers; ++layer)
	{
	    century->NPS().MINERL (layer, N) =
		century->NPS().MINERL (layer, N) * myFraction +
		otherCentury.NPS().MINERL (layer, N) * yourFraction;
	}
}

// ----------------------------------------------------------------------------
//	Century functions
// ----------------------------------------------------------------------------

TDayCentModel::TDailyCenturyConfigPtr TDayCentModel::ConfigureCentury ()
{
    TDailyCenturyConfigPtr myCenturyConfig;

    try
    {
	TAsynchCommunication asynchCom (
				DisplayMsg,		// message function
				DisplayMsg,		// warning function
				0 );			// sim. year function

	// initial site, management, fix.100, output files
	std::string workPath = GetConfiguration().GetInputPath();
	TEH::AppendSeparator ( workPath );

	// 1. get biome ID number
	TIDNumber const biomeID =
		owner->GetBiomeID();			// owner = cohort

	// 2. get biome config object
	::nrel::gcf::TBiomeConfigList const & biomeList =
		GetConfiguration().GetBiomes();
	Assert ( !biomeList.empty() );
	Assert ( biomeID < biomeList.size() );
	::nrel::gcf::TBiomeConfig const & biomeConfig = biomeList[biomeID];

	// 3. get site file name
	std::string siteFile = biomeConfig.siteParameterSource;
	TEH::PrependPathToFileIf ( siteFile, workPath );

	// 4. get mgmt file name
	std::string mgmtFile = biomeConfig.mgmtScheduleSource;
	TEH::PrependPathToFileIf ( mgmtFile, workPath );

	// 5. get fix.100 file name
	std::string const fixFileName = biomeConfig.fixFileName;

	// 6. output file
	bool doOutput = false;		// to do: toggle via config
	bool doDailyOutput = false;	// to do: toggle via config
	std::string outputFile;				// output file
	TOutputBase::TOutputType const outputType =	// file format type
		TOutputBase::Type_CSV;
	TOutputBase::TAccessMode const outputAccess =	// output access mode
		TOutputBase::Mode_Replace;
	if ( doOutput )
	{
		outputFile = workPath;
		MakeOutputFileName (outputFile);
	}

	// last-minute checks
	Assert (!siteFile.empty());
	Assert (!mgmtFile.empty());
	Assert (!workPath.empty());
	Assert (!GetConfiguration().GetExePath().empty());
	Assert (!fixFileName.empty());

	// search path for parameter files
	// for now, use the default path only
	TDailyCenturyConfig::TStringArray paramPathList;
//	if ( !cmdLine.GetParametersPath().empty() )
//		paramPathList.push_back ( cmdLine.GetParametersPath() );

	// create the Century object and check for errors
	myCenturyConfig.reset (
	    new TDailyCenturyConfig (
		siteFile, mgmtFile,
		outputFile, outputType, outputAccess,
		doOutput, doDailyOutput,
		GetConfiguration().GetExePath(),
		workPath,
		EMPTY_STRING,			// parameters path (use default)
		paramPathList,			// paths to search for params
		EMPTY_STRING,			// templates path (use default)
		EMPTY_STRING,			// textdata path (use default)
		fixFileName,			// path/name to fix.100
		GetConfiguration().GetUserName(),
		&asynchCom ) );
	myCenturyConfig->FindAndThrowError ();	// check for config. errors
    }
    catch (TDayCentException const& ce) 	// exceptions thrown by DayCent
    {
	::DisplayMsg ( ce.GetMsg().c_str() );
    }

    catch (TCentException const & ce)		// exceptions thrown by Century
    {
	::DisplayMsg ( ce.GetMsg().c_str() );
    }

    catch (std::exception const & e)		// other exceptions (elaborate!)
    {
	std::string msg ("An error terminates the simulation.\nError is: ");
	msg += e.what();
	::DisplayMsg ( msg.c_str() );
    }
						// error in paths
    catch ( CenturyPaths::TDefPathErr pathErr )
    {
	char const* errStr[] =
	{
		"no error",
		"no path",
		"invalid path index",
		"invalid executable file path",
		"invalid parameters path",
		"invalid templates path",
		"invalid management library path",
		"invalid site library path",
		"invalid block library path",
		"memory allocation failed",
		"unknown error",
		0
	};
	std::string msg ("Directory path error: ");
	msg += errStr[pathErr];
	::DisplayMsg ( msg.c_str() );
    }

    catch (char const * const aMsg)
    {
	::DisplayMsg (aMsg);
    }

    catch (std::string const & aMsg)
    {
	::DisplayMsg ( aMsg.c_str() );
    }

    catch (...)					// anything else not caught
    {
	::DisplayMsg ("An unknown error terminates the simulation.");
    }
    return myCenturyConfig;
}

TDayCentModel::TDayCentGCFPtr TDayCentModel::InstantiateCentury ()
{
	TDebugInfo dbgInfo;			// debugging flags
	Assert (centuryConfig.get() != 0);
	TDayCentGCFPtr myCentury (
		new TDayCentGCF (*centuryConfig, dbgInfo, *this) );
	return myCentury;
}

//--- end of definitions for TDayCentModel ---
