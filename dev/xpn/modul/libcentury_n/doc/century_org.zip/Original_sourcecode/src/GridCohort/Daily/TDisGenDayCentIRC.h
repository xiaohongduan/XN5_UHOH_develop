#ifndef INC_nrel_dcirc_TDisGenDayCentIRC_h
#define INC_nrel_dcirc_TDisGenDayCentIRC_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TDisGenDayCentIRC.h
//	Class:	  TDisGenDayCentIRC
//
//	Description:
//	Disturbance generator for DayCentIRC fire and agriculture.
//
//	Responsibilities:
//	* Knows the simulation configuration.
//	* If specified, reads the disturbance file into a disturbance list.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, July 2002
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------
//	Notes:
//
// ----------------------------------------------------------------------------

#include "TDisGenModelBase.h"
#include "TFireInfo.h"
#include "TDayCentIRCConfig.h"
#include "TDisturbanceList.h"
#include "TCalendarTools.h"
#include "TDayCentModel.h"
#include "GCFfwd.h"

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class TDisGenDayCentIRC
	: public ::nrel::gcf::TDisGenModelBase
{
  public:
	TDisGenDayCentIRC (
	  TDayCentIRCConfig const & useConfiguration)
	  : ::nrel::gcf::TDisGenModelBase (
	  	useConfiguration,
	  	::nrel::gcf::TDisGenBase::DGE_Fire),
	    mySimConfig (useConfiguration)
	  {
	    Initialize ();
	  }
	~TDisGenDayCentIRC ()
	  {
	  }

	//---- functions
	bool Disturb (				// Do a fire disturbance
	  ::nrel::gcf::TCohort * const cohort,	//   this cohort
	  TFireInfo & useFireInfo);		//   fire information

  private:
	//---- constants
	TDayCentIRCConfig const & mySimConfig;	// simulation configuration
	TCalendarTools calendarTools;

	//---- data
	float percentToBurn;			// amount of cohort to burn
	TDisturbanceList disturbList;		// disturbance list
	TDisturbanceList::iterator iDisturbList; // iterator to current record

	//---- functions
	void Initialize ();			// Initialize members
	bool ReadConfiguration ();		// Configure from file
	bool ProcessDisturbanceList (		// Check for disturbance events
	  ::nrel::gcf::TCohort * const cohort);	// Return true if disturbance

	//---- functions: Virtual
	// DoDisturbances
	// Do disturbances for the specified cohort.
	// Return true if a disturbance was done.
	bool DoDisturbances (
	  ::nrel::gcf::TCohort * const cohort)
	  {
	    bool didDisturbance = false;
	    // determine type of disturbance and trigger it

	    // Currently (July 2003), all fire disturbances are done from a
	    // mgmt. schedule file. See TDayCentGCF::InitMonthlyCycle.
	    // Here only disturbances from a disturbance list file
	    // are triggered.
	    if ( disturbList.size() > 0 )
		didDisturbance = ProcessDisturbanceList (cohort);

	    return didDisturbance;
	  }
};

  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_TDisGenDayCentIRC_h
