
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include "netcdf.h"
#include "wrtcdf.h"

/* added volpl -mdh 8/1/00 */

int
write_nflux(float nflux[][12])
{
        int status;
        float *p = (float *) nflux;

	/* Write output to NetCDF file */
	/* There are at most 10 layers - output all regardless */
	status = nc_put_vara_float(nflux_ncid, minerl_id, start_layer, count_layer, p);
	status = nc_put_vara_float(nflux_ncid, nfix_id, start, count, p + 120);
	status = nc_put_vara_float(nflux_ncid, volex_id, start, count, p + 132);
	status = nc_put_vara_float(nflux_ncid, volgm_id, start, count, p + 144);
	status = nc_put_vara_float(nflux_ncid, volpl_id, start, count, p + 156);
	status = nc_put_vara_float(nflux_ncid, wdfxma_id, start, count, p + 168);
	status = nc_put_vara_float(nflux_ncid, wdfxms_id, start, count, p + 180);

	/* Reset memory for variable nflux */
	 memset(p, '\0', (sizeof(float) * 16 * 12));

	return 0;
}
