#ifndef INC_TMCMicrobial_h
#define INC_TMCMicrobial_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model (Monthly)
//	File:	  TMCMicrobial.h
//	Class:	  TMCMicrobial
//
//	Description:
//	Class for microbial decomposition submodel for monthly Century.
//	Members were extracted from class TCentury.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, April 2004
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TMicrobialBase.h"
#include "TCenturySoil.h"
#include "TMCSoilFlows.h"
#include "TSimTime.h"

class TMCMicrobial
	: public TMicrobialBase
{
  public:
	//---- constructors and destructor
	TMCMicrobial (
	  TCenturySoil const & useSoil,			// soil
	  TMCSoilFlows & useSoilFlows,			// soil flows
	  TSimTime const & useSimTime,			// simulation timer
	  float const usePeftxa,	// Intercept; soil texture effect eq.
	  float const usePeftxb,	// Slope; soil texture effect eq.
	  float const useDecompRateActiveSOM[2],	// fixed.dec3[]
	  TLabeling const useIsotopeC, 	// C labeling
	  				//   (0=none, 1=14C, 2=13C)
	  float const useDf13C,		// discrimination factor for 13C due to
					//   microbial respiration.(fixed.dresp)
	  short const useNumElem)	// number of elements (N=1, P=1, S=3)
	  : TMicrobialBase (
	  	useSoilFlows, useSimTime, usePeftxa, usePeftxb,
	  	useDecompRateActiveSOM, useIsotopeC, useDf13C, useNumElem ),
	    soil (useSoil)
	  {
	  }
	TMCMicrobial (				// copy constructor
	  TMCMicrobial const & object,		//   object to copy
	  // Instances of Century submodels - refs to owner's objects
	  TCenturySoil & useSoil,			// soil
	  TMCSoilFlows & useSoilFlows,
	  TSimTime const & useSimTime)
	  : TMicrobialBase (
	  	object,
	  	useSoilFlows, useSimTime),
	    soil (useSoil)
	  {
	  }
	virtual ~TMCMicrobial ()
	  {
	  }
	virtual TMCMicrobial * const Clone () const;	// Clone this

	//---- operator overloads

	//---- functions
	void Respiration (
	  float const co2Loss, 		// CO2 loss from decomposition
	  short const numLayers,	// number of layers modeled for Box A;
					//   =2 for structural, metabolic, som1;
					//   =1 for som2, som3, wood pools.
					//   This is left dim. of the arrays
					//   cstatv, estatv, netMin.
	  short const layer,  		// soil layer (values: SRFC, SOIL)
	  float const * const tcstva,	// [numLayers]: C in each layer of Box A
	  float* const cstatv,		// [numLayers,ISOS]: C in Box A
	  float* const csrsnk,		// [ISOS]: C source/sink
	  float* const respiration,	// respiration; array[2]
	  float* const estatv,		// [numLayers,NUMELEM]: N,P,S for Box A
	  float* const grossMin,	// [NUMELEM]: gross mineralization
	  float* const netMin,		// [numLayers,NUMELEM]: net mineraliz.
	  float const simDepth);		// simulation layer depth (cm)

  protected:
	//---- data
	TCenturySoil const & soil;

	//---- functions

  private:
	//---- data

	//---- functions

};

#endif // INC_TMCMicrobial_h
