// ----------------------------------------------------------------------------
//	Copyright 1999-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TDayCentSoil.cpp
//	Class:	  TDayCentSoil
//
//	Description:
//	Derived from TCenturySoil, implements DayCent-specific functions.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Dec99
//              Melannie Hartman, melannie@nrel.colostate.edu (DayCent updates)
// ----------------------------------------------------------------------------
//	History: See header file.
//	Added indexKsat, indexVSwcMin (Mar 2001)
//		indexSoilTempAvg, indexSoilTempMin, indexSoilTempMax (4/4/01)
//		indexNitrate, indexAmmonium (4/11/01)
//		indexPhosphorus, indexSulfur (6/15/01)
//	Nov02   Tom Hilinski, tom.hilinski@colostate.edu
//	* Misc. clean up, const-correctness, optimization.
// ----------------------------------------------------------------------------
//      Notes:
//      * Need a way to designate volcanic soil (textureIndex == VERYFINE)
//        -mdh 5/16/01
// ----------------------------------------------------------------------------

#include "TDayCentSoil.h"
#include <numeric>
#include <cmath>
using namespace std;

// ----------------------------------------------------------------------------
//	Member constants
// ----------------------------------------------------------------------------

float const TDayCentSoil::PARTDENS = 2.65f;	// Particle Density (g/cm^3)
float const TDayCentSoil::BAR2CM = 1024.0f;	// 1 bar = 1024 cm H2O
long const TDayCentSoil::SEC_PER_DAY = 86400;	// # of seconds per day
short const TDayCentSoil::SEC_PER_HOUR = 3600;	// # of seconds per hour
short const TDayCentSoil::HOURS_PER_DAY = 24;	// # of hours per day
// float const TDayCentSoil::frozenSoilTemp = -1.0f;	// temperature soil freezes (deg C)
double const TDayCentSoil::MIN_FRZN_COND = 0.00005; // hydraul cond in frzn soil (cm/sec)
//<<Gridded>>
short const TDayCentSoil::PPTDAYS = 15;		// nox_pulse.cpp
short const TDayCentSoil::PLDAYS = 2;		// nox_pulse.cpp
short const TDayCentSoil::PMDAYS = 6;		// nox_pulse.cpp
short const TDayCentSoil::PHDAYS = 13;		// nox_pulse.cpp


// The following indices must match the order in which the components are
// added to the component list.
// See sitein.cpp for the actual order.
short const					// component indices
	TDayCentSoil::indexKsat                 = 8,
	TDayCentSoil::indexVSwcMin              = 9,
	TDayCentSoil::indexSoilTempAvg          = 10,
	TDayCentSoil::indexSoilTempMin          = 11,
	TDayCentSoil::indexSoilTempMax          = 12,
	TDayCentSoil::indexNitrate              = 13,
	TDayCentSoil::indexAmmonium             = 14,
	TDayCentSoil::indexPhosphorus           = 15,
	TDayCentSoil::indexSulfur               = 16;

// ----------------------------------------------------------------------------
//	constructors and destructor
// ----------------------------------------------------------------------------

//--- operator overloads

//--- Miscellaneous public

//	Clear
//	"clear" data members
void TDayCentSoil::Clear ()
{
	TCenturySoil::Clear ();
	Initialize ();
}

// ----------------------------------------------------------------------------
//	public functions - DayCent Specific
// ----------------------------------------------------------------------------

//      WtdMeanWFPS
//      Return weighted mean of water filled pore space
//      between top 0 - toDepth cm of soil
float TDayCentSoil::WtdMeanWFPS (
	float const toDepth	  // depth into soil (cm)
	) const
{
    Assert ( toDepth > 0.0f );
    Assert ( toDepth <= SoilDepth() );

    short const layerIndex = GetLayerIndex(toDepth);
    float avgWFPS = 0.0f;
    float thicknessSum = 0.0f;
    for (short layer = 0; layer < layerIndex; layer++)
    {
       avgWFPS += thickness[layer] * WFPS ( layer );
       thicknessSum += thickness[layer];
    }
    avgWFPS += (toDepth - thicknessSum) * WFPS ( layerIndex );
    thicknessSum +=  (toDepth - thicknessSum);
    avgWFPS /= thicknessSum;
    return avgWFPS;
}

//      SetSoilTextureIndexFromFraction
//      Set the value of textureIndex
void TDayCentSoil::SetSoilTextureIndexFromFraction (
    float const sandFraction)
{
    Assert (sandFraction >= 0.0f);
    Assert (sandFraction <= 1.0f);

    if (sandFraction > 0.70f)
       textureIndex = COARSE;
    else if (sandFraction <= 0.70f && sandFraction >= 0.30f)
       textureIndex = MEDIUM;
    else if (sandFraction < 0.30f)
	textureIndex = FINE;

    // Currently VERYFINE can not be set from knowing sand content
}

//      NitrateFraction
//      Return fraction of mineral N in entire soil profile that is nitrate.
float TDayCentSoil::NitrateFraction () const
{
    short const bottomLayer = GetLayerCount() - 1;
    float const nitrate = Nitrate().Quantity(0, bottomLayer);
    float const ammonium = Ammonium().Quantity(0, bottomLayer);
    float fracNO3 = nitrate / ( nitrate + ammonium );
    if (ammonium <= 0.0f)
	fracNO3 = 1.0f;
    if (nitrate <= 0.0f)
	fracNO3 = 0.0f;
    Assert (fracNO3 >= 0.0f);
    Assert (fracNO3 <= 1.0f);
    return fracNO3;
}

//      NitrateFraction
//      Return fraction of mineral N in soil that is nitrate within a soil
//      region between topDepth and bottomDepth (cm).
float TDayCentSoil::NitrateFraction (
    float const topDepth,       // top of soil region from soil surface (cm)
    float const bottomDepth)    // bottom of soil region from soil surface (cm)
    const
{
    float const nitrate =
	Nitrate().Quantity( topDepth, bottomDepth, depth, thickness );
    float const ammonium =
	Ammonium().Quantity( topDepth, bottomDepth, depth, thickness );
    float fracNO3 = nitrate / ( nitrate + ammonium );
    if (ammonium <= 0.0f)
	fracNO3 = 1.0f;
    if (nitrate <= 0.0f)
	fracNO3 = 0.0f;
    Assert (fracNO3 >= 0.0f);
    Assert (fracNO3 <= 1.0f);
    return fracNO3;
}

// ----------------------------------------------------------------------------
//	public functions - water submodel
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions - soil temperature
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	MidPointsOfLayers
//	Calc depths to midpoints of layers.
//	To Do: make "dist" scalar. "depthToMidPt" remains a shared soil array.
void TDayCentSoil::MidPointsOfLayers ()
{
	// resize if needed
	if ( depthToMidPt.size() != GetLayerCount() )
	{
		depthToMidPt.resize ( GetLayerCount() );
		dist.resize ( GetLayerCount() );
	}

	// To Do: put pointers in this loop
	dist(0) = depthToMidPt(0) = 0.5f * thickness[0];
	for (short layer = 1; layer < GetLayerCount(); layer++)
	{
		// dist = mean thickness of adjacent layers.
		// (h2oflux.cpp says it is supposed to be:
		//  "distance between midpoint of two adjacent layers")
		// (TDayCentSoil.h says it is supposed to be:
		//  "thickness of upper half of layers")
		// But...
		// dist is only used in h2oflux.cpp, in calculating Darcy's Eq.
		// flux = K * delta_head / delta_depth
		// This suggests that the calc is correct as shown:
		// "distance between midpoint of two adjacent layers"
		dist(layer) = 0.5f * (thickness[layer-1] + thickness[layer]);
		// depth = cumulative sum of mean thicknesses of adjacent layers
		depthToMidPt(layer) = depthToMidPt(layer-1) + dist(layer);
	}
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Initialize
//	initialize members
//	Note: undefined values require initialization elsewhere.
void TDayCentSoil::Initialize ()
{
	deepSoilWaterStore = 0.0f;
	for ( short i = 0; i < NUMELEM; ++i )
		deepSoilMnrlStore[i] = 0.0;

	InitializeSoilTempModel ();
	InitializeNOxPulseModel ();

	pHsoil = -1.0f;					// undefined value
	textureIndex = UNDEFINED;			// undefined value

	soilWaterModel.reset ( new SoilWaterModel () );
}

//	Copy
// 	copy to this
void TDayCentSoil::Copy (
	const TDayCentSoil& fromObj)
{
	if ( &fromObj && fromObj.GetLayerCount() > 0 )
	{
		CopySoilTempModel (fromObj);
		CopyNOxPulseModel (fromObj);

		//--- data: SoilWaterFlux
		deepSoilWaterStore = fromObj.deepSoilWaterStore;
		for ( short i = 0; i < NUMELEM; ++i )
			deepSoilMnrlStore[i] = fromObj.deepSoilMnrlStore[i];

		//--- data: Misc
		pHsoil = fromObj.pHsoil;
		textureIndex = fromObj.textureIndex;
	}
}

//--- end of definitions for TDayCentSoil ---

