#ifndef INC_TMgtFromLibDlg_h
#define INC_TMgtFromLibDlg_h

// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TMgtFromLibDlg.h
//	Class:	  TMgtFromLibDlg
//
//	Description:
//	Class for copying a management scheme from the library.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Apr98
//	History:
// ----------------------------------------------------------------------------

#include "TModalDlg.h"
#include "TFileName.h"
#include <v/vapp.h>

//	Command objects values

#ifdef _TMgtFromLibDlg_ClassDefined_

enum {
	Enum_MgtFromLib_Start = 11000,	// first item!
					//--- Mgmt. library (radiobuttons)
	D_DefaultLib,			// app default library folder
	D_PersonalLib,			// user's personal library folder
					//--- Mgmt. list and data
	D_DescripList, 			// list: descriptions
	D_MgmtFile,			// r/o text: Mgmt. file base name
					//--- all done!
	Enum_MgtFromLib_End		// last item!
};

#endif	// _TMgtFromLibDlg_ClassDefined_

//	-----------------------------------------------------------------------
//	TMgtFromLibDlg
class TMgtFromLibDlg : public TModalDlg
{
  public:
	//--- constructors and destructor
	TMgtFromLibDlg (
	  vApp * const useParent,		// pointer to application
	  std::string const & newDefPath,	// default path for libraries
	  std::string const & newUserPath,	// user's library path
	  char*& mgmtFileBase,			// returned value = file name
	  std::string const & useHelpPath,	// path to help file
	  char const * const title		// dialog title
	  	= "Select a Management Scheme");
	~TMgtFromLibDlg ();
	//--- functions overridden
	void DialogDisplayed ();
	void DialogCommand (ItemVal id, ItemVal val, CmdType type);

  private:
	//--- data
					//--- data passed into constructor
	vApp * const parent;			// application parent
	std::string const & helpFilePath;	// path to help file
					//--- dialog
	static CommandObject
			cmdList[];	// dialog elements
	char **descList[2];		// description lists
					// (0 = default, 1 = personal)
	char **fnameList[2];		// file name list
	     				// (0 = default, 1 = personal)
	std::string libPath[2];		// paths to the site files
	short usingPath;		// which path is selected (0, 1)
	short usingMgmt;		// index to selected mgmt. scheme
	short idxParamList;		// index to description list in cmdList

	//--- functions
	void Initialize ();		// initialize members
	void ReadDescriptions ();	// gets site descriptions from files
					//--- Load data into dialogs:
	void LoadDlg ();	   	// load the dialog
	void UpdateDlg_DescList ();	// mgmt. scheme list
	void UpdateDlg_MgmtData ();	// mgmt. data
					//--- Clear dialog controls:
	void ClearDlgMgmtList ();	// Clear site list display
};

#endif // INC_TMgtFromLibDlg_h
