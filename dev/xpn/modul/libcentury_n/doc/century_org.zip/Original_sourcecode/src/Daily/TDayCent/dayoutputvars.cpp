// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  dayoutputvars.cpp
//	Class:	  Century output variable classes.
//
//	Description:
//	Implementation of member functions for the DayCent output variable
//	classes.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jun98
// ----------------------------------------------------------------------------
//	History:
//      See header file and Century/outputvars.cpp
// ----------------------------------------------------------------------------

#include "dayoutputvars.h"

//	------------------------------------------------------------
//	TDailyWaterTemp

void TDailyWaterTemp::Clear ()
{
    defac = 0.0f;
    evap = 0.0f;
    irract = 0.0f;
    pet = 0.0f;
    precip = 0.0f;
    runoff = 0.0f;
    snlq = 0.0f;
    snow  = 0.0f;
    simDepth = soilDepth = 0.0f;
    stemp =  0.0f;

    for ( short i = 0; i < 8; i++ )
        stream[i] = 0.0f;

    sublim = 0.0f;
    tave = 0.0f;
    tfunc = 0.0f;
    tran = 0.0f;
    wfunc = 0.0f;

    for ( short i = 0; i < MAXLYR; i++ )
    {
        amtTrans[i] = 0.0f;
 	swc[i] = 0.0f;
        sTempMin[i] = 0.0f;
        sTempMax[i] = 0.0f;
        wfps[i] = 0.0f;
    }

}	// TDailyWaterTemp::Clear

void TDailyWaterTemp::AssignPointers ()
{
	float **v = p;
	for ( short i = 0; i < MAXLYR; i++ )
            *(v++) = &amtTrans[i];
        *(v++) = &anerb;
	*(v++) = &defac;
	*(v++) = &evap;
	*(v++) = &irract;
	*(v++) = &pet;
	*(v++) = &precip;
	*(v++) = &runoff;
        *(v++) = &simDepth;
	*(v++) = &soilDepth;
        *(v++) = &snlq;
	*(v++) = &snow;
	*(v++) = &stemp;
	for ( short i = 0; i < MAXLYR; i++ )
            *(v++) = &sTempMin[i];
        for ( short i = 0; i < MAXLYR; i++ )
            *(v++) = &sTempMax[i];
	for ( short i = 0; i < 8; i++ )
            *(v++) = &stream[i];
        *(v++) = &sublim;
        for ( short i = 0; i < MAXLYR; i++ )
            *(v++) = &swc[i];
        *(v++) = &tave;
        *(v++) = &tfunc;
	*(v++) = &tran;
        for ( short i = 0; i < MAXLYR; i++ )
            *(v++) = &wfps[i];
        *v = &wfunc;

}	// TDailyWaterTemp::AssignPointers

//	------------------------------------------------------------
//	TDailyTraceGas

void TDailyTraceGas::Clear ()
{
        for ( short i = 0; i < MAXLYR; i++ )
        {
            ammonium[i] = 0.0f;
            nitrate[i] = 0.0f;
            phosphorus[i] = 0.0f;
            sulfur[i] = 0.0f;
        }
        for ( short i = 0; i < NUMELEM; i++ )
            netMin[i] = 0.0f;
        CH4flux = 0.0f;
        CO2flux = 0.0f;
        N2flux = 0.0f;
        N2Oflux_dnit = 0.0f;
        N2Oflux_nit = 0.0f;
        NOflux = 0.0f;

}	// TDailyTraceGas::Clear

void TDailyTraceGas::AssignPointers ()
{
	float **v = p;
	for ( short i = 0; i < MAXLYR; i++ )
            *(v++) = &ammonium[i];
        *(v++) = &CH4flux;
        *(v++) = &CO2flux;
        for ( short i = 0; i < NUMELEM; i++ )
           *(v++) = &netMin[i];
        for ( short i = 0; i < MAXLYR; i++ )
            *(v++) = &nitrate[i];
        *(v++) = &N2flux;
        *(v++) = &N2Oflux_dnit;
        *(v++) = &N2Oflux_nit;
        *(v++) = &NOflux;
        for ( short i = 0; i < MAXLYR; i++ )
            *(v++) = &phosphorus[i];
	for ( short i = 0; i < MAXLYR-1; i++ )
            *(v++) = &sulfur[i];
        *v = &sulfur[MAXLYR-1];

}	// TDailyTraceGas::AssignPointers

//	------------------------------------------------------------
//	TDailyCFluxStore

void TDailyCFluxStore::Clear ()
{
    cropProduction[0] = 0.0f;            // Above ground
    cropProduction[1] = 0.0f;            // Below ground
    for (short i = 0; i < 5; i++)        // leaf, froot, fbrnch, lgwood, croot
        treeProduction[i] = 0.0f;
    mRespAnn[0] = 0.0f;                  // Crop/Grass
    mRespAnn[1] = 0.0f;                  // Forest
    mRespStorageCrop[0] = 0.0f;          // Unlabeled
    mRespStorageCrop[1] = 0.0f;          // Labeled
    mRespStorageTree[0] = 0.0f;          // Unlabeled
    mRespStorageTree[1] = 0.0f;          // Labeled
    mRespFlowToStore[0] = 0.0f;          // Crop/Grass
    mRespFlowToStore[1] = 0.0f;          // Forest
    mRespFluxCrop[0] = 0.0f;             // Crop, above ground
    mRespFluxCrop[1] = 0.0f;             // Crop, below ground
    for (short i = 0; i < 5; i++)        // leaf, froot, fbrnch, lgwood, croot
        mRespFluxTree[i] = 0.0f;
    cropCAllocStorage[0] = 0.0f;         // Unlabeled
    cropCAllocStorage[1] = 0.0f;         // Labeled
    treeCAllocStorage[0] = 0.0f;         // Unlabeled
    treeCAllocStorage[1] = 0.0f;         // Labeled

}	// TDailyCFluxStore::Clear

void TDailyCFluxStore::AssignPointers ()

{
    float **v = p;

    *(v++) = &cropProduction[0];         // above ground
    *(v++) = &cropProduction[1];         // below ground
    for (short i = 0; i < 5; i++)        // leaf, froot, fbrnch, lgwood, croot
        *(v++) = &treeProduction[i];
    *(v++) = &mRespAnn[0];               // Crop/Grass
    *(v++) = &mRespAnn[1];               // Forest
    *(v++) = &mRespStorageCrop[0];       // Unlabeled
    *(v++) = &mRespStorageCrop[1];       // Labeled
    *(v++) = &mRespStorageTree[0];       // Unlabeled
    *(v++) = &mRespStorageTree[1];       // Labeled
    *(v++) = &mRespFlowToStore[0];       // Unlabeled
    *(v++) = &mRespFlowToStore[1];       // Labeled
    *(v++) = &mRespFluxCrop[0];          // above ground
    *(v++) = &mRespFluxCrop[1];          // below ground
    for (short i = 0; i < 5; i++)        // leaf, froot, fbrnch, lgwood, croot
        *(v++) = &mRespFluxTree[i];
    *(v++) = &cropCAllocStorage[0];      // Unlabeled
    *(v++) = &cropCAllocStorage[1];      // Labeled
    *(v++) = &treeCAllocStorage[0];      // Unlabeled
    *v = &treeCAllocStorage[1];          // Labeled

}	// TDailyCFluxStore::AssignPointers

//	------------------------------------------------------------
//	TNPSflux

void TNPSflux::Clear ()
{
	nfix = 0.0f;
	wdfxma = 0.0f;
	wdfxms = 0.0f;
	for ( short i = 0; i < 3; i++ )
	{
		fertot[i] = 0.0f;
		s2mnr[i] = 0.0f;
		s3mnr[i] = 0.0f;
		w1mnr[i] = 0.0f;
		w2mnr[i] = 0.0f;
		w3mnr[i] = 0.0f;
	}
	for ( short i = 0; i < 6; i++ )
	{
		metmnr[i] = 0.0f;
		strmnr[i] = 0.0f;
		s1mnr[i] = 0.0f;
	}

}	// TNPSflux::Clear

void TNPSflux::AssignPointers ()
{
	register short i, j;
	float **v = p;

	*(v++) = &nfix;
	*(v++) = &wdfxma;
	*(v++) = &wdfxms;
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &fertot[i];
#define metmnr_ref(a,b)		metmnr[(b)*NUMLAYERS + a]
	for ( i = 0; i < NUMLAYERS; i++ )			// layer
		for ( j = 0; j < NUMELEM; j++ )			// N,P,S
			*(v++) = &metmnr_ref (i, j);
#undef metmnr_ref
#define s1mnr_ref(a,b)		s1mnr[(b)*NUMLAYERS + a]
	for ( i = 0; i < NUMLAYERS; i++ )			// layer
		for ( j = 0; j < NUMELEM; j++ )			// N,P,S
			*(v++) = &s1mnr_ref (i, j);
#undef s1mnr_ref
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &s2mnr[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &s3mnr[i];
#define strmnr_ref(a,b)		strmnr[(b)*NUMLAYERS + a]
	for ( i = 0; i < NUMLAYERS; i++ )			// layer
		for ( j = 0; j < NUMELEM; j++ )			// N,P,S
			*(v++) = &strmnr_ref (i, j);
#undef strmnr_ref
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &w1mnr[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &w2mnr[i];
	for ( i = 0; i < NUMELEM; i++ )
		*(v++) = &w3mnr[i];

}	// TNPSflux::AssignPointers

//	------------------------------------------------------------
//	TCO2flux

void TCO2flux::Clear ()
{
	for ( short i = 0; i < 2; i++ )
	{
		mt1c2[i] = 0.0f;
		mt2c2[i] = 0.0f;
		s11c2[i] = 0.0f;
		s21c2[i] = 0.0f;
		s2c2[i] = 0.0f;
		s3c2[i] = 0.0f;
		st1c2[i] = 0.0f;
		st2c2[i] = 0.0f;
                wd1c2[i] = 0.0f;
                wd2c2[i] = 0.0f;
                wd3c2[i] = 0.0f;
	}
}	// TCO2flux::Clear

void TCO2flux::AssignPointers ()
{
	float **v = p;
	*(v++) = &mt1c2[0];
	*(v++) = &mt1c2[1];
	*(v++) = &mt2c2[0];
	*(v++) = &mt2c2[1];
	*(v++) = &s11c2[0];
	*(v++) = &s11c2[1];
	*(v++) = &s21c2[0];
	*(v++) = &s21c2[1];
	*(v++) = &s2c2[0];
	*(v++) = &s2c2[1];
	*(v++) = &s3c2[0];
	*(v++) = &s3c2[1];
	*(v++) = &st1c2[0];
	*(v++) = &st1c2[1];
	*(v++) = &st2c2[0];
	*(v++) = &st2c2[1];
        *(v++) = &wd1c2[0];
        *(v++) = &wd1c2[1];
        *(v++) = &wd2c2[0];
        *(v++) = &wd2c2[1];
        *(v++) = &wd3c2[0];
        *(v++) = &wd3c2[1];
}	// TCO2flux::AssignPointers

// ----- end of file -----


