#ifndef INC_SiteEditorDataSrcBase_h
#define INC_SiteEditorDataSrcBase_h
// ----------------------------------------------------------------------------
//	Copyright 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  SiteEditorDataSrcBase.h
//	Class:	  SiteEditorDataSrcBase
//
//	Description:
//	Base class for the data source for the Site Editor for
//	Century5 site parameters.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Aug04
//	History:
// ----------------------------------------------------------------------------

#include "EditedDataBase.h"

template
<
	class ParametersType,		// parameters class
	class ParametersInfoType	// parameters info class
>
class SiteEditorDataSrcBase
	: public EditedDataBase<ParametersType>
{
  public:
	virtual ~SiteEditorDataSrcBase ()
	  {
	  }
	void Clear ()
	  {
	    // clear parameter data
	    Get()->Fill (
		0, Get()->GetSetCount(),	// range
		0.0f );
		// TSiteParameter() );		// source of values
	  }
	  typename ParametersInfoType::TInfoPtr GetParametersInfo () const
	    { return info; }

  protected:
	typename ParametersInfoType::TInfoPtr info;	// parameter names

  	SiteEditorDataSrcBase (
	  typename ParametersInfoType::TInfoPtr useInfo)
	  : EditedDataBase<ParametersType> (),
	    info (useInfo)
  	  {
  	  }
	SiteEditorDataSrcBase (
	  SiteEditorDataSrcBase<ParametersType, ParametersInfoType>
	      const & object)
	  : EditedDataBase<ParametersType> (object),
	    info (object.info)
  	  {
  	  }

  private:
	virtual bool DoIsEmpty () const
	  {
	    ParametersType const * const parameters =
		dynamic_cast<ParametersType const * const>(
			dataPtr.get() );
	    return ( parameters != 0 ?
	    		parameters->IsEmpty() :
	    		true );
	  }
};

#endif // INC_SiteEditorDataSrcBase_h
