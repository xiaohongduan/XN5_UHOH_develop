// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  cycle.cpp
//	Class:	  TDayCent
//	Function: InitMonthlyCycle
//
//	Description:
//	Initialize monthly cycle.
// ----------------------------------------------------------------------------
//	History:
//      See DayCent/cycle_dc.cpp
// ----------------------------------------------------------------------------

#include "TDayCent.h"

void TDayCent::InitMonthlyCycle ()
{
        GetBiomass ();

        //--- calc surface temperature from biomass
	// Maximum mean monthly temperature
	float const tmxs =
		weather->TempMax(st->month) + 25.4f /
		(std::exp (weather->TempMax(st->month) * -0.20f) *
			18.0f + 1.0f) *
		(std::exp (fixed.pmxtmp * dailyBiomass.biomass) - 0.13f);
	// Minimum mean monthly temperature
	float const tmns = weather->TempMin(st->month) +
  			fixed.pmntmp * dailyBiomass.biomass - 1.78f;
	// Average surface temperature
	// Note: soil temp. does not take into account the effect of snow (AKM)
	float const stemp = (tmxs + tmns) * 0.5f;

	//--- schedule this month's management events ---
        Schedule (stemp);		// scheduling options for this month
        ResetMonthlyValues ();		// reset monthly accumulators and avgs

	//--- Initialize erosion and deposition monthly variables
	soilC.eroC = soilC.depC = 0.0f;

}

//--- end of file init_monthly.cpp ---

