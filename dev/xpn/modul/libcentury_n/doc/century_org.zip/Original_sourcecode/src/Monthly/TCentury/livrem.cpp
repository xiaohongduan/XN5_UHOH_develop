// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  livrem.cpp
//	Class:	  TCentury
//	Function: ForestLiveBiomassRem
//
//	Description:
//	Removal of live biomass due to cutting or fire in a forest.
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TCentury.h"

void TCentury::ForestLiveBiomassRem (
	float *accum)	// array [ISOS]: cumulative C
{
    float closs,	//
      eloss[NUMELEM];	//

    if (forestC.rleavc > 0.0f)			// Remove live LEAVES
    {
	// remf(ipool) = removal fraction
	// ipool indicates which state variable
	closs = forrem.remf[0] * forestC.rleavc;
	forestC.tcrem += closs;
	ScheduleCFlow ( st->time, closs,
		forestC.rlvcis[LABELD] / forestC.rleavc, 1.0f,
		&forestC.rlvcis[UNLABL], &soilC.csrsnk[UNLABL],
		&forestC.rlvcis[LABELD], &soilC.csrsnk[LABELD],
		accum);
	for (short iel = 0; iel < site.nelem; ++iel)
	{
	    eloss[iel] = closs * nps.rleave[iel] / forestC.rleavc;
	    nps.terem[iel] += eloss[iel];
	    flows->Schedule (&nps.rleave[iel], &nps.esrsnk[iel],
	    		    st->time, eloss[iel]);
	}
    }
    if (forestC.fbrchc > 0.0f)			// Remove live FINE BRANCHES
    {
	closs = forrem.remf[1] * forestC.fbrchc;
	forestC.tcrem += closs;
	ScheduleCFlow ( st->time, closs,
		forestC.fbrcis[LABELD] / forestC.fbrchc, 1.0f,
		&forestC.fbrcis[UNLABL], &soilC.csrsnk[UNLABL],
		&forestC.fbrcis[LABELD], &soilC.csrsnk[LABELD],
		accum);
	for (short iel = 0; iel < site.nelem; ++iel)
	{
	    eloss[iel] = closs * nps.fbrche[iel] / forestC.fbrchc;
	    nps.terem[iel] += eloss[iel];
	    flows->Schedule (&nps.fbrche[iel], &nps.esrsnk[iel],
	    		    st->time, eloss[iel]);
	}
    }
    if (forestC.rlwodc > 0.0f)			// Remove live LARGE WOOD
    {
	closs = forrem.remf[2] * forestC.rlwodc;
	forestC.tcrem += closs;
	ScheduleCFlow ( st->time, closs,
		forestC.rlwcis[LABELD] / forestC.rlwodc, 1.0f,
		&forestC.rlwcis[UNLABL], &soilC.csrsnk[UNLABL],
		&forestC.rlwcis[LABELD], &soilC.csrsnk[LABELD],
		accum);
	for (short iel = 0; iel < site.nelem; ++iel)
	{
	    eloss[iel] = closs * nps.rlwode[iel] / forestC.rlwodc;
	    nps.terem[iel] += eloss[iel];
	    flows->Schedule (&nps.rlwode[iel], &nps.esrsnk[iel],
	    		    st->time, eloss[iel]);
	}

	// Remove from STORAGE pool based on fraction of large wood removed.
	for (short iel = 0; iel < site.nelem; ++iel)
	{
	    eloss[iel] = std::max (forrem.remf[2] * nps.forstg[iel], 0.0f);
	    flows->Schedule (&nps.forstg[iel], &nps.esrsnk[iel],
	    		    st->time, eloss[iel]);
	}
    }
}
