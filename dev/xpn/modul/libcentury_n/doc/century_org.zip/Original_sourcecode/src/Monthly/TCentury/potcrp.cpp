// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  potcrp.cpp
//	Class:	  TCentury
//	Function: CropGrassProductionPotential
//
//	Description:
// 	Compute monthly production potential based upon montly precipitation,
// 	and restrict potential production based upon the method specified
// 	by grzeff.
// ----------------------------------------------------------------------------
//	History:
//	Nov01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Changed many variable names to be descriptive and obvious.
//	* Moved moisture ratio to inline function in TCentury.h
//	* Removed "month" parameter - no longer needed.
//	* Changed name: ProductionPotential to CropGrassProductionPotential.
//	* Returns potentProd.cropC
//	May03	Tom Hilinski
//	* Moved restriction on grazing code into
//	  TCenturyBase::RestrictCropProdGrazing.
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include "ranfun.h"
#include <cmath>

float TCentury::CropGrassProductionPotential (
	float const canopyCover)	// canopy cover
{
    Assert (canopyCover >= 0.0f);

    if (wt.stemp <= 0.0f)
    {
	// No production this month
	potentProd.total = potentProd.aboveGround = potentProd.cropC = 0.0f;
	return 0.0f;
    }

    float r1, r2;	// for min and max temp values

    // ------------------------------------------------------------------------
    // Shading modifier for savanna
    float shadeEffectFraction;	// shading effect upon savanna production
    if (sysType.IsSavanna())
    {
    	float aisc = 0.0f;
	if ( AmountIsSignificant(canopyCover) )		// anything there?
	{
	    //aisc =
	    //    std::exp (forestC.rleavc * 2.5 * -0.0035 / canopyCover) * 5.0;
	    aisc = std::exp (-8.75e-3f * forestC.rleavc / canopyCover) * 5.0f;
	}
	Assert ((aisc + 1.0f) != 0.0f);
	float const subcan = aisc / (aisc + 1.0f);
	shadeEffectFraction = 1.0f - canopyCover + canopyCover * subcan;
    }
    else
    {
	shadeEffectFraction = 1.0f;
    }
    Assert (shadeEffectFraction >= 0.0);
    Assert (shadeEffectFraction <= 1.0);

    // ------------------------------------------------------------------------
    // Soil water content effect upon production.
    // Value for potential plant production is now calculated from the
    // equation of a line whose intercept changes depending on water
    // content based on soil type.  The function PPRDWC contains the
    // equation for the line.

    float const soilWaterEffectFraction = PotPlantProdFromSoilH2O (
	water.extrSoilH2OCrop,
	MoistureRatioForGrowth ( water.extrSoilH2OCrop ) );

    // ------------------------------------------------------------------------
    // Temperature effect on growth
    // Removal of litter effects on soil temperature as it
    // drives plant productin (keith paustian)

    /*----- Century 4 version
    float bio = std::min (cropC.aglivc * 2.5f, fixed.pmxbio);
    // Maximum temperature
    float const tmxs =
	weather->TempMax(st->month) + 25.4f /
	(std::exp (-0.2f * weather->TempMax(st->month)) * 18.0f + 1.0f) *
    	(std::exp (fixed.pmxtmp * bio) - 0.13f);
    // Minimum temperature
    float const tmns = weather->TempMin(st->month) + fixed.pmntmp * bio - 1.78f;
    // Average surface temperature
    float const avgTemp = (tmxs + tmns) * 0.5f;
    float const soilTempEffectFraction =
    	::gpdf (avgTemp,
    		ppdf_ref (0, 0), ppdf_ref (1, 0),
    		ppdf_ref (2, 0), ppdf_ref (3, 0));
    -----*/

    /*----- change taken from VEMAP - TEH 28Oct98
    -----*/
    float const soilTempEffectFraction =
	::gpdf (wt.stemp,
		ppdf_ref (0, 0), ppdf_ref (1, 0),
		ppdf_ref (2, 0), ppdf_ref (3, 0));

    // ------------------------------------------------------------------------
    // Estimate the root/shoot ratio as a function of annual precip
    float rootShootRatio;
    if (parcp.frtc[0] == 0.0f)
	rootShootRatio = (fixed.bgppa + parcp.grwprc * fixed.bgppb) /
	       (fixed.agppa + parcp.grwprc * fixed.agppb);
    else
    {
    	float fracrc;
	if (parcp.MonthsSincePlanting() > (short)parcp.frtc[2])
	    fracrc = parcp.frtc[1];
	else
	{
	    Assert (parcp.frtc[2] != 0.0f);
	    fracrc = parcp.frtc[0] - (float)parcp.MonthsSincePlanting() *
	    	     (parcp.frtc[0] - parcp.frtc[1]) / parcp.frtc[2];
	}
	Assert (1.0f - fracrc != 0.0f);
	rootShootRatio = fracrc / (1.0f - fracrc);
    }

    // modify the root:shoot ratio for fire
    if ( sched->DoingCropGrassFire() || sched->DoingSavannaFire() )
    {
	rootShootRatio += parcp.frtsh;
    }
    rootShootRatio *= co2.co2crs[CRPSYS];		// effect of CO2

    // ------------------------------------------------------------------------
    // Calculate the effect of the ratio of live biomass to
    // dead biomass on the reduction of potential growth rate.
    float biomassRatioEffectFraction = 1.0f;
    if (parcp.bioflg == 1)
    {
	// Calculate maximum potential effect of standing dead on plant growth
	// (the effect of physical obstruction of litter and standing dead)
	float bioc = cropC.stdedc + soilC.strucc[SRFC] * 0.1f;
	if (bioc <= 0.0f)
    		bioc = 0.01f;
	if (bioc > fixed.pmxbio)
    		bioc = fixed.pmxbio;
	float const bioprd = 1.0f - bioc / (parcp.biok5 + bioc);

	// Calculate the effect of the ratio of live biomass to
	// dead biomass on the reduction of potential growth rate.
	// Intercept (highest negative effect of dead plant biomass)
	// = bioprd when the ratio = zero.
	float temp1 = 1.0f - bioprd;
	float temp2 = temp1 * 0.75f;
	float temp3 = temp1 * 0.25f;
	Assert (bioc != 0.0f);
	float const ratlc = cropC.aglivc / bioc;
	if (ratlc <= 1.0f)
    		biomassRatioEffectFraction = bioprd + temp2 * ratlc;
	else if (ratlc > 1.0f && ratlc <= 2.0f)
    		biomassRatioEffectFraction =
    			bioprd + temp2 + temp3 * (ratlc - 1.0f);
	else if (ratlc > 2.0f)
    		biomassRatioEffectFraction = 1.0f;
    }

    // ------------------------------------------------------------------------
    // Restriction on seedling growth
    if (cropC.aglivc > parcp.fulcan)
	parcp.seedl = 0;
    float seedlingEffectFraction;	// fraction that prdx is reduced
    if (parcp.seedl == 1)
    {
    	Assert (parcp.fulcan != 0.0f);
	r1 = 1.0f;
	r2 = parcp.pltmrf + cropC.aglivc *
    			(1.0f - parcp.pltmrf) / parcp.fulcan;
	seedlingEffectFraction = std::min (r1, r2);
    }
    else
    {
	seedlingEffectFraction = 1.0f;
    }

    // ------------------------------------------------------------------------
    // Potential production (biomass)
    // pdrx = biomass
    // 1. aboveground
    potentProd.aboveGround = 
	co2.co2cpr[CRPSYS] * 
	param.prdx[0] *
    	shadeEffectFraction *
    	soilWaterEffectFraction *
    	soilTempEffectFraction *
    	biomassRatioEffectFraction *
    	seedlingEffectFraction;
    // 2. belowground
    float belowgroundPotentialProduction =
    	potentProd.aboveGround * rootShootRatio;
    potentProd.total =
    	potentProd.aboveGround + belowgroundPotentialProduction; // total

    // ------------------------------------------------------------------------
    // Restrict production due to grazing
    if ( sched->DoingGrazing() )
    {
	RestrictCropProdGrazing ( rootShootRatio,
		potentProd.aboveGround, belowgroundPotentialProduction);
	potentProd.total =
		potentProd.aboveGround + belowgroundPotentialProduction;
    }

    // ------------------------------------------------------------------------
    // Minimum and maximum C/N, C/P, and C/S ratios allowed in plants.
    // Changed grwprc to 2.5*aglivc in calculation of cercrp
    for (short e = 0; e < site.nelem; ++e)
    {
	// C:E min and max for aboveground
	Assert (parcp.biomax != 0.0f);
	r1 = pramn_ref (e, 0) +
		(pramn_ref (e, 1) - pramn_ref (e, 0)) * 2.5f *
		cropC.aglivc / parcp.biomax;
	r2 = pramn_ref (e, 1);
	cercrp_ref (MINIMUM, ABOVE, e) = std::min (r1, r2);
	r1 = pramx_ref (e, 0) +
		(pramx_ref (e, 1) - pramx_ref (e, 0)) * 2.5f *
		cropC.aglivc / parcp.biomax;
	r2 = pramx_ref (e, 1);
	cercrp_ref (MAXIMUM, ABOVE, e) = std::min (r1, r2);
	// C:E min and max for belowground
	cercrp_ref (MINIMUM, BELOW, e) =
		prbmn_ref (e, 0) + prbmn_ref (e, 1) * parcp.grwprc;
	cercrp_ref (MAXIMUM, BELOW, e) =
		prbmx_ref (e, 0) + prbmx_ref (e, 1) * parcp.grwprc;
    }

    // ------------------------------------------------------------------------
    // If burning occurs, modify maximum C/N ratio of shoots & roots.
    // minimum values do not change.
    if ( sched->DoingCropGrassFire() || sched->DoingSavannaFire() )
    {
	cercrp_ref (MAXIMUM, ABOVE, N) += parcp.fnue[0];
	cercrp_ref (MAXIMUM, BELOW, N) += parcp.fnue[1];
    }

    // ------------------------------------------------------------------------
    // Add effect of co2 to above ground
    for (short e = 0; e < site.nelem; ++e)
    {
	cercrp_ref(MINIMUM, ABOVE, e) *= co2cce_ref(CRPSYS, 0, e);
	cercrp_ref(MAXIMUM, ABOVE, e) *= co2cce_ref(CRPSYS, 1, e);
    }

    // ------------------------------------------------------------------------
    // Update accumulators & compute potential C production
    // note: 0.4 = 1/2.5 = factor used in calc of potential effects above
    cropC.ptagc += potentProd.aboveGround * 0.4f;
    cropC.ptbgc += belowgroundPotentialProduction * 0.4f;
    potentProd.cropC = potentProd.total * 0.4f;
    return potentProd.cropC;
}

//--- end of potcrp.cpp ---

