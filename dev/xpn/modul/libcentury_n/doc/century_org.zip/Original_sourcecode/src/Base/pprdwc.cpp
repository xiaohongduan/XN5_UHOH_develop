// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  pprdwc.cpp
//	Class:	  TCenturyBase
//	Function: PotPlantProdFromSoilH2O
//
//	Description:
// 	Returns a fraction (0 to 1) for potential plant production
// 	due to water content.
//	Basically you have an equation of a
// 	line with a moveable y-intercept depending upon the soil type.
// 	pprpts(1):  The minimum ratio of available water to pet which
//			would completely limit production assuming
//			simLayerWaterContent=0.
//			Default = 0.0
// 	pprpts(2):  The effect of simLayerWaterContent on the intercept,
//			allows the user to increase the value of the intercept
//            		and thereby increase the slope of the line.
//			Default = 1.0
// 	pprpts(3):  The lowest ratio of available water to pet at which
//             		there is no restriction on production.
//			Default = 0.8
// ----------------------------------------------------------------------------
//	History:
//	Apr00   Tom Hilinski, tom.hilinski@colostate.edu
//	* Cleaned up code and optimized.
//	Nov01   Tom Hilinski, tom.hilinski@colostate.edu
//	* More clean up. Renamed variables to obvious descriptive names.
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
float TCENTURYBASE::PotPlantProdFromSoilH2O (
	float const rootZoneWaterContent, // volumetric soil water content
					  //   in root zone (nlaypg)
	float const moistureRatio)	  // (avh2o(1) + prcurr(month) +
					  //    irract) / pet
{
	// The equation for the y-intercept (intercept) is A+B*WC.  A and B
	// determine the effect of soil texture on plant production based
	// on moisture.
	float const intercept =
		fixed.pprpts[0] + fixed.pprpts[1] * rootZoneWaterContent;
	Assert (fixed.pprpts[2] - intercept != 0.0f);
	float const slope = 1.0f / (fixed.pprpts[2] - intercept);
	float retVal = slope * (moistureRatio - fixed.pprpts[2]) + 1.0f;
	retVal = std::min (retVal, 1.0f);
	retVal = std::max (retVal, 0.01f);
	return retVal;
}

//--- end of file ---
