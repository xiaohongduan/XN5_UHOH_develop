#ifndef	INC_TCenturyBase_h
#define	INC_TCenturyBase_h
// ----------------------------------------------------------------------------
//	Copyright (c) 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCenturyBase.h
//	Class:	  TCenturyBase
//
//	Description:
//	Base class for the various derivations of the Century model.
//	Responsibilities:
//	* Provide exception handling class.
//	* Knows	site parameters.
//	* Knows	site management.
//	* Knows	output file class.
//	* Owns user name
//	* Owns simulation time manager instance.
//	* Owns soil instance.
//	* Owns weather instance.
//	* Owns current instance	of 14C data file.
//	* Owns instances of centtypes.h	structs	and classes.
//	* Services of the base class, TEcosystemModelBase.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, August 2001
//	History:
//	Jul02	Tom Hilinski
//	* Added	auto_ptr members: simulation time manager, soil, weather data,
//	  flows, actions, schedule.
//	* Made a class template.
//	* Move centtypes.h to here, including management thereof.
//	* Added specializations at bottom.
//	Oct02	Tom Hilinski
//	* Moved monthly output variables from TCentury to here.
//	Mar03   Tom Hilinski
//	* Added BalanceCheckWithMsg
//	Aug03	Tom Hilinski
//	* New member functions SynchronizeMgmt and FindWeatherFileInMgmt
//	  encapsulate and expand upon much of the checks and sync'ing
//	  that was previously done in GetCurrentMgmt.
//	* Added copy constructor that also has a new mgmt object.
//	* Added pure virtual function ScheduleNPSFlow.
//	* Moved here from TCentury and TDayCent:
//	  Decompose (inline now),
//	  DecomposeSOM, DecomposeSurfaceSOM1, DecomposeSOM2, DecomposeSOM3,
//	  DecomposeLignin, DecomposeWood
//	Jan04	Tom Hilinski
//	* Inlined ScheduleCFlow for speed.
//	Apr04	Tom Hilinski
//	* Moved decomp functions into new class TDecomposition.
//	* Modified all code to use new decomp. class.
//	* Moved ScheduleNPSFlow, UpdateMineralAccum to TDecomposition.
//	* Moved ScheduleCFlow to TFlowsSchedulable.
//	* Moved MicrobialRespiration to new class TMicrobialBase.
//	Apr05	Tom Hilinski
//	* Added member GetRootingDepth.
// ----------------------------------------------------------------------------
//	Notes:
//	* Specializations for daily and monthly Century (standard versions)
//	  are provided in the file TCentBaseSpecialized.h
//	* Site and management are constant for the lifetime of the class.
//	* Output object can change.
//	* Class does NOT own site, mgmt, or output objects.
// ----------------------------------------------------------------------------

					//--- template-specific ---
#include "TCentBaseTemplate.h"		// template macros
					//--- essentials ---
#include "TEcosystemModelBase.h"	// base	class for model
#include "TFlowsSchedulable.h"		// base	class for Flow	management
#include "arraytypes.h"			// array typdefs
#include "TCentOFBase.h"		// output base class
#include "centconsts.h"			// internal constants
#include "centtypes.h"			// internal types
#include "TCalendarTools.h"		// calendar functions
#include "TCenturyRestart.h"		// restart functions
#include "outputvars.h"			// Classes for output variables
#include "arraydefs.h"			// macros for accessing 2D arrays
#include "TInstList.h"			// Management: Block instances
#include "precision.h"			// Precision functions
class TEventDBList;			// Parameter databases
#include "TSharedPtr.h"
					//--- submodels ---
#include "TCanopy.h"			// Plant canopy calculations
#include "TC14Data.h"			// 14C data
#include "TLowerSoil.h"			// Lower simulation soil pools class
#include "TErosion.h"			// Erosion
#include "TDeposit.h"			// Deposition
#include "TMicrocosm.h"			// Microcosm
#include "TSiteEnv.h"			// Site Environment
#include "TDecomposition.h"		// Decomposition
#include "TLeachOrganicC.h"		// Leach organic C,N,P,S
#include "MonthlyPETModelled.h"		// Monthly PET

// forward declarations
namespace nrel
{
  namespace century
  {
	template< class CenturyType >
	  class CenturySiteCreatorBase;

  } // namespace century
} // namespace nrel


MY_TEMPLATE_DECLARATION
class TCenturyBase
	: public nrel::eco::TEcosystemModelBase,
	  public TFlowsSchedulable
{
  public:
	//---- types
	typedef	TCENTURYBASE				class_type;
	typedef	TMySiteParams				site_params_type;
	typedef TSharedPtr<TMyManagement const>		TMgmtPtr;
	typedef TSharedPtr<TMySiteParams const>		TSitePtr;
	typedef TSharedPtr<TOutputBase>			TOutputPtr;
	typedef TSharedPtr<TEventDBList const>		TParamDBListPtr;

  protected:
	template< class CenturyType >
	  friend class ::nrel::century::CenturySiteCreatorBase;

	//---- constructors and	destructor
	TCenturyBase (
	  TSitePtr useSite,				// site	params.
	  TMgmtPtr useMgmt,				// management
	  TOutputPtr useOutput,				// output engine
	  TParamDBListPtr useParamDbList,		// parameter databases
	  bool const outputFlag = true,			// doing output files?
	  char const * const theUserName = 0,		// user	name
	  bool const timeThisRun = false,		// time	model run?
	  TAsynchCommunication * const
				useAsynchCom = 0,	// asynch. com.
	  TDebugInfo const * const useDebugFlags = 0);	// debug flags
	TCenturyBase (
	  TSitePtr useSite,				// site	params.
	  TMgmtPtr useMgmt,				// management
	  TOutputPtr useOutput,				// output engine
	  TParamDBListPtr useParamDbList,		// parameter databases
	  bool const outputFlag = true,			// doing output files?
	  std::string const & theUserName = "",		// user	name
	  bool const timeThisRun = false,		// time	model run?
	  TAsynchCommunication * const
				useAsynchCom = 0,	// asynch. com.
	  TDebugInfo const * const useDebugFlags = 0);	// debug flags

  public:
	virtual ~TCenturyBase ()
	  {
	  }
	explicit TCenturyBase (				// copy	constructor
	  TCENTURYBASE const & object);
	explicit TCenturyBase (				// copy	constructor
	  TCENTURYBASE const & object,
	  TMgmtPtr useMgmt);				// Use new management
	virtual TCENTURYBASE * const Clone () const = 0;

	//---- operator	overloads
	bool operator== (TCENTURYBASE const & object) const;
	bool operator!= (TCENTURYBASE const & object) const
	  { return !(*this == object); }

	//---- functions
	void UseOutput (			// Use an output object
	  TOutputPtr useOutput)
	  { output = useOutput; }
	void UseDebugFlags (
	  TDebugInfo const & useDebugFlags);
	void Clear ();				// "Clear" computed members
	virtual void ClearForNewSimulation ();	// Reset only computed data

	//---- functions: Access
	TSitePtr GetSite () const
	  { return centSite; }
	TMgmtPtr GetManagement () const
	  { return centMgmt; }
	TMgmtSchedule * const GetScheduling () const
	  { return sched.get(); }
	TOutputPtr GetOutput () const
	  { return output; }
	std::string const & GetUserName () const	// user name
	  { return userName; }
	TMySimTime const * const GetSimTime () const
	  { return st.get(); }
	TMySoil const * const GetSoil () const
	  { return soil.get(); }
	TPlantSystemType const & GetSystemType () const
	  { return sysType; }			// current plant system type
	TMyWeather const * const GetWeather () const
	  { return weather.get(); }
	TMyParcp const & GetCropGrass () const
	  { return parcp; }
	TMyParfs const & GetForest () const
	  { return parfs; }
	TCanopy const & GetCanopy () const
	  { return canopy; }

	//--- Access monthly output variables
	TWaterTemp const &  GetWaterTemp () const	{ return wt; }
	TSoilC const &      GetSoilC () const		{ return soilC; }
	TCropGrassC const & GetCropGrassC () const	{ return cropC; }
	TForestC const &    GetForestC () const		{ return forestC; }
	TCO2 const &        GetCO2 () const		{ return co2; }
	TNPS const &        GetNPS () const		{ return nps; }

	//---- functions: Queries
	float GetMaxSimLayerDepth () const
	  { return MAXSIMDEPTH;	}
	short GetRootDepthLayerCrop () const
	  { return water.nlaypg; }
	short GetRootDepthLayerTree () const
	  { return soil->BottomLayer(); }
	bool HaveSiteParameters () const
	  { return centSite.get() != 0 && !centSite->IsEmpty(); }
	bool HaveManagement () const
	  { return centMgmt.get() != 0 && !centMgmt->IsEmpty(); }
	bool HaveOutput () const
	  { return output != 0 && !output->IsEmpty(); }
	bool HaveUserName () const
	  { return !userName.empty(); }
	bool HaveSoil () const
	  { return soil.get(); }
	bool HaveWeather () const
	  { return weather.get(); }
	bool DoingOutput () const
	  { return doOutput; }
	bool SimMicrocosm () const		// True if simulating microcosm
	  { return (microcosm.get() != 0); }

	//---- functions: Utilities
	template
	  <
	    typename TFP	// floating-point type
	  >
	inline bool BalanceCheckWithMsg (
	  TFP const initBal,		// initial balance
	  TFP const finalBal,		// final balance
	  TFP const epsilon,		// allowable magnitude of difference
					//   between initial and final balances
	  char const * const msg	// Message to deliver if imbalance
	  ) const
	  {
	    if ( !AreClose (initBal, finalBal, epsilon) )
	    {
	    	std::ostringstream os;
	    	os << "Imbalance: " << msg << "\n\t"
	    	   << "time = "          << st->time
	    	   << "   value = "
	    	   << std::fabs((initBal - finalBal) / initBal)
	    	   << "   epsilon = "    << epsilon
	    	   << std::ends;
	    	asynchCom.SendWarningMessage (os);
	    	return true;
	    }
	    return false;
	  }


  protected:
	//---- constants
	static float const MAXSIMDEPTH;	// Maximum depth of simulation layer
#ifdef M_PI
#undef M_PI
#endif
	static double const M_PI;	// apple pi
	static float const PEEDEE;	// PeeDee 14C Belemnite	standard
	static float const MINEF;	// Minimum erosion enrichment factor
	static float const MAXEF;	// Maximum erosion enrichment factor

	//--- configuration data
	TSitePtr centSite;			// site	parameters
	TMgmtPtr centMgmt;			// management scheme
	TOutputPtr output;			// output destination
	std::string const userName;		// name	of user
	TDebugInfo debugInfo;			// debug flags
	bool const doOutput;			// true if doing output files

	//--- data - monthly output variables
	// Each has a dynamically allocated pointer,
	// and a reference to it used in the code.
	std::auto_ptr<TWaterTemp> wtPtr;	// pointer:   water & temp.
	TWaterTemp& wt;				// reference: water & temp.
	std::auto_ptr<TSoilC> soilCPtr;		// pointer:   soil C
	TSoilC& soilC;				// reference: soil C
	std::auto_ptr<TCropGrassC> cropCPtr;	// pointer:   crop/grass C
	TCropGrassC& cropC;			// reference: crop/grass C
	std::auto_ptr<TForestC> forestCPtr;	// pointer:   forest C
	TForestC& forestC;			// reference: forest C
	std::auto_ptr<TCO2> co2Ptr;		// pointer:   CO2
	TCO2& co2;				// reference: CO2
	std::auto_ptr<TNPS> npsPtr;		// pointer:   N, P, S
	TNPS& nps;				// reference: N, P, S

	//--- data: dynamically-allocated;
	//    not reallocated during simulation
	std::auto_ptr<TMgmtSchedule> sched;	// manangement scheduling
	std::auto_ptr<TMySimTime> st;		// simulation time manager
	std::auto_ptr<TMyWeather> weather;	// weather data

	//--- data: statically-allocated
	TSiteEnvironment siteEnv;		// site environment
	TPlantSystemType sysType;		// current plant system type
	TIterationData iterationData;		// bookkeeping info
	TCalendarTools calendarTools;		// calendar functions
	TCenturyRestart restart;		// restart handling

	// submodels: required
	std::auto_ptr<TLeachOrganicC> leachOC;	// leaching of org. C,N,P,S
	std::auto_ptr<TMySoil> soil;		// soil	properties by layer
	std::auto_ptr<TMySoilFlows> soilFlows;	// flows to/from soil
	std::auto_ptr<TMyMicrobial> microbial;	// microbial submodel
	std::auto_ptr<TMyDecomp> decomp;	// decomposition submodel
	TCanopy canopy;				// plant canopy
	std::auto_ptr<TLowerSoil> lowerSoil;	// C,E pools below sim. layer
	MonthlyPETModelled monthlyPET;		// monthly PET

	//--- submodels: optional
	std::auto_ptr<T14CData>	c14;		// 14C (labeled	C) data	file
	std::auto_ptr<TMicrocosm> microcosm;	// microcosm
	std::auto_ptr<TErosion> erosion;	// erosion instance
	std::auto_ptr<TDeposition> deposition;	// deposition instance

	//--- data - internal variables	- structs
	// Dynamically-allocated; not reallocated during simulation.
	// The names of	these mostly are holdovers from	Century4.
	// Each	has a dynamically allocated pointer,
	// and a reference to it used in the code.
	// See centtypes.h for declarations.
	std::auto_ptr<Tcomput> computPtr;	// pointer:   computed values
	Tcomput& comput;			// reference: computed values
	std::auto_ptr<TMyFixed> fixedPtr;	// pointer:   fixed parameters
	TMyFixed& fixed;			// reference: fixed parameters
	std::auto_ptr<Tforrem> forremPtr;	// pointer:   forest removal
	Tforrem& forrem;			// reference: forest removal
	std::auto_ptr<TMyParams> paramPtr;	// pointer:   sim.  parameters
	TMyParams& param;			// reference: sim. parameters
	std::auto_ptr<TMyParcp>	parcpPtr;	// pointer:   crop parameters
	TMyParcp& parcp;			// reference: crop parameters
	std::auto_ptr<TMyParfs> parfsPtr;	// pointer:   forest parameters
	TMyParfs& parfs;			// reference: forest parameters
	std::auto_ptr<TPotentialProduction>
			potentProdPtr;		// pointer:   potentential prod.
	TPotentialProduction& potentProd;	// reference: potentential prod.
	std::auto_ptr<TSite> sitePtr;		// pointer:   misc. site params
	TSite& site;				// reference: misc. site params
	std::auto_ptr<TWater> waterPtr;		// pointer:   water parameters
	TWater& water;				// reference: water parameters
	// List of block instances sorted by year.
	// Filled by ReadSimulationInfo, read by GetCurrentMgmt.
	std::auto_ptr<TInstanceList> blockInstanceList;

	//--- data - parameter databases
	TParamDBListPtr paramDbList;

	//--- Access parameter databases
	virtual bool  GetCrop (
	  char const* cropToMatch);	// name of parameter set
	virtual bool  GetCultivation (
	  char const* cultToMatch);	// name of parameter set
	virtual bool  GetFertilization (
	  char const* fertToMatch);	// name of parameter set
	virtual bool  GetFire (
	  char const* fireToMatch);	// name of parameter set
	virtual bool  GetGrazing (
	  char const* grazeToMatch);	// name of parameter set
	virtual bool  GetHarvest (
	  char const* harvestToMatch);	// name of parameter set
	virtual bool  GetIrrigation (
	  char const* irrigateToMatch);	// name of parameter set
	virtual bool  GetOMAddition (
	  char const* omadToMatch);	// name of parameter set
	virtual bool  GetTree (
	  char const* treeToMatch);	// name of parameter set
	virtual bool  GetTreeRemoval (
	  char const* tremToMatch);	// name of parameter set

	// --------------------------------------------------------------------
	// functions - Management
	virtual void  ReadSimulationInfo ();	// retrieve the simulation info
	virtual short GetCurrentMgmt (
	  short const blockInstNum);	// block instance number; zero-based
	virtual void Schedule (		// Scheduling for month's simulation.
	  float const soilTemp);	// soil temperature
					// monthly avg soil surface temp (deg C)
	short SynchronizeMgmt (		// Get block instance sync'd w/sim time
	  ::TYear simYear,		//   simulation year
	  TInstanceList const & instanceList,	//   block instance list
	  short const currentBlockInstNum);	//   current instance number
	std::string & FindWeatherFileInMgmt (	// Find active weather file
	  TInstanceList const & blockInstanceList, // instance list
	  short const currentBlockInstNum,	// instance num. in inst. list
	  std::string & weatherFileNameStr);	//   weather file (output)
	bool AddPathToWeatherFile (		// Add path to weather file name
	  std::string & weatherFileNameStr);	//   weather file (output)

	// --------------------------------------------------------------------
	// functions - Site
	virtual void  ReadSiteParameters () = 0; // retrieve the site parameters

	// --------------------------------------------------------------------
	// functions - model state
	virtual void ClearOutputVars ();

	// --------------------------------------------------------------------
	// functions - Utility
	float DelLabeledC (		// Del13 or Del14 C
	  float const labeled,		//   labeled C
	  float const unlabeled)	//   unlabeled C
	  {  if (unlabeled != 0.0f)
		return (labeled / unlabeled / PEEDEE - 1.0f) * 1000.0f;
	     else
	     	return 0.0f;
	  }
	short MELoopLimit () const	// loop limit for arrays limited to
					// MAXLYR - 1 layers (9 layers)
	  {
	    return std::min (
		static_cast<const short>(soil->GetLayerCount()),
		static_cast<const short>(MAXLYR - 1));
	  }
	void CopyBase (				// Copy	to this
	  TCenturyBase const & object,
	  bool const copyMgmtVars = true);	// True if copy mgmt.
	bool CheckSitePtr (			// Check site pointer
	  TSitePtr theSite);
	bool CheckManagementPtr (		// Check management ptr
	  TMgmtPtr theMgmt);
	bool CheckOutputPtr (			// Check output pointer
	  TOutputPtr theOutput);
	long YearEndMsgInterval ();	// Years between year-end messages

	// --------------------------------------------------------------------
	// Simulation functions
	virtual	void  InitializePools () = 0;
	virtual	void  PreliminaryCalcs () = 0;
	virtual	void  StartOfYearTasks () = 0;	// Tasks at start of year
	virtual void  ResetAnnualAccum ();
	virtual void  InitAnnualProdAccum ();
	virtual void  SimulateSOM () = 0;	// Main simulation function
	virtual void  Update ()			// Update the flows and sums
	  {
	    DoFlows (st->time);
	    leachOC->DoFlows (st->time);
	    microbial->DoFlows (st->time);
	    decomp->DoFlows (st->time);
	    SumCarbon ();
	  }
	virtual	void  EndOfYearTasks ();	// Tasks at end of year
	virtual void  OutputVariables ();	// calc output variables

	// --------------------------------------------------------------------
	// functions - Erosion and Deposition
	TErosion const * const GetErosion () const
	  { return erosion.get(); }
	TDeposition const * const GetDeposition () const
	  { return deposition.get(); }
	virtual bool  InitDepositionEvent ();
	virtual bool  InitErosionEvent (
	  char const* eventInfo);		// event "additional info" field
	virtual void  InitializeLowerLayer ();

	// --------------------------------------------------------------------
	// functions - Fire submodel
	virtual void  FireEvent () = 0;
	virtual void  BurnLitter (
	  float * const removedE);	// N,P,S returned to system after burn.

	// --------------------------------------------------------------------
	// functions - Irrigation

	// --------------------------------------------------------------------
	// functions - Crop/grassland submodel
	// virtual void SimulateCrop (
	//  float const wfunc);		// water function (?)
	virtual void DeathOfShoots (
	  float const wfunc);		// water function (?)
	virtual void SimulateFallStandingDead ();
	void RestrictCropProdGrazing (	// Grazing affect on crop production
	  float const ratioRootShoot,	// root:shoot C
	  float & agPotProd,		// aboveground potential production
	  float & bgPotProd);		// belowground potential production

	// --------------------------------------------------------------------
	// functions - Forest submodel

	// WoodProductionFromLAI
	// REF:    Efficiency of Tree Crowns and Stemwood
	//         Production at Different Canopy Leaf Densities
	//         by Waring, Newman, and Bell
	//         Forestry, Vol. 54, No. 2, 1981
	virtual float WoodProductionFromLAI (
	  float const lai,	// leaf area index
	  float const laitop)	//
	  {
	    //--- original
	    // The minimum LAI to calculate effect is 0.2.
	    // return (1.0f - std::exp(laitop * std::max(lai, 0.2f)) );
	    // --- from DayCent4.5
	    if (lai < 0.3f)
	    {
	      // Restraint on lower end of production, cak - 07/24/02
	      return 0.03f;
	    }
	    else
	    {
	      return 1.0f - std::exp(laitop * lai);
	    }
	  }
	virtual void ForestRemoval ();
	virtual	void ForestLiveBiomassRem (
	  float	*accum		// Cumulative C: [0]=unlabeled,	[1]=labeled
	  ) = 0;
	virtual void RemoveDeadWood (
	  float *accum);	// Cumulative C: [0]=unlabeled, [1]=labeled
	virtual void  KillRoots (
	  float *accum);	// Cumulative C: [0]=unlabeled, [1]=labeled
	virtual void  CuttingEvent (
	  float *accum);	// Cumulative C: [0]=unlabeled, [1]=labeled

	// --------------------------------------------------------------------
	// functions - Decomposition submodel
	virtual void PSDecompChemistry (
	  float const dtDecomp) = 0;	// decomposition time step
	virtual float TempEffectOnDecomp (
	  float const soilTemp		// soil temperature (C)
	  ) const = 0;			// Required!

	// --------------------------------------------------------------------
	// Physical environment calculations
	virtual void  AtmCO2Effect (
	  float const time);		// simulation time: "year.yearfraction"

	// --------------------------------------------------------------------
	// Misc. simulation functions
	virtual void  SumCarbon ();

	// --------------------------------------------------------------------
	// functions - P submodel
	float FractionMinPInSolution (
	  float const soilDepth,		// depth to calc the amount
	  TSoilPool const & soilP);		// P pool in soil

	// --------------------------------------------------------------------
	// Update variables
	virtual void UpdateWaterVariables (
	  bool const updateRWCF = true);	// true if calc rwcf(*)
	virtual void UpdateFromSoilWater ();
	virtual void UpdateMineralEVariables () = 0;
	virtual void UpdateMineralEOutputVariables () = 0;

	// --------------------------------------------------------------------
	// functions - Plant submodel

	// Adjust the fraction of lignin in structural C when new material
	// is added.
	// "ligninFraction" input as fraction of lignin in structural before new
	// material is added; goes out as fraction of lignin in
	// structural with old and new combined.
	virtual void AdjustLigninFraction (
	  float const oldC,		// C in structural before new C added
	  float const frNew,		// fraction of lignin in new structural
	  float const addC,		// C (g) in structural being added
	  float & ligninFraction)	// lignin fraction in combined residue
	  {
	    // lignin in existing residue
	    float const oldlig = ligninFraction * oldC;
	    // lignin in new residue
	    float const newlig = frNew * addC;
	    // lignin fraction in combined residue
	    Assert (oldC + addC != 0.0f);
	    ligninFraction = (oldlig + newlig) / (oldC + addC);
	  }
				// --------------------------------------------
	virtual void  PlantLigninFraction ();
				// --------------------------------------------
	virtual void  PartitionResidue (
	  float const cpart,	// amount of carbon in the residue.
	  float const *recres,	// array: n/c, p/c, and s/c in the residue.
	  short const lyr,	// layer (values: SRFC, SOIL)
	  float* const cdonor,	// array: compartments
	  float* const edonor,	// array: compartments
	  float const frlign,	// fraction of incoming material = lignin.
	  float const friso	// fraction of cpart = labeled.
	  ) = 0;
				// --------------------------------------------
	virtual float PotPlantProdFromSoilH2O (
	  float const rootZoneWaterContent,
				// volumetric water content in root zone
	  float const moistureRatio);
				// (avh2o(1) + prcurr(month) + irract) / pet
				// --------------------------------------------
	virtual float RootImpactOnNutrients (
	  float const rootc); 	// root biomass C pool

	// --------------------------------------------------------------------
	// functions - Query system state variables
	bool SimSulfur () const			// True if simulating S
	  { return site.nelem > S; }
	bool SimPhosphorous () const		// True if simulating P
	  { return site.nelem > P; }
	bool InFallowPrecipTime () const 	// True if in fallow precip
	  { return param.falprc; }
	bool IsDeciduousForest () const		// True if deciduous forest
	  { return parfs.decid >= 1; }
	bool IsNormalDecidForest () const	// True if "normal" deciduous
	  { return parfs.decid == 1; }
	bool IsDroughtDecidForest () const	// True if "drought" deciduous
	  { return parfs.decid == 2; }
	bool IsCultivatedSoil () const		// True if a cultivated soil
	  { return param.ivauto == 2; }
	bool IsGrasslandSoil () const		// True if a cultivated soil
	  { return param.ivauto == 1; }

  private:
	//---- constants

	//---- data

	//---- functions
	void Constructor ();			// Common constructor
	virtual bool InitializeRun () =	0;	// Initialize a	run

	//---- functions: Not allowed
	TCENTURYBASE & operator= (TCenturyBase const & object)
	  {
	    return *this;
	  }
};

#endif // INC_TCenturyBase_h
