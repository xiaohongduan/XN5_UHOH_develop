#ifndef INC_TNcFileOutVarDef_h
#define INC_TNcFileOutVarDef_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TNcFileOutVarDef.h
//	Class:	  TNcFileOutVarDef
//
//	Description:
//	Class for I/O of netCDF files for the output variables definitions.
//	Derived from the class TNcFile.
//	This is a friend of TMCOutputVariableInfo.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Sep98
//	History:
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* A bit of cleaning up.
// ----------------------------------------------------------------------------
//	Notes:
//	Associated classes:
//	TNcFileOutVarDef	Reads the netCDF file contain names & descrip.
//	TMCOutputVariableInfo	Holds the variables' names and descriptions.
// ----------------------------------------------------------------------------

#include "TNcFile.h"
#include "TMCOutVarInfo.h"

//	-----------------------------------------------------------------------
//	TNcFileOutVarDef
//	Class for I/O of the "OutVarsDef.nc" netCDF file.
class TNcFileOutVarDef : public TNcFile
{
  public:
	//--- constructors and desor
	TNcFileOutVarDef (
	  TEH::TFileName const & useNcfile)
	  : TNcFile ( useNcfile, NCFT_OutVarsDef, version )
	  {
	  }
	~TNcFileOutVarDef ()
	  {
	  }
	//--- functions
	bool Read (				// Reads entire contents
	  TMCOutputVariableInfo & vi);

  private:
	static short const version;		// netCDf file version number
};

#endif // INC_TNcFileOutVarDef_h
