// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  cropin.cpp
//	Class:	  TCentury
//	Function: GetCrop
//
//	Description:
//	Read the new crop/grassland parameter set.
//	Returns true if successful match in database, else false if not.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jun98
// ----------------------------------------------------------------------------
//	History:
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Parameter set is now read in once only during a simulation,
//	  and stored in a TCentury member variable.
//	Jul01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to use new TEventDBList class.
//	* Input of co2ice wasn't incrementing "k" index (via Melannie Hartman).
//	  Updated descriptive comments on co2ice in the Tparam structure.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "TEventDBList.h"
#include "util.h"
#include "constants.h"

MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::GetCrop (
	char const* cropToMatch)
{
	// error checks
	if ( !cropToMatch || !(*cropToMatch) )		// anything there?
		return false;

	// get the option set
	TEventOptionSet const & optionSet =
		*paramDbList->Get (TEventDBList::DBI_Crop);
	if ( !&optionSet )				// database not there?
		ThrowCentException (TCentException::CE_NSPPDB,
			::eventName[ET_Crop]);
	if ( !optionSet.GetOptionCount () )		// empty database?
		ThrowCentException (TCentException::CE_EMPPDB,
			::eventName[ET_Crop]);

	// get the option matching the parameter string
    	TEventOption const * const option = optionSet.GetOption (cropToMatch);
	if ( !option )					// match found?
		return false;

	// retrieve values from option and save in Century's variables
	short const numParams = 70;			// total for an option
	short count = option->GetParamCount ();
	if ( count != numParams )			// counts match?
		ThrowCentException (TCentException::CE_OPCBAD,
			::eventName[ET_Crop]);

	register short k = 0;			// index to param values
	register short i, j;			// loop indices

	// max potential biomass
	param.prdx[0] = option->GetParameter(k++)->GetValue();
	// float const biomassKluge = 0.90f;	// potential is too large!
	// param.prdx[0] *= biomassKluge;

    	for (i = 0; i < 4; ++i)
		ppdf_ref (i, 0) = option->GetParameter(k++)->GetValue();
	parcp.bioflg = (int) option->GetParameter(k++)->GetValue();
	parcp.biok5 = option->GetParameter(k++)->GetValue();
	parcp.pltmrf = option->GetParameter(k++)->GetValue();
	parcp.fulcan = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 3; ++i)
		parcp.frtc[i] = option->GetParameter(k++)->GetValue();
	if (parcp.frtc[2] == 0.0f)
		parcp.frtc[2] = 1.0f;
	parcp.biomax = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 2; ++i)
    	  for (j = 0; j < 3; ++j)
		pramn_ref (j, i) = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 2; ++i)
    	  for (j = 0; j < 3; ++j)
		pramx_ref (j, i) = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 2; ++i)
    	  for (j = 0; j < 3; ++j)
		prbmn_ref (j, i) = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 2; ++i)
    	  for (j = 0; j < 3; ++j)
		prbmx_ref (j, i) = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 2; ++i)
    	  for (j = 0; j < 2; ++j)
		fligni_ref (j, i) = option->GetParameter(k++)->GetValue();
	parcp.himax = option->GetParameter(k++)->GetValue();
	parcp.hiwsf = option->GetParameter(k++)->GetValue();
	parcp.himon[0] = (short) option->GetParameter(k++)->GetValue();
	parcp.himon[1] = (short) option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 3; ++i)
		parcp.efrgrn[i] = option->GetParameter(k++)->GetValue();
	parcp.vlossp = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 4; ++i)
		parcp.fsdeth[i] = option->GetParameter(k++)->GetValue();
	parcp.fallrt = option->GetParameter(k++)->GetValue();
	parcp.rdr = option->GetParameter(k++)->GetValue();
	parcp.rtdtmp = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 3; ++i)
		parcp.crprtf[i] = option->GetParameter(k++)->GetValue();
	param.snfxmx[0] = option->GetParameter(k++)->GetValue();
	float del13c = option->GetParameter(k++)->GetValue();
	param.co2ipr[0] = option->GetParameter(k++)->GetValue();
	param.co2itr[0] = option->GetParameter(k++)->GetValue();
	for (i = 0; i < 2; ++i)
	    for (j = 0; j < 3; ++j)
		co2ice_ref (0, i, j) = option->GetParameter(k++)->GetValue();
	param.co2irs[0] = option->GetParameter(k)->GetValue();

	// save option name in Century class variable
	strcpy (sched->curCrop, cropToMatch);

    // Determine the 'numerical value' of the curCrop,
    // for use as an output variable
    cropC.crpval = 0.0f;
    for (i = 0; i < 5; ++i)
    {
    	if ( sched->curCrop[i] != ' ' && sched->curCrop[i] != '\0' )
	{
	    if ( sched->curCrop[i] >= '0' && sched->curCrop[i] <= '9' )
		cropC.crpval += (sched->curCrop[i] - '0') * 0.1f;
	    else
		cropC.crpval += sched->curCrop[i] - 'A' + 1;
	}
    }
    PlantLigninFraction ();		// Recalculate lignin

    // Calculate cisofr as 13C if 13C labeling
    if (param.labtyp == Lbl_13C)
    {
	param.cisofr = del13c * PEEDEE * 0.001f + PEEDEE;
	param.cisofr = 1.0f / (1.0f / param.cisofr + 1.0f);
    }

    return true;	// successful match
}	// GetCrop
