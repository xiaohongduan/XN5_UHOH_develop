#ifndef INC_TApp_h
#define INC_TApp_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TCMIApp.h
//	Class:	  TCMIApp
//
//	Description:
//	Class Type for GUI Application Main. Inherits vApp
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Dec98
//	History:
//	Apr99	Tom Hilinski
//	* Now closes the progress dialog when execution is stopped
//	  prematurely, either through the "Cancel" button or when an
//	  exception is generated.
//	Jan01	Tom Hilinski
//	* Uses the new message function pointers required for the TCentury
//	  constructors.
//	Oct01	Tom Hilinski
//	* Modified global variables to use the new TCenturyConfig class.
//	* Changed global var. progDlg to be an std::auto_ptr.
//	* Previous global vars now in TCenturyConfig are removed.
//	Oct03	Tom Hilinski
//	* Changed class name from TApp to TCMIApp
// ----------------------------------------------------------------------------

#include <v/vapp.h>
#include <v/vawinfo.h>			// for app info
#include <v/vnotice.h>
#include <memory>
#include "TMgmtSummaryDlg.h"
#include "TCmdLine.h"

class TTextCmdWindow;

class TCMIApp : public vApp
{
	friend int AppMain (int argc, char** argv);	// allow AppMain access
  public:
	//--- constructor and destructor
	TCMIApp (char const * const appName)
#if (V_VersMajor < 1) || (V_VersMinor < 90)
	  // no MDI tabs
	  : vApp (appName)
#else
	  // use MDI tabs
	  : vApp (appName, 0, 0, 0, 1)
#endif
	  {
	    messageWindow = 0;
	    haveFinishedSim = false;
	    inExit = false;
	  }
	~TCMIApp ()
	  {
	  }

	//--- overridden methods
	vWindow* const NewAppWin (		// Create a new window
	  vWindow * const win,		//   parent window
	  char const * const name,	//   window name
	  int const h,			//   height
	  int const w,			//   width
	  vAppWinInfo * const winInfo);	//   window information
	int CloseAppWin (
	  vWindow * const win);
	void Exit ();
	void KeyIn (		// Handles keystrokes not processed by a window
	  vWindow * const win,	//   the window
	  vKey key,		//   the keystroke
	  unsigned int shift)	//   keystroke modifier
	  {
	    vApp::KeyIn (win, key, shift);
	  }
	void AppCommand (	// Handles commands not processed by a window
	  vWindow * const win,	//   the window
	  ItemVal id,		//   command ID
	  ItemVal val,		//   command value
	  CmdType cType)	//   command type
	  {
	    vApp::AppCommand (win, id, val, cType);
	  }

	//--- functions
	void DisplayMsg (		// Writes message to message window and
					// displays message in message dialog.
	  char const * const title,	//   window title
	  char const * const msg	//   the message
	  ) const;
	void DisplayMsg (		// Writes message to message window and
					// displays message in message dialog.
	  char const * const title,	//   window title
	  std::string const & msg	//   the message
	  ) const;
	void DisplayAbout () const;
	void Display_MgmtSummary (
	  bool const createIfNeeded = false);
	void Delete_MgmtSummary ();
	bool CheckAppPaths ();
	void DisplayStatus () const;

	//--- functions for global I/O
	bool ReadSite (
	  char const * const fileNameBase);
	bool ReadMgmt (
	  char const * const fileNameBase);
	bool WriteMgmt ();

	// Century simulation functions
	bool ConfigureCentury (
	  int const argc,
	  char const * const * const argv);
	bool IsReadyToRun () const;		// true if have what is needed
	bool RunCentury ();			// run the simulation

	//--- data
	TTextCmdWindow*	messageWindow;			// message window
	TTextCmdWindow*	historyWindow;			// history window
	std::auto_ptr<TMgmtSummaryDlg> mgmtSummaryDlg;	// mgmt summary dialog

  private:
	//--- functions
	void InitialIniFileName (
	  char const * const useIniFileName);

	//--- data
	::nrel::century::CenturySimConfigInfo
				configInfo;	// sim configuration
	std::auto_ptr<TCenturyCmdLine> cmdLine;	// command-line
	bool haveFinishedSim;			// True if completed a Century
						// simulation and have results.
	bool inExit;				// true if exiting application
};

#endif 	// INC_TApp_h

