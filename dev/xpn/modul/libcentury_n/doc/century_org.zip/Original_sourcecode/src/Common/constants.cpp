// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  constants.cpp
//
//	Description:
//	Contains constants common to the various parts of the Century project.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Nov97
// ----------------------------------------------------------------------------
//	History:
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* added some const correctness.
//	Jan03	Tom Hilinski, tom.hilinski@colostate.edu
//	* Removed array C4FileName[] = list of Century 4.0
//	  parameter database (".100") file names:
// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "constants.h"

//	-----------------------------------------------------------------------
//	eventName
// 	Array of event name strings
//	Do not change the order of these, and they correspond to enum values in
//	the enum TEventType in TMgmtConst.h
char const * const eventName[] = {
	"????",		// Unknown event
			//--- Century 4.0 events
	"CROP",		// Crop type
	"CULT",		// Cultivation
	"FERT",		// Fertilization
	"FIRE",		// Fire
	"GRAZ",		// Grazing
	"HARV",		// Harvest crop
	"IRRI",		// Irrigation
	"OMAD",		// Organic matter addition
	"TREE",		// Tree type
	"TREM",		// Tree removal
	"PLTM",		// Plant crop
	"FRST",		// Crop growth starts
	"LAST",		// Crop growth ends
	"SENM",		// Crop senescence
	"TFST",		// Tree growth starts
	"TLST",		// Tree growth ends
	"EROD",		// Erosion (kg/m^2/month)
			//--- New events
	"DEPO",		// Deposition (kg/m^2/month)
	"EXTR",		// External event
	"FRNG",		// Fertilation year/amt. range + mo. fractions
	"ORNG",		// Org. matter year/amt. range + mo. fractions
	"IRNG",		// Irrigation year/amt. range + mo. fractions
	"IAUT",		// Irrigation - automatic
	"NIND",		// N deposition - industrial year/amt. range
	"NATM",		// N deposition - atmospheric
	"KRNG",		// K addition year/amt. range + mo. fractions
	"SRNG",		// S addition year/amt. range + mo. fractions
	"PRNG",		// P addition year/amt. range + mo. fractions
	"ERNG",		// Erosion year/amt. range + mo. fractions
	"GRZI",		// Grazing intensity
			//--- That's all folks!
	0		// end of list
};

//	-----------------------------------------------------------------------
//	eventDescrip
// 	Array of event description strings associated with eventName[].
char const * const eventDescrip[] = {
	"????",			// Unknown event
				//--- Century 4.0 events
	"Crop/Grass type",	// Crop type
	"Cultivate",		// Cultivation
	"Fertilize",		// Fertilization
	"Burn",			// Fire
	"Graze",		// Grazing
 	"Harvest crop",		// Harvest crop
	"Irrigate",		// Irrigation
	"Add Organic",		// Organic matter addition
	"Tree type",		// Tree type
	"Tree removal",		// Tree removal
	"Plant crop",		// Plant crop
	"Crop growth start",	// Crop growth starts
	"Crop growth end",	// Crop growth ends
	"Crop senescence",	// Crop senescence
	"Tree growth start",	// Tree growth starts
	"Tree growth end",	// Tree growth ends
	"Erosion",		// Erosion (kg/m^2/month)
				//--- New events
	"Deposition",		// Deposition (kg/m^2/month)
	"External event",	// Implementation-dependent
	"Fertilization range",	// Fertilation year/amt. range + mo. fractions
	"Org. addition range",	// Org. matter year/amt. range + mo. fractions
	"Irrigation range",	// Irrigation year/amt. range + mo. fractions
	"Auto irrigate",	// Irrigation - automatic
	"N - industrial",	// N deposition - industrial year/amt. range
	"N - atmospheric",	// N deposition - atmospheric
	"K addition range",	// K addition year/amt. range + mo. fractions
	"S addition range",	// S addition year/amt. range + mo. fractions
	"P addition range",	// P addition year/amt. range + mo. fractions
	"Erosion range",	// Erosion year/amt. range + mo. fractions
	"Grazing intensity",	// Grazing intensity
				//--- That's all folks!
	0			// end of list
};

// ----------------------------------------------------------------------------
//	oFFDescrip
//	Descriptive strings of the output file format choices.
//	Order must match TOutputBase::TOutputType.
char const * const oFFDescrip[] =
{
	"Unknown",
	"Spreadsheet (ASCII, comma-delimited)",
	"NetCDF (binary, platform-independent)",
	0
};

//--- end of constants.cpp ---

