// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  OutputVariables.cpp
//	Class:	  OutputVariables
//
//	Description:
//	Management of output variables for DayCentIRC.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, April 2005
//	History: See header file.
// ----------------------------------------------------------------------------

#include "OutputVariables.h"
using namespace nrel::dcirc;
#include "TDayCentModel.h"
#include "TGridCell.h"

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

	// using C arrays cuz std::vector does not allow
	// an initialization list - that's coming in the C++ 0x standard

// output variable names
#define STR	std::string
TStringCArray OutputVariables::names =
{
  STR("Time Step"),
  STR("Year"),
			// Nitrogen -------------------------------------------
  STR("NFIXAC"),	// N symbiotic fixation, cumulative (g m-2 year-1)
  STR("WDFXMA"),	// N fixation in atmosphere (g m-2 month-1)
  STR("WDFXMS"),	// N non-symbiotic soil fixation (g m-2 month-1)
  STR("GROMIN(1)"),	// N gross mineralization (g m-2 month-1)
  STR("STREAM(2)"),	// N in mineral leached in stream flow (g m-2 month-1)
  STR("STREAM(6)"),	// N in organic leached in stream flow (g m-2 month-1)
  STR("VOLEX"),		// N volatilized from denitrification (g m-2 month-1)
  STR("VOLGM"),		// N volatilized from gross mineralization (g m-2 month-1)
  STR("VOLPL"),		// N volatilized: plant harvest & grass senescence (g m-2 mo-1)
  STR("TEREM(1)"),	// N removed during forest removal events (g m-2 month-1)
			// Water budget ---------------------------------------
  STR("EVAP"),		// H2O evaporation (cm month-1)
  STR("TRAN"),		// H2O transpriation (cm month-1)
  STR("RAIN"),		// H2O precipitation (cm month-1)
  STR("IRRACT"),	// H2O irrigation (cm month-1)
  STR("STREAM(1)"),	// H2O stream flow (cm month-1)
			// Respiraton -----------------------------------------
  STR("RESPH"),		// CO2 total annual heterotrophic respiration (g m-2)
  STR("SUMRSP"),	// CO2 forest maintenance respiration (g m-2 month-1)
			// Production -----------------------------------------
  STR("CPRODC"),	// NPP total crop/grass (g m-2 month-1)
  STR("CPRODF"),	// NPP total tree (g m-2 month-1)
  STR("NPP"),		// NPP total CPRODC + CPRODF (g m-2 month-1)
  STR("NEP"),		// Net ecosystem production (g m-2 year-1)
  STR("FORTC"),		// Total forest system C
  STR("CGTC"),		// Total crop/grass system C
  STR("STREAM(5)"),	// Org C leached in stream flow (g m-2 month-1)
  STR("CRET"),		// Org C removed during graze/fire for crop/grass (g m-2 year-1)
  STR("TCREM"),		// Org C removed during forest removal/fire;
			//   annual (g m-2)
			// Soil Pool Totals -----------------------------------
  STR("SOILTC"),	// Total C in soil (g m-2)
  STR("SOMTE(1)"),	// Total Organic N in soil (g m-2)
  STR("")		// last item always!
};
#undef STR

// output variable descriptions
// To Do: write this list to the output file
#define STR	std::string
TStringCArray OutputVariables::descriptions =
{
  STR("Time Step"),
  STR("End of Year"),
  STR("N symbiotic fixation, cumulative"),			// NFIXAC
  STR("N fixation in atmosphere"),				// WDFXMA
  STR("N non-symbiotic soil fixation"),				// WDFXMS
  STR("N gross mineralization"),				// GROMIN(1)
  STR("N in mineral leached in stream flow"),			// STREAM(2)
  STR("N in organic leached in stream flow"),			// STREAM(6)
  STR("N volatilized from denitrification"),			// VOLEX
  STR("N volatilized from gross mineralization"),		// VOLGM
  STR("N volatilized: plant harvest & grass senescence"),	// VOLPL
  STR("N removed during forest removal events"),		// TEREM(1)
  STR("H2O evaporation"),					// EVAP
  STR("H2O transpriation"),					// TRAN
  STR("H2O precipitation"),					// RAIN
  STR("H2O irrigation"),					// IRRACT
  STR("H2O stream flow"),					// STREAM(1)
  STR("CO2 total heterotrophic respiration"),			// RESPH
  STR("CO2 forest maintenance respiration"),			// SUMRSP
  STR("NPP crop/grass"),					// CPRODC
  STR("NPP tree"),						// CPRODF
  STR("NPP total"),						// NPP
  STR("NEP"),							// NEP
  STR("Total forest system C"),					// FORTC
  STR("Total crop/grass system C"),				// CGTC
  STR("Org C leached in stream flow"),				// STREAM(5)
  STR("Org C removed at grazing/harvest/fire for crop/grass"),	// CRET
  STR("Org C removed during forest removal/fire"),		// TCREM
  STR("Total C in soil"),					// SOILTC
  STR("Org N in soil"),						// SOMTE(1)
  STR("")							// last	item
};
#undef STR

// output variable flags
OutputVariables::TOutVarTypeCArray OutputVariables::typeFlags =
{
	::nrel::gcf::VT_TimeStep,		// Time Step
	::nrel::gcf::VT_FPTime,			// Year
	::nrel::gcf::VT_CumFluxDensity,		// NFIXAC
	::nrel::gcf::VT_FluxDensity,		// WDFXMA
	::nrel::gcf::VT_FluxDensity,		// WDFXMS
	::nrel::gcf::VT_FluxDensity,		// GROMIN(1)
	::nrel::gcf::VT_FluxDensity,		// STREAM(2)
	::nrel::gcf::VT_FluxDensity,		// STREAM(6)
	::nrel::gcf::VT_FluxDensity,		// VOLEX
	::nrel::gcf::VT_FluxDensity,		// VOLGM
	::nrel::gcf::VT_FluxDensity,		// VOLPL
	::nrel::gcf::VT_CumFluxDensity,		// TEREM(1)
	::nrel::gcf::VT_FluxDensity,		// EVAP
	::nrel::gcf::VT_FluxDensity,		// TRAN
	::nrel::gcf::VT_FluxDensity,		// RAIN
	::nrel::gcf::VT_FluxDensity,		// IRRACT
	::nrel::gcf::VT_FluxDensity,		// STREAM(1)
	::nrel::gcf::VT_CumFluxDensity,		// RESPH
	::nrel::gcf::VT_FluxDensity,		// SUMRSP
	::nrel::gcf::VT_FluxDensity,		// CPRODC
	::nrel::gcf::VT_FluxDensity,		// CPRODF
	::nrel::gcf::VT_FluxDensity,		// NPP
	::nrel::gcf::VT_CumFluxDensity,		// NEP
	::nrel::gcf::VT_PoolDensity,		// FORTC
	::nrel::gcf::VT_PoolDensity,		// CGTC
	::nrel::gcf::VT_FluxDensity,		// STREAM(5)
	::nrel::gcf::VT_CumFluxDensity,		// CRET
	::nrel::gcf::VT_CumFluxDensity,		// TCREM
	::nrel::gcf::VT_PoolDensity,		// SOILTC
	::nrel::gcf::VT_PoolDensity,		// SOMTE(1)
	::nrel::gcf::VT_LastItem		// last item always!
};

// variable time type flags
OutputVariables::TVarTimeTypeCArray OutputVariables::timeFlags =
{
	::nrel::gcf::VTT_Value,			// Time Step
	::nrel::gcf::VTT_Value,			// Year
	::nrel::gcf::VTT_Cumulative,		// NFIXAC
	::nrel::gcf::VTT_Interval,		// WDFXMA
	::nrel::gcf::VTT_Interval,		// WDFXMS
	::nrel::gcf::VTT_Interval,		// GROMIN(1)
	::nrel::gcf::VTT_Interval,		// STREAM(2)
	::nrel::gcf::VTT_Interval,		// STREAM(6)
	::nrel::gcf::VTT_Interval,		// VOLEX
	::nrel::gcf::VTT_Interval,		// VOLGM
	::nrel::gcf::VTT_Interval,		// VOLPL
	::nrel::gcf::VTT_Cumulative,		// TEREM(1)
	::nrel::gcf::VTT_Interval,		// EVAP
	::nrel::gcf::VTT_Interval,		// TRAN
	::nrel::gcf::VTT_Interval,		// RAIN
	::nrel::gcf::VTT_Interval,		// IRRACT
	::nrel::gcf::VTT_Interval,		// STREAM(1)
	::nrel::gcf::VTT_Cumulative,		// RESPH
	::nrel::gcf::VTT_Interval,		// SUMRSP
	::nrel::gcf::VTT_Interval,		// CPRODC
	::nrel::gcf::VTT_Interval,		// CPRODF
	::nrel::gcf::VTT_Interval,		// NPP
	::nrel::gcf::VTT_Cumulative,		// NEP
	::nrel::gcf::VTT_Value,			// FORTC
	::nrel::gcf::VTT_Value,			// CGTC
	::nrel::gcf::VTT_Interval,		// STREAM(5)
	::nrel::gcf::VTT_Cumulative,		// CRET
	::nrel::gcf::VTT_Cumulative,		// TCREM
	::nrel::gcf::VTT_Value,			// SOILTC
	::nrel::gcf::VTT_Value,			// SOMTE(1)
	::nrel::gcf::VTT_LastItem		// last item always!
};

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	AdjustForCumulativeValues
//	For cumulative values, substract previous values to get
//	the interval values.
void OutputVariables::AdjustForCumulativeValues ()
{
	TOutVarValueArray::iterator iValues = values.begin();
	TOutVarValueArray::iterator iPrevious = previousValues.begin();
	::nrel::gcf::TVariableTimeType const * pTimeType = timeFlags;
	while ( iValues != values.end() )
	{
	    if ( *pTimeType == ::nrel::gcf::VTT_Cumulative )
	    {
	    	float const newPreviousValue = *iValues;
	    	*iValues -= *iPrevious;			// make interval value
	    	*iPrevious = newPreviousValue;		// save for next time
	    }
	    ++iValues;
	    ++iPrevious;
	    ++pTimeType;
	}
}

//	CollectOutputFromCohort
//	Get values for a cohort.
void OutputVariables::CollectOutputFromCohort (
	::nrel::gcf::TCohort const & cohort)
{
	// get the model for this cohort
	Assert (cohort.HaveModel());
	Assert (dynamic_cast<TDayCentModel const &>(cohort.GetModel()).HaveModel());
	TDayCentGCF const * const century =
	    &dynamic_cast<TDayCentModel const &>(cohort.GetModel()).GetModel();
	Assert (century != 0);

	// calc the area fraction of the cell
	float const areaFraction =
		cohort.GetAreaFraction() *
		cohort.GetLandElement().GetAreaFraction();

	// for this century instance, get the most recent output values
	::nrel::gcf::TOutVarValueArray::iterator iOV = values.begin();
	::nrel::gcf::TOutVarType const * pType = typeFlags;

	// Simulation Time Step
	// *iOV = owner->GetOwner()->GetOwner()->GetOwner()->GetOwner()->
	// 	GetTimer().GetTimeStep();
	*iOV = century->GetIterationCount ();
	++iOV; ++pType;

	// Simulation Time in floating-point format
	*iOV = century->GetSimTime()->time;
	++iOV; ++pType;

	//------------------------------------------------- Nitrogen
	// NFIXAC
	UpdateVariable (
		*(iOV++), *(pType++),
		century->NPS().nfixac,
		areaFraction );

	// WDFXMA
	UpdateVariable (
		*(iOV++), *(pType++),
		century->NPS().wdfxma,
		areaFraction );

	// WDFXMS
	UpdateVariable (
		*(iOV++), *(pType++),
		century->NPS().wdfxms,
		areaFraction );

	// GROMIN(1)
	UpdateVariable (
		*(iOV++), *(pType++),
		century->NPS().gromin[0],
		areaFraction );

	// STREAM(2)
	UpdateVariable (
		*(iOV++), *(pType++),
		century->WaterTemp().stream[1],
		areaFraction );

	// STREAM(6)
	UpdateVariable (
		*(iOV++), *(pType++),
		century->WaterTemp().stream[5],
		areaFraction );

	// VOLEX
	UpdateVariable (
		*(iOV++), *(pType++),
		century->NPS().volex,
		areaFraction );

	// VOLGM
	UpdateVariable (
		*(iOV++), *(pType++),
		century->NPS().volgm,
		areaFraction );

	// VOLPL
	UpdateVariable (
		*(iOV++), *(pType++),
		century->NPS().volpl,
		areaFraction );

	// TEREM(1)
	UpdateVariable (
		*(iOV++), *(pType++),
		century->NPS().terem[0],
		areaFraction );

	//------------------------------------------------- Water budget
	// EVAP
	UpdateVariable (
		*(iOV++), *(pType++),
		century->WaterTemp().evap,
		areaFraction );

	// TRAN
	UpdateVariable (
		*(iOV++), *(pType++),
		century->WaterTemp().tran,
		areaFraction );

	// RAIN
	UpdateVariable (
		*(iOV++), *(pType++),
		century->WaterTemp().rain,
		areaFraction );

	// IRRACT:
	UpdateVariable (
		*(iOV++), *(pType++),
		century->WaterTemp().irract,
		areaFraction );

	// STREAM(1)
	UpdateVariable (
		*(iOV++), *(pType++),
		century->WaterTemp().stream[0],
		areaFraction );

	//------------------------------------------------- Respiration
	// RESPH
	UpdateVariable (
		*(iOV++), *(pType++),
		( century->CO2().resp[0] +	// annual heterotrophic resp.
		  century->CO2().resp[1] ),
		areaFraction );

	// SUMRSP
	UpdateVariable (
		*(iOV++), *(pType++),
		century->ForestC().sumrsp,	// Monthly maintenance resp.
		areaFraction );

	//------------------------------------------------- Production
	// CPRODC : crop NPP
	UpdateVariable (
		*(iOV++), *(pType++),
		century->CropGrassC().cprodc,		// monthly crop npp
		areaFraction );

	// CPRODF : forest NPP
	UpdateVariable (
		*(iOV++), *(pType++),
		century->ForestC().cprodf,		// monthly forest npp
		areaFraction );

	// NPP : total NPP
	UpdateVariable (
		*(iOV++), *(pType++),
		( century->ForestC().cprodf +
		  century->CropGrassC().cprodc ),
		areaFraction );

	// NEP : total NEP
	UpdateVariable (
		*(iOV++), *(pType++),
		( century->ForestC().cproda -		// annual cum. npp
		  ( century->CO2().resp[0] +		// annual cum. resp.
		    century->CO2().resp[1] ) ),
		areaFraction );

	// FORTC : forest total C live + dead
	UpdateVariable (
		*(iOV++), *(pType++),
		( century->ForestC().frstc +
		  century->ForestC().woodc ),
		areaFraction );

	// CGTC : crop/grass total C live + dead
	UpdateVariable (
		*(iOV++), *(pType++),
		( century->CropGrassC().aglivc +
		  century->CropGrassC().bglivc +
		  century->CropGrassC().stdedc ),
		areaFraction );

	// STREAM(5)
	UpdateVariable (
		*(iOV++), *(pType++),
		century->WaterTemp().stream[4],
		areaFraction );

	// CRET - annual crop/grass C removed (not respiration)
	UpdateVariable (
		*(iOV++), *(pType++),
		( century->CropGrassC().creta +		// live C grazing
		  century->CropGrassC().sdrema +	// stand dead graz/fire
		  century->CropGrassC().shrema +	// shoots graz/fire
		  century->CropGrassC().cgracc +	// harvested crop C
		  century->CropGrassC().accrst ),	// harvested straw C
		areaFraction );

	// TCREM - annual forest C removed ( fire/harvest - not respiration)
	UpdateVariable (
		*(iOV++), *(pType++),
		century->ForestC().tcrem,
		areaFraction );

	//------------------------------------------------- Soil Pool Totals
	// SOILTC
	UpdateVariable (
		*(iOV++), *(pType++),
		century->SoilC().totc,
		areaFraction );

	// SOMTE(1)
	UpdateVariable (
		*iOV, *pType,
		century->NPS().somte[0],
		areaFraction );

	// --- all done! ---
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------


//--- end of file ---
