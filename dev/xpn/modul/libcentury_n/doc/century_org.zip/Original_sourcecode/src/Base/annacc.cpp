// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  annacc.cpp
//	Class:	  TCenturyBase
//	Function: ResetAnnualAccum
//
//	Description:
//	Reset annual accumulators.
// ----------------------------------------------------------------------------
//	History:
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::ResetAnnualAccum ()
{
    wt.prcann = wt.petann = 0.0f;
    nps.nfixac = nps.wdfxas = nps.wdfxaa = 0.0f;
    nps.snfxac[0] = nps.snfxac[1] = 0.0f;
    cropC.accrst = 0.0f;
    for (short element = 0; element < site.nelem; ++element)
    {
	// Initialize mineralization accumulators
	nps.tnetmn[element] = 0.0f;
	nps.sumnrs[element] = 0.0f;
	nps.soilnm[element] = 0.0f;
    }
    // removals
    cropC.shrema = cropC.shrmai[0] = cropC.shrmai[1] = 0.0f;
    cropC.sdrema = cropC.sdrmai[0] = cropC.sdrmai[1] = 0.0f;
    cropC.creta = forestC.tcrem = 0.0f;
    for (short element = 0; element < site.nelem; ++element)
    {
	nps.ereta[element] = 0.0f;
	nps.shrmae[element] = 0.0f;
	nps.sdrmae[element] = 0.0f;
    }
    // Initialize annual C production
    cropC.cgrain = 0.0f;
    forestC.cproda = 0.0f;
    cropC.cprodc = 0.0f;
    forestC.cprodf = 0.0f;
    for ( short i = 0; i < 3; ++i )
	comput.annualSumSoilC[i] = 0.0f;
    // Initialize cinputs
    cropC.cinput = 0.0f;
    // Reset minimum total non-living C, an annual value (see savarp)
    // soilC.totc = 1e6f;
    soilC.totc = 0.0f;
    // Initialize co2 accumulators (10/92)
    co2.resp[0] = co2.resp[1] = 0.0f;
    co2.ast1c2 = co2.ast2c2 = 0.0f;
    co2.amt1c2 = co2.amt2c2 = 0.0f;
    co2.as11c2 = co2.as21c2 = 0.0f;
    co2.as2c2 = 0.0f;
    co2.as3c2 = 0.0f;
}

//--- end of file annacc.cpp ---
