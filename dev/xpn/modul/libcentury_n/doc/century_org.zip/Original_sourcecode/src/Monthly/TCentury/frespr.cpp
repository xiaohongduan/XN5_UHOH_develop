// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  frespr.cpp
//	Class:	  TCentury
//	Function: ForestMaintRespiration
//
//	Description:
//	Calculates the maintenance respiration per month 
//	for the forest materials (fine root, coarse root, fine branch, 
//	large wood, and leaf) using an equation derived by Mike Ryan. 
//	Maintenance respiration and tissue N content are strongly 
//	correlated. 
//
//	Reference:  
//	A simple method for estimating gross carbon budget 
//	for vegetation in forest ecosystems.  (Appendix A) 
//	Michael G. Ryan 
//	Tree Physiology, February 1, 1991 
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include <cmath>

// inline
float TCentury::ForestMaintRespiration (
	float const temp,	// tave - for leaf and stem, stemp - for root
	float const nitrogen)	// rleave(1), rlwode(1), fbrche(1), 
				// croote(1), or froote(1)
{
    /*
       frespr =  ((.0106 / 4.0) * (12. / 14.) * 24 * 30 *
		exp((alog(2.) / 10.) * temp) * nitrogen) * 1.1
    */
    return 1.63542857 * std::exp(0.06931472 * temp) * nitrogen * 1.1f;
}
