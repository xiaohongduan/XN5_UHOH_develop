
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Rewrite the livn.nc netCDF file using COARDS standards */
/* The original file was organized variable(cell, time) */
/* The new file is organized variable(time, lat, lon) */

#include <stdio.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf_ll.h"

    int write_livn_ll_(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  aglivn_vals[MAXCELLS], bglivn_vals[MAXCELLS], stdedn_vals[MAXCELLS],
             rleavn_vals[MAXCELLS], frootn_vals[MAXCELLS], fbrchn_vals[MAXCELLS],
             rlwodn_vals[MAXCELLS], crootn_vals[MAXCELLS], wood1n_vals[MAXCELLS],
             wood2n_vals[MAXCELLS], wood3n_vals[MAXCELLS], crpstgn_vals[MAXCELLS],
             forstgn_vals[MAXCELLS];
      int status;
      int oldlivnid;
      int oldaglivnid, oldbglivnid, oldstdednid, oldrleavnid, oldfrootnid,
          oldfbrchnid, oldrlwodnid, oldcrootnid, oldwood1nid, oldwood2nid,
          oldwood3nid, oldcrpstgnid, oldforstgnid;
      int ii, jj, ngrids;

      /* Open old version of livn.nc file */
      status = nc_open("livn.nc", NC_NOWRITE, &oldlivnid);
      if (status != NC_NOERR) handle_error("nc_open(livn.nc)", status);

      /* Get the indices for the livn output variables */
      status = nc_inq_varid(oldlivnid, "aglivn", &oldaglivnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for aglivn",status);
      status = nc_inq_varid(oldlivnid, "bglivn", &oldbglivnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for bglivn",status);
      status = nc_inq_varid(oldlivnid, "stdedn", &oldstdednid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for stdedn",status);
      status = nc_inq_varid(oldlivnid, "rleavn", &oldrleavnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for rleavn",status);
      status = nc_inq_varid(oldlivnid, "frootn", &oldfrootnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for frootn",status);
      status = nc_inq_varid(oldlivnid, "fbrchn", &oldfbrchnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for fbrchn",status);
      status = nc_inq_varid(oldlivnid, "rlwodn", &oldrlwodnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for rlwodn",status);
      status = nc_inq_varid(oldlivnid, "crootn", &oldcrootnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for crootn",status);
      status = nc_inq_varid(oldlivnid, "wood1n", &oldwood1nid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wood1n",status);
      status = nc_inq_varid(oldlivnid, "wood2n", &oldwood2nid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wood2n",status);
      status = nc_inq_varid(oldlivnid, "wood3n", &oldwood3nid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wood3n",status);
      status = nc_inq_varid(oldlivnid, "crpstgn", &oldcrpstgnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for crpstgn",status);
      status = nc_inq_varid(oldlivnid, "forstgn", &oldforstgnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for forstgn",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        aglivn_vals[ii] = fill;
        bglivn_vals[ii] = fill;
        stdedn_vals[ii] = fill;
        rleavn_vals[ii] = fill;
        frootn_vals[ii] = fill;
        fbrchn_vals[ii] = fill;
        rlwodn_vals[ii] = fill;
        crootn_vals[ii] = fill;
        wood1n_vals[ii] = fill;
        wood2n_vals[ii] = fill;
        wood3n_vals[ii] = fill;
        crpstgn_vals[ii] = fill;
        forstgn_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the livn output file */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldlivnid, oldaglivnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for aglivn",status);
            }
            aglivn_vals[jj] = val;
            status = nc_get_var1_float(oldlivnid, oldbglivnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for bglivn",status);
            }
            bglivn_vals[jj] = val;
            status = nc_get_var1_float(oldlivnid, oldstdednid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for stdedn",status);
            }
            stdedn_vals[jj] = val;
            status = nc_get_var1_float(oldlivnid, oldrleavnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for rleavn",status);
            }
            rleavn_vals[jj] = val;
            status = nc_get_var1_float(oldlivnid, oldfrootnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for frootn",status);
            }
            frootn_vals[jj] = val;
            status = nc_get_var1_float(oldlivnid, oldfbrchnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for fbrchn",status);
            }
            fbrchn_vals[jj] = val;
            status = nc_get_var1_float(oldlivnid, oldrlwodnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for rlwodn",status);
            }
            rlwodn_vals[jj] = val;
            status = nc_get_var1_float(oldlivnid, oldcrootnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for crootn",status);
            }
            crootn_vals[jj] = val;
            status = nc_get_var1_float(oldlivnid, oldwood1nid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wood1n",status);
            }
            wood1n_vals[jj] = val;
            status = nc_get_var1_float(oldlivnid, oldwood2nid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wood2n",status);
            }
            wood2n_vals[jj] = val;
            status = nc_get_var1_float(oldlivnid, oldwood3nid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wood3n",status);
            }
            wood3n_vals[jj] = val;
            status = nc_get_var1_float(oldlivnid, oldcrpstgnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for crpstgn",status);
            }
            crpstgn_vals[jj] = val;
            status = nc_get_var1_float(oldlivnid, oldforstgnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for forstgn",status);
            }
            forstgn_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(livnll_ncid, aglivnll_id, start, count, aglivn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for aglivn",status);
        status = nc_put_vara_float(livnll_ncid, bglivnll_id, start, count, bglivn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for bglivn",status);
        status = nc_put_vara_float(livnll_ncid, stdednll_id, start, count, stdedn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for stdedn",status);
        status = nc_put_vara_float(livnll_ncid, rleavnll_id, start, count, rleavn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for rleavn",status);
        status = nc_put_vara_float(livnll_ncid, frootnll_id, start, count, frootn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for frootn",status);
        status = nc_put_vara_float(livnll_ncid, fbrchnll_id, start, count, fbrchn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for fbrchn",status);
        status = nc_put_vara_float(livnll_ncid, rlwodnll_id, start, count, rlwodn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for rlwodn",status);
        status = nc_put_vara_float(livnll_ncid, crootnll_id, start, count, crootn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for crootn",status);
        status = nc_put_vara_float(livnll_ncid, wood1nll_id, start, count, wood1n_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wood1n",status);
        status = nc_put_vara_float(livnll_ncid, wood2nll_id, start, count, wood2n_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wood2n",status);
        status = nc_put_vara_float(livnll_ncid, wood3nll_id, start, count, wood3n_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wood3n",status);
        status = nc_put_vara_float(livnll_ncid, crpstgnll_id, start, count, crpstgn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for crpstgn",status);
        status = nc_put_vara_float(livnll_ncid, forstgnll_id, start, count, forstgn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for forstgn",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldlivnid);

      return 0;
    }
