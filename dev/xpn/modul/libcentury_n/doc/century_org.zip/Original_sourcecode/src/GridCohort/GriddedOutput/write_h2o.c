
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include "netcdf.h"
#include "wrtcdf.h"

int
write_h2o(float h2o[][12])
{
        int status;
        float *p = (float *) h2o;

	/* Write output to NetCDF file */
	status = nc_put_vara_float(h2o_ncid, avh2o1_id, start, count, p);
	status = nc_put_vara_float(h2o_ncid, avh2o2_id, start, count, p + 12);
	status = nc_put_vara_float(h2o_ncid, avh2o3_id, start, count, p + (2 * 12));
	/* There are at most 10 layers  - output all regardless */
	status = nc_put_vara_float(h2o_ncid, asmos_id, start_layer, count_layer, p + (3 * 12));
	status = nc_put_vara_float(h2o_ncid, evap_id, start, count, p + (13 * 12));
	status = nc_put_vara_float(h2o_ncid, pet_id, start, count, p + (14 * 12));
	status = nc_put_vara_float(h2o_ncid, rwcf_id, start, count, p + (15 * 12));
	status = nc_put_vara_float(h2o_ncid, snlq_id, start, count, p + (16 * 12));
	status = nc_put_vara_float(h2o_ncid, snow_id, start, count, p + (17 * 12));
	status = nc_put_vara_float(h2o_ncid, stemp_id, start, count, p + (18 * 12));
	status = nc_put_vara_float(h2o_ncid, stream1_id, start, count, p + (19 * 12));
	status = nc_put_vara_float(h2o_ncid, stream2_id, start, count, p + (20 * 12));
	status = nc_put_vara_float(h2o_ncid, stream5_id, start, count, p + (21 * 12));
	status = nc_put_vara_float(h2o_ncid, stream6_id, start, count, p + (22 * 12));
	status = nc_put_vara_float(h2o_ncid, tran_id, start, count, p + (23 * 12));
	status = nc_put_vara_float(h2o_ncid, runo_id, start, count, p + (24 * 12));

	/* Reset Memory for h2o variable */
	memset(p, '\0', (sizeof(float) * 25 * 12));

	return 0;
}
