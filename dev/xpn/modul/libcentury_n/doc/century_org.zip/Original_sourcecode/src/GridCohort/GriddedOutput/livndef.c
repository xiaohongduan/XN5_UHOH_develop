
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  livn_ncid;			/* netCDF id */

/* variable ids */
int  aglivn_id, bglivn_id, stdedn_id, rleavn_id, frootn_id, 
     fbrchn_id, rlwodn_id, crootn_id, wood1n_id, wood2n_id, 
     wood3n_id, crpstgn_id, forstgn_id;

/* crpstgn and forstgn added 7/14/00 - mdh */

int
livndef(int *ntimes, char *history) {			/* create livn.nc */

   int status;

   /* dimension ids */
   int  time_dim = 0;
   int  cell_dim = 0;

   /* variable shapes */
   int dims[2];

   /* enter define mode */
   status = nc_create("livn.nc", NC_CLOBBER, &livn_ncid );
   if (status != NC_NOERR) handle_error("nc_create(livn.nc)", status);

   /* define dimensions */
   status = nc_def_dim(livn_ncid, "time", (size_t) *ntimes, &time_dim );
   status = nc_def_dim(livn_ncid, "cell", NC_UNLIMITED, &cell_dim );

   /* define variables */

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livn_ncid, "aglivn", NC_FLOAT, 2, dims, &aglivn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livn_ncid, "bglivn", NC_FLOAT, 2, dims, &bglivn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livn_ncid, "stdedn", NC_FLOAT, 2, dims, &stdedn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livn_ncid, "rleavn", NC_FLOAT, 2, dims, &rleavn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livn_ncid, "frootn", NC_FLOAT, 2, dims, &frootn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livn_ncid, "fbrchn", NC_FLOAT, 2, dims, &fbrchn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livn_ncid, "rlwodn", NC_FLOAT, 2, dims, &rlwodn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livn_ncid, "crootn", NC_FLOAT, 2, dims, &crootn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livn_ncid, "wood1n", NC_FLOAT, 2, dims, &wood1n_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livn_ncid, "wood2n", NC_FLOAT, 2, dims, &wood2n_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livn_ncid, "wood3n", NC_FLOAT, 2, dims, &wood3n_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livn_ncid, "crpstgn", NC_FLOAT, 2, dims, &crpstgn_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livn_ncid, "forstgn", NC_FLOAT, 2, dims, &forstgn_id);

   /* assign attributes */
   status = nc_put_att_text (livn_ncid, NC_GLOBAL, "history", strlen(history), history);
   status = nc_put_att_text (livn_ncid, aglivn_id, "long_name",
	strlen("above_ground_live_nitrogen"), "above_ground_live_nitrogen");
   status = nc_put_att_text (livn_ncid, aglivn_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livn_ncid, bglivn_id, "long_name", 
	strlen("below_ground_live_nitrogen"), "below_ground_live_nitrogen");
   status = nc_put_att_text (livn_ncid, bglivn_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livn_ncid, stdedn_id, "long_name", 
	strlen("standing_dead_nitrogen"), "standing_dead_nitrogen");
   status = nc_put_att_text (livn_ncid, stdedn_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livn_ncid, rleavn_id, "long_name", 
	strlen("live_leaf_nitrogen"), "live_leaf_nitrogen");
   status = nc_put_att_text (livn_ncid, rleavn_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livn_ncid, frootn_id, "long_name", 
	strlen("live_fine_root_nitrogen"), "live_fine_root_nitrogen");
   status = nc_put_att_text (livn_ncid, frootn_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livn_ncid, fbrchn_id, "long_name", 
	strlen("live_fine_branch_nitrogen"), "live_fine_branch_nitrogen");
   status = nc_put_att_text (livn_ncid, fbrchn_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livn_ncid, rlwodn_id, "long_name", 
	strlen("live_large_wood_nitrogen"), "live_large_wood_nitrogen");
   status = nc_put_att_text (livn_ncid, rlwodn_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livn_ncid, crootn_id, "long_name", 
	strlen("live_coarse_root_nitrogen"), "live_coarse_root_nitrogen");
   status = nc_put_att_text (livn_ncid, crootn_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livn_ncid, wood1n_id, "long_name", 
	strlen("dead_fine_branch_nitrogen"), "dead_fine_branch_nitrogen");
   status = nc_put_att_text (livn_ncid, wood1n_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livn_ncid, wood2n_id, "long_name", 
	strlen("dead_large_wood_nitrogen"), "dead_large_wood_nitrogen");
   status = nc_put_att_text (livn_ncid, wood2n_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livn_ncid, wood3n_id, "long_name", 
	strlen("dead_coarse_root_nitrogen"), "dead_coarse_root_nitrogen");
   status = nc_put_att_text (livn_ncid, wood3n_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (livn_ncid, crpstgn_id, "long_name", 
	strlen("N_in_crop_retranslocation_storage"), "N_in_crop_retranslocation_storage");
   status = nc_put_att_text (livn_ncid, crpstgn_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livn_ncid, forstgn_id, "long_name", 
	strlen("N_in_forest_retranslocation_storage"), "N_in_forest_retranslocation_storage");
   status = nc_put_att_text (livn_ncid, forstgn_id, "units", strlen("g/m2"), "g/m2");

   /* leave define mode */
   status = nc_enddef (livn_ncid);
   return 0;
}
