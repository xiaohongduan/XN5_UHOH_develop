#ifndef INC_nrel_century_PlantBase_h
#define INC_nrel_century_PlantBase_h

// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  PlantBase.h
//	Class:	  PlantBase
//
//	Description:
//	Class for management of a plant object.
//
//	Responsibilities:
//	* <what class is supposed to do>
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, June 2005
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

namespace nrel
{
  namespace century
  {

class PlantBase
{
  public:
	//---- types

	//---- constructors and destructor

  protected:
	PlantBase ()
	  : isPlanted (false),
	    isGrowing (false)
	  {
	  }
	PlantBase (
	  PlantBase const & object)
	  {
	    Copy (object);
	  }

  public:
	virtual ~PlantBase () = 0;
//	virtual PlantBase * const Clone () const = 0;	// Clone this

	//---- operator overloads
	PlantBase& operator= (
	  PlantBase const & object)
	  {
	    if (this != &object)	// assigning self?
		Copy (object);
	    return *this;
	  }
	bool operator== (
	  PlantBase const & object) const
	  {
	    if ( &object )
	    {
		return
		  isGrowing == object.isGrowing &&
		  isPlanted == object.isPlanted &&
		  monthsSincePlanting == object.monthsSincePlanting;
	    }
	    else
		return false;
	  }
	bool operator!= (
	  PlantBase const & object) const
	  {
	    return !(*this == object);
	  }

	//---- functions
	bool IsPlanted () const			// True if planted/not harvested
	  { return isPlanted; }
	void SetPlantedFlag (			// Set is-planted flag
	  bool const flag)
	  { isPlanted = flag; }
	bool IsGrowing () const			// True if growing
	  { return isGrowing; }
	void SetGrowingFlag (			// Set is-growing flag
	  bool const flag)
	  { isGrowing = flag; }
	short MonthsSincePlanting () const	// Months since planting
	  { return monthsSincePlanting; }
	void SetMonthsSincePlanting (		// Set months since planting
	  short const numberOfMonths)
	  { monthsSincePlanting = numberOfMonths; }
	void Clear ()				// "Clear" data members
	  {
	    isGrowing = isPlanted = false;
	    monthsSincePlanting = 0;
	  }

  protected:
	//---- constants

	//---- data
	bool isGrowing;			// true if growing
	bool isPlanted;			// true if planted and not yet harvested
	short monthsSincePlanting;	// number of months since planting

	//---- constructors and destructor

	//---- functions

  private:
	//---- constants

	//---- data

	//---- functions
	void Copy (					// Copy to this
	  PlantBase const & object)
	  {
	    if ( &object )
	    {
	      isGrowing = object.isGrowing;
	      isPlanted = object.isPlanted;
	      monthsSincePlanting = object.monthsSincePlanting;
	    }
	  }
};

inline PlantBase::~PlantBase ()
{
}


  } // namespace century
} // namespace nrel

#endif // INC_nrel_century_PlantBase_h
