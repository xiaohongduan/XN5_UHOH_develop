#ifndef INC_TAboutDlg_h
#define INC_TAboutDlg_h
// ----------------------------------------------------------------------------
//	Copyright (c) 1998-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TAboutDlg.h
//	Class:	  TAboutDialog
//
//	Description:
//	Class for the "About...' dialog for Century Model Interface & Century.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Jul98, tom.hilinski@colostate.edu
//	History:
//	Oct01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Updated informatin display.
// ----------------------------------------------------------------------------

#include <v/vmodald.h>

// Notes:
// This should be modified to
// add buttons for user to obtain more detailed info. about this  app.
// Suggest then storing all text and V icon data in a netCDF file to keep
// out of memory most of the time.
// Add the CMI icon to the left of the version.

//	-----------------------------------------------------------------------
//	class TAboutDialog

class TAboutDialog : public vModalDialog
{
public:
	// constructors and destructor
	TAboutDialog (vApp* const parent)
		: vModalDialog (parent, title)
		{
		  ConstructMe ();
		}
	TAboutDialog (vBaseWindow* const parent)
		: vModalDialog (parent, title)
		{
		  ConstructMe ();
		}
	void ConstructMe ()
		{
		  AddDialogCmds ((CommandObject*)cmdList);
		  ItemVal retVal;
		  ShowModalDialog (title, retVal);
		}
	// functions overridden
	void DialogCommand (ItemVal id, ItemVal val, CmdType type);

private:
	// data
	static const char			// text strings
		* const title,
		* const version,
		* const where,
		* const who,
		* const notes,
		* const netCDF,
		* const VLib,
		* const copyright;
	static CommandObject cmdList[];		// dialog elements
};


#endif 	// INC_TAboutDlg_h
