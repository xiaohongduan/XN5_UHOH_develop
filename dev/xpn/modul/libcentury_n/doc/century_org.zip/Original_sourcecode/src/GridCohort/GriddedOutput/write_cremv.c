
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include "netcdf.h"
#include "wrtcdf.h"

int
write_cremv(float C_remv[][12])
{
        int status;
        float *p = (float *) C_remv;

	/* Write output to NetCDF file */
	status = nc_put_vara_float(cremv_ncid, shremc_id, start, count, p);
	status = nc_put_vara_float(cremv_ncid, sdremc_id, start, count, p + 12);
	status = nc_put_vara_float(cremv_ncid, rlvremc_id, start, count, p + 24);
	status = nc_put_vara_float(cremv_ncid, fbrremc_id, start, count, p + 36);
	status = nc_put_vara_float(cremv_ncid, rlwremc_id, start, count, p + 48);
	status = nc_put_vara_float(cremv_ncid, wd1remc_id, start, count, p + 60);
	status = nc_put_vara_float(cremv_ncid, wd2remc_id, start, count, p + 72);
	status = nc_put_vara_float(cremv_ncid, stremc_id, start, count, p + 84);
	status = nc_put_vara_float(cremv_ncid, metrmc_id, start, count, p + 96);

	/* Reset memory for variable C_remv */
	 memset(p, '\0', (sizeof(float) * 9 * 12));

	return 0;
}
