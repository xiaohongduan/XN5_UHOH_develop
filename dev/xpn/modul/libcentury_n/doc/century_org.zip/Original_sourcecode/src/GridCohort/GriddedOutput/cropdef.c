
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  crop_ncid;			/* netCDF id */

/* variable ids */
int  crpval_id, crmvst_id, cgrain_id, feramt_id, irract_id, egrain_id, ermvst_id;

int
cropdef(int *ntimes, char *history) {		/* create crop.nc */

   int status;

   /* dimension ids */
   int  time_dim = 0;
   int  cell_dim = 0;

   /* variable shapes */
   int dims[2];

   /* enter define mode */
   status = nc_create("crop.nc", NC_CLOBBER, &crop_ncid);
   if (status != NC_NOERR) handle_error("nc_create(crop.nc)", status);

   /* define dimensions */
   status = nc_def_dim(crop_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(crop_ncid, "cell", NC_UNLIMITED, &cell_dim);

   /* define variables */

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (crop_ncid, "crpval", NC_FLOAT, 2, dims, &crpval_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (crop_ncid, "crmvst", NC_FLOAT, 2, dims, &crmvst_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (crop_ncid, "cgrain", NC_FLOAT, 2, dims, &cgrain_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (crop_ncid, "feramt", NC_FLOAT, 2, dims, &feramt_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (crop_ncid, "irract", NC_FLOAT, 2, dims, &irract_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (crop_ncid, "egrain", NC_FLOAT, 2, dims, &egrain_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (crop_ncid, "ermvst", NC_FLOAT, 2, dims, &ermvst_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;

   /* assign attributes */
   status = nc_put_att_text (crop_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (crop_ncid, crpval_id, "long_name", 
        strlen("crop_value"), "crop_value");
   status = nc_put_att_text (crop_ncid, crpval_id, "units", strlen("unitless"), "unitless");

   status = nc_put_att_text (crop_ncid, crmvst_id, "long_name", 
	strlen("C_in_harvested_straw"), "C_in_harvested_straw");
   status = nc_put_att_text (crop_ncid, crmvst_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   status = nc_put_att_text (crop_ncid, cgrain_id, "long_name", 
	strlen("C_in_harvested_grain"), "C_in_harvested_grain");
   status = nc_put_att_text (crop_ncid, cgrain_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   status = nc_put_att_text (crop_ncid, feramt_id, "long_name", 
	strlen("fertilization amount"), "fertilization amount");
   status = nc_put_att_text (crop_ncid, feramt_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   status = nc_put_att_text (crop_ncid, irract_id, "long_name", 
	strlen("irrigation_amount"), "irrigation_amount");
   status = nc_put_att_text (crop_ncid, irract_id, "units", strlen("cm/mo"), "cm/mo");

   status = nc_put_att_text (crop_ncid, egrain_id, "long_name", 
	strlen("N_in_harvested_grain"), "N_in_harvested_grain");
   status = nc_put_att_text (crop_ncid, egrain_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   status = nc_put_att_text (crop_ncid, ermvst_id, "long_name", 
	strlen("N_in_harvested_straw"), "N_in_harvested_straw");
   status = nc_put_att_text (crop_ncid, ermvst_id, "units", strlen("g/m2/mo"), "g/m2/mo");

   /* leave define mode */
   status = nc_enddef (crop_ncid);
   return 0;
}
