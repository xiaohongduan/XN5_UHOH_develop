#ifndef INC_Dlg_SiteFromLib_h
#define INC_Dlg_SiteFromLib_h
// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TSiteFromLibDlg.h
//	Class:	  TSiteFromLibDlg
//
//	Description:
//	Class for copying a site parameter set from the library.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Apr98
//	History:
//	Mar99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added display of the editor name and edit date in the summary panel.
// ----------------------------------------------------------------------------

#include "TModalDlg.h"
#include "TFileName.h"
#include "TMCSiteParameters.h"
#include <vector>
#include <v/vapp.h>
using namespace std;

//	-----------------------------------------------------------------------
//	Command objects values
#ifdef _TSiteFromLibDlg_ClassDefined_

#endif	// _TSiteFromLibDlg_ClassDefined_

//	-----------------------------------------------------------------------
//	TSiteDesc
//	Temporary data for site descriptions
struct TSiteDesc
{
	TSiteParametersBase::TSiteType type;	// category for description
	char desc[81];				// size matches netCDF file def.
};

//	-----------------------------------------------------------------------
//	TSiteSummary
//	Holds summary info for each site.
//	Char vars are static for speed.
struct TSiteSummary
{
	std::string fileName;		// name of site file (no path)
	std::string name;		// site name (mnemonic)
	float latitude, longitude;	// location (degrees)
	float sand, silt, clay;		// % of each constituent in surface
	std::string editorName;		// attribute: name of last editor
	std::string editDate;		// attribute: date of last edit

	//--- constructors
	TSiteSummary ()
	  { Clear (); }

	//--- functions
	void Clear ()
	  {
	    fileName.clear();
	    name.clear();
	    latitude = longitude = 0.0f;
	    sand = silt = clay = 0.0f;
	    editorName.clear();
	    editDate.clear();
	  }
};

//	-----------------------------------------------------------------------
//	TSiteFromLibDlg
class TSiteFromLibDlg
	: public TModalDlg
{
  public:
	//--- types
	typedef TSiteParametersBase::TSiteType	TSiteType;
	enum {				// Command objects values
	  SiteFromLib_Start = 11500,	// first item!
					//--- site library (radiobuttons)
	  D_DefaultLib,			// app default library folder
	  D_PersonalLib,		// user's personal library folder
					//--- site category
	  D_CatCrop, 			// radiobutton: crop
	  D_CatGrass, 			// radiobutton: grass
	  D_CatTree, 			// radiobutton: tree
	  D_CatSavanna, 		// radiobutton: savanna
					//--- site list and data
	  D_DescripList, 		// list: descriptions
	  D_SiteFile,			// r/o text: site file name
	  D_Mnemonic, 			// r/o text: mnemonic
	  D_Lat, 			// r/o text: latitude
	  D_Long, 			// r/o text: longitude
	  D_Sand, 			// r/o text: surface sand %
	  D_Silt, 			// r/o text: surface silt %
	  D_Clay, 			// r/o text: surface clay %
	  D_EditorName,			// r/o text: editor name
	  D_EditDate,			// r/o text: last edit date
					//--- search paths
	  D_LibPath1,			// default
	  D_LibPath2,			// personal
					//--- all done!
	  SiteFromLib_End		// last item!
	};

	//--- constructors and destructor
	TSiteFromLibDlg (
	  vApp * const useParent,		// pointer to app parent
	  std::string const & useHelpPath,	// path to help file
	  std::string const & defPath,		// path to site libraries
	  std::string const & userPath,		// user's site library path
	  std::string & siteFile,		// returns selected site file
	  char const * const title =		// dialog title
		"Select a Site Parameter Set");
	TSiteFromLibDlg (
	  vBaseWindow * const useParent,	// pointer to window parent
	  vApp * const useApp,			// pointer to app parent
	  std::string const & useHelpPath,	// path to help file
	  std::string const & defPath,		// path to site libraries
	  std::string const & userPath,		// user's site library path
	  std::string & siteFile,		// returns selected site file
	  char const * const title =		// dialog title
		"Select a Site Parameter Set");
	~TSiteFromLibDlg ();

	//--- functions overridden
	void DialogDisplayed ();
	void DialogCommand (ItemVal id, ItemVal val, CmdType type);

  private:
	// types
	typedef vector<TSiteSummary>		TSiteSumArray;

	//--- constants
	static std::string const maskSiteFileNetCDFSuffix;
	static char const * const toolTips[];		// tool tips text
	static CommandObject cmdList[];			// dialog elements

	//--- data
	vApp* const parent;			// pointer to parent
	std::string const helpFilePath;		// path to help file
	char **descListCrop[2],			// description lists
	     **descListGrass[2],		// (0 = default, 1 = personal)
	     **descListTree[2],
	     **descListSav[2];
	TSiteSumArray sumCrop[2],		// summary arrays
		      sumGrass[2],		// (0 = default, 1 = personal)
		      sumTree[2],
		      sumSav[2];
	std::string libPath[2];			// paths to the site files
						// 0 = default site lib path
						// 1 = user's site lib path
	short usingPath;			// selected path (0, 1)
	TSiteType usingCat;			// selected category (1-4)
	TSiteSummary* usingSiteSum;		// current site summary
	short idxParamList;		// index to description list in cmdList

	//--- functions
	void ConstructMe (		// common constructor
	  std::string const & defPath,	// path to site libraries
	  std::string const & userPath,	// user's site library path
	  std::string & siteFile,	// returns selected site file
	  char const * const title);	// dialog title
	void Initialize ();		// initialize members
	void ReadDescriptions ();	// gets site descriptions from files
					//--- Load data into dialogs:
	void LoadDlg ();	   	// load the dialog
	void UpdateDlg_SiteList ();	// site list
	void UpdateDlg_SiteData ();	// site data
					//--- Clear dialog controls:
	void ClearDlgSiteList ();	// Clear site list display
	void ClearDlgSiteSum ();	// Clear the site summary data
};

#endif // INC_Dlg_SiteFromLib_h
