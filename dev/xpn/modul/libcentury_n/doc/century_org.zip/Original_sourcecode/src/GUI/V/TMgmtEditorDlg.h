#ifndef INC_TMgmtDlg_h
#define INC_TMgmtDlg_h
// ----------------------------------------------------------------------------
//	Copyright 1999-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TMgmtEditorDlg.cpp
//	Class:	  TMgmtEditorDlg
//
//	Description:
//	Dialog box for editing the site managment.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Dec97
//	History:
//	Mar99	Tom Hilinski
//	* Added controls, events, functions to select the files for
//	  14C input data, erosion output data, deposition input data.
//	Feb00	Tom Hilinski
//	* Added additional file extentions for browsing for weather files
//	  in function Evt_BrowseWthrFile.
//	Jan01	Tom Hilinski
//	* Added input field for microcosm temperature, and associated
//	  event handler; modified get/load for this field.
//	* Separated microcosm and CO2 effects into adjacent frames.
//	* Added event ET_External handling.
//	Oct03	Tom Hilinski
//	* Some minor cleanup.
//	* Renamed class to TMgmtEditorDlg.
// ----------------------------------------------------------------------------
//	Notes:
//	This class is divided among the following files:
//	TMgmtEditorDlg.h		declarations header file
//	TMgmtEditorDlg.cpp		main class definitions
//	TMgmtEditorDlgLoad.cpp		methods to load data into dialog
//	TMgmtEditorDlgEvents.cpp	methods to handle dialog events
//	TMgmtEditorDlgGet.cpp		methods to retrieve data from dialog
// ----------------------------------------------------------------------------

#include <v/vapp.h>
#include "TModalDlg.h"
#include "TManagement.h"
#include "TVerifyMgmt.h"
#include "TEventDBList.h"

//	Command objects values

#ifdef _TMgtDlg_ClassDefined_

#define NUMBER_OF_TABS	3
enum {
	Enum_TMgtDlg_Start = 10000,	// first item!
					//--- Action buttons
	D_NewMgt, 			// button: new/clear management scheme
	D_OpenMgt, 			// button: open a previous scheme
	D_ImpMgt, 			// button: import Century 4.0 schedule
	D_MgtFromLib,			// button: get mgmt. from library
	D_SaveMgt, 			// button: save the current scheme
	D_VerifyMgmt,			// button: verify mgmt.
					//--- Tab buttons
	Tab_Simulation,			// Simulation info dialog
	Tab_BlockDef,			// Block definitions (events) dialog
	Tab_BlockInst,			// Block instances dialog
	D_MgmtModified,			// color text: displayed if modified
	D_MgmtVerified,			// color text: verification status
					//--- Frames
	D_MasterFrame,
	D_ToggleFrame1,			// Simulation info dialog
	D_ToggleFrame2,			// Block definitions (events) dialog
	D_ToggleFrame3,			// Block instances dialog
					//--- Simulation info dialog
	D_MgtBaseName,			// text: mgmt. base file name
	D_MgtBaseNameChg,		// button: change mgmt. base file name
	D_MgtDescrip,			// edit: management description
	D_YearStart,			// edit: Simulation start year
	D_YearEnd,			// edit: Simulation end year
	D_LabelTypeNone,		// radiobtn: C labeling type - none
	D_LabelType14C,			// radiobtn: C labeling type - 14C
	D_LabelType13C,			// radiobtn: C labeling type - 13C
	D_LabelYear,			// edit: sim. year labeling starts
	D_Microcosm,			// checkbox: use microcosm
	D_MicrocosmTemp,		// edit: microcosm temperature
	D_CO2Effect,			// checkbox: use CO2 effect
	D_CO2EffectYrSt,		// checkbox: CO2 effect year start
	D_CO2EffectYrEnd,		// checkbox: CO2 effect year end
	D_InitSysCrop,			// radiobtn: init. system = crop
	D_InitSysTree,			// radiobtn: init. system = tree
	D_InitSysBoth,			// radiobtn: init. system = both
	D_InitSysCropStr,		// label: init. crop mnemonic
	D_InitSysTreeStr,		// label: init. tree mnemonic
	D_InitSysCropSel,		// button: init. crop choose
	D_InitSysTreeSel,		// button: init. tree choose
	D_14CFileName,			// edit: 14C file name
	D_14CFileBrowse,		// button: browse for a 14C file
	D_EroFileName,			// edit: erosion output  file name
	D_EroFileBrowse,		// button: browse for a erosion file
	D_DepFileName,			// edit: deposition input file name
	D_DepFileBrowse,		// button: browse for a deposition file
	D_SimBlkCnt,			// text: number of blocks defined
					//--- Block definition dialog
	D_BlkList,			// list: blocks
	D_BlkNew,			// button: add new block (clears first)
	D_BlkNewCopy,			// button: copy highlighted to new
	D_BlkLibAdd,			// button: add block from library
	D_BlkDel,			// button: delete block highlighted
	D_BlkNumber,			// text: block number
	D_BlkDesc,			// edit: block description
	D_BlkDescChange,		// button: change block description
	D_BlkEvtCnt,			// text: block event count
	D_BlkLenYrs,			// text: block length in years
	D_EvtList,			// list: events
	D_EvtNew,			// button: add new event (clears first)
	D_EvtDel,			// button: delete event highlighted
	D_EvtSave,			// button: save displayed event data
	D_EvtType,			// label: Type of event
					// Toggle dialogs for event data:
					// ( Note: Keep these in this order! )
	D_EvtTab_None,			// dialog for event data - no event
	D_EvtTab_Std,			// dialog for event data - std evt.
	D_EvtTab_Range,			// dialog for event data - range
					// Century 4.0 events:
	D_EvtYear,			// edit:  Year of event
	D_EvtMonth,			// edit: Month of event
	D_EvtAdd,			// edit: Additional info for event
	D_EvtAddChoose,			// button: choose additional info
					// Range events:
	D_RngYrStart,			// edit: Range event year at start
	D_RngYrEnd,			// edit: year at end
	D_RngValStart,			// edit: value at start
	D_RngValEnd,			// edit: value at end
	D_FracMo1,			// edit: monthly fractions
	D_FracMo2,			// edit: monthly fractions
	D_FracMo3,			// edit: monthly fractions
	D_FracMo4,			// edit: monthly fractions
	D_FracMo5,			// edit: monthly fractions
	D_FracMo6,			// edit: monthly fractions
	D_FracMo7,			// edit: monthly fractions
	D_FracMo8,			// edit: monthly fractions
	D_FracMo9,			// edit: monthly fractions
	D_FracMo10,			// edit: monthly fractions
	D_FracMo11,			// edit: monthly fractions
	D_FracMo12,			// edit: monthly fractions
					//--- Block instance dialog
					// Toggle dialogs for Instance data:
					// ( Note: Keep these in this order! )
	D_InstTab_None,			// dialog for Instance data - no inst.
	D_InstTab_Data,			// dialog for Instance data
					// Instance data:
	D_BlkListInst,			// list: blocks
	D_BlkDescInst,			// edit: block description
	D_BlkInstCnt,			// text: block instance count
	D_InstList,			// list: instances
	D_InstNew,			// button: add new instance (clears)
	D_InstNewCopy,			// button: copy highlighted to new
	D_InstDel,			// button: delete instance highlighted
	D_InstSave,			// button: save displayed inst. data
	D_FirstYear,			// edit: first year in simulation
	D_LastYear,			// edit: last year in simulation
	D_OutputYr, 			// edit: output year in block
	D_OutputMo, 			// edit: output month
	D_OutputFreq, 			// edit: output frequency
	D_OutputFreqSel,		// button: choose output frequency
	D_WthrMeans,			// radiobtn: Means from a site file
	D_WthrStoch,			// radiobtn: Stochastically-generated
	D_WthrFileRew,			// radiobtn: Rewind file for more years
	D_WthrFileCont,			// radiobtn: Data from current position
	D_WthrFileName,			// edit: weather file name
	D_WthrFileBrowse,		// button: browse for a weather file
	D_WthrFileMsg,			// text: msg. if problem with file
					//--- all done!
	Enum_TMgtDlg_End		// last item!
};

#endif	// _TMgtDlg_ClassDefined_


class TMgmtEditorDlg : public TModalDlg
{
  public:
	//--- constructors and destructor
	TMgmtEditorDlg (
	  vApp * const useParent,		// pointer to application
	  TSharedPtr<TManagementScheme> newMgmt, // original/final mgmt scheme
	  std::string const & useHelpPath,	// path to help file
	  std::string const & useMgmtLibPath,	// path to mgmt libraries
	  std::string const & useUserLibPath,	// user's mgmt library path
	  std::string const & useTemplatePath,	// path to template folder
	  std::string const & useWorkPath,	// user's work path
	  TEventDBList const & useDbList,	// parameter database list
	  char const *  const title = 		// dialog title
	  	"Edit the Site Management");
	~TMgmtEditorDlg();
	//--- functions overridden
	void DialogDisplayed ();
	void DialogCommand (ItemVal id, ItemVal val, CmdType type);
	//--- functions

  private:
  	//--- constants
	static char const * const version;	// version of editor
	static CommandObject cmdList[];		// dialog elements
	static char const * toolTips[];		// tooltip text

	//--- data
					//--- data passed into constructor
	vApp * const parent;			// application parent
	std::string const helpFilePath;		// path to help file
	std::string const & mgmtLibPath;	// path to mgmt library
	std::string const & userMgmtLibPath;	// user's site library path
	std::string const & templatePath;	// path to template folder
	std::string const & workPath;		// user's work path
	TSharedPtr<TManagementScheme> origMgmt;	// original management scheme
	TEventDBList const & dbList;		// parameter database list
					//--- dialog
	ItemVal* toggleButtonId;	// array of toggle button ID's
	ItemVal* toggleFrameId;		// array of toggle frame ID's
	int	 toggleCount;		// size of toggle ID arrays
	ItemVal  curButtonId, curFrameId;	// last selected toggle
					//--- for lists:
	char **blkList;			// list of block descrip. strings
	char **evtList;			// list of events for current block
	char **instList;		// list of instances for current block
	enum TEvtDlgSelect 		// for choosing event data dialog
	{
		EvtDlg_NoEvt = 0,	// for no events
		EvtDlg_Cent4, 		// for Century 4.0-style events
		EvtDlg_Range, 		// for range events
		EvtDlg_EndOfList
	};
	TEvtDlgSelect curEvtDlg;	// current event data dialog displayed
					//--- Management scheme in display
	TManagementScheme *mgmtDisp;	// active management scheme displayed
	TManagementBlock *blockDisp;	// active block in def and inst dlgs.
	TManagementEvent *evtDisp;	// active event data displayed
	TManagementInst *instDisp;	// active instance data displayed
	TVerifyMgmt* vrfy;		// instance of verification class
					//--- Indicies to cmdList for lists
	short idxBlkListDef;		// block list in definition dialog
	short idxBlkListInst;		// block list in instance dialog
	short idxEvtList;		// event list
	short idxInstList;		// instance list
					//--- Flags
	bool verified;			// true if verified since last change

	//--- functions
	void Initialize ();		// initialize member variables
	void InitializeManagement ();
					//--- Toggle dialogs:
	void ToggleTheButton (ItemVal theButton);
	void ShowEventDataDialog (TEvtDlgSelect which);
	void ShowInstDataDialog (ItemVal which);
	void ShowHideNotVerified ();
	void ShowHideModified ();
	void Enable14CFileName (bool enable);
					//--- Load data into dialogs:
	void LoadDlg_Simulation ();	// simulation setup dialog
	void LoadBlockLists ();		// Load the block lists
	void LoadDlg_BlockDef ();	// block definition dialog
	void UpdateInitSystem ();	// initial system
	void UpdateDlg_EventList ();	// event list
	void UpdateDlg_EventData ();	// event data
	void DisplayRangeEvent ();	// only for range events
	void DisplayCent4Event ();	// only for standard events
	void LoadDlg_BlockInst ();	// block instance dialog
	void UpdateDlg_InstList ();	// instance list
	void UpdateDlg_InstData ();	// instance data
					//--- Other events:
	void Evt_NewMgmtScheme ();	// "new mgmt." button
	void Evt_OpenMgmtScheme ();	// "open mgmt." button
	void Evt_ImportMgmtScheme ();	// "import mgmt." button
	void Evt_CopyFromLibrary ();	// "from library" button
	void Evt_SaveMgmtScheme ();	// "save mgmt." button
	void Evt_BrowseWthrFile ();	// "browse" for weather file button
	void Evt_AddNewBlock ();	// add new block (clears first)
	void Evt_CopyBlkToNew ();	// copy highlighted block to new
	void Evt_DeleteBlock ();	// delete block highlighted
	void Evt_AddNewEvent ();	// add new event (clears first)
	void Evt_DeleteEvent ();	// delete event highlighted
	void Evt_SaveEventData ();	// save event data displayed
	void Evt_EvtAddChoose ();	// button: additional info for event
	void Evt_AddNewInstance ();	// add new instance (clears)
	void Evt_CopyInstToNew ();	// copy highlighted instance to new
	void Evt_DeleteInstance ();	// delete instance highlighted
	void Evt_SaveInstanceData ();	// save instance data displayed
	void Evt_OutputFreqSel ();	// select output interval from list
	void Evt_BlkDescChange ();	// chg. & update lists for blk. desc.
	void Evt_FileNameBaseChange ();	// chg. & update file name base
	void Evt_InitSysCropSel ();	// button: init. crop select
	void Evt_InitSysTreeSel ();	// button: init. tree select
					//--- Radiobutton events
	void Evt_LabelTypeNone ();	// C labeling type - none
	void Evt_LabelType14C ();	// C labeling type - 14C
	void Evt_LabelType13C ();	// C labeling type - 13C
	void Evt_InitSysCrop ();	// init. system = crop
	void Evt_InitSysTree ();	// init. system = tree
	void Evt_InitSysBoth ();	// init. system = both
	void Evt_Microcosm ();		// simulate a microcosm
	void Evt_CO2Effect ();		// use CO2 effect
	void Evt_Browse14CFile ();	// button: "browse" for 14C data file
	void Evt_BrowseEroFile ();	// button: "browse" for erosion file
	void Evt_BrowseDepFile ();	// button: "browse" for deposition file
					//--- Clear dialog controls:
	void ClearDialogs ();		// Set all controls to default values.
	void ClearDlgBlkDefList ();	// Clear block list in def. dialog
	void ClearDlgEvtList ();	// Clear event list display
	void ClearDlgEvtData ();	// Clear event data display
	void ClearDlgBlkInstList ();	// Clear the block list in inst. dialog
	void ClearDlgInstList ();	// Clear instance list display
	void ClearDlgInstData ();	// Clear instance data display
					//--- Clear member variables:
	void ClearLists ();		// Clear list variables.
	void ClearBlockList ();		// Clear blkList member variable
	void ClearEventList ();		// Clear evtList member variable
	void ClearInstList ();		// Clear instList member variable
	void ClearManagement ();  	// Clear the management variables
					//--- Get Data from dialogs functions
	void GetDispSimInfo ();		// Get info from sim. info dialog
	void GetBlockDescrip ();	// Get block description
	void GetEventData (		// Get event data
	  TManagementEvent * const evt);
	void GetInstanceData (		// Get instance data
	  TManagementInst * const inst);
					//--- Verification functions
	bool ConfirmDelMgmt ();		// User to confirm delete mgmt. scheme.
	void ConfirmSaveEventData ();	// If event changed, ask user to save
	void ConfirmSaveInstData ();	// If inst. changed, ask user to save
	void ConfirmSaveMgmt ();	// If mgmt. changed, ask user to save
	void ConfirmVerifyMgmt ();	// If !verified, ask to verify
					//--- Misc. functions
	void ButtonDisplayBlkLst ();	// Show/hide buttons - block list
	void ButtonDisplayEvtLst ();	// Show/hide buttons - event list
	void ButtonDisplayInstLst ();	// Show/hide buttons - instance list
	TEventType SelectListOfEvents ();  // Select event from list
	bool SelectEventOption (   	// Select event option from list
	  TEventType eventType,		//   event
	  char const * & optionText,	//   event option string
	  char const * const
	  	initialOptionText = 0);	//   initial value
	void DisableWeatherFileControls ();
	void EnableWeatherFileControls ();
	short BuildBlockLIst ();	// Build a list of abbrev. block descs.
	void MakeBlkDescItemStr (	// Make string for block select. lists
	  char*& item, 			//   string (can be null)
	  char const* blkDesc);		//   block's description
					//--- File functions
	char* UserSelectFile (		// Select a file name:
	  char const* title,		//   dialog title
	  char const** filter,		//   file filter
	  const bool mustExist);	//   true if file must already exist
	bool FileExists (		// Check that specified file exists.
	  const TEH::TFileName* name,	//   name of the file
	  char const* desc);		//   description of file for user
	bool FileIsValid (		// Check for a valid file name.
	  const TEH::TFileName* name,	//   name of the file
	  char const* desc);		//   description of file for user
	void AddWorkPath (		// Prepends work path to file name.
	  TEH::TFileName* fileName);
};

#endif 	// INC_TMgmtDlg_h
