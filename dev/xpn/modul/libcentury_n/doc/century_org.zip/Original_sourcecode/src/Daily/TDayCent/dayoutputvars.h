#ifndef INC_dayoutputvars_h
#define INC_dayoutputvars_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  dayoutputvars.h
//
//	Description:
//	Classes for DayCent output variables.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jun98
// ----------------------------------------------------------------------------
//	History:
//      See Century/outputvars.h
//      May01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Created DayCent daily output variable classes
//        TDailyWaterTemp and TDailyTraceGas
//      Jun01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Added soil phosphorous and sulfur and net mineralization to
//        TDailyTraceGas output variables (10+10+3 new variables)
//      Jul01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Added DayCent daily output variable class TDailyCFluxStore
//      Aug01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Separted out daily output variable classes from
//        outputvar.h and outputvar.cpp into their own files
//        dayoutputvar.h and dayoutputvar.cpp.
//      Sep01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Added 5 new output variables to TDailyCFluxStore
//      Aug02   Melannie Hartman, melannie@nrel.colostate.edu
//      * Added TNPSflux, and TCO2flux
// ----------------------------------------------------------------------------
//	Classes:
//        TDailyWaterTemp
//        TDailyTraceGas
//        TDailyCFluxStore
//        TNPSflux
//        TCO2flux
// ----------------------------------------------------------------------------
//	Notes:
//
//	(1) Each output class has a set of floating point values with unique
//	names. A list of pointers to the variables is built upon construction
//	of the class to allow the set of variables to be accessed as an array
//	of floats for speed upon output.
//
//	(2) The order in which the pointers to the variables is assigned must
//	match the list of output variable names! The order is alphabetical (as
//	of the original ordering). Any changes to variable names, or addition
//	of new variables, will have to accommodate ordering, and consider past
//	vs. new ordering.
//
//	(3) With any additions/removals of variables, adjust the number of
//	variables in the total specified in the call to the constructor for
//	TCenturyOutputSet. Also, add/remove the variables from the member
//	functions for the class: Clear, AssignPointers.
//
//	(4) The values for "numFloats" member variable for each class should
//	match the dimemsion for the number of variables in the netCDF file,
//	"OutVarsDef.cdl".
// ----------------------------------------------------------------------------

#include "TCenturyOutputSet.h"
#include "centconsts.h"

//	------------------------------------------------------------
//	TDailyWaterTemp
//	Output variables - daily hydrology and soil temperature related variables
//      New Class for DayCent -mdh 5/16/01
class TDailyWaterTemp : public TCenturyOutputSet
{
  public:
    float
    	firstOne,			// dummy - always first variable!
        amtTrans[MAXLYR], // Net water transferred out of layers (cm H2O/day)
        anerb,          // Effect of anaerobic conditions on decomp
	defac,		// Decomposition factor (tfunc * wfunc)
	evap,		// Water evaporated from soil & vegetation (cm/day)
	irract,		// Actual amount of irrigation (cm H2O).
	pet,		// Daily potential evapotranspiration (cm).
	precip,		// Daily precipitation (cm).
	runoff,		// Daily runoff (cm/month)
        simDepth,	// Simulation layer depth (thickness) (cm).
	soilDepth,	// Soil profile depth
        snlq,		// Liquid water in snowpack (cm).
	snow,		// Snowpack water content (cm H2O).
	stemp,		// Average soil temperature (deg C).
        sTempMin[MAXLYR], // Minimum soil temperature by soil layer (deg C)
        sTempMax[MAXLYR], // Maximum soil temperature by soil layer (deg C)
	stream[8],	// Stream flow and leached amounts of C, N, P, S:
			//   [0] = flow (base flow + storm flow) (cm H2O).
			//   [1-3] = mineral leaching N, P, S (g/m2).
			//   [4-7] = organic leaching C, N, P, S (g/m2).
        sublim,         // Daily sublimation of snow (cm H2O)
        swc[MAXLYR],	// Soil water content by soil layer (cm H2O)
 			//    Last layer = drainage pool
        tave,		// Average air temperature (deg C).
        tfunc,          // Temperature effect on decomposition
	tran,		// Daily transpiration (cm).
        wfps[MAXLYR],   // Water filled pore space fraction (0.0 - 1.0)
        wfunc,          // Moisture effect on decomposition
   	lastOne;			// dummy - always last variable!
    // constuctor
    TDailyWaterTemp () : TCenturyOutputSet(75)
	{ Clear ();
	  firstOne = lastOne = memCheckValue;	// for memory overwrite checks:
    	  AssignPointers ();
	};
    // functions
    void Clear ();
    bool IsMemoryOK ()
    	{ return (firstOne == memCheckValue && lastOne ==  memCheckValue); }

  private:
    void AssignPointers ();	// initialize pointers to variablse
};


//	------------------------------------------------------------
//	TDailyTraceGas
//	Output variables - daily trace gas and nitrogen related variables
//      New Class for DayCent -mdh 5/16/01
class TDailyTraceGas : public TCenturyOutputSet
{
  public:
    float
    	firstOne,			// dummy - always first variable!
        ammonium[MAXLYR], // Soil ammonium concentration by layer (gN/m^2)
        CH4flux,          // Daily methane flux (gC/m^2)
        CO2flux,          // Daily Carbon Dioxide flux due to plant
                          //   and microbial respiration (gC/m^2)
        netMin[NUMELEM],  // Daily net mineralization of elements (gE/m^2)
        nitrate[MAXLYR],  // Soil nitrate concentration by soil layer (gN/m^2)
        N2flux,           // Daily nitrogen gas flux (gN/m^2)
        N2Oflux_dnit,     // Daily N2O flux due to denitrification (gN/m^2)
        N2Oflux_nit,      // Daily N2O flux due to nitrification (gN/m^2)
        NOflux,           // Daily NO flux (gN/m^2)
        phosphorus[MAXLYR], // Soil phosphorus concentration by layer (gP/m^2)
        sulfur[MAXLYR],     // Soil sulfur concentration by layer (gS/m^2)
   	lastOne;			// dummy - always last variable!
    // constuctor
    TDailyTraceGas () : TCenturyOutputSet (49)
	{ Clear ();
	  firstOne = lastOne = memCheckValue;	// for memory overwrite checks:
    	  AssignPointers ();
	};
    // functions
    void Clear ();
    bool IsMemoryOK ()
    	{ return (firstOne == memCheckValue && lastOne ==  memCheckValue); }

  private:
    void AssignPointers ();	// initialize pointers to variablse
};

//	------------------------------------------------------------
//	TDailyCFluxStore
//	Output variables - daily maintenance respiration fluxes
//      and C storage pools for maintenance respiration and C allocation
//      New Class for DayCent -mdh 7/6/01
class TDailyCFluxStore : public TCenturyOutputSet
{
  public:
    float
    	firstOne,		 // dummy - always first variable!
        cropProduction[2],       // crop NPP for shoots [0] and roots [1] (gC/m^2)
        treeProduction[5],       // forest NPP for all 5 forest parts (gC/m^2)
        mRespAnn[2],             // annual maintenance resp. flux, CRPSYS, FORSYS (gC/m^2)
        mRespStorageCrop[2],     // maintenance resp. crop storage pool, UNLABL, LABLD (gC/m^2)
        mRespStorageTree[2],     // maintenance resp. tree storage pool, UNLABL, LABLD (gC/m^2)
        mRespFlowToStore[2],     // maintenance resp. flow to storage pool, CRPSYS, FORSYS (gC/m^2/day)
        mRespFluxCrop[2],        // maintenance resp. crops (ABOVE, BELOW) (gC/m^2/day)
        mRespFluxTree[5],        // maintenance resp. trees (gC/m^2/day)
        cropCAllocStorage[2],    // storage pool for next year's crop greenup (gC/m^2)
        treeCAllocStorage[2],    // storage pool for next year's tree greenup (gC/m^2)
   	lastOne;		 // dummy - always last variable!
    // constuctor
    TDailyCFluxStore () : TCenturyOutputSet (26)
	{ Clear ();
	  firstOne = lastOne = memCheckValue;	// for memory overwrite checks:
    	  AssignPointers ();
	};
    // functions
    void Clear ();
    bool IsMemoryOK ()
    	{ return (firstOne == memCheckValue && lastOne ==  memCheckValue); }

  private:
    void AssignPointers ();	// initialize pointers to variablse
};

//	------------------------------------------------------------
//	TNPSflux
//	Output variables - arrays for daily Nitrogen, Phosphorus, and Sulphur fluxes
//	For all 1-D arrays, [0] = N, [1] = P, [2] = S.
//	For 2-D arrays, the 2nd dim. is described with the variable.
class TNPSflux : public TCenturyOutputSet
{
  public:
    float
    	firstOne,	                // dummy - always first variable!
	nfix,		// Daily symbiotic N fixation (g/m2/day).
	wdfxma,		// Daily N fixation in atmosphere (g/m2/day).
	wdfxms,		// Daily non-symbiotic soil N fixation (g/m2/day).
    			//--- Phosphorus
    			//--- Sulphur
    			//--- NPS arrays
	//egrain[3],	// Economic yield in grain + tubers (g/m2/day).
	//eprodc[3],	// Crop/Grass: Actual monthly uptake (g/m2/day).
	//eprodf[3],	// Forest: Actual monthly uptake (g/m2/day).
	//ermvst[3],	// Amount removed as straw during harvest (g/m2/day).
	fertot[3],	// Amount of fertilizer applied (g/m2/day).
	//gromin[3],	// Gross mineralization.
	metmnr[6],	// Net mineralization for metabolic litter;
			//   was [NUMLAYERS][NUMELEM];
			//   [0][] = aboveground, [1][] = belowground litter.
	s1mnr[6],	// Net mineralization for pools;
			//   was [NUMLAYERS][NUMELEM]:
			//   [0][] = surface microbe pool (g/m2),
			//   [1][] = active SOM pool (g/m2).
	s2mnr[3],	// Net mineralization for slow pool (g/m2).
	s3mnr[3],	// Net mineralization for passive pool (g/m2).
	strmnr[6],	// Net mineralization for structural litter; was [2][3];
			//   [0][] = aboveground, [1][] = belowground.
	w1mnr[3],	// Forest: Amount mineral. from dead fine branch (g/m2).
	w2mnr[3],	// Forest: Amount mineral. from dead large wood (g/m2).
	w3mnr[3],	// Forest: Amount mineral. from dead coarse root (g/m2).
    	lastOne;			// dummy - always last variable!
    // constuctor
    TNPSflux () : TCenturyOutputSet (39)
	{ Clear ();
	  firstOne = lastOne = memCheckValue;	// for memory overwrite checks:
    	  AssignPointers ();
	};
    // functions
    void Clear ();
    bool IsMemoryOK ()
    	{ return (firstOne == memCheckValue && lastOne ==  memCheckValue); }

  private:
    void AssignPointers ();	// initialize pointers to variablse
};

//	------------------------------------------------------------
//	TCO2flux
//	Output variables - daily CO2 fluxes
class TCO2flux : public TCenturyOutputSet
{
  public:
    float
    	firstOne,			// dummy - always first variable!
	mt1c2[ISOS],	// microbial CO2 respiration (gC/m2/day),
                        //   surface metabolic litter;
			//   [0] = unlabeled, [1] = labeled.
	mt2c2[ISOS],	// microbial CO2 respiration (gC/m2/day),
                        //   soil metabolic litter;
			//   [0] = unlabeled, [1] = labeled.
	s11c2[ISOS],	// microbial CO2 respiration (gC/m2/day),
                        //   surf. SOM1 to SOM2;
			//   [0] = unlabeled, [1] = labeled.
	s21c2[ISOS],	// microbial CO2 respiration (gC/m2/day),
                        //   soil SOM1 to 2 & 3;
			//   [0] = unlabeled, [1] = labeled.
	s2c2[ISOS],	// microbial CO2 respiration (gC/m2/day),
                        //   SOM2 to soil 1 & 3;
			//   [0] = unlabeled, [1] = labeled.
	s3c2[ISOS],	// microbial CO2 respiration (gC/m2/day),
                        //   SOM3 to soil SOM1;
			//   [0] = unlabeled, [1] = labeled.
	st1c2[ISOS],	// microbial CO2 respiration (gC/m2/day),
			//   surface structural litter into SOM1 and SOM2;
			//   [0] = unlabeled, [1] = labeled.
	st2c2[ISOS],	// microbial CO2 respiration (gC/m2/day),
			//   soil structural litter into SOM1 and SOM2;
			//   [0] = unlabeled, [1] = labeled.
        wd1c2[ISOS],       // microbial CO2 respiration (gC/m2/day),
                        //   dead fine branches
			//   [0] = unlabeled, [1] = labeled.
        wd2c2[ISOS],       // microbial CO2 respiration (gC/m2/day),
                        //   dead large wood
			//   [0] = unlabeled, [1] = labeled.
        wd3c2[ISOS],       // microbial CO2 respiration (gC/m2/day),
                        //   dead coarse roots
			//   [0] = unlabeled, [1] = labeled.
    	lastOne;			// dummy - always last variable!
    // constuctor
    TCO2flux () : TCenturyOutputSet (22)
	{ Clear ();
	  firstOne = lastOne = memCheckValue;	// for memory overwrite checks:
    	  AssignPointers ();
	};
    // functions
    void Clear ();
    bool IsMemoryOK ()
    	{ return (firstOne == memCheckValue && lastOne ==  memCheckValue); }

  private:
    void AssignPointers ();	// initialize pointers to variablse
};


#endif // INC_dayoutputvars_h
