// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TFlow.cpp
//	Class:	  TFlow
//
//	Description:
//	Class to perform the flows between the Century compartments.
//	This simulates a Euler's solution to difference equations.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jun98
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TFlow.h"
#include "TCentException.h"
#include <algorithm>
#include <sstream>
#include <cmath>
using namespace std;

//--- member constants

short const TFlow::initialSizeStack = 200;	// size of flow stack
float const TFlow::smallestAmount = 1.0e-8f;	// smallest flow allowed
float const TFlow::largestAmount = 1.0e8f;	// largest flow allowed

//--- functions

//	Schedule
//      Schedules a flow by storing the arguments in a stack which
//      will be accessed by the function 'flowup' which performs
//      the actual flow for all stack elements where 'when' is
//      less than or equal to time.
void TFlow::Schedule (
	float * const fromPool,		// from pool
	float * const toPool,		// to pool
	float const whenToFlow,		// time for flow to occur
	float const amount		// amount of flow
#ifdef FLOWSTACK_DEBUG
	,
	char const * const useFileName,		// __FILE__
	unsigned short useLineNumber		// __LINE__
#endif
	)
{
	// Is is a valid amount?
	float const chkVal = std::fabs (amount);	// get absolute value
	if ( chkVal < smallestAmount )			// No tiny fractions
		return;					// ...ignore it
	if ( chkVal > largestAmount )			// No huge flows
#ifdef FLOWSTACK_DEBUG
		FlowError (TCentException::CE_FLWHUG, whenToFlow,
				0, useFileName, useLineNumber);
#else
		FlowError (TCentException::CE_FLWHUG, whenToFlow);
#endif

#ifndef NDEBUG

	if ( fromPool == NULL )				// no "from"?
#ifdef FLOWSTACK_DEBUG
		FlowError (TCentException::CE_FLWNFP, whenToFlow,
				0, useFileName, useLineNumber);
#else
		FlowError (TCentException::CE_FLWNFP, whenToFlow);
#endif

	if ( toPool == NULL )				// no "to"?
#ifdef FLOWSTACK_DEBUG
		FlowError (TCentException::CE_FLWNTP, whenToFlow,
				0, useFileName, useLineNumber);
#else
		FlowError (TCentException::CE_FLWNTP, whenToFlow);
#endif

	if ( fromPool == toPool )			// "from" == "to"?
#ifdef FLOWSTACK_DEBUG
		FlowError (TCentException::CE_FLWTFE, whenToFlow,
				0, useFileName, useLineNumber);
#else
		FlowError (TCentException::CE_FLWTFE, whenToFlow);
#endif

#endif // NDEBUG

	// Store the arguments in the stack
	TStackElement newFlow (fromPool, toPool, whenToFlow, amount
#ifdef FLOWSTACK_DEBUG
		, useFileName, useLineNumber
#endif
		);
	TStack::size_type const previousSize = stack.size();	// save size
	stack.push_back (newFlow);				// add to stack
	bool failed = (previousSize != stack.size() - 1);	// success?
	if ( failed )						// Failed?
#ifdef FLOWSTACK_DEBUG
		FlowError (TCentException::CE_FLWFAS, whenToFlow,
				0, useFileName, useLineNumber);
#else
		FlowError (TCentException::CE_FLWFAS, whenToFlow);
#endif
}

//	FlowUp
//	Perform the flows for all stack elements whose 'when'
//	value is less than or equal to time.
void TFlow::FlowUp (
	float const time)	// at simulation time
{
    if (stack.size() == 0)			// anything to do?
	return;					// ...no

    try
    {
	TStack::iterator i = stack.begin ();
	while ( i != stack.end() && time >= i->when )	// Do the flows:
	{
	    // Cast the amounts to double to avoid insensitivity to
	    // amounts just beyond float precision.
	    double const amount = i->amount;
	    if ( amount == 0.0 )
	    {
#ifdef FLOWSTACK_DEBUG
		FlowError ( TCentException::CE_FLWERR, time, "amount = zero",
			    __FILE__, __LINE__ );
#else
		FlowError ( TCentException::CE_FLWERR, time, "amount = zero" );
#endif
	    }
	    float & from = *(i->from);
	    float & to   = *(i->to);
	    from = static_cast<float>(from - amount);	// remove from source
	    to = static_cast<float>(to + amount);	// add to sink
	    ++i;
	}
	if ( i != stack.begin() )
		stack.erase ( stack.begin(), i );
    }
    catch (std::exception const & e)	// other exceptions (elaborate!)
    {
	FlowError ( TCentException::CE_FLWERR, time, e.what() );
    }
    catch (char const * const aMsg)
    {
    	FlowError ( TCentException::CE_FLWERR, time, aMsg );
    }
    catch (std::string const & aMsg)
    {
    	FlowError ( TCentException::CE_FLWERR, time, aMsg.c_str() );
    }
    catch (...)
    {
    	FlowError (TCentException::CE_FLWERR, time);
    }
}

//	FlowError
void TFlow::FlowError (
	short const error_num, 		// error number
	float const when,		// simulation time of error
	char const * const msg		// optional message
#ifdef FLOWSTACK_DEBUG
	,
	char const * const useFileName,		// __FILE__
	unsigned short useLineNumber		// __LINE__
#endif
	)
{
	// convert time to string
	ostringstream os;
	if ( msg && *msg )
		os << "Error: " << msg << endl;
	os << "Error occurred at simulation time = " << when
#ifdef FLOWSTACK_DEBUG
	   << '\n'
	   << "File: " << useFileName
	   << "   Line: " << useLineNumber
#endif
	   ;

	ThrowCentException ( static_cast<TCentException::TCEIndex>(error_num),
				os.str().c_str() );
}

//--- end of TFlow.cpp ---
