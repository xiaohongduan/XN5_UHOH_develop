#ifndef INC_TNcFile_h
#define INC_TNcFile_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TNcFile.h
//	Class:	  TNcFile
//
//	Description:
//	Polymorphic Base Class for managing netCDF files.
//	Always derive a class from this and implement the member functions
//	Read and Write for your specific data.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Dec97
//	History:
//	Feb99	Tom Hilinski
//	* Added member variable for netCDF file types in ncftypes.h.
//	* Added functions to set, get, check the file type.
//	Mar99	Tom Hilinski
//	* Added member variable for netCDF file versions.
//	* Added functions to set, get, check the file version.
//	May99	Tom Hilinski
//	* Moved template AddOneAtt from header to .cpp file.
//	* Added member function CheckExtension.
//	* Modified CreateFrom to use CheckExtension.
//	* Added error string ivCFFileName (invalid CreateFrom file name).
//	* Added misc. error checks and assertions.
//	* Fixed problems in CreateFrom().
//	Jan00	Tom Hilinski
//	* Operator= : added check for assignment to self, and changed to return
//	  a reference to this rather than a copy of this.
//	* Made the destructor virtual as it should be with base classes.
//	May00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Upgraded error handling in the constructor.
//	* Added ReplaceFrom function.
//	Jun01	Tom Hilinski
//	* A bit of cleaning up and const-correctness.
//	Sep03	Tom Hilinski
//	* Cleaned the logic of part of OpenNcFile and SetNcErrStr.
//	* More cleaning up and const-correctness.
// ----------------------------------------------------------------------------
//	Notes:
//	This class is for managing the structure of netCDF files, not the
//	data contained therein. Functions must be provided by the derived
//	class for reading and writing the entire data set at once.
//
//	To access individual data elements, use the netCDF functions
//	through the variable "ncFile" and the class interfaces for netCDF.
//	Derive a class from TNcFile and override the Read() and Write()
//	functions to handle the I/O specific to the class.
// ----------------------------------------------------------------------------

#include "netcdfcpp.h"		// netCDF C++ interface
#include "ncftypes.h"		// recognized netcdf file types
#include "TFileName.h"

//	-----------------------------------------------------------------------
//	TNcFile
//	Class for managing netCDF files.
class TNcFile
{
  public:
	//--- local type definitions
	struct TNcVar	// a netCDF variable
	{
		NcVar *v;		// variable pointer
		short numAtt, numDim;	// no. of attributes, dimensions
		NcDim **d;		// list of dimensions IN ORDER!
		NcAtt **a;		// list of attributes
	};

	//--- constructors and destructor
	TNcFile (
	  TEH::TFileName const & file,		// netCDF file name
	  TNcFileType const reqFileType =	// Century netCDF file type
			NCFT_Unknown,
	  short const fileVersion = 1);		// version number (highest)
	virtual ~TNcFile () = 0;
	TNcFile (
	  TNcFile const & object);

	//--- operator overloads
	TNcFile& operator = (TNcFile const & object);
	bool operator == (TNcFile const & object) const;
	bool operator != (TNcFile const & object) const
	  { return !(*this == object); }

	//--- functions: File Access
	bool OpenNcFile (		// Open the netCDF file ncFile
	  const NcFile::FileMode mode);
	void CloseNcFile ();		// Close the netCDF file.
	bool CreateFrom (		// Creates netCDF file (no data)
	  TEH::TFileName const & file);	//   from an existing file.
	bool CreateFrom (
	  char const * const file);
	// Derived classes implement the following functions:
	//bool Read (TMyClass & sp);	// Reads entire contents
	//bool Write (TMyClass & sp);	// Write (replace) contents

	//--- functions: Queries
	TEH::TFileName const & GetFileName () const
	  { return ncFileName; }
	bool IsValid ();		// True if valid file
	bool IsOpen () const		// True if netCDF file is open
	  { return isOpen; }
	bool IsModified () const	// True if file is modified
	  { return modified; }
	bool FileTypeMatches (		// Check file for matching type
	  const TNcFileType newType);	// return true if type is OK
	TNcFileType GetFileType () const	// Return netCDF file type
	  { return ncFileType; }
	bool FileVersionValid (		// Check version >= file ver.
	  short const fileVersion);	// return true if check ok
	short GetVersion () const	// returns version number specified
	  { return version; }
	short GetFileVersion () const	// returns version number from file
	  { return versionFromFile; }

	//--- functions: Error handling
	bool IsNcErr () const		// Returns true if netCDF error
	  { return ncErrFlag; }
	char const* GetNcErrStr () const // Gets the netCDF error string
	  { return ncErrStr; }
	int GetNcErrCode () const	// Gets the netCDF error value
	  { if (ncErr)
	    return ncErr->get_err();
	    else return 0;
	  }

	//--- functions: Misc.
	void Clear ();			// "Clear" data members

  protected:
	//--- parameters
	const TNcFileType ncFileType;	// netCDF file type
	short const version;		// highest version number of file

	//--- constants
	static const char
		* const mwhoAttrName,	// last modified by who attribute name
		* const mwhenAttrName,	// last modified when attribute name
		* const ftAttrName,	// file type attribute name
		* const fvAttrName;	// file version attribute name

	//--- data
	TEH::TFileName ncFileName;	// netCDF file name
	NcFile* ncFile;			// Pointer to the netCDF file instance.

	//--- data
	short versionFromFile;		// Version no. read from file
	short numVar, numAtt, numDim;	// No. of variables, attributes, dimen.
	TNcVar* v;			// Pointers to variables
	NcAtt** a;			// Pointers to global attributes
	NcDim** d;			// Pointers to dimensions
	bool isOpen;			// True if the netCDF file is open
	bool modified;			// True if data changed
	NcError *ncErr;			// netCDF error handler class
	const char *ncErrStr;		// Error string - netCDF
	bool ncErrFlag;			// True if a netCDF error was given

	//--- functions for accessing existing netCDF files.
	short GetDims (				// Gets the dimemsions
	  NcFile const * const fromFile);
	short GetVars (				// Gets the variables
	  NcFile const * const fromFile);
	short GetAtts (				// Gets the global attributes
	  NcFile const * const fromFile);
	bool AddDims ();			// Adds the dimemsions
	bool AddVars ();			// Adds the variables
	bool AddAtts ();			// Adds the global attributes
	bool SetNcErrStr ();			// retrieves netCDF error str.
	void CheckExtension ();			// sets extension to "nc".

  private:
	//--- data
	static char const
		* const badFTMsg,		// bad file type message
		* const ivCFFileName,		// invalid "create from" name
		* const badFVMsg,		// bad file version message
		* const fileNFMsg,		// "file not found" message
		* const fileInvMsg;		// "file invalid" message

	//--- functions
	void Initialize ();			// initialize members
	void Copy (const TNcFile &fromObj);	// copy to this
};

#endif // INC_TNcFile_h
