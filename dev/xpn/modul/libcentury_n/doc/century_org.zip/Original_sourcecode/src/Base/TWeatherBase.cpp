// ----------------------------------------------------------------------------
//	Copyright (c) 2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TWeatherBase.cpp
//	Class:	  TWeatherBase
//
//	Description:
//	Base class for the weather (precip. & temp.) source.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Sep 2001
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TWeatherBase.h"
#include "timetypes.h"
#include "AssertEx.h"
#include <cmath>

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

float const TWeatherBase::missingValue = -99.99f;
short const TWeatherBase::mpy = (short)12;
float const TWeatherBase::minMonthlyPET = 0.5f;

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	SetReferenceValues
//	Save reference values and statistics from site parameters.
void TWeatherBase::SetReferenceValues (
	float const* usePrecip, 	// mean precip.
   	float const* useStdDev, 	// mean precip: std. dev.
    	float const* useSkewness, 	// mean precip: skewness
	float const* useMintemp,	// min. mean temp. at 2 m
	float const* useMaxTemp)	// max. mean temp. at 2 m
{
	if ( usePrecip )
		CopyArray (usePrecip, precipSP, mpy);
	if ( useStdDev )
		CopyArray (useStdDev, precipStdDevSP, mpy);
	if ( useSkewness )
		CopyArray (useSkewness, precipSkewSP, mpy);
	if ( useMintemp )
		CopyArray (useMintemp, minTempSP, mpy);
	if ( useMaxTemp )
		CopyArray (useMaxTemp, maxTempSP, mpy);
}

//	MonthlyPET
//	Returns the Potential Evapotranspiration for month
float TWeatherBase::MonthlyPET (
	short const month,	// month
    	float const latitude, 	// site latitude
    	float const fwloss)	// PET loss factor (from fixed.fwloss[3])
{
	float const elev = 0.0f; // ALWAYS ZERO! Should this be a parameter?

	//temperature range; min. temp. allowed = -10.0
	float const annualMeanTempRange =
		std::fabs (
		  maxAnnualMeanTemp - std::max (minAnnualMeanTemp, -10.0f) );

	// Temperature range calculation
	short const i = month - 1;				// array index
	float const annualTempRange =	// temp range adjusting for min. of 10.0
			maxTempCY[i] - std::max (-10.0f, minTempCY[i]);
	float const temp = annualTempRange * 0.5f + minTempCY[i];
	float const tempWithElevEffect = temp + elev * 0.006f;
	float const td = elev * 0.0023f + temp * 0.37f +
			annualTempRange * 0.53f +
    			annualMeanTempRange * 0.35f - 10.9f;
	float const e = (tempWithElevEffect * 700.0f /
			(100.0f - std::fabs(latitude)) + td * 15.0f) /
			(80.0f - temp);
	// FWLOSS(4) is a modifier for PET loss. vek may90
	return std::max (e * 3.0f, minMonthlyPET) * fwloss;
}

//	StochasticPrecip
//	Generate stochastic precipitation for the specified month.
float TWeatherBase::StochasticPrecip (
	short const month)	// month (0-11)
{
	// If skewness value is 0.0, select precipitation values
	// from normal distribution.
	// Else, use skewness value to generate precip values.
	float retVal;
	if (precipSkewSP[month] == 0.0f)
	  retVal = std::max (0.0f,
			   ::anorm (precipSP[month], precipStdDevSP[month]));
	else
	  retVal = std::max (0.0f,
			   ::sknorm (precipSP[month], precipStdDevSP[month],
					precipSkewSP[month]) );
	return retVal;
}

//	StochasticPrecip
//	Generate stochastic precipitation for the next year.
void TWeatherBase::StochasticPrecip (
	float* precip)		// destination array for precipitation
{
	for ( short m = 0; m < mpy; ++m, ++precip )
		*precip = StochasticPrecip (m);
}

//	SynchronizeYear
//	match data with simulation time.
void TWeatherBase::SynchronizeYear (
	  ::TYear simYear)			// simulation year
{
	Assert ("TWeatherBase::SynchronizeYear not implemented" == 0);
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	Copy
// 	copy to this
void TWeatherBase::Copy (
	TWeatherBase const & object)
{
	if ( &object )
	{
		year = object.year;
		sourceData = object.sourceData;
		//--- monthly values for current year:
		CopyArray ( object.precipCY, precipCY, mpy);
		CopyArray ( object.minTempCY, minTempCY, mpy);
		CopyArray ( object.maxTempCY, maxTempCY, mpy);
		//--- monthly site parameter values:
		CopyArray ( object.precipSP, precipSP, mpy);
		CopyArray ( object.precipStdDevSP, precipStdDevSP, mpy);
		CopyArray ( object.precipSkewSP, precipSkewSP, mpy);
		CopyArray ( object.minTempSP, minTempSP, mpy);
		CopyArray ( object.maxTempSP, maxTempSP, mpy);
		//--- annual values
		meanAnnualTemp = object.meanAnnualTemp;
		meanAnnualPrecip = object.meanAnnualPrecip;
		maxAnnualMeanTemp = object.maxAnnualMeanTemp;
		minAnnualMeanTemp = object.minAnnualMeanTemp;
		//--- file access
		fileName = object.fileName;
		// do not copy the stream
	}
}

//	CopyArray
//	Copy the specified number of elements from one array to another.
void  TWeatherBase::CopyArray (
	float const* from,		//   source array
	float* to,			//   destination array
	short const count)		//   number to copy
{
	for ( short i = 0; i < count; ++i, ++from, ++to )
		*to = *from;
}

//	ClearData
//	Zero the data arrays.
void TWeatherBase::ClearData ()
{
	float		// ptrs to arrays
	    *c1 = precipCY, *c2 = maxTempCY, *c3 = minTempCY,
	    *s1 = precipSP, *s2 = precipStdDevSP, *s3 = precipSkewSP,
	    *s4 = minTempSP, *s5 = maxTempSP;
	for ( short i = 0; i < mpy; ++i )
	{
		//--- active weather
    	    	*(c1++) = *(c2++) = *(c3++) = 0.0f;
   	    	//--- from site file:
		*(s1++) = *(s2++) = *(s3++) = *(s4++) = *(s5++) = 0.0f;
	}
}

//	AnnualSummaryCalcs
//	Calculates summary variables for the year.
//	Assumes that missing values are NOT present in the data.
void TWeatherBase::AnnualSummaryCalcs ()
{
	register float
		mat = 0.0f, 		// mean annual temp.
		map = 0.0f, 		// mean annual precip.
		avgTemp,		// average temperature
		minTemp = 999.0f,	// minimum temp
		maxTemp = -999.0f;	// maximum temp

	for ( short i = 0; i < mpy; i++ )
	{
		map += precipCY[i];
		avgTemp = ( minTempCY[i] + maxTempCY[i] ) * 0.5f;
		mat += avgTemp;
		minTemp = std::min ( minTemp, avgTemp );
		maxTemp = std::max ( maxTemp, avgTemp );
	}
	meanAnnualPrecip = map;
	meanAnnualTemp =  mat / 12.0f;
	minAnnualMeanTemp = minTemp;
	maxAnnualMeanTemp = maxTemp;
}

//	MeanAnnualValue
//	Calc a mean value for the annual data, but does not include
//	missing values in the mean.
float TWeatherBase::MeanAnnualValue (
	float const* p				// data array
	) const
{
	register float sum = 0.0f;		// sum of values
	register short count = 0;		// count of values used
	for ( short i = 0; i < mpy; ++i, ++p )
		if ( *p != missingValue )
		{
			sum += *p;
			++count;
		}
	if ( count > 0.0f )
		return sum / (float)count;
	else
		return 0.0f;
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Initialize
// 	initialize members
void TWeatherBase::Initialize ()
{
	year = 0;
	sourceData = WS_Unknown;
	ClearData ();
	meanAnnualTemp = meanAnnualPrecip =
		maxAnnualMeanTemp = minAnnualMeanTemp = 0.0f;
	fileName.clear ();
}

//--- end of definitions for TWeatherBase ---
