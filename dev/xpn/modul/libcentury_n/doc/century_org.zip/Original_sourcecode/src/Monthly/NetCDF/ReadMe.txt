File:	Century/version5/src/NetCDF/ReadMe.txt

Century and Century Model Interface
NetCDF Files


Contents
--------
File Types
File Names
Common Global Attributes
Revision History


File Types
----------

*.cdl	netCDF "common data form" source files (text).
*.nc	netCDF binary files; built with the following command:
		ncgen -b <filename>.cdl

File Names
----------

BlkDef
	Block Library Management Data; block definitions.

BlkHeader
	Block Library Management Data; block headers.

ManageDef
	Management Scheme: block definitions.

ManageInst
	Management Scheme: block instances.

ManageScheme
	Management Scheme: simulation data and block headers.

OutVarsDef
	Output variables' names and definitions.

SiteParam
	Site parameter values.

SiteParamDef
	Site parameter names and definitions.

Weather
	Weather Data (currently unused).


Common Global Attributes
------------------------
title
	Descriptive title of the file.
	Important! The value of this attribute should NEVER be changed!

LastModifiedWho
	Name of user who last modified this file.

LastModifiedWhen
	Date and time this file was last modified.

LastModifiedHow
	Software or process which was used to modify this file.

FileType
	Tag indicating the type of Century/CMI information contained
	in this file. Tags are unique relative to the file's content.
	Important! The value of this attribute should NEVER be changed!

	tag  description
	---- ----------------------------------------------------
	0 =  Unknown (should never be used).
	1 =  "ManageScheme"
	2 =  "ManageDef"
	3 =  "ManageInst"
	4 =  "BlkHeader"
	5 =  "BlkDef"
	6 =  "SiteParamDef"
	7 =  "SiteParam"
	8 =  "OutVarsDef"
	9 =  "Weather"
	10 = 14C data (currently not used)
	11 = Century parameters: crop (currently not used)
	12 = Century parameters: cult (currently not used)
	13 = Century parameters: fert (currently not used)
	14 = Century parameters: fire (currently not used)
	15 = Century parameters: fix  (currently not used)
	16 = Century parameters: graz (currently not used)
	17 = Century parameters: harv (currently not used)
	18 = Century parameters: irri (currently not used)
	19 = Century parameters: omad (currently not used)
	20 = Century parameters: tree (currently not used)
	21 = Century parameters: trem (currently not used)
	22-29 = Reserved for future use for parameter files.
	30 = Century output file.
	31 = Century erosion output data file.
	32-49 = Reserved for future use for output files.
	50-89 = Reserved for future use.
	90 = Century error text (currently not used)
	91 = Century warnings text (currently not used)
	92 = CMI error text (currently not used)
	93 = CMI warnings text (currently not used)

Version
	Integer indicating the version number of this file. This number
	should be incremented whenever the structure of the netCDF file
	is modified. In the Century/CMI code, this value can be
	examined in order to determine how to read in the data.

	For example, if a parameter is added to the site file, then
	the version number is incremented. In the source code function
	TNcSiteParameters::Read, an "if" block check on this value
	determines where in the array of site parameter values an
	adjustment is to made as to where values are stored.



Revision History
----------------
18Sep98	First version. T.E. Hilinski
06Oct98	Added global attribute "Version" description.


--- end of document ---
