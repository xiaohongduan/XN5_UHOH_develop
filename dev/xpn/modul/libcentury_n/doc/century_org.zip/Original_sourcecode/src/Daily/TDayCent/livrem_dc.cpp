// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  livrem.cpp
//	Class:	  TDayCent
//	Function: ForestLiveBiomassRem
//
//	Description:
//	Removal of live biomass due to cutting or fire in a forest.
// ----------------------------------------------------------------------------
//	History:
//      See Century/livrem.cpp
//	09Jul01 Melannie Hartman, melannie@nrel.colostate.edu
//	* Changed this function from TCentury member to TDayCent member
//      * Added flow of C out of maintenance respiration storage pool
//        when large wood is removed.
//	05Sep01 Melannie Hartman, melannie@nrel.colostate.edu
//      * Flow of C out of maintenance respiration storage pool
//        is proportional to the fraction of total live wood removed,
//        including coarse roots, fine branches, and large wood.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//      Notes:
//      Is removal of negative mRespStorage handled correctly? -mdh 9/28/01
// ----------------------------------------------------------------------------

#include "TDayCent.h"

void TDayCent::ForestLiveBiomassRem (
	float *accum)	// array [ISOS]: cumulative C
{
    float liveWoodCremoved = 0.0f;	// sum of live wood removed

    if (forestC.rleavc > 0.0f)			// Remove live LEAVES
    {
	// remf(ipool) = removal fraction
	// ipool indicates which state variable
	float const closs = forrem.remf[0] * forestC.rleavc;
	forestC.tcrem += closs;
	ScheduleCFlow ( st->time, closs,
		forestC.rlvcis[LABELD] / forestC.rleavc, 1.0f,
		&forestC.rlvcis[UNLABL], &soilC.csrsnk[UNLABL],
		&forestC.rlvcis[LABELD], &soilC.csrsnk[LABELD],
		accum);
	for (short e = 0; e < site.nelem; ++e)
	{
	    float const eloss = closs * nps.rleave[e] / forestC.rleavc;
	    nps.terem[e] += eloss;
	    flows->Schedule (&nps.rleave[e], &nps.esrsnk[e], st->time, eloss);
	}
    }
    if (forestC.fbrchc > 0.0f)			// Remove live FINE BRANCHES
    {
	float const closs = forrem.remf[1] * forestC.fbrchc;
	forestC.tcrem += closs;
        liveWoodCremoved += closs;
	ScheduleCFlow ( st->time, closs,
		forestC.fbrcis[LABELD] / forestC.fbrchc, 1.0f,
		&forestC.fbrcis[UNLABL], &soilC.csrsnk[UNLABL],
		&forestC.fbrcis[LABELD], &soilC.csrsnk[LABELD],
		accum);
	for (short e = 0; e < site.nelem; ++e)
	{
	    float const eloss = closs * nps.fbrche[e] / forestC.fbrchc;
	    nps.terem[e] += eloss;
	    flows->Schedule (&nps.fbrche[e], &nps.esrsnk[e], st->time, eloss);
	}
    }
    if (forestC.rlwodc > 0.0f)			// Remove live LARGE WOOD
    {
	float const closs = forrem.remf[2] * forestC.rlwodc;
	forestC.tcrem += closs;
        liveWoodCremoved += closs;
	ScheduleCFlow ( st->time, closs,
		forestC.rlwcis[LABELD] / forestC.rlwodc, 1.0f,
		&forestC.rlwcis[UNLABL], &soilC.csrsnk[UNLABL],
		&forestC.rlwcis[LABELD], &soilC.csrsnk[LABELD],
		accum);
	for (short e = 0; e < site.nelem; ++e)
	{
	    float const eloss = closs * nps.rlwode[e] / forestC.rlwodc;
	    nps.terem[e] += eloss;
	    flows->Schedule (&nps.rlwode[e], &nps.esrsnk[e], st->time, eloss);
	}

        // Remove C from maintenace respiration storage pool based on
        // fraction of total live wood removed. -mdh 7/9/01

	float const liveWoodCtotal =
			forestC.fbrchc + forestC.rlwodc + forestC.crootc;
	float const liveWoodCFrac = liveWoodCremoved / liveWoodCtotal;
	if ( gpp.mRespStorageTree[UNLABL] < 0.0f ||
    	     gpp.mRespStorageTree[LABELD] < 0.0f )
        {
            // ScheduleCFlow cannot handle negative mRespStorage.
            // Removing a negative amount
	    float mRespStorageLoss =
	    		liveWoodCFrac * gpp.mRespStorageTree[UNLABL];
	    flows->Schedule (&gpp.mRespStorageTree[UNLABL],
				&soilC.csrsnk[UNLABL],
				st->time, mRespStorageLoss);
	    mRespStorageLoss = liveWoodCFrac * gpp.mRespStorageTree[LABELD];
	    flows->Schedule (&gpp.mRespStorageTree[LABELD],
				&soilC.csrsnk[LABELD],
				st->time, mRespStorageLoss);
        }
        else
        {
	    float const mRespStorage =
		(gpp.mRespStorageTree[UNLABL] + gpp.mRespStorageTree[LABELD]);
	    float const mRespStorageLoss = liveWoodCFrac * mRespStorage;
	    ScheduleCFlow ( st->time, mRespStorageLoss,
	    		gpp.mRespStorageTree[LABELD] / mRespStorage, 1.0f,
			&gpp.mRespStorageTree[UNLABL], &soilC.csrsnk[UNLABL],
			&gpp.mRespStorageTree[LABELD], &soilC.csrsnk[LABELD],
			accum);
        }

	// Remove from STORAGE pool based on fraction of large wood removed.
	for (short e = 0; e < site.nelem; ++e)
	{
	    float const eloss = std::max (forrem.remf[2] * nps.forstg[e], 0.0f);
	    flows->Schedule (&nps.forstg[e], &nps.esrsnk[e], st->time, eloss);
	}
    }
}

//--- end of file ---

