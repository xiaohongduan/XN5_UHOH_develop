// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  killrt.cpp
//	Class:	  TCenturyBase
//	Function: KillRoots
//
//	Description:
//	Death of roots due to cutting or fire in a forest.
// ----------------------------------------------------------------------------
//	History:
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::KillRoots (
	float *accum)		// array [ISOS]: Cumulative C
{
    float const minimumPoolAmount = 0.001f;

    if ( forestC.frootc > minimumPoolAmount )		// Death of FINE ROOTS
    {
	float recres[NUMELEM];	//
	float const frd = forestC.frootc * forrem.fd[0];
	float const recip = 1.0 / forestC.frootc;	// optimize division
	for (short element = 0; element < site.nelem; ++element)
		recres[element] = nps.froote[element] * recip;
	float const frc14 = forestC.frtcis[LABELD]  * recip;
	PartitionResidue (frd, recres, SOIL, forestC.frtcis, nps.froote,
			  parfs.wdlig[FROOT], frc14);
    }
    if ( forestC.crootc > minimumPoolAmount )		// Death of COARSE ROOTS
    {
	float const crd = forestC.crootc * forrem.fd[1];
	float const recip = crd / forestC.crootc;	// optimize division
	for (short element = 0; element < site.nelem; ++element)
	{
		float const dethe = nps.croote[element] * recip;
		flows->Schedule (&nps.croote[element], &nps.wood3e[element],
				st->time, dethe);
	}
	ScheduleCFlow ( st->time, crd,
		forestC.crtcis[LABELD] / forestC.crootc, 1.0f,
		&forestC.crtcis[UNLABL], &forestC.wd3cis[UNLABL],
		&forestC.crtcis[LABELD], &forestC.wd3cis[LABELD],
		accum);
    }
}

//--- end of file killrt.cpp ---
