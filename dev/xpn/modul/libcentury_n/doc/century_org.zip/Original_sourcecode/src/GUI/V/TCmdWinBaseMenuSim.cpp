// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TCmdWinBaseMenuSim.cpp
//	Class:	  TCmdWinBase
//	Function: DoMenuEvent_Simulation
//
//	Description:
//	Base class for the main client window + common menu.
//	Processes selection events from the Management Drop-Down Menu
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Jan98
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TCmdWinBase.h"
#include "SiteEditorDlg.h"
#include "TMgmtEditorDlg.h"
#include "TOutputSelectDlg.h"
#include "SiteEditorDataSrcMCFile.h"
#include "externals.h"
#include <v/vreply.h>
#include <v/vynreply.h>
using namespace std;

//	DoMenuEvent_Simulation
//	Process events from the main menu bar's "Simulation" drop-down menu.
void TCmdWinBase::DoMenuEvent_Simulation (ItemVal itemId)
{
	char *str = 0;

	switch (itemId)
	{
	  case M_Sim_Clear:
		str = "Clear all simulation configuration data";
		ActionMsg (str);
		break;

	  case M_Sim_Site:
	  {
		str = "Editing site parameters.";
		HistText (str);
		ActionMsg (str);

		// get paths
		std::string const sitesPathStr =
			::userPref.GetSitesPath().GetFullPath();
		std::string const workPathStr =
			::userPref.GetWorkPath().GetFullPath();
		std::string const & templatesPath =
			::defPaths->GetPath (CenturyPaths::Templates);
		std::string const & textDataPath =
			::defPaths->GetPath (CenturyPaths::TextData);

		// create a data source object holding the site parameters
		typedef SiteEditorDlg<TMCSiteParameters, TMCSiteParamInfo>
			MyEditor;
		MyEditor::TSiteDataSrcPtr siteDataSrc;

		if ( !::centuryConfig->HaveSite() )
		{
		    // parameters info object
		    TSiteParamInfoBase::TInfoPtr infoPtr (
			new TMCSiteParamInfo ( textDataPath ) );
		    // site parameters object
		   TCenturyConfig::TSitePtr zeroedSiteParamPtr (
			new TMCSiteParameters (
				templatesPath, workPathStr, infoPtr ) );
		    ::centuryConfig->UseSite (zeroedSiteParamPtr);
		}

		// data source object
		siteDataSrc.reset (
		    new SiteEditorDataSrcMCFile (
			app,							// vApp * const
			::centuryConfig->GetSite(),				// TSiteParametersBase::TSitePtr
			::centuryConfig->GetSite()->GetSiteParamInfo() ) );	// TMCSiteParamInfo::TInfoPtr
		if ( siteDataSrc->HaveError() )
			throw siteDataSrc->GetErrorMessage();

		// display editor
		std::auto_ptr<MyEditor> dlg (
		    new MyEditor (
			app,					// parent
			siteDataSrc,				// params
			siteDataSrc->Get()->GetSiteParamInfo(),
			::helpPath,				// help
			::defPaths->GetPath (CenturyPaths::SiteLib),
			sitesPathStr,
			templatesPath,
			workPathStr,
			::userPref.GetName() ) );
		Assert ( !(siteDataSrc->IsEmpty()) );
		::centuryConfig->UseSite ( siteDataSrc->Get() );	// save
		Assert ( !(siteDataSrc->IsEmpty()) );

		HistText ("Finished.\n");
		break;
	  }

	  case M_Sim_Mgmt:
	  {
	  	// Display status
		str = "Editing site management.";
		HistText (str);
		ActionMsg (str);

		// Setup and display the dialog
		std::string const mgmtPathStr =
			::userPref.GetMgmtPath().GetFullPath();
		std::string const workPathStr =
			::userPref.GetWorkPath().GetFullPath();
		std::string const & templatesPath =
			::defPaths->GetPath (CenturyPaths::Templates);

		std::auto_ptr<TMgmtEditorDlg> dlg (
		    new TMgmtEditorDlg (
			dynamic_cast<vApp * const>(app),
			::centuryConfig->GetManagement(),
			::helpPath,
			::defPaths->GetPath (CenturyPaths::MgmtLib),
			mgmtPathStr,
			templatesPath,
			workPathStr,
			*::centuryConfig->GetParametersDBList() ) );
		// Cleanup
		HistText ("Finished.\n");
		break;
	  }

	  case M_Sim_MgmtSum:
		myApp.Display_MgmtSummary (true);
		break;

	  case M_Sim_WthrEdit:
		str = "Editing weather data";
		ActionMsg (str);
		break;

	  case M_Sim_C14Edit:
		str = "Editing 14C data";
		ActionMsg (str);
		break;

	  case M_Sim_ParEdit:
		str = "Editing model parameters";
		ActionMsg (str);
		break;

	  case M_Sim_ResFile:
	  {
		str = "Selecting the restart files";
		ActionMsg (str);
		break;
	  }

	  case M_Sim_OutFile:
	  {
		str = "Selecting the output file type.";
		HistText (str);
		ActionMsg (str);

		// display a dialog of output file choices and ask user
		std::string outputFileName;
		TOutputBase::TOutputType outputType = TOutputBase::Type_CSV;
		if ( ::centuryConfig->HaveOutput() )
		{
		    outputType = ::centuryConfig->GetOutput()->GetOutputType();
		    TCentOutFileBase * const outputPtr =
			dynamic_cast<TCentOutFileBase * const>(
			    ::centuryConfig->GetOutput().get() );
		    Assert (outputPtr != 0);
		    outputFileName = outputPtr->GetFileName();
		}
		std::auto_ptr<TOutputSelectDlg> dlg (
			new TOutputSelectDlg (
			this, outputFileName, outputType ) );
		if ( !dlg->Cancelled() )
		{
			::centuryConfig->UseOutputFile (
				outputFileName.c_str(),
				outputType,
				TOutputBase::Mode_Replace );
		}
		// all done!
		HistText ("Finished.\n");
		break;
	  }

	  case M_Sim_RunEquil:
		str = "Running the simulation to equilibrium";
		ActionMsg (str);
		break;

	  case M_Sim_RunResFile:
		str = "Running the simulation from Restart File";
		ActionMsg (str);
		break;

	  case M_Sim_Run:
		str = "Running the simulation";
		ActionMsg (str);
		const_cast<TCMIApp*>(app)->RunCentury ();
		break;

	  case M_Sim_Status:
		app->DisplayStatus ();
		break;
	}
	ActionMsg ("Idle");
}

//--- end of file ---

