
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  soilc_ncid;			/* netCDF id */

/* variable ids */
int  defac_id, som1c1_id, som1c2_id, som2c_id, som3c_id, 
     strucc1_id, strucc2_id, metabc1_id, metabc2_id;

int
soilcdef(int *ntimes, char *history) {		/* create soilc.nc */

   int status;

   /* dimension ids */
   int  time_dim = 0;
   int  cell_dim = 0;

   /* variable shapes */
   int dims[2];

   /* enter define mode */
   status = nc_create("soilc.nc", NC_CLOBBER, &soilc_ncid);
   if (status != NC_NOERR) handle_error("nc_create(soilc.nc)", status);

   /* define dimensions */
   status = nc_def_dim(soilc_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(soilc_ncid, "cell", NC_UNLIMITED, &cell_dim);

   /* define variables */

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soilc_ncid, "defac", NC_FLOAT, 2, dims, &defac_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soilc_ncid, "som1c1", NC_FLOAT, 2, dims, &som1c1_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soilc_ncid, "som1c2", NC_FLOAT, 2, dims, &som1c2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soilc_ncid, "som2c", NC_FLOAT, 2, dims, &som2c_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soilc_ncid, "som3c", NC_FLOAT, 2, dims, &som3c_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soilc_ncid, "strucc1", NC_FLOAT, 2, dims, &strucc1_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soilc_ncid, "strucc2", NC_FLOAT, 2, dims, &strucc2_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soilc_ncid, "metabc1", NC_FLOAT, 2, dims, &metabc1_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (soilc_ncid, "metabc2", NC_FLOAT, 2, dims, &metabc2_id);

   /* assign attributes */
   status = nc_put_att_text (soilc_ncid, NC_GLOBAL, "history", strlen(history), history);
   status = nc_put_att_text (soilc_ncid, defac_id, "long_name", 
	strlen("decomposition factor"), "decomposition factor");
   status = nc_put_att_text (soilc_ncid, defac_id, "units", strlen("unitless"), "unitless");
   status = nc_put_att_text (soilc_ncid, som1c1_id, "long_name", 
	strlen("surface_microbial_carbon"), "surface_microbial_carbon");
   status = nc_put_att_text (soilc_ncid, som1c1_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (soilc_ncid, som1c2_id, "long_name", 
	strlen("soil_microbial_carbon"), "soil_microbial_carbon");
   status = nc_put_att_text (soilc_ncid, som1c2_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (soilc_ncid, som2c_id, "long_name", 
	strlen("som2_carbon"), "som2_carbon");
   status = nc_put_att_text (soilc_ncid, som2c_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (soilc_ncid, som3c_id, "long_name", 
	strlen("som3_carbon"), "som3_carbon");
   status = nc_put_att_text (soilc_ncid, som3c_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (soilc_ncid, strucc1_id, "long_name", 
	strlen("surface_structural_carbon"), "surface_structural_carbon");
   status = nc_put_att_text (soilc_ncid, strucc1_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (soilc_ncid, strucc2_id, "long_name", 
	strlen("soil_structural_carbon"), "soil_structural_carbon");
   status = nc_put_att_text (soilc_ncid, strucc2_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (soilc_ncid, metabc1_id, "long_name", 
	strlen("surface_metabolic_carbon"), "surface_metabolic_carbon");
   status = nc_put_att_text (soilc_ncid, metabc1_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (soilc_ncid, metabc2_id, "long_name", 
	strlen("soil_metabolic_carbon"), "soil_metabolic_carbon");
   status = nc_put_att_text (soilc_ncid, metabc2_id, "units", strlen("g/m2"), "g/m2");

   /* leave define mode */
   status = nc_enddef (soilc_ncid);
   return 0;
}
