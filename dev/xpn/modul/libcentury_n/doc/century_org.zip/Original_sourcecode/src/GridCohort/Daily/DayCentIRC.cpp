//---------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  DayCentIRC.cpp
//
//	Description:
//	IRC-coupled Daily Century main program.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, tom.hilinski@colostate.edu, June02
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
//---------------------------------------------------------------------------

#include "versionDayCentIRC.h"
#include "About.h"
#include "CmdLine.h"
#include "TINIDataDCIRC.h"
#include "INIFileText.h"
#include "INIDataToConfigDCIRC.h"
#include "TDayCentModel.h"
#include "TDayCentSimController.h"	// Simulation
#include "TFactories.h"			// Factories instances
#include "ClimateServer.h"		// Climate data interface
#include "TCenturyOutputFactory.h"	// output device factory
#include "CenturyOutputMgrFactories.h"	// output manager factories
#include "TDayCentModelFactory.h"	// model factory
#include "TSimInfoOutput.h"		// Simulation information to output
#include "TDisGenDayCentIRC.h"		// Disturbance generator
#include "TCohortAgModelPercent.h"	// Cohort aggregation model
#include "fnutil.h"
#include "WeatherException.h"
#include "SiteException.h"
#include <iostream>
#include <sstream>
// #include "INIDisplay.h"		// debug
using namespace ::nrel::dcirc;

// To Do: replace DisplayMsg with the TAsynch class functions.
inline
void DisplayMsg (
	char const * const msg)
{
	std::cout << msg << std::endl;
}

void DisplayMsg (
	char const * const msg,
	TDayCentSimController * const sim)
{
	std::cout << msg << std::endl;
	if ( sim )
	{
		sim->Write ( msg );
		if ( !sim->GetMessage().empty() )
		{
			std::cout << sim->GetMessage() << std::endl;
			sim->Write ( sim->GetMessage() );
		}
	}
}

inline
void DisplayMsg (
	std::string const & msg,
	TDayCentSimController * const sim = 0)
{
	DisplayMsg (msg.c_str(), sim);
}

//	Terminate
//	Handle uncaught exceptions.
inline
void Terminate ()
{
	::DisplayMsg ("An unknown error terminates the simulation.");
}

inline void DisplayDoneMsg ()
{
	::DisplayMsg ("\n   all done!");
}

//	ReadINIData
//	Read the INI data file.
//	Returns false if successful, else true if failed or error.
bool ReadINIData (
	TINIDataDCIRC & iniData,
	std::string const & fileName)
{
	std::string msg = "Reading INI data file:\n";
	msg += fileName;
	::DisplayMsg ( msg );

	::nrel::ini::INIFileText iniFile (
		iniData,
		fileName,
		::nrel::ini::INIFileText::Access_ReadOnly );

	bool const failed =
		iniData.IsEmpty() ||
		( iniFile.GetDeviceState() ==
		  ::nrel::ini::INIFileText::DevState_Error );

	if ( failed )
		msg = "Read failed.";
	else
		msg = "ok!";
	::DisplayMsg ( msg );
	return failed;
}

int main (int argc, char* argv[])
{
	// shortcuts
	typedef std::auto_ptr<TDayCentSimController>		TSimControllerPtr;
	typedef auto_ptr< ::nrel::gcf::TDisGenBase>		TDisGenPtr;
	typedef auto_ptr< ::nrel::gcf::TSuccessionBase>		TSuccessionPtr;
	typedef auto_ptr< ::nrel::gcf::TCompetitionBase>	TCompetitionPtr;
	typedef auto_ptr< ::nrel::gcf::TCohortAgModelBase>	TCohortAgModelPtr;
	typedef TSharedPtr< ::nrel::gcf::TDecision>		TDecisionPtr;
	typedef TSharedPtr<ClimateServer>			TClimateServerPtr;
	typedef	::nrel::gcf::TFactories::TModelOutputMgrFactoryPtr
		TModelOutputMgrFactoryPtr;
	typedef	::nrel::gcf::TFactories::TCohortOutputMgrFactoryPtr
		TCohortOutputMgrFactoryPtr;
	typedef	::nrel::gcf::TFactories::TCellOutputMgrFactoryPtr
		TCellOutputMgrFactoryPtr;
	typedef	::nrel::gcf::TFactories::TGridOutputMgrFactoryPtr
		TGridOutputMgrFactoryPtr;
	typedef	::nrel::gcf::TFactories::TSimOutputMgrFactoryPtr
		TSimOutputMgrFactoryPtr;
	typedef	::nrel::gcf::TFactories::TModelFactoryPtr
		TModelFactoryPtr;
	typedef	::nrel::gcf::TFactories::TModelMgmtGenFactoryPtr
		TModelMgmtGenFactoryPtr;
	typedef	::nrel::gcf::TFactories::TModelEventMgrFactoryPtr
		TModelEventMgrFactoryPtr;
	typedef	::nrel::gcf::TFactories::TOutputFactoryPtr
		TOutputFactoryPtr;

	char const * const exceptionMsg =
		"Exception caught. Ending simulation.\n";
	std::set_terminate ( Terminate );	// terminate function
	::DisplayMsg ( "" );		// blank line below command line
	TSimControllerPtr sim;

	//--- process command line options ---

	CmdLine cmdLine (
		argc,
		(char const ** const)argv,
		::DisplayMsg );
	if ( cmdLine.HaveError() || cmdLine.Terminate() )
	{
		::DisplayDoneMsg ();
		return 1;
	}

	::DisplayMsg ("----- " DayCentIRCNickname " -----\n");

	// Get the executable path
	std::string exePath = TEH::ActualPath (argv[0]);
	Assert (!exePath.empty());

    try
    {
	//--- Read the simulation INI file

	TINIDataDCIRC iniData;
	if ( ::ReadINIData ( iniData, cmdLine.GetINIFileName() ) )
	{
		std::string msg =
			"Error: Read of INI file failed. Cannot continue.";
		throw (msg);
	}
	// ::nrel::ini::DisplayINIData (iniData, std::cout);

	//--- Set the simulation configuration ---

	::DisplayMsg ("Creating configuration object...");
	TDayCentIRCConfig simConfig;
	INIDataToConfigDCIRC toConfig (iniData, simConfig);
	if ( toConfig.TransferFailed() )
	{
		std::string msg =
			"Error: "
			"Transfer of INI data to configuration failed.";
		throw (msg);
	}
	// save the executable path so can find parameters/definitions files
	simConfig.SetPaths (
		exePath, simConfig.GetInputPath(), simConfig.GetOutputPath() );
	::DisplayMsg ("ok!");

	//--- Create the class factories ---

	::DisplayMsg ("Creating object factories...");

	TModelOutputMgrFactoryPtr modelOMFactory;		// optional
	TCohortOutputMgrFactoryPtr cohortOMFactory;		// optional

	::nrel::gcf::TFactories::TCellOutputMgrFactory* pCellOMFactory =
		new TCenturyCellOutMgrFactory;
	TCellOutputMgrFactoryPtr cellOMFactory ( pCellOMFactory );
	Assert (cellOMFactory.get() != 0);
	pCellOMFactory = 0;

	TGridOutputMgrFactoryPtr gridOMFactory;			// optional

	::nrel::gcf::TFactories::TSimOutputMgrFactory* pSimOMFactory =
		new TCenturySimOutMgrFactory;
	TSimOutputMgrFactoryPtr simOMFactory ( pSimOMFactory );
	Assert (simOMFactory.get() != 0);
	pSimOMFactory = 0;

	::nrel::gcf::TFactories::TModelFactory* pModelFactory =
		new TDayCentModelFactory;
	TModelFactoryPtr modelFactory ( pModelFactory );
	Assert (modelFactory.get() != 0);
	pModelFactory = 0;

	TModelMgmtGenFactoryPtr mgmtGenFactory;			// optional
	TModelEventMgrFactoryPtr modelEvtMgrFactory;		// optional

	::nrel::gcf::TFactories::TOutputFactory* pMyOutputFactory =
		new TCenturyOutputFactory;
	TOutputFactoryPtr myOutputFactory ( pMyOutputFactory );
	Assert (myOutputFactory.get() != 0);
	pMyOutputFactory = 0;

	TSharedPtr< ::nrel::gcf::TFactories> factories (
		new ::nrel::gcf::TFactories (
			modelOMFactory,		// model output mgr. factory
			cohortOMFactory,	// cohort output mgr. factory
			cellOMFactory,		// cell output mgr. factory
			gridOMFactory,		// grid output mgr. factory
			simOMFactory,		// sim. output mgr. factory
			modelFactory,		// model factory (required)
			mgmtGenFactory,		// landuse management factory
			modelEvtMgrFactory,	// model evt mgr. factory
			myOutputFactory ) );	// output object factory

	::DisplayMsg ("ok!");

	//--- Create the decision modules ---

	::DisplayMsg ("Creating decision objects...");
	TDisGenPtr disturbGen (				// disturbance generator
		new TDisGenDayCentIRC (simConfig) );
	TSuccessionPtr succession;			// succession rules
		// empty
	TCompetitionPtr competition;			// competition effects
		// empty
	TCohortAgModelPtr coAgModel (			// cohort aggreg. model
		new TCohortAgModelPercent (simConfig) );
	TDecisionPtr decision ( 			// decision module
		new ::nrel::gcf::TDecision (
			disturbGen, succession, competition, coAgModel) );
	::DisplayMsg ("ok!");

	//--- Climate interface object ---

	::DisplayMsg ("Creating climate interface object...");
	TClimateServerPtr climate (
		new ClimateServer (
			iniData.GetWeatherINIFileName() ) );
	// Assert ( !climate.IsError() );
	::DisplayMsg ("ok!");

	//--- Initialize and run the simulation ---

	// Create the simulation controller
	::DisplayMsg ("Creating simulation controller...");
	sim.reset ( new TDayCentSimController (
			simConfig, climate.get(), decision, factories) );
	if ( sim->IsError() )
	{
		throw ( sim->GetMessage() );
	}
	::DisplayMsg ("ok!");

	// Initialize the simulation
	::DisplayMsg ("Initializing the simulation...");
	sim->InitializeSimulation ();
	if ( sim->GetState() != TDayCentSimController::State_Initialized )
	{
		std::string msg =
			"Initialization of simulation failed!. Stopping.";
		throw (msg);
	}
	::DisplayMsg ("ok!");

	//Display simulation information
//	::nrel::gcf::TSimInfoOutput simInfoOutput (
//	    dynamic_cast< ::nrel::io::TFileStream& >(
//		sim->GetOutputManager().GetOutput() ).GetStream(),
//	    sim.get() );
//	// TSimInfoOutput simInfoOutput ( std::cout, sim.get() );
//	simInfoOutput.WriteAllInfo ();

	// Run the simulation
	::DisplayMsg ("Running the simulation...");
	sim->RunSimulation ();		// off we go! wheeee!
	sim->TerminateSimulation ();	// make sure all are stopped
	ostringstream os;
	os << "Simulation completed." << std::endl
	   << "\tElapsed time = " << sim->GetTimerSeconds() << std::endl
	   << "\tElapsed iterations = " << sim->GetIterationCount();
	sim->Write ( os.str() );
	std::cout << os.str() << std::endl;
    }
    catch (TDayCentException const & ce)	// exceptions thrown by DayCent
    {
	string msg (exceptionMsg);
	msg += ce.GetMsg();
	::DisplayMsg ( msg, sim.get() );
    }
    catch (TCentException const & ce)		// exceptions thrown by Century
    {
	string msg (exceptionMsg);
	msg += ce.GetMsg();
	::DisplayMsg ( msg, sim.get() );
    }
    catch (nrel::weather::WeatherException const & e)
    {
	std::string msg =
		"Weather Data Framework error terminates the simulation.\n"
		"The error is: ";
	msg += e.what();
	::DisplayMsg ( msg, sim.get() );
    }
    catch (nrel::site::SiteException const & e)
    {
	std::string msg =
		"Site Parameters subsystem error terminates the simulation.\n"
		"The error is: ";
	msg += e.what();
	::DisplayMsg ( msg );
    }
    catch (std::exception const & e)		// other exceptions (elaborate!)
    {
	string msg (exceptionMsg);
	msg += e.what();
	::DisplayMsg ( msg, sim.get() );
    }
    catch ( CenturyPaths::TDefPathErr pathErr )
    {
	char const* errStr[] =
	{
	  "no error",
	  "no path",
	  "invalid path index",
	  "invalid executable file path",
	  "invalid parameters path",
	  "invalid templates path",
	  "invalid management library path",
	  "invalid site library path",
	  "invalid block library path",
	  "memory allocation failed",
	  "unknown error",
	  0
	};
	string msg ("Directory path error: ");
	msg += errStr[pathErr];
	::DisplayMsg ( msg, sim.get() );
    }
    catch (char const * const aMsg)
    {
	string msg (exceptionMsg);
	if ( *aMsg )
	{
		msg += aMsg;
		msg += '\n';
	}
	::DisplayMsg ( msg, sim.get() );
    }
    catch (std::string const & aMsg)
    {
	string msg (exceptionMsg);
	if ( !aMsg.empty() )
		msg += aMsg;
	::DisplayMsg ( msg, sim.get() );
    }
    catch (...)
    {
	::DisplayMsg ( exceptionMsg, sim.get() );
    }

    // all done
    ::DisplayDoneMsg ();
    // sim.Clear ();
    return 0;
}
//---------------------------------------------------------------------------


