#ifndef INC_nrel_dcirc_TDisturbanceList_h
#define INC_nrel_dcirc_TDisturbanceList_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  TDisturbanceList.h
//	Class:	  ScheduledDisturbanceEvent
//
//	Description:
//	Defines class ScheduledDisturbanceEvent which contains data
//	for a single scheduled disturbance event.
//	TDisturbanceList contains a list of cohort disturbances for
//	one grid cell.
//	TDisturbListArray contains an array of lists for the grid cells for
//	which a disturbance list was specified..
//
//	Classes defined here:
//	  ScheduledDisturbanceEvent	One record from the disturbance file.
//	Types defined here:
//	  TDisturbanceList		std::list<ScheduledDisturbanceEvent>
//	  TCellSchedDisturbListItem	pair <grid cell index, TDisturbanceList>
//	  TCellSchedDisturbListMap	std:;map <cell index, TDisturbanceList>
//
//	Responsibilities:
//	* class ScheduledDisturbanceEvent
//	  - Provides a class with public interface for
//	    scheduled disturbance events.
//	  - Declares the type for the list.
//	  - Has flags for
//	    (1) disturbance being performed;
//	    (2) record is a comment.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, July 2003
//	History:
//	Oct03	Tom Hilinski
//	* Added typedefs TCellSchedDisturbListItem, TCellSchedDisturbListMap.
//	* Renamed class TDisturbanceRecord to ScheduledDisturbanceEvent.
// ----------------------------------------------------------------------------

#include "timetypes.h"
#include "TCohort.h"
#include <string>
#include <list>		// for TDisturbanceList
#include <utility>	// for TCellSchedDisturbListItem
#include <map>		// for TDisturbListArray
#include "DayCentIRCTypes.h"

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

// ----------------------------------------------------------------------------
//	ScheduledDisturbanceEvent
//	Hold and manage data associated with one scheduled disturbance event.
//	An event associates a management file name with the simulation time
//	at which the management is to begin, and with the cohort which
//	will either use that management or provide the new cohort to use it.
class ScheduledDisturbanceEvent
{
  public:
	//---- types

	//---- constructors and destructor
	ScheduledDisturbanceEvent ()
	  : idSource (0),
	    id (0),
	    year (0),
	    month (Jan),
	    day (0),
	    cellAreaFraction (0.0f),
	    initialized (false),
	    done (false),
	    isComment (false)
	  {
	  }
	ScheduledDisturbanceEvent (
	  TCohortID const useIdSource,		// ID number of source cohort
	  TCohortID const useId,		// my cohort ID number
	  TYear const useYear,			// simulation year
	  TMonth const useMonth,		// simulation month
	  TDay const useDay,			// simulation day of month
	  float const useCellAreaFraction,	// area fraction of cell
	  std::string const & useMgmtFileName,	// management file name
	  std::string const & useDescription)	// description of disturbance
	  : idSource (useIdSource),
	    id (useId),
	    year (useYear),
	    month (useMonth),
	    day (useDay),
	    cellAreaFraction (useCellAreaFraction),
	    mgmtFile (useMgmtFileName),
	    description (useDescription),
	    initialized (true),
	    done (false),
	    isComment (false)
	  {
	  }
	ScheduledDisturbanceEvent (
	  ScheduledDisturbanceEvent const & object)
	  {
	    Copy (object);
	  }
	~ScheduledDisturbanceEvent ()
	  {
	  }

	//---- operator overloads
	ScheduledDisturbanceEvent& operator= (ScheduledDisturbanceEvent const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
		Copy (object);
	    }
	    return *this;
	  }
	bool operator== (ScheduledDisturbanceEvent const & object) const
	  {
	    bool result = (	// do these first
	    	year == object.year &&
	    	month == object.month &&
	    	day == object.day);
	    if ( result )
	    	result = (	// check the remaining
	    	    id == object.id &&
	    	    idSource == object.idSource &&
	    	    cellAreaFraction == object.cellAreaFraction &&
	    	    mgmtFile == object.mgmtFile);
	    return result;
	  }
	bool operator!= (ScheduledDisturbanceEvent const & object) const
	  { return !(*this == object); }
	bool operator< (ScheduledDisturbanceEvent const & object) const
	  {
	    bool result = (
	    	year <= object.year &&
	    	month <= object.month &&
	    	day < object.day);
	    if ( !result )
	    	result = (	// check the remaining
	    	    day == object.day &&
	    	    id <= object.id &&
	    	    idSource <= object.idSource &&
	    	    cellAreaFraction < object.cellAreaFraction);
	    return result;
	  }
	bool operator<= (ScheduledDisturbanceEvent const & object) const
	  { return (*this == object || *this < object); }
	bool operator> (ScheduledDisturbanceEvent const & object) const
	  { return !(*this <= object); }
	bool operator>= (ScheduledDisturbanceEvent const & object) const
	  { return !(*this < object); }

	//---- functions
	TCohortID GetSourceCohortID () const
	  { return idSource; }
	TCohortID GetID () const
	  { return id; }
	TYear GetYear () const
	  { return year; }
	TMonth GetMonth () const
	  { return month; }
	TDay GetDay () const
	  { return day; }
	float GetCellAreaFraction () const
	  { return cellAreaFraction; }
	std::string const & GetManagementFileName () const
	  { return mgmtFile; }
	std::string const & GetDescription () const
	  { return description; }

	bool IsInitialized () const			// True if has data
	  { return initialized; }
	bool IsDone () const				// True if dist. done
	  { return done; }
	void SetDone (					// Set the done flag
	  bool doneFlag)
	  { done = doneFlag; }
	bool IsComment () const				// True if is a comment
	  { return isComment; }
	void SetComment (				// set comment
	  bool const commentFlag,
	  std::string const & commentText)
	  {
	    isComment = commentFlag;
	    description = commentText;
	    initialized = true;
	  }
	bool IsEmpty () const				// True if no data
	  {
	    return (
	    	year == 0 && month == 0 && day == 0 &&
	    	id == 0 && idSource == 0 &&
	    	cellAreaFraction == 0.0f &&
	    	mgmtFile.empty() );
	  }
	void Clear ()
	  {
	    year = 0;
	    month = ::Jan;
	    day = 0;
	    id = idSource = 0;
	    cellAreaFraction = 0.0f;
	    mgmtFile.clear();
	    description.clear();
	    done = isComment = initialized = false;
	  }

  private:
	//---- data
	TCohortID idSource;		// ID number of source cohort
	TCohortID id;			// my ID number
	TYear year;			// simulation year
	TMonth month;			// simulation month
	TDay day;			// simulation day of month
	float cellAreaFraction;		// area fraction of cell
	std::string mgmtFile;		// management file name
	std::string description;	// description of disturbance

	//--- flags ---
	bool initialized;		// true if data is initialized
	bool done;			// true if disturbance was performed
	bool isComment;			// comments are stored in mgmtFile

	//---- functions
	void Copy (ScheduledDisturbanceEvent const & object)	// Copy to this
	  {
	    year = object.year;
	    month = object.month;
	    day = object.day;
	    id = object.id;
	    idSource = object.idSource;
	    cellAreaFraction = object.cellAreaFraction;
	    mgmtFile = object.mgmtFile;
	    description = object.description;
	    initialized = object.initialized;
	    done = object.done;
	    isComment = object.isComment;
	  }
};

// ----------------------------------------------------------------------------
//	TDisturbanceList
//	List of scheduled disturbance events.
typedef std::list<ScheduledDisturbanceEvent>	TDisturbanceList;

// ----------------------------------------------------------------------------
//	TCellSchedDisturbListItem
//	Associate one cell with its scheduled disturbance list.
typedef	std::pair
	<
	  TGridSize, 			// index to cell in grid's cell array
	  TDisturbanceList 		// the disturbance list for that cell
	>
	TCellSchedDisturbListItem;

// ----------------------------------------------------------------------------
//	TCellSchedDisturbListMap
//	For each cell with a scheduled disturbance list,
//	map cells' position in grid array to it's scheduled disturbance list.
typedef	std::map
	<
	  TGridSize, 			// index to cell in grid's cell array
	  TDisturbanceList 		// the disturbance list for that cell
	>
	TCellSchedDisturbListMap;


  } // namespace dcirc
} // namespace nrel

#endif // INC_nrel_dcirc_TDisturbanceList_h
