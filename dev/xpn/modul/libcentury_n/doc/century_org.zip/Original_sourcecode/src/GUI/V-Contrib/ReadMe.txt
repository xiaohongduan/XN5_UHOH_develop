File:	Century/version5/src/V-contrib/ReadMe.txt

This directory contains C++ source code used in the Century Model Interface.
This code is for V GUI classes and functions which were created outside
of the CMI project, but used by the project by permission of the authors.
See the headers of the source code files for copyright information.



--- end of file ---