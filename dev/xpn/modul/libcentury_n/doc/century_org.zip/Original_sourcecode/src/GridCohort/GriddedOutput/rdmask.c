
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include "netcdf.h"
#include "wrtcdf.h"

void
rdmask_(int *col, int *row, int *maskval)
{
	int             status;
	static size_t	mstart[2]={0, 0};
	size_t 		mcount[2]={1, 1};

	/* Get variable ID */
	status = nc_inq_varid(osite_ncid, "mask", &mask_id);

        printf("rdmask: row = %1d  col = %1d\n", *row, *col);
	/* Read correct value */
	mstart[0] = (size_t) *row;
	mstart[1] = (size_t) *col;
	status = nc_get_vara_int(osite_ncid, mask_id, mstart, mcount, maskval);

	return;
}
