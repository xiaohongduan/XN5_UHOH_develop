// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  T_CmdWinBase.cpp
//	Class:	  TCmdWinBase
//
//	Description:
//	Base class for windows.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Oct98
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TCmdWinBase.h"
#include "externals.h"
#include "HelpDisplay.h"
#include <v/vcmdpane.h>
#include <v/vkeys.h>

// ----------------------------------------------------------------------------
//	static non-member variables
// ----------------------------------------------------------------------------

static char *toolTips[] =		// tool tips text
{
	// 0 = general message
	"Configure and run the simulation with these quick steps.",
	// 1 = button Preferences
	"Specify your preferences or read a preferences file.",
	// 2 = button Site
	"Select and edit the site parameters.",
	// 3 = button Management
	"Select and edit the management scheme.",
	// 4 = button Output File
	"Specify the output file name and type.",
	// 5 = button Status
	"View the status of the simulation configuration.",
	// 6 = button Run
	"Run the simulation.",
	// last item always
	NULL
};

// ----------------------------------------------------------------------------
//	static member variables
// ----------------------------------------------------------------------------

//	status bar

vStatus TCmdWinBase::statusBar[] =
{
	{"Status:", S_Status_Lbl, CA_NoBorder, isSens, 0},
	{"Ready", S_Status, CA_None, isSens, 100},
	{"Action:", S_Action_Lbl, CA_NoBorder, isSens, 0},
	{"Idle", S_Action, CA_None, isSens, 200},
	{0}
};

//	toolbar - quick steps

CommandObject TCmdWinBase::toolBarQS[] =
{
	{ C_Label, TBQS_BtnLabel, 0,                "Quick Steps:",
		NoList, CA_None, isSens, NoFrame, 0, 0, 0, toolTips[0]},
	{ C_Button, TBQS_BtnPref, TBQS_BtnPref,     " Preferences  ",
		NoList, CA_Small, isSens, NoFrame, 0, 0, 0, toolTips[1]},
	{ C_Button, TBQS_BtnSite, TBQS_BtnSite,     "     Site     ",
		NoList, CA_Small, isSens, NoFrame, 0, 0, 0, toolTips[2]},
	{ C_Button, TBQS_BtnMgmt, TBQS_BtnMgmt,     "  Management  ",
		NoList, CA_Small, isSens, NoFrame, 0, 0, 0, toolTips[3]},
	{ C_Button, TBQS_BtnOF, TBQS_BtnOF,         " Output File  ",
		NoList, CA_Small, isSens, NoFrame, 0, 0, 0, toolTips[4]},
	{ C_Button, TBQS_BtnStatus, TBQS_BtnStatus, "    Status    ",
		NoList, CA_Small, isSens, NoFrame, 0, 0, 0, toolTips[5]},
	{ C_Button, TBQS_BtnRun, TBQS_BtnRun,       "Run Simulation",
		NoList, CA_Small, isSens, NoFrame, 0, 0, 0, toolTips[6]},
	{C_EndOfList, 0, 0, 0, 0, CA_None, 0, 0}
};

//-------------------------------------------------------------------------
//	Shortcut keys for menu bar and drop-down menus:
//	File:New				Ctrl+N (not implemented)
//	File:Open				Ctrl+O
//	File:Save				Ctrl+S (not implemented)
//	File:Print				Ctrl+P (not implemented)
//	File:Exit				Alt+F4
//	Edit:Cut				Ctrl+X (not implemented)
//	Edit:Copy				Ctrl+C (not implemented)
//	Edit:Paste				Ctrl+V (not implemented)
//	Edit:Find				Ctrl+F
//	Edit:Find Next				F3
//	Edit:Replace				Ctrl+R (not implemented)
//	Edit:Go to (line)			Ctrl+G (not implemented)
//	Simulation:Edit Site Parameters		F4
//	Simulation:Edit Management		F5
//	Simulation:Edit Weather			F6 (not implemented)
//	Simulation:14C data			F7 (not implemented)
//	Simulation:Edit Model Parameters
//	Simulation:Output File			F8
//	Simulation:Restart File
//	Note: On MS-Windows systems, the F10 key is reserved for the following:
//	"Activate the menu bar in programs"
//	so use F2 instead.
//	Simulation:Run to Equilibrium		Shift+F2 (not implemented)
//	Simulation:Run				F2
//	Simulation:Status			F9
//	Results:View				Shift+F2 (not implemented)
//	Results:Plot				Shift+F3 (not implemented)
//	Results:Export				Shift+F4 (not implemented)
//	Help:Contents				F1
//	Help:Search Help			Ctrl+F1
//-------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	Drop-down menus
// ----------------------------------------------------------------------------

vMenu TCmdWinBase::fileMenuDef[] =
{
  //{"&New", M_New, notSens, notChk, "Ctrl+N", noKey, noSub},
  {"&Open...", M_Open, isSens, notChk, "Ctrl+O", 'O'-'@', noSub},
  //{"&Close", M_Close, isSens, notChk, noKeyLbl, noKey, noSub},
  //{"&Save", M_Save, isSens, notChk, "Ctrl+S", noKey, noSub},
  //{"Save &As...", M_SaveAs, isSens, notChk, noKeyLbl, noKey, noSub},
  {"-", M_Line, notSens, notChk, noKeyLbl, noKey, noSub},
  {"&Print...", M_Print, notSens, notChk, "Ctrl+P", 'P'-'@', noSub},
  {"P&rint Setup...", M_PrintSetup, notSens, notChk, noKeyLbl, noKey, noSub},
  {"-", M_Line, notSens, notChk, noKeyLbl, noKey, noSub},
  {"E&xit", M_Exit, isSens, notChk, "Alt+F4", noKey, noSub},
  {NULL}
};

vMenu TCmdWinBase::projectMenuDef[] =
{
  {"&New", M_Proj_New, notSens, notChk, noKeyLbl, noKey, noSub},
  {"&Open", M_Proj_Open, notSens, notChk, noKeyLbl, noKey, noSub},
  {"&Close", M_Proj_Close, notSens, notChk, noKeyLbl, noKey, noSub},
  {"-", M_Line, isSens, notChk, noKeyLbl, noKey, noSub},
  {"&Edit...", M_Proj_Edit, notSens, notChk, noKeyLbl, noKey, noSub},
  {"-", M_Line, isSens, notChk, noKeyLbl, noKey, noSub},
  {"&Recent...", M_Proj_Recent, notSens, notChk, noKeyLbl, noKey, noSub},
  {NULL}
};

vMenu TCmdWinBase::simulationMenuDef[] =
{
  {"&Clear Simulation", M_Sim_Clear, notSens, notChk, noKeyLbl, noKey, noSub},
  {"-", M_Line, isSens, notChk, noKeyLbl, noKey, noSub},
  {"Edit &Site Parameters...", M_Sim_Site, isSens, notChk, "F4", vk_F4, noSub},
  {"Edit &Management...", M_Sim_Mgmt, isSens, notChk, "F5", vk_F5, noSub},
  {"M&anagement Summary", M_Sim_MgmtSum,
	isSens, notChk, noKeyLbl, noKey, noSub},
  {"&Weather...", M_Sim_WthrEdit,
  	notSens, notChk, "F6", vk_F6, noSub},
  {"&14C Data...", M_Sim_C14Edit,
  	notSens, notChk, "F7", vk_F7, noSub},
  {"Model &Parameters...", M_Sim_ParEdit,
	notSens, notChk, noKeyLbl, noKey, noSub},
  {"-", M_Line, isSens, notChk, noKeyLbl, noKey, noSub},
  {"&Output File...", M_Sim_OutFile,
  	isSens, notChk, "F8", vk_F8, noSub},
  {"Restart &File...", M_Sim_ResFile, notSens, notChk, noKeyLbl, noKey, noSub},
  {"-", M_Line, isSens, notChk, noKeyLbl, noKey, noSub},
  {"Run to &Equilibrium", M_Sim_RunEquil,
	notSens, notChk, "Shift+F2", noKey, noSub},
  {"Run from Restart File", M_Sim_RunResFile,
	notSens, notChk, "Ctrl+F2", vk_F2, noSub, VKM_Shift},
  {"&Run", M_Sim_Run, isSens, notChk, "F2", vk_F2, noSub},
  {"-", M_Line, isSens, notChk, noKeyLbl, noKey, noSub},
  {"S&tatus", M_Sim_Status, isSens, notChk, "F9", vk_F9, noSub},
  {NULL}
};

vMenu TCmdWinBase::resultsMenuDef[] =
{
  {"&View...", M_Res_View, notSens, notChk, "Shift+F3", noKey, noSub},
  {"&Plot...", M_Res_Plot, notSens, notChk, "Shift+F4", noKey, noSub},
  {"&Export...", M_Res_Export, notSens, notChk, "Shift+F5", noKey, noSub},
  {"&Browse...", M_Res_Browse, notSens, notChk, "Shift+F6", noKey, noSub},
  {NULL}
};

vMenu TCmdWinBase::toolsMenuDef[] =
{
  {"Simulation &Preferences", M_Preferences,
	isSens, notChk, noKeyLbl, noKey, noSub},
  {"Configure Display &Environment", M_Tools_Environment,
  	notSens, notChk, noKeyLbl, noKey, noSub},
  {"-", M_Line, isSens, notChk, noKeyLbl, noKey, noSub},
  {"Manage &Simulation Projects...", M_Tools_Projects,
  	notSens, notChk, noKeyLbl, noKey, noSub},
  {"Manage Site &Libraries...", M_Tools_SiteLib,
  	notSens, notChk, noKeyLbl, noKey, noSub},
  {"Manage &Management Libraries...", M_Tools_MgmtLib,
	notSens, notChk, noKeyLbl, noKey, noSub},
  {"Manage &Block Libraries...", M_Tools_BlkLib,
	notSens, notChk, noKeyLbl, noKey, noSub},
  {"-", M_Line, isSens, notChk, noKeyLbl, noKey, noSub},
  {"&Climate Wizard...", M_Tools_ClimateWiz,
	notSens, notChk, noKeyLbl, noKey, noSub},
  {"E&rosion Wizard...", M_Tools_ErosionWiz,
	notSens, notChk, noKeyLbl, noKey, noSub},
  {"Pl&ant Wizard...", M_Tools_PlantWiz,
	notSens, notChk, noKeyLbl, noKey, noSub},
  {"S&oil Wizard...", M_Tools_SoilWiz,
	notSens, notChk, noKeyLbl, noKey, noSub},
 {NULL}
};

vMenu TCmdWinBase::helpMenuDef[] =
{
  {"&Contents", M_Hlp_Contents, isSens, notChk, "F1", vk_F1, noSub},
  {"&Search for Help On...", M_Hlp_Search, isSens, notChk, "Ctrl+F1",
  	noKey, noSub},
  {"&Getting Started", M_Hlp_GetStarted, isSens, notChk, noKeyLbl,
  	noKey, noSub},
  {"Shortcut &Keys", M_Hlp_Keys, notSens, notChk, noKeyLbl,
	noKey, noSub},
  {"&How to Use Help", M_Hlp_HowToUse, isSens, notChk, noKeyLbl,
	noKey, noSub},
  {"-", M_Line, notSens, notChk, noKeyLbl, noKey, noSub},
  {"Create &Debug Report", M_Hlp_DebugReport,
	notSens, notChk, noKeyLbl, noKey, noSub},
  {"-", M_Line, notSens, notChk, noKeyLbl, noKey, noSub},
  {"&About", M_About, isSens, notChk, notUsed, noKey, noSub},
  {NULL}
};

// ----------------------------------------------------------------------------
//	constructors and destructor
// ----------------------------------------------------------------------------

TCmdWinBase::TCmdWinBase (
	TCMIApp * const parentApp,	// pointer to app instance
	char const * windowTitle)	// window title string
	: app (parentApp),
	  vCmdWindow (windowTitle)
{
	// add tool bar pane
	vCommandPane * mainTBQSPane =
		new vCommandPane ((CommandObject*)toolBarQS);
	AddPane ( mainTBQSPane );		// transfer ownership
	mainTBQSPane = 0;
	// add status bar pane
	vStatusPane * mainStatusPane =
		new vStatusPane ((vStatus*)statusBar);
	AddPane ( mainStatusPane );		// transfer ownership
	mainStatusPane = 0;
}

TCmdWinBase::~TCmdWinBase ()
{
}

// ----------------------------------------------------------------------------
//	overridden functions
// ----------------------------------------------------------------------------

//	KeyIn
//	Process unhandled keyboard events.
void TCmdWinBase::KeyIn (vKey keysym, unsigned int shift)
{
	// check for Help request = F1
	if ( shift == 0 && keysym == vk_F1 )
		WindowCommand (M_Hlp_Contents, (ItemVal)0, (CmdType)0 );

	// control-key combinations
	else if ( shift & VKM_Ctrl )
	{
		switch (keysym)
		{
		  case vk_F1:	// Check for Search Help request = Ctrl+F1
			WindowCommand (M_Hlp_Search, (ItemVal)0, (CmdType)0 );
			break;
		  case vk_F2:	// Simulation:Run from Restart File = Ctrl+F2
			WindowCommand (
				M_Sim_RunResFile, (ItemVal)0, (CmdType)0 );
			break;
		  default:
			vCmdWindow::KeyIn (keysym, shift);  // default handler
			break;
		};
	}

	// shift-key combinations
	else if ( shift & VKM_Shift )
	{
		switch (keysym)
		{
		  case vk_F2:	// Simulation:Run to Equilibrium = Shift+F2
			WindowCommand (M_Sim_RunEquil, (ItemVal)0, (CmdType)0 );
			break;
		  case vk_F3:	// Results:View = Shift+F3
			WindowCommand (M_Res_View, (ItemVal)0, (CmdType)0 );
			break;
		  case vk_F4:	// Results:Plot = Shift+F4
			WindowCommand (M_Res_Plot, (ItemVal)0, (CmdType)0 );
			break;
		  case vk_F5:	// Results:Export = Shift+F5
			WindowCommand (M_Res_Export, (ItemVal)0, (CmdType)0 );
			break;
		  case vk_F6:	// Results:Browse = Shift+F6
			WindowCommand (M_Res_Browse, (ItemVal)0, (CmdType)0 );
			break;
		  default:
			break;
		};
	}

	// default handler
	else
		vCmdWindow::KeyIn (keysym, shift);
}

//	TCmdWinBase::WindowCommand
//	Process the menu and toolbar selections
void TCmdWinBase::WindowCommand (ItemVal itemId, ItemVal val, CmdType cType)
{
	switch (itemId)
	{
							// File menu
	  case M_New:
	  case M_Open:
	  case M_Close:
	  case M_Save:
	  case M_SaveAs:
	  case M_Print:
	  case M_PrintSetup:
	  case M_Exit:
		DoMenuEvent_File (itemId);
		break;
							// Project menu
	  case M_Proj_New:
	  case M_Proj_Open:
	  case M_Proj_Close:
	  case M_Proj_Edit:
	  case M_Proj_Recent:
		// DoMenuEvent_Project (itemId);
		break;
							// Simulation menu
	  case M_Sim_Clear:
	  case M_Sim_Site:
	  case M_Sim_Mgmt:
	  case M_Sim_MgmtSum:
	  case M_Sim_WthrEdit:
	  case M_Sim_C14Edit:
	  case M_Sim_ParEdit:
	  case M_Sim_OutFile:
	  case M_Sim_ResFile:
	  case M_Sim_RunEquil:
	  case M_Sim_RunResFile:
	  case M_Sim_Run:
	  case M_Sim_Status:
		DoMenuEvent_Simulation (itemId);
		break;
							// Results menu
	  case M_Res_View:
	  case M_Res_Plot:
	  case M_Res_Export:
		DoMenuEvent_Results (itemId);
		break;
							// Tools menu
	  case M_Preferences:
	  case M_Tools_Environment:
	  case M_Tools_Projects:
	  case M_Tools_SiteLib:
	  case M_Tools_MgmtLib:
	  case M_Tools_BlkLib:
	  case M_Tools_PlantWiz:
	  case M_Tools_SoilWiz:
	  case M_Tools_ErosionWiz:
	  case M_Tools_ClimateWiz:
		DoMenuEvent_Tools (itemId);
		break;
							// Quick Start toolbar
	  case TBQS_BtnPref:
		DoMenuEvent_Tools (M_Preferences);
		break;
	  case TBQS_BtnSite:
		DoMenuEvent_Simulation (M_Sim_Site);
		break;
	  case TBQS_BtnMgmt:
		DoMenuEvent_Simulation (M_Sim_Mgmt);
		break;
	  case TBQS_BtnOF:
		DoMenuEvent_Simulation (M_Sim_OutFile);
		break;
	  case TBQS_BtnStatus:
		DoMenuEvent_Simulation (M_Sim_Status);
		break;
	  case TBQS_BtnRun:
		DoMenuEvent_Simulation (M_Sim_Run);
		break;

	  //----- Help menu -----
	  case M_Hlp_Contents:
#ifdef MSWindowsHelp
		::HelpDisplay (app->winHwnd(), ::helpPath, HELP_CONTENTS, 0);
#elif defined(X11Help)
		::HelpDisplay (winHwnd(), ::helpPath, HELP_CONTENTS, 0);
#endif
		break;

	  case M_Hlp_Search:
#ifdef MSWindowsHelp
		::HelpDisplay (app->winHwnd(), ::helpPath, HELP_FINDER, 0);
#elif defined(X11Help)
		::HelpDisplay (winHwnd(), ::helpPath, HELP_FINDER, 0);
#endif
		break;

	  case M_Hlp_GetStarted:
#ifdef MSWindowsHelp
		::HelpDisplay (app->winHwnd(), ::helpPath,
			   HELP_CONTEXT, IDH_GETTING_STARTED);
#elif defined(X11Help)
		::HelpDisplay (winHwnd(), ::helpPath,
			   HELP_CONTEXT, IDH_GETTING_STARTED);
#endif
		break;

	  case M_Hlp_Keys:
#ifdef MSWindowsHelp
		//::HelpDisplay (app->winHwnd(), "", , 0);
#elif defined(X11Help)
#endif
		break;

	  case M_Hlp_HowToUse:
#ifdef MSWindowsHelp
		::HelpDisplay (app->winHwnd(), "", HELP_HELPONHELP, 0);
#elif defined(X11Help)
		::HelpDisplay (winHwnd(), "", HELP_HELPONHELP, 0);
#endif
		break;

	  case M_Hlp_DebugReport:
		break;

	  case M_About:
		((TCMIApp*)(app))->DisplayAbout ();
		break;

	  default:				// Default event processing
		vCmdWindow::WindowCommand (itemId, val, cType);
		break;
	}
}
