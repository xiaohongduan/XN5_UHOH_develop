#ifndef INC_centconsts_h
#define INC_centconsts_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  centconsts.h
//	Class:	  TCenturyBase
//
//	Description:
//	Constants for class TCentury and related utilities.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
// ----------------------------------------------------------------------------
//	History:
//	Oct01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved M_PI and PEEDEE to the century base class.
// ----------------------------------------------------------------------------

#include "TMgmtConst.h"

//--- Misc. constants
#define MPY	(short)12	// Number of months per year
#define MAXLYR	(short)10	// Maximum soil layers in site file
#define CLTEFF_MIN	1.00f	// min. cultivation factor for decomposition
//#define CLTEFF_MAX	1.60f	// max. cultivation factor for decomposition
#define CLTEFF_MAX	10.0f	// max. cultivation factor for decomposition
#define FRTCINDX_MIN	0	// minimum value of frtcindx
#define FRTCINDX_MAX	2	// maximum value of frtcindx

//	TWeatherSrc
//	Source of the weather data.
enum TWeatherSrc
{
	WS_Unknown = 0,
	WS_Means,	    // 'M': Means from site file
	WS_Stochastic,	    // 'S': Stochastically-generated from site file
	WS_FileRewind,	    // 'F': Rewind weather data file if need more years
	WS_FileContinue,    // 'C': Data from current position in weather file
	WS_EndOfList
};

//--- INTCPT, SLOPE are the intercept and slope array pointers
enum { INTCPT, SLOPE };

//--- system type
enum TSystemTypeIndex
{
	CRPSYS,	// crop system
	FORSYS,	// forest system
	SAVSYS,	// savanna system
	NUMSYS	// number of systems
};

//--- SRFC, SOIL are enumerations for surface, soil; array indices
enum TSurfaceSoilIndex
{
	SRFC,
	SOIL,
	NUMLAYERS
};

//--- Indices to the crop/grass system arrays:
enum TCropGrassParts
{
	ABOVE,	// aboveground
	BELOW,	// belowground
	CPARTS	// number of parts in the crop/grass system
};

//--- Indices to the forest parts pools:
enum TForestParts
{
	LEAF,	// leaf forest part; array index
	FROOT,	// fine root forest part
	FBRCH,	// fine branch forest part
	LWOOD,	// large wood forest part
	CROOT,	// coarse root forest part
	FPARTS	// number of parts in the forest system
};

//--- Indices to the E uptake pools
// used only in restrp.f, growth.f, trees.f
enum TEUptakePoolsIndex
{
	ESTOR,
	ESOIL,
	ENFIX,
	EFERT,
	EPOOLS
};

//--- Indices to the N, P, S pools:
enum TMineralElements
{
	N,
	P,
	S,
	NUMELEM
};

//--- Indices to the C pools:
// active, slow, and passive C pools (SOM1, SOM2, SOM3)
// Note: does not include the structural and metabolic pools.
enum TRatePoolsIndex
{
	ACTIVE,
	SLOW,
	PASSIVE,
	NUMPOOLS
};

//--- C isotope indices
enum TIsotopesIndex
{
	UNLABL,
	LABELD,
	ISOS
};

//--- Minimum and maximum indices
enum TMinMaxIndex
{
	MINIMUM,
	MAXIMUM
};

#endif // INC_centconsts_h
