// ----------------------------------------------------------------------------
//	Copyright (c) 2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TFixed.cpp
//	Class:	  TFixed
//
//	Description:
//	Contains "fixed" model parameters.
//	Responsibilities:
//	* Initialize values.
//	* Check for bad values.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, July 2002
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TFixed.h"

#define damr_ref(a_,b_)		damr[(b_)*2 + (a_)]
#define pcemic_ref(a_,b_)	pcemic[(b_)*3 + (a_)]
#define rad1p_ref(a_,b_)	rad1p[(b_)*3 + (a_)]
#define varat1_ref(a_,b_)	varat1[(b_)*3 + (a_)]
#define varat2_ref(a_,b_)	varat2[(b_)*3 + (a_)]
#define varat3_ref(a_,b_)	varat3[(b_)*3 + (a_)]

void TFixed::Clear ()
{
      	//--- float arrays
     	for ( short i = 0; i < MAXLYR; ++i )
     	  adep[i] = awtl[i] = 0.0f;
      	for ( short i = 0; i < 2; ++i )
     	  co2ppm[i] = dec1[i] = dec2[i] = dec3[i] =
     	  p1co2a[i] = p1co2b[i] = pligst[i] = pmco2[i] = ps1co2[i] =
     	  ps1s3[i] = ps2s3[i] = spl[i] = strmax[i] = tmelt[i] = 0.0f;
     	for ( short i = 0; i < 3; ++i )
     	  aneref[i] = damrmn[i] = lhzf[i] = omlech[i] = pmnsec[i] =
     	  pparmn[i] = pprpts[i] = psecmn[i] = rcestr[i] =
     	  texesp[i] = teff[i] = 0.0f;
      	for ( short i = 0; i < 4; ++i )
     	  fwloss[i] = phesp[i] = 0.0f;
      	for ( short i = 0; i < 5; ++i )
     	  fleach[i] = texepp[i] = 0.0f;
     	for ( short i = 0; i < 6; ++i )
     	  damr[i] = favail[i] = 0.0f;
     	for ( short i = 0; i < 9; ++i )
     	  pcemic[i] = rad1p[i] = varat1[i] = varat2[i] = varat3[i] = 0.0f;

     	//--- float
	agppa = agppb = animpt = bgppa = bgppb = co2rmp = 0.0f;
 	dec4 = dec5 = deck5 = dligdf = dresp = 0.0f;
	edepth = elitst = enrich = 0.0f;
	fxmca = fxmcb = fxmxs = fxnpb = gremb = 0.0f;
	minlch = p2co2 = p3co2 = pabres = peftxa = peftxb = 0.0f;
	pmntmp = pmxbio = pmxtmp = psecoc = 0.0f;
	rictrl = riint = rsplig = 0.0f;
	vlosse = vlossg = 0.0f;

	//--- short
	idef = nsnfix = ntspm = 0;

	//--- bool
}

//	Verify
//	Checks values for problems.
//	Returns true if problem found, else false if OK.
bool TFixed::Verify ()
{
	// To Do: TFixed::Verify

/*
	if ( idef != 1 && idef != 2 )	// valid values?
	{
		std::ostringstream os;
		os << "Fixed parameter IDEF has an invalid value.\n"
		   << "Valid values are 1 or 2. Current value is "
		   << idef
		   << "\nChange this value before running this simulation."
		   << std::ends;
	    	ThrowCentException ( TCentException::CE_UNKNOWN_ERROR,
	    				os.str().c_str() );
	}
*/

	return false;
}

//	CheckOptionSet
//	Check the fixed option set for obvious problems.
//	Returns true if problem found, else false if OK.
bool TFixed::CheckOptionSet (
	TSharedPtr<TEventOptionSet> optionSet)
{
	bool failed = false;
	if ( !optionSet.get() )			// database not there?
	{
		// std::string fileName ( optionSet.GetFileName() );
		// ThrowCentException (
		//	TCentException::CE_RDFIXD, fileName.c_str() );
		failed = true;
	}
	else if ( optionSet->GetOptionCount() == 0 ) // empty database?
	{
		// std::string fileName ( optionSet.GetFileName() );
		// ThrowCentException (
		// 	TCentException::CE_EMPPDB, fileName.c_str() );
		failed = true;
	}
	else
	{
		// get the first character in the set, matching the string "X"
		TEventOption const * const option = optionSet->GetOption ("X");
		if ( !option )					// match found?
		{
			failed = true;
		}
	}
	return failed;
}

//	LoadValues
//	Load values from fixed option set.
//	Returns true if problem found, else false if OK.
bool TFixed::LoadValues (
	TSharedPtr<TEventOptionSet> optionSet)
{
	if ( CheckOptionSet (optionSet) )
		return true;			// oops... get outta here

 	// only one parameter set (option) in the fixed parameters set
    	TEventOption const * const option = optionSet->GetOption ("X");

	short k = 0;			// index to param values

	// default thicknesses
    	for (short i = 0; i < MAXLYR; ++i)
		adep[i] = option->GetParameter(k++)->GetValue();
	// ...
	agppa = option->GetParameter(k++)->GetValue();
	agppb = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 3; ++i)
		aneref[i] = option->GetParameter(k++)->GetValue();
	animpt = option->GetParameter(k++)->GetValue();
	// default wilting points
    	for (short i = 0; i < MAXLYR; ++i)
		awtl[i] = option->GetParameter(k++)->GetValue();
	// ...
	bgppa = option->GetParameter(k++)->GetValue();
	bgppb = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 2; ++i)
		co2ppm[i] = option->GetParameter(k++)->GetValue();
	co2rmp = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 2; ++i)
    	  for (short j = 0; j < 3; ++j)
		damr_ref (i, j) = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 3; ++i)
		damrmn[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 2; ++i)
		dec1[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 2; ++i)
		dec2[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 2; ++i)
		dec3[i] = option->GetParameter(k++)->GetValue();
	dec4 = option->GetParameter(k++)->GetValue();
	dec5 = option->GetParameter(k++)->GetValue();
	deck5 = option->GetParameter(k++)->GetValue();
	dligdf = option->GetParameter(k++)->GetValue();
	dresp = option->GetParameter(k++)->GetValue();
	// thickness of simulation layer is in meters.
	// convert to cm for internal use
	edepth = option->GetParameter(k++)->GetValue() * 100.0f;
	elitst = option->GetParameter(k++)->GetValue();
	enrich = option->GetParameter(k++)->GetValue();
	favail[0] = option->GetParameter(k++)->GetValue();
	favail[1] = 0.0f;
    	for (short i = 2; i < 6; ++i)
		favail[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 5; ++i)
		fleach[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 4; ++i)
		fwloss[i] = option->GetParameter(k++)->GetValue();
	fxmca = option->GetParameter(k++)->GetValue();
	fxmcb = option->GetParameter(k++)->GetValue();
	fxmxs = option->GetParameter(k++)->GetValue();
	fxnpb = option->GetParameter(k++)->GetValue();
	gremb = option->GetParameter(k++)->GetValue();
	idef = (int) option->GetParameter(k++)->GetValue();

    	for (short i = 0; i < 3; ++i)
		lhzf[i] = option->GetParameter(k++)->GetValue();
	minlch = option->GetParameter(k++)->GetValue();
	nsnfix = (int) option->GetParameter(k++)->GetValue();
	// ntspm must be 4! So don't worry about using the fixed parameter.
	// ntspm = (int) option->GetParameter(k++)->GetValue();
	ntspm = 4; ++k;
    	for (short i = 0; i < 3; ++i)
		omlech[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 2; ++i)
		p1co2a[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 2; ++i)
		p1co2b[i] = option->GetParameter(k++)->GetValue();
	p2co2 = option->GetParameter(k++)->GetValue();
	p3co2 = option->GetParameter(k++)->GetValue();
	pabres = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 3; ++i)
    	    for (short j = 0; j < 3; ++j)
		pcemic_ref (i, j) = option->GetParameter(k++)->GetValue();
	peftxa = option->GetParameter(k++)->GetValue();
	peftxb = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 4; ++i)
		phesp[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 2; ++i)
		pligst[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 2; ++i)
		pmco2[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 3; ++i)
		pmnsec[i] = option->GetParameter(k++)->GetValue();
	pmntmp = option->GetParameter(k++)->GetValue();
	pmxbio = option->GetParameter(k++)->GetValue();
	pmxtmp = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 3; ++i)
		pparmn[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 3; ++i)
		pprpts[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 2; ++i)
		ps1co2[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 2; ++i)
	ps1s3[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 2; ++i)
		ps2s3[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 3; ++i)
		psecmn[i] = option->GetParameter(k++)->GetValue();
	psecoc = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 3; ++i)
    	    for (short j = 0; j < 3; ++j)
		rad1p_ref (j, i) = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 3; ++i)
		rcestr[i] = option->GetParameter(k++)->GetValue();
	rictrl = option->GetParameter(k++)->GetValue();
	riint = option->GetParameter(k++)->GetValue();
	rsplig = option->GetParameter(k++)->GetValue();
	// NOTE: seed is obsolete! So ignore it here.
	// seed = (int) option->GetParameter(k++)->GetValue();
   	for (short i = 0; i < 2; ++i)
		spl[i] = option->GetParameter(k++)->GetValue();
   	for (short i = 0; i < 2; ++i)
		strmax[i] = option->GetParameter(k++)->GetValue();
   	for (short i = 0; i < 5; ++i)
		texepp[i] = option->GetParameter(k++)->GetValue();
	texesp[0] = option->GetParameter(k++)->GetValue();
	texesp[2] = option->GetParameter(k++)->GetValue();
   	for (short i = 0; i < 3; ++i)
   		teff[i] = option->GetParameter(k++)->GetValue();
   	for (short i = 0; i < 2; ++i)
   		tmelt[i] = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 3; ++i)
    	    for (short j = 0; j < 3; ++j)
    		varat1_ref (j, i) = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 3; ++i)
    	    for (short j = 0; j < 3; ++j)
    		varat2_ref (j, i) = option->GetParameter(k++)->GetValue();
    	for (short i = 0; i < 3; ++i)
    	    for (short j = 0; j < 3; ++j)
    		varat3_ref (j, i) = option->GetParameter(k++)->GetValue();
	vlosse = option->GetParameter(k++)->GetValue();
	vlossg = option->GetParameter(k)->GetValue();

	return false;	// success!
}

//--- end of file TFixed.cpp ---
