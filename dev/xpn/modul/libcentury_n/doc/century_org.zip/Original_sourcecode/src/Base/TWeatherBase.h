#ifndef INC_TWeatherBase_h
#define INC_TWeatherBase_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TWeatherBase.h
//	Class:	  TWeatherBase
//
//	Description:
//	Base class for the weather (precip. & temp.) source.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Sep 2001
//	History:
//	Jun02	Tom Hilinski
//	* Added pure virtual functions common to monthly and daily Century.
//	Oct04	Tom Hilinski
//	* Moved enum TWeatherSrc to file centconsts.h in preparation for
//	  switching to the Weather Data Framework.
// ----------------------------------------------------------------------------

#include "centconsts.h"
#include "TSimTime.h"
#include "ranfun.h"		// random number generator
//#include "zufall.h"		// random number generator
#include <string>

class TCalendarTools;

class TWeatherBase
{
  public:
	//--- types

	//---- constructors and destructor
	explicit TWeatherBase (
	  TCalendarTools * const useCT)	// calendar functions
	  : calendarTools (useCT)
	  {
	    Initialize ();
	  }
	virtual ~TWeatherBase ()
	  {
	  }
	TWeatherBase (
	  TWeatherBase const & object)
	  : calendarTools (object.calendarTools)
	  {
	    Initialize ();
	    Copy (object);
	  }
	virtual TWeatherBase * const Clone () const = 0; // Clone this

	//---- operator overloads
	TWeatherBase& operator= (
	  TWeatherBase const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	Clear ();
		Copy (object);
	    }
	    return *this;
	  }
	bool operator== (
	  TWeatherBase const & object) const
	  {
	    if ( &object )
		return sourceData == object.sourceData &&
			fileName == object.fileName;
	    else
		return false;
	  }
	bool operator!= (
	  TWeatherBase const & object) const
	  { return !(*this == object); }

	//---- functions
	virtual void InitAnnualData (		// Setup the next year's data
     	  const TWeatherSrc source,		//   source of weather data
    	  char const* newFileName = 0		//   file name if source = file
    	  ) = 0;
	void SetReferenceValues (		// Save reference values:
	  float const* usePrecip, 		//   mean precip.
    	  float const* useStdDev, 		//   mean precip: std. dev.
    	  float const* useSkewness, 		//   mean precip: skewness
	  float const* useMintemp,		//   min. mean temp. at 2 m
	  float const* useMaxTemp);		//   max. mean temp. at 2 m
   						//--- Access to data
	float Precip (short const month) const	// Get precipitation
	  { return precipCY[month-1]; }		//   month (1-12)
	float TempMin (short const month) const	// Get minimum temperature
	  { return minTempCY[month-1]; }	//   month (1-12)
	float TempMax (short const month) const	// Get maximum temperature
    	  { return maxTempCY[month-1]; }	//   month (1-12)
	float const* const Precip () const	// Get precipitation array
	  { return precipCY; }
	float const* const TempMin () const	// Get minimum temp array
	  { return minTempCY;; }
	float const* const TempMax () const	// Get maximum temp array
	  { return maxTempCY; }
						//--- Calculations
 	float MeanAnnualTemp () const		// Mean annual temperature
    	  { return meanAnnualTemp; }
	float MeanAnnualPrecip () const		// Mean annual precipitation
    	  { return meanAnnualPrecip; }
	float MaxAnnualMeanTemp () const	// Max. annual temperature
    	  { return maxAnnualMeanTemp; }
	float MinAnnualMeanTemp () const	// Min. annual temperature
    	  { return minAnnualMeanTemp; }
	float MeanMonthlyTemp (			// Mean monthly temp
    	  short const month) const		//   month (1-12)
    	  {
    	    return (minTempCY[month-1] +
    		  maxTempCY[month-1]) * 0.5;
    	  }
	virtual float MeanMonthlyTempSPD (	// Mean monthly temp from
    						//   site parameter data.
    	  short const month) const		//   month (1-12)
    	  {
    	    return (minTempSP[month-1] +
    		  maxTempSP[month-1]) * 0.5f;
    	  }
	virtual float MonthlyPET (		// PET for month
    	  short const month,			//   month (1-12)
    	  float const latitude,			//   latitude (-90 to 90)
    	  float const fwloss);			//   Scaling factor for PET
	float StochasticPrecip (		// Random precip for month
    	  short const month);			//   month (0-11)
	void StochasticPrecip (			// Random precip values for yr.
	  float* precip);			//   stores precipitation

	//---- functions: Utility
	virtual void SynchronizeYear (		// match data with sim. time
	  ::TYear simYear);			// simulation year
	virtual void Clear ()			// "Clear" data members
	  {
	    Initialize ();
	  }

	//---- functions: Queries
	TYear CurrentYear () const		// Get the last year read
	  { return year; }
	TWeatherSrc WeatherSource () const	// Return source of data
    	  { return sourceData; }
	virtual bool IsEmpty () const = 0;	// True if no data

  protected:
	//---- constants
	static float const missingValue;	// missing value number
	static short const mpy;			// months per year (12)
	static float const minMonthlyPET;	// minimum monthly PET

	//--- data: constant parameters
	TCalendarTools * const calendarTools;	// calendar functions

	//---- data
	TYear year;			// current year
	TWeatherSrc sourceData;		// source of the data
	float				//--- monthly values for current year:
		precipCY[12],		// current mean precipitation
		minTempCY[12],		// minimum mean temp at 2 m (deg C)
		maxTempCY[12]; 		// maximum mean temp at 2 m (deg C)
	float				//--- monthly site parameter values:
		precipSP[12], 		// mean precipitation
    		precipStdDevSP[12], 	// mean precipitation: std. deviation
    		precipSkewSP[12], 	// mean precipitation: skewness
		minTempSP[12],		// minimum mean temp at 2 m (deg C)
		maxTempSP[12];		// maximum mean temp at 2 m (deg C)
					//--- annual values
	float meanAnnualTemp;		// mean annual temperature
	float meanAnnualPrecip;		// mean annual precipitation
	float maxAnnualMeanTemp;	// max. annual temperature
	float minAnnualMeanTemp;	// min. annual temperature
					//--- File access
	std::string fileName;		// weather file name

	//---- functions
	void Copy (				// Copy to this
	  TWeatherBase const & object);
	void CopyArray (			// Copy an array
	  float const* from,			//   source array
	  float* to,				//   destination array
	  short const count);			//   number to copy
	virtual void ClearData ();		// Erase data arrays
	void AnnualSummaryCalcs ();		// Calc annual summary values
	float MeanAnnualValue (			// Mean of annual data
	  float const* p) const;		//   data array
	bool IsComment (			// True if a comment char
	  char const * const s
	  ) const
	  {
	    // function source: weather data framework
	    return *s == '#' || *s == '!' || *s == ';' ||
	    	(*s == '/' && *(s + 1) == '/');
	  }

  private:
	//---- constants

	//---- data

	//---- functions
	void Initialize ();				// Initialize members
};

#endif // INC_TWeatherBase_h
