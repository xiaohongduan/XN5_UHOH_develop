
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  h2oll_ncid;			/* netCDF id */

/* variable ids */
int  avh2o1ll_id, avh2o2ll_id, avh2o3ll_id, asmosll_id, evapll_id, 
     petll_id, rwcfll_id, snlqll_id, snowll_id, stempll_id, stream1ll_id, 
     stream2ll_id, stream5ll_id, stream6ll_id, tranll_id, runoll_id;
int  timell_id, lat_id, lon_id;

/* create h2o.nc */
int
h2odef_ll(int *ntimes, int *nlat, int *nlon, char *history,
          float *opltim, float *qtime) {

   int   status, istart_year, iend_year, ii;
   float fill, fstart_year, fend_year;
   char  timeunits[25], temp[5];

   /* dimension ids */
   int  time_dim = 0;
   int  layer_dim = 0;
   int  lat_dim = 0;
   int  lon_dim = 0;

   /* variable shapes */
   int dims[4];

   /* Set fill, start_year, and end_year values */
   fill = NC_FILL_FLOAT;
   fstart_year = *opltim;
   fend_year = *qtime - 1;
   istart_year = fstart_year;
   iend_year = fend_year;

   for (ii = 0; ii < 25; ii++) {
     timeunits[ii] = '\0';
   }
   /* Get the start time for the time definition */
   sprintf(temp, "%d", istart_year); 
   strcat(timeunits, "days since ");
   strcat(timeunits, temp);
   strcat(timeunits, "-01-01");

   /* enter define mode */
   status = nc_create("h2oll.nc", NC_CLOBBER, &h2oll_ncid);
   if (status != NC_NOERR) handle_error("nc_create(h2o.nc)", status);

   /* define dimensions */
   status = nc_def_dim(h2oll_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(h2oll_ncid, "layer", 10L, &layer_dim);
   status = nc_def_dim(h2oll_ncid, "lat", (size_t) *nlat, &lat_dim);
   status = nc_def_dim(h2oll_ncid, "lon", (size_t) *nlon, &lon_dim);

   /* define variables */

   dims[0] = time_dim;
   status = nc_def_var (h2oll_ncid, "time", NC_INT, 1, dims, &timell_id);

   dims[0] = lat_dim;
   status = nc_def_var (h2oll_ncid, "lat", NC_FLOAT, 1, dims, &lat_id);

   dims[0] = lon_dim;
   status = nc_def_var (h2oll_ncid, "lon", NC_FLOAT, 1, dims, &lon_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "avh2o1", NC_FLOAT, 3, dims, &avh2o1ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "avh2o2", NC_FLOAT, 3, dims, &avh2o2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "avh2o3", NC_FLOAT, 3, dims, &avh2o3ll_id);

   dims[0] = time_dim;
   dims[1] = layer_dim;
   dims[2] = lat_dim;
   dims[3] = lon_dim;
   status = nc_def_var (h2oll_ncid, "asmos", NC_FLOAT, 4, dims, &asmosll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "evap", NC_FLOAT, 3, dims, &evapll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "pet", NC_FLOAT, 3, dims, &petll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "rwcf", NC_FLOAT, 3, dims, &rwcfll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "snlq", NC_FLOAT, 3, dims, &snlqll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "snow", NC_FLOAT, 3, dims, &snowll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "stemp", NC_FLOAT, 3, dims, &stempll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "stream1", NC_FLOAT, 3, dims, &stream1ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "stream2", NC_FLOAT, 3, dims, &stream2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "stream5", NC_FLOAT, 3, dims, &stream5ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "stream6", NC_FLOAT, 3, dims, &stream6ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "tran", NC_FLOAT, 3, dims, &tranll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (h2oll_ncid, "runoff", NC_FLOAT, 3, dims, &runoll_id);

   /* assign attributes */
   status = nc_put_att_text (h2oll_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (h2oll_ncid, timell_id, "long_name", strlen("Time"), "Time");
   status = nc_put_att_text (h2oll_ncid, timell_id, "units", strlen(timeunits), timeunits);
   status = nc_put_att_text (h2oll_ncid, timell_id, "time_step", strlen("monthly"), "monthly");
   status = nc_put_att_text (h2oll_ncid, timell_id, "calendar", strlen("gregorian"), "gregorian");
   status = nc_put_att_int (h2oll_ncid, timell_id, "start_year", NC_INT, 1, &istart_year);
   status = nc_put_att_int (h2oll_ncid, timell_id, "end_year", NC_INT, 1, &iend_year);

   status = nc_put_att_text (h2oll_ncid, lat_id, "long_name", strlen("Latitude"), "Latitude");
   status = nc_put_att_text (h2oll_ncid, lat_id, "units", strlen("degrees_north"), "degrees_north");
   status = nc_put_att_text (h2oll_ncid, lat_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (h2oll_ncid, lat_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (h2oll_ncid, lon_id, "long_name", strlen("Longitude"), "Longitude");
   status = nc_put_att_text (h2oll_ncid, lon_id, "units", strlen("degrees_east"), "degrees_east");
   status = nc_put_att_text (h2oll_ncid, lon_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (h2oll_ncid, lon_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (h2oll_ncid, avh2o1ll_id, "long_name", 
	strlen("growth_h2o"), "growth_h2o");
   status = nc_put_att_text (h2oll_ncid, avh2o1ll_id, "units", 
	strlen("cm"), "cm");
   status = nc_put_att_float(h2oll_ncid, avh2o1ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, avh2o2ll_id, "long_name", 
	strlen("survival_h2o"), "survival_h2o");
   status = nc_put_att_text (h2oll_ncid, avh2o2ll_id, "units", strlen("cm"), "cm");
   status = nc_put_att_float(h2oll_ncid, avh2o2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, avh2o3ll_id, "long_name", 
	strlen("2_layer_h2o"), "2_layer_h2o");
   status = nc_put_att_text (h2oll_ncid, avh2o3ll_id, "units", strlen("cm"), "cm");
   status = nc_put_att_float(h2oll_ncid, avh2o3ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, asmosll_id, "long_name", 
	strlen("soil_h2o"), "soil_h2o");
   status = nc_put_att_text (h2oll_ncid, asmosll_id, "units", strlen("cm"), "cm");
   status = nc_put_att_float(h2oll_ncid, asmosll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, evapll_id, "long_name", 
	strlen("evaporation"), "evaporation");
   status = nc_put_att_text (h2oll_ncid, evapll_id, "units", strlen("cm/mo"), "cm/mo");
   status = nc_put_att_float(h2oll_ncid, evapll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, petll_id, "long_name", 
	strlen("pot_evapotranspiration"), "pot_evapotranspiration");
   status = nc_put_att_text (h2oll_ncid, petll_id, "units", strlen("cm/mo"), "cm/mo");
   status = nc_put_att_float(h2oll_ncid, petll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, rwcfll_id, "long_name", 
	strlen("relative_water_content"), "relative_water_content");
   status = nc_put_att_text (h2oll_ncid, rwcfll_id, "units", strlen("unitless"), "unitless");
   status = nc_put_att_float(h2oll_ncid, rwcfll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, snlqll_id, "long_name", 
	strlen("liquid_h2o_snow"), "liquid_h2o_snow");
   status = nc_put_att_text (h2oll_ncid, snlqll_id, "units", strlen("cm"), "cm");
   status = nc_put_att_float(h2oll_ncid, snlqll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, snowll_id, "long_name", 
	strlen("snow"), "snow");
   status = nc_put_att_text (h2oll_ncid, snowll_id, "units", strlen("cm"), "cm");
   status = nc_put_att_float(h2oll_ncid, snowll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, stempll_id, "long_name", 
	strlen("soil_temperature"), "soil_temperature");
   status = nc_put_att_text (h2oll_ncid, stempll_id, "units", strlen("cm"), "cm");
   status = nc_put_att_float(h2oll_ncid, stempll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, stream1ll_id, "long_name", 
	strlen("stream_flow"), "stream_flow");
   status = nc_put_att_text (h2oll_ncid, stream1ll_id, "units", strlen("cm/mo"), "cm/mo");
   status = nc_put_att_float(h2oll_ncid, stream1ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, stream2ll_id, "long_name", 
	strlen("N_inorganic_leaching_flow"), "N_inorganic_leaching_flow");
   status = nc_put_att_text (h2oll_ncid, stream2ll_id, "units", 
	strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(h2oll_ncid, stream2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, stream5ll_id, "long_name", 
	strlen("C_organic_leaching_flow"), "C_organic_leaching_flow");
   status = nc_put_att_text (h2oll_ncid, stream5ll_id, "units", 
	strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(h2oll_ncid, stream5ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, stream6ll_id, "long_name", 
	strlen("N_organic_leaching_flow"), "N_organic_leaching_flow");
   status = nc_put_att_text (h2oll_ncid, stream6ll_id, "units", 
	strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(h2oll_ncid, stream6ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, tranll_id, "long_name", 
	strlen("transpiration"), "transpiration");
   status = nc_put_att_text (h2oll_ncid, tranll_id, "units", strlen("cm/mo"), "cm/mo");
   status = nc_put_att_float(h2oll_ncid, tranll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (h2oll_ncid, runoll_id, "long_name", 
	strlen("runoff"), "runoff");
   status = nc_put_att_text (h2oll_ncid, runoll_id, "units", strlen("cm/mo"), "cm/mo");
   status = nc_put_att_float(h2oll_ncid, runoll_id, "_FillValue", NC_FLOAT, 1, &fill);

   /* leave define mode */
   status = nc_enddef (h2oll_ncid);
   return 0;
}
