
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  livc_ncid;			/* netCDF id */

/* variable ids */
int  aglivc_id, bglivc_id, stdedc_id, rleavc_id, frootc_id, 
     fbrchc_id, rlwodc_id, crootc_id, wood1c_id, wood2c_id, 
     wood3c_id, pltlig1_id, pltlig2_id;

int
livcdef(int *ntimes, char *history) {		/* create livc.nc */

   int status;

   /* dimension ids */
   int  time_dim = 0;
   int  cell_dim = 0;

   /* variable shapes */
   int dims[2];

   /* enter define mode */
   status = nc_create("livc.nc", NC_CLOBBER, &livc_ncid );
   if (status != NC_NOERR) handle_error("nc_create(livc.nc)", status);

   /* define dimensions */
   status = nc_def_dim(livc_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(livc_ncid, "cell", NC_UNLIMITED, &cell_dim);

   /* define variables */

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livc_ncid, "aglivc", NC_FLOAT, 2, dims, &aglivc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livc_ncid, "bglivc", NC_FLOAT, 2, dims, &bglivc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livc_ncid, "stdedc", NC_FLOAT, 2, dims, &stdedc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livc_ncid, "rleavc", NC_FLOAT, 2, dims, &rleavc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livc_ncid, "frootc", NC_FLOAT, 2, dims, &frootc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livc_ncid, "fbrchc", NC_FLOAT, 2, dims, &fbrchc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livc_ncid, "rlwodc", NC_FLOAT, 2, dims, &rlwodc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livc_ncid, "crootc", NC_FLOAT, 2, dims, &crootc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livc_ncid, "wood1c", NC_FLOAT, 2, dims, &wood1c_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livc_ncid, "wood2c", NC_FLOAT, 2, dims, &wood2c_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livc_ncid, "wood3c", NC_FLOAT, 2, dims, &wood3c_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livc_ncid, "pltlig1", NC_FLOAT, 2, dims, &pltlig1_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (livc_ncid, "pltlig2", NC_FLOAT, 2, dims, &pltlig2_id);

   /* assign attributes */
   status = nc_put_att_text (livc_ncid, NC_GLOBAL, "history", strlen(history), history);
   status = nc_put_att_text (livc_ncid, aglivc_id, "long_name", 
        strlen("above_ground_live_carbon"), "above_ground_live_carbon");
   status = nc_put_att_text (livc_ncid, aglivc_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livc_ncid, bglivc_id, "long_name", 
	strlen("below_ground_live_carbon"), "below_ground_live_carbon");
   status = nc_put_att_text (livc_ncid, bglivc_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livc_ncid, stdedc_id, "long_name", 
	strlen("standing_dead_carbon"), "standing_dead_carbon");
   status = nc_put_att_text (livc_ncid, stdedc_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livc_ncid, rleavc_id, "long_name", 
	strlen("live_leaf_carbon"), "live_leaf_carbon");
   status = nc_put_att_text (livc_ncid, rleavc_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livc_ncid, frootc_id, "long_name", 
	strlen("live_fine_root_carbon"), "live_fine_root_carbon");
   status = nc_put_att_text (livc_ncid, frootc_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livc_ncid, fbrchc_id, "long_name", 
	strlen("live_fine_branch_carbon"), "live_fine_branch_carbon");
   status = nc_put_att_text (livc_ncid, fbrchc_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livc_ncid, rlwodc_id, "long_name", 
	strlen("live_large_wood_carbon"), "live_large_wood_carbon");
   status = nc_put_att_text (livc_ncid, rlwodc_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livc_ncid, crootc_id, "long_name", 
	strlen("live_coarse_root_carbon"), "live_coarse_root_carbon");
   status = nc_put_att_text (livc_ncid, crootc_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livc_ncid, wood1c_id, "long_name", 
	strlen("dead_fine_branch_carbon"), "dead_fine_branch_carbon");
   status = nc_put_att_text (livc_ncid, wood1c_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livc_ncid, wood2c_id, "long_name", 
	strlen("dead_large_wood_carbon"), "dead_large_wood_carbon");
   status = nc_put_att_text (livc_ncid, wood2c_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livc_ncid, wood3c_id, "long_name", 
	strlen("dead_coarse_root_carbon"), "dead_coarse_root_carbon");
   status = nc_put_att_text (livc_ncid, wood3c_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_text (livc_ncid, pltlig1_id, "long_name", 
	strlen("lignin_fraction_of_surface_material"), "lignin_fraction_of_surface_material");
   status = nc_put_att_text (livc_ncid, pltlig1_id, "units", 
	strlen("unitless"), "unitless");
   status = nc_put_att_text (livc_ncid, pltlig2_id, "long_name", 
	strlen("lignin_fraction_of_sub-surface_material"), 
	"lignin_fraction_of_sub-surface_material");
   status = nc_put_att_text (livc_ncid, pltlig2_id, "units", 
	strlen("unitless"), "unitless");

   /* leave define mode */
   status = nc_enddef (livc_ncid);
   return 0;
}
