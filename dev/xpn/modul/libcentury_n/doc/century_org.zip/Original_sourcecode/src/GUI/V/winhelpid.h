/*	-----------------------------------------------------------------------
	Century Model Interface
	File: winhelpid.h
	Help file topic-context ID mapping.

	Last Modified: 16Apr98 - TE Hilinski
	-----------------------------------------------------------------------
 */
 
/*-----	Help Menu Items			-----*/
#define IDH_GETTING_STARTED		0x0002	/* Help | Getting Started */

/*-----	User Preferences Dialog		-----*/
#define IDH_USER_PREFERENCES_DLG	0x0010	/* Options | User Preferences */

/*-----	Management Editor Dialog	-----*/
#define IDH_SIMULATION_INFO		0x0020	/* Simulation Information tab */
#define IDH_DEFINE_BLOCKS		0x0022	/* Define Blocks tab */
#define IDH_USE_BLOCKS			0x0024	/* Use Blocks tab */

/*-----	Site Parameters Editor Dialog	-----*/
#define IDH_EDIT_SITE_PARAMS_DLG	0x0030

/*-----	Site Parameters "From Library" Dialog	-----*/
#define IDH_SITE_FROMLIB_DLG		0x0040

/*-----	Management Scheme "From Library" Dialog	-----*/
#define IDH_MGMT_FROMLIB_DLG		0x0050

/*-----	End of winhelpid.h -----*/
