
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include "netcdf.h"
#include "wrtcdf.h"

int
write_livc(float livc[][12])
{
        int status;
        float *p = (float *) livc;

	/* Write output to NetCDF file */
	status = nc_put_vara_float(livc_ncid, aglivc_id, start, count, p);
	status = nc_put_vara_float(livc_ncid, bglivc_id, start, count, p + 12);
	status = nc_put_vara_float(livc_ncid, stdedc_id, start, count, p + 24);
	status = nc_put_vara_float(livc_ncid, rleavc_id, start, count, p + 36);
	status = nc_put_vara_float(livc_ncid, frootc_id, start, count, p + 48);
	status = nc_put_vara_float(livc_ncid, fbrchc_id, start, count, p + 60);
	status = nc_put_vara_float(livc_ncid, rlwodc_id, start, count, p + 72);
	status = nc_put_vara_float(livc_ncid, crootc_id, start, count, p + 84);
	status = nc_put_vara_float(livc_ncid, wood1c_id, start, count, p + 96);
	status = nc_put_vara_float(livc_ncid, wood2c_id, start, count, p + 108);
	status = nc_put_vara_float(livc_ncid, wood3c_id, start, count, p + 120);
	status = nc_put_vara_float(livc_ncid, pltlig1_id, start, count, p + 132);
	status = nc_put_vara_float(livc_ncid, pltlig2_id, start, count, p + 144);

	/* Reset memory for variable livc */
	 memset(p, '\0', (sizeof(float) * 13 * 12));

	return 0;
}
