// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  allocleaf1st.cpp
//	Class:	  TDayCent
//	Function: AllocateFineRootsFirst
//
//	Description:
//
//      Allocate carbon first for fine roots (FROOT), then for leaves (LEAF),
//      then for woody components of trees (FBRCH, LWOOD, and CROOT).
//
//      Author: Melannie Hartman, melannie@nrel.colostate.edu 07June2001
// ----------------------------------------------------------------------------
//	History:
// ----------------------------------------------------------------------------
//	Copyright 2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Notes:
//      * Assuming enum { LEAF, FROOT, FBRCH, LWOOD, CROOT, FPARTS };
// ----------------------------------------------------------------------------

#include "TDayCent.h"
#include <sstream>

void TDayCent::AllocateFineRootsFirst(
    int const indexFCAF,      // index to forest C allocation fractions (0=new, 1=mature)
    float const cprodf,       // total potential forest production (gC/m^2)
    float treeCfrac[FPARTS])  // frac of carbon allocated to each tree part (0-1)
{
    treeCfrac[FROOT] = FractionRootAllocation(SysType_Forest,
            parfs.a2drat, parfs.pptprd);

    float cprodfLeftToAllocate = cprodf * (1.0f - treeCfrac[FROOT]);
    float remCfrac = 1.0 - treeCfrac[FROOT];

    treeCfrac[LEAF] = std::min(remCfrac, FractionLeafAllocation(forestC.rleavc,
            forestC.rlwodc, cprodfLeftToAllocate, cprodf));

    remCfrac = 1.0 - treeCfrac[FROOT] - treeCfrac[LEAF];
    //if (remCfrac < 0.0)
    //{
    //    cout << "treeCfrac[FROOT] = " << treeCfrac[FROOT] << endl;
    //    cout << "treeCfrac[LEAF] = " << treeCfrac[LEAF] << endl;
    //}
    if ( !AmountIsSignificant( std::fabs(remCfrac) ) ) remCfrac = 0.0;
    Assert (remCfrac >= 0.0);

    if ( !AmountIsSignificant(remCfrac) )
    {
        //  for FBRCH, LWOOD, and CROOT ...
        for ( short ipart = FBRCH; ipart <= CROOT; ++ipart)
        {
            treeCfrac[ipart] = 0.0;
        }
    }
    else
    {
        //  for FBRCH, LWOOD, and CROOT ...
	float totCup = 0.0f;
        for ( short ipart = FBRCH; ipart <= CROOT; ++ipart)
        {
            treeCfrac[ipart] = fcfrac_ref (ipart, indexFCAF);
            totCup += treeCfrac[ipart];
        }
        if (totCup > 0.0)
        {
            //  for FBRCH, LWOOD, and CROOT ...
            for ( short ipart = FBRCH; ipart <= CROOT; ++ipart)
            {
                //treeCfrac[ipart] = remCfrac * treeCfrac[ipart]/totCup;
                treeCfrac[ipart] *= remCfrac / totCup;
            }
        }
        else
        {
            std::ostringstream os;
            os << "Error in TreeDynamCarbonAlloc: "
               << std::endl;
            os << "FCFRAC(FBRCH) + FCFRAC(LWOOD) + FCFRAC(CROOT) = "
               << totCup << ", and should be > 0.0 for tree."
               << std::endl;
            ThrowDayCentException ( TDayCentException::DCE_VORTRE,
            				os.str().c_str() );
        }
    }
}

//--- end of file ---
