// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  cycle.cpp
//	Class:	  TCentury
//	Function: InitMonthlyCycle
//
//	Description:
//	Determine relative water content, available water, and
//	decomposition factor related to temperature and water.
//	Initialize mineralization accumulators.
//	Compute potential production.
// ----------------------------------------------------------------------------
//	History:
//	Mar00   Tom Hilinski, tom.hilinski@colostate.edu
//	* Consolidated calc of wfunc in inline function WaterEffectOnDecomp.
//	Dec00   Tom Hilinski, tom.hilinski@colostate.edu
//	* Mod'd to work properly with microcosm (constant soil temp & water).
//	Jul02   Melannie Hartman, melannie@nrel.colostate.edu
//	* Added nps.volpl initialization.
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include <cmath>

// debugging
// Approx. fuction from daycent5

float WaterEffectOnDecomp_DayCent5 (
	float const avgWFPS)		// average wfps in sim. layer (0-1)
{
    float a, b, c, d;   // intermediate variable for calculations
	// case MEDIUM:
            a = 0.60f;
            b = 1.27f;
            c = 0.0012f;
            d = 2.84f;

    // exponent bases
    float const base1 =((avgWFPS - b) / (a-b));
    float const base2 =((avgWFPS - c) / (a-c));
    // exponents
    float const e1 = d * ((b-a)/(a-c));
    float const e2 = d;

    Assert (base1 > 0.0f);
    Assert (base2 > 0.0f);
    float wfunc = ( std::pow (base1, e1) * std::pow (base2, e2) );

    Assert (wfunc >= 0.0f);
    if ((wfunc - 1.0f) > 1.0E-05f)
    {
	/*
	iterationData.ms
	  << "TDayCent::WaterEffectOnDecomp::wfunc = "
	  << std::scientific << std::showpoint
	  << wfunc
	  << std::endl;
	asynchCom.SendMessage ( iterationData.ms.str().c_str() );
	iterationData.ms.seekp (0, ios::beg);
	*/
	Assert ((wfunc - 1.0f) < 1.0E-05f);
        wfunc = 1.0f;
    }
    // To Do: throw exception for out-of-range wfunc

    return wfunc;
}

inline static
float catanf (
    float const soilTemp,	// soil temperature
    float const teff1,	// fix.100 TEFF(1)
    float const teff2,	// fix.100 TEFF(2)
    float const teff3,	// fix.100 TEFF(3)
    float const teff4)	// fix.100 TEFF(4)
{
    double const M_PI = 		// apple pi
	3.14159265358979323846;
    return teff2 + (teff3 / M_PI) *
    	   std::atan ( M_PI * teff4 * (soilTemp - teff1) );
}

float TempEffectOnDecomp_DayCent5 (
	float const soilTemp)			// soil temperature (C)
{
    float const teff[4] = { 15.40, 11.75, 29.70, 0.031 };
    float const valueAt30C =		// value of the numerator at 30 deg C
    	::catanf (30.0f, teff[0], teff[1], teff[2], teff[3]);
    float const tcalc =
      std::min ( 1.2f,
	std::max (
    		0.01f,
        	::catanf ( soilTemp, teff[0], teff[1], teff[2], teff[3] ) /
        	  valueAt30C ) );
    return tcalc;
}




void TCentury::InitMonthlyCycle ()
{
    // Initialize monthly output variables - all systems
    nps.nfix = 0.0f;
    nps.volex = 0.0f;
    nps.volgm = 0.0f;

    // Initialize monthly output variables - crop/grass/savanna
    if ( sysType.IsCropGrass() || sysType.IsSavanna() )
    {
	cropC.cprodc = 0.0f;
	for (short e = 0; e < site.nelem; ++e)
		nps.eprodc[e] = 0.0f;
	nps.volpl = 0.0f;
    }

    // Initialize monthly output variables - tree/savanna
    if ( sysType.IsForest() || sysType.IsSavanna() )
    {
    	for (short element = 0; element < site.nelem; ++element)
    	{
		nps.eprodf[element] = 0.0f;
		for (short part = 0; part < FPARTS; ++part)
			elementUptake_ref (part, element) = 0.0f;
    	}
    }

    //--- Call schedl to determine scheduling options for this month
    Schedule (wt.stemp);

    //--- Initialize production accumulators
    // For crops, annual accumulation starts at the month of planting.
    // For grasses and forest, annual accumulation starts at the beginning of
    // the growing season.
    if ( sched->DoingPlanting() ||
    	 sched->DoingStartCropGrassGrowth() ||
         sched->DoingStartTreeGrowth() ||
         st->month == ::Jan )
    {
	InitAnnualProdAccum ();
    }

    //--- Initialize weather and water
    if ( !SimMicrocosm() )
    {
	wt.tave = weather->MeanMonthlyTemp (st->month);	// Avg air temp at 2m
	wt.rain = weather->Precip (st->month);
	wt.pet = monthlyPET.PET (
		siteEnv.GetLatitude(),
		fixed.fwloss[3],		// PET loss factor
		weather->TempMin(st->month),
		weather->TempMax(st->month),
		weather->MinAnnualMeanTemp(),
		weather->MaxAnnualMeanTemp()
		/* elevation defaults to 0 */ );
	// If irrigating, determine actual amount of irrigation, irract
	if ( sched->DoingIrrigation() )
		wt.irract = Irrigate (st->month);
    }
    else	// simulating a microcosm
    {
 	wt.pet = 15.0f;		// constant temperature and soil moisture
    }

    // Ratio of total available water to PET
    Assert (wt.pet != 0.0f);
    float const ratioPrecPET = (wt.avh2o[2] + wt.rain + wt.irract) / wt.pet;

    //--- If the system has a microcosm, skip the rest of the routine
    if ( SimMicrocosm() )
    {
	wt.anerb = AnaerobicImpact (ratioPrecPET);
	if ( sched->DoingCultivation() )
	    for (short i = 0; i < 4; ++i)
		soilC.cltfac[i] = parcp.clteff[i];
	else
	    for (short i = 0; i < 4; ++i)
		soilC.cltfac[i] = 1.0f;
	return;
    }

    // If planting or growing month, calculate growing season precipitation
    if ( sched->DoingPlanting() || sched->DoingStartCropGrassGrowth() )
	parcp.grwprc = weather->GrowingSeasonPrecip (st->month);

    //--- Initialize monthly mineralization accumulators for each element.
    for (short element = 0; element < site.nelem; ++element)
    {
	for ( short layer = SRFC; layer <= SOIL; ++layer )
	{
	    strmnr_ref (layer, element) = 0.0f;
	    metmnr_ref (layer, element) = 0.0f;
	    s1mnr_ref (layer, element) = 0.0f;
	}
	nps.s2mnr[element] =  nps.s3mnr[element] = 0.0f;
	nps.gromin[element] = 0.0f;
	nps.w1mnr[element] =  nps.w2mnr[element] =  nps.w3mnr[element] = 0.0f;
    }

    //--- biomass
    float
    	agLiveBiomass,			// monthly aboveground live biomass
    	surfaceLitterBiomass,		// monthly litter biomass
    	standDeadBiomass;		// monthly standing dead biomass
    if ( sysType.IsForest() )
    {
	agLiveBiomass = forestC.rleavc * 2.5f;
	// Second mod to remove effect of woodc -rm 1/91
	surfaceLitterBiomass = (soilC.strucc[SRFC] + soilC.metabc[SRFC]) * 2.0f;
	standDeadBiomass = 0.0f;
    }
    else if ( sysType.IsSavanna() )
    {
	agLiveBiomass = (forestC.rleavc + cropC.aglivc) * 2.5f;
	surfaceLitterBiomass = (soilC.strucc[SRFC] + soilC.metabc[SRFC]) * 2.0f;
	standDeadBiomass = cropC.stdedc * 2.5f;
    }
    else // system = crop/grass
    {
	agLiveBiomass = cropC.aglivc * 2.5f;
	surfaceLitterBiomass = (soilC.strucc[SRFC] + soilC.metabc[SRFC]) * 2.5f;
	standDeadBiomass = cropC.stdedc * 2.5f;
    }
    float biomass = std::min ( 			// total aboveground biomass
    	(agLiveBiomass + standDeadBiomass +
    		fixed.elitst * surfaceLitterBiomass),
    	fixed.pmxbio );

    //--- Calculate temperature
    // Maximum mean monthly temperature
    float tmxs = weather->TempMax(st->month) + 25.4f /
	    (std::exp (weather->TempMax(st->month) * -0.20f) * 18.0f + 1.0f) *
	    (std::exp (fixed.pmxtmp * biomass) - 0.13f);
    // Minimum mean monthly temperature
    float tmns = weather->TempMin(st->month) +
			fixed.pmntmp * biomass - 1.78f;
    // Average surface temperature
    // Note: soil temperature used to calculate potential production
    //     does not take into account the effect of snow (AKM)
    wt.stemp = (tmxs + tmns) * 0.5f;

    //--- Potential Production
    // Uses the current month's soil temperature (AKM).
    // Determine potential production if it's during the growth season.
    float potentialProduction = 0.0f;		// potential production
    float canopyCover = 0.0f;		// canopy cover
    // 1. For a savana system...
    if (sysType.IsSavanna())	// Added below for savanna model (rm)
    {
	// wood biomass = (forestC.fbrchc + forestC.rlwodc) * 2.0
	param.trbasl = (forestC.fbrchc + forestC.rlwodc) * 2.0f / parfs.basfct;
	if (param.trbasl == 0.0f)
	    param.trbasl = 0.1f;
	canopyCover = 1.0f - std::exp (param.trbasl * -0.064f);
    }
    // 2. For a Crop System...
    if ( parcp.IsGrowing() )
    {
	potentialProduction = CropGrassProductionPotential (canopyCover);
    }
    if ( sysType.IsCropGrass() )
    {
	// agLiveBiomass += potentialProduction * 0.25f * 2.5f;
	agLiveBiomass += potentialProduction * 0.625f;
    }
    // 3. For a Forest System...
    if ( parfs.IsGrowing() )
	ForestProductionPotential ();

    //--- submodel: soil temperature
    SoilTemperatureModel (st->month);

    //--- submodel: soil water
    wt.evap = wt.tran = wt.pttr = wt.runoff = 0.0f;
    soil->ResetMonthly ();

    SoilWaterModel ( st->month,
		     agLiveBiomass, surfaceLitterBiomass, standDeadBiomass,
		     wt.rain + wt.irract,
		     wt.pet,
		     /* following are modified */
		     wt.evap, wt.tran, wt.pttr, wt.snow, wt.runoff );

    // Calc stream flow
    wt.stream[0] = soil->GetStormFlow() + soil->GetBaseFlow() + wt.runoff;
    // save transpiration and potential transpiration for harvest
    param.hpttr[st->month - 1] = wt.pttr;
    param.htran[st->month - 1] = wt.tran;
    // Update some of the other water variables
    UpdateWaterVariables ();

    //--- Compute daylength for use in phenology of trees
    siteEnv.GetDayLength (st->month);

    //--- Initialize erosion and deposition monthly variables
    soilC.eroC = soilC.depC = 0.0f;

    //--- Decomposition effects

    // Effect of moisture on decomposition
    // Changed coefficients in both wfunc equations  -rm 6/91
    // Relative water content -- rwcf
    if (fixed.idef == 1)		// wfunc option: linear; use rwcf
    {
	wfunc = WaterEffectOnDecomp ();
	// wfunc = WaterEffectOnDecomp_DayCent5 (
	// 	soil->PlantExtractableWater(0.0f, wt.simDepth) );
    }
    else if (fixed.idef == 2)		// wfunc option: ratio rain:PET
    {
	Assert (ratioPrecPET >= 0.0f);
	// Check added to handle underflow potential in exp intrinsic
	if (ratioPrecPET > 2.0f)	// exp(2*-8.5) = 4.140e-8
	    wfunc = 1.0f;
	else				// 1 / (exp(ratio * -8.5) * 30 + 1)
	{
	    wfunc = 1.0f / (std::exp (ratioPrecPET * -8.5f) * 30.0f + 1.0f);
	}
    }
    else
    {
	ThrowCentException (TCentException::CE_PARMIV, "IDEF != 1 or 2" );
    }

    // Effect impact of anerobic conditions on decomposition
    wt.anerb = AnaerobicImpact (ratioPrecPET);

    // Combined effects of temperature and moisture
    // Bound defac to >= 0.0   12/21/92
    wt.defac = std::max ( TempEffectOnDecomp(wt.stemp) * wfunc, 0.0f );
    // wt.defac = TempEffectOnDecomp_DayCent5 (wt.stemp);
    comput.defacm[st->month - 1] = wt.defac;

    // Effect of cultivation on decomposition (used in decomp routine)
    // vk 03-13-91
    // cltfac is this month's effect of cultivation on decomposition
    // of som1, som2, som3, and structural.  It is set to clteff
    // in months when cultivation occurs; otherwise it equals 1.
    // clteff is the effect of cultivation on decomposition read from
    // the cult.100 file
    if ( sched->DoingCultivation() )
	for (short i = 0; i < 4; ++i)
	    soilC.cltfac[i] = parcp.clteff[i];
    else
	for (short i = 0; i < 4; ++i)
	    soilC.cltfac[i] = 1.0f;
}
//--- end of file ---
