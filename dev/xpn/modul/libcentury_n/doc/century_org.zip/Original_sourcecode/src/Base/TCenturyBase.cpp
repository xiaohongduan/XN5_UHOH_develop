// ----------------------------------------------------------------------------
//	Copyright (c) 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCenturyBase.cpp
//	Class:	  TCenturyBase
//
//	Description:
//	Base class for the various derivations of the Century model.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, August 2001
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TCenturyBase.h"
#include "TCentException.h"
#include "TCentBaseSpecialized.h"	// specializations
#include "TEventDBList.h"

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

MY_TEMPLATE_DECLARATION
float const TCENTURYBASE::MAXSIMDEPTH = 	// Max sim layer depth
	30.0f;
MY_TEMPLATE_DECLARATION
double const TCENTURYBASE::M_PI = 		// apple pi
	3.14159265358979323846;
MY_TEMPLATE_DECLARATION
float const TCENTURYBASE::PEEDEE =		// PeeDee 14C standard
	0.0112372f;
// Erosion enrichment factors specify the increase/decrease of SOC with
// depth in the simulation layer.
MY_TEMPLATE_DECLARATION
float const TCENTURYBASE::MINEF =	// Minimum erosion enrichment factor
	0.1f;
MY_TEMPLATE_DECLARATION
float const TCENTURYBASE::MAXEF = 	// Maximum erosion enrichment factor
	2.0f;

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

MY_TEMPLATE_DECLARATION
TCENTURYBASE::TCenturyBase (
	TSitePtr useSite,				// site params.
	TMgmtPtr useMgmt,				// management
	TOutputPtr useOutput,				// output destination
	TParamDBListPtr useParamDbList,	// parameter databases
	bool const outputFlag,				// doing output files?
	char const * const theUserName,			// user name
	bool const timeThisRun,				// time model run?
	TAsynchCommunication * const useAsynchCom,	// asynch. com.
	TDebugInfo const * const useDebugFlags)		// debug flags
	: nrel::eco::TEcosystemModelBase (0, 0, timeThisRun, 0, useAsynchCom),
	  TFlowsSchedulable (),
	  centSite (useSite),
	  centMgmt (useMgmt),
	  output (useOutput),
	  doOutput (outputFlag),
	  userName (theUserName),
	  debugInfo (*useDebugFlags),
	  paramDbList (useParamDbList),
	  // Allocate memory for monthly output variables classes
	  wtPtr ( new TWaterTemp() ),
	  wt (*wtPtr),
	  soilCPtr ( new TSoilC() ),
	  soilC (*soilCPtr),
	  cropCPtr ( new TCropGrassC() ),
	  cropC (*cropCPtr),
	  forestCPtr ( new TForestC() ),
	  forestC (*forestCPtr),
	  co2Ptr ( new TCO2() ),
	  co2 (*co2Ptr),
	  npsPtr ( new TNPS() ),
	  nps (*npsPtr),
	  // Allocate memory for parameters structs
	  computPtr ( new Tcomput() ),
	  comput (*computPtr),
	  fixedPtr (
	  	new TMyFixed( useParamDbList->Get (TEventDBList::DBI_Fix) ) ),
	  fixed (*fixedPtr),
	  forremPtr ( new Tforrem() ),
	  forrem (*forremPtr),
	  paramPtr ( new TMyParams() ),
	  param (*paramPtr),
	  parcpPtr ( new TMyParcp() ),
	  parcp (*parcpPtr),
	  parfsPtr ( new TMyParfs() ),
	  parfs (*parfsPtr),
	  potentProdPtr ( new TPotentialProduction() ),
	  potentProd (*potentProdPtr),
	  sitePtr ( new TSite() ),
	  site (*sitePtr),
	  waterPtr ( new TWater() ),
	  water (*waterPtr)
{
    //try	// don't let constructor throw an exception
    //{
	CheckSitePtr (useSite);
	CheckManagementPtr (useMgmt);
	Constructor ();
	CheckOutputPtr (output);
    //}
    //catch (...)
    //{
    //	state.SetError (TModelState::Error_Constructor);
    //}
}

MY_TEMPLATE_DECLARATION
TCENTURYBASE::TCenturyBase (
	TSitePtr useSite,				// site params.
	TMgmtPtr useMgmt,				// management
	TOutputPtr useOutput,				// output destination
	TParamDBListPtr useParamDbList,			// parameter databases
	bool const outputFlag,				// doing output files?
	std::string const & theUserName,		// user name
	bool const timeThisRun,				// time model run?
	TAsynchCommunication * const useAsynchCom,	// asynch. com.
	TDebugInfo const * const useDebugFlags)		// debug flags
	: nrel::eco::TEcosystemModelBase (0, 0, timeThisRun, 0, useAsynchCom),
	  TFlowsSchedulable (),
	  centSite (useSite),
	  centMgmt (useMgmt),
	  output (useOutput),
	  doOutput (outputFlag),
	  userName (theUserName),
	  debugInfo (*useDebugFlags),
	  paramDbList (useParamDbList),
	  // Allocate memory for monthly output variables classes
	  wtPtr ( new TWaterTemp() ),
	  wt (*wtPtr),
	  soilCPtr ( new TSoilC() ),
	  soilC (*soilCPtr),
	  cropCPtr ( new TCropGrassC() ),
	  cropC (*cropCPtr),
	  forestCPtr ( new TForestC() ),
	  forestC (*forestCPtr),
	  co2Ptr ( new TCO2() ),
	  co2 (*co2Ptr),
	  npsPtr ( new TNPS() ),
	  nps (*npsPtr),
	  // Allocate memory for parameters structs
	  computPtr ( new Tcomput() ),
	  comput (*computPtr),
	  fixedPtr (
	  	new TMyFixed( useParamDbList->Get (TEventDBList::DBI_Fix) ) ),
	  fixed (*fixedPtr),
	  forremPtr ( new Tforrem() ),
	  forrem (*forremPtr),
	  paramPtr ( new TMyParams() ),
	  param (*paramPtr),
	  parcpPtr ( new TMyParcp() ),
	  parcp (*parcpPtr),
	  parfsPtr ( new TMyParfs() ),
	  parfs (*parfsPtr),
	  potentProdPtr ( new TPotentialProduction() ),
	  potentProd (*potentProdPtr),
	  sitePtr ( new TSite() ),
	  site (*sitePtr),
	  waterPtr ( new TWater() ),
	  water (*waterPtr)
{
    //try	// don't let constructor throw an exception
    //{
	CheckSitePtr (useSite);
	CheckManagementPtr (useMgmt);
	Constructor ();
	CheckOutputPtr (output);
    //}
    //catch (...)
    //{
    //	state.SetError (TModelState::Error_Constructor);
    //}
}

MY_TEMPLATE_DECLARATION
TCENTURYBASE::TCenturyBase (				// copy constructor
	TCENTURYBASE const & object)
	: nrel::eco::TEcosystemModelBase (object),
	  TFlowsSchedulable (object),
	  centSite (object.centSite),
	  centMgmt (object.centMgmt),
	  output (object.output),
	  userName (object.userName),
	  doOutput (object.doOutput),
	  paramDbList (object.paramDbList),
	  //--- data - output variables
	  wtPtr ( new TWaterTemp (object.wt) ),
	  wt (*wtPtr),
	  soilCPtr ( new TSoilC (object.soilC) ),
	  soilC (*soilCPtr),
	  cropCPtr ( new TCropGrassC (object.cropC) ),
	  cropC (*cropCPtr),
	  forestCPtr ( new TForestC (object.forestC) ),
	  forestC (*forestCPtr),
	  co2Ptr ( new TCO2 (object.co2) ),
	  co2 (*co2Ptr),
	  npsPtr ( new TNPS (object.nps) ),
	  nps (*npsPtr),
	  //--- data - internal variables - structs
	  computPtr ( new Tcomput (object.comput) ),
	  comput (*computPtr),
	  fixedPtr ( new TMyFixed (object.fixed) ),
	  fixed (*fixedPtr),
	  forremPtr ( new Tforrem (object.forrem) ),
	  forrem (*forremPtr),
	  paramPtr ( new TMyParams (object.param) ),
	  param (*paramPtr),
	  parcpPtr ( new TMyParcp (object.parcp) ),
	  parcp (*parcpPtr),
	  parfsPtr ( new TMyParfs (object.parfs) ),
	  parfs (*parfsPtr),
	  potentProdPtr ( new TPotentialProduction (object.potentProd) ),
	  potentProd (*potentProdPtr),
	  sitePtr ( new TSite (object.site) ),
	  site (*sitePtr),
	  waterPtr ( new TWater (object.water) ),
	  water (*waterPtr)
{
    //try	// don't let constructor throw an exception
    //{
	restart.SetRestartFlag (true);
	CopyBase (object);
    //}
    //catch (...)
    //{
    //	state.SetError (TModelState::Error_Constructor);
    //}
}

MY_TEMPLATE_DECLARATION
TCENTURYBASE::TCenturyBase (
	TCENTURYBASE const & object,	// Clone from this
	TMgmtPtr useMgmt)		// Use new management
	: nrel::eco::TEcosystemModelBase (object),
	  TFlowsSchedulable (object),
	  centSite (object.centSite),
	  centMgmt (useMgmt),
	  output (object.output),
	  userName (object.userName),
	  doOutput (object.doOutput),
	  paramDbList (object.paramDbList),
	  //--- data - output variables
	  wtPtr ( new TWaterTemp (object.wt) ),
	  wt (*wtPtr),
	  soilCPtr ( new TSoilC (object.soilC) ),
	  soilC (*soilCPtr),
	  cropCPtr ( new TCropGrassC (object.cropC) ),
	  cropC (*cropCPtr),
	  forestCPtr ( new TForestC (object.forestC) ),
	  forestC (*forestCPtr),
	  co2Ptr ( new TCO2 (object.co2) ),
	  co2 (*co2Ptr),
	  npsPtr ( new TNPS (object.nps) ),
	  nps (*npsPtr),
	  //--- data - internal variables - structs
	  computPtr ( new Tcomput (object.comput) ),
	  comput (*computPtr),
	  fixedPtr ( new TMyFixed (object.fixed) ),
	  fixed (*fixedPtr),
	  forremPtr ( new Tforrem (object.forrem) ),
	  forrem (*forremPtr),
	  paramPtr ( new TMyParams (object.param) ),
	  param (*paramPtr),
	  parcpPtr ( new TMyParcp (object.parcp) ),
	  parcp (*parcpPtr),
	  parfsPtr ( new TMyParfs (object.parfs) ),
	  parfs (*parfsPtr),
	  potentProdPtr ( new TPotentialProduction (object.potentProd) ),
	  potentProd (*potentProdPtr),
	  sitePtr ( new TSite (object.site) ),
	  site (*sitePtr),
	  waterPtr ( new TWater (object.water) ),
	  water (*waterPtr)
{
    try	// don't let constructor throw an exception
    {
	restart.SetRestartFlag (true);
	CopyBase (object, false);

	// remember some state variables
	::TYear const year = st->year;		// sim. year, start year
	::TYear const endYear = st->endYear;	// sim. end year
	::TMonth const month = st->month;

	// setup new mgmt
	sched.reset ( new TMgmtSchedule (centMgmt) );
	ReadSimulationInfo ();			// Initialize mgmt
	// Potential issue
	// The mgmt block instance has start/end sim. years that may not
	// match the current sim start/end year.

	// restore state vars
	st->year = year;
	st->startYear = year;
	st->endYear = endYear;
	st->month = month;

	iterationData.blockInstNum =		// Read the first block
		GetCurrentMgmt (0);
	++iterationData.blockInstNum;		// count block instances
    }
    catch (...)
    {
	state.SetError (TModelState::Error_Constructor);
    }
}

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::operator== (
	TCenturyBase const & object) const
{
	if ( &object )
	{
		return	*centSite == *object.centSite &&
			*centMgmt == *object.centMgmt;
	}
	else
		return false;
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	UseDebugFlags
//	Save the debug flag values.
MY_TEMPLATE_DECLARATION
void TCENTURYBASE::UseDebugFlags (
	TDebugInfo const & useDebugFlags)
{
	debugInfo.execTime = useDebugFlags.execTime;
	debugInfo.writeTime = useDebugFlags.writeTime;
}

//	Clear
// 	"clear" data members
//	Restore to state at the end of construction.
//	Note: do not clear "constant" auto_ptrs
MY_TEMPLATE_DECLARATION
void TCENTURYBASE::Clear ()
{
	TFlowsSchedulable::Clear ();

	// data objects
	sched->Clear ();
	st->Initialize ();
	sysType.Clear ();
	iterationData.Clear ();
	c14.reset ();
	comput.Clear ();
	fixed.Clear ();
	forrem.Clear ();
	param.Clear ();
	parcp.Clear ();
	parfs.Clear ();
	potentProd.Clear ();
	site.Clear ();
	water.Clear ();

	// submodels
	leachOC->Clear ();
	decomp->Clear ();
	soil->Clear ();
	canopy.Clear ();
	if ( SimMicrocosm() )
		microcosm->Clear ();
	if ( lowerSoil.get() )
		lowerSoil->Clear ();
	if ( erosion.get() )
		erosion->Clear ();
	if ( deposition.get() )
		deposition->Clear ();
}

//	ClearForNewSimulation
// 	Reset only computed data.
//	All I/O files, site, and management remains active.
MY_TEMPLATE_DECLARATION
void TCENTURYBASE::ClearForNewSimulation ()
{
	TFlowsSchedulable::Clear ();

	sched->Clear ();
	st->Initialize ();
	iterationData.Clear ();
	ClearOutputVars ();                     // daily output variables
	comput.Clear ();

	// submodels
	leachOC->Clear ();
	decomp->Clear ();
	if ( lowerSoil.get() )
		lowerSoil->Clear ();
	if ( erosion.get() )
		erosion->Clear ();
	if ( deposition.get() )
		deposition->Clear ();
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	CopyBase
// 	copy to this
//	The copy constructor should be able to duplicate a snapshot of the
//	model state, so the copy constructor and Copy have to copy EVERYTHING!
MY_TEMPLATE_DECLARATION
void TCENTURYBASE::CopyBase (
	TCenturyBase const & object,
	bool const copyMgmtVars)
{
	if ( &object )
	{
		//--- data
		// centSite copied in constructor init list
		if ( copyMgmtVars )
		{
		    sched.reset ( new TMgmtSchedule (*object.sched) );
		    blockInstanceList.reset (
		    	new TInstanceList (*object.blockInstanceList) );
		}
		st.reset ( new TMySimTime (*object.st) );
		debugInfo = object.debugInfo;
		siteEnv = object.siteEnv;
		sysType = object.sysType;
		iterationData = object.iterationData;
		if ( object.weather.get() )
			weather.reset ( object.weather->Clone() );
		if ( c14.get() )
			c14.reset ( new T14CData (*object.c14) );

		// submodels
		soil.reset ( new TMySoil (*object.soil) );
		canopy = object.canopy;
		// monthlyPET has no data to copy
		if ( SimMicrocosm() )
			microcosm.reset (new TMicrocosm (*object.microcosm) );
		if ( object.lowerSoil.get() )
			lowerSoil.reset (new TLowerSoil (*object.lowerSoil) );
		if ( object.erosion.get() )
			erosion.reset (new TErosion (*object.erosion) );
		if ( object.deposition.get() )
			deposition.reset (new TDeposition (*object.deposition) );

		soilFlows.reset (
			new TMySoilFlows (
				*object.soilFlows,
				*soil, *flows, *st ) );

		microbial.reset (
			new TMyMicrobial (
				*object.microbial,
				*soil, *soilFlows, *st ) );

		leachOC.reset (
			new TLeachOrganicC (
				*object.leachOC,
				*st, nps, soilC, wt ) );

		decomp.reset (
			new TMyDecomp (
				*object.decomp,
				*leachOC, *soil, *soilFlows, *microbial,
				*st, fixed, parfs, comput, site,
				co2, forestC, nps, soilC, wt,
				sysType.Type() ) );
	}
}

//	Constructor
//	Common constructor tasks.
//	Should be called only from the constructors.
MY_TEMPLATE_DECLARATION
void TCENTURYBASE::Constructor ()
{
	// schedule, timer, and weather
	sched.reset ( new TMgmtSchedule (centMgmt) );
	st.reset ( new TMySimTime () );
	weather.reset ( new TMyWeather (&calendarTools) );

	//--- output variable sets
	if ( DoingOutput() )
	{
		TCentOutFileBase * const myOutput =
			dynamic_cast<TCentOutFileBase*>( output.get() );
		Assert (myOutput != 0);
		// add to the list of output sets
		myOutput->GetOutputSetList().clear();
		myOutput->GetOutputSetList().push_back ( wtPtr.get() );
		myOutput->GetOutputSetList().push_back ( soilCPtr.get() );
		myOutput->GetOutputSetList().push_back ( cropCPtr.get() );
		myOutput->GetOutputSetList().push_back ( forestCPtr.get() );
		myOutput->GetOutputSetList().push_back ( co2Ptr.get() );
		myOutput->GetOutputSetList().push_back ( npsPtr.get() );
	}

	// submodels
	leachOC.reset (
		new TLeachOrganicC ( fixed.omlech, *st, nps, soilC, wt ) );
	soil.reset ( new TMySoil (*this) );
	soilFlows.reset ( new TMySoilFlows ( *soil, *flows, *st ) );

	// management
	ReadSimulationInfo ();

	// site info needed now

	// debug
	TMySiteParams const * const mySite = GetSite().get();
	TSiteParamSet const & mySet =
		mySite->GetSet (mySite->indices.SPGI_Soil);
	TSiteParameter const & myParameter = mySet.GetParameter (
		mySite->indices.SPI_nelem - mySite->indices.SPI_ivauto );
	short const numElem =
		static_cast<short const>( myParameter.GetValue() );

//	short const numElem =
//		(short) GetSite()->GetSet (
//			  GetSite()->indices.SPGI_Soil).GetParameter (
//			    GetSite()->indices.SPI_nelem -
//			      GetSite()->indices.SPI_ivauto ).GetValue();

	// submodels
	microbial.reset (
		new TMyMicrobial (
			*soil, *soilFlows, *st,
			fixed.peftxa, fixed.peftxb, fixed.dec3,
			param.labtyp, fixed.dresp, numElem ) );
	decomp.reset (
		new TMyDecomp (
			// Century submodels
			*leachOC, *soil, *soilFlows, *microbial,
			// Century internal data
			*st, fixed, parfs, comput, site,
			// Century output variables
			co2, forestC, nps, soilC,
			const_cast<TWaterTemp const &>( wt ),
			sysType.Type() ) );
}

//	CheckSitePtr
//	Returns true if site pointer is valid and has data.
//	Throws exception if pointer is invalid or empty.
MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::CheckSitePtr (
	TSitePtr theSite)
{
	if ( !theSite.get() || theSite->IsEmpty() )
		ThrowCentException (TCentException::CE_NOSITE, 0);
	else if ( theSite->IsError() )
		ThrowCentException (
			TCentException::CE_SITERR,
			theSite->GetErrorMsg().c_str() );
	return true;
}

//	CheckManagementPtr
//	Returns true if management pointer is valid and has data.
//	Throws exception if pointer is invalid or empty.
MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::CheckManagementPtr (
	TMgmtPtr theMgmt)
{
	if ( !theMgmt.get() || theMgmt->IsEmpty() )
		ThrowCentException (TCentException::CE_NOMGMT, 0);
	else if ( theMgmt->IsError() )
		ThrowCentException (
			TCentException::CE_MGTERR, theMgmt->GetErrorMsg());
	return true;
}

//	CheckOutputPtr
//	Returns true if output pointer is valid and has data.
//	If doing output, throws exception if pointer is invalid or empty.
//	Returns false if not doing output.
MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::CheckOutputPtr (
	TOutputPtr theOutput)
{
    if ( DoingOutput() )
    {
	if ( !theOutput.get() || theOutput->IsEmpty() )
		ThrowCentException (TCentException::CE_NOOUTF, 0);
	else if ( theOutput->GetErrorState() != TOutputBase::Error_NoError )
		ThrowCentException (
			TCentException::CE_OUTERR, 0);
	return true;
    }
    else
    	return false;
}

//	YearEndMsgInterval
//	Years between year-end messages
//	Returns interval size.
MY_TEMPLATE_DECLARATION
long TCENTURYBASE::YearEndMsgInterval ()
{
    long updateInterval = 0L;	// interval for calls to yearFunction
    if ( asynchCom.HaveSendYearFunction() && st->SimYears() > 1L )
    {
	long numYrs = st->SimYears();	// simulation length in years
	if ( numYrs >= 10000L )
	    updateInterval = static_cast<long>(
				(float)numYrs / 100.0f + 0.5f);	// 100 updates
	else if ( numYrs >= 1000L )
	    updateInterval = static_cast<long>(
				(float)numYrs / 50.0f + 0.5f);	// 50 updates
	else if ( numYrs >= 100L )
	    updateInterval = static_cast<long>(
				(float)numYrs / 20.0f + 0.5f);	// 20 updates
	else if ( numYrs >= 10L )
	    updateInterval = static_cast<long>(
				(float)numYrs / 10.0f + 0.5f);	// 10 updates
	else
	    updateInterval = 1;					// annually
    }
    return updateInterval;
}

//	ClearOutputVars
//	Clears the output variables.
MY_TEMPLATE_DECLARATION
void TCENTURYBASE::ClearOutputVars ()
{
	wt.Clear ();
	soilC.Clear ();
	cropC.Clear ();
	forestC.Clear ();
	co2.Clear ();
	nps.Clear ();
}

//	SynchronizeMgmt
//	Synchronize the management's block instance list with the
//	current simulation time.
//	Return the block instance number.
MY_TEMPLATE_DECLARATION
short TCENTURYBASE::SynchronizeMgmt (
	::TYear simYear,			// simulation year
	TInstanceList const & instanceList,	// block instance list
	short const currentBlockInstNum)	// current instance number
{
	short syncdInstanceNum = currentBlockInstNum;	// return value

	// advance so instance start year <= sim year <= instance last year
	// if it is time for a new block, the sim year will be one year behind
	// the new block instance year.
	::TYear yearWanted;
	if ( st->AtSimulationStart() )
		yearWanted = simYear;		// year has been incremented
	else
		yearWanted = simYear + 1;	// year not incremented yet

	TInstanceListItem const * item =
		&blockInstanceList->GetInstance (syncdInstanceNum);
	while ( item->yearLast < yearWanted &&
		syncdInstanceNum < blockInstanceList->GetCount() - 1 )
	{
		++syncdInstanceNum;
		Assert (GetManagement()->GetBlock (syncdInstanceNum) != NULL);
		Assert (GetManagement()->GetBlock (syncdInstanceNum)->
			GetInstanceCount() > 0);
		item = &blockInstanceList->GetInstance (syncdInstanceNum);
	}
	// month sychronization should be done in class TMgmtSchedule.

	// Assume that block can start at it's first event. There is potential
	// here for the sim year and instance years to be out of sync when
	// mgmt. schedules are changed mid-sim., or if the model is cloned
	// after the simulation has started.
	if ( item->yearFirst > yearWanted )	// have match?
	{
		std::ostringstream os;
		os << "Simulation year = "
		   << yearWanted
		   << ", Instance start year = "
		   << item->yearFirst;
		ThrowCentException ( TCentException::CE_INSTOS,
	    				os.str().c_str() );
	}
	Assert (syncdInstanceNum < blockInstanceList->GetCount());
	Assert (item->yearFirst <= yearWanted);
	Assert (item->yearLast >= yearWanted);

	return syncdInstanceNum;
}

//	FindWeatherFileInMgmt
// 	Get the weather file name, if any, associated with the current
//	management block instance. Prepend it's path, if not already there.
//	Returns the file name.
MY_TEMPLATE_DECLARATION
std::string & TCENTURYBASE::FindWeatherFileInMgmt (
	TInstanceList const & instanceList, // instance list
	short const currentBlockInstNum,	// instance num. in inst. list
	std::string & weatherFileNameStr)	// weather file (output)
{
	weatherFileNameStr.clear ();

	// get the current instance
	TInstanceListItem const & currentItem =	// instance list item
		instanceList.GetInstance ( currentBlockInstNum );
	TManagementBlock const * block =
		GetManagement()->GetBlock(currentItem.blockNum);
	TManagementInst const * instance =
		block->GetInstance (currentItem.instNum);

	// search for a file name
	bool foundFileName = false;
	if ( instance->weatherSource == WS_FileRewind &&
	     !instance->weatherFile.empty() )
	{
		foundFileName = true;
	}
	else if ( instance->weatherSource == WS_FileRewind ||
		  instance->weatherSource == WS_FileContinue )
	{
	    // search backwards in the instance list for the latest block
	    // to specify a weather file name.
	    short instanceNum = currentBlockInstNum - 1;
	    while ( instanceNum >= 0 )
	    {
		// get block number and instance number from instance list
		// and get the instance from mgmt
		TInstanceListItem const & item =
			instanceList.GetInstance ( instanceNum );
		instance = GetManagement()->GetBlock(item.blockNum)->
				GetInstance(item.instNum);
		// check for a file name
	  	if ( ( instance->weatherSource == WS_FileRewind ||
			instance->weatherSource == WS_FileContinue ) &&
		     !instance->weatherFile.empty() )
		{
			foundFileName = true;
			break;
		}
		--instanceNum;
	    }
	}
	if ( foundFileName )
		weatherFileNameStr = instance->weatherFile;
	return weatherFileNameStr;
}

//	AddPathToWeatherFile
//	Add path to weather file name, and check if it exists.
//	Return true if have an existing weather file, else false if not.
MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::AddPathToWeatherFile (
	std::string & weatherFileNameStr)	// weather file (modified)
{
	bool haveWeatherFile = false;		// return value

	if ( weatherFileNameStr.empty() )
		return false;

	// If the file name doesn't have a path, try to find it.
	TEH::TFileName weatherFileName ( weatherFileNameStr,
					 TEH::TFileName::FT_Normal );
	if ( weatherFileName.GetFullPathLen() == 0 )		// no path?
	{
		// make a list of search paths
		std::vector<TEH::TFileName> pathList;
		// mgmt path
		pathList.push_back ( TEH::TFileName (
		  GetManagement()->GetBaseName(), TEH::TFileName::FT_Normal ) );
		// site path
		pathList.push_back ( TEH::TFileName (
		  GetSite()->GetBaseName(), TEH::TFileName::FT_Normal ) );
		// current directory
		pathList.push_back ( TEH::TFileName (
			".", TEH::TFileName::FT_Directory ) );

		// search the paths
		std::vector<TEH::TFileName>::const_iterator iList =
			pathList.begin();
		while ( iList != pathList.end() )
		{
			TEH::TFileName aPath (
				iList->GetFullPath(),
				TEH::TFileName::FT_Directory );
			if ( aPath.GetFullPathLen() > 0 && aPath.Exists() )
			{
				weatherFileName.SetPath ( aPath );
				if ( weatherFileName.Exists() )
				{
					haveWeatherFile = true;
					break;	// found file so stop looking
				}
			}
			++iList;
		}
		// return the path + name string
		if ( haveWeatherFile )
		{
			weatherFileNameStr = weatherFileName.GetFullName();
		}
		else	// no weather file found
		{
			std::ostringstream os;
			os << "Weather file was not found in any known path:\n";
			iList = pathList.begin();
			while ( iList != pathList.end() )
			{
				os << iList->GetFullPath() << '\n';
				++iList;
			}
			os << "Requested weather file:\n"
			   << weatherFileNameStr;
			ThrowCentException ( TCentException::CE_WTHRNO,
	    					os.str().c_str() );
		}
	} // if has no path?
	return haveWeatherFile;
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	Include member source code files
//	(Because of out-of-line template functions. This issue hopefully
//	 will go away once compilers support the "export" keyword.)
// ----------------------------------------------------------------------------

// production
#include "inprac.cpp"
#include "co2eff.cpp"
#include "cmplig.cpp"
#include "pprdwc.cpp"
#include "rtimp.cpp"
#include "rcpgraz.cpp"

// removals, fire, and death
#include "frem.cpp"
#include "dedrem.cpp"
#include "cutrtn.cpp"
#include "dshoot.cpp"
#include "killrt.cpp"
#include "litburn.cpp"
#include "falstd.cpp"

// parameter database access
#include "cropin.cpp"
#include "cultin.cpp"
#include "fertin.cpp"
#include "firein.cpp"
#include "grazin.cpp"
#include "harvin.cpp"
#include "irrgin.cpp"
#include "omadin.cpp"
#include "treein.cpp"
#include "tremin.cpp"

// site management input
#include "rdsiminfo.cpp"
#include "readblk.cpp"
#include "schedule.cpp"

// P
#include "fsfunc.cpp"

// others
#include "annacc.cpp"
#include "initerev.cpp"
#include "initll.cpp"
#include "savarp.cpp"
#include "sumcar.cpp"
#include "ufwater.cpp"
#include "updatewv.cpp"
#include "yearend.cpp"

//--- end of definitions for TCenturyBase ---
