// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  droot.cpp
//	Class:	  TDayCent
//	Function: DeathOfRoots
//
//	Description:
//	Simulate death of roots for the month.
// ----------------------------------------------------------------------------
//	History:
//      See Century/droot.cpp
//      Jun01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Replaced wt.stemp with dwt.stemp. Is this okay? -mdh 6/7/01
//      * Changed this function from TCentury to TDayCent member. -mdh 6/7/01
//      Sep01   Melannie Hartman, melannie@nrel.colostate.edu
//      * A fraction of the maintenance respiration storage pool is
//        removed in proportion to the amount of live roots removed.
//      Jan02   Melannie Hartman, melannie@nrel.colostate.edu
//      * Made stemp a parameter, no longer using dwt.stemp.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//      Notes:
//      * A fraction of the maintenance respiration storage pool flows into
//        the soil metabolic C pool, is this correct? -mdh 9/5/01
//        (See also harvst.cpp and cultiv.cpp)
// ----------------------------------------------------------------------------

#include "TDayCent.h"

void TDayCent::DeathOfRoots (
    float const stemp)          // averaged soil surface temperature (deg C)
{
    register short iel;		// loop index
    float
      rtdh,		//
      recres[NUMELEM],	//
      rdeath;		//

//	Mod. added (stemp .lt. 2.0) conditional since roots don't floatly
//	die in winter because it's too cold for physiological activity.
//	-rm  9-12-90
    if (cropC.bglivc <= 0.0f || stemp < parcp.rtdtmp)
	return;

    // This is representing the death of fine surface roots.  They depend
    // on moisture in the top soil layers, so use avh2o(1).
    //	Also added rtdh term for drought conditions. -rm  9-12-90
    // Changed to use sim layer depth for moisture: root depth >> sim depth
    rtdh = 1.0f - wt.avh2o[2] / (fixed.deck5 + wt.avh2o[2]);
    rdeath = parcp.rdr * rtdh;
    rdeath = std::min (rdeath, 0.95f);	// limit maximum rdeath
    rdeath *= cropC.bglivc;
    for (iel = 0; iel < site.nelem; ++iel)
	recres[iel] = nps.bglive[iel] / cropC.bglivc;
    float mRespStorageFracRemoved = rdeath / cropC.bglivc; // compute before cropC.bglcis is updated
    float const fr14 = cropC.bglcis[LABELD] / cropC.bglivc;
    PartitionResidue (rdeath, recres, SOIL, cropC.bglcis, nps.bglive,
    			comput.pltlig[BELOW], fr14);

    // When live roots die, a proportional amount of the maintenance
    // respiration storage carbon pool flows to the same destination
    // as the roots.

    //Assert (gpp.mRespStorageCrop[UNLABL] >= 0.0);
    //Assert (gpp.mRespStorageCrop[LABELD] >= 0.0);

    if ( gpp.mRespStorageCrop[UNLABL] < 0.0f ||
         gpp.mRespStorageCrop[LABELD] < 0.0f )
    {
        // these statements are commented out for testing purposes -mdh 11/14/01
        // ScheduleCFlow cannot handle negative mRespStorage.
        // Removing a negative amount
        //float const mRespStorageLoss =
        //	mRespStorageFracRemoved * gpp.mRespStorageCrop[UNLABL];
        //flows->Schedule (&gpp.mRespStorageCrop[UNLABL], &metcis_ref (SOIL, UNLABL),
        //        st->time, mRespStorageLoss);
        // mRespStorageLoss = mRespStorageFracRemoved * gpp.mRespStorageCrop[LABELD];
        //flows->Schedule (&gpp.mRespStorageCrop[LABELD], &metcis_ref (SOIL, LABELD),
        //        st->time, mRespStorageLoss);
    }
    else
    {
        float const mRespStorage =
        	gpp.mRespStorageCrop[UNLABL] + gpp.mRespStorageCrop[LABELD];
        float const mRespStorageLoss = mRespStorageFracRemoved * mRespStorage;
        float accum[ISOS] =	{ 0.0f, 0.0f }; 	// accumulator
        ScheduleCFlow ( st->time, mRespStorageLoss,
		gpp.mRespStorageCrop[LABELD] / mRespStorage, 1.0f,
		&gpp.mRespStorageCrop[UNLABL], &metcis_ref (SOIL, UNLABL),
		&gpp.mRespStorageCrop[LABELD], &metcis_ref (SOIL, LABELD),
		accum );
        //cropC.cinput += accum[UNLABL] + accum[LABELD];  // need this?
    }
}

//--- end of file ---
