
/*              Copyright 1998 Colorado State University     */
/*                      All Rights Reserved                  */

#include <stdlib.h>
#include <stdio.h>
#include "netcdf.h"

/* Externally defined variables */
extern int GeogNcid;
extern long maskRows, maskCols;

void handle_error(char *funcname, int status);

/* Global variables */
float *geoglat, *geoglon;

void
ReadLatLon()
{
    int i, j;
    size_t start[2] = {0, 0};
    size_t count[2] = {1, 1}; 
    int cellNo = 1;
    int lat_id, lon_id;
    int status;
    short *p;
    int icell;

    /* Allocate space to hold mask with cell numbers */
    geoglat = (float *)calloc(maskRows * maskCols, sizeof(float));
    geoglon = (float *)calloc(maskRows * maskCols, sizeof(float));

    /* Set count length to number of columns */
    count[0] = maskRows;
    count[1] = maskCols;

    /* Get NetCDF variable ID for lat/lon variables */
 
    /*
    printf("ReadLatLon: GeogNcid = %d\n", GeogNcid);
    printf("ReadLatLon: maskRows = %d\n", maskRows);
    printf("ReadLatLon: maskCols = %d\n", maskCols);
    */

    status = nc_inq_varid(GeogNcid, "lat", &lat_id);
    if (status != NC_NOERR) handle_error("nc_inq_varid(lat)", status);
 
    status = nc_inq_varid(GeogNcid, "lon", &lon_id);
    if (status != NC_NOERR) handle_error("nc_inq_varid(lon)", status);
 
    status = nc_get_vara_float(GeogNcid, lat_id, start, count, geoglat);
    if (status != NC_NOERR) handle_error("nc_get_vara_float(geoglat)", status);

    status = nc_get_vara_float(GeogNcid, lon_id, start, count, geoglon);
    if (status != NC_NOERR) handle_error("nc_get_vara_float(geoglon)", status);

    /*
    for (icell = 0; icell < 1690; icell++ ) {
       printf("%5.2f  %5.2f\n", geoglat[icell], geoglon[icell]);
    }
    */
    return;
   
}
