
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include "netcdf.h"
#include "wrtcdf.h"

void
rdvars_(float fl_out[], int int_out[], int *no_of_flts, 
	 int *no_of_ints, int *cellpos)
{
        int             status;
	static size_t	vstart[2]={0, 0};
	size_t 		vcount[2]={1, 1};

	/* Get variable IDs */
        status = nc_inq_varid(osite_ncid, "fltvar", &fltvar_id);
	status = nc_inq_varid(osite_ncid, "intvar", &intvar_id);

        vstart[0] = *cellpos - 1;

	/* Read values into array */
	vcount[1] = (size_t) *no_of_flts;
	status = nc_get_vara_float(osite_ncid, fltvar_id, vstart, vcount, fl_out);

	vcount[1] = (size_t) *no_of_ints;
	status = nc_get_vara_int(osite_ncid, intvar_id, vstart, vcount, int_out);

        printf("vstart[0] = %1d\n", vstart[0]);
/*        vstart[0] = vstart[0] + 1; */

	return;
}
