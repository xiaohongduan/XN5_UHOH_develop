
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Rewrite the soilc.nc netCDF file using COARDS standards */
/* The original file was organized variable(cell, time) */
/* The new file is organized variable(time, lat, lon) */

#include <stdio.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf_ll.h"

    int write_soiln_ll_(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  som1n1_vals[MAXCELLS], som1n2_vals[MAXCELLS], som2n_vals[MAXCELLS],
             som3n_vals[MAXCELLS], strucn1_vals[MAXCELLS], strucn2_vals[MAXCELLS],
             metabn1_vals[MAXCELLS], metabn2_vals[MAXCELLS];
      int status;
      int oldsoilnid;
      int oldsom1n1id, oldsom1n2id, oldsom2nid, oldsom3nid, oldstrucn1id,
          oldstrucn2id, oldmetabn1id, oldmetabn2id;
      int ii, jj, ngrids;

      /* Open old version of soiln.nc file */
      status = nc_open("soiln.nc", NC_NOWRITE, &oldsoilnid);
      if (status != NC_NOERR) handle_error("nc_open(soiln.nc)", status);

      /* Get the indices for the soiln output variables */
      status = nc_inq_varid(oldsoilnid, "som1n1", &oldsom1n1id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for som1n1",status);
      status = nc_inq_varid(oldsoilnid, "som1n2", &oldsom1n2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for som1n2",status);
      status = nc_inq_varid(oldsoilnid, "som2n", &oldsom2nid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for som2n",status);
      status = nc_inq_varid(oldsoilnid, "som3n", &oldsom3nid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for som3n",status);
      status = nc_inq_varid(oldsoilnid, "strucn1", &oldstrucn1id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for strucn1",status);
      status = nc_inq_varid(oldsoilnid, "strucn2", &oldstrucn2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for strucn2",status);
      status = nc_inq_varid(oldsoilnid, "metabn1", &oldmetabn1id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for metabn1",status);
      status = nc_inq_varid(oldsoilnid, "metabn2", &oldmetabn2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for metabn2",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        som1n1_vals[ii] = fill;
        som1n2_vals[ii] = fill;
        som2n_vals[ii] = fill;
        som3n_vals[ii] = fill;
        strucn1_vals[ii] = fill;
        strucn2_vals[ii] = fill;
        metabn1_vals[ii] = fill;
        metabn2_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the soiln output file */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldsoilnid, oldsom1n1id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for som1n1",status);
            }
            som1n1_vals[jj] = val;
            status = nc_get_var1_float(oldsoilnid, oldsom1n2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for som1n2",status);
            }
            som1n2_vals[jj] = val;
            status = nc_get_var1_float(oldsoilnid, oldsom2nid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for som2n",status);
            }
            som2n_vals[jj] = val;
            status = nc_get_var1_float(oldsoilnid, oldsom3nid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for som3n",status);
            }
            som3n_vals[jj] = val;
            status = nc_get_var1_float(oldsoilnid, oldstrucn1id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for strucn1",status);
            }
            strucn1_vals[jj] = val;
            status = nc_get_var1_float(oldsoilnid, oldstrucn2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for strucn2",status);
            }
            strucn2_vals[jj] = val;
            status = nc_get_var1_float(oldsoilnid, oldmetabn1id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for metabn1",status);
            }
            metabn1_vals[jj] = val;
            status = nc_get_var1_float(oldsoilnid, oldmetabn2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for metabn2",status);
            }
            metabn2_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(soilnll_ncid, som1n1ll_id, start, count, som1n1_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for som1n1",status);
        status = nc_put_vara_float(soilnll_ncid, som1n2ll_id, start, count, som1n2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for som1n2",status);
        status = nc_put_vara_float(soilnll_ncid, som2nll_id, start, count, som2n_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for som2n",status);
        status = nc_put_vara_float(soilnll_ncid, som3nll_id, start, count, som3n_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for som3n",status);
        status = nc_put_vara_float(soilnll_ncid, strucn1ll_id, start, count, strucn1_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for strucn1",status);
        status = nc_put_vara_float(soilnll_ncid, strucn2ll_id, start, count, strucn2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for strucn2",status);
        status = nc_put_vara_float(soilnll_ncid, metabn1ll_id, start, count, metabn1_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for metabn1",status);
        status = nc_put_vara_float(soilnll_ncid, metabn2ll_id, start, count, metabn2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for metabn2",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldsoilnid);

      return 0;
    }
