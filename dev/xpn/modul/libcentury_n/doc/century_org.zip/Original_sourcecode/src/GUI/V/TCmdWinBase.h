#ifndef INC_TCmdWinBase_h
#define INC_TCmdWinBase_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  T_CmdWinBase.h
//	Class:	  TCmdWinBase
//
//	Description:
//	Base class for the main client window + common menu.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Oct98
//	History:
//	Jan00	Tom Hilinski
//	* Modified GetOutputFileName so that the first name checked is
//	  the management file name.
//	Oct01	Tom Hilinski
//	* Many mods to the logic to work with new TCenturyConfig class.
//	* Removed member function BuildOutputFileName; now in TCenturyConfig.
//	Nov03	Tom Hilinski
//	* Sim. output configuration now uses class TOutputSelectDlg.
//	* Removed member function GetOutputFileName; no longer used.
// ----------------------------------------------------------------------------

#include <v/vcmdwin.h>
#include <v/vcmdpane.h>
#include <v/vmenu.h>
#include <v/vstatusp.h>
#include "TCMIApp.h"
#include <string>
#include <memory>

class TCmdWinBase : public vCmdWindow
{
  public:
	//--- constructors and destructor
	TCmdWinBase (
		TCMIApp* const parentApp,	// pointer to app instance
		char const* windowTitle);	// window title string
	virtual ~TCmdWinBase ();

	//--- overridden functions
	void WindowCommand (ItemVal itemId, ItemVal val, CmdType cType);
	void KeyIn (vKey keysym, unsigned int shift);
	void CloseWin ()
		{ vCmdWindow::CloseWin (); }

	// status bar functions
	void ActionText (const char *msg)		// action msg to this
		{ SetString (S_Action, (char*)msg); }
	void ActionTextAll (const char *msg)		// action msg all wins
		{ app->SetStringAll ((int)S_Action, msg); }
	void StatusText (const char *msg)		// status msg to this
		{ SetString (S_Status, (char*)msg); }
	void StatusTextAll (const char *msg)		// status msg all wins
		{ app->SetStringAll ((int)S_Status, msg); }

  protected:
	//--- data
	TCMIApp* const app;			// pointer to app instance

	//--- menu
	enum {
		//----- menu bar
		// M_File,			defined in V
		// M_Edit,			defined in V
		M_ProjectMenu = 1000,		// "Project" drop-down menu
		M_SimulationMenu,		// "Simulation" drop-down menu
		M_ResultsMenu,			// "Results" drop-down menu
		M_ToolsMenu,			// "Tools" drop-down menu
		// M_GraphMenu,			// "Graph" drop-down menu
		// M_ImageMenu,			// "Image" drop-down menu
		// M_Help,			defined in V
		//----- File drop-down menu
		M_PrintSetup,			// Printer setup
		//----- Project drop-down menu
		M_Proj_New,			// Create a new project
		M_Proj_Open,			// Open an existing project
		M_Proj_Close,			// Close the current project
		M_Proj_Edit,			// Edit the current project
		M_Proj_Recent,			// List of recently accessed
		//----- Simulation drop-down menu
		M_Sim_Clear,			// Clear site, mgmt, out. file
		M_Sim_Site,			// Edit Site parameters
		M_Sim_Mgmt,			// Edit Site Management
		M_Sim_MgmtSum,			// Site Management summary
		M_Sim_ParEdit,			// Edit Model Parameters
		M_Sim_WthrEdit,			// Edit weather data
		M_Sim_C14Edit,			// Edit 14C data
		M_Sim_OutFile,			// Type of output file
		M_Sim_ResFile,			// Specify the restart files
		M_Sim_RunEquil,			// Run sim. to equilibrium
		M_Sim_RunResFile,		// Run from restart file
		M_Sim_Run,			// Run simulation
		M_Sim_Status,			// Status of simulation
		//----- Results drop-down menu
		M_Res_View,			// View output variables
		M_Res_Plot,			// X-Y Plot
		M_Res_Export,			// Export to external format
		M_Res_Browse,			// View results files
		//----- Tools drop-down menu
		M_Tools_Environment,		// Configure GUI environment
		M_Tools_Projects,		// Manage Simulation projects
		M_Tools_SiteLib,		// Manage Site Libraries
		M_Tools_MgmtLib,		// Manage Management Libraries
		M_Tools_BlkLib,			// Manage Block Libraries
		M_Tools_PlantWiz,		// Plant parameter wizard
		M_Tools_SoilWiz,		// Soil design wizard
		M_Tools_ErosionWiz,		// Erosion design wizard
		M_Tools_ClimateWiz,		// Climate generator wizard
		//	Help drop-down menu
		M_Hlp_Contents,			// Contents of help file
		M_Hlp_Search,			// Search of help file
		M_Hlp_GetStarted,		// "Getting Started" topic
		M_Hlp_Keys,			// List of shortcut keys
		M_Hlp_HowToUse,			// Help on using Help
		M_Hlp_DebugReport,		// Debug report
		//----- No more!
		M_EndOfList			// last item
	};
	static vMenu fileMenuDef[];		// "File" drop-down menu
	static vMenu projectMenuDef[];		// "Project" drop-down menu
	static vMenu simulationMenuDef[];	// "Simulation" drop-down menu
	static vMenu resultsMenuDef[];		// "Results" drop-down menu
	static vMenu toolsMenuDef[];		// "Tools" drop-down menu
	static vMenu helpMenuDef[];		// "Help" drop-down menu

	//--- status bar
	enum
	{
		S_Status_Lbl = 1100,		// status label
		S_Status,			// status
		S_Action_Lbl,			// current action label
		S_Action,			// current action
		S_EndOfList			// last item always!
	};
	static vStatus statusBar[];		// status bar instance

	//--- toolbar - QuickSteps
	enum
	{
		TBQS_BtnLabel = 1200,		// Label
		TBQS_BtnPref,			// Preferences button
		TBQS_BtnSite,			// Site button
		TBQS_BtnMgmt,			// Management button
		TBQS_BtnOF,			// Select Output File button
		TBQS_BtnStatus,			// Display Status button
		TBQS_BtnRun,			// Run Simulation button
		TBQS_EndOfList			// last item always!
	};
	static CommandObject toolBarQS[];	// toolbar instance

	//--- window display items

	//--- event functions
	enum TCWBResultChoice			// list of choices
	{
		RC_OutputThis,			// output from this simulation
		RC_OutputFile,			// output from a previous sim.
		RC_ErosionThis,			// erosion file from this sim.
		RC_ErosionFile,			// erosion file previous sim.
		RC_EndOfList			// last item always!
	};
	void DoMenuEvent_File (ItemVal itemId);
	// void DoMenuEvent_Project (ItemVal itemId);
	void DoMenuEvent_Simulation (ItemVal itemId);
	void DoMenuEvent_Results (ItemVal itemId);
	void DoMenuEvent_Tools (ItemVal itemId);

	//--- utility functions
};

#endif 	// INC_TCmdWinBase_h
