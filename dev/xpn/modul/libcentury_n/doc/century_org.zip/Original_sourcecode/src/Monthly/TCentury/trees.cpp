// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  trees.cpp
//	Class:	  TCentury
//	Function: SimulateTrees
//
//	Description:
//	Simulate forest production for the month.
// ----------------------------------------------------------------------------
//	History:
//	Jan00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Removed parameter "wfunc" since WoodDeath no longer uses it.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TCentury.h"

void TCentury::SimulateTrees ()
{
    // Death and disturbance
    WoodDeath ();

    // Option to add organic matter; added here so that it won't be
    // done twice in savanna
    if ( sched->DoingOMAddition() )
	PartitionResidue ( parcp.astgc, parcp.astrec, SRFC, soilC.csrsnk,
			   nps.esrsnk, parcp.astlig, parcp.astlbl );

    // Update flows so direct absorption will be accounted for
    // before plant uptake
    Update ();				// Update the flows and sums

    // Production for trees
    TreeGrowth ();
}
