// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  monthvals.cpp
//	Class:	  TDayCent
//	Function: ResetMonthlyValues
//
//	Description:
//	Reset monthly accumulators and averages
// ----------------------------------------------------------------------------
//	History:
//	Nov01   Melannie Hartman, melannie@nrel.colostate.edu
//      * created
//	Jul02 Melannie Hartman, melannie@nrel.colostate.edu
//      * Added forestC.cprodf and cropC.cprodc to monthly reinitialization.
//      * Added nps.nfixac as monthly reinitialization.
//	Aug02 Melannie Hartman, melannie@nrel.colostate.edu
//      * Added many intializations for monthly output variables
//      Sep02 Melannie Hartman, melannie@nrel.colostate.edu
//      * Added co2.wd1c2[i], co2.wd2c2[i], co2.wd3c2[i] initializations
//      * Added cropC.mcnupt[i], cropC.mcprd[i] initializations
//      * Added forestC.mfnupt[i], forestC.mfprd[i] initializations
// ----------------------------------------------------------------------------

#include "TDayCent.h"

void TDayCent::ResetMonthlyValues ()
{
	short const monthIdx = st->month - 1;	// month index to arrays
	wt.evap =  wt.irract =  wt.rain =  wt.pet =  wt.tran = wt.runoff = 0.0f;
	for (short i = 0; i < 8; i++)
            wt.stream[i] = 0.0f;
        wt.anerb = wt.defac = wt.stemp = 0.0f;
        wt.tave = weather->MeanMonthlyTemp (st->month);
        forestC.sumrsp = 0.0f;
        param.htran[monthIdx] =  param.hpttr[monthIdx] = 0.0f;
        nps.volex = nps.volpl = nps.volgm = 0.0f;
        comput.defacm[monthIdx] = 0.0f;
        forestC.cprodf = 0.0f;
        cropC.cprodc = cropC.crmvst = cropC.cgrain = 0.0f;
        for (short element = 0; element < site.nelem; ++element)
        {
            nps.egrain[element] = 0.0f;
            nps.ermvst[element] = 0.0f;
            nps.fertot[element] = 0.0f;
        }
        nps.nfix = nps.wdfxma = nps.wdfxms = 0.0f;

        //--- Initialize MONTHLY mineralization accumulators for each element.
        for (short element = 0; element < site.nelem; ++element)
        {
	    for ( short layer = SRFC; layer <= SOIL; ++layer )
	    {
	        strmnr_ref (layer, element) = 0.0f;
	        metmnr_ref (layer, element) = 0.0f;
	        s1mnr_ref (layer, element) = 0.0f;
	    }
	   nps.s2mnr[element] =  nps.s3mnr[element] = 0.0f;
           nps.gromin[element] = 0.0f;
	   nps.w1mnr[element] =  nps.w2mnr[element] =  nps.w3mnr[element] = 0.0f;
        }
        // Initialize monthly co2 accumlators
        for (short i = 0; i < ISOS; ++i)        // for each isotope...
        {
            co2.st1c2[i] = co2.st2c2[i] = co2.mt1c2[i] = co2.mt2c2[i] =
            co2.s11c2[i] = co2.s21c2[i] = co2.s2c2[i] = co2.s3c2[i] = 0.0f;
        }
}

//--- end of file ---
