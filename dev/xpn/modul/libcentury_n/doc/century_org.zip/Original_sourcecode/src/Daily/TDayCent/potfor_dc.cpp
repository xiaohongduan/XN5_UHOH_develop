// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  potfor.cpp
//	Class:	  TDayCent
//	Function: ForestProductionPotential
//
//	Description:
//	Compute monthly potential production for forest

#include "TDayCent.h"
#include "ranfun.h"

void TDayCent::ForestProductionPotential  (
        float const prodPrecip,         // precip amount over prod period (cm H2O)
        float const prodTempMin,        // avg min temp over prod period (deg C)
        float const prodTempMax,        // avg max temp over prod period (deg C)
        float const prodPET,            // PET amount over prod period (cm H2O)
        float const prodMonthFrac,      // fraction of current month comprised
                                        //   by the current production period (0-1)
        float const stemp)              // soil surface temperature
{
	Assert (prodPrecip >= 0.0f);
	Assert (prodTempMin <= prodTempMax);
	Assert (prodPET >= 0.0f);
	Assert (prodMonthFrac > 0.0f);
	Assert (prodMonthFrac <= 1.0f);
	Assert (stemp > -99.0);
	Assert (stemp < 100.0);

	if (stemp <= 0.0f )		// too cold?
	{
		potentProd.forestC = 0.0f;
		return;
	}

	// Estimate potential production based on temp & h2o
	// Calculate temperature effect on growth.
	// potential production:
	float soilTempEffectFraction =
		::gpdf ( stemp, ppdf_ref (0, 1), ppdf_ref (1, 1),
			 ppdf_ref (2, 1), ppdf_ref (3, 1) );
	soilTempEffectFraction *= 0.8f;	 // Added to match version 3.0 -lh 4/93

	// Calculate moisture effect on growth -
	// Value for potential plant production is now calculated from the
	// equation of a line whose intercept changes depending on water
	// content based on soil type.  The function PPRDWC contains the
	// equation for the line.  -rm 9/91
	// Trees are allowed to access the whole soil profile -rm 2/97

 	float const soilWaterEffectFraction = PotPlantProdFromSoilH2O (
	    water.extrSoilH2OTree,
	    MoistureRatioForGrowth (
		water.extrSoilH2OTree, prodPrecip, prodPET, prodMonthFrac) );

        parfs.pptprd = soilWaterEffectFraction;

	// For large wood, calculate the fraction which is live (sapwood)
	// Use in calculating monthly maintenance respiration (below).
	//Assert (parfs.sapk != forestC.rlwodc);
	//float const liveLargeWoodFraction =
	//	parfs.sapk / (parfs.sapk + forestC.rlwodc);

	// Calculate LAI and then use in function for LAI reducer on
	// production.  -rm 5/91
	float const lai = canopy.LAI (forestC.rleavc, forestC.rlwodc);
	float const totalPotentialProduction =
		param.prdx[1] *
		soilTempEffectFraction *
		soilWaterEffectFraction *
		co2.co2cpr[FORSYS] *
		WoodProductionFromLAI (lai, parfs.laitop) *
		prodMonthFrac;

	// Calculate monthly maintenance respiration:
	// respiration values for the forest system production components.
        // Maintenace respiration is calculated differently now. -mdh 7/30/01
	//float resppt[FPARTS];
        //float tave = 0.5 * (prodTempMin + prodTempMax);
	//resppt[LEAF]  = prodMonthFrac * ForestMaintRespiration (tave,  nps.rleave[N]);
	//resppt[FROOT] = prodMonthFrac * ForestMaintRespiration (stemp, nps.froote[N]);
	//resppt[FBRCH] = prodMonthFrac * ForestMaintRespiration (tave,  nps.fbrche[N]);
	//resppt[LWOOD] = prodMonthFrac * ForestMaintRespiration (tave,
	//				liveLargeWoodFraction  * nps.rlwode[N]);
	//resppt[CROOT] = prodMonthFrac * ForestMaintRespiration (stemp,
	//				liveLargeWoodFraction  * nps.croote[N]);
	//for (short part = 0; part < FPARTS; ++part)
	//    forestC.sumrsp += resppt[part];

        // Use 0.5 to convert from biomass to carbon in forest system
	// - Mike Ryan & Dennis Ojima
	// Added calculation of maxForestC  -rm  11/91
	float const maxForestC =
		param.prdx[2] *
		soilTempEffectFraction *
		soilWaterEffectFraction *
		WoodProductionFromLAI (lai, parfs.laitop) *
		prodMonthFrac;
        // forestC.sumrsp is a monthly accumulator of forest maintentance
        // respiration.  Don't use it here. -mdh 7/16/02
	//potentProd.forestC = totalPotentialProduction * 0.5f - forestC.sumrsp;
        potentProd.forestC = totalPotentialProduction * 0.5f;
	potentProd.forestC = std::max ( potentProd.forestC, 0.0f );
	potentProd.forestC = std::min ( potentProd.forestC, maxForestC );

	if ( potentProd.forestC > 0.01f )
	{
		// Compute carbon allocation fractions of each tree part
		TreeDynamCarbonAlloc (
			potentProd.forestC,
			0.5f * (prodTempMin + prodTempMax),
			// the following parameters return values:
			parfs.treeCfrac);
	}
	else
		potentProd.forestC = 0.0f;
 }
