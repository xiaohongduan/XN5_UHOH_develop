#ifndef INC_nrel_century_CenturyProjectBase_h
#define INC_nrel_century_CenturyProjectBase_h
// ----------------------------------------------------------------------------
//	Copyright 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  CenturyProjectBase.h
//	Class:	  CenturyProjectBase
//
//	Description:
//	Base class for a Century project. A project is defined by
//	* simulation configuration
//	* project file (INI format)
//	* simulation history
//	* editor information
//
//	Responsibilities:
//	* Provides configuration data and a public interface to it.
//	* Maintains a simulation history.
//	* Knows editor information.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Nov2004
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------
//	Notes:
//	There are 3 parts to the Century project class hierarchy:
//	(1) project classes (base, monthly, daily)
//	(2) project I/O class (base, monthly, daily)
//	(3) GUI dialog to edit the project
//
//	!!! This is class is under construction !!!
// ----------------------------------------------------------------------------

#include "ProjectGroup.h"
#include "TCenturyConfigBase.h"
#include "timeutil.h"
#include "EditorsInfo.h"
#include "TSharedPtr.h"
#include <stack>

namespace nrel
{

  namespace century
  {

class CenturyProjectBase
	: public TEH::SimulationProject,
	  public TEH::NamedProject
{
  public:
	//---- types: Simulation history
	typedef TSharedPtr<TCenturyConfigBase>	CenturyConfigPtr;
	struct TSimEvent		// holds one simulation event record
	{
	  TDateTime dateTime;
	  // to do: replace by class CenturySimConfigInfo
	  std::string siteFileName;
	  std::string mgmtFileName;
	  std::string outputFileName;
	  std::string userName;
	  std::string description;
	};
	typedef std::stack<TSimEvent>		TSimHistory;

	//---- constructors and destructor
  protected:
	CenturyProjectBase (
	  std::string const & projectName,		// project name
	  CenturyConfigPtr useConfig,			// configuration
	  EditorsInfo const & useEditInfo)
	  : TEH::SimulationProject (),
	    TEH::NamedProject (projectName),
	    config (useConfig),
	    editInfo (useEditInfo),
	    modified (false)
	  {
	  }
	CenturyProjectBase (
	  CenturyProjectBase const & object)
	  : TEH::SimulationProject (object),
	    TEH::NamedProject (object)
	  {
	    Copy (object);
	  }
  public:
	virtual ~CenturyProjectBase () = 0;
	virtual CenturyProjectBase * const Clone () const = 0;	// Clone this

	//---- operator overloads
	CenturyProjectBase& operator= (
	  CenturyProjectBase const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	Clear ();
		Copy (object);
	    }
	    return *this;
	  }
	bool operator== (
	  CenturyProjectBase const & object) const
	  {
	    if ( &object )
	    {
		return NamedProject::operator== (object) &&
		  config == object.config;
	    }
	    else
		return false;
	  }
	bool operator!= (
	  CenturyProjectBase const & object) const
	  { return !(*this == object); }

	//---- functions: configuration
	void SetConfig (
	  CenturyConfigPtr useConfig)
	  { config = useConfig; }
	void SetConfig (
	  TCenturyConfigBase const & useConfig)
	  { *config = useConfig; }
	TCenturyConfigBase const & GetConfig () const
	  { return config; }

	//---- functions: editors info
	EditorsInfo const & GetEditorsInfo () const
	  { return editInfo; }

	//---- functions: simulation history
	void AppendSimHistory (
	  TSimHistory const & historyItem)
	  {
	    // To Do: AppendSimHistory
	  }
	TSimHistory const & GetSimHistory () const
	  { return simHistory; }

	//---- functions: misc
	void Clear ()					// "Clear" data members
	  {
	    config->Clear();
	    editInfo.Clear();
	    // never clear the simulation history!
	    modified = true;
	  }

	//---- functions: Queries
	bool IsEmpty () const				// True if no data
	  {
	    return config.get() == 0 &&
		simHistory.empty();
	  }
	bool IsModified () const			// True if modified
	  { return modified; }

  protected:
	//---- constants

	//---- data
	CenturyConfigPtr config;			// config pointer
	EditorsInfo editInfo;				// editing info
	TSimHistory simHistory;				// simulation history
	bool modified;					// true if data changed

	//---- functions

  private:
	//---- constants

	//---- data

	//---- functions
	void Copy (					// Copy to this
	  CenturyProjectBase const & object)
	  {
	    if ( &object )
	    {
	    	config = object.config;
		simHistory = object.simHistory;
		editInfo = object.editInfo;
		modified = object.modified;
	    }
	  }
};

inline CenturyProjectBase::~CenturyProjectBase ()
{
}


  } // namespace century

} // namespace nrel

#endif // INC_CenturyProjectBase_h
