               Century version 5 and the Century Model Interface
                                  NetCDF Files


Contents
--------
File Types
File Names
Common Global Attributes
Revision History


File Types
----------

*.cdl	netCDF "common data form" source files (text).
*.nc	netCDF binary files; built with the following command:
		ncgen -b <filename>.cdl

File Names
----------

BlkDef
	Block Library Management Data; block definitions.

BlkHeader
	Block Library Management Data; block headers.

ManageDef
	Management Scheme: block definitions.

ManageInst
	Management Scheme: block instances.

ManageScheme
	Management Scheme: simulation data and block headers.

EcoSumOutVarsDef
	Ecosystem summary output variables' names and definitions.



Common Global Attributes
------------------------
title
	Descriptive title of the file.
	Important! The value of this attribute should NEVER be changed!

LastModifiedWho
	Name of user who last modified this file.

LastModifiedWhen
	Date and time this file was last modified.

LastModifiedHow
	Software or process which was used to modify this file.

FileType
	Tag indicating the type of Century/CMI information contained
	in this file. Tags are unique relative to the file's content.
	Important! The value of this attribute should NEVER be changed!
	See the file "ncftypes.h" for values and descriptions.

Version
	Integer indicating the version number of this file. This number
	should be incremented whenever the structure of the netCDF file
	is modified. In the Century/CMI code, this value can be
	examined in order to determine how to read in the data.

	For example, if a parameter is added to the site file, then
	the version number is incremented. In the source code function
	TNcSiteParameters::Read, an "if" block check on this value
	determines where in the array of site parameter values an
	adjustment is to made as to where values are stored.



Revision History
----------------
03Apr30	 Tom Hilinski	First version.



--- end of document ---
