// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  readblk.cpp
//	Class:	  TCenturyBase
//	Function: GetCurrentMgmt
//
//	Description:
//	Reads the next block of events from the schedule file.
//	Returns the new block instance number.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jan98
//	History:
//	Aug03	Tom Hilinski
//	* Added loop to be sure the current block instance contains the
//	  current simulaton year.
//	* New member functions SynchronizeMgmt and FindWeatherFileInMgmt
//	  encapsulate and expand upon much of the checks and sync'ing
//	  that was done here.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include <cstring>
#include <sstream>

MY_TEMPLATE_DECLARATION
short TCENTURYBASE::GetCurrentMgmt (
	short const blockInstNum)	// block instance number; zero-based
{
	if ( !GetManagement().get() )		// mgmt scheme allocated?
		return blockInstNum;		// how to handle this better?

	// get next block instance, that matches the current simulation time.
	std::string weatherFileNameStr;
	short const currentBlockInstNum = SynchronizeMgmt (
		st->year, *blockInstanceList.get(), blockInstNum );
	FindWeatherFileInMgmt ( *blockInstanceList.get(), currentBlockInstNum,
				weatherFileNameStr );
	AddPathToWeatherFile ( weatherFileNameStr );

	// tell scheduler which block and instance we are now at
	TInstanceListItem const & item =
		blockInstanceList->GetInstance ( currentBlockInstNum );
	sched->SetActiveBlock ( GetManagement()->GetBlock (item.blockNum) );

	sched->SetActiveInstance (
		sched->GetActiveBlock()->GetInstance (item.instNum) );
	TManagementInst * const inst =
		const_cast<TManagementInst * const>(
			sched->GetActiveInstance () );
	inst->weatherFile = weatherFileNameStr;
	sched->SetActiveInstance (inst);

	// add to Century's variables
	st->blockStartYear =
	  sched->GetActiveInstance()->yearFirst;	// first sim year
	st->blockEndYear =
	  sched->GetActiveInstance()->yearLast;	// last sim year
	st->writeYear =
	  sched->GetActiveInstance()->outputStartYr;	// sim yr output begins
	st->writeMonth =
	  sched->GetActiveInstance()->outputStartMo;	// month output begins
	// Save the output frequency value
	if (sched->GetActiveInstance()->outputInterval <
	    st->dt - st->dt * 0.0001f)				// too small?
		st->SetOutputFreq (st->dt);			// use minimum
	else
		st->SetOutputFreq (
			sched->GetActiveInstance()->outputInterval );

	// weather
	weather->InitAnnualData (
		sched->GetActiveInstance()->weatherSource,
		weatherFileNameStr.c_str() );

	// store events
	// Note: the following needs to be modified to allow range events.

	// initialize the event scheduler
	sched->currentEventIndex = 0;		// index to the event arrays

	// Get the current system being simulated:
	// crop/grass, forest, or savanna
	// Reset system for each block to handle changing systems.
	// Store the value of the previous system
	TPlantSystemType previousSystem;
	if (currentBlockInstNum > 0)
		previousSystem = sysType;
	// search the event list to see if crop or tree or both are specified
	bool haveCrop = false, haveTree = false;
	for ( short evtCount = 0;
		evtCount < sched->GetActiveBlock()->GetEventCount();
		++evtCount )
	{
		TManagementEvent const *currentEvent =
			sched->GetActiveBlock()->GetEvent(evtCount);
		if ( currentEvent->type == ET_Crop )		// found a crop?
			haveCrop = true;
		else if ( currentEvent->type == ET_Tree )	// found a tree?
			haveTree = true;
		if ( haveCrop && haveTree )		// can stop searching?
			break;
	}
	// If no crop or forest designation was given in the
	// first block, use the initial system designated
	sysType.Type() = (haveCrop && haveTree) ?
		SysType_Savanna :
		( haveCrop ?
			SysType_CropGrass :
			( haveTree ? SysType_Forest : SysType_Unknown ) );

	if ( sysType.IsUnknown() )		// don't have either?
	{
	    if (currentBlockInstNum == 0) // 1st block; check crop | tree types
	    {
		if ( sysType.HaveCropGrass() )
			haveCrop = true;
		if ( sysType.HaveTree() )
			haveTree = true;
		sysType.Type() = haveCrop && haveTree ? SysType_Savanna :
				 ( haveCrop ? SysType_CropGrass :
				   ( haveTree ? SysType_Forest :
				     SysType_Unknown ) );
	    }
	    else	// have a system from a previous block instance
		sysType = previousSystem;
	}

	// Check if decsys needs to be updated.  If it does, predec()
	// will also have to be called so new decomposition parameters
	// are initialized
	if ( decomp->GetSystemType().IsCropGrass() && haveTree )
	{
		decomp->SetSystemType ( SysType_Forest );
		decomp->InitializeSOMDecomp ();
	}

	return currentBlockInstNum;
}

//--- end of file ---
