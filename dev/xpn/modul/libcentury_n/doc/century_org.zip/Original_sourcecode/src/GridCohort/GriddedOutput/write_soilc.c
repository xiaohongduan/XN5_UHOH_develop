
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include "netcdf.h"
#include "wrtcdf.h"

int
write_soilc(float soilc[][12])
{
        int status;
        float *p = (float *) soilc;

	/* Write output to NetCDF file */
	status = nc_put_vara_float(soilc_ncid, defac_id, start, count, p);
	status = nc_put_vara_float(soilc_ncid, som1c1_id, start, count, p + 12);
	status = nc_put_vara_float(soilc_ncid, som1c2_id, start, count, p + 24);
	status = nc_put_vara_float(soilc_ncid, som2c_id, start, count, p + 36);
	status = nc_put_vara_float(soilc_ncid, som3c_id, start, count, p + 48);
	status = nc_put_vara_float(soilc_ncid, strucc1_id, start, count, p + 60);
	status = nc_put_vara_float(soilc_ncid, strucc2_id, start, count, p + 72);
	status = nc_put_vara_float(soilc_ncid, metabc1_id, start, count, p + 84);
	status = nc_put_vara_float(soilc_ncid, metabc2_id, start, count, p + 96);

	/* Reset memory for variable soilc */
	 memset(p, '\0', (sizeof(float) * 9 * 12));

	return 0;
}
