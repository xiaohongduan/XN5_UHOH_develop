
/*              Copyright 1998 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include "netcdf.h"

/* Externally defined variables */
extern int PrecNcid, MinTNcid, MaxTNcid;
extern int T_precip_id, T_mintmp_id, T_maxtmp_id;
extern size_t maskRows, maskCols;
extern short *mask;
extern int curr_row;
extern size_t months;
extern int t_index;
extern int wrepeat;
extern float *geoglat, *geoglon;

void handle_error(char *funcname, int status);

/* Read weather for current year from NetCDF files */

int
tranwth_(float prec[], float precnxt[], float tmin[], float tmax[],
       int *nrow, int *ncol, float *lat, float *lon, int *no_of_cols)
{
       float annprc;
       int mth, retval;
       int cellNo;
       static int cellNo_save = -1;
       int status;
       static size_t start[2] = {0,0};
       static size_t nstart[2] = {0,0};
       static size_t count[2] = {1,12};

       retval = 0;
       annprc = 0;

       /* Determine which cell index to access */
       cellNo = mask[*nrow * maskCols + *ncol]-1;
/*       printf("tranwth: nrow = %1d\n", *nrow);
       printf("tranwth: ncol = %1d\n", *ncol);
       printf("tranwth: maskCols = %1d\n", maskCols);
       printf("tranwth: cellNo = %1d\n", cellNo); */

       /* Set starting and ending location for NetCDF reads */
       /* For variables */
       start[0] = cellNo;
       /* nstart[0] was not initialized. -mdh 11/14/00 */
       nstart[0] = cellNo;

       /* If first time through for this cell simulation */
       /* The original check for resetting the index was not working */
       /* properly when reading only a portion of a transient weather */
       /* file (stopped reading before reached end of the file).  */
       /* Changed the conditional for determining when we are simulating */
       /* a new cell.  cak - 09/20/01
/*       if (start[1] == 0) { start[1] = (size_t)t_index; */
       if (cellNo != cellNo_save) {
          start[1] = (size_t)t_index;
          cellNo_save = cellNo;
       }

       nstart[1] = start[1]+12;

       /* Latitude and Longitude are read from geog.nc now -mdh 9/30/99 */
       *lat = geoglat[*nrow * *no_of_cols + *ncol];
       *lon = geoglon[*nrow * *no_of_cols + *ncol];

/*       fprintf(stdout, "tranwth: no_of_cols = %1d\n", *no_of_cols);
       fprintf(stdout, "tranwth: nrow = %1d\n", *nrow);
       fprintf(stdout, "tranwth: ncol = %1d\n", *ncol);
       fprintf(stdout, "tranwth: cell = %1d\n", cellNo);
       fprintf(stdout, "tranwth: lat = %5.2f\n", *lat);
       fprintf(stdout, "tranwth: lon = %5.2f\n", *lon); */

/*       fprintf(stdout, "tranwth: cellNo = %1d\n", cellNo);
       fprintf(stdout, "tranwth: t_index = %1d\n", t_index);
       fprintf(stdout, "tranwth: months = %1d\n", months);
       fprintf(stdout, "tranwth: start[0] = %1d\n", start[0]);
       fprintf(stdout, "tranwth: start[1] = %1d\n", start[1]);
       fprintf(stdout, "tranwth: nstart[0] = %1d\n", nstart[0]);
       fprintf(stdout, "tranwth: nstart[1] = %1d\n\n", nstart[1]); */

       /* Do you have the correct row if you are returning to this function? */
       /* If the cell is valid get weather values */
       if (mask[*nrow * maskCols + *ncol] >= 1)
       {
           status = nc_get_vara_float(PrecNcid, T_precip_id, start, count, prec);
           if (status != NC_NOERR) handle_error("nc_get_vara_float(prec-TranGetWth)", status);
           status = nc_get_vara_float(MinTNcid, T_mintmp_id, start, count, tmin);
           if (status != NC_NOERR) handle_error("nc_get_vara_float(tmin-TranGetWth)", status);
           status = nc_get_vara_float(MaxTNcid, T_maxtmp_id, start, count, tmax);
           if (status != NC_NOERR) handle_error("nc_get_vara_float(tmax-TranGetWth)", status);
	   if (nstart[1] <= months-12)
	   {
              status = nc_get_vara_float(PrecNcid, T_precip_id, nstart, count, precnxt);
              if (status != NC_NOERR) handle_error("nc_get_vara_float(precnxt)", status);
	      start[1] += 12;
	   }
	   else
	   {
              /* Repeat using the starting index read from the initialization */
              /* file, cak - 01/02/02 */
/*              start[1] = 0; */
              start[1] = (size_t)t_index;
              /* If you want to repeat weather from the beginning, same cell */
              if (wrepeat == 1)
              {
/*                 nstart[1] = 0; */
                 nstart[1] = (size_t)t_index;
                 status = nc_get_vara_float(PrecNcid, T_precip_id, nstart, count, precnxt);
                 if (status != NC_NOERR) handle_error("nc_get_vara_float(precnxt)", status);
	      }
	   }

           /* Compute annual precipitation */
/*           printf("prec: "); */
           for (mth=0; mth<12; mth++)
	   {
	       /* Convert precip from mm to cm */
	       prec[mth] *=  0.1;
	       precnxt[mth] *=  0.1;
	       annprc += prec[mth];
/*               printf("%5.2f  ", prec[mth]); */
	   }
/*           printf("\n"); */

           /* Is the precipitation reasonable? */
           if (annprc <= 0.0) 
	   {
	       /* If no precip, add in nominal amount to avoid 0 divide */
	       annprc = 0.5;
               for (mth=0; mth<12; mth++) prec[mth] = .5/12;
	   }
       }
       else
	  retval = 2;


       return retval;
}
