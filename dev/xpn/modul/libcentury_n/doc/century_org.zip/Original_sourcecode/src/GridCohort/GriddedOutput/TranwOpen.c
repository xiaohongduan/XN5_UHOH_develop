
/*              Copyright 1998 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "gridconst.h"
#include "netcdf.h"

/* Global Variables */
int PrecNcid, MinTNcid, MaxTNcid;
int T_precip_id, T_mintmp_id, T_maxtmp_id;
size_t months;

void handle_error(char *funcname, int status);

/* Open Transient NetCDF Weather Files */

int
TranwOpen(FILE *fp_init)
{

	char line[MAXL+1];
	int errno;
	size_t tmp_months;
	int monthid;
        int status;

	char pfname[FNAMEMAX];
	char nfname[FNAMEMAX];
	char xfname[FNAMEMAX];

	errno = 0;

	/* Get Name of Precip NetCDF File */
        fgets(line, MAXL, fp_init);
        fgets(line, MAXL, fp_init);
        sscanf(line, "%s", pfname);

        /* Get Name of Min-Temp NetCDF file */
        fgets(line, MAXL, fp_init);
        fgets(line, MAXL, fp_init);
        sscanf(line, "%s", nfname);

        /* Get Name of Max-Temp NetCDF file */
        fgets(line, MAXL, fp_init);
        fgets(line, MAXL, fp_init);
        sscanf(line, "%s", xfname);

	/* Open files */
	if ((status = nc_open(pfname, NC_NOWRITE, &PrecNcid)) != NC_NOERR)
	   printf("TranwOpen: Unable to open file %s\n", pfname);

	if ((status = nc_open(nfname, NC_NOWRITE, &MinTNcid)) != NC_NOERR)
	   printf("TranwOpen: Unable to open file %s\n", nfname);

	if ((status = nc_open(xfname, NC_NOWRITE, &MaxTNcid)) != NC_NOERR)
	   printf("TranwOpen: Unable to open file %s\n", xfname);

	/* Inquire number of months in weather files */
	status = nc_inq_dimid(PrecNcid, "month", &monthid);
        if (status != NC_NOERR) handle_error("nc_inq_dimid(prec)", status);
	status = nc_inq_dimlen(PrecNcid, monthid, &months);
        if (status != NC_NOERR) handle_error("nc_inq_dimlen(prec)", status);
/*        printf("months(ppt) = %1d\n", months); */

	/* Check that the number of months is the same in all files */
	status = nc_inq_dimid(MinTNcid, "month", &monthid);
        if (status != NC_NOERR) handle_error("nc_inq_dimid(tmin)", status);
	status = nc_inq_dimlen(MinTNcid, monthid, &tmp_months);
        if (status != NC_NOERR) handle_error("nc_inq_dimlen(tmin)", status);
	if (tmp_months != months) errno = 1; 
/*        printf("tmp_months(TN) = %1d\n", tmp_months); */

	status = nc_inq_dimid(MaxTNcid, "month", &monthid);
        if (status != NC_NOERR) handle_error("nc_inq_dimid(tmax)", status);
	status = nc_inq_dimlen(MaxTNcid, monthid, &tmp_months);
        if (status != NC_NOERR) handle_error("nc_inq_dimlen(tmax)", status);
/*        printf("tmp_months(TX) = %1d\n", tmp_months); */

        if (tmp_months < months) {
           fprintf(stderr, "tmp_months(%1d) < months(%1d) in Tranwopen.c\n",
              tmp_months, months);
           fprintf(stderr, "setting months = tmp_months\n");
           months = tmp_months;
        }

	if (tmp_months != months) {
	   errno = 1; 
        }

  	/* Get variable IDs */
	status = nc_inq_varid(PrecNcid, "ppt",  &T_precip_id);
        if (status != NC_NOERR) handle_error("nc_inq_varid(ppt)", status);
	status = nc_inq_varid(MinTNcid, "tmin", &T_mintmp_id);
        if (status != NC_NOERR) handle_error("nc_inq_varid(tmin)", status);
	status = nc_inq_varid(MaxTNcid, "tmax", &T_maxtmp_id);
        if (status != NC_NOERR) handle_error("nc_inq_varid(tmax)", status);

	return errno;
}
