// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  updatewv.cpp
//	Class:	  TCenturyBase
//	Function: UpdateWaterVariables
//
//	Description:
// 	Updates soil water content variables.
//	The water content variables need to be updated whenever
//	(1) a water infiltration event occurs,
//	(2) upon any change in the soil structure or textural composition,
//	    e.g., erosion, deposition, tillage, etc.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu
//	History:
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
//	* Added flag for optional calc of rwcf values - they site parameter
//	  values were always being overwritten at the start of the sim.
//	Nov04	Tom Hilinski
//	* Split TWater.wc into extrSoilH2OCrop and extrSoilH2OTree.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include <cmath>

//	UpdateWaterVariables
MY_TEMPLATE_DECLARATION
void TCENTURYBASE::UpdateWaterVariables (
	bool const updateRWCF)	// true if calc rwcf(*)
{
	//--- Update available water pools
	// plant-extractable water content fraction for soil layer
	if ( updateRWCF )
	{
		for (short layer = 0; layer < MELoopLimit(); ++layer)
			wt.rwcf[layer] = soil->GetPlantExtractableWCF (layer);
	}
	// plant-available water in the rooting depth of soil
	wt.avh2o[0] = soil->PlantExtractableWater (0.0f, water.depthOfRoots);
	Assert (wt.avh2o[0] >= 0.0f);
	// plant-available water in the depth of soil
	wt.avh2o[1] = soil->PlantExtractableWater (0, soil->BottomLayer());
	Assert (wt.avh2o[1] >= 0.0f);
	// plant-available water in the simulation depth of soil
	wt.avh2o[2] = soil->PlantExtractableWater (0.0f, wt.simDepth);
	Assert (wt.avh2o[2] >= 0.0f);

	//--- water content (volumetric) in the root depth;
	//    used to determine plant production in potcrp and potfor.
	// From Bill Parton (April 2000)
	// "WC should be calculated for the NLYPG depth with the
	// potential NPP equations."
	water.extrSoilH2OCrop =
		soil->MeanPlantWaterCapacity (0.0f, water.depthOfRoots);
	water.extrSoilH2OTree =
		soil->MeanPlantWaterCapacity (0, soil->BottomLayer());
}

//--- end of file updateWaterVars.cpp ---

