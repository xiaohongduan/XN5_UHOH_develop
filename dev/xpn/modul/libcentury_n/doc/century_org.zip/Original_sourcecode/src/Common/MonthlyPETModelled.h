#ifndef INC_MonthlyPETModelled_h
#define INC_MonthlyPETModelled_h

// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  MonthlyPETModelled.h
//	Class:	  MonthlyPETModelled
//
//	Description:
//	Class for submodel of montly Potential Evapotranspiration (PET).
//	Members were extracted from original Century 4/5 model.
//
//	Responsibilities:
//	* Provides a value for total monthly PET.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Oct 2004
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

class MonthlyPETModelled
{
  public:
	//---- constructors and destructor
	MonthlyPETModelled ()
	  {
	  }
	MonthlyPETModelled (
	  MonthlyPETModelled const & object)
	  {
	    Copy (object);
	  }
	~MonthlyPETModelled ()
	  {
	  }

	//---- operator overloads
	MonthlyPETModelled& operator= (
	  MonthlyPETModelled const & object)
	  {
	    Copy (object);
	    return *this;
	  }

	//---- functions
	float PET (
    	  float const latitude, 		// site latitude
    	  float const fwloss,			// PET loss factor
    	  					//   (from fixed.fwloss[3])
    	  float const minTemp,			// minimum temp for month
    	  float const maxTemp,			// maximum temp for month
    	  float const minAnnualMeanTemp,	// minimum of mean monthly
    	  					//   temperatures for year.
    	  float const maxAnnualMeanTemp,	// maximum of mean monthly
    	  					//   temperatures for year.
    	  float const elevation			// elevation:
    	  	= 0.0f);

	//---- functions: Queries

  protected:
	//---- constants

	//---- data

	//---- functions

  private:
	//---- constants
	static float const minimumMonthlyPET;	// minimum monthly PET

	//---- data: external
	// Century internal data
	// Century output variables

	//---- data: const parameters

	//---- data

	//---- functions
	void Copy (				// Copy to this
	  MonthlyPETModelled const & object)
	  {
	  }
};

#endif // INC_MonthlyPETModelled_h
