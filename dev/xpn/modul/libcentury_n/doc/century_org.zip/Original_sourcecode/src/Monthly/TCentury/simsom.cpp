// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  simsom.cpp
//	Class:	  TCentury
//	Function: SimulateSOM
//
//	Description:
//	Simulate flow of carbon, nitrogen, phosphorous, and sulfur.
//	This routine is executed each time step.  It calls the decomposition
//	submodel and a producer submodel.  It also includes a bunch of
//	N fixation stuff that needs to be rewritten and put in its own routine.
//	This is the main driver function for the model.
// ----------------------------------------------------------------------------
//	History:
//	6/91	rm
//	Added new local variable FSOL.  Added calls to new function FSFUNC
//	to calculate the amount of mineral P that is in solution.  Added
//	call to new subroutine PSCHEM, which calculates and schedules the
//	Phosophorus and Sulfur flows during decomposition.  Previously
//	this was calculated in the DECOMP routine.  -
//	Dec99   Tom Hilinski, tom.hilinski@colostate.edu
//	* Consolidated code for leaching of mineralized N, P, and S.
//	Nov01   Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved erosion/deposition processes to be the first processes.
//	Dec01   Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to use new mineral E pools.
//	Sep03	Tom Hilinski
//	* Merged many mods from TDayCent::SimulateSOM.
//	* Added function CalcAMINRL to remove duplicate code.
//	* Also, the initial calc of nps.aminerl at the top of the function
//	  did not average, rather used the entire amount of E in the sim. layer.
// ----------------------------------------------------------------------------

#include "TCentury.h"
using namespace std;

//	CalcAMINRL
//	calculate the value for nps.aminrl
inline
void CalcAMINRL (
	float * const aminrl,			// nps.aminrl[3]
	float const fractionInSolutionP,	// fraction of P in solution
	float const simDepth,			// depth to calc in
	TMCSoil const * const soil,		// the soil
	short const numElements)		// number of elements
{
    for (short element = 0; element < numElements; ++element)
    {
	aminrl[element] = 0.5f *
	    ( aminrl[element] +
	      soil->QuantityE ( (TMineralElements)element, 0.0f, simDepth ) );
	if (element == P)
	    aminrl[element] *= fractionInSolutionP;
    }
}

void TCentury::SimulateSOM ()
{
    // Set aminrl for use in routines called from decomp
    if ( site.nelem > 1 )
    {
	::CalcAMINRL ( nps.aminrl,
    		       FractionMinPInSolution ( wt.simDepth, soil->MineralP() ),
		       wt.simDepth, soil.get(), site.nelem );
    }
    else
    {
	::CalcAMINRL ( nps.aminrl, 0.0f, wt.simDepth, soil.get(), site.nelem );
    }

    // Determine decomposition factor and initialize accumulators
    InitMonthlyCycle ();

    //--- Physical Process Submodels ---

    // submodel: Soil erosion
    if ( sched->DoingErosion() )
    {
    	// Erode the pools
	Assert (erosion.get() != 0);
   	float const erodedThickness = erosion->Erode (st->time);
	// Erode the physical soil
	std::auto_ptr<TSoilLayer> layer = soil->NewLayerLike (0);
	soil->Erode (erodedThickness, *layer);
	Assert (soil->SoilDepth() >= wt.simDepth);
	if ( soil->LastError() != NSSoilErrors::NoError )
	{
		Assert (soil->LastError() != NSSoilErrors::NoError);
		// TO DO: error handling
	}
    }

    // submodel: Deposition
    if ( sched->DoingDeposition() )
    {
    	// Deposit the pools
    	Assert (deposition.get() != 0);
	std::auto_ptr<TSoilLayer> newLayer = deposition->Deposit (st->time);
	// Deposit the physical soil
	soil->Deposit (*newLayer);
	if ( soil->LastError() != NSSoilErrors::NoError )
	{
		Assert (soil->LastError() != NSSoilErrors::NoError);
		// TO DO: error handling
	}
    }
    if ( sched->DoingErosion() || sched->DoingDeposition() )
    {
	// Update dependencies upon soil texture and water
	UpdateFromTexture ();
	UpdateFromSoilWater ();
	// Update pools for remaining processes
	Update ();				// Update the flows and sums
    }

    //--- Biological Process Submodels ---

    // submodel: N Fixation
    // Does not take into account the effect of irrigation
    if ( fixed.nsnfix == 1 && SimPhosphorous() )
    {
	// Compute mineral N:P ratio for N-Fixation (use suface layer only)
    	// rnpml1 is used to control soil N-fixation using a regression
	// equation based on Kansas data.
	// This ratio is used only if nelem = 2.
	// rnpml1 is flagged if either minerl(1,1) or minerl(1,2) is zero.

	float const quantityP = soil->QuantityE (P, 0.0f, wt.simDepth);
	Assert (quantityP > 0.0f);
	nps.rnpml1 = soil->QuantityE (N, 0.0f, wt.simDepth) / quantityP *
		FractionMinPInSolution ( wt.simDepth, soil->MineralP() );

	// Wet-dry fixation of nitrogen -- monthly flow
	// Atmospheric fixation is split between monthly dry fall and ?
	// Both wdfnp and fxbiom are relative functions
	// which vary from 0 to 1.
	// wdfnp computed as a negative natural log of rnpml1
	// symnfx is the symbiotic N fixation by legumes derived from Cole
	// and Heil (1981) using data from Walker et al. 1959.
	float wdfnp;	// N:P ratio control for non-symbiotic N fixation.
	if (nps.rnpml1 == 0.0f)
	    wdfnp = 1.0f;
	else
	{
	    Assert (fixed.fxnpb > 0.0f);
	    wdfnp = std::min ( 1.0f,
	    		(float) -std::log (nps.rnpml1) / fixed.fxnpb - 0.2f );
	}
	// The definitions of fxmca and fxmcb originally refered to water,
	// not biomass. (Alister 11/91)
	float const tbiom = cropC.aglivc + cropC.stdedc + soilC.strucc[SRFC];
	float const fxbiom =
		std::min (1.0f, 1.0f - (fixed.fxmca + tbiom * fixed.fxmcb) );
	// fraction of wet/dry fixation of nitrogen
	register float fwdfx;
	if (wdfnp < 0.0f || fxbiom < 0.0f || wt.stemp < 7.5f)
	    fwdfx = 0.0f;
	else
	    fwdfx = wdfnp * fxbiom;

	// Monthly abiotic N-fixation based upon monthly precipitation
	Assert (wt.prcann > 0.0f);
	nps.wdfxma = nps.wdfxa * weather->Precip(st->month) / wt.prcann;
	nps.wdfxms = fixed.fxmxs * fwdfx;
    }
    else	// Monthly abiotic N-fixation based upon annual parameters
    {
	Assert (wt.prcann > 0.0f);
	float const ratio = weather->Precip (st->month) / wt.prcann;
	nps.wdfxms = nps.wdfxs * ratio;
	nps.wdfxma = nps.wdfxa * ratio;
    }
    nps.wdfxma = soilFlows->FlowNPSintoMineralSoil (
    			N, &nps.esrsnk[N], nps.wdfxma, wt.simDepth );
    nps.wdfxms = soilFlows->FlowNPSintoMineralSoil (
    			N, &nps.esrsnk[N], nps.wdfxms, wt.simDepth );
    nps.wdfxas += nps.wdfxms;
    nps.wdfxaa += nps.wdfxma;

    // submodel: Atmospheric S deposition
    if ( SimSulfur() )
    {
	float const atmosphericS =
		param.satmt * weather->Precip(st->month) / wt.prcann;
	float const irrigationS = ( sched->DoingIrrigation() ?
		param.sirri * wt.irract * 0.01f :
		0.0f );
	nps.satmac += soilFlows->FlowNPSintoMineralSoil (
			S, &nps.esrsnk[S], atmosphericS, wt.simDepth);
	nps.sirrac += soilFlows->FlowNPSintoMineralSoil (
			S, &nps.esrsnk[S], irrigationS, wt.simDepth);
    }

    Update ();					// Update the flows and sums

    // submodel: Decomposition
    // Determine  whether cultivation occurs this month.
    // Removed this call from DECOMP and put it here -rm 2/91
    // Removed it from here and put it in CYCLE.  -vk 3/91

    // Initialize stream variables for organic leaching (they are
    // monthly output).  -rm 3/92
    for (short element = 4; element < 8; ++element)
	wt.stream[element] = 0.0f;

    // Initialize monthly co2 accumlators (10/92)
    for (short i = 0; i < ISOS; ++i)			// for each isotope...
    {
	co2.st1c2[i] = co2.st2c2[i] = co2.mt1c2[i] = co2.mt2c2[i] =
	  co2.s11c2[i] = co2.s21c2[i] = co2.s2c2[i] = co2.s3c2[i] =
	  0.0f;
    }

    // Call decomp routines ntspm times per month.
    // Removed the P and S chemistry from decomp and created the
    // subroutine pschem.  -rm  6/91
    for (short kts = 0; kts < fixed.ntspm; ++kts)
    {
	decomp->Decompose (st->dtDecomp, wt.anerb, wt.defac);
	if ( SimPhosphorous() || SimSulfur() )
	    PSDecompChemistry (st->dtDecomp);
	Update ();				// Update the flows and sums

	// aminrl contains the average amount of N, P, and S
	// available in the simulation layer for the time period covered by
	// dt/ntspm.  minerl contains the current value of mineral N,
	// P, and S by layer.
	if ( site.nelem > 1 )
	{
	    ::CalcAMINRL ( nps.aminrl,
		FractionMinPInSolution ( wt.simDepth, soil->MineralP() ),
		wt.simDepth, soil.get(), site.nelem );
	}
	else
	{
	    ::CalcAMINRL ( nps.aminrl, 0.0f,
	    		   wt.simDepth, soil.get(), site.nelem );
	}
    }

    UpdateFromSoilWater ();	// update depedencies on SOM and soil water

    // Annual co2 accumulators (10/92)
    co2.amt1c2 += co2.mt1c2[UNLABL] + co2.mt1c2[LABELD];
    co2.amt2c2 += co2.mt2c2[UNLABL] + co2.mt2c2[LABELD];
    co2.as11c2 += co2.s11c2[UNLABL] + co2.s11c2[LABELD];
    co2.as2c2 +=  co2.s2c2[UNLABL]  + co2.s2c2[LABELD];
    co2.as3c2 +=  co2.s3c2[UNLABL]  + co2.s3c2[LABELD];
    co2.ast1c2 += co2.st1c2[UNLABL] + co2.st1c2[LABELD];
    co2.as21c2 += co2.s21c2[UNLABL] + co2.s21c2[LABELD];
    co2.ast2c2 += co2.st2c2[UNLABL] + co2.st2c2[LABELD];

    // Volatilization loss of N as a function of
    // gross mineralization (nitrification)
    if ( nps.gromin[N] > 0.0f )
    {
    	float const lossN = fixed.vlossg * nps.gromin[N];
	nps.volgm = soilFlows->FlowNPSfromMineralSoil (
			N, &nps.esrsnk[N], lossN, wt.simDepth);
	nps.volgma += nps.volgm;		// accumulate volatilization
    }

    // Fertilization option
    // Flow into the simulation layer. Assume the distribution is
    // immediate and uniform.
    if ( sched->DoingFertilization() )
    {
	for (short element = 0; element < site.nelem; ++element)
	{
		float const fertAmount =
			soilFlows->FlowNPSintoMineralSoil (
				(TMineralElements)element,
				&nps.esrsnk[element], param.feramt[element],
				wt.simDepth);
		nps.fertot[element] += fertAmount;
		param.feramt[element] -= fertAmount;
	}
    }

    // Available nutrients in the rooting depth of the soil profile.
    // Needed for crop/grass growth.
    UpdateMineralEVariables ();

    // Compute the fraction of labile (non-sorbed) P in the surface
    // layer available to plants
     Assert (fixed.favail[5] != 0.0f);
    float const r3 = fixed.favail[3] +
    	soil->QuantityE (N, 0.0f, wt.simDepth) *
	(fixed.favail[4] - fixed.favail[3]) /
	fixed.favail[5];
    float const r2 = std::min (r3, fixed.favail[4]);
    fixed.favail[1] = std::max (fixed.favail[3], r2);

    // Add to fallow rain
    if ( InFallowPrecipTime() == 1 && !sched->DoingHarvest() )
	wt.prcfal += weather->Precip(st->month);

    // submodel: Production
    // Crop and Forest removal options - moved here from CROP
    // and TREES so the mineral pools are not radically changed
    // between the growth routines. - rm 7/94
    if (sysType.IsCropGrass())
    {
	SimulateCrop ();
	if ( sched->DoingCropGrassFire() ||
	     sched->DoingGrazing() )			// Fire and grazing
	    RemoveCropGrass ();
    }
    else if (sysType.IsForest())
    {
	SimulateTrees ();
	// Fire or cutting events
	if ( sched->DoingForestFire() || sched->DoingTreeRemoval() )
	    ForestRemoval ();
    }
    else if (sysType.IsSavanna())
    {
	SimulateCrop ();
	SimulateTrees ();
	if ( sched->DoingSavannaFire() ||
	     sched->DoingGrazing() )		// Fire and grazing
	    RemoveCropGrass ();
	if ( sched->DoingTreeRemoval() )	// Fire or cutting events
	    ForestRemoval ();
    }

    Update ();				// Update the flows and sums

    // Harvest may be performed after updating flows.  Put here for
    // consistency with the Savanna model - moved calls to flowup,
    // sumcar and harvst from CROP routine to here. -rm 7/94
    if ( sched->DoingHarvest() )
	HarvestCrop ((short)st->month, comput.pltlig);

    UpdateFromSoilWater ();	// update depedencies on SOM and soil water

    // submodel: Leaching of mineralized N, P, and S
    // Set leachFraction to leaching fraction. vek june90
    // Compute normal value for leachFraction.
    // Recompute in flood routine if flooding occurs.
    float const textureEffect = fixed.fleach[INTCPT] +
	fixed.fleach[SLOPE] *
	soil->SandFraction().WtdMean ( 0.0f, wt.simDepth,
				soil->Depth(), soil->Thickness() );
    Assert (textureEffect != 0.0f);
    float leachFraction[NUMELEM];			// leaching fraction
    for (short element = 0; element < site.nelem; ++element)
    {
	leachFraction[element] = textureEffect * fixed.fleach[element + 2];
	if (element == P)
	    leachFraction[element] *=
	    	FractionMinPInSolution ( wt.simDepth, soil->MineralP() );
    }
    LeachMineralNPS (leachFraction);

    // Accumulate leached C,N,P,S
    soilC.csrsnk[UNLABL] += leachOC->GetLeachedC (UNLABL);
    soilC.csrsnk[LABELD] += leachOC->GetLeachedC (LABELD);
    wt.stream[4] += leachOC->GetLeachedC ();		// org. C monthly
    for (short element = 0; element < site.nelem; ++element)
	nps.esrsnk[element] +=
		wt.stream[element + 1] +
		leachOC->GetLeachedE ((TMineralElements)element);

    // Volatilization loss as a function of the mineral N which
    // remains after uptake by plants (denitrification)
    if (nps.aminrl[N] > 0.0f)
    {
	nps.volex = soilFlows->FlowNPSfromMineralSoil (
		N, &nps.esrsnk[N],
		(fixed.vlosse * nps.aminrl[N] * st->dt),
		wt.simDepth );
    	nps.volexa += nps.volex;		// accumulate volatilization
    }

    // accumulate: Net Mineralization
    // Net mineralization for the mineralizing compartments
    // The structural component of litter and the wood compartments
    // are not mineralizers.  They should not be added into cmn or
    // sumnrs.
    for (short element = 0; element < site.nelem; ++element)
    {
	float const cmn =
		metmnr_ref (SRFC, element) +
		metmnr_ref (SOIL, element) +
		nps.s2mnr[element] +
		nps.s3mnr[element] +
		s1mnr_ref (SOIL, element) +
		s1mnr_ref (SRFC, element);
	nps.sumnrs[element] += cmn;

	// soilnm is net mineralization in the soil.
	nps.soilnm[element] +=
		s1mnr_ref (SOIL, element) +
		nps.s2mnr[element] +
		nps.s3mnr[element] +
		metmnr_ref (SOIL, element) +
		strmnr_ref (SOIL, element) +
		nps.w3mnr[element];

	// Total net mineralization
	nps.tnetmn[element] +=
		cmn +
		nps.w1mnr[element] +
		nps.w2mnr[element] +
		nps.w3mnr[element] +
		strmnr_ref (SOIL, element) +
		strmnr_ref (SRFC, element);
    }

    // end of simulation iteration - update and output tasks
    UpdateFromSoilWater ();	// update depedencies on SOM and soil water

    if ( sched->HaveExternalEvent() )
	asynchCom.DoExternalEvent ();
}

//--- end of SimulateSOM ---
