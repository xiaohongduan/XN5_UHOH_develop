#ifndef INC_nrel_dcirc_OutputVariablesByCell
#define INC_nrel_dcirc_OutputVariablesByCell

// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  OutputVariablesByCell.h
//	Class:	  OutputVariablesByCell
//
//	Description:
//	Management of output variables by cell for DayCentIRC.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, April 2005
//	History:
//	<date, eg., 22May01>	<your name>, <your e-mail address>
//	<description>
// ----------------------------------------------------------------------------

#include "OutputVariables.h"

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class OutputVariablesByCell
	: public OutputVariables
{
  public:
	//---- types

	//---- constructors and destructor
	OutputVariablesByCell (
	  OwnerType * const ownerPtr)		// ptr to object owning this
	  : OutputVariables (ownerPtr)
	  {
	  }
	OutputVariablesByCell (
	  OutputVariablesByCell const & object)
	  : OutputVariables (object)
	  {
	  }
	~OutputVariablesByCell ()
	  {
	  }

	//---- operator overloads

	//---- functions

  protected:
	//---- data

	//---- functions
	void CollectOutputForCell ();		// Output for all biomes in cell

  private:
	//---- data

	//---- functions
	virtual void DoUpdateValues ();

};

  } // namespace dcirc
} // nrel

#endif // INC_nrel_dcirc_OutputVariablesByCell
