
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  cremv_ncid;			/* netCDF id */

/* variable ids */
int shremc_id, sdremc_id, rlvremc_id, fbrremc_id, rlwremc_id, wd1remc_id, wd2remc_id,
   stremc_id, metrmc_id;

int
cremvdef(int *ntimes, char *history) {		/* create cremv.nc */

   int status;

   /* dimension ids */
   int  time_dim = 0;
   int  cell_dim = 0;

   /* variable shapes */
   int dims[2];

   /* enter define mode */
   status = nc_create("cremv.nc", NC_CLOBBER, &cremv_ncid );

   /* define dimensions */
   status = nc_def_dim(cremv_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(cremv_ncid, "cell", NC_UNLIMITED, &cell_dim);

   /* define variables */

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (cremv_ncid, "shremc", NC_FLOAT, 2, dims, &shremc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (cremv_ncid, "sdremc", NC_FLOAT, 2, dims, &sdremc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (cremv_ncid, "rlvremc", NC_FLOAT, 2, dims, &rlvremc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (cremv_ncid, "fbrremc", NC_FLOAT, 2, dims, &fbrremc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (cremv_ncid, "rlwremc", NC_FLOAT, 2, dims, &rlwremc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (cremv_ncid, "wd1remc", NC_FLOAT, 2, dims, &wd1remc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (cremv_ncid, "wd2remc", NC_FLOAT, 2, dims, &wd2remc_id);

   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (cremv_ncid, "stremc", NC_FLOAT, 2, dims, &stremc_id);
 
   dims[0] = cell_dim;
   dims[1] = time_dim;
   status = nc_def_var (cremv_ncid, "metrmc", NC_FLOAT, 2, dims, &metrmc_id);


   /* assign attributes */
   status = nc_put_att_text (cremv_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (cremv_ncid, shremc_id, "long_name", 
        strlen("above_ground_live_carbon_removed"), "above_ground_live_carbon_removed");
   status = nc_put_att_text (cremv_ncid, shremc_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (cremv_ncid, sdremc_id, "long_name", 
	strlen("standing_dead_carbon_removed"), "standing_dead_carbon_removed");
   status = nc_put_att_text (cremv_ncid, sdremc_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (cremv_ncid, rlvremc_id, "long_name", 
	strlen("live_leaf_carbon_removed"), "live_leaf_carbon_removed");
   status = nc_put_att_text (cremv_ncid, rlvremc_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (cremv_ncid, fbrremc_id, "long_name", 
	strlen("live_fine_branch_carbon_removed"), "live_fine_branch_carbon_removed");
   status = nc_put_att_text (cremv_ncid, fbrremc_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (cremv_ncid, rlwremc_id, "long_name", 
	strlen("live_large_wood_carbon_removed"), "live_large_wood_carbon_removed");
   status = nc_put_att_text (cremv_ncid, rlwremc_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (cremv_ncid, wd1remc_id, "long_name", 
	strlen("dead_fine_branch_carbon_removed"), "dead_fine_branch_carbon_removed");
   status = nc_put_att_text (cremv_ncid, wd1remc_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (cremv_ncid, wd2remc_id, "long_name", 
	strlen("dead_large_wood_carbon_removed"), "dead_large_wood_carbon_removed");
   status = nc_put_att_text (cremv_ncid, wd2remc_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (cremv_ncid, stremc_id, "long_name", 
	strlen("surface_structural_carbon_removed"), "surface_structural_carbon_removed");
   status = nc_put_att_text (cremv_ncid, stremc_id, "units", strlen("g/m2"), "g/m2");

   status = nc_put_att_text (cremv_ncid, metrmc_id, "long_name", 
	strlen("surface_metabolic_carbon_removed"), 
	"surface_metabolic_carbon_removed");
   status = nc_put_att_text (cremv_ncid, metrmc_id, "units", strlen("g/m2"), "g/m2");

   /* leave define mode */
   status = nc_enddef (cremv_ncid);
   return 0;
}
