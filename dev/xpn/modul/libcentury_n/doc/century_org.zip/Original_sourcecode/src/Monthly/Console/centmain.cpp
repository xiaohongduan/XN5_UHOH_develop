// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  centmain.cpp
//	Class:	  TCentury
//	Function: main
//
//	Description:
//	Contains main() for the standalone build of Century.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
//	History:
//	Aug01	Tom Hilinski,
//	* Removed MINGW32 stuff.
//	* Changed many char* to std::string
//	* Used new class TCentDefaultSetup
//	* Changed TCentury* century to std::auto_ptr<TCentury>
//	Oct01	Tom Hilinski
//	* Modified to work with the new Century class constructor and its
//	  new configuration class, TCenturyConfig.
//	Apr03	Tom Hilinski
//	* Added Terminate function.
//	* Misc. cleanup.
//	Sep03	Tom Hilinski
//	* Added verbose messages optionally displayed.
//	* Made exitCode assignments consistant.
//	Jun05	Tom Hilinski
//	* Added code to handle site file write at end of simulation.
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include "TEventDBList.h"
#include "CenturyPaths.h"
#include "TCmdLine.h"
#include "TUserPref.h"
#include "fnutil.h"
#include "SiteException.h"
#include "WeatherException.h"
#include "MCSiteCreator.h"
#include <iostream>
using namespace std;

//	DisplayMsg
//	Display messages to the user.
inline
void DisplayMsg (
	std::string const & str)
{
	if ( !str.empty() )
		std::cout << str << std::endl;
}

inline
void DisplayMsg (
	char const * const str)
{
	if ( str )
		std::cout << str << std::endl;
}

//	DisplaySimYear
//	Display simuation year to the user.
inline
void DisplaySimYear (
	const long year)
{
	std::cout << year << std::endl;
}

//	Terminate
//	Handle uncaught exceptions.
inline
void Terminate ()
{
	::DisplayMsg ("An unknown error terminates the simulation.");
}

bool WriteSiteFile (
	std::string const & newSiteFileName,
	TCenturyConfig const & config,
	TCentury const & century)
{
	// update the site information
	TSharedPtr<TMCSiteParameters const> oldSite = century.GetSite();
	EditorsInfo editInfo = oldSite->GetEditInfo();
	editInfo.SetEditorName ( config.GetUserName() );
	editInfo.SetEditDate( ::DateTimeStr() );

	// Create new site parameter set from century model internal values
	TMCSiteParameters newSite (
		config.GetPaths()->GetPath(CenturyPaths::Templates),
		config.GetPaths()->GetPath(CenturyPaths::Work),
		oldSite->GetSiteParamInfo() );
	::nrel::century::MCSiteCreator siteCreator (	// create from
		century, editInfo, newSite );
	newSite.SetName ( oldSite->GetName() );
	newSite.SetDescription ( oldSite->GetDescription() );
	newSite.SetSiteType ( oldSite->GetSiteType() );
	siteCreator.MakeParameters ();

	// write the parameter set to a file
	bool failed = false;				// return value
	std::string errorMsg;
	try
	{
	    if ( newSiteFileName.empty() )
	    {
		errorMsg = "File name was not specified.";
		throw true;
	    }
	    newSite.SetBaseName (newSiteFileName);
	    failed = newSite.WriteNcFile ();
	    if ( failed )
		throw true;
	}
	catch (...)
	{
		failed = true;
	}
	if ( failed )
	{
		if ( !newSite.GetNcFileName().GetFullName().empty() )
		{
		    errorMsg +=
			"Failed writing the site parameters "
			"to the NetCDF file:\n";
		    errorMsg += newSite.GetNcFileName().GetFullName();
		}
		if ( newSite.IsError() )
		{
			errorMsg += "\nSite parameter set error message:\n";
			errorMsg += newSite.GetErrorMsg();
		}
	}
	if ( !errorMsg.empty() )
		throw errorMsg;
	return failed;
}


int main (int argc, char **argv)
{
	std::set_terminate ( Terminate );	// terminate function
	int exitCode = 0;			// exit code returned to OpSys

	// Century instance lifetime is <= lifetime of configuration object
	std::auto_ptr<TCentury> century;	// Century model instance
	std::auto_ptr<TCenturyConfig> config;	// Century model configuration
	bool verboseMsg = false;

	try			// exception-handling for the entire simulation
	{
		//--- sim configuration
                ::nrel::century::CenturySimConfigInfo configInfo;

		//--- Get command line arguments
		TCenturyCmdLine cmdLine (
			argc,
			const_cast<char const * const * const>(argv),
			configInfo );
		if ( cmdLine.GetMessageCount() > 0 )
			::DisplayMsg (  cmdLine.GetMessages() );
		if ( cmdLine.ArgError() )
		{
			::DisplayMsg (
				"Error in the command line. Terminating now.");
		}
		if ( cmdLine.Terminate() )
			goto all_done;
		verboseMsg = cmdLine.GetDebugInfo().verbose;

		//--- Setup the Century configuration

		if ( verboseMsg )
			::DisplayMsg ( "Configuring..." );

		// Get the executable path
		std::string exePath = TEH::ActualPath (argv[0]);
		Assert (!exePath.empty());

		// Check for an .INI file
		std::string workPath;
		std::string userName = configInfo.GetUserName();
		TUserPref userPref;
		if ( !cmdLine.GetIniFile().empty() )
		{
			userPref.SetIniFile ( cmdLine.GetIniFile() );
			if ( userPref.ReadIniFile() )
			{
			    // warning message
			    ::DisplayMsg (
				  "Could not read the initialization file.");
			}
			else
			{
			    workPath = userPref.GetWorkPath().GetFullPath();
			    if ( !userName.empty() )
			    	userName = userPref.GetName();
			}
		}
		configInfo.SetUserName (userName);

		TAsynchCommunication asynchCom (
			::DisplayMsg,			// message function
			::DisplayMsg,			// warning function
			0);				// sim. year function

		// build config object
		config.reset (
		    new TCenturyConfig (
			configInfo.GetSiteFileName(),
			configInfo.GetManagementFileName(),
			configInfo.GetOutputFileName(),
			configInfo.GetOutputType(),
			configInfo.GetOutputAccess(),
			configInfo.ProduceOutput(),
			exePath,
			workPath,		// path to work files
			"",			// parameters path (use default)
			configInfo.GetParameterSearchPaths(),
			"",			// templates path (use default)
			"",			// textdata path (use default)
			configInfo.GetFixFileName(),
			configInfo.GetUserName(),
			&asynchCom ) );
		if ( config->HaveWarningMsg() )
			::DisplayMsg ( config->GetWarningMsg() );
		config->FindAndThrowError ();	// check for config. errors

		//--- Initialize the model
		if ( verboseMsg )
			::DisplayMsg (
				"Creating " CenturyNickname "..." );
		century.reset (
			new TCentury ( *config, cmdLine.GetDebugInfo() ) );

		//--- initialize and run the simulation
		if ( verboseMsg )
			::DisplayMsg ( "Begin initialization..." );
		if ( century->InitializeModel () )	// init failed?
			exitCode = 1;
		if ( exitCode == 0 )
		{
			if ( verboseMsg )
				::DisplayMsg ( "Begin simulation run..." );
			if ( century->RunToCompletion() )	// run failed?
				exitCode = 1;			// ...yes
		}

		// new site file?
		if ( exitCode == 0 && !cmdLine.GetNewSiteFile().empty() )
		{
			// write a site file
			if ( verboseMsg )
				::DisplayMsg ( "Writing the new site file..." );
			bool failed = WriteSiteFile (
				cmdLine.GetNewSiteFile(), *config, *century);
			if ( failed )
			{
				exitCode = 1;
				if ( verboseMsg )
					::DisplayMsg ( "Failed!" );
			}
			else
			{
				if ( verboseMsg )
					::DisplayMsg ( "Successful!" );
			}
		}
	}

	catch (TCentException const & ce)	// exceptions thrown by Century
	{
		::DisplayMsg ( ce.GetMsg() );
		exitCode = ce.GetCode();
	}
	catch (nrel::weather::WeatherException const & e)
	{
		std::string msg (
			"A weather dataset error "
			"terminates the simulation.\nError is: ");
		msg += e.what();
		::DisplayMsg ( msg );
		exitCode = 1;
	}
	catch (nrel::site::SiteException const & e)
	{
		std::string msg (
			"A site parameter set error "
			"terminates the simulation.\nError is: ");
		msg += e.what();
		::DisplayMsg ( msg );
		exitCode = 1;
	}
	catch (std::exception const & e)	// other exceptions (elaborate!)
	{
		std::string msg (
			"An error terminates the simulation.\nError is: ");
		msg += e.what();
		::DisplayMsg ( msg );
		exitCode = 1;
	}
						// error in paths
	catch ( CenturyPaths::TDefPathErr pathErr )
	{
		char const* errStr[] =
		{
			"no error",
			"no path",
			"invalid path index",
			"invalid executable file path",
			"invalid parameters path",
			"invalid templates path",
			"invalid management library path",
			"invalid site library path",
			"invalid block library path",
			"memory allocation failed",
			"unknown error",
			0
		};
		std::string msg ("Directory path error: ");
		msg += errStr[pathErr];
		::DisplayMsg ( msg );
		exitCode = 1;
	}

	catch (char const * const aMsg)
	{
		::DisplayMsg (aMsg);
		exitCode = 1;
	}

	catch (std::string const & aMsg)
	{
		::DisplayMsg ( aMsg );
		exitCode = 1;
	}

	catch (...)			// anything else not caught
	{
		::Terminate ();
		exitCode = 1;
	}

all_done:			// all done! errors previously handled
	if ( verboseMsg )
		::DisplayMsg ( "   all done!\n" );
	century.reset ();	// delete Century before config object
	config.reset ();	// delete config object after Century
	return exitCode;
}

//--- end of definitions for main ---
