#ifndef INC_nrel_century_MCSiteCreator_h
#define INC_nrel_century_MCSiteCreator_h

// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  MCSiteCreator.h
//	Class:	  MCSiteCreator
//
//	Description:
//	Class for creating site parameter files for monthly Century.
//
//	Responsibilities:
//	* <what class is supposed to do>
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, June 2005
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "CenturySiteCreatorBase.h"
#include "TMCSiteParameters.h"

class TCentury;

namespace nrel
{
  namespace century
  {

class MCSiteCreator
	: public CenturySiteCreatorBase<TCentury>
{
  public:
	//---- types

	//---- constructors and destructor
	MCSiteCreator (
	  TCentury const & monthlyCentury,		// model source
	  EditorsInfo const & useEditInfo,
	  TMCSiteParameters & siteParameters)		// fill this
	  : CenturySiteCreatorBase<TCentury> (
	  	monthlyCentury, useEditInfo, siteParameters)
	  {
	  }
	MCSiteCreator (
	  MCSiteCreator const & object)
	  : CenturySiteCreatorBase<TCentury> (object)
	  {
	  }
	virtual ~MCSiteCreator ()
	  {
	  }

	//---- operator overloads

	//---- functions

  protected:
	//---- constants

	//---- data

	//---- functions

  private:
	//---- constants

	//---- data

	//---- functions
	virtual void GetMineralE (
	  TSiteParamSet & parameterSet );
};

  } // namespace century
} // namespace nrel

#endif // INC_nrel_century_MCSiteCreator_h
