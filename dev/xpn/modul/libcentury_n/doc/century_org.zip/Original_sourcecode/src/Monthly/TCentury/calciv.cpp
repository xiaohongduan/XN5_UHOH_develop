// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  calciv.cpp
//	Class:	  TCentury
//	Function: InitializePools
//
//	Description:
//	Calculate initial values for temperature, water and live root.
//	This is done only once, at the start of a simulation.
// ----------------------------------------------------------------------------
//	History:
//	May99	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added initialization of new water/temp output variable, "simDepth".
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to keep temp and precip constant w/microcosm simulation.
//	* Simplified litter partitioning w/loop over layers.
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include <sstream>

void TCentury::InitializePools ()
{
    // Compute mean annual temperature (meanAnnualTemp) and
    // mean annual precipitation (meanAnnualPrecip)
    float meanAnnualTemp;			// mean annual temperature
    float meanAnnualPrecip;			// mean annual precipitation
    if ( SimMicrocosm() )
    {
    	meanAnnualTemp = microcosm->GetTemperature();
    	meanAnnualPrecip = 0.0f;
    }
    else	// no microcosm
    {
	meanAnnualTemp =
	  std::min (weather->MeanAnnualTemp(), 23.0f);	 // limit to 23 degs.
	meanAnnualPrecip =
	  std::min (weather->MeanAnnualPrecip(), 120.0f); // limit to 120 cm.
    }

    // soil initializations
    wt.simDepth = fixed.edepth;
    wt.soilDepth = soil->SoilDepth();

    // current silt and clay fractions for the simulation layer
    float const clayFrac = soil->ClayFraction().WtdMean ( 0.0f, fixed.edepth,
    					 soil->Depth(), soil->Thickness() );
    float const siltFrac = soil->SiltFraction().WtdMean ( 0.0f, fixed.edepth,
    					 soil->Depth(), soil->Thickness() );

    // Initialize soil C pools for a grassland soil
    if ( IsGrasslandSoil() )
    {
	// tcg = total soil carbon in grams (som1c + som2c + som3c)
	register float tcg = (meanAnnualTemp * -0.827f +
		meanAnnualTemp * 0.0224f * meanAnnualTemp +
		meanAnnualPrecip * 0.127f -
		meanAnnualPrecip * 9.38e-4f * meanAnnualPrecip +
		meanAnnualPrecip * siltFrac * 0.0899f +
	       	meanAnnualPrecip * clayFrac * 0.06f + 4.09f) * 1000.0;

	// Assign a fixed value to surface som1.   vek  08-91
	som1ci_ref (SRFC, UNLABL) = 10.0f;
	som1ci_ref (SRFC, LABELD) = 0.0f;

	// Burke's equations only apply to soil compartments.
	som1ci_ref (SOIL, UNLABL) = tcg * 0.02f;
	som1ci_ref (SOIL, LABELD) = 0.0f;
	soilC.som2ci[UNLABL] = tcg * 0.64f;
	soilC.som2ci[LABELD] = 0.0f;
	soilC.som3ci[UNLABL] = tcg * 0.34f;
	soilC.som3ci[LABELD] = 0.0f;
	cropC.stdcis[UNLABL] = 80.0f;
	cropC.stdcis[LABELD] = 0.0f;
	nps.stdede[N] = 1.6f;
	nps.stdede[P] = 0.3f;
	nps.stdede[S] = 0.3f;
	cropC.bglcis[UNLABL] = 200.0f;
	cropC.bglcis[LABELD] = 0.0f;
	nps.bglive[N] = 3.0f;
	nps.bglive[P] = 0.5f;
	nps.bglive[S] = 0.5f;
	clittr_ref (SRFC, UNLABL) = 100.0f;
	clittr_ref (SRFC, LABELD) = 0.0f;
	clittr_ref (SOIL, UNLABL) = 100.0f;
	clittr_ref (SOIL, LABELD) = 0.0f;
    }

    // Initialize soil C pools for cultivated soils
    else if ( IsCultivatedSoil() )
    {
	// tcg = total soil carbon in grams (som1c + som2c + som3c)
	register float tcg = (meanAnnualTemp * -0.75f +
		meanAnnualTemp * 0.021f * meanAnnualTemp +
		meanAnnualPrecip * 0.0581f -
		meanAnnualPrecip * 4.58e-4f * meanAnnualPrecip +
		meanAnnualPrecip * siltFrac * 0.0494f +
		meanAnnualPrecip * 0.0582f * clayFrac + 5.15f) * 1000.0;
	// Assign a fixed value to surface som1.   vek  08-91
	som1ci_ref (SRFC, UNLABL) = 10.0f;
	som1ci_ref (SRFC, LABELD) = 0.0f;
	// Burke's equations only apply to soil compartments. vek  08-91
	som1ci_ref (SOIL, UNLABL) = tcg * 0.02f;
	som1ci_ref (SOIL, LABELD) = 0.0f;
	soilC.som2ci[UNLABL] = tcg * 0.54f;
	soilC.som2ci[LABELD] = 0.0f;
	soilC.som3ci[UNLABL] = tcg * 0.44f;
	soilC.som3ci[LABELD] = 0.0f;
	cropC.stdcis[UNLABL] = 20.0f;
	cropC.stdcis[LABELD] = 0.0f;
	nps.stdede[N] = 0.4f;
	nps.stdede[P] = 0.075f;
	nps.stdede[S] = 0.075f;
	clittr_ref (SRFC, UNLABL) = 10.0f;
	clittr_ref (SRFC, LABELD) = 0.0f;
	clittr_ref (SOIL, UNLABL) = 10.0f;
	clittr_ref (SOIL, LABELD) = 0.0f;
    }

    // Starting values for nitrogen, phosphorus, and sulfur depend on
    // carbon values and the ratios of carbon to each other element.
    // Initialize structural and metabolic pools C, N, P, and S.
    // First set them to zero and calculate N/C, P/C, & S/C ratios.
    for (short layer = SRFC; layer <= SOIL; ++layer)
    {
	for (short isotope = 0; isotope < ISOS; ++isotope)
	{
	    strcis_ref (layer, isotope) = 0.0f;
	    metcis_ref (layer, isotope) = 0.0f;
	}
	for (short element = 0; element < site.nelem; ++element)
	{
	    struce_ref (layer, element) = 0.0f;
	    metabe_ref (layer, element) = 0.0f;
	}
    }
    SumCarbon ();		// Sum carbon isotopes

    //--- Partition above and belowground litter C content into
    //    structural/metabolic based upon litter C and litter lignin content.
    //    Calc structural and metabolic N, P, & S based upon amount of C
    //    and the N/C, P/C, and S/C ratios.

    for (short layer = SRFC; layer <= SOIL; ++layer)
    {
    	// N/C, P/C, and S/C ratios from C/N, C/P, and C/S.
	float ratioEC[NUMELEM];				// E:C ratio in litter
	for (short element = 0; element < site.nelem; ++element)
	{
		if (rcelit_ref (layer, element) > 0.0f)
			ratioEC[element] = 1.0f / rcelit_ref (layer, element);
		else
			ratioEC[element] = 0.0f;
	}
	// Plant lignin
	if ( sysType.HaveCropGrass() )
	{
		comput.pltlig[layer] = fligni_ref (INTCPT, layer) +
				fligni_ref (SLOPE, layer) * meanAnnualPrecip;
		Assert (comput.pltlig[layer] >= 0.0f);
		Assert (comput.pltlig[layer] <= 1.0f);
	}
	else if ( sysType.HaveTree() )
	{
	    if ( layer == SRFC )
	    	comput.pltlig[SRFC] = parfs.wdlig[LEAF];
	    else
	    	comput.pltlig[SOIL] = parfs.wdlig[FROOT];
	}
	else if ( sysType.HaveCropGrass() && sysType.HaveTree() )
	{
	    if ( layer == SRFC )
		comput.pltlig[SRFC] =
			(parfs.wdlig[LEAF] + fligni_ref (INTCPT, SRFC) +
			fligni_ref (SLOPE, SRFC) * meanAnnualPrecip) * 0.5f;
	    else
		comput.pltlig[SOIL] =
			(parfs.wdlig[FROOT] + fligni_ref (INTCPT, SOIL) +
			fligni_ref (SLOPE, SOIL) * meanAnnualPrecip) * 0.5f;
	}
	// total C and fractions of labeled C in litter
	float const totalLitterC =
    		clittr_ref (layer, UNLABL) + clittr_ref (layer, LABELD);
	float const fractionLabeledC =
		clittr_ref (layer, LABELD) / totalLitterC;
	// Partition the litter
	PartitionResidue (totalLitterC, ratioEC, layer,
			 (float* const)dummyC, (float* const)dummyE,
    			 comput.pltlig[layer], fractionLabeledC);
    }
    Update ();				// Update the flows and sums

    // Compute N, P, and S for surface and soil som1, as well as for
    // som2 and som3.   vek  08-91
    for (short e = 0; e < site.nelem; ++e)
    {
	if (rces1_ref (SRFC, e) > 0.0f)
	    som1e_ref (SRFC, e) = soilC.som1c[SRFC] / rces1_ref (SRFC, e);
	if (rces1_ref (SOIL, e) > 0.0f)
	    som1e_ref (SOIL, e) = soilC.som1c[SOIL] / rces1_ref (SOIL, e);
	if (param.rces2[e] > 0.0f)
	    nps.som2e[e] = soilC.som2c / param.rces2[e];
	if (param.rces3[e] > 0.0f)
	    nps.som3e[e] = soilC.som3c / param.rces3[e];
    }
    if ( sysType.HaveTree() )
    {
	for (short e = 0; e < site.nelem; ++e)
	{
	    if (cerfor_ref (2, FBRCH, e) > 0.0f)
		nps.wood1e[e] = forestC.wood1c / cerfor_ref (2, FBRCH, e);
	    if (cerfor_ref (2, LWOOD, e) > 0.0f)
		nps.wood2e[e] = forestC.wood2c / cerfor_ref (2, LWOOD, e);
	    if (cerfor_ref (2, CROOT, e) > 0.0f)
		nps.wood3e[e] = forestC.wood3c / cerfor_ref (2, CROOT, e);
	}
    }

    // Surface temperature and soil temperature:
    // Initialize from the site file weather data.
    if ( !SimMicrocosm() )
    {
	wt.tave = weather->MeanMonthlyTempSPD (1);	// January mean temp.
	wt.stemp = wt.tave;				// Init soil temp.
    }

    // Make sure there is N, P, and S for roots
    register float totalBglcis = cropC.bglcis[UNLABL] + cropC.bglcis[LABELD];
    if (totalBglcis > 0.0f)
    {
	for (short e = 0; e < site.nelem; ++e)
	{
	    // Added extra if check with Bill's recommendation -mdh 8/28/98
	    if (nps.bglive[e] <= 0.0f)
	    {
	    	if ( totalBglcis < 0.01f )	// no belowgound C?
	    	{
	    		cropC.bglcis[UNLABL] = cropC.bglcis[LABELD] = 0.0f;
	    	}
	    	else	// there is belowground C but not enough of E
	    	{
	    		std::ostringstream os;
			os << "Value for BGLIVE("
			   << (e + 1)
			   << ") must be greater than 0."
			   << std::ends;
			ThrowCentException ( TCentException::CE_UNKNOWN_ERROR,
	    					os.str().c_str() );
		}
	    }
	}
    }

    // Initialize grain pools
    cropC.cgrain = 0.0f;
    for (short e = 0; e < site.nelem; ++e)
	nps.egrain[e] = 0.0f;

    // all done!
}

//--- end of file ---

