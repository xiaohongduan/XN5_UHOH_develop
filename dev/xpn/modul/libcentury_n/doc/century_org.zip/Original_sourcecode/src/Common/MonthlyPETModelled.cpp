// ----------------------------------------------------------------------------
//	Copyright (c) 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  MonthlyPETModelled.cpp
//	Class:	  MonthlyPETModelled
//
//	Description:
//	Class for submodel of montly Potential Evapotranspiration (PET).
//	Members were extracted from original Century 4/5 model.
//
//	Responsibilities:
//	* Provides a value for total monthly PET.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Oct 2004
//	History: see header file.
// ----------------------------------------------------------------------------

#include "MonthlyPETModelled.h"
#include <algorithm>
#include <cmath>

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

float const MonthlyPETModelled::minimumMonthlyPET = 0.5f;

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

float MonthlyPETModelled::PET (
	float const latitude, 		// site latitude
    	float const fwloss,		// PET loss factor
    					//   (from fixed.fwloss[3])
    	float const minTemp,		// minimum temp for month
    	float const maxTemp,		// maximum temp for month
    	float const minAnnualMeanTemp,	// minimum of mean monthly temperatures
    					//   for year.
    	float const maxAnnualMeanTemp,	// maximum of mean monthly temperatures
    					//   for year.
    	float const elevation)		// elevation:
{
	//temperature range; min. temp. allowed = -10.0
	float const annualMeanTempRange =
		std::fabs (
		  maxAnnualMeanTemp -
		  std::max (minAnnualMeanTemp, -10.0f) );

	// Temperature range calculation
	float const annualTempRange =			// temp range adjusted
		maxTemp - std::max (-10.0f, minTemp);
	// effective temperature, and with elevation effect
	float const temp = annualTempRange * 0.5f + minTemp;
	float const tempWithElevEffect = temp + elevation * 0.006f;
	float const td = elevation * 0.0023f + temp * 0.37f +
			annualTempRange * 0.53f +
    			annualMeanTempRange * 0.35f - 10.9f;
	float const e = (tempWithElevEffect * 700.0f /
			(100.0f - std::fabs(latitude)) + td * 15.0f) /
			(80.0f - temp);
	// FWLOSS(4) is a modifier for PET loss. vek may90
	return std::max (e * 3.0f, minimumMonthlyPET) * fwloss;
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//--- end of definitions for MonthlyPETModelled ---

