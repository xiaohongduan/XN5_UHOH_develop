// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  pschem_dc.cpp
//	Class:	  TDayCent
//	Function: PSDecompChemistry
//
//	Description:
//	Calculates the P and S chemistry for decomposition flows.
// ----------------------------------------------------------------------------
//	History:
//      See Century/pschem.cpp
//      May01   Melannie Hartman, melannie@nrel.colostate.edu
//      * chaged wt.defac (monthly avg) to dwt.defac (computed daily)
//      19June01 Melannie Hartman, melannie@nrel.colostate.edu
//      * Changed this function from a TCentury member to a TDayCent member.
//      * Replaced some flows->Schedule() calls that flow minerl_ref(SRFC, E)
//        with calls to FlowNPSfromMineralSoil() and/or FlowNPSintoMineralSoil
//      11Jan02 Melannie Hartman, melannie@nrel.colostate.edu
//      * Updated to keep consistent with TCentury::PSDecompChemistry()
//        For one, the flow from parent material to mineral compartment, and
//        the flow from secondary material to mineral compartment, occur
//        into the entire soil profile instead of into wt.SimDepth.
// ----------------------------------------------------------------------------

#include "TDayCent.h"

void TDayCent::PSDecompChemistry (
	float const dtm)	// time step (years)
{
    //--- decomposition factor effect scaled for the time step
    float const decompFactor = dwt.defac * dtm;
    Assert (site.nelem > 1);
    for (short element = P; element < site.nelem; ++element)
    {
	//--- Determine the fraction of mineral P in solution
	float const fractionInSolution =
		( element == P ?
			FractionMinPInSolution (
				wt.simDepth, soil->Phosphorus() ) :
			1.0f );

	// Flow from parent material to mineral compartment.
	float const fparnt = fixed.pparmn[element] * nps.parent[element]
		* decompFactor;
	soilFlows->FlowNPSintoMineralSoil ( (TMineralElements)element,
		&nps.parent[element], fparnt, wt.simDepth,
		-1.0f /* only nitrate */ );

	// Flow from secondary to mineral compartment.
	float const fsecnd = fixed.psecmn[element] * nps.secndy[element]
		* decompFactor;
	soilFlows->FlowNPSintoMineralSoil ( (TMineralElements)element,
		&nps.secndy[element], fsecnd, wt.simDepth,
		-1.0f /* only nitrate */ );

	// Flow from mineral to secondary
	// Assumes
	// (1) the decomposition factor is the same for the entire profile.
	// (2) fraction in solution is the same for the entire profile.
	float const fmnsec = fixed.pmnsec[element] *
		soil->QuantityE ( (TMineralElements) element,
				  (short unsigned) 0,
				  (short unsigned) soil->BottomLayer() ) *
		(1.0f - fractionInSolution) * decompFactor;
	soilFlows->FlowNPSintoMineralSoil ( (TMineralElements)element,
		&nps.secndy[element], fmnsec,
		soil->SoilDepth(),
		-1.0f /* only nitrate */ );

    }
    //--- Flow from secondary Phosophorus to occluded Phosophorus.
    float const amountToFlow = fixed.psecoc * nps.secndy[P] * dwt.defac * dtm;
    flows->Schedule (&nps.secndy[P], &nps.occlud, st->time, amountToFlow);
}

//--- end of file ---

