// ----------------------------------------------------------------------------
//	Copyright 1998-2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  savarp.cpp
//	Class:	  TCenturyBase
//	Function: OutputVariables
//
//	Description:
//	Calculate values for many of the output variables.
// ----------------------------------------------------------------------------
//	History:
//	Jan00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Fixed bug in calculation of adefac. Was a remnant of the conversion
//	  of *BAD* Fortran (if you can imagine) to C.
//	Dec01   Tom Hilinski
//	* Modified to use new mineral E pools.
//	Nov02	Tom Hilinski
//	* Moved into base class TCenturyBase from class TCentury.
//	Aug03	Tom Hilinski
//	* Moved into N,P,S profile calcs into UpdateMineralEVariables.
//	Jun05	Tom Hilinski
//	* Moved update of water content output variables here from
//	  WriteOutputValues (same for monthly/daily).
//	* Added call to new virtual function UpdateMineralEOutputVariables.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"

MY_TEMPLATE_DECLARATION
void TCENTURYBASE::OutputVariables ()
{
    //--- misc. variables
    wt.soilDepth = soil->SoilDepth();

    //--- Compute soil organic matter sums
    soilC.somsc = soilC.som1c[SOIL] + soilC.som2c + soilC.som3c;
    if (param.swflag == 0)
    {
    	// if swflag > 0, somsc is calc'd prior to calling this function
	soilC.somsc = soilC.som1c[SOIL] + soilC.som2c + soilC.som3c;
    }
    if ( lowerSoil.get() )
	soilC.lhsomtc = lowerSoil->GetTotalC ();
    else
	soilC.lhsomtc = 0.0f;
    soilC.somtpc = soilC.lhsomtc + soilC.somsc;
    soilC.somtc = soilC.somsc + soilC.strucc[SOIL] + soilC.metabc[SOIL];
    // minimum annual total non-living C - soil and litter
    // float const temp = soilC.totc;
    soilC.totc =
      soilC.somtc + soilC.som1c[SRFC] + soilC.strucc[SRFC] + soilC.metabc[SRFC];
    // soilC.totc = std::min (soilC.totc, temp);

    forestC.woodc = forestC.wood1c + forestC.wood2c + forestC.wood3c;
    forestC.frstc = forestC.rleavc + forestC.frootc + forestC.fbrchc +
	forestC.rlwodc + forestC.crootc;
    forestC.fsysc = soilC.somtc +
    	soilC.strucc[SRFC] + soilC.metabc[SRFC] + soilC.som1c[SRFC] +
    	forestC.woodc + forestC.frstc;

    //--- Compute soil organic matter sums by isotope
    for (short i = 0; i < ISOS; ++i)			// for each isotope
    {
	soilC.somsci[i] = som1ci_ref(SOIL, i) + soilC.som2ci[i] +
				soilC.som3ci[i];
	soilC.somtci[i] = soilC.somsci[i] + strcis_ref(SOIL, i) +
				 metcis_ref(SOIL, i);
	// Add litter layer components, including surface som1
	// to get total organic matter including residue.  vek 08-91
	soilC.tomres[i] = soilC.somtci[i] + strcis_ref(SRFC, i) +
				metcis_ref(SRFC, i) + som1ci_ref(SRFC, i);
    }
    // annual accumulators
    comput.annualSumSoilC[0] +=
    			som1ci_ref(SOIL, UNLABL) + som1ci_ref(SOIL, LABELD);
    comput.annualSumSoilC[1] += soilC.som2ci[UNLABL] + soilC.som2ci[LABELD];
    comput.annualSumSoilC[2] += soilC.som3ci[UNLABL] + soilC.som3ci[LABELD];

    //--- Sum the co2 loss
    // Currently ignores co2 respired in declig
    // [0] = unlabeled, [1] = labeled
    comput.totco2 += co2.mt1c2[UNLABL] + co2.mt1c2[LABELD] +
			co2.mt2c2[UNLABL] + co2.mt2c2[LABELD] +
			co2.s11c2[UNLABL] + co2.s11c2[LABELD] +
			co2.s21c2[UNLABL] + co2.s21c2[LABELD] +
			co2.s2c2[UNLABL] + co2.s2c2[LABELD] +
			co2.s3c2[UNLABL] + co2.s3c2[LABELD] +
			co2.st1c2[UNLABL] + co2.st1c2[LABELD] +
			co2.st2c2[UNLABL] + co2.st2c2[LABELD];

    //--- Sum all C state variables
    soilC.totalc = soilC.somtc +
    		soilC.som1c[SRFC] + soilC.strucc[SRFC] + soilC.metabc[SRFC] +
		cropC.aglivc + cropC.stdedc + cropC.bglivc +
		soilC.csrsnk[UNLABL] + soilC.csrsnk[LABELD] +
		forestC.woodc + forestC.frstc +
		comput.totco2;

    //--- Calculate total mineral
    for (short e = 0; e < site.nelem; ++e)	// for each element
    {
	nps.somse[e] = som1e_ref(SOIL, e) + nps.som2e[e] + nps.som3e[e];
	nps.somte[e] = nps.somse[e] + struce_ref(SOIL, e) +
			metabe_ref(SOIL, e);
	nps.woode[e] = nps.wood1e[e] + nps.wood2e[e] + nps.wood3e[e];
	nps.frste[e] = nps.rleave[e] + nps.froote[e] + nps.fbrche[e] +
				nps.rlwode[e] + nps.croote[e];
	nps.fsyse[e] = nps.somte[e] + nps.woode[e] +
				nps.frste[e] + struce_ref(SRFC, e) +
				metabe_ref(SRFC, e) + som1e_ref(SRFC, e);
    }

    UpdateMineralEVariables ();
    // mineralized N,P,S output variables; specific to each Century class
    UpdateMineralEOutputVariables ();

    for (short e = 0; e < site.nelem; ++e)
    {
	nps.totale[e] =
		soil->QuantityE ( (TMineralElements)e,
			(unsigned short)0, soil->GetLayerCount() - 1 ) +
		nps.somte[e] +
		struce_ref(SRFC, e) +
		metabe_ref(SRFC, e) +
		som1e_ref(SRFC, e) +
		nps.aglive[e] +
		nps.stdede[e] +
		nps.bglive[e] +
		nps.esrsnk[e] +
		water.deepStoreE[e] +
		nps.parent[e] +
		nps.secndy[e] +
		nps.woode[e] +
		nps.frste[e] +
		nps.crpstg[e] +
		nps.forstg[e];
	if (e == P)
	    nps.totale[P] += nps.occlud;
    }

    // Above and below ground live C/N ratio
    if (nps.aglive[N] > 0.0f && nps.bglive[N] > 0.0f)
    {
	cropC.aglcn = cropC.aglivc / nps.aglive[N];
	cropC.bglcn = cropC.bglivc / nps.bglive[N];
    }
    else
    {
	cropC.aglcn = -999.0f;
	cropC.bglcn = -999.0f;
    }

    // Overall c/n, c/p, and c/s ratios in soil organic matter
    for (short element = 0; element < site.nelem; ++element)
	nps.tcerat[element] = soilC.somtc / nps.somte[element];

    // Average annual value of defac, the decomposition factor which
    // combines the effects of temperature and moisture.
    // A negative value indicates that defac has not yet been calculated
    // for the month.
    wt.adefac = 0.0f;
    short count = 0;
    for (short m = 0; m < MPY; ++m)			// for each month...
	if (comput.defacm[m] >= 0.0f)			// have a value?
	{
		++count;
		wt.adefac += comput.defacm[m];
	}
    if (count > 1)					// take average?
	wt.adefac /= (float)count;

    // Clittr output
    clittr_ref(SRFC, UNLABL) =
    			metcis_ref(SRFC, UNLABL) + strcis_ref(SRFC, UNLABL);
    clittr_ref(SRFC, LABELD) =
    			metcis_ref(SRFC, LABELD) + strcis_ref(SRFC, LABELD);
    clittr_ref(SOIL, UNLABL) =
    			metcis_ref(SOIL, UNLABL) + strcis_ref(SOIL, UNLABL);
    clittr_ref(SOIL, LABELD) =
    			metcis_ref(SOIL, LABELD) + strcis_ref(SOIL, LABELD);

    // Delta 13/14C output
    // [0] = surface, [[1] = soil, [0] = unlabeled, [1] = labeled
    soilC.dsomsc = DelLabeledC (soilC.somsci[LABELD], soilC.somsci[UNLABL]);
    soilC.dsomtc = DelLabeledC (soilC.somtci[LABELD], soilC.somtci[UNLABL]);
    soilC.dsom1c[SRFC] =
    	DelLabeledC (som1ci_ref(SRFC, LABELD), som1ci_ref(SRFC, UNLABL));
    soilC.dsom1c[SOIL] =
    	DelLabeledC (som1ci_ref(SOIL, LABELD), som1ci_ref(SOIL, UNLABL));
    soilC.dsom2c = DelLabeledC (soilC.som2ci[LABELD], soilC.som2ci[UNLABL]);
    soilC.dsom3c = DelLabeledC (soilC.som3ci[LABELD], soilC.som3ci[UNLABL]);
    soilC.dslit =
      	DelLabeledC (clittr_ref(SRFC, LABELD), clittr_ref(SRFC, UNLABL));
    soilC.dblit =
    	DelLabeledC (clittr_ref(SOIL, LABELD), clittr_ref(SOIL, UNLABL));
    soilC.dstruc[SRFC] =
    	DelLabeledC (strcis_ref(SRFC, LABELD), strcis_ref(SRFC, UNLABL));
    soilC.dstruc[SOIL] =
    	DelLabeledC (strcis_ref(SOIL, LABELD), strcis_ref(SOIL, UNLABL));
    soilC.dmetc[SRFC] =
    	DelLabeledC (metcis_ref(SRFC, LABELD), metcis_ref(SRFC, UNLABL));
    soilC.dmetc[SOIL] =
    	DelLabeledC (metcis_ref(SOIL, LABELD), metcis_ref(SOIL, UNLABL));

	// water content
	// layers with data
	short const deepStoreLayer = MAXLYR - 1;
	short const endLayer = MELoopLimit ();
	for ( short layer = 0; layer < endLayer; ++layer )
		wt.asmos[layer] = soil->WaterContent(layer);
	// layers w/o data - zero them
	short emptyLayer = endLayer;		// start after bottom of soil
	while ( emptyLayer < deepStoreLayer )
		wt.asmos[emptyLayer++] = 0.0f;
	// drainage pool layer
	wt.asmos[deepStoreLayer] = soil->GetDeepSoilStorage();

}

//--- end of file ---
