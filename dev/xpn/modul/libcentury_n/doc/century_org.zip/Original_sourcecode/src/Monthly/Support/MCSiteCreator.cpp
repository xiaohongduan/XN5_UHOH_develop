// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  MCSiteCreator.cpp
//	Class:	  MCSiteCreator
//
//	Description:
//	Class for creating site parameter files for monthly Century.
//
//	Responsibilities:
//	* <what class is supposed to do>
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, June 2005
//	History: See header file.
// ----------------------------------------------------------------------------

#include "MCSiteCreator.h"
#include "TCentury.h"
using namespace ::nrel::century;

void MCSiteCreator::GetMineralE (
	  TSiteParamSet & parameterSet)
{
    TSiteParamSet & s = parameterSet;
    TMCSiteParIndices const & idx = century.GetSite()->indices;
    TMCSoil const & soil = *century.GetSoil();
    short const numLayers = std::min ((short) soil.GetLayerCount(), MAXLYR);
    short const base = idx.SPI_minerl;

    // mineral N
    for ( short layer = 0; layer < numLayers; ++layer )
	s.GetParameter(layer).SetValue ( soil.MineralN(layer) );

    // mineral P
    //if ( century.site.nelem > 1 )
    //{
	for ( short layer = 0; layer < numLayers; ++layer )
	    s.GetParameter(layer + MAXLYR).SetValue (
	    	soil.MineralP(layer) );
    //}

    // mineral S
    //if ( century.site.nelem > 2 )
    //{
	for ( short layer = 0; layer < numLayers; ++layer )
	    s.GetParameter(layer + 2 * MAXLYR).SetValue (
	    	soil.MineralS(layer) );
    //}
    // parent, secondary, occluded
    for ( short i = 0; i < NUMELEM; i++ )		// for each in N,P,S...
    {
      s.GetParameter(i + idx.SPI_parent - base).SetValue(century.nps.parent[i]);
      s.GetParameter(i + idx.SPI_secndy - base).SetValue(century.nps.secndy[i]);
    }
    s.GetParameter(idx.SPI_occlud - base).SetValue(century.nps.occlud);

}


//--- end of file ---

