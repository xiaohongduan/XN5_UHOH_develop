// ----------------------------------------------------------------------------
//	Copyright 1998-2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  SiteEditorDlg.cpp
//	Class:	  SiteEditorDlg
//
//	Description:
//	Class for Editing Site Files.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Feb98, tom.hilinski@colostate.edu
//	History: See header file.
// ----------------------------------------------------------------------------

// Borland C++ Builder 6
//#pragma warn -pck
//#pragma warn -inl

#include "SiteEditorDlg.h"
#include "SiteEditorDataSrcMCFile.h"
#include "TSiteFromLibDlg.h"
#include "TChoicesDlg.h"
#include "precision.h"
#include <v/vcolor.h>
#include <v/vynreply.h>
#include <v/vreply.h>
#include <v/vnotice.h>
#include <v/vutil.h>
#include <v/vos.h>
#include "HelpDisplay.h"
#include "AssertEx.h"
#include <sstream>

// specific types for dynamic_cast checks
#include "TMCSiteParameters.h"
#include "TDCSiteParameters.h"

// ----------------------------------------------------------------------------
//	template stuff
// ----------------------------------------------------------------------------

#define TEMPLATE_DECLARATION 		\
	template 			\
	< 				\
	  class ParametersType,		\
	  class ParametersInfoType	\
	>

#define	SITEEDITORDLG				\
	SiteEditorDlg				\
	<					\
	  ParametersType, ParametersInfoType	\
	>

//	specialization for monthly site parameters
class TMCSiteParameters;
class TMCSiteParamInfo;
template class SiteEditorDlg<TMCSiteParameters, TMCSiteParamInfo>;

// ----------------------------------------------------------------------------
//	static member variables
// ----------------------------------------------------------------------------

TEMPLATE_DECLARATION
const char * const SITEEDITORDLG::version =	// version of editor
	"2.0.1";

#define pathLength 257				// maximum path length
static char displayStrLen = 21;			// length of display string
static const char *NULLStr = "";		// global NULL string
static const vColor labelColor(128, 0, 0);	// define color for main labels

TEMPLATE_DECLARATION
const char * SITEEDITORDLG::toolTips[] =	// tool tips text
{
	// 0 = site file name text input
	"Path and file name. Do not include the extension.",
	// 1 = "save as" file name button
	"Save the parameters to a different file path or name.",
	// 2 = site name text input
	"A short name for the site.",
	// 3 = site description text input
	"Description of the site (1 line)",
	// 4 = change the parameter value
	"Change the parameter to the displayed value.",
	// 5 = done button
	"Finished editing the site parameters.",
	// 6 = new button
	"Create a new site parameter set from a template.",
	// 7 = open button
	"Open an existing site parameter set.",
	// 8 = import button
	"", // Import a Century 4 site parameter file.
	// 9 = save button
	"Save the current site parameters to a file.",
	// 10 = help button
	"View Help on editing site parameters.",
	// 11 = parameter list
	"Select a parameter name to view or change the value.",
	// 12 = parameter value
	"Enter a new value, then press \"Change\".",
	// 13 = button: copy from library
	"Create a new site parameter set from a library set.",
	// 14 = button: choose site type from list
	"Choose the site type from a list.",
	// 15 = radiobutton: parameter set
	"Select a parameter set from this list",
	// 16 = radiobutton:  parameter set
	"", // Climate: mean precipitation and min/max temperature.
	// 17 = radiobutton:  parameter set
	"", // Soil: layered texture and water.
	// 18 = radiobutton:  parameter set
	"", // Deposition and fixation of N and S.
	// 19 = radiobutton:  parameter set
	"", // Crop/Grassland organic matter characterization.
	// 20 = radiobutton:  parameter set
	"", // Forest organic matter characterization.
	// 21 = radiobutton:  parameter set
	"", // Mineralized N, P, S, and parent material.
	// 22 = radiobutton:  parameter set
	"", // Initial soil and snow water content.
	// 23 = radiobutton:  parameter set
	"", // Initial organic C, N, P, S below simulation layer.
	// 24 = radiobutton:  parameter set
	"", // Controls on erosion and deposition of C, N, P, S.
	// 25 = button: Clear Set
	"Set all values in this parameter set to zero.",
	// last item always
	0
};

TEMPLATE_DECLARATION
CommandObject SITEEDITORDLG::cmdList1[] =
{
	//--- Master Frame provides a border for data
	{C_Frame, D_FrameMaster, 0, ::NULLStr, NoList,
		CA_NoBorder | CA_NoSpace, isSens,
		NoFrame, 0, 0},

	//--- Site header info
	{C_Frame, D_FrameSiteInfo, 0, ::NULLStr, NoList,
		CA_NoBorder, isSens,
		D_FrameMaster, 0, 0},

	// Type of parameters
	{C_Label, 242, 0, "Type of parameters:", NoList, CA_None, isSens,
		D_FrameSiteInfo, 0, 0, 15 },
	{C_Label, D_ParamDataType, 0, "                    ",
		NoList, CA_None, isSens,
		D_FrameSiteInfo, 242, 0},

	// Site File
	{C_Label, 240, 0, "Site File:", NoList, CA_None, isSens,
		D_FrameSiteInfo, 0, D_ParamDataType, 15 },
	{C_TextIn, D_FileName, 0, ::NULLStr, NoList, CA_None, isSens,
		D_FrameSiteInfo, 240, D_ParamDataType, 50, toolTips[0]},

	// Site Mnemonic
	{C_Label, 201, 0, "Site Mnemonic:", NoList, CA_None, isSens,
		D_FrameSiteInfo, 0, D_FileName, 15 },
	{C_TextIn, D_Mnemonic, 0, ::NULLStr, NoList, CA_None, isSens,
		D_FrameSiteInfo, 201, D_FileName, 20, toolTips[2]},

	// Site Description
	{C_Label, 205, 0, "Site Description:", NoList, CA_None, isSens,
		D_FrameSiteInfo, 0, D_Mnemonic, 15 },
	{C_TextIn, D_Description, 0, ::NULLStr, NoList, CA_None, isSens,
		D_FrameSiteInfo, 205, D_Mnemonic, 50, toolTips[3]},

	// Site Type
	{C_Label, 260, 0, "Site Type:", NoList, CA_None, isSens,
		D_FrameSiteInfo, 0, D_Description, 15 },
	{C_Frame, D_FrameSelectSiteType, 0, ::NULLStr, NoList,
		CA_None, isSens,
		D_FrameSiteInfo, 260, D_Description},
	{C_Label, D_SiteType, 0, "", NoList, CA_None, isSens,
		D_FrameSelectSiteType, 0, 0, 8 },
	{C_Button, D_SiteTypeChg, D_SiteTypeChg, "Select...",
		NoList, CA_None, isSens,
		D_FrameSelectSiteType, D_SiteType, 0, 0, toolTips[14]},

	//--- parameter group radiobuttons
	{C_Frame, D_FrameSelectParamSet, 0, ::NULLStr, NoList,
		CA_NoBorder, isSens,
		D_FrameMaster, 0, D_FrameSiteInfo},
	{C_Label, 207, 0, "1. Select parameter set:",
		NoList, CA_None, isSens,
		D_FrameSelectParamSet, 0, 0},
	{C_Frame, D_FrameParamSetButtons, 0, ::NULLStr, NoList,
		CA_None, isSens,
		D_FrameSelectParamSet, 0, 207,
		0, toolTips[15]},

	{C_EndOfList, 0, 0, 0, NoList, CA_None, notSens, NoFrame, 0, 0}
};

TEMPLATE_DECLARATION
CommandObject SITEEDITORDLG::cmdList2[] =
{
	//--- parameter list
	{C_Frame, D_FrameParameterList, 0, ::NULLStr, NoList,
		CA_NoBorder, isSens,
		D_FrameMaster, D_FrameSelectParamSet, D_FrameSiteInfo},
	{C_Label, 208, 0, "2. Select Parameter:",
		NoList, CA_None, isSens,
		D_FrameParameterList, 0, 0},
	// {C_List, D_ParamList, 0, ::NULLStr, (void*)NULL,
	{C_List, D_ParamList, 0, ::NULLStr, NoList,
		CA_Large | CA_Size, isSens,
		D_FrameParameterList, 0, 208,
		15 /* rows */, toolTips[11]},

	//--- parameter data display
	{C_Frame, D_FrameParameterEdit, 0, ::NULLStr, NoList,
		CA_NoBorder, isSens,
		D_FrameMaster, D_FrameParameterList, D_FrameSiteInfo},
	{C_Label, 209, 0, "3. Parameter Value:",
		NoList, CA_None, isSens,
		D_FrameParameterEdit, 0, 0},
	{C_Frame, D_FrameParameterValue, 0, ::NULLStr, NoList,
		CA_None, isSens,
		D_FrameParameterEdit, 0, 209},
	{C_TextIn, D_ParamValue, 0, ::NULLStr,
		NoList, CA_None, isSens,
		D_FrameParameterValue, 0, 0, 8, toolTips[12]},
	{C_Button, D_ChangeValue, D_ChangeValue, "&Change",
		NoList,	CA_None, isSens,
		D_FrameParameterValue, D_ParamValue, 0, 0,
		toolTips[4]},
	{C_Button, D_ClearSet, D_ClearSet, "Clear Set",
		NoList,	CA_None, isSens,
		D_FrameParameterValue, D_ChangeValue, 0,
		0, toolTips[25]},

	//--- parameter description
	{C_Frame, D_FrameParameterDesc, 0, ::NULLStr, NoList,
		CA_NoBorder, isSens,
		D_FrameMaster, D_FrameParameterList, D_FrameParameterEdit},
	{C_Label, 220, 0, "Parameter Description:",
		NoList, CA_None, isSens,
		D_FrameParameterDesc, 0, 0},
	{C_Text, D_ParamDesc, 0,
		"\n\n\n", /* 4 lines */
		NoList, CA_NoBorder, isSens,
		D_FrameParameterDesc, 0, 220,
		50 },

	//---	Status Messages
	{C_Frame, D_FrameStatusMessages, 0, ::NULLStr, NoList,
		CA_NoBorder, isSens,
		NoFrame, 0, D_FrameMaster},
	{C_CheckBox, D_ReadOnly, 0, "Read-Only    ",
		NoList, CA_None, isSens,
		D_FrameStatusMessages, 0, 0},
	{C_Label, 225, 0, "Status:",
		NoList, CA_None, isSens,
		D_FrameStatusMessages, D_ReadOnly, 0},
	{C_ColorLabel, D_Modified, 0, "Modified", (void *)&labelColor,
		CA_None, isSens,
		D_FrameStatusMessages, 225, 0, 20},

	//---	Common Buttons
	{C_Frame, D_FrameCommonButtons, 0, ::NULLStr, NoList,
		CA_NoBorder, isSens,
		NoFrame, 0, D_FrameStatusMessages},
	{C_Button, M_OK, M_OK,			"&Done",
		NoList,	CA_DefaultButton, isSens,
		D_FrameCommonButtons, 0, 0,
		0, toolTips[5]},
	{C_Button, M_New, M_New,		"&New",
		NoList,	CA_None, isSens,
		D_FrameCommonButtons, M_OK, 0,
		0, toolTips[6]},
	{C_Button, M_Open, M_Open,		"&Open",
		NoList,	CA_None, isSens,
		D_FrameCommonButtons, M_New, 0,
		0, toolTips[7]},
	{C_Button, D_FromLib, D_FromLib,	"&From Library",
		NoList,	CA_None, isSens,
		D_FrameCommonButtons, M_Open, 0,
		0, toolTips[13]},
	{C_Button, M_Save, M_Save,		"&Save",
		NoList,	CA_None, isSens,
		D_FrameCommonButtons, D_FromLib, 0,
		0, toolTips[9]},
	{C_Button, M_SaveAs, M_SaveAs,		"Save &As",
		NoList,	CA_None, isSens,
		D_FrameCommonButtons, M_Save, 0,
		0, toolTips[1]},
	{C_Button, M_Help, M_Help,		"&Help",
		NoList,	CA_None, isSens,
		D_FrameCommonButtons, M_SaveAs, 0,
		0, toolTips[10]},

	{C_EndOfList, 0, 0, 0, NoList, CA_None, notSens, NoFrame, 0, 0}
};

TEMPLATE_DECLARATION
char const * const SITEEDITORDLG::defaultDlgTitle =	// default dialog title
	"Edit Site Parameters";


// ----------------------------------------------------------------------------
//	methods
// ----------------------------------------------------------------------------

// --- constructors and destructor

TEMPLATE_DECLARATION
SITEEDITORDLG::SiteEditorDlg (
	vApp * const useParent,			// pointer to application
	TSiteDataSrcPtr useSite,		// site instance to use
	TInfoPtr useInfo,			// site parameters info
	std::string const & useHelpPath,	// path to help file
	std::string const & useSiteLibPath,	// path to site libraries
	std::string const & useUserLibPath,	// user's site library path
	std::string const & useTemplatePath,	// path to template folder
	std::string const & useWorkPath,	// user's work path
	std::string const & useUserName,	// user name for output file
	char const * const title)		// dialog title
	: EditDlgBase (useParent, title),
	  parent (useParent),
	  siteDataSrc (useSite),
	  infoPtr (useInfo),
	  helpFilePath (useHelpPath),
	  siteLibPath (useSiteLibPath),
	  userSiteLibPath (useUserLibPath),
	  templatePath (useTemplatePath),
	  workPath (useWorkPath),
	  userName (useUserName),
	  dispSet (0),
	  dispSetNum (-1),
	  dispParam (0),
	  parameterNames (0),
	  cmdList (0),
	  indexCmdObjList (0),
	  idLastParamGroup (0)
{
	// error checks
	// check the site parameters info
	Assert (infoPtr.get());
	Assert (!infoPtr->IsEmpty());
	if ( infoPtr.get() )
	{
	    if ( infoPtr->IsEmpty() )
	    {
		vNoticeDialog dlg (parent, "Error");
		dlg.Notice ("SiteEditorDlg constructor:\n"
			    "The site parameters information object is empty.");

	    }
	}
	else // no object! oops
	{
	    vNoticeDialog dlg (parent, "Error");
	    dlg.Notice ("SiteEditorDlg constructor:\n"
			"The site parameters information object is null.");
	}

	// set the active site parameters
	Assert (siteDataSrc.get());
	Assert (!siteDataSrc->IsEmpty());
	if ( siteDataSrc.get() )
	{
	    SetDisplayedSiteParams ( siteDataSrc );
	}
	else // no object! oops
	{
	    vNoticeDialog dlg (parent, "Error");
	    dlg.Notice ("SiteEditorDlg constructor:\n"
			"The site parameters object is null.");
	}

	// Get the parameters name - only once!
	BuildParamNameLists ();

	// build dialog controls
	DlgCmdsArray cmdArray;
	UtilGUI::Copy (cmdList1, cmdArray);
	BuildRadioButtonSetList (
		ParametersInfoType::indices.siteSetName,
		D_FirstParameterSet,
		D_FrameParamSetButtons,
		cmdArray );
	UtilGUI::Copy (cmdList2, cmdArray);
	cmdList = new CommandObject [cmdArray.size() + 1];
	UtilGUI::Copy (cmdArray, cmdList);
	AddDialogCmds (cmdList);

	// Get the indicies to cmdList items for lists.
	indexCmdObjList =
		static_cast<unsigned short>(
			::vGetcmdIdIndex (D_ParamList, cmdList) );
	idLastParamGroup = D_FirstParameterSet +
			   ParametersInfoType::indices.SPGI_EndOfList - 1;

	//--- display dialog
	ItemVal retVal;
	ShowModalDialog (title, retVal);
}

TEMPLATE_DECLARATION
SITEEDITORDLG::~SiteEditorDlg ()
{
	ClearDialog ();
	Clear ();
	delete [] cmdList;
	cmdList = 0;
}

// --- functions overridden

TEMPLATE_DECLARATION
void SITEEDITORDLG::DialogDisplayed ()
{
	EditDlgBase::DialogDisplayed ();

	// determine and display data set type
	ParametersType const * const mySite = dispSite->Get().get();
	if ( dynamic_cast<TMCSiteParameters const *>( mySite ) )
		SetString ( D_ParamDataType, "Monthly" );
	else if ( dynamic_cast<TDCSiteParameters const *>( mySite ) )
		SetString ( D_ParamDataType, "Daily" );
	else
		SetString ( D_ParamDataType, "Unknown" );

	// Load dialog data
	LoadDlg ();
	// things to check always
	ShowHideModified ();
}

TEMPLATE_DECLARATION
void SITEEDITORDLG::DialogCommand (
	ItemVal cmdID,
	ItemVal cmdValue,
	CmdType cmdType)
{
    if ( cmdID >= D_FirstParameterSet && cmdID <= idLastParamGroup )
    {
    	// selected a parameter set radiobutton
	UpdateDlg_ParamList (cmdID);
    }
    else
    {
	switch (cmdID)
	{
	  case D_ChangeValue:			// "change value" button
	  	Event_ChangeValue ();
		break;
	  case D_ClearSet:			// "Clear Set" button
	  	Event_ClearSet ();
		break;
	  case D_ParamList:			// parameter list selection
		UpdateDlg_ParamData (cmdValue);
		break;
	  case D_SiteTypeChg:		// button: choose site type from list
		Event_SiteTypeChg ();
		break;
	  case D_ReadOnly:
	  	Event_ReadOnly ();
	  	break;

	  case M_OK:	  cmdID = Event_OK ();	break;	// "done" button
	  case M_Open:    Event_Open ();	break;	// "open" button
	  case M_New:	  Event_New ();		break;	// "new" button
	  case M_Save:	  Event_Save ();	break;	// "save" button
	  case M_SaveAs:  Event_SaveAs ();	break;	// "save as" button
	  case D_FromLib: Event_FromLibrary ();	break;	// "from library" button
	  case M_Help:	  Event_Help ();	break;	// "help" button
	  default:
		break;
	}
    }

    // things to check always
    ShowHideModified ();

    // Default event processing
    EditDlgBase::DialogCommand (cmdID, cmdValue, cmdType);
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	Clear
//	"Clears" the dialog and the data members.
TEMPLATE_DECLARATION
void SITEEDITORDLG::Clear ()
{
	ClearDialog ();			// clear display
	siteDataSrc->Clear ();
	Initialize ();			// clear this
	// SetDisplayedSiteParams (siteDataSrc);
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

// initialize members
TEMPLATE_DECLARATION
void SITEEDITORDLG::Initialize ()
{
	dispSet = 0;
	dispSetNum = -1;
	dispParam = 0;
}

//	SetDisplayedSiteParams
//	Sets the site parameter to the specified site.
//	Makes a copy of the site parameters - the copy is edited.
//	Returns false if accepted, or true if not.
TEMPLATE_DECLARATION
void SITEEDITORDLG::SetDisplayedSiteParams (
	TSiteDataSrcPtr & useSite)
{
	if ( !dispSite.get() )			// need instance?
	{
		dispSite.reset (
			dynamic_cast< TSiteDataSrc* >( useSite->Clone() ) );
	}
	else
		*dispSite = *useSite;		// copy values

	dispSite->Get()->SetModified (false);
}

TEMPLATE_DECLARATION
void SITEEDITORDLG::SetSensitive ()
{
	int const sensitive = ( HaveDisplayedData() ? isSens : notSens );
	SetValue (D_SiteTypeChg, sensitive, Sensitive);
	SetValue (D_ChangeValue, sensitive, Sensitive);
	SetValue (D_ClearSet, sensitive, Sensitive);
	SetValue (M_Save, sensitive, Sensitive);
	SetValue (M_SaveAs, sensitive, Sensitive);
	for ( short i = D_FirstParameterSet;
	      i < ParametersInfoType::indices.SPGI_EndOfList;
	      ++i )
	{
		SetValue (i, sensitive, Sensitive);
	}
}

// ----------------------------------------------------------------------------
// --- Load data into dialogs:
// ----------------------------------------------------------------------------

// load the dialog
TEMPLATE_DECLARATION
void SITEEDITORDLG::LoadDlg ()
{
	SetSensitive ();
	if ( !HaveDisplayedData() )
	{
		Initialize ();
		return;					// ...no
	}

	// Get dialog ready for new site parameters
	ClearDialog ();						// erase

	// site type
	strncpy (displayStr, dispSite->Get()->GetSiteTypeStr(), displayStrLen);
	SetString ( D_SiteType, displayStr );

	// remaining fields
	SetString ( D_FileName, dispSite->Get()->GetBaseName().c_str() );
	SetString ( D_Mnemonic, dispSite->Get()->GetName().c_str() );
	SetString ( D_Description, dispSite->Get()->GetDescription().c_str() );
	SetValue ( D_FirstParameterSet, 1, Checked );

	UpdateDlg_ParamList ( D_FirstParameterSet );		// update list
}

//	UpdateDlg_ParamList
//	update the parameter list
//	"id" is the id if the radio button selected
TEMPLATE_DECLARATION
void SITEEDITORDLG::UpdateDlg_ParamList (
	ItemVal const id)
{
	// ID ok?
	if ( id < D_FirstParameterSet || id > idLastParamGroup )
		return;

	if ( !HaveDisplayedData() )	// anything there?
	{
		Initialize ();
		return;
	}

	// update ptrs to dislayed data
	short const newDispSetNum =
		static_cast<short>(id - D_FirstParameterSet); // index the set
	if ( newDispSetNum == dispSetNum )
		return;
	dispSetNum = newDispSetNum;
	dispSet = const_cast<TSiteParamSet*>(		 // get the set
			&dispSite->Get()->GetSet (dispSetNum) );
	Assert (dispSet != NULL);

	// Display the parameter name list
	vSList const & theList = parameterNames[dispSetNum];
	CommandObject & coList = cmdList[indexCmdObjList];
	if ( theList.list != coList.itemList )
	{
		ClearDlgParamList ();	// delete previous list & clear display
		// set ptr to list
		coList.itemList =  static_cast<void*>( theList.list );
		SetValue (coList.cmdId, 0, ChangeListPtr); 	// display
	}
	// update the parameter data
	short const indexList = (short)GetValue (D_ParamList);
	dispParam = &dispSet->GetParameter (indexList);		// get param
	UpdateDlg_ParamData (indexList);			// param display
}

//	UpdateDlg_ParamData
//	Update the display of the parameter data.
TEMPLATE_DECLARATION
void SITEEDITORDLG::UpdateDlg_ParamData (
	ItemVal const indexSelectedItem)
{
	if ( !HaveDisplayedData() )
	{
		Initialize ();
		return;
	}
	Assert (dispParam != NULL);
	Assert (dispSet != NULL);
	Assert (dispSet->GetParamCount() > 0);
	Assert (indexSelectedItem >= 0);
	Assert (indexSelectedItem < dispSet->GetParamCount());

	// get the currently selected item in the event list
	TSiteParameter const * const p =
		&dispSet->GetParameter ( (short)indexSelectedItem );
	Assert (p != NULL);

	DisplayParameterValue (p, indexSelectedItem);	// change displayed
	dispParam = const_cast<TSiteParameter*>(p);	// save parameter
}

// ----------------------------------------------------------------------------
// --- Button events:
// ----------------------------------------------------------------------------

// "done" button
TEMPLATE_DECLARATION
int SITEEDITORDLG::Event_OK ()
{
	ItemVal cmdID = M_OK;
	CopyParamsToOriginal();
	Assert ( !(siteDataSrc->IsEmpty()) );
	Assert ( *dispSite->Get() == *(siteDataSrc->Get()) );
	if ( ConfirmSaveSite() )	// no save?
		cmdID == M_Cancel;
	return cmdID;
}

// 	create a new site parameters set
TEMPLATE_DECLARATION
void SITEEDITORDLG::Event_New ()
{
	if ( ConfirmReplaceData() )
	{
		Clear ();
		typename ParametersType::TSitePtr zeroedSiteParam (
			new TMCSiteParameters (
				templatePath, workPath, infoPtr ) );
		zeroedSiteParam->SetModified (false);
		siteDataSrc->Get() = zeroedSiteParam;

		// not saved, therefore is modified
		siteDataSrc->Get()->SetModified (true);
		dispSite->Get()->SetModified (true);

		SetDisplayedSiteParams ( siteDataSrc );
		LoadDlg ();
	}
}

// 	open a site parameter file
TEMPLATE_DECLARATION
void SITEEDITORDLG::Event_Open ()
{
	if ( ConfirmReplaceData() )		// delete the current site?
	{
		Clear ();
		// ask for the file
		SiteEditorDataSrcMCFile::TUserAction const
			openResult = siteDataSrc->Open ();
		if ( openResult == SiteEditorDataSrcMCFile::ActionCancel ||
		     siteDataSrc->HaveError() )
		{
			return;
		}

		// display the parameters
		SetDisplayedSiteParams ( siteDataSrc );
		LoadDlg ();
	}
}

// 	get a site from a library
TEMPLATE_DECLARATION
void SITEEDITORDLG::Event_FromLibrary ()
{
	if ( ConfirmReplaceData() )		// delete the current site?
	{
		// select the site
		std::string librarySiteFileName;
		TSiteFromLibDlg dlg ( this, parent,
				helpFilePath, siteLibPath,
				userSiteLibPath, librarySiteFileName );
		if ( !librarySiteFileName.empty() )
		{
			Clear ();
			siteDataSrc.reset (
			    dynamic_cast< TSiteDataSrc * > (
				new SiteEditorDataSrcMCFile (
					parent,
					librarySiteFileName,
					templatePath,
					workPath,
					infoPtr ) ) );
			siteDataSrc->Get()->SetModified (true);
			SetDisplayedSiteParams ( siteDataSrc );
			LoadDlg ();
		}
	}
}

//	Event_Save
// 	save to the current file
TEMPLATE_DECLARATION
void SITEEDITORDLG::Event_Save ()
{
  	CopyParamsToOriginal ();
	if ( !siteDataSrc->Save() )		// save successful?
	{
		siteDataSrc->Get()->SetModified (false);
		dispSite->Get()->SetModified (false);
	}
}

//	Event_SaveAs
// 	save to a different file
TEMPLATE_DECLARATION
void SITEEDITORDLG::Event_SaveAs ()
{
  	CopyParamsToOriginal ();
	if ( !siteDataSrc->SaveAs() )		// save successful?
	{
		// saved, so set flags
		siteDataSrc->Get()->SetModified (false);
		dispSite->Get()->SetModified (false);
		// display new file name
		SetString (
			D_FileName,
			dispSite->Get()->GetBaseName().c_str() );
	}
}

TEMPLATE_DECLARATION
void SITEEDITORDLG::Event_Help ()		// Display Help information
{
#ifdef MSWindowsHelp
	::HelpDisplay (parent->winHwnd(), helpFilePath,
			HELP_CONTEXT, IDH_EDIT_SITE_PARAMS_DLG);
#elif defined(X11Help)
	::HelpDisplay (winHwnd(), helpFilePath,
			HELP_CONTEXT, IDH_EDIT_SITE_PARAMS_DLG);
#endif
}

//	Event_ChangeValue
// 	Change parameter value
TEMPLATE_DECLARATION
void SITEEDITORDLG::Event_ChangeValue ()
{
	if ( readOnly )
	{
		// make sure the value displayed is the unmodified one
		DisplayParameterValue ( dispParam, GetValue (D_ParamList) );
		return;
	}

	if ( !HaveDisplayedData() )
	{
		Initialize ();
		return;
	}

	// save the previous data
	TSiteParameter prevParam = *dispParam;		// save for comparisons
	GetParamData ();				// get new value
	if ( !::AreClose ( prevParam.GetValue(),
			   dispParam->GetValue(),
			   0.001f /* threshold */ ) )
	{
		dispParam->SetModified (true);
		siteDataSrc->Get()->SetModified (true);
	}
	else	// restore
		*dispParam = prevParam;
}

//	Event_ClearSet
//	Clear all parameters in set - set them to zero.
TEMPLATE_DECLARATION
void SITEEDITORDLG::Event_ClearSet ()
{
	if ( readOnly )
	{
		// make sure the value displayed is the unmodified one
		DisplayParameterValue ( dispParam, GetValue (D_ParamList) );
		return;
	}

	TSiteParamSet::TParameterList & dispParamListList =
		dispSet->ParameterList();
	TSiteParamSet::TParameterList::iterator iList =
		dispParamListList.begin();
	while ( iList != dispParamListList.end() )
	{
		iList->SetValue (0.0f);
		++iList;
	}
	// Zero the display of the current value
	// get the currently selected item in the event list
	short const indexList = (short)GetValue (D_ParamList);
	DisplayParameterValue ( &dispSet->GetParameter (indexList), indexList );
	siteDataSrc->Get()->SetModified (true);
}

//	Event_SiteTypeChg
// 	Choose the site file type from list
TEMPLATE_DECLARATION
void SITEEDITORDLG::Event_SiteTypeChg ()
{
	// build dialog
	static short const numChoices = 4;
	TChoicesDialog dlg (this,
			"Select the site type\nfor the current parameter set:",
			numChoices, "Change Site Type");
	for (short i = 1; i <= numChoices; i++)
		dlg.AddChoice (TSiteParametersBase::GetSiteTypeStrings()[i]);
	// display choice to user
	short choice = dlg.GetChoice ();
	if ( choice == (short)0 )		// cancel button?
		return;				// ...nothing else to do
	*displayStr = '\0';
	switch ( (TSiteType)choice )
	{
	  case TSiteParametersBase::ST_Crop:
		strncpy (displayStr,
			 TSiteParametersBase::GetSiteTypeStrings()[1],
			 displayStrLen);
		break;
	  case TSiteParametersBase::ST_Grass:
		strncpy (displayStr,
			 TSiteParametersBase::GetSiteTypeStrings()[2],
			 displayStrLen);
		break;
	  case TSiteParametersBase::ST_Tree:
		strncpy (displayStr,
			 TSiteParametersBase::GetSiteTypeStrings()[3],
			 displayStrLen);
		break;
	  case TSiteParametersBase::ST_Savanna:
		strncpy (displayStr,
			 TSiteParametersBase::GetSiteTypeStrings()[4],
			 displayStrLen);
	  	break;
	  default:
	  	break;
	};
	SetString ( D_SiteType, displayStr );
	// if changed, save in displayed site instance
	if ( dispSite.get() &&
	     siteDataSrc->Get()->GetSiteType () != (TSiteType)choice )
	{
		siteDataSrc->Get()->SetSiteType ( (TSiteType)choice );
		siteDataSrc->Get()->SetModified (true);
	}
}

//	Event_ReadOnly
//	Read-only checkbox.
TEMPLATE_DECLARATION
void SITEEDITORDLG::Event_ReadOnly ()
{
	readOnly = (GetValue(D_ReadOnly) == isChk);
	if ( readOnly )
	{
		if ( siteDataSrc->Get()->IsModified() )
		{
			// restore to original
			SetDisplayedSiteParams ( siteDataSrc );
			UpdateDlg_ParamList (dispSetNum);
			siteDataSrc->Get()->SetModified (false);
		}
		else
		{
			// make sure the value displayed is the unmodified one
			DisplayParameterValue (
				dispParam, GetValue (D_ParamList) );
		}
		// inactivate "change" buttons
		SetValue (D_ChangeValue, notSens, Sensitive);
		SetValue (D_ClearSet, notSens, Sensitive);
	}
	else
	{
		// activate "change" buttons
		SetValue (D_ChangeValue, isSens, Sensitive);
		SetValue (D_ClearSet, isSens, Sensitive);
	}
}

// ----------------------------------------------------------------------------
// --- Clear dialog controls:
// ----------------------------------------------------------------------------

//	Clear site info
TEMPLATE_DECLARATION
void SITEEDITORDLG::ClearDlgSiteInfo ()
{
	SetString (D_FileName, NULLStr);
	SetString (D_Mnemonic, NULLStr);
	SetString (D_Description, NULLStr);
	SetString (D_SiteType, NULLStr);
}

// Clear parameter list display
TEMPLATE_DECLARATION
void SITEEDITORDLG::ClearDlgParamList ()
{
	// clear parameter list
	CommandObject & coList = cmdList[indexCmdObjList];
	coList.itemList = 0; 				// set ptr to list
	SetValue (coList.cmdId, 0, ChangeListPtr);	// list
	SetString (D_ParamDesc, NULLStr);		// parameter description
}

// Clear parameter data display
TEMPLATE_DECLARATION
void SITEEDITORDLG::ClearDlgParamData ()
{
	SetString (D_ParamValue, NULLStr);
}

// ----------------------------------------------------------------------------
// --- Get data functions
// ----------------------------------------------------------------------------

//	GetSiteInfo
// 	Retrieve the site header information from the dialog.
TEMPLATE_DECLARATION
void SITEEDITORDLG::GetSiteInfo ()
{
	bool modifiedHere = false;

	// retrieve base file name from dialog
	char newName[pathLength];
	GetTextIn ( D_FileName, newName, pathLength );
	::strtrim (newName);
	if ( *newName && !VerifyFileName(newName) )		// name ok?
	{
	    if ( siteDataSrc->Get()->GetBaseName() != newName )	// changed?
	    {
		siteDataSrc->Get()->SetBaseName (newName);	// save it
		modifiedHere = true;
	    }
	}
	else
	{						// no... use previous
		SetString ( D_FileName,
			    siteDataSrc->Get()->GetBaseName().c_str() );
	}
	// read values
	static short const maxLen = 256;
	char str[maxLen];
	// mnemonic for site
	GetTextIn (D_Mnemonic, str, 21);			// retrieve it
	::strtrim (str);
	std::string const & siteName = siteDataSrc->Get()->GetName();
	if ( siteName != str )					// changed?
	{
		siteDataSrc->Get()->SetName (str);		// save it
		modifiedHere = true;
	}
	// description of site
	GetTextIn (D_Description, str, maxLen);			// retrieve it
	::strtrim (str);
	if ( siteDataSrc->Get()->GetDescription() != str )	// changed?
	{
		siteDataSrc->Get()->SetDescription (str);	// save it
		modifiedHere = true;
	}
	// all done
	if ( modifiedHere )
		siteDataSrc->Get()->SetModified (true);
}

//	GetParamData
// 	Get data for a single parameter from the parameter value edit box.
TEMPLATE_DECLARATION
void SITEEDITORDLG::GetParamData ()
{
	Assert (dispSite.get() != NULL);
	Assert (dispParam != NULL);

	// read value
	char str[13];
	GetTextIn (D_ParamValue, str, 12);
	float newValue;
	sscanf ( str, "%f", &newValue );
	dispParam->SetValue (newValue);
}

// ----------------------------------------------------------------------------
// --- Utility functions
// ----------------------------------------------------------------------------

//	ConfirmReplaceData
//	Asks the user to confirm deletion of the current site parameters.
//	Returns true if "yes, delete" or false if "do not delete".
//	If "yes", the dialog is cleared and the current site parameters are
//	deleted from memory.
TEMPLATE_DECLARATION
bool SITEEDITORDLG::ConfirmReplaceData ()
{
	if ( !HaveDisplayedData() )
	{
		Initialize ();
		return false;
	}

	bool retVal = false;				// default response
	std::string const msg1 =
		"Display of current site parameters\n"
		"will be replaced ";
	std::string const msg2 =
		"The current site parameters\n"
		"have been modified but not saved.\n\n"
		"Modifications will be lost ";
	std::string const msg3 =
		"if you continue.\n\n"
		"Do you want to continue?";

	// build the message
	std::string msg;
	if ( dispSite->Get()->IsModified() )
		msg = msg2;
	else
		msg = msg1;
	msg += msg3;

	// display and get response
	vYNReplyDialog ynDlg (this);
	if ( 1 == ynDlg.AskYN ( msg.c_str() ) )		// yes?
		retVal = true;				// delete is confirmed

	return retVal;
}

//	ConfirmSaveSite
//	If the site values have been changed but not saved, ask user
//	if want to save it.
//	Returns true if Cancel request is made, else false.
TEMPLATE_DECLARATION
bool SITEEDITORDLG::ConfirmSaveSite ()
{
	if ( !HaveDisplayedData() )
	{
		Initialize ();
		return false;
	}

	if ( readOnly )
		return true;

	bool cancelSave = false;
	if ( dispSite->Get()->IsModified() )
	{
		// ask user if want to save
		vYNReplyDialog ynDlg (this);
		int answer = ynDlg.AskYN (
			"The site parameters displayed have been modified "
			"but not saved.\n\n"
			"Do you want to save these changes?" );
		if ( answer == 1 )			// yes?
			Event_Save ();
		else if ( answer == -1 )			// "cancel"?
			cancelSave = true;
	}
	return cancelSave;
}

//	CopyParamsToOriginal
//	Transfers site parameters to external site param. object, if exists.
TEMPLATE_DECLARATION
void SITEEDITORDLG::CopyParamsToOriginal ()
{
	if ( readOnly )				// don't modify original?
		return;

	// make sure all the info is gotten from the dialog
	GetSiteInfo ();
	// dispSite->Get()->SetModified (true);
	if ( dispSite->Get()->IsModified() )
	{
		dispSite->Get()->GetEditInfo().SetEditorName (userName);
	}

	// if changed, copy
	if ( *siteDataSrc != *dispSite )
	{
		*siteDataSrc = *dispSite;			// save
		siteDataSrc->Get()->SetModified (true);
	}
	Assert ( *dispSite->Get() == *(siteDataSrc->Get()) );
}

//	VerifyFileName
//	Verifies the file exists and is a valid file path.
//	If a problem, displays a message to the user.
//	Returns false if no error, else true if error.
TEMPLATE_DECLARATION
bool SITEEDITORDLG::VerifyFileName (char const* name)
{
	bool retVal = false;
	short errFlag = 0;
	if ( !name || !(*name) )	// anything there?
		return true;		// ...no = error

	TEH::TFileName newFile (name);
	TEH::TFileName newFilePath (
		newFile.GetFullPath(), TEH::TFileName::FT_Directory );
	if ( !newFile.IsValid() )		// valid file?
		errFlag = 1;
	else if ( !newFilePath.Exists() )	// file directory exists?
		errFlag = 2;

	if ( errFlag )
	{
		retVal = true;
		vNoticeDialog dlg (this, "Error in File Name or File");
		char msg[512];
		strcpy (msg, "The file you specified is not valid:\n\n");
		strcat (msg, name);
		if ( errFlag == 1 )
			strcat (msg, "\n\nThe file name is not a valid name.");
		else if ( errFlag == 2 )
			strcat (msg, "\n\nThe file\'s folder does not exist.");
		dlg.Notice (msg);
	}
	return retVal;
}

//	ShowHideModified
//	Toggles the display of the "modified" message at the top-right
//	of the dialog.
TEMPLATE_DECLARATION
void SITEEDITORDLG::ShowHideModified ()
{
	if ( siteDataSrc->Get()->IsModified() )
		SetValue (D_Modified, 0, Hidden);	// show
	else
		SetValue (D_Modified, 1, Hidden);	// hide
}

//	BuildParamNameLists
//	Build the lists of lists of parameter names - only once!
TEMPLATE_DECLARATION
void SITEEDITORDLG::BuildParamNameLists ()
{
	if ( !HaveDisplayedData() )
		return;

	short const numSets = siteDataSrc->Get()->GetSetCount();
	parameterNames.resize (numSets);

	std::vector<vSList>::iterator iParameterNames = parameterNames.begin();
	for ( short setNum = 0; setNum < numSets; ++setNum, ++iParameterNames )
	{
		vStringContainerToSList (
			infoPtr->BeginNames (setNum),
			infoPtr->EndNames (setNum),
			*iParameterNames );
	}
}

//	DisplayParameterValue
//	Display a parameter value in the parameter value Text box.
TEMPLATE_DECLARATION
void SITEEDITORDLG::DisplayParameterValue (
	TSiteParameter const * const parameter,
	ItemVal const indexParamList)
{
	Assert (parameter != 0);
	// force float conversion in case of odd values
	float const value = static_cast<float>( parameter->GetValue() );
	sprintf ( displayStr, "%-.4g", value );
	SetString ( D_ParamValue, displayStr );
	SetString ( D_ParamDesc,
		    infoPtr->GetDescription (
			dispSetNum, indexParamList).c_str() );
}

TEMPLATE_DECLARATION
void SITEEDITORDLG::BuildRadioButtonSetList (	// build dlg radiobutton list
	char const * const siteSetNames[],	//    from these strings
	int const startingButtonID,		//    first button ID
	int const frameID,			//    inside this frame
	DlgCmdsArray & cmdArray)		//    store here
{
	char const * const * pNames = siteSetNames;
	int id = startingButtonID;
	int i = 0;
	paramGroupToolTips.erase ();
	while ( *pNames )
	{
		// build a tooltip
		std::string toolTipStr = "Parameter group: ";
		toolTipStr += *pNames;
		paramGroupToolTips.insert ( i + 1, toolTipStr.c_str() );

		// create CommandObject
		CommandObject cmd;
		cmd.cmdType = C_RadioButton;
		cmd.cmdId = id;
		cmd.retVal = (i == 0 ? 1 : 0);
		cmd.title = *pNames;
		cmd.itemList = NoList;
		cmd.attrs = CA_None;
		cmd.Sensitive = isSens;
		cmd.cFrame = frameID;
		cmd.cRightOf = 0;
		cmd.cBelow = id - 1;
		cmd.size = 0;
		cmd.tip = paramGroupToolTips.list[i];
		cmdArray.push_back (cmd);

		++pNames;
		++id;
		++i;
	}
}

// --- end of file ---



