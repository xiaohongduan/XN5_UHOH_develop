#ifndef INC_TOutputSelectDlg_h
#define INC_TOutputSelectDlg_h
// ----------------------------------------------------------------------------
//	Copyright 2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  TOutputSelectDlg.h
//	Class:	  TOutputSelectDlg
//
//	Description:
//	Class for a dialog to select the name, path, and type of output
//	for a Century simulation.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, Nov03, tom.hilinski@colostate.edu
//	History:
// ----------------------------------------------------------------------------

#include "TModalDlg.h"
#include "TOutputBase.h"
#include <string>

class vApp;
class vBaseWindow;

class TOutputSelectDlg
	: public TModalDlg
{
  public:
	//--- types
	enum /* anonymous */		// Command objects values
	{
	  Enum_Dlg_Start = 8500,	// first item!
					//--- Output type
	  D_FrameOutputType,
	  D_OutType_CVS,		// radiobutton: CVS/spreadsheet file
	  D_OutType_NetCDF,		// radiobutton: NetCDF file
					//--- Output File
	  D_FrameOutputFile,
	  D_FileName,			// text: file name
	  D_BrowseFileName,		// button: browse for file name
	  D_ClearFileName,		// button: clear file name display
					//--- buttons
	  D_FrameCommonButtons,
					//--- all done!
	  Enum_Dlg_End			// last item!
	};

	//--- constructors and destructor
	TOutputSelectDlg (
	  vApp * const useParent,			// parent application
	  std::string & initFileNameBase,		// output file name
	  TOutputBase::TOutputType & initOutputType,	// output type
	  char const * const title =			// default dialog title
	  	defaultDlgTitle);
	TOutputSelectDlg (
	  vBaseWindow * const useParent,		// parent window
	  std::string & initFileNameBase,		// output file name
	  TOutputBase::TOutputType & initOutputType,	// output type
	  char const * const title =			// default dialog title
	  	defaultDlgTitle);
	~TOutputSelectDlg ()
	  {
	    ClearDialog ();
	  }

	//--- functions overridden
	void DialogDisplayed ();
	void DialogCommand (ItemVal cmdID, ItemVal cmdValue, CmdType cmdType);

	//--- functions
	std::string const & GetFileNameBase (
	  ) const
	  { return fileNameBase; }
	TOutputBase::TOutputType GetOutputType (
	  ) const
	  { return outputType; }
	bool Cancelled () const			// True if cancel button pressed
	  { return cancelled; }
	void Clear ();				// "clear" data members

  private:
  	//--- constants
	static const char * toolTips[];			// tool tips text
	static CommandObject cmdList[];			// dialog elements
	static char const * const defaultDlgTitle;	// default dialog title

	//--- data
	std::string & fileNameBase;		// output file name base
	TOutputBase::TOutputType & outputType;	// output type
	bool cancelled;				// true if cancel button pressed

	//--- initial data
	std::string const origFileNameBase;		// output file name base
	TOutputBase::TOutputType const origOutputType;	// output type

	//--- functions
					//--- Load/Clear data in dialog:
	void LoadDlg ();		// Load the dialog
	void ClearDialog ();		// Clears the entire dialog
					//--- Events:
	void EventOK ();		// button: OK
	void EventCancel ();		// button: Cancel
	void EventOutTypeCVS ();	// radiobutton: CVS/spreadsheet file
	void EventOutTypeNetCDF ();	// radiobutton: NetCDF file
	void EventBrowseFileName ();	// button: browse for file name
	void EventClearFileName ();	// button: clear file name
};

#endif // INC_TOutputSelectDlg_h
