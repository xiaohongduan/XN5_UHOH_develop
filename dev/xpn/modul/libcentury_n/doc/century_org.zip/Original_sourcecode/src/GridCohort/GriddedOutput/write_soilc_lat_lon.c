
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Rewrite the soilc.nc netCDF file using COARDS standards */
/* The original file was organized variable(cell, time) */
/* The new file is organized variable(time, lat, lon) */

#include <stdio.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf_ll.h"

    int write_soilc_ll_(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  defac_vals[MAXCELLS], som1c1_vals[MAXCELLS], som1c2_vals[MAXCELLS],
             som2c_vals[MAXCELLS], som3c_vals[MAXCELLS], strucc1_vals[MAXCELLS],
             strucc2_vals[MAXCELLS], metabc1_vals[MAXCELLS], metabc2_vals[MAXCELLS];
      int status;
      int oldsoilcid;
      int olddefacid, oldsom1c1id, oldsom1c2id, oldsom2cid, oldsom3cid,
          oldstrucc1id, oldstrucc2id, oldmetabc1id, oldmetabc2id;
      int ii, jj, ngrids;

      /* Open old version of soilc.nc file */
      status = nc_open("soilc.nc", NC_NOWRITE, &oldsoilcid);
      if (status != NC_NOERR) handle_error("nc_open(soilc.nc)", status);

      /* Get the indices for the soilc output variables */
      status = nc_inq_varid(oldsoilcid, "defac", &olddefacid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for defac",status);
      status = nc_inq_varid(oldsoilcid, "som1c1", &oldsom1c1id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for som1c1",status);
      status = nc_inq_varid(oldsoilcid, "som1c2", &oldsom1c2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for som1c2",status);
      status = nc_inq_varid(oldsoilcid, "som2c", &oldsom2cid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for som2c",status);
      status = nc_inq_varid(oldsoilcid, "som3c", &oldsom3cid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for som3c",status);
      status = nc_inq_varid(oldsoilcid, "strucc1", &oldstrucc1id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for strucc1",status);
      status = nc_inq_varid(oldsoilcid, "strucc2", &oldstrucc2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for strucc2",status);
      status = nc_inq_varid(oldsoilcid, "metabc1", &oldmetabc1id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for metabc1",status);
      status = nc_inq_varid(oldsoilcid, "metabc2", &oldmetabc2id);
      if(status != NC_NOERR) handle_error("nc_inq_varid for metabc2",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        defac_vals[ii] = fill;
        som1c1_vals[ii] = fill;
        som1c2_vals[ii] = fill;
        som2c_vals[ii] = fill;
        som3c_vals[ii] = fill;
        strucc1_vals[ii] = fill;
        strucc2_vals[ii] = fill;
        metabc1_vals[ii] = fill;
        metabc2_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the soilc output file */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldsoilcid, olddefacid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for defac",status);
            }
            defac_vals[jj] = val;
            status = nc_get_var1_float(oldsoilcid, oldsom1c1id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for som1c1",status);
            }
            som1c1_vals[jj] = val;
            status = nc_get_var1_float(oldsoilcid, oldsom1c2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for som1c2",status);
            }
            som1c2_vals[jj] = val;
            status = nc_get_var1_float(oldsoilcid, oldsom2cid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for som2c",status);
            }
            som2c_vals[jj] = val;
            status = nc_get_var1_float(oldsoilcid, oldsom3cid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for som3c",status);
            }
            som3c_vals[jj] = val;
            status = nc_get_var1_float(oldsoilcid, oldstrucc1id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for strucc1",status);
            }
            strucc1_vals[jj] = val;
            status = nc_get_var1_float(oldsoilcid, oldstrucc2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for strucc2",status);
            }
            strucc2_vals[jj] = val;
            status = nc_get_var1_float(oldsoilcid, oldmetabc1id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for metabc1",status);
            }
            metabc1_vals[jj] = val;
            status = nc_get_var1_float(oldsoilcid, oldmetabc2id, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for metabc2",status);
            }
            metabc2_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(soilcll_ncid, defacll_id, start, count, defac_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for defac",status);
        status = nc_put_vara_float(soilcll_ncid, som1c1ll_id, start, count, som1c1_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for som1c1",status);
        status = nc_put_vara_float(soilcll_ncid, som1c2ll_id, start, count, som1c2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for som1c2",status);
        status = nc_put_vara_float(soilcll_ncid, som2cll_id, start, count, som2c_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for som2c",status);
        status = nc_put_vara_float(soilcll_ncid, som3cll_id, start, count, som3c_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for som3c",status);
        status = nc_put_vara_float(soilcll_ncid, strucc1ll_id, start, count, strucc1_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for strucc1",status);
        status = nc_put_vara_float(soilcll_ncid, strucc2ll_id, start, count, strucc2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for strucc2",status);
        status = nc_put_vara_float(soilcll_ncid, metabc1ll_id, start, count, metabc1_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for metabc1",status);
        status = nc_put_vara_float(soilcll_ncid, metabc2ll_id, start, count, metabc2_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for metabc2",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldsoilcid);

      return 0;
    }
