#ifndef INC_TCenturyCellOutputMgr_h
#define INC_TCenturyCellOutputMgr_h

// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  TCenturyCellOutputMgr.h
//	Class:	  TCenturyCellOutputMgr
//
//	Description:
//	Class for managing simulation output at the cell level for
//	the DayCent model.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, June 2002
//	History:
//	<date, eg., 29May01>	<your name>, <your e-mail address>
//	<description of modifications>
// ----------------------------------------------------------------------------

#include "TCellOutputMgr.h"
#include "TCellCSVFileOutput.h"
#include "TModelBase.h"
#include "TGridCell.h"

class TDayCentGCF;

namespace nrel
{
  namespace dcirc
  {

class TCenturyCellOutputMgr
	: public ::nrel::gcf::TCellOutputMgr
{
  public:
	//---- types
	typedef ::nrel::gcf::TGridCell			TOwner;
	typedef ::nrel::gcf::TCellCSVFileOutput		TOutput;

	//---- constructors and destructor
	TCenturyCellOutputMgr (
	  TOwner * const useParent,			// ptr to parent
	  TSharedPtr<TOutput> outputSink); 		// output sink
	virtual ~TCenturyCellOutputMgr ()
	  {
	    csvFile->Close ();
	  }
	TCenturyCellOutputMgr (				// copy constructor
	  TCenturyCellOutputMgr const & object)
	  : ::nrel::gcf::TCellOutputMgr (object),
	    csvFile (object.csvFile)
	  {
	  }

	//---- operator overloads
	TCenturyCellOutputMgr& operator= (
	  TCenturyCellOutputMgr const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
		::nrel::gcf::TCellOutputMgr::operator= (object);
	    }
	    return *this;
	  }

	//---- functions
	void Clear ()					// "Clear" data members
	  {
	    ::nrel::gcf::TCellOutputMgr::Clear ();
	  }

	//---- functions: Queries

  protected:
	//---- constants

	//---- data
	TSharedPtr<TOutput> csvFile;			// output object

	//---- functions

  private:
	//---- constants

	//---- data

	//---- functions
	virtual void DoCollectOutput (		// Collect output from models
	  bool const atOutputTime)
	  {
	    GetOutputVariablesManager().UpdateValues ();
	  }

};

  } // namespace dcirc
} // namespace nrel

#endif // INC_TCenturyCellOutputMgr_h
