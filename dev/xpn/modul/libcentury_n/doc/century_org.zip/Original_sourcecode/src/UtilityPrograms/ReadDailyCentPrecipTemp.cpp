// ----------------------------------------------------------------------------
//	Copyright 2002, 2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  ReadDailyCentPrecipTemp.cpp
//	Class:	  ReadDailyCentPrecipTemp
//
//	Description:
//	Reads precip and temperature data from Century daily weather file
//	into arrays.
//---------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May2005 (C++ driver)
//		Cindy Keough, 2002, file read, and statistical functions.
//	History: See header file.
// ----------------------------------------------------------------------------

#include "ReadDailyCentPrecipTemp.h"
using namespace nrel::util;
#include "fnutil.h"
#include <cstdio>
#include <cerrno>
#include <cstring>
#include <cstdlib>

// ----------------------------------------------------------------------------
//	Original C function (with minor mods to use 2D arrays)
// ----------------------------------------------------------------------------

//---------------------------------------------------------------------------
/*
**  FILE:      process_weather.c
**
**  FUNCTION:  void process_daily_weather()
**
**  PURPOSE:   Read the weather data from an existing DayCent 4.5 weather data
**             file, assimilate the information for each month/year, and store
**             the data in the weather arrays.
**
**  INPUTS:
**    wthrfp - file pointer to the DayCent 4.5 weather data file
**
**  GLOBAL VARIABLES:
**    BUFSIZE - maximum buffer size (132)
**    MAXYRS  - maximum number of years of historical weather data (500)
**    MONTHS  - number of months per year (12)
**
**  EXTERNAL VARIABLES:
**    None
**
**  LOCAL VARIABLES:
**    buf[]           - buffer to hold information read from weather data file
**    current_month   - the month of data read from the daily weather data
**                      file that is being processed
**    current_year    - the year of data read from the daily weather data file
**                      that is being processed
**			This is actually the zero-based year count;
**			the actual year value is in variable "year".
**    day_of_month    - day of month, as read from the weather data file
**    julian_day      - Julian day, as read from the weather data file
**    maxtemp         - maximum temperature value, as read from the weather
**                      data file
**    mintemp         - minimum temperature value, as read from the weather
**                      data file
**    month           - month, as read from the weather data file
**    month_max_avg   - average of valid maximum temperature values read from
**                      the weather data file for the current month
**    month_max_count - number of valid maximum temperature values read from
**                      the weather data file for the current month
**    month_max_total - summation of valid maximum temperature values read
**                      from the weather data file for the current month
**    month_min_avg   - average of valid minimum temperature values read from
**                      the weather data file for the current month
**    month_min_count - number of valid minimum temperature values read from
**                      the weather data file for the current month
**    month_min_total - summation of valid minimum temperature values read
**                      from the weather data file for the current month
**    month_ppt_count - number of valid precipitation values read from the
**                      weather data file for the current month
**    month_ppt_total - summation of valid precipitation values read from the
**                      weather data file for the current month
**    precip          - precipitation value, as read from the weather data
**                      file
**    year            - year, as read from the weather data file
**
**  OUTPUTS:
**    prec[][]     - precipitation data, assimilated from daily weather data
**                   file, by year and month
**    tmax[][]     - maximum temperature data, assimilated from daily weather
**                   data file, by year and month
**    tmin[][]     - minimum temperature data, assimilated from daily weather
**                   data file, by year and month
**
**  RETURNS:
**    the number of records read from the file.
**
**  CALLED BY:
**    weather
**
**  CALLS:
**    None
*/
//---------------------------------------------------------------------------

int ReadDailyCentPrecipTemp::process_daily_weather (
	std::FILE * const wthrfp,	// file to read
	T2DFloatArray & prec,		// precipitation [year][month]
	T2DFloatArray & tmin,		// minimum temperature [year][month]
	T2DFloatArray & tmax,		// maximum temperature [year][month]
	TInterval<long> & yearRange)	// year range of the data
{
    using namespace std;

    const short BUFSIZE = 1024;
    char buf[ BUFSIZE ];
    int day_of_month;
    int month;
    int year;
    int julian_day;
    float maxtemp;
    float mintemp;
    float precip;
    int month_max_count, month_min_count, month_ppt_count;
    float month_max_total, month_min_total, month_ppt_total;
    float month_max_avg, month_min_avg;
    int current_year = 0;
    int current_month = 1;
    int recordCount = 0;

    /* Initializations */

    prec = 0.0f;
    tmin = 0.0f;
    tmax = 0.0f;

    month_max_count = 0;
    month_min_count = 0;
    month_ppt_count = 0;
    month_max_total = 0.0f;
    month_min_total = 0.0f;
    month_ppt_total = 0.0f;

    /* Read the values from the existing weather file one line at a time */

    long yearStart = -999999;
    while ( fgets( buf, sizeof buf, wthrfp ) != NULL )
    {
	// check for comment records
	if ( IsComment (buf) )
		continue;		// skip

	// parse record
	sscanf( buf, "%d %d %d %d %f %f %f", &day_of_month, &month, &year,
		&julian_day, &maxtemp, &mintemp, &precip );
	++recordCount;

	if ( yearStart == -999999L )
		yearStart = year;
	if ( month == current_month )
	{
	    if ( maxtemp >= -98.0 )
	    {
		    month_max_count++;
		    month_max_total += maxtemp;
	    }

	    if ( mintemp >= -98.0 )
	    {
		    month_min_count++;
		    month_min_total += mintemp;
	    }

	    if ( precip >= -98.0 )
	    {
		    month_ppt_count++;
		    month_ppt_total += precip;
	    }
	}

	else
	{

	    /* We are at the end of the month, store the values */

	    if ( month_max_count > 1 )
	    {
		    month_max_avg = month_max_total / month_max_count;
	    }

	    else
	    {
		    month_max_avg = missingValue;
	    }

	    if ( month_min_count > 1 )
	    {
		    month_min_avg = month_min_total / month_min_count;
	    }

	    else
	    {
		    month_min_avg = missingValue;
	    }

	    if ( month_ppt_count < 1 )
	    {
		    month_ppt_total = missingValue;
	    }

	    // check that the arrays are big enough
	    if (  current_month == 12 &&
	          current_year + 1 > prec.size().first )
	    {
		// increment by 1 year
		// inefficient if several of these are done,
		// but since the record count is supposed to be
		// previously known, normally this code block shouldn't
		// be entered
		tmax.resize ( (current_year + 1), 12 );
		tmin.resize ( (current_year + 1), 12 );
		prec.resize ( (current_year + 1), 12 );
	    }

	    // save data
	    tmax( current_year, current_month - 1 ) = month_max_avg;
	    tmin( current_year, current_month - 1 ) = month_min_avg;
	    prec( current_year, current_month - 1 ) = month_ppt_total;

	    /* Reset counters and accumulators */

	    if ( current_month == 12 )
	    {
		++current_year;
	    }

	    current_month = month;

	    if ( maxtemp >= -98.0 )
	    {
		    month_max_count = 1;
		    month_max_total = maxtemp;
	    }

	    else
	    {
		    month_max_count = 0;
		    month_max_total = 0.0f;
	    }

	    if ( mintemp >= -98.0 )
	    {
		    month_min_count = 1;
		    month_min_total = mintemp;
	    }

	    else
	    {
		    month_min_count = 0;
		    month_min_total = 0.0f;
	    }

	    if ( precip >= -98.0 )
	    {
		    month_ppt_count = 1;
		    month_ppt_total = precip;
	    }

	    else
	    {
		    month_ppt_count = 0;
		    month_ppt_total = 0.0f;
	    }
	}
    }

    /* Write out the final month's values */
    if ( month_max_count > 1 )
    {
	    month_max_avg = month_max_total / month_max_count;
    }

    else
    {
	    month_max_avg = missingValue;
    }

    if ( month_min_count > 1 )
    {
	    month_min_avg = month_min_total / month_min_count;
    }

    else
    {
	    month_min_avg = missingValue;
    }
    // need missing values?
    if ( current_month < 12 ||	// didn't fill up the year?
	 current_year + 1 < prec.size().first )
    {
	// add missing values
	++current_month;
	while ( current_month < 12 )
	{
		tmax( current_year, current_month - 1 ) = missingValue;
		tmin( current_year, current_month - 1 ) = missingValue;
		prec( current_year, current_month - 1 ) = missingValue;
		++current_month;
	}
    }

    if ( month_ppt_count < 1 )
    {
	    month_ppt_total = missingValue;
    }

    tmax( current_year, current_month - 1 ) = month_max_avg;
    tmin( current_year, current_month - 1 ) = month_min_avg;
    prec( current_year, current_month - 1 ) = month_ppt_total;
    yearRange = TInterval<long> (yearStart, year);

    return recordCount;
}

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

char const * const ReadDailyCentPrecipTemp::version =		// class version number
	"1.0.0.0";

const float ReadDailyCentPrecipTemp::missingValue = -99.99f;

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

ReadDailyCentPrecipTemp::ReadDailyCentPrecipTemp (
	std::string const & fileName,
	long const yearStart,
	long const yearEnd)
	: recordCount (0)
{
	if ( ReadData (fileName, yearStart, yearEnd) )
	{
		// failed
		errorMsg.insert (0, "Error - Read of weather data failed:\n");
	}
}

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

bool ReadDailyCentPrecipTemp::operator== (
	ReadDailyCentPrecipTemp const & object) const
{
	if ( &object )
	{
		return yearRange == object.yearRange &&
			ARRAY_EQUAL<T2DBoolArray> (precip, object.precip) &&
			ARRAY_EQUAL<T2DBoolArray> (tempMin, object.tempMin) &&
			ARRAY_EQUAL<T2DBoolArray> (tempMax, object.tempMax);
	}
	else
		return false;
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	Clear
// 	"clear" data members
void ReadDailyCentPrecipTemp::Clear ()
{
	errorMsg.clear ();
	recordCount = 0;
	yearRange.Clear ();
	precip.clear ();
	tempMin.clear ();
	tempMax.clear ();
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

ReadDailyCentPrecipTemp::TSizeDimensions
    ReadDailyCentPrecipTemp::GetRecordsInFile (
	  std::FILE * const fp)
{
	using namespace std;

	TSizeDimensions dim = make_pair(0, 0);		// return value

	// count the data records
	const short BUFSIZE = 1024;
	char buf[ BUFSIZE ];
	int current_year = 1;
	int current_month = 1;
	int leapYearDayCount = 0;
	int dataRecordCount = 0;
	std::fseek (fp, 0, SEEK_SET);		// beginning
	while ( fgets( buf, sizeof buf, fp ) != NULL )
	{
		if ( IsComment (buf) )
			continue;

		int day_of_month, month, year;
		sscanf( buf,
			"%d %d %d ",
			&day_of_month, &month, &year );
		++dataRecordCount;

		// check for leap year days
		if ( month == 2 && day_of_month == 29 )
			++leapYearDayCount;

		if ( month != current_month )		// start next month?
		{
			if ( current_month == 12 )	// end of year?
			{
				++current_year;
				current_month = 1;
			}
			else
				++current_month;
		}
		
	}
	std::fseek (fp, 0, SEEK_SET);		// beginning

	// calculate the year size
	int const expectedDayCount = 365 * current_year + leapYearDayCount; 
	div_t qr = div (dataRecordCount, expectedDayCount);
	dim.first =  current_year;
	if ( qr.rem > 0 )
		++dim.first;
	dim.second = 12;

	return dim;
}

//	ReadData
//	Read data into the arrays from the file specified.
//	Returns false if successful, else true if error.
bool ReadDailyCentPrecipTemp::ReadData (
	std::string const & fileName,
	long const yearStart,
	long const yearEnd)
{
	using namespace std;

	// read data
	FILE * fp = fopen (fileName.c_str(), "r");
	if ( fp )
	{
	    // resize arrays
	    TSizeDimensions dim = GetRecordsInFile (fp);
	    precip.resize (dim.first, dim.second);
	    tempMin.resize (dim.first, dim.second);
	    tempMax.resize (dim.first, dim.second);

	    // read data
	    yearRange = TInterval<long> (yearStart, yearEnd);
	    recordCount = process_daily_weather (
	    			fp, precip, tempMin, tempMax, yearRange);
	    if ( ferror (fp) && strerror (errno) )
		errorMsg = strerror (errno);		// system error msg
	    fclose (fp);

	    // error checks
	    if ( recordCount == 0 )
	    {
		if ( !errorMsg.empty() )
			errorMsg += '\n';
		errorMsg += "No records were successfully read.";
	    }

	    if ( dim.first != precip.size().first ||
		 dim.first != tempMin.size().first ||
		 dim.first != tempMax.size().first )
	    {
		if ( !errorMsg.empty() )
			errorMsg += '\n';
		errorMsg += "Array size dimension mismatch - "
			    "before vs. after data read.";
	    }
	}
	else
	{
		errorMsg = "Error opening file: \"";
		errorMsg += fileName;
		errorMsg += "\"";
	}
	return !errorMsg.empty();
}

//	Copy
// 	copy to this
void ReadDailyCentPrecipTemp::Copy (const ReadDailyCentPrecipTemp &fromObj)
{
	if ( &fromObj )
	{
		errorMsg = fromObj.errorMsg;
		recordCount = fromObj.recordCount;
		yearRange = fromObj.yearRange;
		precip = fromObj.precip;
		tempMin = fromObj.tempMin;
		tempMax = fromObj.tempMax;
	}
}

//--- end of definitions for ReadDailyCentPrecipTemp ---




