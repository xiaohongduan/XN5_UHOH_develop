#ifndef INC_SiteEditorDataSrcFile_h
#define INC_SiteEditorDataSrcFile_h
// ----------------------------------------------------------------------------
//	Copyright 2004 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  SiteEditorDataSrcFile.h
//	Class:	  SiteEditorDataSrcFile
//
//	Description:
//	Template class for the data source for the Site Editor for Century5
//	site parameters from a file.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Dec04
//	History:
// ----------------------------------------------------------------------------

#include "SiteEditorDataSrcBase.h"
#include "TSiteParamUnknown.h"
#include "v/vapp.h"
#include <string>

template
<
	class SiteParameters,		// parameter values
	class SiteParamInfo		// parameter names and descriptions
>
class SiteEditorDataSrcFile
	: public SiteEditorDataSrcBase<SiteParameters, SiteParamInfo>
{
  public:
  	//---- types
  	typedef SiteEditorDataSrcBase<SiteParameters, SiteParamInfo>
  		MyBaseClass;
  	typedef SiteEditorDataSrcFile<SiteParameters, SiteParamInfo>
  		MyType;

	//---- constructors and destructor
	SiteEditorDataSrcFile (
	  vApp * const useParent,			// pointer to app
	  std::string const & useFileName,		// parameters file name
	  std::string const & useTmpltPath,		// template files
	  std::string const & useWorkPath,		// working directory
	  SiteParamInfo::TInfoPtr useInfo)		// parameter names
	  : SiteEditorDataSrcBase<SiteParameters, SiteParamInfo> (
	  	useInfo),
	    parent (useParent),
	    templatePath (useTmpltPath),
	    workPath (useWorkPath),
	    activePath (useWorkPath),
	    fileName (useFileName)
	  {
	    /* error = */ Read (dataPtr);
	  }
	SiteEditorDataSrcFile (
	  vApp * const useParent,			// pointer to app
	  TSiteParametersBase::TSitePtr useSiteParameters, // parameters
	  SiteParamInfo::TInfoPtr useInfo)		// parameter names
	  : SiteEditorDataSrcBase<SiteParameters, SiteParamInfo> (
	  	useInfo),
	    parent (useParent),
	    templatePath ( useSiteParameters->GetTemplatePath() ),
	    workPath ( useSiteParameters->GetWorkPath() )
	  {
	    activePath = workPath;
	    fileName = useSiteParameters->GetNcFileName().GetFullName();
	    DoSave ( dynamic_cast<SiteParameters &>(*useSiteParameters) );
	  }
	SiteEditorDataSrcFile (
	  MyType const & object)
	  : SiteEditorDataSrcBase<SiteParameters, SiteParamInfo> (object),
	    parent (object.parent),
	    templatePath (object.templatePath),
	    workPath (object.workPath),
	    activePath (object.activePath),
	    fileName (object.fileName)
	  {
	  }
	virtual ~SiteEditorDataSrcFile ()
	  {
	  }
	virtual MyType * const Clone () const	// Clone this
	  {
	    return new MyType (*this);
	  }

	//---- operator overloads
	SiteEditorDataSrcFile & operator= (
	  MyType const & object)
	  {
	    MyBaseClass::operator= (object);
	    return *this;
	  }
	bool operator== (
	  MyType const & object) const
	  {
	    if ( &object )
	    {
		return
		  MyBaseClass::operator== (object) &&
		  fileName == object.fileName;
	    }
	    else
		return false;
	  }
	bool operator!= (
	  MyType const & object) const
	  {
	    return !(*this == object);
	  }

	std::string const & GetFileName () const
	  { return fileName; }

  protected:
	vApp * const parent;		// parent dialog
	std::string const templatePath;		// path to template folder
	std::string const workPath;		// user's work path
	std::string activePath;			// user's current path
	std::string fileName;			// site param file name

	bool Read (				// Read the file
	  TSharedPtr<SiteParameters> & siteParameters);
	bool Write ();				// Write the file
	void ReadWriteErrorNotice (
	  char const * const msgFirstPart);

  private:
	virtual TUserAction DoOpen (
	  TSharedPtr<SiteParameters> & siteParameters);
	virtual TUserAction DoSave (
	  SiteParameters const & siteParameters);
	virtual TUserAction DoSaveAs (
	  SiteParameters & siteParameters);
};

#endif // INC_SiteEditorDataSrcFile_h
