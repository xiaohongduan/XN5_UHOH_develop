#ifndef INC_daycenttypes_h
#define INC_daycenttypes_h

// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  daycenttypes.h
//	Class:	  TDayCent
//
//	Description:
//	Types, structs, and classes for class TDayCent and related classes.
//
//	Author: Melannie Hartman
// ----------------------------------------------------------------------------
//	History:
//      See Century/centtypes.h
//	Apr01  Melannie Hartman, melannie@NREL.colostate.edu
//      * Added new Tparcp members (Crop parameters)
//      * Added new Tparfs members (Forest-Savanna parameters)
//      * Added new TFixed members
//      Aug01   Melannie Hartman, melannie@NREL.colostate.edu
//      * Created file "daycenttypes.h from centtypes.h.  Removed
//        classes not modified for DayCent. Define only TFixed, Tparcp,
//        and Tparfs.
//	Sep01  Melannie Hartman, melannie@NREL.colostate.edu
//      * Added new nitrateUptakePref Tparcp member (Crop parameters)
//      * Added new nitrateUptakePref Tparfs member (Forest-Savanna parameters)
//      * Define Tparam based on centtypes.h Tparam definition
//      * Added new nitrateFertFrac Tparam member
//	Nov01  Melannie Hartman, melannie@NREL.colostate.edu
//      * Added new maxMntRespRat[*] parameters to Tparcp and Tparfs members
//      Jan02   Melannie Hartman, melannie@NREL.colostate.edu
//      * Cut Tfixed, Tparam, Tparcp, and Tparfs from centtypes.h and
//        added DayCent specific variables to these structs.
//	Jun-Jul02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Added default constructors, virtual destructors, Clear() members.
//	* Changed names from T* to TDC*.
//	* Added struct TDCStaticVars
//	* Now they inherit and extend their "centypes.h" counterparts.
//	* Replaced memset calls with explicit initialization of variables.
//	* Added struct TDailyBiomass
//	May04	Tom Hilinski
//      * TDCFixed now in it's own files; extended along with class TFixed.
// ----------------------------------------------------------------------------

#include "centtypes.h"
#include "arraytypes.h"
#include "TDCFixed.h"
#include <cstring>

//	------------------------------------------------------------
//	TMaintRespiration
//	Maintenance respiration variables
//	Note: Need for this class is yet to be determined.
struct TMaintRespiration
{
    TMaintRespiration ()
      {
      	Clear ();
      }
    virtual ~TMaintRespiration ()
      {
      }
    void Clear ()
      {
      	// To Do: TMaintRespiration::Clear
      }

    //---- public data
    // static short const maxDaysPerYear;	// == 366
    // float mRespCropFlux[366];	// maintenance resp. for crops (gC/m^2/day)
    // float mRespTreeFlux[366];	// maintenance resp. for trees (gC/m^2/day)
};

//	------------------------------------------------------------
//	TDailyBiomass
struct TDailyBiomass
{
    TDailyBiomass ()
      {
      	Clear ();
      }
    virtual ~TDailyBiomass ()
      {
      }
    void Clear ()
      {
      	agLiveBiomass = surfaceLitterBiomass = standDeadBiomass =
      		biomass = 0.0f;
      }

    //---- public data
    float
    	agLiveBiomass,		// aboveground live biomass (g/m^2)
    	surfaceLitterBiomass,	// litter biomass (g/m^2)
    	standDeadBiomass,	// standing dead biomass (g/m^2)
	biomass;		// total aboveground biomass (g/m^2)
};

//	------------------------------------------------------------
//	TDCStaticVars
//	This is temporary kluge to provide a place to hold what were
//	local static vars.
//	To Do: TDCStaticVars - Move these into their appropriate structs.
struct TDCStaticVars
{
    TDCStaticVars ()
      {
      	Clear ();
      }
    virtual ~TDCStaticVars ()
      {
      }
    void Clear ()
      {
      	numGreenUpPeriods = 0;
        greenUpCnt = 0;
      }

    //---- public data
    float prodIrrigation;	// InitDailyCycle
    short numGreenUpPeriods;	// DeciduousGreenUpPeriod
				//    number of time periods allocated
				//    to deciduous green up
    short greenUpCnt;           // # of greenup periods that have passed
};

//	------------------------------------------------------------
//	TDCparam
//	Site and management parmaters.
struct TDCparam : public Tparam
{
    TDCparam ()
      : Tparam ()
      {
      	Clear ();
      }
    virtual ~TDCparam ()
      {
      }
    void Clear ()
      {
      	Tparam::Clear ();
      	nitrateFertFrac = 0.0f;
      }

    //---- public data
	  		//--- fertilization
    // fraction of N fertilizer that is nitrate (0-1) -mdh 9/12/01
    float nitrateFertFrac;
};

//	------------------------------------------------------------
//	TDCparcp
//	Crop parameters
struct TDCparcp : public Tparcp
{
    TDCparcp ()
      : Tparcp ()
      {
      	Clear ();
      }
    virtual ~TDCparcp ()
      {
      }
    void Clear ()
      {
      	Tparcp::Clear ();
       	for ( short i = 0; i < 3; ++i )
	  a2drat[i] = 0.0f;
       	for ( short i = 0; i < 4; ++i )
	  frtc[i] = 0.0f;
	frtcindx = 0;
	kmrsp = kmrspMax[0] = kmrspMax[1] = nitrateUptakePref = pptprd = 0.0f;
     }

    //---- public data
    float
        a2drat[3],      // ratio available minerl E to plant demand for E -mdh 5/10/01
        frtc[4];	// was frtc[3] -mdh 4/25/01
    int frtcindx;       // new -mdh 4/25/01
			// frtcindx  - (0) Use Great Plains eqn,
			//	(1) perrenial plant,
			//	(2) annual plant
    float
        kmrsp,          // -mdh 4/25/01 (prod frac that goes to maintenance resp storage)
        kmrspMax[2],    // -mdh 11/10/01 (max live C frac that goes to maintenance resp: ABOVE, BELOW)
        nitrateUptakePref, // mdh 9/11/01 (frac of N uptake that is NO3, 0-1)
        pptprd;		// effect of moisture on potential crop/grass production -mdh 5/11/01
};

//	------------------------------------------------------------
//	TDCparfs
//	Forest-Savanna parameters
struct TDCparfs : public Tparfs
{
    TDCparfs ()
      : Tparfs ()
      {
      	Clear ();
      }
    virtual ~TDCparfs ()
      {
      }
    void Clear ()
      {
      	Tparfs::Clear ();
       	for ( short i = 0; i < 3; ++i )
	  a2drat[i] = 0.0f;
	frfrac[0] = frfrac[1] = kmrsp = 0.0f;
       	for ( short i = 0; i < FPARTS; ++i )
	  kmrspMax[i] = treeCfrac[i] = 0.0f;
	nitrateUptakePref = pptprd = 0.0f;
      }

    //---- public data
    float
        a2drat[3],      // ratio available minerl E to plant demand for E -mdh 5/10/01
        frfrac[2],      // -mdh 4/25/01
        kmrsp,          // -mdh 4/25/01 (prod frac that goes to maintenance resp storage, 0-1)
        kmrspMax[FPARTS],// -mdh 11/10/01 (max live C frac that goes to maintenance resp, 0-1)
        nitrateUptakePref, // -mdh 9/11/01 (frac of N update that is NO3, 0-1)
        pptprd,         // effect of moisture on potential forest production -mdh 5/11/01
        treeCfrac[FPARTS]; // -mdh 4/25/01
};

#endif // INC_daycenttypes_h



