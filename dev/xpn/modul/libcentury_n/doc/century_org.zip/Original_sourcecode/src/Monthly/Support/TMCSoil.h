#ifndef INC_TMCSoil_h
#define INC_TMCSoil_h
// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model, monthly version
//	File:     TMCSoil.h
//	Class:    TMCSoil
//
//	Description:
//	Derived from TCenturySoil, implements monthly Century-specific
//	functions.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Aug03
//	History:
// ----------------------------------------------------------------------------
//	Notes:
//
//	The following soil components are defined in this class:
//
//		    Pool or
//	Component:  Property:	Description:
//	----------  ---------	-------------------------------------------
//	mineral N   pool	mineral N (g m-2)
//	mineral P   pool	mineral P (g m-2)
//	mineral S   pool	mineral S (g m-2)
//
//	Soil components are indexed in TCenturySoil:
//  	index	component	Where created:		Type:
//	0	bulk density	ReadSiteParameters	property
//	1	sand fraction	ReadSiteParameters	property
//	2	silt fraction	ReadSiteParameters	property
//	3	clay fraction	ReadSiteParameters	property
//	4	wilting point	ReadSiteParameters	property
//	5	field capacity	ReadSiteParameters 	property
//	6	water content   ReadSiteParameters	pool
//	7	SOM wt %	ReadSiteParameters 	property
//
//	Soil components are indexed in in TMCSoil:
//  	index	component	Where created:		Type:
//	------- --------------- ----------------------- --------
//	8	mineral N	ReadSiteParameters 	pool
//	9	mineral P	ReadSiteParameters	pool
//				  if site.nelem > 1
//	10	mineral S	ReadSiteParameters 	pool
//				  if site.nelem == 3
// ----------------------------------------------------------------------------

#include "TCenturySoil.h"
#include "centconsts.h"

class TMCSoil : public TCenturySoil
{
  public:
	//--- constructors and destructor
	TMCSoil (
	  nrel::eco::TEcosystemModelBase const & useOwner)	// owner = model
	  : TCenturySoil (useOwner)
	  {
	  }
	TMCSoil (
	  nrel::eco::TEcosystemModelBase const & useOwner,	// owner = model
	  short const useNumLayers)
	  : TCenturySoil (useOwner, useNumLayers)
	  {
	  }
	TMCSoil (					// copy constructor
	  TMCSoil const & object)
	  : TCenturySoil (object)
	  {
	  }
	~TMCSoil ()
	  {
	  }

	// Misc. public functions

	float QuantityE (			// Mineralized N,P,S in layer
	  TMineralElements element,		//   this element
	  unsigned short const top,		//   top layer
	  unsigned short const bottom		//   bottom layer
	  ) const
	  {
	    float amount;
	    if (element == N)
		amount =
		  MineralN().Quantity (top, bottom);
	    else if (element == P)
		amount =
		  MineralP().Quantity (top, bottom);
	    else if (element == S)
		amount =
		  MineralS().Quantity (top, bottom);
	    else
		amount = 0.0f;
	    return amount;
	  }
	float QuantityE (			// Mineralized N,P,S in layer
	  TMineralElements element,		//   this element
	  float const topDepth,			//   top soil depth (cm)
	  float const bottomDepth		//   bottom soil depth (cm)
	  ) const
	  {
	    float amount;
	    if (element == N)
		amount =
		  MineralN().Quantity (topDepth, bottomDepth,
		  			depth, thickness);
	    else if (element == P)
		amount =
		  MineralP().Quantity (topDepth, bottomDepth,
					depth, thickness);
	    else if (element == S)
		amount =
		  MineralS().Quantity (topDepth, bottomDepth,
		  			depth, thickness);
	    else
		amount = 0.0f;
	    return amount;
	  }

	//--- Data Access functions
	TSoilPool& MineralN ()				// Mineral N
	  { return static_cast<TSoilPool&>(
	    *compList[indexMineralN]); }
	TSoilPool const & MineralN () const		// Mineral N
	  { return static_cast<TSoilPool&>(
	    *compList[indexMineralN]); }
	TSoilPool& MineralP ()				// Mineral P
	  { return static_cast<TSoilPool&>(
	    *compList[indexMineralP]); }
	TSoilPool const & MineralP () const		// Mineral P
	  { return static_cast<TSoilPool&>(
	    *compList[indexMineralP]); }
	TSoilPool& MineralS ()				// Mineral S
	  { return static_cast<TSoilPool&>(
	    *compList[indexMineralS]); }
	TSoilPool const & MineralS () const		// Mineral S
	  { return static_cast<TSoilPool&>(
	    *compList[indexMineralS]); }
	float& MineralN (				// Mineral N
	  short const layerIndex)			//   index to layer
	  { return CompValue(indexMineralN,layerIndex); }
	float const & MineralN (			// Mineral N
	  short const layerIndex) const			//   index to layer
	  { return CompValue(indexMineralN,layerIndex); }
	float& MineralP (				// Mineral P
	  short const layerIndex)			//   index to layer
	  { return CompValue(indexMineralP,layerIndex); }
	float const & MineralP (			// Mineral P
	  short const layerIndex) const			//   index to layer
	  { return CompValue(indexMineralP,layerIndex); }
	float& MineralS (				// Mineral S
	  short const layerIndex)			//   index to layer
	  { return CompValue(indexMineralS,layerIndex); }
	float const & MineralS (			// Mineral S
	  short const layerIndex) const			//   index to layer
	  { return CompValue(indexMineralS,layerIndex); }


  protected:
	//--- constants
	static short const			// component indices
		indexMineralN,			//   pool
		indexMineralP,			//   pool
		indexMineralS;			//   pool

	//--- data

	//--- functions

  private:
	//--- data

	//--- functions

};

#endif // INC_TMCSoil_h
