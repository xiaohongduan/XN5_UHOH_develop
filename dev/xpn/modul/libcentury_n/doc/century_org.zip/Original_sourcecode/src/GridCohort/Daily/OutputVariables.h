#ifndef INC_nrel_dcirc_OutputVariables
#define INC_nrel_dcirc_OutputVariables

// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  OutputVariables.h
//	Class:	  OutputVariables
//
//	Description:
//	Base class for management of output variables for DayCentIRC.
//
//	Responsibilities:
//	* Knows names of output variables.
//	* Owns output variables.
//	* Manages output variables values.
//	* Provides public interface to output variables' names and values.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, April 2005
//	History:
//	<date, eg., 22May01>	<your name>, <your e-mail address>
//	<description>
// ----------------------------------------------------------------------------

#include "OutputVariablesMgrBase.h"
#include "TSharedPtr.h"
#include "GCFfwd.h"
#include "DayCentIRCTypes.h"

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class TCenturyCellOutputMgr;

class OutputVariables
	: public ::nrel::gcf::OutputVariablesMgrBase
{
  public:
	//---- types
	typedef TCenturyCellOutputMgr			OwnerType;

	//---- constructors and destructor
  protected:
	OutputVariables (
	  OwnerType * const ownerPtr)		// ptr to object owning this
	  : ::nrel::gcf::OutputVariablesMgrBase (),
	    owner (ownerPtr),
	    namesSize ( Size (names) )
	  {
	    DoInitializeValues ();
	  }
	OutputVariables (
	  OutputVariables const & object)
	  : ::nrel::gcf::OutputVariablesMgrBase (object),
	    owner (object.owner),
	    namesSize (object.namesSize)
	  {
	  }
  public:
	virtual ~OutputVariables () = 0;

	//---- operator overloads
	OutputVariables& operator= (
	  OutputVariables const & object)
	  {
	    ::nrel::gcf::OutputVariablesMgrBase::operator= (object);
	    return *this;
	  }

	//---- functions
	OwnerType & GetOwner () const		// Get owner of this
	  { return *owner; }

  protected:
	//---- constant data for output variables
	static TStringCArray names;		// variable names
	static TStringCArray descriptions;	// variable descriptions
	static TOutVarTypeCArray typeFlags;	// variable type flags
	static TVarTimeTypeCArray timeFlags;	// variable time type flags

	//---- data
	OwnerType * const owner;		// owner of this
	short const namesSize;			// size of names array
	TOutVarValueArray previousValues;	// previous output values array

	//---- functions
	void AdjustForCumulativeValues ();
	void CollectOutputFromCohort (		// Get values for a cohort
	  ::nrel::gcf::TCohort const & cohort);

  private:
	//---- data

	//---- functions
	virtual void DoInitializeValues ()
	  {
	    values.assign (namesSize, 0.0f);
	    previousValues.assign (namesSize, 0.0f);
	  }
	virtual TStringCArray & DoGetNames () const
	  { return names; }				// null-term'd array
	virtual TStringCArray & DoGetDescriptions () const
	  { return descriptions; }			// null-term'd array
	virtual TOutVarTypeCArray & DoGetVarTypeFlags () const
	  { return typeFlags; }				// "unknown" term'd
	virtual TVarTimeTypeCArray & DoGetVarTimeTypes () const
	  { return timeFlags; }

};

inline OutputVariables::~OutputVariables ()
{
}

  } // namespace dcirc

} // nrel

#endif // INC_nrel_dcirc_OutputVariables
