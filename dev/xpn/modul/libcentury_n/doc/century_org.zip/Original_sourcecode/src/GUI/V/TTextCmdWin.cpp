// ----------------------------------------------------------------------------
//	Project:  Century Model Interface - V GUI
//	File:	  TTextCmdWin.cpp
//	Class:	  TTextCmdWindow
//
//	Description:
//	Class for text editor windows.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Oct98
// ----------------------------------------------------------------------------
//	History:
//	May98	Tom Hilinski, tom.hilinski@colostate.edu
//	* Implemented "Clear" window function.
// ----------------------------------------------------------------------------
//	Copyright 1998 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TTextCmdWin.h"
#include <v/vkeys.h>
#include <v/vfontsel.h>

extern TCMIApp myApp;		// global application instance

// ----------------------------------------------------------------------------
//	Drop-down menus
// ----------------------------------------------------------------------------

vMenu TTextCmdWindow::editTextMenuDef[] =
{
  //{"&Undo", M_UnDo, notSens, notChk, "Alt+BkSp", noKey, noSub},
  //{"-", M_Line, isSens, isSens, noKeyLbl, noKey, noSub},
  //{"Cu&t", M_Cut, notSens, notChk, "Ctrl+X", 'X'-'@', noSub},
  {"&Copy", M_Copy, notSens, notChk, "Ctrl+C", 'C'-'@', noSub},
  //{"&Paste", M_Paste, notSens, notChk, "Ctrl+V", 'V'-'@', noSub},
  {"-", M_Line, isSens, notChk, noKeyLbl, noKey, noSub},
  {"C&lear", M_Clear, isSens, notChk, noKeyLbl, noKey, noSub},
  {"-", M_Line, isSens, notChk, noKeyLbl, noKey, noSub},
  {"&Find...", edFind, isSens, notChk, "Ctrl+F", 'F'-'@', noSub},
  //{"&Replace...", M_Replace, isSens, notChk, "Ctrl+R", 'R'-'@', noSub},
  {"&Next", edFindNext, isSens, notChk, "F3", vk_F3, noSub},
  {"&Go to...", edLineGoto, notSens, notChk, "Ctrl+G", 'G' - '@', noSub},
  {NULL}
};

// ----------------------------------------------------------------------------
//	Menu bar
// ----------------------------------------------------------------------------

vMenu TTextCmdWindow::textEditorMenuBarDef[] =
{
  {"&File", M_File, isSens, notChk, noKeyLbl, noKey, &fileMenuDef[0]},
  {"&Edit", M_Edit, isSens, notChk, noKeyLbl, noKey, &editTextMenuDef[0]},
  {"&Project", M_ProjectMenu, notSens, notChk, noKeyLbl, noKey,
	&projectMenuDef[0]},
  {"&Simulation", M_SimulationMenu, isSens, notChk, noKeyLbl, noKey,
	&simulationMenuDef[0]},
  {"&Results", M_ResultsMenu, isSens, notChk, noKeyLbl, noKey,
  	&resultsMenuDef[0]},
  {"&Tools", M_ToolsMenu, isSens, notChk, noKeyLbl, noKey, &toolsMenuDef[0]},
  {"&Help", M_Help, isSens, notChk, noKeyLbl, noKey, &helpMenuDef[0]},
  {NULL}
};

// ----------------------------------------------------------------------------
//	constructors and destructor
// ----------------------------------------------------------------------------

TTextCmdWindow::TTextCmdWindow (
	TCMIApp * const parentApp,		// pointer to app instance
	char const * const windowTitle)		// window title string
	: TCmdWinBase (parentApp, windowTitle),
	  textWindow (0)
{
	// add display panes (menu, tool bar, status bar, text canvas)
	vMenuPane * mainMenuPane =
		new vMenuPane ((vMenu*)textEditorMenuBarDef);
	AddPane ( mainMenuPane );	// transfer ownership
	mainMenuPane = 0;
	textWindow = new TTextWindow ( this,
					true,	// read-only
					false);	// user can close
	AddPane( textWindow );	// transfer ownership

	vFont const & defFont = theApp->GetWindowFont();
	vFont windowFont (
		// kluge: MS Windows w/size = 8, text is very, very small
		defFont.GetFamily(), 16 /* point size */,
		defFont.GetStyle(), defFont.GetWeight(), false, 0,
		std::string("Helvetica") );
	textWindow->SetFont ( windowFont );

	// show all now
	ShowWindow ();
	textWindow->ShowHScroll (1);	// horizontal scroll bar on
	// kluge to force font
	// textWindow->Resize( textWindow->GetWidth(), textWindow->GetHeight() );
}

TTextCmdWindow::~TTextCmdWindow ()
{
}

// ----------------------------------------------------------------------------
//	overridden functions
// ----------------------------------------------------------------------------

//	TTextCmdWindow::WindowCommand
//	Process the menu and toolbar selections
void TTextCmdWindow::WindowCommand (ItemVal itemId, ItemVal val, CmdType cType)
{
	switch ( itemId )
	{
	  case M_Clear:
		if ( this == myApp.historyWindow )	// do not clear
			return;
		textWindow->resetBuff ();
		textWindow->displayBuff ();
		break;
	  case M_Cut:
	  	textWindow->EditCommand (edCut, 0);
		break;
	  case M_Copy:
	  	textWindow->EditCommand (edCopy, 0);
		break;
	  case M_Paste:
		textWindow->EditCommand (edPaste, 0);
		break;
	  case M_Font:
	  {
		vFont font ( textWindow->GetFont() );
		vFontSelect fontSelector (this);
		fontSelector.FontSelect (font);
		textWindow->SetFont (font);
		break;
	  }
	  default:
		break;
	}

	// process all other events
	if (textWindow->EditCommand (itemId, 1) < 0)
		TCmdWinBase::WindowCommand (itemId, val, cType);
}

//--- end of file ---
