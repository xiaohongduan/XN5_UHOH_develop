#ifndef INC_TCmdLine_h
#define INC_TCmdLine_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2005 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCmdLine.h
//	Class:	  TCenturyCmdLine
//
//	Description:
//	Class for processing command-line arguments for the Century model.
//	For a list of command-line options, see
//	TCenturyCmdLine::cmdLineHelpMsg.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Apr98
//	History:
//	Jan99	Tom Hilinski
//	* Modified to use with the encapsulated output file classes' access
//	  modes; removed debug option for ASCII file output.
//	Jan01	Tom Hilinski
//	* Added pointer to message function, so the message display is
//	  independent of the user interface.
//	Aug01	Tom Hilinski
//	* Added check for null msgFunction pointer.
//	Oct01	Tom Hilinski
//	* Added new arg "-d4" to display sim time details.
//	* Added constructor option to suppress warning messages.
//	* Added option to require site + mgmt to be specified.
//	* Add new arg "-i filename" to get .INI file name.
//	* Removed option "-dn" which displayed default file names.
//	  These default names are now in the class TCenturyConfig.
//	Oct03	Tom Hilinski
//	* Removed DisplayCommandLine (all display is now external to the class).
//	* Uses a new base class for command-line arguments.
//	* All variables are now protected.
//	* Rewrote ProcessArguments to use new base class.
//	* File and user names are now std::string.
//	Feb04	Tom Hilinski
//	* Added command line args "-f" and "-fm".
//	* Updated the help message to describe these, and to use the
//	  version macros CenturyNickname and CenturyCommand.
//	Aug05	Tom Hilinski
//	* Now stores all info extracted from a command-line into a
//	  CenturySimConfigInfo object.
//	* Removed Get...() that duplicates the CenturySimConfigInfo object.
// ----------------------------------------------------------------------------

#include "TCmdLineBase.h"
#include "centtypes.h"
#include "TCentOFBase.h"
#include "CenturySimConfigInfo.h"

//	-----------------------------------------------------------------------
//	TCenturyCmdLine
//	Class for processing the command line arguments for Century.
class TCenturyCmdLine
	: public TCmdLineBase
{
  public:
	//--- types
	typedef nrel::century::CenturySimConfigInfo::TStringArray
		TStringArray;

	//--- data

	//--- constructors and destructor
	TCenturyCmdLine (
	  short const argc,	 		// number of arguments
	  char const * const * const argv,	// list of arguments
	  nrel::century::CenturySimConfigInfo &
	  		useSimConfigInfo,	// configuration information
	  bool suppressWarnings = false,	// suppress warning messages?
	  bool requireSiteAndMgmt = true);	// require site & mgmt options?
	TCenturyCmdLine (
	  TCenturyCmdLine const & object)
	  : TCmdLineBase (object),
	    simConfigInfo (object.simConfigInfo)
	  {
	    Copy (object);
	  }
	virtual ~TCenturyCmdLine ()
	{
	}
	virtual TCenturyCmdLine * const Clone () const	// Clone this
	  { return new TCenturyCmdLine (*this); }

	//---- operator overloads
	TCenturyCmdLine& operator= (
	  TCenturyCmdLine const & object)
	  {
	    if (this != &object)	// assigning self?
	    {
	    	TCmdLineBase::operator= (object);
		Copy (object);
	    }
	    return *this;
	  }

	//--- functions
	bool ArgError ()			// true if have an error
	  { return error; }
	bool Terminate ()			// true if should terminate
	  { return terminate; }
	char const * const GetCmdLineHelpStr ()
	  { return cmdLineHelpMsg; }
	char const * const GetCmdLineDebugHelpStr ()
	  { return cmdLineDebugHelpMsg; }

	//--- functions: Data
	std::string const & GetExePath () const
	  { return exePath; }
	std::string const & GetIniFile () const
	  { return iniFile; }
	std::string const & GetNewSiteFile () const
	  { return newSiteFile; }
#ifdef DAILY_CENTURY
	bool ProduceDailyOutput () const
	  { return doDailyOutput; }
#endif
	TDebugInfo const & GetDebugInfo () const
	  { return dbgInfo; }

  protected:
	//--- constants
	static char const * const cmdLineHelpMsg;
	static char const * const cmdLineDebugHelpMsg;
	static char const * const optionList[];

	//--- data: internal
	short countOptionsUsed;		// no. options in indexList used
	bool error;			// true if have error in argument list
	bool terminate;			// true if program should terminate
	bool displayMessages;		// true if displaying messages
	bool needSiteAndMgmt;		// true if site & mgmt options required

	//--- data: command-line
	nrel::century::CenturySimConfigInfo &
	  			simConfigInfo;	// configuration information

	std::string exePath;			// executable file path
	std::string iniFile;			// .INI file name
	std::string newSiteFile;		// new site file at end of sim.
#ifdef DAILY_CENTURY
	bool doDailyOutput;			// false if no output files
#endif
	TDebugInfo dbgInfo;			// debugging flags

	//--- functions
	virtual bool ProcessArguments ();
	void ProcessOption (
	  TArgListIterator const & beginArgList,
	  TArgListIterator const & endArgList);
	void CheckSiteName ();
	void CheckMgmtName ();
	void WriteCmdLine ();

  private:
	//--- data

	//--- functions
	void Initialize ();
	void Copy (				// Copy to this
	  TCenturyCmdLine const & object);
};

#endif // INC_TCmdLine_h
