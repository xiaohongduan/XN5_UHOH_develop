
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  respll_ncid;			/* netCDF id */

/* variable ids */
int  s11c2ll_id, s21c2ll_id, s2c2ll_id, s3c2ll_id, st1c2ll_id, st2c2ll_id, 
     mt1c2ll_id, mt2c2ll_id, wd1c2ll_id, wd2c2ll_id, wd3c2ll_id;
int  timell_id, lat_id, lon_id;

/* create resp.nc */
int
respdef_ll(int *ntimes, int *nlat, int *nlon, char *history,
           float *opltim, float *qtime) {

   int   status, istart_year, iend_year, ii;
   float fill, fstart_year, fend_year;
   char  timeunits[25], temp[5];

   /* dimension ids */
   int  time_dim = 0;
   int  lat_dim = 0;
   int  lon_dim = 0;

   /* variable shapes */
   int dims[3];

   /* Set fill, start_year, and end_year values */
   fill = NC_FILL_FLOAT;
   fstart_year = *opltim;
   fend_year = *qtime - 1;
   istart_year = fstart_year;
   iend_year = fend_year;

   for (ii = 0; ii < 25; ii++) {
     timeunits[ii] = '\0';
   }
   /* Get the start time for the time definition */
   sprintf(temp, "%d", istart_year); 
   strcat(timeunits, "days since ");
   strcat(timeunits, temp);
   strcat(timeunits, "-01-01");

   /* enter define mode */
   status = nc_create("respll.nc", NC_CLOBBER, &respll_ncid);
   if (status != NC_NOERR) handle_error("nc_create(resp.nc)", status);

   /* define dimensions */
   status = nc_def_dim(respll_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(respll_ncid, "lat", (size_t) *nlat, &lat_dim);
   status = nc_def_dim(respll_ncid, "lon", (size_t) *nlon, &lon_dim);

   /* define variables */

   dims[0] = time_dim;
   status = nc_def_var (respll_ncid, "time", NC_INT, 1, dims, &timell_id);

   dims[0] = lat_dim;
   status = nc_def_var (respll_ncid, "lat", NC_FLOAT, 1, dims, &lat_id);

   dims[0] = lon_dim;
   status = nc_def_var (respll_ncid, "lon", NC_FLOAT, 1, dims, &lon_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (respll_ncid, "s11c2", NC_FLOAT, 3, dims, &s11c2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (respll_ncid, "s21c2", NC_FLOAT, 3, dims, &s21c2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (respll_ncid, "s2c2", NC_FLOAT, 3, dims, &s2c2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (respll_ncid, "s3c2", NC_FLOAT, 3, dims, &s3c2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (respll_ncid, "st1c2", NC_FLOAT, 3, dims, &st1c2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (respll_ncid, "st2c2", NC_FLOAT, 3, dims, &st2c2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (respll_ncid, "mt1c2", NC_FLOAT, 3, dims, &mt1c2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (respll_ncid, "mt2c2", NC_FLOAT, 3, dims, &mt2c2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (respll_ncid, "wd1c2", NC_FLOAT, 3, dims, &wd1c2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (respll_ncid, "wd2c2", NC_FLOAT, 3, dims, &wd2c2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (respll_ncid, "wd3c2", NC_FLOAT, 3, dims, &wd3c2ll_id);

   /* assign attributes */
   status = nc_put_att_text (respll_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (respll_ncid, timell_id, "long_name", strlen("Time"), "Time");
   status = nc_put_att_text (respll_ncid, timell_id, "units", strlen(timeunits), timeunits);
   status = nc_put_att_text (respll_ncid, timell_id, "time_step", strlen("monthly"), "monthly");
   status = nc_put_att_text (respll_ncid, timell_id, "calendar", strlen("gregorian"), "gregorian");
   status = nc_put_att_int (respll_ncid, timell_id, "start_year", NC_INT, 1, &istart_year);
   status = nc_put_att_int (respll_ncid, timell_id, "end_year", NC_INT, 1, &iend_year);

   status = nc_put_att_text (respll_ncid, lat_id, "long_name", strlen("Latitude"), "Latitude");
   status = nc_put_att_text (respll_ncid, lat_id, "units", strlen("degrees_north"), "degrees_north");
   status = nc_put_att_text (respll_ncid, lat_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (respll_ncid, lat_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (respll_ncid, lon_id, "long_name", strlen("Longitude"), "Longitude");
   status = nc_put_att_text (respll_ncid, lon_id, "units", strlen("degrees_east"), "degrees_east");
   status = nc_put_att_text (respll_ncid, lon_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (respll_ncid, lon_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (respll_ncid, s11c2ll_id, "long_name", 
	strlen("surface_microbial_respiration"), "surface_microbial_respiration");
   status = nc_put_att_text (respll_ncid, s11c2ll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(respll_ncid, s11c2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (respll_ncid, s21c2ll_id, "long_name", 
	strlen("soil_microbial_respiration"), "soil_microbial_respiration");
   status = nc_put_att_text (respll_ncid, s21c2ll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(respll_ncid, s21c2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (respll_ncid, s2c2ll_id, "long_name", 
	strlen("som2_respiration"), "som2_respiration");
   status = nc_put_att_text (respll_ncid, s2c2ll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(respll_ncid, s2c2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (respll_ncid, s3c2ll_id, "long_name", 
	strlen("som3_respiration"), "som3_respiration");
   status = nc_put_att_text (respll_ncid, s3c2ll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(respll_ncid, s3c2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (respll_ncid, st1c2ll_id, "long_name", 
	strlen("surface_structural_respiration"), "surface_structural_respiration");
   status = nc_put_att_text (respll_ncid, st1c2ll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(respll_ncid, st1c2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (respll_ncid, st2c2ll_id, "long_name", 
	strlen("soil_structural_respiration"), "soil_structural_respiration");
   status = nc_put_att_text (respll_ncid, st2c2ll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(respll_ncid, st2c2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (respll_ncid, mt1c2ll_id, "long_name", 
	strlen("surface_metabolic_respiration"), "surface_metabolic_respiration");
   status = nc_put_att_text (respll_ncid, mt1c2ll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(respll_ncid, mt1c2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (respll_ncid, mt2c2ll_id, "long_name", 
	strlen("soil_metabolic_respiration"), "soil_metabolic_respiration");
   status = nc_put_att_text (respll_ncid, mt2c2ll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(respll_ncid, mt2c2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (respll_ncid, wd1c2ll_id, "long_name", 
	strlen("dead_fine_branch_respiration"), "dead_fine_branch_respiration");
   status = nc_put_att_text (respll_ncid, wd1c2ll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(respll_ncid, wd1c2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (respll_ncid, wd2c2ll_id, "long_name", 
	strlen("dead_large_wood_respiration"), "dead_large_wood_respiration");
   status = nc_put_att_text (respll_ncid, wd2c2ll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(respll_ncid, wd2c2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (respll_ncid, wd3c2ll_id, "long_name", 
	strlen("dead_coarse_roots_respiration"), "dead_coarse_roots_respiration");
   status = nc_put_att_text (respll_ncid, wd3c2ll_id, "units", strlen("g/m2/mo"), "g/m2/mo");
   status = nc_put_att_float(respll_ncid, wd3c2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   /* leave define mode */
   status = nc_enddef (respll_ncid);
   return 0;
}
