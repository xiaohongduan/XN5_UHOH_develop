// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  OutputVariablesByCell.cpp
//	Class:	  OutputVariablesByCell
//
//	Description:
//	Management of output variables by cell for DayCentIRC.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, April 2005
//	History: See header file.
// ----------------------------------------------------------------------------

#include "OutputVariablesByCell.h"
#include "TGridCell.h"
#include "TCenturyCellOutputMgr.h"
using namespace nrel::dcirc;

using ::nrel::gcf::TGridCell;
using ::nrel::gcf::TCohortList;
using ::nrel::gcf::TCohortListIterator;

//	CollectOutputForCell
//	Output for all biomes in cell.
void OutputVariablesByCell::CollectOutputForCell ()
{
	// get output mgr owner = grid cell
	TGridCell const & myCell =
		dynamic_cast<TGridCell const &>( owner->GetOwner() );
	Assert (&myCell != 0);

	// for each cohort in cell, collect output values
	TCohortListIterator iCL = myCell.GetCohortList().Begin();
	while ( iCL != myCell.GetCohortList().End() )
	{
		CollectOutputFromCohort (**iCL);
		++iCL;					// next cohort
	}
}

void OutputVariablesByCell::DoUpdateValues ()
{
	CollectOutputForCell ();
	AdjustForCumulativeValues ();
}


//--- end of file ---
