#ifndef INC_arraydefs_dc_h
#define INC_arraydefs_dc_h

// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model - Daily version
//	File:	  arraydefs_dc.h
//	Class:	  TCentury
//
//	Description:
//	Preprocessor macros for accessing 2-D and 3-D arrays.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Nov02
//	History:
// ----------------------------------------------------------------------------

#include "centconsts.h"

#define ds1mnr_ref(a,b)		dnps.s1mnr[(b)*NUMLAYERS + a]
#define dstrmnr_ref(a,b)	dnps.strmnr[(b)*NUMLAYERS + a]
#define dmetmnr_ref(a,b)	dnps.metmnr[(b)*NUMLAYERS + a]


#endif // INC_arraydefs_dc_h
