// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  restrp.cpp
//	Class:	  TCentury
//	Function: RestrictProduction
//
//	Description:
//	Restrict the actual production based on C/E ratios.
//	Calculate minimum, and maximum whole plant nutrient concentrations.
// ----------------------------------------------------------------------------
//	History:
//	Apr00   Tom Hilinski, tom.hilinski@colostate.edu
//	* Cleaned up code and optimized.
//	Jun01   Tom Hilinski, tom.hilinski@colostate.edu
//	* Fixed uptake of N in "otherwise..." block, per Melannie Hartman's
//	  decription of the fix.
//	Apr05	Tom Hilinski
//	* Added factor for C to biomass conversion to be passed to
//	  NutrientLimitation; code taken from DayCent4.5
// ----------------------------------------------------------------------------

#include "TCentury.h"

void TCentury::RestrictProduction (
	float const* const availableE,	// array [NUMELEM]:
	float const* const ceRatio,	// C:E ratio [2, nparts, NUMELEM]
	short const nparts,		// no. of parts (values: CPARTS, FPARTS)
	float const* const cfrac,	// array [nparts]:
	float const potenc,		// potential crop/grass/forest prod.
	float const rootImpact,		// impact of root biomass on
					//    available nutrients
	float const * const storage,	// Retranslocation E storage pool
					// array [NUMELEM]:
	float const snfxmx,		// Symbiotic N fixation maximum for
					//   crop or forest
                                        //   (gN fixed/gC new growth)
	float & cprodl,			// NPP: modified here
	float * const eprodl,		// available E: array [NUMELEM]
	float * const uptake,		// uptake: array [EPOOLS,NUMELEM]
	float & plantNfix)		// symbiotic N-fixation (gN/m2)
{
    Assert (nparts == CPARTS || nparts == FPARTS);
#define ceRatio_ref(a_1,a_2,a_3)	ceRatio[((a_3)*nparts + (a_2))*2 + a_1]
#define uptake_ref(a_1,a_2)	uptake[(a_2)*EPOOLS + a_1]

    // Reset variables to zero
    cprodl = 0.0f;
    for (short e = 0; e < site.nelem; ++e)
    {
	eprodl[e] = 0.0f;
	for (short part = 0; part < nparts; ++part)
	    elementUptake_ref (part, e) = 0.0f;
    }

    // There is no production if one of the mineral elements in not available.
    for (short e = 0; e < site.nelem; ++e)
	if ( availableE[e] <= 1.0e-4f && snfxmx == 0.0f )
	    return;

    // Initialize NPP to potential production
    cprodl = potenc;

    // Compute weighted average carbon to biomass conversion factor
    float factorCtoBiomass = 0.0f;
    if ( nparts <= 2 )				// crop/grass
    {
    	factorCtoBiomass = 2.5f;
    }
    else					// forest/savana
    {
	for (short part = 0; part < nparts; ++part)
	{
	    if ( part < 2 )
		factorCtoBiomass += cfrac[part] * 2.5;
	    else
		factorCtoBiomass += cfrac[part] * 2.0;
	}
    }

    // Calculate average E/C of whole plant (crop, grass, or tree)
    float
	// minec[NUMELEM],	// not currently used
	maxec[NUMELEM],		// maximum E:C of each element
	mineci[15],		// minimum E:C [FPARTS][NUMELEM]
	maxeci[15];		// maximum E:C [FPARTS][NUMELEM]

#define mineci_ref(a_1,a_2)	mineci[(a_2)*FPARTS + (a_1)]
#define maxeci_ref(a_1,a_2)	maxeci[(a_2)*FPARTS + (a_1)]

    for (short e = 0; e < site.nelem; ++e)
    {
	// minec[e] = 0.0f;	// not currently used
	maxec[e] = 0.0f;
	for (short part = 0; part < nparts; ++part)
	{
		Assert (ceRatio_ref (1, part, e) != 0.0f);
		Assert (ceRatio_ref (0, part, e) != 0.0f);
		mineci_ref (part, e) = 1.0f / ceRatio_ref (MAXIMUM, part, e);
		maxeci_ref (part, e) = 1.0f / ceRatio_ref (MINIMUM, part, e);
		// OLD:
		// minec[e] += cfrac[part] * mineci_ref (part, e);
		// maxec[e] += cfrac[part] * maxeci_ref (part, e);
	}
	// NEW:
	// Calculate average nutrient content based on roots and shoots only,
	// cak - 07/25/02
	// FROOT = BELOW (crop/grass)
	// LEAF = ABOVE (crop/grass)
	maxec[e] += ( cfrac[FROOT] * maxeci_ref (FROOT, e) ) +
		    ( (1.0f - cfrac[FROOT]) * maxeci_ref (LEAF, e) )  / 2.5f;
	maxec[e] *= factorCtoBiomass;
	Assert (maxec[e] > 1.0e-6f);
    }

#undef maxeci_ref
#undef mineci_ref

    // Compute the E limitation
    // available nutrients in the translocation storage.
    // Calculate soil available nutrients, based on a maximum fraction
    // (favail) and the impact of root biomass (rootImpact), adding storage.
    float eAvailable[NUMELEM];
    for (short e = 0; e < site.nelem; ++e)
	eAvailable[e] =
		fixed.favail[e] * rootImpact * availableE[e] + storage[e];
    NutrientLimitation ( nparts, cfrac, eAvailable, maxec, maxeci, mineci,
			 snfxmx, factorCtoBiomass,
			 // parameters returning values
			 cprodl, eprodl, plantNfix);

    // Calculate uptakes from all sources: storage, soil, nfix
    for (short e = 0; e < site.nelem; ++e)
    {
	float const ustorg = std::min (storage[e], eprodl[e]);

	// If storage pool contains all needed for uptake
	if (eprodl[e] <= ustorg)
	{
	    // all soil E uptake goes to storage
	    uptake_ref (ESTOR, e) = eprodl[e];
	    uptake_ref (ESOIL, e) = 0.0f;
	}
	// Otherwise, extra necessary from the soil pool
	else // if (eprodl[e] > ustorg)
	{
	    uptake_ref (ESTOR, e) = storage[e];
	    uptake_ref (ESOIL, e) = eprodl[e] - storage[e];
	    // c...subtract nfix -mdh 3/1/99
	    // I.e., soil N uptake should not include
	    // monthly symbiotic N fixation amount.
	    if ( e == N )
		uptake_ref (ESOIL, N) -= plantNfix;
	    Assert (AmountIsSignificant (availableE[e], uptake_ref (ESOIL, e)));
	}
    }
    // N fixation uptake was computed in the limitation routines
    uptake_ref (ENFIX, N) = plantNfix;

#undef ceRatio_ref
#undef uptake_ref
}

//--- end of file restrp.cpp ---
