// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  uftexture.cpp
//	Class:	  TCentury
//	Function: UpdateFromTexture
//
//	Description:
//	Updates variables and parameters based upon soil texture.
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------
//	Copyright 2000 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TCentury.h"
#include "TCenturyMath.h"

void TCentury::UpdateFromTexture ()
{
    float const clayFrac = soil->ClayFraction().WtdMean (
    			0.0f, wt.simDepth, soil->Depth(), soil->Thickness() );
    float const siltFrac = soil->SiltFraction().WtdMean (
    			0.0f, wt.simDepth, soil->Depth(), soil->Thickness() );
    float const sandFrac = soil->SandFraction().WtdMean (
    			0.0f, wt.simDepth, soil->Depth(), soil->Thickness() );

    //--- Effect of soil texture on the leaching of organic C
    leachOC->CalcTextureEffect (sandFrac);

    //--- Effect of soil texture on the microbe decomposition rate
    microbial->CalcTextureEffect (sandFrac);

    //--- Compute parameters which control decomposition of som1
    // p1co2 must be computed for surface and soil.   vek  08/91
    // Note that p1co2b(1) must equal 0 because there is no
    // soil texture effect on the surface.
    comput.p1co2[SOIL] = fixed.p1co2a[SOIL] + fixed.p1co2b[SOIL] * sandFrac;
    // Decomposition of som1 to som3 is a function of clay content
    //         vek june90
    comput.fps1s3 = fixed.ps1s3[INTCPT] + fixed.ps1s3[SLOPE] * clayFrac;
    comput.fps2s3 = fixed.ps2s3[INTCPT] + fixed.ps2s3[SLOPE] * clayFrac;
    if (fixed.texepp[0] == 1.0f)
    {
	// Calculate pparmn(2)
	// Include effect of texture; weathering factor should be per year
	fixed.pparmn[1] = 12.0f * atanf ( clayFrac + siltFrac,
					fixed.texepp[1], fixed.texepp[2],
		        		fixed.texepp[3], fixed.texepp[4] );
    }
    if (fixed.texesp[0] == 1.0f)	// psecmn(2) - Include texture effect
	fixed.psecmn[1] =
		12.0f * ( fixed.texesp[1] + fixed.texesp[2] * sandFrac );
}

//--- end of uftexture.cpp ---

