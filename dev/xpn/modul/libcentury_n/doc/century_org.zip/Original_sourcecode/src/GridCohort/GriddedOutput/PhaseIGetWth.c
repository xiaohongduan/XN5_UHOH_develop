
/*              Copyright 1998 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include "gridconst.h"
#include "netcdf.h"

/* Externally defined variables */
extern int curr_row;
extern int PhaseINcid;
extern int P_precip_id, P_mintmp_id, P_maxtmp_id;
extern float *geoglat, *geoglon;

void handle_error(char *funcname, int status);

/* Read VEMAP PhaseI weather information  */

int
getwth_(float prec[], float precnxt[], float tmin[], float tmax[],
       int *nrow, int *ncol, float *lat, float *lon, int *no_of_cols)
{
       float annprc;
       size_t start[2] = {0,0};
       size_t count[2] = {12,1};
       int cell;
       int status;
       int mth, retval;

       retval = 0;

       /* Compute latitude and longitude - assume VEMAP run */
       /* Latitude and Longitude are read from geog.nc now -mdh 9/30/99 */
/*       *lat = 48.75 - (*nrow * 0.5); */
/*       *lon = -124.25 + (*ncol * 0.5); */
       *lat = geoglat[*nrow * *no_of_cols + *ncol];
       *lon = geoglon[*nrow * *no_of_cols + *ncol];

       /* Compute cell number to access */
       /* Use calculated no_of_cols instead of MAXE (-mdh 11-11-98) */
/*       cell = (*nrow * MAXE) + *ncol; */
       cell = (*nrow * *no_of_cols) + *ncol;
       start[1] = cell;

/*       fprintf(stdout, "getwth: no_of_cols = %1d\n", *no_of_cols);
       fprintf(stdout, "getwth: nrow = %1d\n", *nrow);
       fprintf(stdout, "getwth: ncol = %1d\n", *ncol);
       fprintf(stdout, "getwth: cell = %1d\n", cell); */

       fprintf(stdout, "getwth: lat = %5.2f\n", *lat);
       fprintf(stdout, "getwth: lon = %5.2f\n", *lon);

       /* Retrieve the climate data for the cell */
       status = nc_get_vara_float(PhaseINcid, P_precip_id, start, count, prec);
       if (status != NC_NOERR) handle_error("nc_get_vara_float(prec-PhaseIgetWth)", status);
       status = nc_get_vara_float(PhaseINcid, P_mintmp_id, start, count, tmin);
       if (status != NC_NOERR) handle_error("nc_get_vara_float(tmin-PhaseIgetWth)", status);
       status = nc_get_vara_float(PhaseINcid, P_maxtmp_id, start, count, tmax);
       if (status != NC_NOERR) handle_error("nc_get_vara_float(tmax-PhaseIgetWth)", status);

       /* Compute annual precipitation and scale input */
       annprc = 0.0;
       for (mth=0; mth<12; mth++)
       {
              /* Precip comes in as mm change to cm */
              prec[mth] = prec[mth] / 10.0;
              precnxt[mth] = prec[mth];
              annprc += prec[mth];
              tmin[mth] = tmin[mth] / 10.0;
              tmax[mth] = tmax[mth] / 10.0;

              /* Are the values reasonable */
              if (tmin[mth] < -998 ||
                  tmax[mth] < -998 ||
                  prec[mth] < 0) retval = 2;

/*       printf("tmin[%1d] = %f\n", mth, tmin[mth]);
       printf("tmax[%1d] = %f\n", mth, tmax[mth]);
       printf("prec[%1d] = %f\n", mth, prec[mth]); */

       }

       /* Is the precipitation reasonable? */
       if (annprc <= 0.0) retval = 2;

/*       if (retval > 0) fprintf(stderr, "Error in PhaseIGetWth\n"); */
       return retval;
}
