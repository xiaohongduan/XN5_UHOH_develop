// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  leafa.cpp
//	Class:	  TDayCent
//	Function: FractionLeafAllocation
//
//	Description:
//      Compute the fraction of production going to fine roots in crops,
//      grasses, and woody plants based on water and nutrient availability.
// ----------------------------------------------------------------------------
//      Sep00   Melannie Hartman, melannie@nrel.colostate.edu
//      * Created this function for the Dynamic Carbon Allocation
//        (FORTRAN/C) version of DayCent
//      May01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Translated leafa.f to leafa.cpp
// ----------------------------------------------------------------------------
//	Copyright 2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//      Notes:
//      * Should we use theoretical maximum for LAI?
//        tlai = maxlai * rlwodc / (klai + rlwodc) instead of lai? -mdh 5/11/01
// ----------------------------------------------------------------------------

#include "TDayCent.h"

float TDayCent::FractionLeafAllocation(
    float const rleavc,			// tree leaf carbon (g m-2)
    float const rlwodc,			// tree large wood carbon (g m-2)
    float const cprodfLeftToAllocate,	// C still available to allocate (g m-2)
    float const cprodf)			// potential C production
    					//   for all tree parts (g m-2)
{
    Assert (rleavc >= 0.0f);
    Assert (rlwodc >= 0.0f);
    Assert (cprodfLeftToAllocate >= 0.0f);
    Assert (cprodf > 0.0f);

    float const leafCOptimal =
    	canopy.BiomassFromLAI ( canopy.LAI (rleavc, rlwodc) );

    float leafProdOptimal;	// leaf production required to reach optimal LAI
    if (leafCOptimal > rleavc)
    {
        // if possible, increase leaf biomass so that optimum is reached
        leafProdOptimal =
        	std::min( leafCOptimal - rleavc,
        		  cprodfLeftToAllocate );
    }
    else
    {
        // optimum leaf area has already been acheived
        leafProdOptimal = 0.0f;
    }

    Assert (cprodf != 0.0f);
    float const leafa = leafProdOptimal / cprodf;
    Assert (leafa >= 0.0f);
    Assert (leafa <= 1.0f);
    return leafa;
}
