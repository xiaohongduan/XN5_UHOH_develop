// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  rtimp.cpp
//	Class:	  TCenturyBase
//	Function: RootImpactOnNutrients
//
//	Description:
//	Calculates a value between 0-1 which is the impact of root biomass on
//	available nutrients.  It is used in the calculation of total plant
// 	production in RESTRP and SRESTRP.
// ----------------------------------------------------------------------------
//	History:
//	Nov02	Tom Hilinski, tom.hilinski@colostate.edu
//	* Moved into base class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include <cmath>

// inline
MY_TEMPLATE_DECLARATION
float TCENTURYBASE::RootImpactOnNutrients (
	float const rootC) 	// root biomass C (g m-2)
{
    float rootImpact = fixed.rictrl * rootC;
    // Check added to handle underflow potential in exp intrinsic
    // if (rootImpact <= 33.0f)    std::exp(33* -2.5) = 1.48e-36!
    if (rootImpact < 7.0f)
	rootImpact = 1.0f - fixed.riint * std::exp( -2.5  * rootImpact );
    else
	rootImpact = 1.0f;
    // should be a normalized fraction
    Assert (rootImpact >= 0.0f);
    Assert (rootImpact <= 1.0f);
    return rootImpact;
}

//--- end of file ---

