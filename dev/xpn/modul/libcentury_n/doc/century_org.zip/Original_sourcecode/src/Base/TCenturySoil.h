#ifndef INC_TCenturySoil_h
#define INC_TCenturySoil_h
// ----------------------------------------------------------------------------
//	Copyright 1999-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCenturySoil.h
//	Class:	  TCenturySoil
//
//	Description:
//	Derived from TSoilBase, implements Century-specific functions.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Dec99
//	History:
//	Aug2000	Tom Hilinski
//	* Added exponential distribution of C using Newton's Method to
//	  find the parameters for the distribution.
//	* Moved the geometric distribution of C from class TSoil to here.
//	Dec2000	Tom Hilinski
//	* Rewrote class using the new soil classes.
//	Nov01	Tom Hilinski
//	* Removed constant "toOMPC"; replaced with conversion functions in
//	  class TSoilBase.
//	* Add components for mineral N, P, S pools.
//	* Changed function name GetAmtTrans to GetWaterTransferred.
//	Jul02	Tom Hilinski
//	* Gave it a virtual destructor for inheritance.
//	* Made SetNumLayers public.
//	* Added const versions of access functions.
//	Nov02   Tom Hilinski
//	* Added the typedefs T1DFloatArray, T1DDoubleArray.
//	Feb03	Tom Hilinski
//	* Made a derived class of TSubModelBase, and modified the constructor.
//	Aug03	Tom Hilinski
//	* Moved MineralN, P, S and their index variables to class TMCSoil.
//	Apr04	Tom Hilinski
//	* Added missing const versions of access functions for pool and
//	  property arrays (e.g., BulkDensity() ).
//	Apr05	Tom Hilinski
//	* Added GetPlantExtractableWCF over depth range.
// ----------------------------------------------------------------------------
//	Notes:
//	The following soil components are used in this class:
//
//		    Pool or
//	Component:  Property:	Description:
//	----------  ---------	-------------------------------------------
//	bulkDen	    property	bulk density (kg/liter or g cm-3)
//	sand	    property	fraction of sand-sized fraction
//	silt	    property	fraction of silt-sized fraction
//	clay	    property	fraction of clay-sized fraction
//	wiltPt 	    property	wilting point of layers (volumn fraction)
//	fldCap	    property	field capacity of layers (volumn fraction)
//	waterCm	    pool	water content (cm) of each layer
//	ompc	    property	organic matter, percent
//
//	Component indexing is the order in which components were added
//	to the component list (TSoilBase::CompList()), as follows:

//  	index	component	Where created:		Type:
//	------- --------------- ----------------------- --------
//	0	bulk density	ReadSiteParameters	property
//	1	sand fraction	ReadSiteParameters	property
//	2	silt fraction	ReadSiteParameters	property
//	3	clay fraction	ReadSiteParameters	property
//	4	wilting point	ReadSiteParameters	property
//	5	field capacity	ReadSiteParameters 	property
//	6	water content   ReadSiteParameters	pool
//	7	SOM wt %	ReadSiteParameters 	property
// ----------------------------------------------------------------------------

#include "TSubModelBase.h"
#include "CenturySubmodelBase.h"
#include "TSoilBase.h"
#include "TSoilCDis.h"
#include "NSUnits.h"
#include "arraytypes.h"			// array typdefs
#include <iterator>

#define DBG_CENTURY_SOIL 1	// write soil array values to debug file
#undef DBG_CENTURY_SOIL		// no debug file
#if !defined(NDEBUG) && defined(DBG_CENTURY_SOIL)
  #include <fstream>
#else
  #undef DBG_CENTURY_SOIL
#endif

//	NSSoilErrors
//	Values for error conditions in the class TSoilBase.
//	This extends the namespace in the base class TSoilBase.
namespace NSSoilErrors
{
    enum ValuesCentury
    {
	  NoSolutionC =		// 14 = no solution to C Distribution attempt
	    UnknownError + 1,
	  BadSolutionC,		// 15 = invalid solution to C Distribution
	  BadSWFlag		// 16 = invalid flag sent to CalcWPandFC
    };
    extern std::string const errorMsgCentury[BadSWFlag + 1];
}

class TCenturySoil
	: public nrel::eco::TSubModelBase,
	  public CenturySubmodelBase,
	  public TSoilBase
{
  public:
	//--- types

	//--- constructors and destructor
	TCenturySoil (
	  nrel::eco::TEcosystemModelBase const & useOwner);	// owner = model
	TCenturySoil (
	  nrel::eco::TEcosystemModelBase const & useOwner,	// owner = model
	  size_type const useNumLayers);	// initial number of layers
	virtual ~TCenturySoil ()
	  {
	  }
	TCenturySoil (
	  TCenturySoil const & object);

	//--- operator overloads
	TCenturySoil& operator = (
	  TCenturySoil const & object);

	//--- Data Access functions
	void SetNumLayers (			// Set number of layers
	  size_type const useNumLayers);
	bool UseThicknesses (			// Thicknesses of layers
	  TFloatArray const & useThicknesses);	//   container of thicknesses
							//--- data vectors
	TSoilProperty& BulkDensity ()			// Bulk Density (g cm-3)
	  { return static_cast<TSoilProperty&>(
	    *compList[indexBulkDensity]); }
	TSoilProperty const & BulkDensity () const	// Bulk Density (g cm-3)
	  { return static_cast<TSoilProperty&>(
	    *compList[indexBulkDensity]); }
	TSoilProperty& SandFraction ()			// Sand Fraction
	  { return static_cast<TSoilProperty&>(
	    *compList[indexSandFraction]); }
	TSoilProperty const & SandFraction () const	// Sand Fraction
	  { return static_cast<TSoilProperty&>(
	    *compList[indexSandFraction]); }
	TSoilProperty const & SiltFraction () const	// Silt Fraction
	  { return static_cast<TSoilProperty&>(
	    *compList[indexSiltFraction]); }
	TSoilProperty& SiltFraction ()			// Silt Fraction
	  { return static_cast<TSoilProperty&>(
	    *compList[indexSiltFraction]); }
	TSoilProperty& ClayFraction ()			// Clay Fraction
	  { return static_cast<TSoilProperty&>(
	    *compList[indexClayFraction]); }
	TSoilProperty const & ClayFraction () const	// Clay Fraction
	  { return static_cast<TSoilProperty&>(
	    *compList[indexClayFraction]); }
	TSoilProperty& WiltingPoint ()			// Wilting Point
	  { return static_cast<TSoilProperty&>(
	    *compList[indexWiltingPoint]); }
	TSoilProperty const & WiltingPoint () const	// Wilting Point
	  { return static_cast<TSoilProperty&>(
	    *compList[indexWiltingPoint]); }
	TSoilProperty& FieldCapacity ()			// Field Capacity
	  { return static_cast<TSoilProperty&>(
	    *compList[indexFieldCapacity]); }
	TSoilProperty const & FieldCapacity () const	// Field Capacity
	  { return static_cast<TSoilProperty&>(
	    *compList[indexFieldCapacity]); }
	TSoilPool& WaterContent ()			// Water Content (cm)
	  { return static_cast<TSoilPool&>(
	    *compList[indexWaterContent]); }
	TSoilPool const & WaterContent () const		// Water Content (cm)
	  { return static_cast<TSoilPool&>(
	    *compList[indexWaterContent]); }
	TSoilProperty& OMPC ()				// Organic matter %
	  { return static_cast<TSoilProperty&>(
	    *compList[indexOMPC]); }
	TSoilProperty const & OMPC () const		// Organic matter %
	  { return static_cast<TSoilProperty&>(
	    *compList[indexOMPC]); }
							//--- data elements
	float& BulkDensity (				// Bulk Density (g cm-3)
	  size_type const layerIndex)			//   index to layer
	  { return CompValue(indexBulkDensity,layerIndex); }
	float const & BulkDensity (			// Bulk Density (g cm-3)
	  size_type const layerIndex) const		//   index to layer
	  { return CompValue(indexBulkDensity,layerIndex); }
	float& SandFraction (				// Sand Fraction
	  size_type const layerIndex)			//   index to layer
	  { return CompValue(indexSandFraction,layerIndex); }
	float const & SandFraction (			// Sand Fraction
	  size_type const layerIndex) const		//   index to layer
	  { return CompValue(indexSandFraction,layerIndex); }
	float& SiltFraction (				// Silt Fraction
	  size_type const layerIndex)			//   index to layer
	  { return CompValue(indexSiltFraction,layerIndex); }
	float const & SiltFraction (			// Silt Fraction
	  size_type const layerIndex) const		//   index to layer
	  { return CompValue(indexSiltFraction,layerIndex); }
	float& ClayFraction (				// Clay Fraction
	  size_type const layerIndex)			//   index to layer
	  { return CompValue(indexClayFraction,layerIndex); }
	float const & ClayFraction (			// Clay Fraction
	  size_type const layerIndex) const		//   index to layer
	  { return CompValue(indexClayFraction,layerIndex); }
	float& WiltingPoint (				// Wilting Point
	  size_type const layerIndex)			//   index to layer
	  { return CompValue(indexWiltingPoint,layerIndex); }
	float const & WiltingPoint (			// Wilting Point
	  size_type const layerIndex) const		//   index to layer
	  { return CompValue(indexWiltingPoint,layerIndex); }
	float& FieldCapacity (				// Field Capacity
	  size_type const layerIndex)			//   index to layer
	  { return CompValue(indexFieldCapacity,layerIndex); }
	float const & FieldCapacity (			// Field Capacity
	  size_type const layerIndex) const		//   index to layer
	  { return CompValue(indexFieldCapacity,layerIndex); }
	float& WaterContent (				// Water Content (cm)
	  size_type const layerIndex)			//   index to layer
	  { return CompValue(indexWaterContent,layerIndex); }
	float const & WaterContent (			// Water Content (cm)
	  size_type const layerIndex) const		//   index to layer
	  { return CompValue(indexWaterContent,layerIndex); }
	float& OMPC (					// Organic matter %
	  size_type const layerIndex)			//   index to layer
	  { return CompValue(indexOMPC,layerIndex); }
	float const & OMPC (				// Organic matter %
	  size_type const layerIndex) const		//   index to layer
	  { return CompValue(indexOMPC,layerIndex); }

	//--- soil water submodel functions
	void CalcWPandFC (			// Set wilting pt. & field cap.
	  short const swflag);			//   flag: 0-6
	void SetFractions (			// Set fractions for runoff
	  float const useBaseFlowFrac,		//   base flow fraction
	  float const useStormFlowFrac);	//   storm flow fraction
	float GetBaseFlowFraction () const	// Get base flow fraction
	  { return baseFlowFraction; }
	float GetStormFlowFraction () const	// Get storm flow fraction
	  { return stormFlowFraction; }
	void ApplyWaterToSurface (		// Run bucket model.
	  float const amount);			//   cm of water
	float const GetWaterTransferred (	// Amt. transferred down
	  size_type const layerIndex)		//   layer index (zero-based)
	  { return amtTrans(layerIndex); }
	float GetBaseFlow () const		// Get base flow amount
	  { return baseFlow; }
	float GetStormFlow () const		// Get storm flow amount
	  { return stormFlow; }
	float GetDeepSoilStorage () const	// Get deep soil storage amount
	  { return deepSoilStore; }

	float GetPlantExtractableWCF (		// Get plant-extractable H2O
	  size_type const layerIndex);		//   layer index (zero-based)
	float GetPlantExtractableWCF (		// Get plant-extractable H2O
	  float const topDepth,			//   top depth of range
	  float const bottomDepth);		//   bottom depth of range

	float FieldCapacityQuantity (		// Field capacities amount (cm)
	  float const topDepth,			//   top depth of range
	  float const bottomDepth);		//   bottom depth of range
	float FieldCapacityQuantity (		// Field capacities amount (cm)
	  size_type const topLayerIndex,	//   top layer of range
	  size_type const bottomLayerIndex); 	//   bottom layer of range

	float MeanPlantWaterCapacity (	// avg. plant-extractable capacity (cm)
	  float const topDepth,
	  float const bottomDepth);
	float MeanPlantWaterCapacity (	// avg. plant-extractable capacity (cm)
	  size_type const topLayerIndex,
	  size_type const bottomLayerIndex);

	float PlantWaterCapacityAmt (	// plant-extractable capacity (cm)
	  float const topDepth,
	  float const bottomDepth);
	float PlantWaterCapacityAmt (	// plant-extractable capacity (cm)
	  size_type const topLayerIndex,
	  size_type const bottomLayerIndex);

	float PlantExtractableWater (		// plant-extractable water (cm)
	  float const topDepth,
	  float const bottomDepth);
	float PlantExtractableWater (		// plant-extractable water (cm)
	  size_type const topLayerIndex,
	  size_type const bottomLayerIndex);

	//--- Geometric C distribution submodel functions
	void GeometricOMPC (			// Calc OMPC with 0.85 factor
	  float const totalC);			//   Total OMPC surface layer
						//--- Exponential depth dist.

	//--- Exponential C distribution submodel functions
	void ExponentialOMPC (			// Calc OMPC exponential dist.
	  float const cSimLayer,		//   sim. layer C (g m-2)
	  float const cLowerLayer,		//   lower layer C (g m-2)
	  float const simThickness,		//   sim. layer thickness (cm)
	  float const llThickness);		//   lower layer thickness (cm)
	bool GetExpDistribution (		// Returns C dist. parameters.
	  float& newK,				//   K (cm-1)
	  float& newCTopDen,			//   C at surface (g cm-3)
	  float& newCBottomDen);		//   C at bottom (g cm-3)
	float GetCDensity (			// Get the C density (g cm-3)
	  size_type const layer);		//   in this layer index
	float GetProfileC () const		// C total for profile (g m-2)
	  { return cProfileTotal * NSUnits_cm2m2; }
	float GetCAmount (			// C total for depth range
	  float const topDepth,			//   depth to top (cm)
	  float const bottomDepth		//   depth to bottom (cm)
	  ) const
	  { return minimalCDist->LayerAmt (
		topDepth, bottomDepth, k, cTopDensity, cBottomDensity) *
		NSUnits_cm2m2;
	  }

	//--- Misc. C content functions
	void UpdateBulkDensityFromC ();		// Update the bulk density
						//   from new organic C content

	//--- misc. functions
	void Clear ();				// "clear" and delete data
	virtual TCenturySoil * const Clone () const		// Clone this
	  { return new TCenturySoil (*this); }

	//--- debug functions
#ifdef DBG_CENTURY_SOIL

	virtual void Homogenize (		// Homogenize these layers
	  size_type const topLayerIndex,	//   index of top layer
	  size_type const bottomLayerIndex)	//   index of bottom layer
	  {
	    DEBUG_DumpSoil ("Homogenize() start");
	    TSoilBase::Homogenize (topLayerIndex, bottomLayerIndex);
	    DEBUG_DumpSoil ("Homogenize() end");
	  }
	virtual void Homogenize (		// Homogenize this depth range
	  float const topDepth,			//   top depth
	  float const bottomDepth)		//   bottom depth
	  {
	    DEBUG_DumpSoil ("Homogenize() start");
	    TSoilBase::Homogenize (topDepth, bottomDepth);
	    DEBUG_DumpSoil ("Homogenize() end");
	  }

#endif // DBG_CENTURY_SOIL

  protected:
	//--- constants
	static float const ompcGeomFactor;	// OMPC geometric decrease
	static size_type const			// component indices
		indexBulkDensity,		//   property
		indexSandFraction,		//   property
		indexSiltFraction,		//   property
		indexClayFraction,		//   property
		indexWiltingPoint,		//   property
		indexFieldCapacity,		//   property
		indexWaterContent,		//   pool
		indexOMPC;			//   property

	//--- data for soil water submodel
	T1DFloatArray amtTrans;		// Amount transfered between
					//   layers last time step (cm)
	float baseFlowFraction;		// Fraction to base flow (const)
	float stormFlowFraction;	// Fraction to storm flow (const)
	float deepSoilStore;		// pool for deep soil storage
	float baseFlow;			// pool to hold base flow
	float stormFlow;		// pool to hold storm flow

	//--- data for Exponential C distribution submodel
	float cProfileTotal;		// total C in profile (g cm-2)
	float k;			// K - scaling constant (cm-1)
	float cTopDensity;		// C sim layer density (g cm-3)
	float cBottomDensity;		// C lower layer min. density (g cm-3)
	// a distribution instance for access to the distribution functions.
	std::auto_ptr<TSoilCDistribution> minimalCDist;

	//--- functions

  private:
	//--- functions
	void Initialize ();				// initialize members
	void Copy (TCenturySoil const & fromObj);	// copy to this

	//---- functions: Virtual
	virtual void DoResetDaily ()
	  {
	  }
	virtual void DoResetMonthly ()
	  {
	    if ( amtTrans.size() != thickness.size() )
		amtTrans.resize ( thickness.size() );
	    amtTrans = 0.0f;
	    baseFlow = stormFlow = deepSoilStore = 0.0f;
	  }
	virtual void DoResetAnnual ()
	  {
	  }
	// These are currently unused.
	virtual bool DoInitializeSubmodel ()	// Initialize the submodel
						//   Return false if successful
	  {
	    state = TModelState::State_Initialized;
	    return false;
	  }
	virtual bool DoRunIteration ()		// Run submodel one iteration
						//   Return true if can continue
	  {
	    state = TModelState::State_Running;
	    return !state.IsError();
	  }
	virtual TState DoPauseRun ()		// Pause submodel run
	  {
	    return TModelState::State_Paused;
	  }
	virtual TState DoTerminateSubmodel ()	// Terminate submodel run
	  {
	    return TModelState::State_Terminated;
	  }

	// --------------------------------------------------------------------
	// Debugging
	// --------------------------------------------------------------------
#ifdef DBG_CENTURY_SOIL
	std::ofstream dbgOFS;
	void DEBUG_DumpSoil (char const * const calledFrom);
	friend class TCentury;
  public:
  	// from Century
	short dbg_nlaypg;
	float dbg_rootDepth;
  private:
#endif
};

#endif // INC_TCenturySoil_h
