
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */


#include <stdlib.h>
#include "netcdf.h"
#include "wrtcdf.h"

void
wrtime_(float *time)
{
        int status;
	static size_t	tstart={0};
	size_t 		tcount={1};

	status = nc_put_vara_float(site_ncid, time_id, &tstart, &tcount, time);
	tstart += 1;

	return;
}
