
/*              Copyright 1993 Colorado State University     */
/*                      All Rights Reserved                  */

#include <string.h>
#include "netcdf.h"

/* Global Variables */
int  soilnll_ncid;			/* netCDF id */

/* variable ids */
int  som1n1ll_id, som1n2ll_id, som2nll_id, som3nll_id, strucn1ll_id, 
     strucn2ll_id, metabn1ll_id, metabn2ll_id;
int  timell_id, lat_id, lon_id;

/* create soiln.nc */
int
soilndef_ll(int *ntimes, int *nlat, int *nlon, char *history,
            float *opltim, float *qtime) {

   int   status, istart_year, iend_year, ii;
   float fill, fstart_year, fend_year;
   char  timeunits[25], temp[5];

   /* dimension ids */
   int  time_dim = 0;
   int  lat_dim = 0;
   int  lon_dim = 0;

   /* variable shapes */
   int dims[3];

   /* Set fill, start_year, and end_year values */
   fill = NC_FILL_FLOAT;
   fstart_year = *opltim;
   fend_year = *qtime - 1;
   istart_year = fstart_year;
   iend_year = fend_year;

   for (ii = 0; ii < 25; ii++) {
     timeunits[ii] = '\0';
   }
   /* Get the start time for the time definition */
   sprintf(temp, "%d", istart_year); 
   strcat(timeunits, "days since ");
   strcat(timeunits, temp);
   strcat(timeunits, "-01-01");

   /* enter define mode */
   status = nc_create("soilnll.nc", NC_CLOBBER, &soilnll_ncid);
   if (status != NC_NOERR) handle_error("nc_create(soiln.nc)", status);

   /* define dimensions */
   status = nc_def_dim(soilnll_ncid, "time", (size_t) *ntimes, &time_dim);
   status = nc_def_dim(soilnll_ncid, "lat", (size_t) *nlat, &lat_dim);
   status = nc_def_dim(soilnll_ncid, "lon", (size_t) *nlon, &lon_dim);

   /* define variables */

   dims[0] = time_dim;
   status = nc_def_var (soilnll_ncid, "time", NC_INT, 1, dims, &timell_id);

   dims[0] = lat_dim;
   status = nc_def_var (soilnll_ncid, "lat", NC_FLOAT, 1, dims, &lat_id);

   dims[0] = lon_dim;
   status = nc_def_var (soilnll_ncid, "lon", NC_FLOAT, 1, dims, &lon_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilnll_ncid, "som1n1", NC_FLOAT, 3, dims, &som1n1ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilnll_ncid, "som1n2", NC_FLOAT, 3, dims, &som1n2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilnll_ncid, "som2n", NC_FLOAT, 3, dims, &som2nll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilnll_ncid, "som3n", NC_FLOAT, 3, dims, &som3nll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilnll_ncid, "strucn1", NC_FLOAT, 3, dims, &strucn1ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilnll_ncid, "strucn2", NC_FLOAT, 3, dims, &strucn2ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilnll_ncid, "metabn1", NC_FLOAT, 3, dims, &metabn1ll_id);

   dims[0] = time_dim;
   dims[1] = lat_dim;
   dims[2] = lon_dim;
   status = nc_def_var (soilnll_ncid, "metabn2", NC_FLOAT, 3, dims, &metabn2ll_id);

   /* assign attributes */
   status = nc_put_att_text (soilnll_ncid, NC_GLOBAL, "history", strlen(history), history);

   status = nc_put_att_text (soilnll_ncid, timell_id, "long_name", strlen("Time"), "Time");
   status = nc_put_att_text (soilnll_ncid, timell_id, "units", strlen(timeunits), timeunits);
   status = nc_put_att_text (soilnll_ncid, timell_id, "time_step", strlen("monthly"), "monthly");
   status = nc_put_att_text (soilnll_ncid, timell_id, "calendar", strlen("gregorian"), "gregorian");
   status = nc_put_att_int (soilnll_ncid, timell_id, "start_year", NC_INT, 1, &istart_year);
   status = nc_put_att_int (soilnll_ncid, timell_id, "end_year", NC_INT, 1, &iend_year);

   status = nc_put_att_text (soilnll_ncid, lat_id, "long_name", strlen("Latitude"), "Latitude");
   status = nc_put_att_text (soilnll_ncid, lat_id, "units", strlen("degrees_north"), "degrees_north");
   status = nc_put_att_text (soilnll_ncid, lat_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (soilnll_ncid, lat_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (soilnll_ncid, lon_id, "long_name", strlen("Longitude"), "Longitude");
   status = nc_put_att_text (soilnll_ncid, lon_id, "units", strlen("degrees_east"), "degrees_east");
   status = nc_put_att_text (soilnll_ncid, lon_id, "point_spacing", strlen("even"), "even");
   status = nc_put_att_text (soilnll_ncid, lon_id, "grid_interval", strlen("0.1 degree"), "0.1 degree");

   status = nc_put_att_text (soilnll_ncid, som1n1ll_id, "long_name", 
	strlen("surface_microbial_nitrogen"), "surface_microbial_nitrogen");
   status = nc_put_att_text (soilnll_ncid, som1n1ll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilnll_ncid, som1n1ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilnll_ncid, som1n2ll_id, "long_name", 
	strlen("soil_microbial_nitrogen"), "soil_microbial_nitrogen");
   status = nc_put_att_text (soilnll_ncid, som1n2ll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilnll_ncid, som1n2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilnll_ncid, som2nll_id, "long_name", 
	strlen("som2_nitrogen"), "som2_nitrogen");
   status = nc_put_att_text (soilnll_ncid, som2nll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilnll_ncid, som2nll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilnll_ncid, som3nll_id, "long_name", 
	strlen("som3_nitrogen"), "som3_nitrogen");
   status = nc_put_att_text (soilnll_ncid, som3nll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilnll_ncid, som3nll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilnll_ncid, strucn1ll_id, "long_name", 
	strlen("surface_structural_nitrogen"), "surface_structural_nitrogen");
   status = nc_put_att_text (soilnll_ncid, strucn1ll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilnll_ncid, strucn1ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilnll_ncid, strucn2ll_id, "long_name", 
	strlen("soil_structural_nitrogen"), "soil_structural_nitrogen");
   status = nc_put_att_text (soilnll_ncid, strucn2ll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilnll_ncid, strucn2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilnll_ncid, metabn1ll_id, "long_name", 
	strlen("surface_metabolic_nitrogen"), "surface_metabolic_nitrogen");
   status = nc_put_att_text (soilnll_ncid, metabn1ll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilnll_ncid, metabn1ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   status = nc_put_att_text (soilnll_ncid, metabn2ll_id, "long_name", 
	strlen("soil_metabolic_nitrogen"), "soil_metabolic_nitrogen");
   status = nc_put_att_text (soilnll_ncid, metabn2ll_id, "units", strlen("g/m2"), "g/m2");
   status = nc_put_att_float(soilnll_ncid, metabn2ll_id, "_FillValue", NC_FLOAT, 1, &fill);

   /* leave define mode */
   status = nc_enddef (soilnll_ncid);
   return 0;
}
