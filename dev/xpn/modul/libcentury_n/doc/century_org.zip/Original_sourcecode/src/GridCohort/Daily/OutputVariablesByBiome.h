#ifndef INC_nrel_dcirc_OutputVariablesByBiome
#define INC_nrel_dcirc_OutputVariablesByBiome

// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC-Daily Century coupling
//	File:	  OutputVariablesByBiome.h
//	Class:	  OutputVariablesByBiome
//
//	Description:
//	Management of output variables by biome for DayCentIRC.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, April 2005
//	History:
//	<date, eg., 22May01>	<your name>, <your e-mail address>
//	<description>
// ----------------------------------------------------------------------------

#include "OutputVariables.h"
#include "ContainerIndex.h"

namespace nrel
{
  namespace dcirc	// DayCentIRC
  {

class OutputVariablesByBiome
	: public OutputVariables
{
  public:
	//---- types

	//---- constructors and destructor
	OutputVariablesByBiome (
	  OwnerType * const ownerPtr)		// ptr to object owning this
	  : OutputVariables (ownerPtr)
	  {
	  }
	OutputVariablesByBiome (
	  OutputVariablesByBiome const & object)
	  : OutputVariables (object)
	  {
	  }
	~OutputVariablesByBiome ()
	  {
	  }

	//---- operator overloads

	//---- functions

  protected:
	//---- data

	//---- functions
	void CollectOutputByBiome ();		// Output for biomes separately

  private:
	//---- data

	//---- functions
	virtual void DoUpdateValues ();

};

  } // namespace dcirc
} // nrel

#endif // INC_nrel_dcirc_OutputVariablesByBiome
