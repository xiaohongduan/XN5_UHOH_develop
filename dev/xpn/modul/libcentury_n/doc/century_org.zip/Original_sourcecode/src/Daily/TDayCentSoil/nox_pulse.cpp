// ----------------------------------------------------------------------------
//    Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//    Project:  Century Soil Organic Matter Model, daily version
//    File:	nox_pulse.cpp
//    Class:	none
//    Function: NOxPulse
//
//    Description:
//    Compute the multiplier NOx flux based on recent rain events and snowpack
// ----------------------------------------------------------------------------
//    Author: Melannie Hartman, Steve Del Grosso
//    History:
//    ??????  Melannie Hartman, melannie@NREL.colostate.edu
//    * Created original denitrify.c for FORTRAN/C version of DayCent
//    Apr2001	 Melannie Hartman, melannie@NREL.colostate.edu
//    * Translated nox_pulse.c to nox_pulse.cpp
//	Dec02   Tom Hilinski, tom.hilinski@colostate.edu
//	* Misc. clean up, const-correctness, optimization.
// ----------------------------------------------------------------------------

#include "TDayCentSoil.h"
#include "AssertEx.h"
#include <cmath>

//    max3
//    return the maximum of the 3 arguments
inline
float max3 (float const a, float const b, float const c)
{
    float m;
    if (a > b && a > c)
	m = a;
    else if (b > c)
	m = b;
    else
	m = c;
    return m;
}

//	InitializeNOxPulseModel
//	Initialize variables used in the soil NOX pulse submodel.
void TDayCentSoil::InitializeNOxPulseModel ()
{
	cumppt.resize (PPTDAYS);	cumppt = 0.0f;
	pl.resize (PLDAYS);		pl = 1.0f;
	pm.resize (PMDAYS);		pm = 1.0f;
	ph.resize (PHDAYS);		ph = 1.0f;
	mtplr.resize (PHDAYS);		mtplr = 1.0f;
	npl = npm = nph = nppt = mptr = 0;
	noxPulseTag = 0;

	Assert ( cumppt.size() > 0 );
	Assert ( pl.size() > 0 );
	Assert ( pm.size() > 0 );
	Assert ( ph.size() > 0 );
	Assert ( mtplr.size() > 0 );
}

//	CopyNOxPulseModel
//	Copy Nox pulse model data into this.
void TDayCentSoil::CopyNOxPulseModel (
	const TDayCentSoil& fromObj)
{
	if ( &fromObj && fromObj.GetLayerCount() > 0 )
	{
		cumppt = fromObj.cumppt;
		pl = fromObj.pl;
		pm = fromObj.pm;
		ph = fromObj.ph;
		mtplr = fromObj.mtplr;
		npl = fromObj.npl;
		npm = fromObj.npm;
		nph = fromObj.nph;
		nppt = fromObj.nppt;
		mptr = fromObj.mptr;
		noxPulseTag = fromObj.noxPulseTag;
	}
}

//	CheckNOxPulseValues
//	Check the NOx pulse submodel data for validity
//	Return true if failed check.
bool TDayCentSoil::CheckNOxPulseValues ()
{
	bool failed = false;				// return value

	// To Do: add if checks for these for when assertions are off.

	Assert ( cumppt.size() == PPTDAYS );
	Assert ( pl.size() == PLDAYS );
	Assert ( pm.size() == PMDAYS );
	Assert ( ph.size() == PHDAYS );
	Assert ( mtplr.size() == PHDAYS );

	return failed;
}

//	NOxPulse
//	Calculates the NOx pulse based upon precip.
//	Returns a NOx pulse factor.
float TDayCentSoil::NOxPulse (
    float const ppt,    // the current day's precipitation (cm)
    float const snow)   // snow pack on the ground (cm SWE)
{
    // These static vars are now protected members of TDayCentSoil. -mdh 2/14/02
    // static float cumppt[PPTDAYS) = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    // static float pl[PLDAYS] = {1,1};
    // static float pm[PMDAYS] = {1,1,1,1,1,1};
    // static float ph[PHDAYS] = {1,1,1,1,1,1,1,1,1,1,1,1};
    // static float mtplr[PHDAYS] = {1,1,1,1,1,1,1,1,1,1,1,1,1};
    // static int npl=0, npm=0, nph=0, nppt=0, mptr=0;
    // static int noxPulseTag=0;

    float noxPulse = 0.0f;			// return value

    CheckNOxPulseValues ();

    cumppt(nppt) = ppt;
    float sumppt = 0.0f;
    for (int i = 1; i < PPTDAYS; i++)
	sumppt += cumppt( (nppt+i) % PPTDAYS );

    if (snow)
    {
	mtplr(mptr) = 0.0f;
    }
    else if (sumppt <= 1.0f && ppt > 0.1f)
    {
	//  initiate new pulse
	if (ppt < 0.5f)
        {
            for (int i = 0; i < PLDAYS; i++)
		pl( (npl+i) % PLDAYS ) = 11.19f * std::exp(-0.805f * (i+1));
	    noxPulseTag = 2;
       }
       else if (ppt >= 0.5f && ppt <= 1.5f)
       {
	   for (int i=0; i < PMDAYS; i++)
	       pm( (npm+i) % PMDAYS ) = 14.68f * std::exp(-0.384f * (1.0f + i));
	   noxPulseTag = 6;
       }
       else
       {
	   for (int i = 0; i < PHDAYS; i++)
	       ph( (nph+i) % PHDAYS ) = 18.46f * std::exp(-0.208f * (i+1));
	   noxPulseTag = 13;
       }

       mtplr(mptr) = max3 ( pl(npl), pm(npm), ph(nph) );
       --noxPulseTag;
    }
    else if (noxPulseTag > 0)
    {
	mtplr(mptr) = max3 ( pl(npl), pm(npm), ph(nph) );
        noxPulseTag--;
    }
    else
    {
	mtplr(mptr) = 1.0f;
    }

    noxPulse = mtplr(mptr);
    pl(npl) = 1.0f;
    pm(npm) = 1.0f;
    ph(nph) = 1.0f;

    // increment pointers in circular arrays
    npl = (npl+1) % PLDAYS;
    npm = (npm+1) % PMDAYS;
    nph = (nph+1) % PHDAYS;
    nppt = (nppt+1) % PPTDAYS;
    mptr = (mptr+1) % PHDAYS;

    Assert (noxPulse >= 0.0f);
    return noxPulse;
}

//--- end of file ---
