// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TSoilCDis.cpp
//	Class:	  TSoilCDistribution
//
//	Description:
//	Models the depth distribution of soil C as an exponential function.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Dec00
// ----------------------------------------------------------------------------
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TSoilCDis.h"
#include "precision.h"
#include <limits>
using namespace std;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// Multiplier for C density at 1/2 profile depth
float const TSoilCDistribution::halfDepthDensityFactor = 0.10f;
// Factor to multiply lower layer C density by to get the minimum den.
float const TSoilCDistribution::minDenLLDenFactor = 0.10f;
// Factor to multiply simulation layer density by to get max. density
float const TSoilCDistribution::maxDenSLDenFactor = 1.5f;
// Depth at which to calc the max. depth in the root finder (cm)
float const TSoilCDistribution::maxDenDepthRoot = 5.0f;

// ----------------------------------------------------------------------------
//	constructors and destructor
// ----------------------------------------------------------------------------

//	Construct using Century's simulation and lower layer
//	C densities.
TSoilCDistribution::TSoilCDistribution (
	float const useMaxDepth,		// maximum soil depth (cm)
	float const useCProfileTotal,		// profile C total (g cm-2)
	float const useSimLayerDensity,		// sim. layer density (g cm-3)
	float const useLowerLayerDensity)	// lower layer density (g cm-3)
	: maxDepth (useMaxDepth),
	  cProfileTotal (useCProfileTotal),
	  cSimLayerDensity (useSimLayerDensity),
	  cLowerLayerDensity (useLowerLayerDensity)
{
	Assert (cProfileTotal > 0.0f);
	Assert (cSimLayerDensity > 0.0f);
	Assert (cLowerLayerDensity > 0.0f);

	cTopDensity = useSimLayerDensity * maxDenSLDenFactor;
	cBottomDensity = useLowerLayerDensity * minDenLLDenFactor;
	//Assert (cTopDensity > cBottomDensity);

	lastError = NoSolution;
	if ( cTopDensity > cBottomDensity )
	{
		kSC = K (cTopDensity, cBottomDensity);
		FindTheRoots ();
	}
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	GetDistribution
//	Retrieves the parameters of the distribution.
//	Returns false if no error else true if an error occurred.
bool TSoilCDistribution::GetDistribution (
	float& theK,	// K (cm-1)
	float& C0,   	// C density at surface (g cm-3)
	float& Cb)	// C density at bottom (g cm-3)
{
	bool retVal = false;
	if ( lastError == NoError )
	{
		theK = kSC;
		C0 = cTopDensity;
		Cb = cBottomDensity;
	}
	else
		retVal = true;
	return retVal;
}

//	LayerAmt
//      Returns the C amount in a depth range (g cm-2)
float TSoilCDistribution::LayerAmt (
	float const zTop,	// depth at top (cm, >= 0)
	float const zBottom	// depth at bottom (cm, > 0))
	) const
{
	Assert (zTop < zBottom);
	Assert (zTop >= 0.0f);
	Assert (zBottom > 0.0f);
	Assert (cTopDensity >= cBottomDensity);

	if ( lastError != NoError )			// anything to do?
		return 0.0f;				// ...no
	else if (zTop >= zBottom || zTop < 0.0f || zBottom <= 0.0f)
		return 0.0f;
	else
		return (std::exp (-kSC * zTop) - std::exp (-kSC * zBottom)) *
			(cTopDensity - cBottomDensity) / kSC +
			(zBottom - zTop) * cBottomDensity;
}

//	LayerAmt
//      Returns the C amount in a depth range (g cm-2) using the parameters
//	provided, rather than the calculated parameters.
float TSoilCDistribution::LayerAmt (
	float const zTop,		// depth at top (cm, >= 0)
	float const zBottom,		// depth at bottom (cm, > 0))
	float const theK,		// exponential scaling constant (cm-1)
	float const C0,			// C density at surface (g cm-3)
	float const Cb			// C density at profile bottom (g cm-3)
	) const
{
	Assert (zTop < zBottom);
	Assert (zTop >= 0.0f);
	Assert (zBottom > 0.0f);
	Assert (C0 > 0.0f);
	Assert (Cb >= 0.0f);
	if ( C0 < Cb && AmountIsSignificant(C0-Cb, 0.01f) )
		Assert (C0 >= Cb);

	if (zTop >= zBottom || zTop < 0.0f || zBottom <= 0.0f)
		return 0.0f;
	else
		return	(std::exp (-theK * zTop) - std::exp (-theK * zBottom)) *
			(C0 - Cb) / theK +
			(zBottom - zTop) * Cb;
}

//	CProfileSum
//	C amount in the entire profile (g cm-2).
float TSoilCDistribution::CProfileSum () const
{
	Assert (maxDepth > 0.0f);
	Assert (kSC != 0.0f);
	if ( lastError != NoError )			// anything to do?
		return 0.0f;				// ...no
	else
		return (1.0f - std::exp (-kSC * maxDepth)) *
			(cTopDensity - cBottomDensity) / kSC +
			(maxDepth * cBottomDensity);
}

//	CProfileSum
//	C amount in the entire profile (g cm-2).
float TSoilCDistribution::CProfileSum (
	float const theK,		// exponential scaling constant (cm-1)
	float const C0,			// C density at surface (g cm-3)
	float const Cb			// C density at profile bottom (g cm-3)
	) const
{
	Assert (theK != 0.0f);
	//Assert (C0 > 0.0f);
	//Assert (Cb > 0.0f);
	//Assert (C0 > Cb);
	Assert (maxDepth > 0.0f);
	return	(1.0f - std::exp (-theK * maxDepth)) *
		(C0 - Cb) / theK +
		(maxDepth * Cb);
;
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	K
//	Evaluate K for C = 0.1*C0 at z = 1/2 profile depth.
//	K = (-2.0 / maxDepth) * ln ( (0.1 * C0 - Cb) / (C0 - Cb) )
float TSoilCDistribution::K (
	float const C0,			// C density at surface (g cm-3)
	float const Cb			// C density at profile bottom (g cm-3)
	) const
{
	Assert (C0 > 0.0f);
	Assert (Cb > 0.0f);
	Assert (C0 - Cb > 0.0f);
	Assert (maxDepth > 0.0f);

	float const Ch = Cb + halfDepthDensityFactor * (C0 - Cb); // half depth
	return -2.0f / maxDepth * log ( (Ch - Cb) / (C0 - Cb) );
}

//	FindTheRoots
void TSoilCDistribution::FindTheRoots ()
{
	lastError = NoError;
	Assert (kSC > 0.0f);

	// Assume the end points of the distribution, C0 and Cb, are ok.
	// Find the K that provides the proper area under the curve, ie.,
	// the calc'd total profile C matches the data profile C.
	// Total C is inversely proportional to K.

	float newTotalC = CProfileSum ();		// total C calc
	float dK = kSC * 0.05;				// delta K
	if ( newTotalC < cProfileTotal )
		dK = -dK;				// want to decrease

	// decrease K stepwise until total C values are close
	float const threshold = 0.05f;
//	float const threshold =
//		std::fabs ((newTotalC - cProfileTotal) / newTotalC) * 0.05f;
	while ( !::AreClose (newTotalC, cProfileTotal, threshold) )
	{
	    kSC += dK;
	    if ( kSC != 0.0f )
	    {
		newTotalC = CProfileSum ();
		// Check if skipped over correct value range:
		// 1. too large?
		if ( dK < 0.0f &&
		     newTotalC > cProfileTotal &&
		     !::AreClose (newTotalC, cProfileTotal, threshold) )
		{
			dK = -dK * 0.5;	// reverse and decrease step size
		}
		// 2. too small?
		else if ( dK > 0.0f &&
			  newTotalC < cProfileTotal &&
			  !::AreClose (newTotalC, cProfileTotal, threshold) )
		{
			dK = -dK * 0.5;	// reverse and decrease step size
		}
	    }
	}
}


// --- end of file ---
