// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  TNcFileErosion.cpp
//	Class:	  TNcErosionFile
//
//	Description:
//	Class for I/O of the netCDF file for the TErosion and TDeposition
//	classes. Derived from the class TNcFile.
//	File can be both read from and written to in the same instance.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Jan99
// ----------------------------------------------------------------------------
//	History:
//	ddMMMyy	<who>, <email>
//	<description>
// ----------------------------------------------------------------------------
//	Copyright 1999 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Notes:
//	Erosion data file contains the amounts eroded from
//	5 elements in 5 below-ground pools:
//	Pools = active, slow, passive, metabolic, structural
//	Elements = unlabeled C, labeled C, N, P, S
//	The variables are by element, with each array index by pool:
//	e.g., N(1) = active pool N, N(2) = slow pool N, etc.
// ----------------------------------------------------------------------------

#include "TNcFileErosion.h"
#include "TDepEroBase.h"
#include "charutil.h"
#include "timeutil.h"
#include "AssertEx.h"

//--- constructors and destructor

TNcErosionFile::TNcErosionFile (	// Constructor for creating file:
	TEH::TFileName const & file,	//   name of erosion file
	char const* useUserName,	//   user's name
	char const* useMgmtDesc,	//   management description
	char const* useMgmtFile,	//   management file name
	char const* useSiteDesc,	//   site description
	char const* useSiteFile)	//   site file name
	: nrel::io::TIOSourceSinkBase (Type_Output, Access_WriteOnly),
	  TNcFile (file, NCFT_ErosionOutput),
	  userName (useUserName),
	  mgmtDesc (useMgmtDesc),
	  mgmtFile (useMgmtFile),
	  siteDesc (useSiteDesc),
	  siteFile (useSiteFile)
{
	Initialize ();
	try
	{
		Create ();
	}
	catch (char const* msgStr)
	{
		throw msgStr;
	}
}

TNcErosionFile::TNcErosionFile (		// Constructor for reading file:
	TEH::TFileName const & file)		//   name of erosion file
	: nrel::io::TIOSourceSinkBase (Type_Output, Access_WriteOnly),
	  TNcFile (file, NCFT_ErosionOutput)
{
	Initialize ();
	OpenNcFile (NcFile::ReadOnly);
}


//--- public functions

//	Create
//	Creates a new file.
//	Returns if successful, else throws exception if error.
void TNcErosionFile::Create ()
{
	//bool retVal = false;			// return value
	bool r;					// return from functions
	register unsigned short i;		// loop index

	//--- dimension names
	const unsigned short numDims = 2;
	char const* dimNames[numDims] =
	{
		"numRec", "numPools"
	};
	const long numPools = EPT_NumPools;	// numPools dimension size
	NcDim* dim[numDims];			// pointers to dimensions

	//--- variable names
	char const* varNames[] =
	{
		"time",
		"thickness", "bulkDensity", "sand", "silt", "clay",
		"unlabeledC", "labeledC", "N", "P", "S"
	};
	const unsigned short numOutVars = 	// no. output variables
			6 + (short)EE_NumElements;
	Assert (numOutVars == 11);
	NcVar* ncVars[numOutVars];		// netCDF output variables
	register unsigned short k = 0;		// index to variables

	//--- attribute names
	char const* attNames[] =
	{
		"title", "SimDescription", "MgmtFile", "SiteFile", "SiteDesc",
		"LastModifiedWho", "LastModifiedWhen",
		"FileType", "Version"
	};
	char const* titleAttr = 		// title attribute
	 		"Century erosion data";
	// Modify the version when the structure of this file changes
	const long versionNumber = 1;

	//--- initialize error handling
	NcError ncErr (NcError::silent_nonfatal);	// error handler
	char const* locStr = NULL;    			// error location
	ncErrStr = NULL;

#define ChkErr(r,s) \
	if ( r && ncErr.get_err() != NC_NOERR ) \
	{ \
		ncErrStr = (char const *)::nc_strerror ( ncErr.get_err() ); \
		locStr=s; goto error_done; \
	}

	//--- create the file
	NcFile::FileMode accessMode;		// access mode
	if ( ncFileName.Exists() )
		accessMode = NcFile::Replace;
	else
		accessMode = NcFile::New;
	if ( OpenNcFile (accessMode) )		// open the file
		return;				// ...problem!
	NcFile *fp = ncFile;			// local pointer to file

	//--- add the dimensions
	dim[0] = fp->add_dim(dimNames[0]);	// unlimited dimension
	ChkErr(true, dimNames[0])
	dim[1] = fp->add_dim(dimNames[1], numPools);
	ChkErr(true, dimNames[1])

	//--- add the variables
	// time
	ncVars[k] = fp->add_var(varNames[k], ncFloat, dim[0]);
	ChkErr(true, varNames[k])
	// physical variables - thickness; bulk den.; sand, silt, clay frac.
	for ( i = 0; i < 5; ++i )
	{
		++k;
		ncVars[k] = fp->add_var(varNames[k], ncFloat, dim[0]);
		ChkErr(true, varNames[k])
	}
	// C and element pools
	for ( i = 0; i < (short)EE_NumElements; i++ )
	{
		++k;
		ncVars[k] = fp->add_var(varNames[k], ncFloat, dim[0], dim[1]);
		ChkErr(true, varNames[k])
	}

	//--- add the global attributes
	k = 0;					// index to attribute names
	r = fp->add_att (attNames[k], titleAttr);	// title
	ChkErr(r, attNames[k])
	{ // limit scope of variable str and emptyStr
		char const* emptyStr = "";
		char const* str;

		if ( mgmtDesc )			// simulation description
			str = mgmtDesc;
		else
			str = emptyStr;
		r = fp->add_att (attNames[++k], str );
		ChkErr(r, attNames[k])
		if ( mgmtFile )			// management file name
			str = mgmtFile;
		else
			str = emptyStr;
		r = fp->add_att (attNames[++k], str );
		ChkErr(r, attNames[k])
		if ( siteFile )			// site file name
			str = siteFile;
		else
			str = emptyStr;
		r = fp->add_att (attNames[++k], str );
		ChkErr(r, attNames[k])
		if ( siteDesc )			// site description
			str = siteDesc;
		else
			str = emptyStr;
		r = fp->add_att (attNames[++k], str );
		ChkErr(r, attNames[k])
		if ( userName && *userName )	// user's name
			str = userName;
		else
			str = "none specified";
		r = fp->add_att (attNames[++k], str);
		ChkErr(r, attNames[k])
	}
						// date/time of creation
	char str[20];
	strcpy ( str, ::DateTimeStr().c_str() );
	r = fp->add_att (attNames[++k], str );
	ChkErr(r, attNames[k])
						// Century file type
	r = fp->add_att (attNames[++k], (long)NCFT_ErosionOutput );
	ChkErr(r, attNames[k])
						// netCDF file version number
	r = fp->add_att (attNames[++k], versionNumber );
	ChkErr(r, attNames[k])
	goto all_done;

error_done:
	{
	CloseNcFile ();
	// handle error
	char* lastErrMsg;		// last error message issued
	const char *intro =
			"Error creating netCDF output file.\n"
			"NetCDF error: ";
	const char *msgPart = "\nwhile creating ";
	lastErrMsg = new char [strlen(intro) + strlen(ncErrStr) +
			       strlen(msgPart) + strlen(locStr) + 1];
	 strcpy (lastErrMsg, intro);
	 strcat (lastErrMsg, ncErrStr);
	 strcat (lastErrMsg, msgPart);
	 strcat (lastErrMsg, locStr);
	 ncErrStr = lastErrMsg;
	 throw ncErrStr;
	 }

all_done:
	TNcFile::Clear ();	// close since access mode will change
	return;
}

//	ReadAbout
//	Read the descriptive attibutes.
//	Returns false if successful, else true if not or if error.
//	Notes:
//	The pointers are owned by the calling function, and so must
//	be deleted by the calling function.
//	Assumes the arguments point to NULL upon entry.
bool TNcErosionFile::ReadAbout (
	char*& title,		//   title of file
	char*& simDesc,		//   simulation description
	char*& mgmtFile,	//   management file name
	char*& siteFile,	//   site file name
	char*& siteDesc,	//   site description
	char*& whoMod,		//   who modified this file
	char*& whenMod)		//   modified date
{
	if ( ncErrStr )			// already have error message?
		return true;		// ...yes

	bool retVal = true;			// return value
	if ( IsFileOpen (NcFile::ReadOnly) )	// open the netCDF file
	{
		GetAtts (ncFile);

		//--- retrieve attributes
		// assumes the attributes are in the same order as the
		// function argument list
		register short k = 0;			// index to variables
		title    = GetOneStrAttribute (k);
		simDesc  = GetOneStrAttribute (++k);
		mgmtFile = GetOneStrAttribute (++k);
		siteFile = GetOneStrAttribute (++k);
		siteDesc = GetOneStrAttribute (++k);
		whoMod   = GetOneStrAttribute (++k);
		whenMod  = GetOneStrAttribute (++k);

	    error_handler:				// check for errors
		SetNcErrStr ();
		retVal = ncErrFlag;
	}
	return retVal;
}

//	GetOneStrAttribute
//	Retrieves the values for one string attribute.
//	Returns the pointer to the string.
//	The pointers are owned by the calling function, and so must
//	be deleted by the calling function.
//	Does not do any error checks on the netCDF file; leave that for
//	the calling function.
char* TNcErosionFile::GetOneStrAttribute (short const which)
{
	char* tp;			// return value pointer
	char str [1024];		// work string
	register short len;		// string length
	tp = a[which]->as_string (0);	// title
	if ( tp && *tp )
	{
		strcpy (str, tp);
		::strtrim (str);
		len = static_cast<short>(strlen (str));
		tp = new char [len + 1];
		strcpy (tp, str);
	}
	return tp;
}

//	ReadRecord
// 	Reads the next record from the erosion netCDF file.
//	Returns false if successful, else true if not or if error.
bool TNcErosionFile::ReadRecord (
	float& simTime,		// simulation time (years w/fraction)
	float& thickness,	// thickness eroded (cm)
	float& bulkDen,		// bulk density (g/cm^3)
	float& sand,		// fraction of sand-sized particles
	float& silt,		// fraction of silt-sized particles
	float& clay,		// fraction of clay-sized particles
	float* data)		// float (&data)[EE_NumElements][EPT_NumPools])
{
	if ( ncErrStr )			// already have error message?
		return true;		// ...yes

	bool retVal = true;			// return value
	if ( IsFileOpen (NcFile::ReadOnly) )	// open the netCDF file
	{
		GetVars (ncFile);		// get pointers to variables
		GetDims (ncFile);		// get dimensions
		float* pData = data;		// pointer to data array
		register short k = 0;		// index to variables

							// sim. time
		v[k].v->set_cur (curRecRd);
		if ( !v[k].v->get (&simTime, 1) )
			goto error_handler;
							// thickness
		v[++k].v->set_cur (curRecRd);
		if ( !v[k].v->get (&thickness, 1) )
			goto error_handler;
							// bulk density
		v[++k].v->set_cur (curRecRd);
		if ( !v[k].v->get (&bulkDen, 1) )
			goto error_handler;
							// sand frac.
		v[++k].v->set_cur (curRecRd);
		if ( !v[k].v->get (&sand, 1) )
			goto error_handler;
							// silt frac.
		v[++k].v->set_cur (curRecRd);
		if ( !v[k].v->get (&silt, 1) )
			goto error_handler;
							// clay frac.
		v[++k].v->set_cur (curRecRd);
		if ( !v[k].v->get (&clay, 1) )
			goto error_handler;
							// unlabeled C
		v[++k].v->set_cur (curRecRd, 0);
		if ( !v[k].v->get (pData, 1, EPT_NumPools) )
			goto error_handler;
							// labeled C
		pData += EPT_NumPools;
		v[++k].v->set_cur (curRecRd, 0);
		if ( !v[k].v->get (pData, 1, EPT_NumPools) )
			goto error_handler;
							// N
		pData += EPT_NumPools;
		v[++k].v->set_cur (curRecRd, 0);
		if ( !v[k].v->get (pData, 1, EPT_NumPools) )
			goto error_handler;
							// P
		pData += EPT_NumPools;
		v[++k].v->set_cur (curRecRd, 0);
		if ( !v[k].v->get (pData, 1, EPT_NumPools) )
			goto error_handler;
							// S
		pData += EPT_NumPools;
		v[++k].v->set_cur (curRecRd, 0);
		if ( !v[k].v->get (pData, 1, EPT_NumPools) )
			goto error_handler;

	    error_handler:				// check for errors
		SetNcErrStr ();
		retVal = ncErrFlag;
		if ( !retVal )				// successful?
			++curRecRd;			// ...to next record
	}
	return retVal;
}

//	WriteRecord
// 	Writes the next record to the erosion netCDF file.
//	Returns false if successful, else true if not or if error.
bool TNcErosionFile::WriteRecord (
	float const simTime,   	// simulation time (years w/fraction)
	float const thickness,	// thickness eroded (cm)
	float const bulkDen,	// bulk density (g/cm^3)
	float const sand,	// fraction of sand-sized particles
	float const silt,	// fraction of silt-sized particles
	float const clay,	// fraction of clay-sized particles
	float const* data)	// float (&data)[EE_NumElements][EPT_NumPools])
{
	bool retVal;				// return value
	if ( IsFileOpen (NcFile::Write) )	// open the netCDF file
	{
	    GetVars (ncFile);	    		// get pointers to variables
	    GetDims (ncFile);	    		// get dimensions
	    float const* pData = data;		// pointer to data array
	    register short k = 0;		// index to variables

		// Write variable values
	    curRecWr = ncFile->rec_dim()->size();	// get record number
							// simulation time
	    if (!v[k].v->put_rec (const_cast<float*>(&simTime), curRecWr))
		goto error_handler;
							// erosion thickness
	    if (!v[++k].v->put_rec (const_cast<float*>(&thickness), curRecWr))
		goto error_handler;
							// bulk density
	    if (!v[++k].v->put_rec (const_cast<float*>(&bulkDen), curRecWr))
		goto error_handler;
							// sand fraction
	    if (!v[++k].v->put_rec (const_cast<float*>(&sand), curRecWr))
		goto error_handler;
							// silt fraction
	    if (!v[++k].v->put_rec (const_cast<float*>(&silt), curRecWr))
		goto error_handler;
							// clay fraction
	    if (!v[++k].v->put_rec (const_cast<float*>(&clay), curRecWr))
		goto error_handler;
							// unlabeled C
	    if (!v[++k].v->put_rec (pData, curRecWr) )
		goto error_handler;
							// labeled C
	    pData += EPT_NumPools;
	    if (!v[++k].v->put_rec (pData, curRecWr) )
		goto error_handler;
							// N
	    pData += EPT_NumPools;
	    if (!v[++k].v->put_rec (pData, curRecWr) )
		goto error_handler;
							// P
	    pData += EPT_NumPools;
	    if (!v[++k].v->put_rec (pData, curRecWr) )
		goto error_handler;
							// S
	    pData += EPT_NumPools;
	    if (!v[++k].v->put_rec (pData, curRecWr) )
		goto error_handler;

	    error_handler:			// check for errors
		//ncFile->sync ();		// flush buffer to disk
		SetNcErrStr ();
		retVal = ncErrFlag;
	}
	else	// not open
	{
		// To Do: need error handling for write to not-open file
		retVal = true;
	}
	return retVal;
}

//	SetRecordRead
//	Set the record number for the next read from the file.
//	Returns the previous record number.
long TNcErosionFile::SetRecordRead (
	const long recordNumber)
{
	long prevRecNum = curRecRd;
	if ( recordNumber >= 0 )
		curRecRd = recordNumber;
	return prevRecNum;
}

//	SetRecordWrite
//	Set the record number for the next write to the file.
//	Returns the previous record number.
long TNcErosionFile::SetRecordWrite (
	const long recordNumber)
{
	long prevRecNum = curRecWr;
	if ( recordNumber >= 0 )
		curRecWr = recordNumber;
	return prevRecNum;
}

//	GetRecordCount
//	Returns the number of time-step records,
//	or -1 if file access failed.
long TNcErosionFile::GetRecordCount ()
{
	bool openedHere = false;		// opened file here?
	if ( !isOpen )				// if not open, open the file
	{
		if ( OpenNcFile (NcFile::ReadOnly) )
		{
			CloseNcFile ();
			return -1;				// ...failed
		}
		else
			openedHere = true;			// ...opened
	}
	long numRecords;					// record count
	if ( ncFile && ncFile->is_valid() )			// file open?
		numRecords =  ncFile->rec_dim()->size();	// ...get count
	else
		numRecords = -1;				// ...failed
	if ( openedHere )
		CloseNcFile ();
	return numRecords;			// all done!
}


//--- private functions

//	IsFileOpen
//	Returns true if file is open for access as specified, else
//	false if not, or false if access mode is other than read or write.
bool TNcErosionFile::IsFileOpen (
	const NcFile::FileMode accessMode)	// NcFile::ReadOnly or Write
{
	bool retVal = false;
	if ( accessMode == NcFile::ReadOnly ||
	     accessMode == NcFile::Write    ||
	     accessMode == NcFile::Replace  )
	{
		// is file not open or has access mode changed?
		if ( !isOpen || accessMode != curAccMode )
		{
			if ( !OpenNcFile (accessMode) )		// open file
			{
				curAccMode = accessMode;	// ...save
				retVal = true;			// ...opened!
			}
		}
		else
			retVal = true;
	}
	return retVal;
}

//---	end of T_NcFileErosion.cpp ---//
