// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  initll.cpp
//	Class:	  TCenturyBase
//	Function: InitializeLowerLayer
//
//	Description:
//	Initialize the lower simulation soil layer's C and element pools.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Nov98
// ----------------------------------------------------------------------------
//	History:
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Updated to work with the new physical soil and C depth distribution.
//	Oct02	Tom Hilinski
//	* Moved into class TCenturyBase from class TCentury.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "TDepEroBase.h"

MY_TEMPLATE_DECLARATION
void  TCENTURYBASE::InitializeLowerLayer ()
{
	//--- error checks
	Assert (soil.get());
	Assert (wt.simDepth >= fixed.edepth);
	if ( soil->SoilDepth() == wt.simDepth )		// any soil to use here?
		return;					// ...no

	//--- class initialization
	lowerSoil.reset (
		new TLowerSoil (fixed.edepth, TCENTURYBASE::MAXSIMDEPTH) );

	//--- initialize the lower soil layer class
	lowerSoil->SetSoil (soil.get());

	//--- the C and element pools (units = density = g cm-3)
	float poolsC[sizeC], poolsE[sizeE];
	float *pC = poolsC, *pE= poolsE;
	for ( short i = 0; i < sizeC; ++i )
		*(pC++) = 0.0f;
	for ( short i = 0; i < sizeE; ++i )
		*(pE++) = 0.0f;

#define poolsC_ref(pool_,_isotope_)	(poolsC[(pool_) * ISOS + (_isotope_)])
#define poolsE_ref(pool_,element_)	(poolsE[(pool_) * NUMELEM + (element_)])

	// check for site-supplied values for each;
	// if not present, use default fraction from the fixed parameter set.
	// (because of different array structures, cannot use loop here)
	// Note: minPoolAmt defined in TDepEroBase.h
	// These initialization assignments check if the site parameter is
	// above the minimum threshold value. If so, the site parameter is
	// used. If not, the fixed parameter fraction * the sim. layer SOM
	// is used.

	// Calculation of amounts:
	// Pools are
	// (1) amounts = g m-2 in a 20 cm depth of upper soil (initially),
	// provided from the simulation layer pools.
	// To convert to density (g cm-3):
	//     density = pool (g/(m2 cm) * 20 cm) * (1 m2/1e4 cm2) / 20 cm
	// Conversion constant:
	register float const convertFactor1 = 1.0e-4f / fixed.edepth;

	// (2) amounts = g m-2 in a 180 cm thickness of lower soil
	// provided from the site parameters for initial lower layer pools.
	// To convert to density (g cm-3):
	//     density = pool (g/(m2 cm) * 180 cm) * (1 m2/1e4 cm2) / 180 cm
	// Conversion constant:
	Assert (lowerSoil->Thickness() > 0.0f);
	register float const convertFactor2 = 1.0e-4f / lowerSoil->Thickness();

	//--- 1. unlabeled C
	if ( site.lhiCU[ACTIVE] > NSDepEro_poolMinThreshold )
	    poolsC_ref(ACTIVE, UNLABL) = site.lhiCU[ACTIVE] * convertFactor2;
	else
	    poolsC_ref(ACTIVE, UNLABL) =
		som1ci_ref(SOIL, UNLABL) * fixed.lhzf[ACTIVE] * convertFactor1;
	if ( site.lhiCU[SLOW] > NSDepEro_poolMinThreshold )
	    poolsC_ref(SLOW, UNLABL) = site.lhiCU[SLOW] * convertFactor2;
	else
	    poolsC_ref(SLOW, UNLABL) =
		soilC.som2ci[UNLABL] * fixed.lhzf[SLOW] * convertFactor1;
	if ( site.lhiCU[PASSIVE] > NSDepEro_poolMinThreshold )
	    poolsC_ref(PASSIVE, UNLABL) = site.lhiCU[PASSIVE] * convertFactor2;
	else
	    poolsC_ref(PASSIVE, UNLABL) =
	 	soilC.som3ci[UNLABL] * fixed.lhzf[PASSIVE] * convertFactor1;
	//--- 2. labeled C
	if ( site.lhiCL[ACTIVE] > NSDepEro_poolMinThreshold )
	    poolsC_ref(ACTIVE, LABELD) = site.lhiCL[ACTIVE] * convertFactor2;
	else
	    poolsC_ref(ACTIVE, LABELD) =
	    	som1ci_ref(SOIL, LABELD) * fixed.lhzf[ACTIVE] * convertFactor1;
	if ( site.lhiCL[SLOW] > NSDepEro_poolMinThreshold )
	    poolsC_ref(SLOW, LABELD) = site.lhiCL[SLOW] * convertFactor2;
	else
	    poolsC_ref(SLOW, LABELD) =
	    	soilC.som2ci[LABELD] * fixed.lhzf[SLOW] * convertFactor1;
	if ( site.lhiCL[PASSIVE] > NSDepEro_poolMinThreshold )
	    poolsC_ref(PASSIVE, LABELD) = site.lhiCL[PASSIVE] * convertFactor2;
	else
	    poolsC_ref(PASSIVE, LABELD) =
		soilC.som3ci[LABELD] * fixed.lhzf[PASSIVE] * convertFactor1;
	//--- 3. N
	if ( site.lhiN[ACTIVE] > NSDepEro_poolMinThreshold )
	    poolsE_ref(ACTIVE, N) = site.lhiN[ACTIVE] * convertFactor2;
	else
	    poolsE_ref(ACTIVE, N) =
		som1e_ref(SOIL, N) * fixed.lhzf[ACTIVE] * convertFactor1;
	if ( site.lhiN[SLOW] > NSDepEro_poolMinThreshold )
	    poolsE_ref(SLOW, N) = site.lhiN[SLOW] * convertFactor2;
	else
	    poolsE_ref(SLOW, N) =
	    	nps.som2e[N] * fixed.lhzf[SLOW] * convertFactor1;
	if ( site.lhiN[PASSIVE] > NSDepEro_poolMinThreshold )
	    poolsE_ref(PASSIVE, N) = site.lhiN[PASSIVE] * convertFactor2;
	else
	    poolsE_ref(PASSIVE, N) =
	    	nps.som3e[N] * fixed.lhzf[PASSIVE] * convertFactor1;

    //--- 4. P - only do if using P in this simulation
    if ( SimPhosphorous() )
    {
	if ( site.lhiP[PASSIVE] > NSDepEro_poolMinThreshold )
	    poolsE_ref(ACTIVE, P) = site.lhiP[ACTIVE] * convertFactor2;
	else
	    poolsE_ref(ACTIVE, P) =
		som1e_ref(SOIL, P) * fixed.lhzf[ACTIVE] * convertFactor1;
	if ( site.lhiP[PASSIVE] > NSDepEro_poolMinThreshold )
	    poolsE_ref(SLOW, P) = site.lhiP[SLOW] * convertFactor2;
	else
	    poolsE_ref(SLOW, P) =
	    	nps.som2e[P] * fixed.lhzf[SLOW] * convertFactor1;
	if ( site.lhiP[PASSIVE] > NSDepEro_poolMinThreshold )
	    poolsE_ref(PASSIVE, P) = site.lhiP[PASSIVE] * convertFactor2;
	else
	    poolsE_ref(PASSIVE, P) =
	    	nps.som3e[P] * fixed.lhzf[PASSIVE] * convertFactor1;
    }

    //--- 5. S - only do if using P and S in this simulation
    if ( SimSulfur() )
    {
	if ( site.lhiS[ACTIVE] > NSDepEro_poolMinThreshold )
	    poolsE_ref(ACTIVE, S) = site.lhiS[ACTIVE] * convertFactor2;
	else
	    poolsE_ref(ACTIVE, S) =
		som1e_ref(SOIL, S) * fixed.lhzf[ACTIVE] * convertFactor1;
	if ( site.lhiS[SLOW] > NSDepEro_poolMinThreshold )
	    poolsE_ref(SLOW, S) = site.lhiS[SLOW] * convertFactor2;
	else
	    poolsE_ref(SLOW, S) =
	    	nps.som2e[S] * fixed.lhzf[SLOW] * convertFactor1;
	if ( site.lhiS[PASSIVE] > NSDepEro_poolMinThreshold )
	    poolsE_ref(PASSIVE, S) = site.lhiS[PASSIVE] * convertFactor2;
	else
	    poolsE_ref(PASSIVE, S) =
	    	nps.som3e[S] * fixed.lhzf[PASSIVE] * convertFactor1;
    }
#undef poolsC_ref
#undef poolsE_ref

	//--- initialize the lower layer pools with these amounts
	lowerSoil->SetPoolsFromDensity (poolsC, poolsE);
	// save ratio of simulation layer to lower layer total C
	comput.ratioSC2LLC = soilC.somsc / lowerSoil->GetTotalC ();
}
