// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TNcFileOutVarDef.cpp
//	Class:	  TNcFileOutVarDef
//
//	Description:
//	Class for I/O of netCDF files for the output variables definitions.
//	Derived from the class TNcFile.
//	This is a friend of TMCOutputVariableInfo.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Sep98
//	History: See header file.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

#include "TNcFileOutVarDef.h"
#include "charutil.h"

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

short const TNcFileOutVarDef::version = 4;	// netCDf file version number

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	Read
//	Reads entire contents of the netCDF file.
//	Returns false upon successful read, else true if not successful.
bool TNcFileOutVarDef::Read (
	TMCOutputVariableInfo & vi)
{
	if ( ncErrStr )			// already have error message?
		return true;		// ...yes

	bool retVal = false;
	if ( !OpenNcFile (NcFile::ReadOnly) )	// open the netCDF file
	{
		GetVars (ncFile);		// get pointers to variables
		GetDims (ncFile);		// get dimensions

		// Save dimensions
		short catLen = (short)d[0]->size ();	// category name length
		short nameLen = (short)d[2]->size ();	// length of names
							// list sizes
		vi.wtCount = (short)d[3]->size ();		// water/temp
		vi.soilCount = (short)d[5]->size ();		// soil C
		vi.cgCount = (short)d[7]->size ();		// crop/grass C
		vi.forestCount = (short)d[9]->size ();		// forest C
		vi.co2Count = (short)d[11]->size ();		// CO2
		vi.npsCount = (short)d[13]->size ();		// NPS
							// description lengths
		short wtDescLen = (short)d[4]->size ();		// water/temp
		short scDescLen = (short)d[6]->size ();		// soil C
		short ccDescLen = (short)d[8]->size ();		// crop/grass C
		short fcDescLen = (short)d[10]->size ();	// forest C
		short co2DescLen = (short)d[12]->size ();	// CO2
		short npsDescLen = (short)d[14]->size ();	// NPS

		// memory for lists
		vi.categories = new char* [7];			// categories
		vi.categories[6] = 0;				//  null-term
								// water/temp
		vi.wtNames = new char* [vi.wtCount + 1];	//   names
		vi.wtNames[vi.wtCount] = 0;			//   null-term
		vi.wtDescs = new char* [vi.wtCount + 1];	//   desc.
		vi.wtDescs[vi.wtCount] = 0;			//   null-term
								// soil C
		vi.soilNames = new char* [vi.soilCount + 1];	//   names
		vi.soilNames[vi.soilCount] = 0;			//   null-term
		vi.soilDescs = new char* [vi.soilCount + 1];	//   desc.
		vi.soilDescs[vi.soilCount] = 0;			//   null-term
								// crop/grass C
		vi.cgNames = new char* [vi.cgCount + 1];	//   names
		vi.cgNames[vi.cgCount] = 0;			//   null-term
		vi.cgDescs = new char* [vi.cgCount + 1];	//   desc.
		vi.cgDescs[vi.cgCount] = 0;			//   null-term
								// forest C
		vi.forestNames = new char* [vi.forestCount + 1];//   names
		vi.forestNames[vi.forestCount] = 0;		//   null-term
		vi.forestDescs = new char* [vi.forestCount + 1];//   desc.
		vi.forestDescs[vi.forestCount] = 0;		//   null-term
								// CO2
		vi.co2Names = new char* [vi.co2Count + 1];	//   names
		vi.co2Names[vi.co2Count] = 0;			//   null-term
		vi.co2Descs = new char* [vi.co2Count + 1];	//   desc.
		vi.co2Descs[vi.co2Count] = 0;			//   null-term
								// NPS
		vi.npsNames = new char* [vi.npsCount + 1];	//   names
		vi.npsNames[vi.npsCount] = 0;			//   null-term
		vi.npsDescs = new char* [vi.npsCount + 1];	//   desc.
		vi.npsDescs[vi.npsCount] = 0;			//   null-term

		// Read variable values
		for ( short j = 0; j <= 12; j++ )	// for each list...
		{
		    short strLength = 0, loopEnd = 0;
		    char **p = 0;				// ptr to list
		    // parameters for loop which retrieves the strings
		    switch (j)
		    {
		      case 0:			// categories
		      	strLength = catLen;
		      	loopEnd = 6;
		      	p = vi.categories;
		      	break;
		      case 1:			// water/temp names
		      	strLength = nameLen;
		      	loopEnd = vi.wtCount;
		      	p = vi.wtNames;
		      	break;
		      case 2:			// water/temp descriptions
		      	strLength = wtDescLen;
		      	loopEnd = vi.wtCount;
		      	p = vi.wtDescs;
		      	break;
		      case 3:			// soil C names
		      	strLength = nameLen;
		      	loopEnd = vi.soilCount;
		      	p = vi.soilNames;
		      	break;
		      case 4:			// soil C descriptions
		      	strLength = scDescLen;
		      	loopEnd = vi.soilCount;
		      	p = vi.soilDescs;
		      	break;
		      case 5:			// crop/grass C names
		      	strLength = nameLen;
		      	loopEnd = vi.cgCount;
		      	p = vi.cgNames;
		      	break;
		      case 6:			// crop/grass C descriptions
		      	strLength = ccDescLen;
		      	loopEnd = vi.cgCount;
		      	p = vi.cgDescs;
		      	break;
		      case 7:			// forest C names
		      	strLength = nameLen;
		      	loopEnd = vi.forestCount;
		      	p = vi.forestNames;
		      	break;
		      case 8:			// forest C descriptions
		      	strLength = fcDescLen;
		      	loopEnd = vi.forestCount;
		      	p = vi.forestDescs;
		      	break;
		      case 9:			// CO2 names
		      	strLength = nameLen;
		      	loopEnd = vi.co2Count;
		      	p = vi.co2Names;
		      	break;
		      case 10:			// CO2 descriptions
		      	strLength = co2DescLen;
		      	loopEnd = vi.co2Count;
		      	p = vi.co2Descs;
		      	break;
		      case 11:			// NPS names
		      	strLength = nameLen;
		      	loopEnd = vi.npsCount;
		      	p = vi.npsNames;
		      	break;
		      case 12:			// NPS descriptions
		      	strLength = npsDescLen;
		      	loopEnd = vi.npsCount;
		      	p = vi.npsDescs;
		      	break;
		    }
		    // retrieve the strings from the netCDF file
		    char *str = new char [strLength + 1];	// temp str
		    for ( short i = 0; i < loopEnd; i++ )	// for each...
		    {
		    	memset (str, 0, strLength + 1);
			v[j].v->set_cur (i, 0);			// next string
			v[j].v->get (str, 1, strLength);	// retrieve
			::strtrim (str);			// trim
			*p = new char [strlen(str) + 1];	// alloc mem
			strcpy (*p, str);			// save
			++p;					// to next
		    }
		    delete [] str;				// dealloc mem
		    if ( SetNcErrStr () )		// check for errors
		    {
		    	// need error handling here
		    	retVal = true;		// error flag
		    	break;			// end the loop
		    }
		}
		// all done!
		CloseNcFile ();			// close the netCDF file
		if ( ncErrFlag )		// error?
			retVal = true;		// ...no
	}
	return retVal;
}

//---	end of T_NcFileOutVarDef.cpp ---//
