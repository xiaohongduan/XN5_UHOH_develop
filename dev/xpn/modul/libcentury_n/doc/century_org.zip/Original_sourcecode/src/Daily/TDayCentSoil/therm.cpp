// ----------------------------------------------------------------------------
//    Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//    Project:  Century Soil Organic Matter Model, daily version
//    File:	therm.cpp
//    Class:	TDayCentSoil
//    Function: CalcThermalDiffusivity
//
//    Description:
//    Calculates thermal diffusivity of soil temperature layers
//    and other soil temperature layer properties
//
//    Author: Melannie Hartman, Bill Parton, Josef Eitzinger
// ----------------------------------------------------------------------------
//	History:
//	Sep1994  Melannie Hartman, melannie@NREL.colostate.edu
//	* Created therm.c from therm.f and linked it to the
//        daily soil water model
//	Apr1997  Melannie Hartman, melannie@NREL.colostate.edu
//	* Linked soiltemp.c to FORTRAN/C version of DayCent
//	Jan1999 Josef Eitzinger + Melannie Hartman
//	* Modified and adapted for frost/thew periods during winter
//	Apr2001	 Melannie Hartman, melannie@NREL.colostate.edu
//	* Translated therm.c to therm.cpp
//	Nov02-Feb03   Tom Hilinski, tom.hilinski@colostate.edu
//	* Misc. clean up, const-correctness, optimization.
//	* Convert to use arraytypes.h for arrays
//	Jan04	Tom Hilinski
//	* Fixed incorrect calc of "p" for top and bottom layer, such that
//	  d1 < d2 always.
// ----------------------------------------------------------------------------

#include "TDayCentSoil.h"
#include "precision.h"

void TDayCentSoil::CalcThermalDiffusivity (
    float const airTempMin,	// minimum air temperature for the day (deg C)
    float const airTempMax,	// maximum air temperature for the day (deg C)
    T1DFloatArray & thermDif,	// thermal diffusivity of soil temp lyrs (units?)
    T1DFloatArray & vh2oc,	// volum swc of soil temp lyrs (frac)
    T1DFloatArray & hcst)	// heat capacity of soil temp lyrs (cal/K)
{
    Assert ( airTempMin <= airTempMax );

    float const hc_h2o = 1.0f;		// heat capacity of water (cal/g/K)
    float const hc_ice = 0.5f;		// heat capacity of ice (cal/g/K)
    float const hc_dry_soil = 0.20f;	// heat capacity of dry soil (cal/g/K)
    float const tc_ice = 4.4f;		// thermal conductivity of ice (units?)
    float const dx = 		// actual soil temperature interval size (cm)
    	SoilDepth() / numSoilTemperatureLayers;

    if ( heatCapacity.size() != numSoilTemperatureLayers )
    {
	// heat capacity of soil temp lyrs (units?)
	heatCapacity.resize (numSoilTemperatureLayers);
	// weight frac of moisture in soil temp lyrs
	weightFractionH2O.resize (numSoilTemperatureLayers);
    }
    heatCapacity = 0.0f;
    weightFractionH2O = 0.0f;

    for (short layer = 0; layer < numSoilTemperatureLayers; layer++)
    {
	float const di =			// center of soil temp layer
		(float)(layer) * dx + dx * 0.5f;
	bool found = false;

	//  Determine which soil layers (i1 and i2) contain the current soil
	//  temperature layer.

	short indexUpperLayer, indexLowerLayer;		// indices to layers
	float d1, d2;		// depths to layer midpoint at indices
	float p = 0.0f;		// fraction below beginning of interval
	if ( di <= depthToMidPt(0) )
	{
	    indexUpperLayer = indexLowerLayer = 0;
	    d1 = 0.0f;					// top of layer
	    d2 = depthToMidPt(0);			// midpoint of layer
	    if ( d2 != d1 )
	    	p = (di - d1) / (d2 - d1);
	    found = true;
	}
	else if ( di >= depthToMidPt( BottomLayer() ) )
	{
	    indexUpperLayer = indexLowerLayer = BottomLayer();
	    d1 = depthToMidPt(indexUpperLayer);		// midpoint of layer
	    d2 = SoilDepth();				// bottom of layer
	    if ( d2 != d1 )
	    	p = (di - d1) / (d2 - d1);
	    found = true;
	}
	else
	{
	  // Search for indexUpperLayer and indexLowerLayer
	    for (short j = 0; j < GetLayerCount(); j++)
	    {
		indexUpperLayer = j;
		indexLowerLayer = j + 1;
		d1 = depthToMidPt(indexUpperLayer);
		d2 = depthToMidPt(indexLowerLayer);
		if ( (di >= d1) && (di < d2) )
		{
		    found = true;
		    // if p > 0.5 then di is farther from center of upper layer
		    // than it is to the center of lower layer
		    p = (di - d1) / (d2 - d1);
		}
		if (found)
			break;
	    }
	}

	if (!found)
	{
	    ThrowDayCentException (TDayCentException::DCE_SWMERR,
		"ERROR in CalcThermalDiffusivty: "
		"Could not find soil temperature layers.");
	}

	float const pCompliment = 1.0f - p;	// calc only once

	float const adjustedBulkDensity =
		p * BulkDensity(indexLowerLayer) + pCompliment *
		BulkDensity(indexUpperLayer);
	float const fci =
		p * FieldCapacity(indexLowerLayer) + pCompliment *
		FieldCapacity(indexUpperLayer);
	vh2oc(layer) =
		p * WaterContent(indexLowerLayer) / thickness[indexLowerLayer] +
		pCompliment *  WaterContent(indexUpperLayer) /
		thickness[indexUpperLayer];
	float const vice = vh2oc(layer) * 1.11f;
	weightFractionH2O(layer) = vh2oc(layer) / adjustedBulkDensity;

	// Commented out cuz layer can be very dry
	// Assert ( AmountIsSignificant (vh2oc(layer)) );
	// Assert ( AmountIsSignificant (weightFractionH2O(layer)) );

	float const sand = p * SandFraction(indexLowerLayer) +
		pCompliment * SandFraction(indexUpperLayer);
	float const clay = p * ClayFraction(indexLowerLayer) +
		pCompliment * ClayFraction(indexUpperLayer);
	float const org = p * OMPC(indexLowerLayer) / 100.0f +
		pCompliment * OMPC(indexUpperLayer) / 100.0f;

	//  New silt terms by Bill Parton 9/94
	// The following calc defines the mineral fractions to be:
	//      sand + silt + clay + org = 1.0
	// Incorrect! In Century, only the mineral fractions sum to 1.0.
	// org is from the OMPC which derived from wt % (g org C / g Soil).
	// Corrected equation follows.   Tom Jul02
	// float silt = 1.0f - sand - clay - org;
	float const silt = 1.0f - sand - clay;
	float const bdRatio = adjustedBulkDensity / PARTDENS;	// optimize
	float const vsilt = silt * bdRatio;
	float const vsand = sand * bdRatio;
	float const vclay = clay * bdRatio;
	float const vmuck = org  * bdRatio;
	float const totPoreSpace = 1.0f - vsand - vclay  - vmuck - vsilt;

	//! Debug Error (No exception handling necessary)
	Assert ( (totPoreSpace > 0.0f) && (totPoreSpace < 1.0f) );

	//  Calculate heat capacity of soil (cal/g-deg C)
	//  heatCapacity calculation modified by Bill Parton 9/94
	//  heatCapacity=(0.46 * (vsand+vclay))+(0.6 * vmuck)+vh2oc(layer);
	//  heatCapacity=(0.20 * (vsand+vclay+vsilt))+(0.30 * vmuck)+vh2oc(layer);

	if (soilTempLyrAvg(layer) < -1.0f)
	{
	    heatCapacity(layer) =
	    	hc_ice * weightFractionH2O(layer) +
		hc_dry_soil * ( 1.0f - weightFractionH2O(layer) );
	}
	else
	{
	    heatCapacity(layer) =
	    	hc_h2o * weightFractionH2O(layer) +
		hc_dry_soil * ( 1.0f - weightFractionH2O(layer) );
	}
	hcst(layer) =
		heatCapacity(layer) * (adjustedBulkDensity + vh2oc(layer)) * dx;
	Assert ( AmountIsSignificant(hcst(layer)) );

	//  Calculate the thermal conductivity of air saturated with water
	//  vapor and water at temperature of layer

	// tch2o - thermal conductivity of water (units?)
	// tcsat - thermal conductivity of ?? (units?)
	// tcair - thermal conductivity of air (units?)
	// tcvap - thermal conductivity of water vapor (units?)
	float tch2o = 1.33f + (0.0044f *  soilTempLyrAvg(layer));
	float tcair = 0.058f + (0.000017f *  soilTempLyrAvg(layer));
	float tcvap = 0.052f *  std::exp(0.058f *  soilTempLyrAvg(layer));
	float tcsat = tcair + (tcvap *  vh2oc(layer) / fci);
	if (vh2oc(layer) >= fci)
	    tcsat = tcair + tcvap;

	//  Calculate an intermediate parameter pertaining to the
	//  thermal conductivity of each soil constituent
	float const recipTch2o = 1.0f / tch2o;		// optimize
	float const recipThree = 1.0f / 3.0f;		// optimize
	float const xsand =
		( (2.0f / (1.0f + (( 20.4f * recipTch2o  - 1.0f ) *  0.125f))) +
		(1.0f / (1.0f + (( 20.4f * recipTch2o - 1.0f ) *  0.75f))) ) *
		recipThree;
	float const xclay =
		( (2.0f / (1.0f + (( 7.0f * recipTch2o - 1.0f ) *  0.125f))) +
		(1.0f / (1.0f + (( 7.0f * recipTch2o - 1.0f ) *  0.75f))) ) *
		recipThree;
	float const xsilt =
		( (2.0f / (1.0f + (( 7.0f * recipTch2o - 1.0f ) *  0.125f))) +
		(1.0f / (1.0f + (( 7.0f * recipTch2o - 1.0f ) *  0.75f))) ) *
		recipThree;
	float const xmuck =
		( (2.0f / (1.0f + (( 0.6f * recipTch2o - 1.0f) * 0.5f))) +
		  1.0f) * recipThree;
	float xgair = 0.0f + (0.333f * vh2oc(layer) / fci);
	if (xgair > recipThree)
		xgair = recipThree;
	float const xair =
		( ( 2.0f / (1.0f + ( (tcsat * recipTch2o) - 1.0f) * xgair) ) +
		 ( 1.0f / ( 1.0f +
		   ( (tcsat * recipTch2o - 1.0f) * (1.0f - 2.0f * xgair) ) )
		 )
		) * recipThree;

	// thermal conductivity of the soil layer
	if (soilTempLyrAvg(layer) < -1.0f)
	{
	    vh2oc(layer) = vice;
	    tch2o = tc_ice * 0.10f;
	}
	float const thermalConductivity = (
			vh2oc(layer) * tch2o +
			xsand * vsand * 20.4f +
			xclay * vclay * 7.0f +
			xsilt * vsilt * 7.0f +
			xmuck * vmuck * 0.6f +
			xair  * ( totPoreSpace - vh2oc(layer) ) * tcsat ) /
			( vh2oc(layer) +
				xsand * vsand +
				xclay * vclay +
				xsilt * vsilt +
				xmuck * vmuck +
				xair  * ( totPoreSpace - vh2oc(layer) ) ) /
			1000.0f;

	// thermal diffusivity of the soil layer
	float const thermalDiffusivity =
		0.95f *  ( thermalConductivity / heatCapacity(layer) );
	if (thermalDiffusivity < 0.004f)
	    thermDif(layer) = 0.004f;
	//    else if (thermalDiffusivity > 0.009f)
	//	thermDif(layer) = 0.009f;
	else if (soilTempLyrAvg(layer) <= -1.0f &&
		 thermalDiffusivity > 0.0095f)
	{
		thermDif(layer) = 0.0095f;
	}
	else if (soilTempLyrAvg(layer) > -1.0f &&
		 thermalDiffusivity > 0.0085f)
	{
		thermDif(layer) = 0.0085f;
	}
	else
	{
		thermDif(layer) = thermalDiffusivity;
	}

    } // for layer
}

//--- end of file ---
