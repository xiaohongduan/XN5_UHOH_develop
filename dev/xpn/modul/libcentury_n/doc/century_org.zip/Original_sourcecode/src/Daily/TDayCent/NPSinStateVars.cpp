// ----------------------------------------------------------------------------
//	Copyright 2001-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	NPSinStateVars.cpp
//	Class:	TDayCent
//	Function: NPSInStateVars, NPSInSoilLayers
//
//	Description:
//	NPSInStateVars:   Returns the sum of N, P, or S in all state variables
//	NPSInSoilLayers:  Returns the sum of mineral N, P, or S is soil layers
// ----------------------------------------------------------------------------
//	Author: Melannie Hartman, melannie@NREL.colostate.edu, 26June2001
//	History:
// ----------------------------------------------------------------------------

#include "TDayCent.h"

//	NPSInStateVars
//	Calculate the total element in Century's state variables.
float TDayCent::NPSInStateVars (
	TMineralElements element   // element N, P, or S
	) const
{
    float totalElement = 0.0;

    if (element == N)
    {
        totalElement
            = soil->Ammonium().Quantity(0, soil->BottomLayer())
            + soil->Nitrate().Quantity(0, soil->BottomLayer());
    }
    else if (element == P)
    {
       totalElement = soil->Phosphorus().Quantity(0, soil->BottomLayer())
                    + nps.occlud;
    }
    else if (element == S)
    {
       totalElement = soil->Sulfur().Quantity(0, soil->BottomLayer());
    }

    totalElement
        += soil->GetDeepSoilMnrlStore(element)
        // surface and soil litter components
        + struce_ref(SRFC, element) + struce_ref(SOIL, element)
        + metabe_ref(SRFC, element) + metabe_ref(SOIL, element)
        // active, slow, passive soil organic matter pools
        + som1e_ref(SRFC, element) + som1e_ref(SOIL, element)
        + nps.som2e[element]
        + nps.som3e[element]
        // live crop/grass components
        + nps.aglive[element] + nps.bglive[element]
        // live tree components
	+ nps.rleave[element] + nps.froote[element]
        + nps.fbrche[element] + nps.rlwode[element] + nps.croote[element]
        // dead crop/grass components
        + nps.stdede[element]
        // dead tree components
        + nps.wood1e[element] + nps.wood2e[element] + nps.wood3e[element]
        // mineral N - primary and secondary
        + nps.parent[element] + nps.secndy[element]
        // crop/grass and tree retranslocation storage
        + nps.crpstg[element] + nps.forstg[element]
        // Catch-all nps Source/Sink
        // (fluxes and removals are added in, inputs subtracted)
        + nps.esrsnk[element];

    return totalElement;
}

//	NPSInSoilLayers
//	Calculate the total element in the soil profile.
float TDayCent::NPSInSoilLayers (
	TMineralElements element   // element N, P, or S
	) const
{
    float totalElement = 0.0;

    if (element == N)
    {
        totalElement
            = soil->Ammonium().Quantity(0, soil->BottomLayer())
            + soil->Nitrate().Quantity(0, soil->BottomLayer());
    }
    else if (element == P)
    {
       totalElement = soil->Phosphorus().Quantity(0, soil->BottomLayer())
                    + nps.occlud;
    }
    else if (element == S)
    {
       totalElement = soil->Sulfur().Quantity(0, soil->BottomLayer());
    }

    return totalElement;
}

//void TDayCent::NPSFluxes(
//   short element)   // element N, P, or S
//{
//    Assert (element == N) || (element == P) || (element == S);
//    double totalElementFlux = 0.0;
//    double totalElementInput = 0.0;
//
//    if (element == N)
//    {
//        // Output fluxes
//        totalElementFlux
//            = tg.NOflux + tg.N2flux
//            + tg.N2Oflux_nit + tg.N2Oflux_dnit;
//
//        // Inputs
//        totalElementInput
//            = nps.wdfxma + nps.wdfxms    // non-symbiotic N-fixation
//            + nps.nfix;                  // symbiotic N-fixation
//    }
//    else if (element == P)
//    {
//        // Output fluxes
//        // Inputs
//    }
//    else if (element == S)
//    {
//        // Output fluxes
//        // Inputs
//        //atmS + irrS (simsom.cpp)        // Atmospheric S deposition
//    }
//
//    // Output fluxes
//    //totalElementFlux
//        // these are added to esrsnk[element]
//        //+= dwt.stream[element+1] + dwt.stream[element+5];  // Inorg + Org leaching
//
//    // Inputs
//    //totalElementInput
//       //Need daily fertilization variable
//       //+= nps.fertot[element];  // an accumulator over multiple time steps?
//
//
//Notes:
//after cutting event, there is egain (cutrtn.cpp)
//after fire event, there is egain (firrtn.cpp)
//nps.terem[element] (dedrem.cpp)
//nps.volpla (dshoot.cpp)
//nps.shrmae[], nps.sdreme[], eret[], urine (grem.cpp)
//uptake_ref (ENFIX, e): N fixation, autofert (growth.cpp)
//tmpUptake: N fixation, autofert (treegrow.cpp)
//nps.volpla, nps.egrain[iel], nps.ermvst[iel] (harvst.cpp)
//TDeposit.cpp
//TErosion.cpp
//streme[iel], litrme[iel] (litburn.cpp)
//nps.terem[iel], eloss[iel] from storage removal) (livrem.cpp)
//}

