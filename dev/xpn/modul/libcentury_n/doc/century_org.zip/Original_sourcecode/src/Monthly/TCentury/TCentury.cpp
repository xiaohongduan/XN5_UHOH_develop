// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCentury.cpp
//	Class:	  TCentury
//
//	Description:
//	Century soil organic matter model class, version 5, monthly time step.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
//	History: See the file TCentury-History.txt.
// ----------------------------------------------------------------------------

#include "TCentury.h"
#ifndef MONTHLY_CENTURY
#error Macro MONTHLY_CENTURY is not defined!
#endif
#include "TCentSSFile.h"
#include "TCentNcFile.h"
#include "TMCDecomposition.h"
#include "TCalendarTools.h"
using namespace std;

// ----------------------------------------------------------------------------
//	constructors and destructor
// ----------------------------------------------------------------------------

/* obsolete - Feb04
TCentury::TCentury (
	TMCSiteParameters * const useSite, 		// site params.
	TManagementScheme * const useMgmt,		// management
	TEventDBList * const useParamDbList,		// parameter databases
	TOutputBase * const useOutput,			// output engine
	CenturyPaths const * const usePaths,		// directories
	char const * const useUserName,			// user's name
	TAsynchCommunication const * const useAsynchCom,// asynch communication
	TDebugInfo const & useDebugFlags)		// debug flags
	: TMonthlyCenturyBase (
		useSite, useMgmt, useOutput,
		useParamDbList,
		(useOutput ? true : false),	// doing output?
		useUserName,
		useDebugFlags.execTime, useAsynchCom,
		&useDebugFlags )
{
	Constructor ();
	Initialize ();
}
*/

TCentury::TCentury (
	TCenturyConfig const & config,			// configuration
	TDebugInfo const & useDebugFlags)		// debug flags
	: TMonthlyCenturyBase (
		// dynamic_cast<TMCSiteParameters * const>( config.GetSite().get() ),
		config.GetSite(),
		config.GetManagement(),
		config.GetOutput(),
		config.GetParametersDBList(),
		config.ProduceOutput(),
		config.GetUserName(),
		useDebugFlags.execTime,
		config.GetAsynchCommunication().get(),
		&useDebugFlags )
{
	Constructor ();
	if ( state.IsError() )
	{
		std::string msg;
		if ( state.HaveMessage() )
		{
			if ( !state.GetErrorMessage().empty() )
			{
				msg += state.GetErrorMessage();
				msg += '\n';
			}
			if ( !state.GetWarningMessage().empty() )
 			{
				msg += state.GetWarningMessage();
 				msg += '\n';
			}
			if ( !state.GetInfoMessage().empty() )
			{
				msg += state.GetInfoMessage();
			}
		}
		throw (msg);
	}
	else
	{
		Initialize ();
	}
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	InitializeRun
//	Initialize the simulation run.
//	Returns false if completed, else true if did not.
bool TCentury::InitializeRun ()
{
    char const * const failedInitMsg =
    	CenturyNickname
	" initialization failed in InitializeRun().";

    if ( state != TModelState::State_NotInitialized )	// at start of run?
	ThrowCentException ( TCentException::CE_UNKNOWN_ERROR, failedInitMsg);
    //--- Make sure we have everything we need
    if ( !asynchCom.HaveMessageFunction() )		// anything there?
	ThrowCentException ( TCentException::CE_UNKNOWN_ERROR,
			"Message function has not been specified." );
    if ( !asynchCom.HaveWarningFunction() )		// anything there?
	ThrowCentException ( TCentException::CE_UNKNOWN_ERROR,
			"Warning message function has not been specified." );

    bool failedFlag = false;
    if ( DoingOutput() )
	OpenOutput ();				// open output files

    //--- Initialization tasks  - Keep these in order!
    // Step 1 moved to TCENTURYBASE::Constructor
    // ReadSimulationInfo ();		// 1. read general mgmt. info
    ReadSiteParameters ();		// 3. read site parameters
    // ReadPreviousOutput ();		// 4. get previous output (if any)
    // Note: this is a feature of Century4 that is not implemented here.
					// 5. get starting crop & tree vals
    if ( sysType.IsUnknown() )		// system type should be known!
	ThrowCentException (TCentException::CE_MGTERR,
				"Starting system type is unknown." );
    if ( sysType.HaveCropGrass() && !GetCrop ( sysType.CropName() ) )
	ThrowCentException (TCentException::CE_ONFCRP, sysType.CropName());
    if ( sysType.HaveTree() && !GetTree ( sysType.TreeName() ) )
	ThrowCentException (TCentException::CE_ONFTRE, sysType.TreeName());
    InitializePools ();			// 6. Calculate initial pool values
    PreliminaryCalcs ();		// 7. Init vars/prelim. calcs
    OutputVariables ();			// 8. Calc initial output values

    // To Do: TCentury::InitializeRun: Check if initialization ok; set flag.

    if ( !failedFlag )
	state = TModelState::State_Initialized;
    return failedFlag;
}

//	OpenOutput
//	Open the output file(s)
void TCentury::OpenOutput ()
{
	// Initialize the output file(s)
	TMCOutputFileBase * const myOutput =
		dynamic_cast<TMCOutputFileBase*>( output.get() );
	Assert (myOutput != 0);
	if ( myOutput && !myOutput->IsOpen() )		// open output engine
	{
		TOutputBase::TState outputState = myOutput->Open ();
		if ( outputState != TOutputBase::State_Open )
		{
			ThrowCentException ( TCentException::CE_OPNOUT,
				myOutput->GetFileName().c_str() );
		}
	}
}

//	UpdateMineralEVariables
//	Update the total soil mineral E output variables.
void TCentury::UpdateMineralEVariables ()
{
    // Available nutrients in the rooting depth of the soil profile.
    nps.plabil = 0.0f;
    for (short element = 0; element < site.nelem; ++element)
    {
	nps.tminrl[element] = soil->QuantityE (
		(TMineralElements)element,
		0.0f, water.depthOfRoots /* depth range */ );
	if (element == P)
		nps.plabil += nps.tminrl[P] *
				FractionMinPInSolution (
				    water.depthOfRoots, soil->MineralP() );
    }
}

void TCentury::UpdateMineralEOutputVariables ()
{
	// mineral E and deep storage E
	short const deepStoreLayer = MAXLYR - 1;
	short const endLayer = MELoopLimit ();
	for ( short element = 0; element < site.nelem; ++element )
	{
	    minerl_ref(deepStoreLayer, element) = water.deepStoreE[element];
	    TSoilPool::TFloatArray::const_iterator mineralE;
	    switch (element)
	    {
	      case N: mineralE = soil->MineralN().Values().begin();	break;
	      case P: mineralE = soil->MineralP().Values().begin();	break;
	      case S: mineralE = soil->MineralS().Values().begin();	break;
	    }
	    for ( short layer = 0; layer < endLayer; ++layer, ++mineralE )
	    	minerl_ref(layer, element) = *mineralE;
	    for ( short layer = endLayer; layer < deepStoreLayer; ++layer )
		minerl_ref (layer, element) = 0.0f;
	}
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Constructor
//	Common constructor tasks.
//	Should be called only from the constructors.
void TCentury::Constructor ()
{
}

//	Initialize
//	Initializes simple class variables to a known state.
void TCentury::Initialize ()
{
    for ( short i = 0; i < 3; ++i )	// To do: move into TDCComput
    	dummyE[i] = 100.0f;		// dummy E compartment values
    for ( short i = 0; i < 2; ++i )	// To do: move into TDCComput
    	dummyC[i] = 1000.0f;		// dummy C compartment values
}

//	Duplicate
// 	Duplicate this
void TCentury::Duplicate (
	TCentury const & object)
{
	if ( !(&object) )
		return;

	//--- data - parameter databases
	// These are duplicated in the copy constructor initialization list.

	//--- data - output variables
	// These are duplicated in the copy constructor initialization list.

	//--- data - dynamically allocated classes (all are auto_ptr)
}

//	DoInitializeModel
//	Initialize the model
//	Return false if successful
bool TCentury::DoInitializeModel ()
{
    if ( state == TModelState::State_NotInitialized  && // at start of run?
	 !restart.InRestartMode() )
    {
	if ( InitializeRun() )			// Initialization failed?
	{
		return true;			// ...yes
		// ThrowCentException ( TCentException::CE_UNKNOWN_ERROR,
		//			failedInitMsg);
	}
	state = TModelState::State_Initialized;
	iterationData.blockInstNum =		// 9. Read the first block
		GetCurrentMgmt ( iterationData.blockInstNum );
	++iterationData.blockInstNum;		// count block instances
	WriteOutputValues (st->time);		// 10. Write starting values
	iterationData.updateInterval = YearEndMsgInterval();
	// display sim time details
	if ( debugInfo.writeTimeDetails )
	{
		iterationData.ms.str("");
		iterationData.ms
		  << "Simulation start, end year: "
		  << st->startYear << ", " << st->endYear << endl
		  << "Output month/year start, "
		  << "and month/year increment: "
		  << st->writeMonth << '/' << st->writeYear << ", "
		  << st->dtWriteMonth << '/' << st->dtWriteYear;
		asynchCom.SendMessage ( iterationData.ms );
	}
    }
    return false;	// successful initialization!
}

//	DoRunToCompletion
//	Runs the Century model simulation.
//	Returns false if completed, else true if did not.
bool TCentury::DoRunToCompletion ()
{
	//--- Run the simulation
	//    Do one iteration for each time step (dt = 1/12).
	//    Loop limits are st.startYear and st.endYear, inclusive.
	//    st->year is float type, so comparisons check that within 1/2 dt.
	asynchCom.SendMessage ( CenturyNickname " simulation is running..." );

	//--- simulation loop ---
	bool moreToDo = true;
	while ( moreToDo )			// for each time step...
	{
		moreToDo = DoRunIteration();
	}

	// execution time at simulation end
	if ( debugInfo.execTime )
	{
		iterationData.ms.str("");
		iterationData.ms
		   << "Execution time: "
		   << GetTimerSeconds()
		   << " seconds.";
		asynchCom.SendMessage ( iterationData.ms );
	}

	//--- all done!
	asynchCom.SendMessage ( CenturyNickname " simulation finished." );
	return !(state == TModelState::State_Completed);
}

//	DoRunIteration
//	Run one iteration.
//	Returns true if can continue again for another, else false if cannot.
bool TCentury::DoRunIteration ()
{
	//--- Local variables
	char const * const failedInitMsg =
		CenturyNickname " initialization failed.";
	bool stopFlag = false;			// return value

	// check for cancelation requested posted asynchronously
	if ( HaveCancelRequest() )
	{
		state = TModelState::State_Terminated;	// set model state
		stopFlag = true;
		goto all_done;
	}

	if ( restart.InRestartMode() )	// operations needed for restart
	{
		if ( DoingOutput() )
			OpenOutput ();		// open output files
		restart.SetRestartFlag (false);	// turn restart flag off
	}

	if ( asynchCom.HaveTimeStepFunction() )
		asynchCom.DoTimeStepFunction();

	if ( state == TModelState::State_Paused ||	// at start of next iteration?
	     state == TModelState::State_Initialized )	// first iteration?
	{
		state = TModelState::State_Running;
	}
	if ( state == TModelState::State_NotInitialized ||  // not initialized?
	     state != TModelState::State_Running )
	{
		// should not get here!
		ThrowCentException ( TCentException::CE_UNKNOWN_ERROR,
					failedInitMsg);
	}

	//--- start of iteration ---
	if ( st->IsStartOfYear() )		// Perform start-of-year tasks
	{
		if ( asynchCom.HaveSendYearFunction() &&
			st->year % iterationData.updateInterval == 0 )
		{
			asynchCom.SendSimulationYear (st->year);
		}
		StartOfYearTasks ();
		if ( debugInfo.writeTime )
		{
			iterationData.ms.str("");
			iterationData.ms
			   << "Simulation Year = "
			   << st->year
			   << ": "
			   << "Weather Year = "
			   << weather->CurrentYear()
			   << ": ";
			asynchCom.SendMessage ( iterationData.ms );
		}
	}
	SimulateSOM ();				// Do simulation
	OutputVariables ();			// Compute output variables
	if ( st->IsEndOfYear() )		// Perform end-of-year tasks
		EndOfYearTasks ();
	if ( st->TimeForOutput() )		// Write output variables
	{
	    if ( debugInfo.writeTime )
	    {
		iterationData.ms.str("");
		iterationData.ms
		   << "output time: year " << st->year
		   << ", month " << (short)st->month;
		asynchCom.SendMessage ( iterationData.ms );
	    }
	    // Make an output time that represents the last day of the month.
	    // This is to match that of DayCent5, which counts by days, not by
	    // months. In DayCent5, Jan. output is at float time = year + 0.082
	    short const lastDayInMonth =
		TCalendarTools::DaysInMonth (st->month, st->year) - 1;
	    float const outputTime =
		st->time +
		  (float) lastDayInMonth /
		  (float) TCalendarTools::DaysInYear(st->year);
	    WriteOutputValues (outputTime);
	    st->IncrementOutput ();	    // increment to next output date
	}
	stopFlag = st->AtSimulationEnd();
	if ( !stopFlag )			// not done yet?
	{
	    if ( st->AtBlockEnd() )		// need new management?
	    {
		iterationData.blockInstNum =	// zero-based index
			GetCurrentMgmt (iterationData.blockInstNum);
		++iterationData.blockInstNum;	// count block instances
		if ( debugInfo.writeTime )
		{
		    iterationData.ms.str("");
		    iterationData.ms
			<< "change mgmt: block "
			<< iterationData.blockInstNum
			<< ", year " << st->year
			<< ", month " << (short)st->month;
		    asynchCom.SendMessage ( iterationData.ms );
		}
	    }
	    st->Increment ();			// Update simulation time
	}
	else					// simulation completed
	{
    		state = TModelState::State_Completed;	// ...yes
    	}
	//--- end of iteration ---

	//--- all done!
  all_done:
	if ( stopFlag )				// Completed or stopped?
	{
		if ( DoingOutput() )
			output->Close ();	// close the output file
		if ( state == TModelState::State_Running )
			state = TModelState::State_Completed;
	}
	return !stopFlag;	// return true if can do another iteration
}

//--- end of definitions for TCentury ---
