// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  firein.cpp
//	Class:	  TCentury
//	Function: GetFire
//
//	Description:
//	Read the new fire parameter set.
//	Returns true if successful match in database, else false if not.
//
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, May98
// ----------------------------------------------------------------------------
//	History:
//	Dec00	Tom Hilinski, tom.hilinski@colostate.edu
//	* Parameter set is now read in once only during a simulation,
//	  and stored in a TCentury member variable.
//	Jul01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Modified to use new TEventDBList class.
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------

// #include "TCenturyBase.h"
#include "TEventDBList.h"
#include "util.h"
#include "constants.h"

MY_TEMPLATE_DECLARATION
bool TCENTURYBASE::GetFire (
	char const* fireToMatch)
{
	// error checks
	if ( !fireToMatch || !(*fireToMatch) )		// anything there?
		return false;

	// get the option set
	TEventOptionSet const & optionSet =
		*paramDbList->Get (TEventDBList::DBI_Fire);
	if ( !&optionSet )				// database not there?
		ThrowCentException (TCentException::CE_NSPPDB,
			::eventName[ET_Fire]);
	if ( !optionSet.GetOptionCount () )		// empty database?
		ThrowCentException (TCentException::CE_EMPPDB,
			::eventName[ET_Fire]);

	// get the option matching the parameter string
    	TEventOption const * const option = optionSet.GetOption (fireToMatch);
	if ( !option )					// match found?
		return false;

	// retrieve values from option and save in Century's variables
	short const numParams = 9;			// total for an option
	short count = option->GetParamCount ();
	if ( count != numParams )			// counts match?
		ThrowCentException (TCentException::CE_OPCBAD,
			::eventName[ET_Fire]);

	register short k = 0;			// index to param values
	register short i;			// loop indices

	parcp.flfrem = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 2; ++i)
		parcp.fdfrem[i] = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 3; ++i)
		parcp.fret[i] = option->GetParameter(k++)->GetValue();
	parcp.frtsh = option->GetParameter(k++)->GetValue();
    	for (i = 0; i < 2; ++i)
		parcp.fnue[i] = option->GetParameter(k++)->GetValue();

	// save option name in Century class variable
	strcpy (sched->curFire, fireToMatch);		// save it

	return true;
}				/* GetFire */
