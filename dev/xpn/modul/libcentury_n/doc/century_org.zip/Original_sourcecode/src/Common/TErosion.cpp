// ----------------------------------------------------------------------------
//	Copyright 1998-2003 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural	Resource Ecology Laboratory
//			Colorado State University, Fort	Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  T_Erosion.cpp
//	Class:	  TErosion
//
//	Description:
//	Class to perform erosion of Century's pools.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Oct98
//	History:
//	See header file.
// ----------------------------------------------------------------------------

#include "TErosion.h"
#include "TNcFileErosion.h"
using namespace std;

// macro to reference the TErosion output data array
#define outData_ref(e_,p_)	outData[(e_)*EPT_NumPools + (p_)]

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

// size of output data
short const TErosion::outDataSize = EE_NumElements * EPT_NumPools;

// ----------------------------------------------------------------------------
//	constructors and destructor
// ----------------------------------------------------------------------------

TErosion::TErosion (
	TSite & useSite,		// use this site class instance
	TCenturySoil & useSoil,		// use this soil class instance
	TLowerSoil & useLwrSoil,	// use this lower soil pool instance
	TSoilC & useSoilC, 		// soil C output variable instance
	TNPS & useNPS,			// NPS output variable instance
	TWater & useWater,		// water parameters class
	TWaterTemp & useWT,		// water & temperature output class
	TFlow & useFlows,		// flow manager class instance
	short const useNumIso,		// number of isotopes
	short const useNumElem,		// number of elements
	char const * const useMgmtDesc,	// management description
	char const * const useMgmtFile,	// management file name
	char const * const useSiteDesc,	// site description
	char const * const useSiteFile,	// site file name
	char const * const useUserName)	// user name for output file
	: TDepEroBase ( useSite, useSoil, useLwrSoil, useSoilC, useNPS,
	  		useWater, useWT, useFlows, useNumIso, useNumElem),
	  mgmtDesc (useMgmtDesc),
	  mgmtFile (useMgmtFile),
	  siteDesc (useSiteDesc),
	  siteFile (useSiteFile),
	  userName (useUserName)
{
	Initialize ();
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	SetRate
//	Set the erosion rate (kg/m^2/month)
void TErosion::SetRate (
	float const newRate)	// rate of erosion to use
{
	if ( newRate <= 0.0f )
		return;		// To Do: error handling
	// rate = const_cast<float>(newRate);
	rate = newRate;
}

//	SetEnrichFactor
// 	Set the enrichment factor
void TErosion::SetEnrichFactor (
	float const newFactor)	// factor to use
{
	if ( newFactor <= 0.0f )
		return;		// To Do: error handling
	// enrichFactor = const_cast<float>(newFactor);
	enrichFactor = newFactor;
}

//	UseErosionFile
//	Save eroded amounts to the specified file.
//	Returns false if file name is OK, else true if not or error.
//	If the file already exists, its contents are replaced.
bool TErosion::UseErosionFile (
	char const * const filePath)	// full path with file name
{
	//--- error checks
	if( !filePath || !(*filePath) )			// anything there?
	{
		// To Do: invalid file path - need error handling
		return true;
	}

	//--- open the output file
	bool retVal = false;			// return value
	TEH::TFileName outFileName (filePath);	// file name instance
	eoFile.reset ( new TNcErosionFile (outFileName, userName,
				mgmtDesc, mgmtFile, siteDesc, siteFile) );
	TNcErosionFile* const myEOFile =
		dynamic_cast<TNcErosionFile*>( eoFile.get() );
	if ( myEOFile == 0 || !myEOFile->IsValid() )
	{
		// To Do: invalid instance - need error handling
		eoFile.reset(0);
		retVal = true;
	}
	return retVal;
}

//	Erode
//	Removes material from the top of the soil.
//	Returns the thickness eroded.
float TErosion::Erode (
	float const simTime) 		// simulation time
{
	//--- amount of erosion
	float erodedThickness = ThicknessEroded ();	// thickness eroded
	Assert (erodedThickness >= 0.0f);		// valid value?
	Assert (erodedThickness <= 10.0f);		// max. reasonable rate
	// Do not let erosion remove more than simulation Depth
	erodedThickness = std::min (erodedThickness,
				    soil.SoilDepth() - lowerSoil.DepthToTop());
	Assert (erodedThickness >= 0.0f);
	if ( erodedThickness < NSDepEro_thicknessMin )	// less than minimum?
		return 0.0f;					// ...quit now
	// Fraction of simulation lost to erosion.
	// Enrichment factor is from the event "additional info" string,
	// and accommodates a non-constant change in C and E's density
	// vertically through the simulation layer.
	float simDepth = lowerSoil.DepthToTop ();
	float bulkDen = soil.BulkDensity().WtdMean (0.0f, simDepth,
						soil.Depth(), soil.Thickness());
	register float fractionLost =
			FractionLost (bulkDen, simDepth) * enrichFactor;
	Assert (fractionLost >= 0.0f);
	Assert (fractionLost <= 1.0f);

	//--- Calc the C and element amounts which will transfer into
	// the simulation layer from the lower layer.
	float transferAmtC[sizeC], transferAmtE[sizeE];
	float actualThickness = erodedThickness;	// changed in Remove
	float newSimDepth =
	  lowerSoil.Remove ( actualThickness, transferAmtC, transferAmtE );
	Assert (actualThickness <= erodedThickness);
	Assert (newSimDepth >= lowerSoil.MinSimLayerThickness());
	Assert (soil.SoilDepth() >= newSimDepth);

	//--- Erode the C and elemental pools
	// Soil losses from below-ground som1, som2, som3,
	// below-ground metabolic, and below-ground structural pools
	// in the simulation layer.
	//  	index	component	Where created:		Type:
	//	0	bulk density	ReadSiteParameters	property
	//	1	sand fraction	ReadSiteParameters	property
	//	2	silt fraction	ReadSiteParameters	property
	//	3	clay fraction	ReadSiteParameters	property
	//	4	wilting point	ReadSiteParameters	property
	//	5	field capacity	ReadSiteParameters 	property
	//	6	water content   ReadSiteParameters	pool
	//	7	SOM wt %	ReadSiteParameters 	property
	actualThickness = ErodeLayers (
		simTime, fractionLost, actualThickness );
	Assert (actualThickness <= erodedThickness);
	Assert (soil.SoilDepth() >= newSimDepth);

	//--- Transfer from lower layer to sim layer
	LowerToSimLayerPools ( simTime, transferAmtC, transferAmtE );

	//--- Adjust soil-water variables in the calling function
	wt.simDepth = newSimDepth;
	return erodedThickness;
}

//	Clear
// 	"clear" data members
void TErosion::Clear ()
{
	eoFile.reset ();
	Initialize ();
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	ErodeLayers
//	Erode as many soil layers as needed to meet thickness, or until
//	the depth of soil is reached.
//	Returns the actual thickness eroded.
float TErosion::ErodeLayers (
	float const simTime, 		// simulation time
	float const fractionLost,	// Fraction of soil lost by erosion
	float const thicknessToErode)	// thickness (cm)
{
	float thicknessRemaining = thicknessToErode;
	while ( thicknessRemaining > 0.0f &&
		thicknessRemaining < lowerSoil.MinSimLayerThickness() &&
		soil.GetLayerCount() > 0 )
	{
		float const actualThickness = std::min (
			thicknessRemaining,
			soil.Thickness(0) );
		auto_ptr<TSoilLayer> layer =
				soil.CopyLayer (0, actualThickness);
		SimPoolsLosses (simTime, fractionLost, actualThickness,
				layer->Component(0),	// bulk density
				layer->Component(1),	// sand
				layer->Component(2),	// silt
				layer->Component(3));	// clay
		thicknessRemaining -= actualThickness;
	}
	return thicknessToErode - thicknessRemaining;
}

//	ThicknessEroded
// 	Returns the thickness of soil to erode
//	using the current rate of erosion and the bulk density of the soil.
//	The maximum thickness available to erode is the soil thickness.
float TErosion::ThicknessEroded () const
{
	TCenturySoil::TFloatArray::const_iterator
		pT = soil.Thickness().begin();		// thicknesses
	TSoilCompList::TComponentVector::const_iterator
		pC = soil.CompList().GetList().begin();	// component list
	register float thick;				// mean thickness
	register float cumThick = 0.0;			// cumulative thickness
	float const maxDepth = soil.SoilDepth ();	// maximum soil Depth
	register float mass = rate * 0.1f;		// g/cm2 to erode

	while ( cumThick < maxDepth && mass > NSDepEro_poolMinThreshold )
	{
		register float const pBD = (*pC)->Values()[0];
		// Is current thickness > layer thickness?
		// If so, accumulate thickness, and calc new mean thickness
		// using the layer below.
		// thickness = rate / bulk density * 0.1 = cm
		// Units: kg/m^2 / g/cm^3 * 0.1 = cm
		thick = mass / pBD;		// new thickness
		Assert (thick <= 10);		// prevent absurdities
		if ( thick > *pT )		// exceed layer thick?
		{
			mass -= pBD * *pT;	// mass remaining
			cumThick += *pT;	// accumulate thickness
			++pC;			// to next layer
			++pT;
		}
		else
		{
			cumThick += thick;	// accumulate thickness
			break;			// all done!
		}
	}
	return cumThick;
}

//	FractionLost
//	Returns the weight fraction of material lost by erosion
//	in the layer specified.
float TErosion::FractionLost (
	float const bulkDensity,	// bulk density (g/cm^3)
	float const thickness) const	// thickness (cm)
{
	// fraction = rate (kg/m^2) / mass of layer (kg/m^2)
	// mass of layer (kg/m^2)
	//	= bulkDensity * thickness * 10000 cm^2/m^2 * 1 kg/1000 g
	return rate / (bulkDensity * thickness * 10.0f);
}

//	SimPoolsLosses
// 	Compute elemental losses for the simulation layer pools due to erosion.
//	Schedule the losses and, if requested, write them to the erosion file.
//	Note: enums TErosionElements and TErosionPoolTypes are defined in
//	the file "T_NcFileErosion.h".
void TErosion::SimPoolsLosses (
	float const simTime,	// simulation time
	float const fracLost,	// Fraction of soil lost by erosion
	float const thickness,	// thickness (cm)
	float const bulkDen,	// bulk density (g/cm^3)
	float const sand,	// fraction of sand-sized
	float const silt,	// fraction of silt-sized
	float const clay)	// fraction of clay-sized
{
	if ( fracLost < 1.0e-6f || thickness < 1.0e-6f )	// anything?
		return;

	//--- error checks
	Assert (thickness >= 0.0f);
	Assert (sand + silt + clay <= 1.001f);		// fractions sum to 1
	Assert (fracLost >= 0.0f);
	Assert (fracLost <= 1.0f);

	short layer;		// Index to the soil layer
	short numLayers;	// Number of soil layers in the array
       	float  cSource;  	// SOM pool from which C is lost
       	float* ciSource;	// SOM pool from which 13C/14C is lost
       	float* eSource;		// SOM pool from which N,P,S is lost

#define eSource_ref(a_1,a_2)	eSource[(a_2)*(numLayers) + (a_1)]
#define ciSource_ref(a_1,a_2)	ciSource[(a_2)*(numLayers) + (a_1)]

	InitOutData ();				// zero output array

	for (short pool = (short)EPT_Active;
	     pool < (short)EPT_NumPools;
	     pool+=1)
	{
	    //--- initialize the pool variables
	    switch ( pool )
	    {
	      case EPT_Active:
		layer = SOIL;
		numLayers = 2;
		cSource = soilC.som1c[SOIL];
		ciSource = soilC.som1ci;
		eSource = nps.som1e;
		break;
	      case EPT_Slow:
		layer= 0;
		numLayers = 1;
		cSource = soilC.som2c;
		ciSource = soilC.som2ci;
		eSource = nps.som2e;
		break;
	      case EPT_Passive:
		layer= 0;
 		numLayers = 1;
		cSource = soilC.som3c;
		ciSource = soilC.som3ci;
		eSource = nps.som3e;
		break;
	      case EPT_Metabolic:
		layer = SOIL;
		numLayers = 2;
		cSource = soilC.metabc[SOIL];
		ciSource = soilC.metcis;
		eSource = nps.metabe;
		break;
	      case EPT_Structural:
		layer = SOIL;
 		numLayers = 2;
		cSource = soilC.strucc[SOIL];
		ciSource = soilC.strcis;
		eSource = nps.struce;
		break;
	    }
	    if ( cSource < NSDepEro_poolMinThreshold )	// source large enough?
		continue;		// ...no, to next pool

	    //--- Amount of unlabeled and labeled C lost from current pool
	    // Total loss of C from simulation layer = cSource * fracLost
	    register float amount;
	    // 1. unlabeled C
	    float unlabeledCFlow = fracLost * ciSource_ref (layer, UNLABL);
	    if ( unlabeledCFlow >= NSDepEro_poolMinThreshold )
	    {
	    	// remove from the simulation pool
		flows.Schedule (
			&ciSource_ref (layer, UNLABL), &soilC.csrsnk[UNLABL],
			simTime, unlabeledCFlow);
		// C losses from eroded material to dissolution & atmosphere
		float netCU = unlabeledCFlow;	    // net C flow
		amount = eflCU_ref (pool, ELF_Dis) * unlabeledCFlow;
		disLoss[EE_CU][pool] += amount;
		netCU -= amount;
		amount = eflCU_ref (pool, ELF_Gas) * unlabeledCFlow;
		gasLoss[EE_CU][pool] += amount;
		netCU -= amount;
		// Add net C losses to the erosion output file
		if ( eoFile.get() && netCU >= NSDepEro_poolMinThreshold )
			outData_ref(EE_CU, pool) = netCU;
	    }
	    // 2. labeled C
	    float labeledCFlow = fracLost * ciSource_ref (layer, LABELD);
	    if ( labeledCFlow >= NSDepEro_poolMinThreshold )
	    {
	    	// remove from the simulation pool
	    	flows.Schedule (
			&ciSource_ref (layer, LABELD), &soilC.csrsnk[LABELD],
			simTime, labeledCFlow);
		// C losses from eroded material to dissolution & atmosphere
		float netCL = labeledCFlow;		// net C flow
		amount = eflCL_ref (pool, ELF_Dis) * labeledCFlow;
		disLoss[EE_CL][pool] += amount;
		netCL -= amount;
		amount = eflCL_ref (pool, ELF_Gas) * labeledCFlow;
		gasLoss[EE_CL][pool] += amount;
		netCL -= amount;
		// Add net C losses to the erosion output file
		if ( eoFile.get() && netCL >= NSDepEro_poolMinThreshold )
			outData_ref(EE_CL, pool) = netCL;
	    }

	    //--- Amount of N, P, S lost from current pool
	    // Loss for each element is based on element/C ratio
	    register float netE;	// net element lost
	    for (short element = 0; element < numElem; ++element)
	    {
		float eLost = fracLost * eSource_ref (layer, element);
		if ( eLost >= NSDepEro_poolMinThreshold )
		{
		    flows.Schedule (
			&eSource_ref (layer, element), &nps.esrsnk[element],
			simTime, eLost);
		    netE = eLost;
		    // losses from eroded material to dissolution & atmosphere
		    if ( element == EE_N )
		    {
			amount = eflN_ref (pool, ELF_Dis) * eLost;
			disLoss[EE_N + element][pool] += amount;
			netE -= amount;
			amount = eflN_ref (pool, ELF_Gas) * eLost;
			gasLoss[EE_N + element][pool] += amount;
			netE -= amount;
		    }
		    // No S or P lost to dissolution or atmosphere currently.
		    // Add net losses to the erosion output file
		    if ( eoFile.get() && netE >= NSDepEro_poolMinThreshold )
			outData_ref(EE_N + element, pool) = netE;
		}
	    }
	}

	//--- write current output data to the erosion output file
	if ( eoFile.get() )
	{
		bool retVal =
			dynamic_cast<TNcErosionFile*>(eoFile.get())->
		    		WriteRecord (simTime, thickness, bulkDen,
						sand, silt, clay, outData);
		if ( retVal )	// write of data failed!
		{
			// TO DO: need error handling
		}
	}

	//--- Save eroded amounts in the output variables
	// Total C losses for this event
	soilC.eroC = soilC.somtc * fracLost;	// total C loss this event
	soilC.eroCcum += soilC.eroC;		// cumulative total C loss

	// all done!
#undef ciSource_ref
#undef eSource_ref
}

//	LowerToSimLayerPools
//	Do transfers from lower layer pools.
void TErosion::LowerToSimLayerPools (
	float const simTime, 		// simulation time
       	float const amtC[sizeC], 	// C transfer amounts (g m-2)
       	float amtE[sizeE] )		// Element transfer amounts (g m-2)
{
	float amtCTrans[NUMPOOLS] =	// Amount C transferred each pool
	  { 0.0f, 0.0f, 0.0f };		//   summed over isotopes.

	//--- transfer C to the simulation layer
	for (short isotope = 0; isotope < ISOS; ++isotope)
	{
		// ACTIVE pool
		amtCTrans[ACTIVE] += amtC_ref (ACTIVE, isotope);
		flows.Schedule (			// active C pool
			&soilC.csrsnk[isotope], &som1ci_ref (SOIL, isotope),
			simTime, amtC_ref (ACTIVE, isotope) );
		// SLOW pool
		amtCTrans[SLOW] += amtC_ref (SLOW, isotope);
		flows.Schedule (			// slow C pool
			&soilC.csrsnk[isotope], &soilC.som2ci[isotope],
			simTime, amtC_ref (SLOW, isotope) );
		// PASSIVE pool
		amtCTrans[PASSIVE] += amtC_ref (PASSIVE, isotope);
		flows.Schedule (			// passive C pool
			&soilC.csrsnk[isotope], &soilC.som3ci[isotope],
			simTime, amtC_ref (PASSIVE, isotope) );
	}

	//--- Transfer element at the same C:E ratio as in the
	//    simulation layer for the same pools.
	//    Etransferred = Ctransferred * Nsimlayer / Csimlayer
	float amtETrans;		// amount of element transferred
	for (short element = 0; element < numElem; ++element)
	{
		// ACTIVE pool
		amtETrans = std::min ( amtE_ref(ACTIVE, element),
				amtCTrans[ACTIVE] *
				som1e_ref(SOIL, element) / soilC.som1c[SOIL] );
		flows.Schedule (
			&nps.esrsnk[element], &som1e_ref (SOIL, element),
			simTime, amtETrans );
		amtE_ref(ACTIVE, element) = amtETrans;
		// SLOW pool
		amtETrans = std::min ( amtE_ref(SLOW, element),
				amtCTrans[SLOW] *
				nps.som2e[element] / soilC.som2c );
		flows.Schedule (
			&nps.esrsnk[element], &nps.som2e[element],
			simTime, amtETrans );
		amtE_ref(SLOW, element) = amtETrans;
		// PASSIVE pool
		amtETrans = std::min ( amtE_ref(PASSIVE, element),
				amtCTrans[PASSIVE] *
				nps.som3e[element] / soilC.som3c );
		flows.Schedule (
			&nps.esrsnk[element], &nps.som3e[element],
			simTime, amtETrans );
		amtE_ref(PASSIVE, element) = amtETrans;
	}

	//--- Save eroded amounts in the output variables
	// Cumulative erosion transfers for each pool
	for ( short i = 0; i < sizeC; ++i )
	    soilC.lhzcac += amtC[i];
	for (short element = 0; element < numElem; ++element)
	    for (short pool = 0; pool < NUMPOOLS; ++pool)
		nps.lhzeac[element] += amtE_ref (pool, element);
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Initialize
// 	initialize members
void TErosion::Initialize ()
{
	rate = 0.0f;
	enrichFactor = 1.0f;
	InitOutData ();
	for ( short e = EE_CU; e < EE_NumElements; e+=1 )
	    for (short p = (short)EPT_Active; p < (short)EPT_NumPools; p+=1 )
	    {
		// initialize accumulators
		disLoss[e][p] = gasLoss[e][p] = 0.0f;
		// initialize total element fractions lost
		if ( e == EE_CU )
			lossFraction[e][p] = eflCU_ref(p,0) + eflCU_ref(p,1);
		else if ( e == EE_CL )
			lossFraction[e][p] = eflCL_ref(p,0) + eflCL_ref(p,1);
		else if ( e == EE_N )
			lossFraction[e][p] = eflN_ref(p,0) + eflN_ref(p,1);
		else // currently no losses for P or S
			lossFraction[e][p] = 0.0f;
	    }
}

//	Copy
// 	copy to this
void TErosion::Copy (TErosion const & object)
{
	if ( &object )
	{
	    rate = object.rate;
	    enrichFactor = object.enrichFactor;
	    for ( short e = EE_CU; e < EE_NumElements; e+=1 )
		for (short p = (short)EPT_Active;
			p < (short)EPT_NumPools; p+=1 )
		{
		    // accumulators
		    disLoss[e][p] = object.disLoss[e][p];
		    gasLoss[e][p] = object.gasLoss[e][p];
		    // total element fractions lost
		    lossFraction[e][p] = object.lossFraction[e][p];
		}
	    float* pThis = outData;
	    float const * pThat = object.outData;
	    float const * const pEnd = outData + outDataSize;
	    while ( pThis < pEnd )
		*(pThis++) = *(pThat++);
	}
}

#undef outData_ref

//--- End of file T_Erosion.cpp ---
