
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


/* Rewrite the nremv.nc netCDF file using COARDS standards */
/* The original file was organized variable(cell, time) */
/* The new file is organized variable(time, lat, lon) */

#include <stdio.h>
#include "gridconst.h"
#include "netcdf.h"
#include "wrtcdf_ll.h"

    int write_nremv_ll_(int *ntimes, int *nlat, int *nlon, int lat_lon_mask[MAXCELLS]) {

      /* START and COUNT are dimensioned {TIME, LAT, LON} */
      size_t start[3] = {0, 0, 0}; 
      size_t count[3] = {0, 0, 0};
      size_t indx[2]  = {0, 0};
      float  fill = NC_FILL_FLOAT;
      float  val;
      float  shremn_vals[MAXCELLS], sdremn_vals[MAXCELLS], rlvremn_vals[MAXCELLS],
             fbrremn_vals[MAXCELLS], rlwremn_vals[MAXCELLS], wd1remn_vals[MAXCELLS],
             wd2remn_vals[MAXCELLS], stremn_vals[MAXCELLS], metrmn_vals[MAXCELLS],
             fstgrmn_vals[MAXCELLS];
      int status;
      int oldnremvid;
      int oldshremnid, oldsdremnid, oldrlvremnid, oldfbrremnid, oldrlwremnid,
          oldwd1remnid, oldwd2remnid, oldstremnid, oldmetrmnid, oldfstgrmnid;
      int ii, jj, ngrids;

      /* Open old version of nremv.nc file */
      status = nc_open("nremv.nc", NC_NOWRITE, &oldnremvid);
      if (status != NC_NOERR) handle_error("nc_open(nremv.nc)", status);

      /* Get the indices for the nremv output variables */
      status = nc_inq_varid(oldnremvid, "shremn", &oldshremnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for shremn",status);
      status = nc_inq_varid(oldnremvid, "sdremn", &oldsdremnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for sdremn",status);
      status = nc_inq_varid(oldnremvid, "rlvremn", &oldrlvremnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for rlvremn",status);
      status = nc_inq_varid(oldnremvid, "fbrremn", &oldfbrremnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for fbrremn",status);
      status = nc_inq_varid(oldnremvid, "rlwremn", &oldrlwremnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for rlwremn",status);
      status = nc_inq_varid(oldnremvid, "wd1remn", &oldwd1remnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wd1remn",status);
      status = nc_inq_varid(oldnremvid, "wd2remn", &oldwd2remnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for wd2remn",status);
      status = nc_inq_varid(oldnremvid, "stremn", &oldstremnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for stremn",status);
      status = nc_inq_varid(oldnremvid, "metrmn", &oldmetrmnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for metrmn",status);
      status = nc_inq_varid(oldnremvid, "fstgrmn", &oldfstgrmnid);
      if(status != NC_NOERR) handle_error("nc_inq_varid for fstgrmn",status);

      for (ii = 0; ii < *nlat * *nlon; ii++) {
        shremn_vals[ii] = fill;
        sdremn_vals[ii] = fill;
        rlvremn_vals[ii] = fill;
        fbrremn_vals[ii] = fill;
        rlwremn_vals[ii] = fill;
        wd1remn_vals[ii] = fill;
        wd2remn_vals[ii] = fill;
        stremn_vals[ii] = fill;
        metrmn_vals[ii] = fill;
        fstgrmn_vals[ii] = fill;
      }

      ngrids = 0;
      count[0] = 1;
      count[1] = *nlat;
      count[2] = *nlon;
      indx[0] = 0;
      /* Re-write the nremv output file */
      for (ii = 0; ii < *ntimes; ii++) {
        for (jj = 0; jj < *nlat * *nlon; jj++) {
          if(lat_lon_mask[jj]) {
            /* Read all of the output for the current time */
            status = nc_get_var1_float(oldnremvid, oldshremnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for shremn",status);
            }
            shremn_vals[jj] = val;
            status = nc_get_var1_float(oldnremvid, oldsdremnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for sdremn",status);
            }
            sdremn_vals[jj] = val;
            status = nc_get_var1_float(oldnremvid, oldrlvremnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for rlvremn",status);
            }
            rlvremn_vals[jj] = val;
            status = nc_get_var1_float(oldnremvid, oldfbrremnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for fbrremn",status);
            }
            fbrremn_vals[jj] = val;
            status = nc_get_var1_float(oldnremvid, oldrlwremnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for rlwremn",status);
            }
            rlwremn_vals[jj] = val;
            status = nc_get_var1_float(oldnremvid, oldwd1remnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wd1remn",status);
            }
            wd1remn_vals[jj] = val;
            status = nc_get_var1_float(oldnremvid, oldwd2remnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for wd2remn",status);
            }
            wd2remn_vals[jj] = val;
            status = nc_get_var1_float(oldnremvid, oldstremnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for stremn",status);
            }
            stremn_vals[jj] = val;
            status = nc_get_var1_float(oldnremvid, oldmetrmnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for metrmn",status);
            }
            metrmn_vals[jj] = val;
            status = nc_get_var1_float(oldnremvid, oldfstgrmnid, indx, &val);
            if(status != NC_NOERR) {
              fprintf(stdout, "ngrids %d\n", ngrids);
              handle_error("nc_get_var1 for fstgrmn",status);
            }
            fstgrmn_vals[jj] = val;
            ngrids++;
            /* Go to next cell */
            indx[0]++;
          }
        }
        ngrids = 0;
        /* Go back to first cell */
        indx[0] = 0;
        /* Write the values for the current time to the new netCDF file */
        status = nc_put_vara_float(nremvll_ncid, shremnll_id, start, count, shremn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for shremn",status);
        status = nc_put_vara_float(nremvll_ncid, sdremnll_id, start, count, sdremn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for sdremn",status);
        status = nc_put_vara_float(nremvll_ncid, rlvremnll_id, start, count, rlvremn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for rlvremn",status);
        status = nc_put_vara_float(nremvll_ncid, fbrremnll_id, start, count, fbrremn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for fbrremn",status);
        status = nc_put_vara_float(nremvll_ncid, rlwremnll_id, start, count, rlwremn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for rlwremn",status);
        status = nc_put_vara_float(nremvll_ncid, wd1remnll_id, start, count, wd1remn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wd1remn",status);
        status = nc_put_vara_float(nremvll_ncid, wd2remnll_id, start, count, wd2remn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for wd2remn",status);
        status = nc_put_vara_float(nremvll_ncid, stremnll_id, start, count, stremn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for stremn",status);
        status = nc_put_vara_float(nremvll_ncid, metrmnll_id, start, count, metrmn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for metrmn",status);
        status = nc_put_vara_float(nremvll_ncid, fstgrmnll_id, start, count, fstgrmn_vals);
        if(status != NC_NOERR) handle_error("nc_inq_varid for fstgrmn",status);
        /* Increment the time index */
        start[0]++;
        indx[1]++;
      } 

      /* Close the old output file */
      nc_close(oldnremvid);

      return 0;
    }
