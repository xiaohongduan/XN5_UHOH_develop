
/*              Copyright 1996 Colorado State University     */
/*                      All Rights Reserved                  */


#include "netcdf.h"
#include "wrtcdf.h"

int
write_nmnr(float nmnr[][12])
{
        int status;
        float *p = (float *) nmnr;

	/* Write output to NetCDF file */
	status = nc_put_vara_float(nmnr_ncid, gromin_id, start, count, p);
	status = nc_put_vara_float(nmnr_ncid, strmnr1_id, start, count, p + 12);
	status = nc_put_vara_float(nmnr_ncid, strmnr2_id, start, count, p + 24);
	status = nc_put_vara_float(nmnr_ncid, metmnr1_id, start, count, p + 36);
	status = nc_put_vara_float(nmnr_ncid, metmnr2_id, start, count, p + 48);
	status = nc_put_vara_float(nmnr_ncid, s1mnr1_id, start, count, p + 60);
	status = nc_put_vara_float(nmnr_ncid, s1mnr2_id, start, count, p + 72);
	status = nc_put_vara_float(nmnr_ncid, s2mnr_id, start, count, p + 84);
	status = nc_put_vara_float(nmnr_ncid, s3mnr_id, start, count, p + 96);
	status = nc_put_vara_float(nmnr_ncid, wd1mnr_id, start, count, p + 108);
	status = nc_put_vara_float(nmnr_ncid, wd2mnr_id, start, count, p + 120);
	status = nc_put_vara_float(nmnr_ncid, wd3mnr_id, start, count, p + 132);

	/* Reset memory for variable nmnr */
	 memset(p, '\0', (sizeof(float) * 12 * 12));

	return 0;
}
