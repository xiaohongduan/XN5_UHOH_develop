// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  IRC  ( www.nrel.colostate.edu/projects/irc/ )
//	File:	  CmdLine.cpp
//	Class:	  CmdLine
//
//	Interface class for the IRC adaptor to the DayCent model.
// ----------------------------------------------------------------------------
//	Author:	Thomas E. Hilinski, March 2005
//	History: See header file.
// ----------------------------------------------------------------------------

#include "CmdLine.h"
#include "stringutil.h"
#include <cstdlib>
using namespace nrel::dcirc;

// ----------------------------------------------------------------------------
//	member constants
// ----------------------------------------------------------------------------

std::string const CmdLine::helpMsg =		// option descriptions
  "DayCentIRC command-line options:\n"
  "-i <file name>                  "
  	" (Required) Specify the simulation INI file name.\n"
  "-V or --version                 Display version information.\n"
  "-C or --copyright               Display copyright statement.\n"
  "-S or --support                 Display support information.\n"
  "-D or --disclaimer              Display disclaimer statement.\n"
  "-dcl or --display-command-line  Echo your command-line options.\n"
  "-? or --help                    Displays this help screen.";

std::string const CmdLine::options[] =		// options list
{
	std::string ("-i"),
	std::string ("-V"),
	std::string ("-C"),
	std::string ("-S"),
	std::string ("-D"),
	std::string ("-dcl"),
	std::string ("-?"),
	EMPTY_STRING
};

std::string const CmdLine::altOptions[] =	// alternate options list
{
	std::string ("--ini-file"),
	std::string ("--version"),
	std::string ("--copyright"),
	std::string ("--support"),
	std::string ("--disclaimer"),
	std::string ("--display-command-line"),
	std::string ("--help"),
	EMPTY_STRING
};

bool CmdLine::HaveOption (
	TIndexOptionList const index,
	std::string const & argStr)
{
      #ifdef __BCPLUSPLUS__
	// BCB6 wierdness - string::operator== always returning false!
	// seems to be a linker issue - "trace into" jumps to
	// TTimeManager.h::GetMaximumLimit()
	// So we'll use strcmp instead.
	return ( strcmp ( argStr.c_str(), options[index].c_str() ) == 0 ||
		 strcmp ( argStr.c_str(), altOptions[index].c_str() ) == 0 );
      #else
	return argStr == options[index] || argStr == altOptions[index];
      #endif
}

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

CmdLine::CmdLine (
	int newArgc, 					// number of arguments
	char const * const * const newArgv,		// list of arguments
	void (*useMsgFunction)(char const* const),	// message function
	bool const suppressWarnings)			// suppress messages?
	: origArgc (newArgc),
	  origArgv (newArgv),
	  msgFunction (useMsgFunction),
	  displayWarnings (!suppressWarnings),
	  numArgsUsed (0),
	  error (false),
	  terminate (false)
{
	if ( origArgc == 0 || !origArgv )		// anything there?
	{
		numArgsUsed = -1;			// error flag = -1
		return;
	}

	// skip the command for the program
	numArgsUsed = 0;
	if ( ProcessCmdLineArgs() )		// processed ok?
		terminate = true;
	if ( numArgsUsed < origArgc - 1 )	// used all args?
		terminate = true;
}

// ----------------------------------------------------------------------------
//	operator overloads
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

//	DisplayCommandLine
//	Writes the command line to the msg function.
void CmdLine::DisplayCommandLine ()
{
	std::string msg = "Command-line arguments: ";
	for ( short i = 1; i < origArgc; i++ )	// copy the args
	{
		msg += origArgv[i];
		msg += " ";
	}
	if (msgFunction)
		(*msgFunction)( msg.c_str() );
}

//	ProcessCmdLineArgs
//	Parses the command line arguments and saves the information.
//	Returns false if all required args are specified, else true if not.
//	Notes:
//	Sets 2 messages - (1) error in the arguments; (2) terminate execution.
//	Also, counts the number of args used = number of valid arguments.
bool CmdLine::ProcessCmdLineArgs ()
{
	std::string msg;			// output message
	bool ignoreError = false;		// true if display error msg

	short numArgs = origArgc - 1;		// Subtract exe file name
	char const * const * args = origArgv + 1;

	// any command-line args to process?
	if ( numArgs <= 0 )
	{
		if (msgFunction && displayWarnings)
			(*msgFunction)( GetCmdLineHelpStr().c_str() );
		return true;
	}

	// process the arguments
	while (numArgs > 0 && *args)
	{
	    std::string curArg;				// current argument
	    //curArg = *(args++);			// get next arg
	    curArg = *args;		// for BCB6 wierdness here
	    ++args;

	    //--- simulation INI file ---
	    if ( HaveOption (Iini_file, curArg) )
	    {
		// Expect next arg to be a file name.
		--numArgs;
		++numArgsUsed;
		curArg = *(args++);			// get file name
		if ( curArg.empty() )			// anything there?
			continue;			// ...no
		iniFile = curArg;			// save it
		// To Do: Remove quotes enclosing the file name.
		--numArgs;
		++numArgsUsed;
		continue;
	    }

	    else if ( HaveOption (Iversion, curArg) )
	    {
	    	if (msgFunction)
		{
		    // version
		    std::string displayStr;
		    StringArrayToString (about.GetVersions(), displayStr);
		    (*msgFunction)( displayStr.c_str() );
		    // platform
		    displayStr.clear();
		    StringArrayToString (about.GetPlatform(), displayStr);
		    (*msgFunction)( displayStr.c_str() );
		}
		terminate = true;		// don't do anything else
		ignoreError = true;
		--numArgs;
		++numArgsUsed;
		continue;
	    }

	    else if ( HaveOption (Icopyright, curArg) )
	    {
	    	if (msgFunction)
		{
		    std::string displayStr = about.GetProductName();
		    displayStr += ":\n";
		    StringArrayToString (about.GetCopyright(), displayStr);
		    displayStr += "\nOrganization:\n";
		    StringArrayToString (about.GetContacts(), displayStr);
		    (*msgFunction)( displayStr.c_str() );
		}
		terminate = true;		// don't do anything else
		ignoreError = true;
		--numArgs;
		++numArgsUsed;
		continue;
	    }

	    else if ( HaveOption (Isupport, curArg) )
	    {
	    	if (msgFunction)
		{
		    std::string displayStr;
		    StringArrayToString (about.GetSupport(), displayStr);
		    StringArrayToString (about.GetLinks(), displayStr);
		    (*msgFunction)( displayStr.c_str() );
		}
		terminate = true;		// don't do anything else
		ignoreError = true;
		--numArgs;
		++numArgsUsed;
		continue;
	    }

	    else if ( HaveOption (Idisclaimer, curArg) )
	    {
	    	if (msgFunction)
		{
		    std::string displayStr;
		    StringArrayToString (about.GetDisclaimer(), displayStr);
		    (*msgFunction)( displayStr.c_str() );
		}
		terminate = true;		// don't do anything else
		ignoreError = true;
		--numArgs;
		++numArgsUsed;
		continue;
	    }

	    else if ( HaveOption (Ihelp, curArg) )
	    {
	    	if (msgFunction)
	    	{
	    	    (*msgFunction)( GetCmdLineHelpStr().c_str() );
	    	}
		--numArgs;
		++numArgsUsed;
		terminate = true;		// don't do anything else
		ignoreError = true;
		continue;
	    }

	    else if ( HaveOption (Idcl, curArg) )
	    {
		DisplayCommandLine ();
		--numArgs;
		++numArgsUsed;
		continue;
	    }

	    // unknown argument
	    if (msgFunction && displayWarnings)
	    {
	    	msg = "An unknown command-line option was found and ignored.\n";
	    	msg += "The option is: ";
	    	msg += curArg;
		(*msgFunction)( msg.c_str() );
	    }
	    --numArgs;				// decrement counter
	}

	// return status
	error = (numArgsUsed != origArgc - 1);
	// required for the command-line version:
	if ( !ignoreError && error )
	{
		if ( msgFunction && displayWarnings )
		{
		    std::string errorMsg =
		    	"A required command-line option was not specified.";
		    if ( iniFile.empty() )
		    {
		    	errorMsg +=
			  "\nError: "
			  "You must specify the simulation INI file name.";
		    }
		    (*msgFunction)( errorMsg.c_str() );
		}
		error = true;
	}
	return error;
}

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//--- end of definitions for CmdLine ---
