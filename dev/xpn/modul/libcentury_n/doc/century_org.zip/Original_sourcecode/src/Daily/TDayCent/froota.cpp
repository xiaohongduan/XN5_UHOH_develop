// ----------------------------------------------------------------------------
//	Project:  Century Soil Organic Matter Model
//	File:	  froota.cpp
//	Class:	  TDayCent
//	Function: FractionRootAllocation
//
//	Description:
//      Compute the fraction of production going to fine roots in crops,
//      grasses, and woody plants based on water and nutrient availability.
// ----------------------------------------------------------------------------
//      Sep00   Melannie Hartman, melannie@nrel.colostate.edu
//      * Created this function for the Dynamic Carbon Allocation
//        (FORTRAN/C) version of DayCent
//      May01   Melannie Hartman, melannie@nrel.colostate.edu
//      * Translated froota.f to froota.cpp
//      May02   Melannie Hartman, melannie@nrel.colostate.edu
//      * Added Assert statements to check value of parcp.monthsSincePlanting
// ----------------------------------------------------------------------------
//	Copyright 2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//      Notes:
//
//      For trees only:
//        frfrac[0] - minimum possible allocation fraction to fine roots
//                    (tree.100)
//        frfrac[1] - maximum possible allocation fraction to fine roots
//                    (tree.100)
//
//      For grasses/crops only (crop.100):
//        frtcindx  - (0) Use Great Plains eqn, (1) perrenial plant,
//                    (2) annual plant
//        frtc[0]   - initial (maximum) fraction of C allocated to fine roots
//        frtc[1]   - final (minimum) fraction of C allocated to fine roots
//        frtc[2]   - months after planting at which final value is reached
//                   (annuals only)
//        frtc[3]   - range about frtc[0] (annuals only)
// ----------------------------------------------------------------------------

#include "TDayCent.h"
#include "TCenturyMath.h"

float TDayCent::FractionRootAllocation (
    int const systype,           // SysType_Forest or SysType_CropGrass
    float const a2drat[NUMELEM], // ratio of E available to E demand by plant
    float const h2ogef)          // effect of water on root to shoot ratio
{

#ifdef NDEBUG
    for (short element = 0; element < site.nelem; ++element)
    {
	Assert (a2drat[element] >= 0.0f);
	Assert (a2drat[element] <= 1.0f);
    }
#endif

    float h2oeff = 0.0f;  	// effect of water stress on root C fraction
    float ntreff = 0.0f;  	// effect of nutrient stress in root C fraction
    float rtsh = 0.0f;    	// root to shoot ratio
    float froota = -1.0f;	// fraction of C to be allocated to roots
				//   (return value)

    if ( systype == SysType_Forest )
    {
        // Effect of water limitation - inverse of growth curve
	h2oeff = parfs.frfrac[0] +
		((parfs.frfrac[1] - parfs.frfrac[0]) * (1.0f - h2ogef));

        // Effect of nutrient limitation
	ntreff = 0.0f;
        for (short e = 0; e < site.nelem; ++e)
        {
	    float const temp = YOnLine (
		  a2drat[e], 0.0f, parfs.frfrac[1], 1.0f, parfs.frfrac[0]);
            ntreff = std::max(temp, ntreff);
        }

        // Compute fraction of C to go to fine roots
        froota = std::max(h2oeff, ntreff);
        Assert (froota >= parfs.frfrac[0]);
        Assert (froota <= parfs.frfrac[1]);
    }
    else if ( systype == SysType_CropGrass  )
    {
        // Effect of nutrient limitation
        ntreff = 0.0f;
        for (short e = 0; e < site.nelem; ++e)
        {
	    float const temp = YOnLine (
		a2drat[e], 0.0f, parcp.frtc[0], 1.0f, parcp.frtc[1]);
            ntreff = std::max(temp, ntreff);
        }
        if (parcp.frtcindx == 0)
        {
            // Use Great Plains equation for root to shoot ratio

            //parcp.grwprc = weather->GrowingSeasonPrecip (month) - in cycle.cpp
            rtsh = (fixed.bgppa + parcp.grwprc * fixed.bgppb) /
    	           (fixed.agppa + parcp.grwprc * fixed.agppb);
	    froota = 1.0f / (1.0f / rtsh + 1.0f);
        }
        else if (parcp.frtcindx == 1)
        {
            // A perennial plant (grass)

	    h2oeff = YOnLine (h2ogef, 0.0f, parcp.frtc[0], 1.0f, parcp.frtc[1]);
            froota = std::max(h2oeff, ntreff);
            froota = std::min(froota, 1.0f);
        }
        else if (parcp.frtcindx == 2)
        {
            // An annual plant (crop)
            Assert( parcp.MonthsSincePlanting() >= 0 );
            Assert( parcp.MonthsSincePlanting() <= 24 );

            if (parcp.MonthsSincePlanting() > parcp.frtc[2])
            {
                froota = parcp.frtc[1];
            }
            else
            {
		Assert ( parcp.frtc[2] > 0.0f );
		h2oeff =
		    YOnLine(h2ogef, 0.0f, parcp.frtc[0], 1.0f, parcp.frtc[1]);
                froota = std::max(h2oeff, ntreff);
                froota = std::min(froota, 1.0f);
                float const froot_max =
                  parcp.frtc[0] + froota * parcp.frtc[3] - 0.5f * parcp.frtc[3];
                froota = froot_max - parcp.MonthsSincePlanting()
                        * (froot_max - parcp.frtc[1]) / parcp.frtc[2];
            }
        }
    }

    Assert (froota >= 0.0f);
    Assert (froota <= 1.0f);
    return froota;
}
