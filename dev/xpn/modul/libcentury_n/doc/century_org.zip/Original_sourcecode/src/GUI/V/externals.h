#ifndef INC_externals_h
#define INC_externals_h
// ----------------------------------------------------------------------------
//	Copyright 1998-2002 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Model Interface - V GUI
//	File:	  externals.h
//
//	Description:
//	External declarations for global variables.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Nov-Dec97
//	History:
//	Jun01	Tom Hilinski, tom.hilinski@colostate.edu
//	* Housekeeping.
// ----------------------------------------------------------------------------

#include "constants.h"
#include "TTextCmdWin.h"
#include "TCentConfig.h"
#include "TUserPref.h"

//--- Global variables

//	GUI:
extern	TCMIApp myApp;				// global application instance

//	Application Data:
extern
  std::auto_ptr<TCenturyConfig> centuryConfig;	// Century model configuration
extern	TUserPref userPref;			// user preferences

//--- Pointers to application data
extern	TSharedPtr<CenturyPaths> defPaths;	// default directory paths
extern	std::string helpPath;			// Windows Help file name

//--- Macros to access members of global variables
// For the main window:
#define HistText(str)	(myApp.historyWindow->Text(str))
// For the messages window (warnings, errors):
#define MsgText(str)	(myApp.messageWindow->Text(str))
// For the status bar "action" text:
#define ActionMsg(str)	(myApp.historyWindow->ActionTextAll(str))
// For the status bar "status" text:
#define StatusMsg(str)	(myApp.historyWindow->StatusTextAll(str))

#endif // INC_externals_h


