// ----------------------------------------------------------------------------
//	Developed in part with funding from the
//	National Science Foundation grant NSF DEB-9977066.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model, monthly version
//	File:     TMCSoil.cpp
//	Class:    TMCSoil
//
//	Description:
//	Derived from TCenturySoil, implements monthly Century-specific
//	functions.
// ----------------------------------------------------------------------------
//	Author: Tom Hilinski, tom.hilinski@colostate.edu, Aug03
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TMCSoil.h"

// ----------------------------------------------------------------------------
//	Member constants
// ----------------------------------------------------------------------------

// The following indices must match the order in which the components are
// added to the component list.
// See sitein.cpp for the order.
short const				// component indices
	TMCSoil::indexMineralN		= 8,
	TMCSoil::indexMineralP		= 9,
	TMCSoil::indexMineralS		= 10;



//--- end of file ---
