// ----------------------------------------------------------------------------
//	Copyright 1999-2001 Colorado State University. All rights reserved.
// ----------------------------------------------------------------------------
//	Organization:	Natural Resource Ecology Laboratory
//			Colorado State University, Fort Collins, CO 80523 USA
//			www.nrel.colostate.edu
//	Project:  Century Soil Organic Matter Model
//	File:	  TCentNcFile.cpp
//	Class:	  TCentNcFile
//
//	Description:
//	Century output file class which builds a netCDF file containing
//	Century output variables.
// ----------------------------------------------------------------------------
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu, Jan99
//	History: See header file.
// ----------------------------------------------------------------------------

#include "TCentNcFile.h"
#include "TManagement.h"
#include "TMCSiteParameters.h"
#include "timeutil.h"
#include "util.h"

// ----------------------------------------------------------------------------
//	 constructors and destructor
// ----------------------------------------------------------------------------

TCentNcFile::TCentNcFile (
	std::string const & useFileName, 	// file name instance
	TOutputBase::TAccessMode const useAccess,	// file access mode
	TManagementScheme & useMgmt,		// simulation mgmt. scheme
	TMCSiteParameters & useSite,		// site parameter set
	std::string const & useUserName,	// user name for output file
	TEH::TFileName const & useOVDefPath)	// path to the netCDF file with
						//   the names and definitions
						//   of the output variables.
	: TMCOutputFileBase ( useFileName,
			Type_NetCDF, useAccess, Format_Binary,
			useMgmt, useSite, useUserName, useOVDefPath )
{
	Initialize ();
	char const * const extension = "nc";		// expected extension
	TEH::TFileName tempName (			// parse file name
	  fileName, TEH::TFileName::FT_Normal );
	tempName.SetExtension (extension);		// force extension
	fileName = tempName.GetFullName();		// save it
}

// ----------------------------------------------------------------------------
//	public functions
// ----------------------------------------------------------------------------

//	WriteRecord
//	Write one record to the file stream.
//	Returns false if successful, else true if failed or error.
bool TCentNcFile::WriteRecord (
	float const simTime)		//   simulation time
{
	// error handling
	NcError myErr (NcError::silent_nonfatal);	// error handler
	bool r;					// return from functions
	char const * str = 0;			// string for error msgs
	#define CheckResult(s,p)	if (!p) { str = s; goto error_done; }

	// get size of the unlimited dimension
	long numRec = fp->get_dim(0)->size();	// == the next record number
	// get the number of output sets
	short const numSets = outputSetList.size();	// set here only!

	//--- write the data
	// 1. simulation time
	r = ncVars[0]->put_rec (&simTime, numRec);
	CheckResult("time", r)
	// 2. output sets
	{
	    for ( short outputSet = 0; outputSet < numSets; ++outputSet )
	    {
		//--- Get list of values and the size of the list
		float const ** p =			// ptr to data array
			const_cast<float const **>(outputSetList[outputSet]->p);
		short numValues = outputSetList[outputSet]->GetNumValues ();
		//--- Write the data for the current output set
		::CopyListToArray (list, p, numValues );
		r = ncVars[1]->put_rec (list, numRec);
		CheckResult(outputSetName[outputSet], r)
	    }
	}
/*-----
	// 2. water/temperature
	::CopyListToArray (list, const_cast<float const**>(wt.p),
			   wt.GetNumValues() );
	r = ncVars[1]->put_rec (list, numRec);
	CheckResult("wt", r)
	// 3. soil C
	::CopyListToArray (list, const_cast<float const**>(soilC.p),
			   soilC.GetNumValues() );
	r = ncVars[2]->put_rec (list, numRec);
	CheckResult("soilC", r)
	// 4. crop/grass C
	::CopyListToArray (list, const_cast<float const**>(cropC.p),
			   cropC.GetNumValues() );
	r = ncVars[3]->put_rec (list, numRec);
	CheckResult("cropC", r)
	// 5. forest C
	::CopyListToArray (list, const_cast<float const**>(forestC.p),
			   forestC.GetNumValues() );
	r = ncVars[4]->put_rec (list, numRec);
	CheckResult("forestC", r)
	// 6. CO2
	::CopyListToArray (list, const_cast<float const**>(co2.p),
			   co2.GetNumValues() );
	r = ncVars[5]->put_rec (list, numRec);
	CheckResult("co2", r)
	// 7. N, P, S
	::CopyListToArray (list, const_cast<float const**>(nps.p),
			   nps.GetNumValues() );
	r = ncVars[6]->put_rec (list, numRec);
	CheckResult("NPS", r)
-----*/

	// all done!
	fp->sync ();
	++lastRecord;			// increment record number
	modified = true;		// files have been modified
	return false;			// successful write

error_done:
	{
	    msg = "Error occurred with NetCDF output variable ";
	    msg += str;
	    msg += "\nNetCDF message: ";
	    msg += ::nc_strerror( myErr.get_err() );
	    ncErrStr = msg.c_str();
	    return true;
	}
}

// ----------------------------------------------------------------------------
//	protected functions
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//	private functions
// ----------------------------------------------------------------------------

//	Initialize
// 	initialize members
void TCentNcFile::Initialize ()
{
	fp = 0;
	numNcVars = 0;
	ncVars = 0;
	ncErrStr = 0;
}

//	Copy
//	Copy to this.
//	Assumes Clear() has been called prior.
void TCentNcFile::Copy (
	TCentNcFile const & object)
{
	if ( &object )
	{
		// To Do: TCentNcFile::Copy
	}
}

//	CreateNCOutputStructure
//	Creates the structure for the netCDF output file.
//	Returns false if successful, else true if not.
bool TCentNcFile::CreateNCOutputStructure ()
{
	bool retVal = false;			// return value
	bool r;					// return from functions
	register short k;			// array index

	// dimension names and sizes
	short const numDims = 7;
	char *dimNames[] = { "numRec", "lenWT", "lenSoilC", "lenCropC",
			     "lenForestC", "lenCO2", "lenNPS" };
	long dimSizes[numDims - 1];
	for ( short i = 0; i < numDims - 1; ++i )
		dimSizes[i] = outputSetList[i]->GetNumValues();
	NcDim *dim[numDims];			// pointers to dimensions

	// variable names
	char *varNames[] = { "time", "watertemp", "soilC", "cropC", "forestC",
			     "co2", "NPS" };

	// attribute names
	char const* attNames[] =
	{
		"title", "SimDescription", "MgmtFile", "SiteFile", "SiteDesc",
		"LastModifiedWho", "LastModifiedWhen",
		"FileType", "Version"
	};
	char const* titleAttr = 		// title attribute
			"Century Simulation Output";
	// Modify the version when the structure of this file changes
	short const versionNumber = 2;

	// initialize error handling
	NcError ncErr (NcError::silent_nonfatal);	// error handler
	const char *locStr = 0;    			// error location
	ncErrStr = 0;

#define ChkErr(r,s) \
	if ( r && ncErr.get_err() != NC_NOERR ) \
	{ \
		ncErrStr = (char*)::nc_strerror ( ncErr.get_err() ); \
		locStr=s; goto error_done; \
	}

	// add the dimensions
	dim[0] = fp->add_dim(dimNames[0]);		// unlimited dimension
	ChkErr(true, dimNames[0])
	for ( short i = 1; i < numDims; i++ )		// sized dimensions
	{
		dim[i] = fp->add_dim(dimNames[i], dimSizes[i - 1]);
		ChkErr(true, dimNames[i])
	}

	// add the variables
	ncVars[0] = fp->add_var(varNames[0], ncFloat, dim[0]);	     // time
	ChkErr(true, varNames[0])
	for ( short i = 1; i < numNcVars; i++ )		// remaining variables
	{
		ncVars[i] = fp->add_var(varNames[i], ncFloat, dim[0], dim[i]);
		ChkErr(true, varNames[i])
	}

	// add the global attributes
	k = 0;
	// title
	r = fp->add_att (attNames[k], titleAttr);
	ChkErr(r, attNames[k])
	{ // limit scope of variable str
		// simulation description
		std::string str = mgmt.GetSimDescription();
		if ( !mgmt.IsEmpty() && !str.empty() )
		{
			r = fp->add_att ( attNames[++k], str.c_str() );
			ChkErr(r, attNames[k])
		}
		// management file name
		str = mgmt.GetBaseName();
		if ( !mgmt.IsEmpty() && !str.empty() )
		{
			r = fp->add_att ( attNames[++k], str.c_str() );
			ChkErr(r, attNames[k])
		}
		// simulation file name
		str = site.GetBaseName().c_str();
		if ( !site.IsEmpty() && !str.empty() )
		{
			r = fp->add_att ( attNames[++k], str.c_str() );
			ChkErr(r, attNames[k])
		}
		// simulation description
		str = site.GetDescription().c_str();
		if ( !site.IsEmpty() && !str.empty() )
		{
			r = fp->add_att ( attNames[++k], str.c_str() );
			ChkErr(r, attNames[k])
		}
		// user's name
		if ( !userName.empty() )
			str = userName;
		else
			str = "none specified";
		r = fp->add_att ( attNames[++k], str.c_str() );
		ChkErr(r, attNames[k])
	}
	// date/time of creation
	r = fp->add_att ( attNames[++k], ::DateTimeStr().c_str() );
	ChkErr(r, attNames[k])
	// file type
	r = fp->add_att ( attNames[++k], (long)NCFT_CenturyOutput );
	ChkErr(r, attNames[k])
	// netCDF file version number
	r = fp->add_att ( attNames[++k], (long)versionNumber );
	ChkErr(r, attNames[k])
	goto all_done;

error_done:
	// handle error
	msg = "Error creating netCDF output file.\nNetCDF error: ";
	msg += ncErrStr;
	msg += "\nwhile creating ";
	msg += locStr;
	ncErrStr = msg.c_str();

all_done:
	fp->sync ();
	return retVal;
}

//	DoOpen
//	Open the output file.
//	Return state of output engine..
TCentNcFile::TState TCentNcFile::DoOpen ()
{
	// if already open, close it
	if ( state == State_Open )
		Close ();

	// get access mode specifier for netCDF file
	NcFile::FileMode mode;
	switch ( accessMode )
	{
	  case Mode_New:	mode = NcFile::New;		break;
	  case Mode_Replace:	mode = NcFile::Replace;		break;
	  case Mode_Append:	mode = NcFile::Write;		break;
	  default:
	  	errorState = Error_InvalidAccess;
	  	return state;
	}

	// create a new netCDF file instance and open the file
	NcError myErr (NcError::silent_nonfatal);	// error handler
	fp = new NcFile ( fileName.c_str(), mode );	// create instance
	if ( !fp->is_valid() )			// failed?
	{
		ncErrStr = ::nc_strerror ( myErr.get_err() );
		errorState = Error_OpenFailed;
		return state;
	}

	// Get netCDF variable count and allocate mem for variables
	numNcVars = (short)(ovi->GetCategoryCount() + 1);// time + categories
	ncVars = new NcVar* [numNcVars];		// memory for array

	// Create the output file structure
	if ( CreateNCOutputStructure() )
	{
		errorState = Error_OpenFailed;
		return state;
	}

	// all done!
	state = State_Open;
	return state;
}

//	DoClose
//	Close the output file.
//	Return state of output engine.
TCentNcFile::TState TCentNcFile::DoClose ()
{
	delete fp;
	fp = 0;
	delete [] ncVars;
	ncVars = 0;
	state = State_Closed;
	return state;
}

//	DoReset
//	Reset the output file to its initialized state.
//	Return state of output engine.
TCentNcFile::TState TCentNcFile::DoReset ()
{
	Close ();
	accessMode = Mode_Replace;
	Open ();
	if ( state != State_Open || errorState != Error_NoError )
	{
		Assert (state == State_Open);
		Assert (errorState == Error_NoError);
		// To do: Handle DoReset Open failed
	}
	return state;
}

//--- end of definitions for TCentNcFile ---
