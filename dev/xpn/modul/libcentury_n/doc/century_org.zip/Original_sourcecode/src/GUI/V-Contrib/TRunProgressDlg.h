#ifndef INC_TRunProgressDlg_h
#define INC_TRunProgressDlg_h
// ----------------------------------------------------------------------------
//	Copyright (c) 1998, T.E. Hilinski. All rights reserved.
//	This software is made freely available for non-commercial use.
//	This copyright notice must remain intact and in place.
// ----------------------------------------------------------------------------
//	File:	  TRunProgressDlg.h
//	Class:	  TRunProgressDlg
//
//	Description:
//	Class for Displaying the progress of an action in a progress bar.
//
//	Author:	Tom Hilinski, tom.hilinski@colostate.edu
// ----------------------------------------------------------------------------
// Example of using this dialog to display a progress bar:
//
//	const char
//		*caption = "Simulation is running.\n"
//			   "Press Cancel to stop the simulation.",
//		*leftLabel = "start",
//		*rightLabel = "end",
//		*title = "Simulation Progress";
//
//	TRunProgressDlg dlg (myApp, caption, leftLabel, rightLabel, true, title);
//	for ( short pct = 0; pct <= 100; pct += 10 )
//	{
//		if ( !dlg.IsDisplayed() )
//			break;
//		dlg.Update (pct);
//		sleep(1);
//	}
//	if ( dlg.IsDisplayed() )
//	{
//		vNoticeDialog nd (myApp);
//		nd.Notice ("Simulation has finished.");
//		dlg.CloseDialog ();
//	}
// ----------------------------------------------------------------------------

#include <v/vdialog.h>

//	-----------------------------------------------------------------------
//	Command objects values
enum {
	Enum_DP_Start = 1000,		// first item!
					//--- controls
	DC_Caption,			// text: caption above bar
	DC_LeftLabel,			// text: left bar label
	DC_RightLabel,			// text: right bar label
	DC_ProgressBar,			// progress bar
					//--- all done!
	Enum_DP_End			// last item!
};

//	-----------------------------------------------------------------------
//	TRunProgressDlg
class TRunProgressDlg : public vDialog
{
  public:
	//--- constructors and destructor
	TRunProgressDlg (
	  vApp* const useParent,		// ptr to parent app
	  char const* newCaption = 		// explanatory caption for bar
	  		"Percent Completed:",
	  char const* newLeftLabel = 0,		// text label left of bar
	  char const* newRightLabel = 0,	// text label right of bar
	  bool showPct = false,			// true if displaying percent
	  char const* title = "Progress",	// text for dialog title bar
	  CmdAttribute size = CA_None);		// CA_None, CA_Small, CA_Large
	TRunProgressDlg (vBaseWindow * const parent,
	  vApp* const useParent,		// ptr to parent app
	  char const* newCaption = 		// explanatory caption for bar
	  		"Percent Completed:",
	  char const* newLeftLabel = 0,		// text label left of bar
	  char const* newRightLabel = 0,	// text label right of bar
	  bool showPct = false,			// true if displaying percent
	  char const* title = "Progress",	// text for dialog title bar
	  CmdAttribute size = CA_None);		// CA_None, CA_Small, CA_Large
	~TRunProgressDlg ();

	//--- functions overridden
	void DialogDisplayed ();
	void DialogCommand (ItemVal id, ItemVal val, CmdType type);

	//--- functions
	void UseCancelFunction (void (*)());	// function to call upon cancel
	void Update (int percent);		// update the bar display
	void Reset ();				// reset to original state

  private:
	//--- data
	vApp* const parent;		// pointer to parent app
	static CommandObject cmdList[];	// dialog elements
	char *caption,			// explanatory caption for bar
	     *leftLabel,		// text for label on left end of bar
	     *rightLabel;		// text for label on right end of bar
	bool displayPct;		// true if displaying percent progress
	int curValue;			// current value of bar
	void (*cancelFunction)();	// function to call upon cancel
	//--- functions
	void Initialize (char const* newCaption,	// initialize data
			 char const* newLeftLabel,
			 char const* newRightLabel,
			 bool showPct,
			 CmdAttribute newSize);
};

#endif // INC_TRunProgressDlg_h
